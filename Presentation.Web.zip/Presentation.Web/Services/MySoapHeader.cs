﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services.Protocols;

namespace RWIS.Presentation.Web.Services
{
    public class MySoapHeader : SoapHeader
    {
        public string UserName;
        public string PassWord;

        public bool ValideUser(string userName, string password)
        {
            if (userName.Equals("PCISMSG") && password.Equals("cissmsgtol79"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}