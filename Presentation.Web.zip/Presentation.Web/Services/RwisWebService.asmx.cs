﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using System.Web.Services.Protocols;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using CIT.UPC.Authorization.Client;
using UpcAuthClient = CIT.UPC.Authorization.Client;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels;
using System.Data.Entity.Validation;

namespace RWIS.Presentation.Web.Services
{
    /// <summary>
    /// 常量信息 
    /// </summary>
    public  class ConstObject
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string Uuid { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// 编码
        /// </summary>
        public string Code { get; set; }

        public string Name { get; set; }

        /// <summary>
        /// 父ID
        /// </summary>
        public string ParentUuid { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 顺序值
        /// </summary>
        public Nullable<decimal> SortNumber { get; set; }

  
        public string Remark { get; set; }

        /// <summary>
        /// 创建人员ID
        /// </summary>
        public string CreateUserId { get; set; }

        /// <summary>
        /// 创建人员名称
        /// </summary>
        public string CreateUserName { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public Nullable<System.DateTime> CreateTime { get; set; }


        /// <summary>
        /// 是否区分电站(0:否 1:是)
        /// </summary>
        public string IsmultiStation { get; set; }
        /// <summary>
        /// 电站编号
        /// </summary>
        public string StationCode { get; set; }
    }

    /// <summary>
    /// 用户约束信息 
    /// </summary>
    public class UserConstraint
    {
        public string UserCode { get; set; }
        public string Constraint { get; set; }
    }


    /// <summary>
    /// 设备维护
    /// </summary>
    public class EquipManage
    {
        public string EquipId { get; set; }
        public string EquipName { get; set; }
        public string FunctionPosition { get; set; }
    }
    /// <summary>
    /// RwisWebService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消对下行的注释。
    // [System.Web.Script.Services.ScriptService]
    public class RwisWebService : System.Web.Services.WebService
    {
        //公有令牌变量
        public MySoapHeader header;

        /// <summary>
        /// 验证令牌
        /// </summary>
        /// <returns></returns>
        #region private bool IsValiToken()
        private bool IsValiToken()
        {
            bool flag = false;
            if (header.ValideUser(header.UserName, header.PassWord))
            {
                flag = true;
            }
            return flag;
        }
        #endregion

        #region 写入日志
        public void WriteErrorLog(string title, string content)
        {
            ILogRepository logRepository = ServiceLocator.Current.GetInstance<ILogRepository>();
            //记录接口错误日志
            Log log = new Log();
            log.Logid = Guid.NewGuid().ToString();
            log.Createdate = DateTime.Now;
            log.Title = title;
            log.Subsysid = "RWIS";
            log.Message = content;
            logRepository.Create(log);
            logRepository.UnitOfWork.Commit();
        }
        #endregion

        [WebMethod]
        [SoapHeader("header")]
        public UserConstraint[] GetUsersConstraint()
        {
            
            IBasicWasteUnitRepository basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
            List<BasicWasteUnit> list = basicWasteUnitRepository.GetAll().AsQueryable().Where(c=>(c.SimpleCode!="" || c.SimpleCode!=null) && (c.ParentUnitID==null || c.ParentUnitID=="")).ToList();
            List<UserConstraint> userList = new List<UserConstraint>();
            if (list != null && list.Count > 0)
            {
                UpcAuthClient.IAuthorization auth = UpcAuthClient.AuthorizationFactory.Create();
                string[] arrRole = { "RWIS_RFID_DISPITE_INPUT", "RWIS_RFID_NUCLEAR_INPUT"};
                string strUserConstraint = string.Empty;
                foreach (var item in list)
                {
                    foreach (var roleCode in arrRole)
                    {
                          string[] arr=auth.GetUsersInRole(roleCode, item.SimpleCode);
                          if (arr != null && arr.Length > 0)
                          {
                              foreach (var user in arr)
                              {
                                  if (strUserConstraint.Contains(item.SimpleCode + "," + user))
                                  {
                                      continue;
                                  }
                                  else
                                  {
                                      strUserConstraint = strUserConstraint + item.SimpleCode + "," + user + ",";
                                  }
                                  UserConstraint userConstraint = new UserConstraint();
                                  userConstraint.Constraint = item.SimpleCode;
                                  userConstraint.UserCode = user;
                                  userList.Add(userConstraint);
                              }
                          }
                    }
                }
            }
            UserConstraint[] arrUser = userList.ToArray<UserConstraint>();
            return arrUser;
        }

        /// <summary>
        /// 根据
        /// </summary>
        /// <param name="projectCode"></param>
        /// <param name="userCode"></param>
        /// <returns></returns>
        [WebMethod]
        [SoapHeader("header")]
        public Resource[] GetResource(string userCode, string projectCode)
        {
            List<Resource> menuModules = new List<Resource>();
            UpcAuthClient.IAuthorization auth = UpcAuthClient.AuthorizationFactory.Create();
            UpcAuthClient.Resource[] accessMenuResources = auth.GetUserAccessMenuResources(userCode.ToUpper(), projectCode.ToUpper());
            foreach (var menuRes in accessMenuResources)
            {
                menuModules.AddRange(BuidMenu(menuRes));
            }
            List<string> menuList = GetMenuList();
            var list = (from i in menuModules
                        join m in menuList
                        on i.ResourceCode equals m
                        select i).ToList<Resource>();
            Resource[] arrResource = list.ToArray<Resource>();
            return arrResource;
        }

        private List<string> GetMenuList()
        {
            List<string> menuList = new List<string>();

            //材料管理
            menuList.Add("MaterialManage");     //材料管理
            menuList.Add("Material_Input");     //材料入库
            menuList.Add("Material_Transfer");  //材料转运
            menuList.Add("Material_Drain");     //材料消耗

            //源项跟踪单
            menuList.Add("WasteTracking");             //废物跟踪单    
            menuList.Add("Nuclear_Track_Element");     //废滤芯列表
            menuList.Add("Nuclear_Track_Deposit");     //淤积物列表
            menuList.Add("Nuclear_Track_Solvent");     //废油和溶剂
            menuList.Add("Nuclear_Track_Filter");      //通风过滤器列表
            menuList.Add("Nuclear_Track_TechB");       //技术废物1
            menuList.Add("Nuclear_Track_TechS");       //技术废物2
            menuList.Add("Nuclear_Track_Sundry");      //杂项

            //废物处理
            menuList.Add("Waste_Manage");            //废物处理
            menuList.Add("Waste_Treatment");         //废物处理
            menuList.Add("Bucket_Check");            //桶检查
            menuList.Add("Cement_Solidify");           //水泥固化
            menuList.Add("Bucket_Solution_Detail");    //浓缩液装桶固化
            menuList.Add("Bucket_Resin_Detail");       //废树脂装桶固化
            menuList.Add("Bucket_R_Solidify_Detail");  //废树脂固化
            menuList.Add("Bucket_S_Solidify_Detail");  //浓缩液固化
            menuList.Add("Fix_Ation");                 //固定
            menuList.Add("Bucket_Cover");              //超压
            menuList.Add("Cover_Metal");               //400L金属桶超压
            menuList.Add("Bucket_CoverM");             //封盖
            menuList.Add("Cover_Mix");                 //湿混料制备及封盖 
            menuList.Add("QT_Transfer");               //封盖后贮存
            menuList.Add("Other_Technology");           //其他工艺
            menuList.Add("Index_H_Dispose");          //高整体容器处理  

            //转运
            menuList.Add("TemporaryStorage");       //暂存管理
            menuList.Add("Transport");              //转运
            menuList.Add("Factory_Transfer");       //厂房间废物桶转运 
            menuList.Add("Package_Record");         //厂房废物货包记录  
            menuList.Add("Record_In");              //入库记录
            menuList.Add("Record_Out");             //出库记录

            //废物处置
            menuList.Add("Dispite_Waste_Manage"); //处置场废物管理
            menuList.Add("WasteDisposal");        //废物处置
            menuList.Add("Nuclear_Rub_Reception"); //废物接收 
            return menuList;
        }
        /// <summary>
        /// 构建菜单
        /// </summary>
        /// <param name="menuResource"></param>
        /// <returns></returns>
        private List<Resource> BuidMenu(UpcAuthClient.Resource menuResource)
        {
            List<Resource> menuModules = new List<Resource>();
            menuModules.Add(menuResource);
            if (menuResource.HasChildren)
            {
                foreach (UpcAuthClient.Resource child in menuResource.Children)
                {
                    menuModules.AddRange(BuidMenu(child));
                }
            }
            return menuModules;
        }

        #region 调用材料信息

        /// <summary>
        /// 调用材料信息
        /// </summary>
        /// <param name="stationCode">电站ID</param>
        /// <param name="outErrorMessage">返回错误信息</param>
        /// <returns></returns>
        [WebMethod]
        [SoapHeader("header")]
        public MaterialType[] GetMaterialTypeList(string stationCode,out string outErrorMessage)
        {
            MaterialType[] arr = null;
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法GetMaterialTypeList()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用材料信息", outErrorMessage);
                return null;
            }
            try
            {
                IMaterialTypeRepository materialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
                var list = materialTypeRepository.GetAll().AsQueryable().Where(c => c.Status=="2" && c.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim()).ToList();
                if (list.Count > 0)
                {
                    arr = new MaterialType[list.Count];
                    for (int i = 0; i < list.Count; i++)
                    {
                        arr[i] = list[i];
                    }
                }
                return arr;
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法GetMaterialTypeList()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用材料信息", outErrorMessage);
                return null;
            }
        }

        #endregion 调用材料信息

        #region 调用电站信息
        [WebMethod]
        [SoapHeader("header")]
        public BasicWasteUnit[] GetBasicWasteUnitList(out string outErrorMessage)
        {
            BasicWasteUnit[] arr=null;
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法GetBasicWasteUnitList()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用电站信息", outErrorMessage);
                return null;
            }

            try
            {
                IBasicWasteUnitRepository basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
                List<BasicWasteUnit> list = basicWasteUnitRepository.GetAll().AsQueryable().ToList();
                if (list.Count > 0)
                {
                    arr = new BasicWasteUnit[list.Count];
                    for (int i = 0; i < list.Count; i++)
                    {
                        arr[i] = list[i];
                    }
                }
                else {
                    arr = new BasicWasteUnit[0];
                }
              
                return arr;
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法GetBasicWasteUnitList()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用电站信息", outErrorMessage);
                return null;
            }
        }

        #endregion 调用电站信息

        #region 调用常量信息
        [WebMethod]
        [SoapHeader("header")]
        public ConstObject[] GetBasicObjectList(out string outErrorMessage)
        {
            ConstObject[] arr = null;
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法GetBasicObjectList()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用常量信息", outErrorMessage);
                return null;
            }

            try
            {
                IBasicObjectRepository basicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
                List<BasicObject> list = basicObjectRepository.GetAll().AsQueryable().ToList();
                if (list.Count > 0)
                {
                    arr = new ConstObject[list.Count];
                    for (int i = 0; i < list.Count; i++)
                    {
                        ConstObject constObject = new ConstObject();
                        constObject.Uuid = list[i].Uuid;
                        constObject.Type = list[i].Type;
                        constObject.Code = list[i].Code;
                        constObject.Name = list[i].Name;
                        constObject.ParentUuid = list[i].ParentUuid;
                        constObject.Status = list[i].Status;
                        constObject.SortNumber = list[i].SortNumber;
                        constObject.Remark = list[i].Remark;
                        constObject.CreateUserId = list[i].CreateUserId;
                        constObject.CreateUserName = list[i].CreateUserName;
                        constObject.CreateTime = list[i].CreateTime;
                        constObject.IsmultiStation = list[i].IsmultiStation;
                        constObject.StationCode = list[i].StationCode;
                        arr[i] = constObject;
                    }
                }
                return arr;
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法GetBasicObjectList()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用常量信息", outErrorMessage);
                return null;
            }
        }
        #endregion 调用常量信息

        #region 调用桶信息
        [WebMethod]
        [SoapHeader("header")]
        public NuclearBucket[] GetBucketList(out string outErrorMessage)
        {
            NuclearBucket[] arr = null;
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法GetBucketList()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用桶信息", outErrorMessage);
                return null;
            }

            try
            {
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                List<NuclearBucket> list = nuclearBucketRepository.GetAll().AsQueryable().Where(c => (c.IsCompress==null || c.IsCompress != "1") && (c.IsOutSend == null || c.IsOutSend != "1") && c.BucketStatus.ToUpper().Trim() != "UNPREPARE").ToList();
                if (list.Count > 0)
                {
                    arr = new NuclearBucket[list.Count];
                    for (int i = 0; i < list.Count; i++)
                    {
                        arr[i] = list[i];
                    }
                }
                else
                {
                    arr = new NuclearBucket[0];
                }
                return arr;
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法GetBucketList()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用桶信息", outErrorMessage);
                return null;
            }
        }

        #endregion 调用桶信息

        #region 调用废物货包信息
        [WebMethod]
        [SoapHeader("header")]
        public NuclearWastePackage[] GetWastePackageList(out string outErrorMessage)
        {
            NuclearWastePackage[] arr = null;
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法GetWastePackageList()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用废物货包信息", outErrorMessage);
                return null;
            }

            try
            {
                INuclearWastePackageRepository nuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
                List<NuclearWastePackage> list = nuclearWastePackageRepository.GetAll().AsQueryable().Where(c => c.Status.ToUpper().Trim() == "APPLIED").ToList();
                if (list.Count > 0)
                {
                    arr = new NuclearWastePackage[list.Count];
                    for (int i = 0; i < list.Count; i++)
                    {
                        arr[i] = list[i];
                    }
                }
                else
                {
                    arr = new NuclearWastePackage[0];
                }
                return arr;
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法GetWastePackageList()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用废物货包信息", outErrorMessage);
                return null;
            }
        }

        #endregion 调用废物货包信息

        #region 调用设备维护信息
        [WebMethod]
        [SoapHeader("header")]
        public EquipInfo[] GetEquipManageList(out string outErrorMessage, string projectCode)
        {
            EquipInfo[] arr = null;
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法GetEquipManageList()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用设备维护信息", outErrorMessage);
                return null;
            }

            try
            {
                IEquipInfoRepository _EquipInfoRepository = ServiceLocator.Current.GetInstance<IEquipInfoRepository>();
                //获取数据
                List<EquipInfo> list = _EquipInfoRepository.GetAll().Where(d => d.Stationcode.ToUpper() == projectCode.ToUpper() && d.Status=="2").ToList();
                if (list.Count > 0)
                {
                    arr = new EquipInfo[list.Count];
                    for (int i = 0; i < list.Count; i++)
                    {
                        arr[i] = list[i];
                    }
                }
                return arr;
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法GetEquipManageList()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用设备维护信息", outErrorMessage);
                return null;
            }
        }

        #endregion 

        #region 插入材料入库信息
        /// <summary>
        /// 插入入库信息
        /// </summary>
        /// <param name="item">入库信息</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertMaterialInput(MaterialInput item, NuclearBucket[] nuclearBucket, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertMaterialInput()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入入库信息", outErrorMessage);
            }
            try
            {
                INuclearBucketChangeRepository nuclearBucketChangeRepository = ServiceLocator.Current.GetInstance<INuclearBucketChangeRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                IMaterialInputRepository materialInputRepository = ServiceLocator.Current.GetInstance<IMaterialInputRepository>();
                IMaterialTypeRepository materialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
                IBasicObjectRepository basicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
                if (nuclearBucket != null)
                {
                    foreach (var itemBucket in nuclearBucket)
                    {
                        IQueryable<NuclearBucket> data = nuclearBucketRepository.GetAll().AsQueryable().Where(s => s.BucketCode == itemBucket.BucketCode).Where(d => d.Stationcode == stationCode);
                        if (data.Count() > 0)
                        {
                            outErrorMessage += "<br>" + "您填的桶号:" + itemBucket.BucketCode + "已存在！";
                        }
                    }
                }
               
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    
                    IQueryable<MaterialType> materialType = materialTypeRepository.GetAll().Where(d => d.MaterialId == item.MaterialId).AsQueryable();
                    if (materialType.Count() > 0)
                    {
                        item.UnitId = materialType.ToList()[0].UnitId;
                        BasicObject basicObject = basicObjectRepository.GetAll().Where(d => d.Uuid == materialType.ToList()[0].SpecId).FirstOrDefault();
                        if (basicObject!=null)
                        {
                            item.MaterialSpec = basicObject.Name;
                        }
                       
                    }
                 
                    item.InputId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    materialInputRepository.Create(item);
                    if (nuclearBucket != null)
                    {
                        foreach (var itemNuclearBucket in nuclearBucket)
                        {

                            itemNuclearBucket.BucketId = Guid.NewGuid().ToString();
                            itemNuclearBucket.MaterialId = item.MaterialId;
                            itemNuclearBucket.LocationId = item.StorageLocationId;
                            itemNuclearBucket.Status = "1";
                            itemNuclearBucket.IsDrain = "0";
                            itemNuclearBucket.Stationcode = stationCode;
                            nuclearBucketRepository.Create(itemNuclearBucket);

                            NuclearBucketChange nuclearBucketChange = new NuclearBucketChange();
                            nuclearBucketChange.Detailid = Guid.NewGuid().ToString();
                            nuclearBucketChange.ChangeType = "INPUT";
                            nuclearBucketChange.BusinessId = item.InputId;
                            nuclearBucketChange.BucketId = itemNuclearBucket.BucketId;
                            nuclearBucketChangeRepository.Create(nuclearBucketChange);

                        }
                    }
                   

                    materialInputRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入入库信息", "调用方法InsertMaterialInput()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertMaterialInput()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入入库信息", outErrorMessage);
            }
        }
        #endregion

        #region 插入材料转运信息
        /// <summary>
        /// 插入材料转运
        /// </summary>
        /// <param name="item">材料转运信息</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertMaterialTransfer(MaterialTransfer item, NuclearBucket[] nuclearBucket, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertMaterialTransfer()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入材料转运", outErrorMessage);
            }
            try
            {
                INuclearBucketChangeRepository nuclearBucketChangeRepository = ServiceLocator.Current.GetInstance<INuclearBucketChangeRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                IMaterialTransferRepository materialTransferRepository = ServiceLocator.Current.GetInstance<IMaterialTransferRepository>();
                if (nuclearBucket != null)
                {
                    foreach (var itemBucket in nuclearBucket)
                    {
                        IQueryable<NuclearBucket> data = nuclearBucketRepository.GetAll().AsQueryable().Where(s => s.BucketCode == itemBucket.BucketCode).Where(d => d.LocationId == item.OutputLoctionId && d.MaterialId == item.MaterialId).Where(d => d.Stationcode == stationCode);
                        if (data.Count() > 0)
                        {
                            List<NuclearBucket> dataList = data.ToList();
                            if (dataList[0].IsDrain == "1")
                            {
                                outErrorMessage += "<br>" + "您填的桶号:" + itemBucket.BucketCode + "已消耗,不能被转运！";
                            }
                            if (dataList[0].Status != "2")
                            {
                                outErrorMessage += "<br>" + "您填的桶号:" + itemBucket.BucketCode + "未被确认！";
                            }

                        }
                        else
                        {
                            outErrorMessage += "<br>" + "该仓库不存在该桶号！";

                        }
                    }
                }
               
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.TransferId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    materialTransferRepository.Create(item);
                    if (nuclearBucket != null)
                    {
                        foreach (var itemNuclearBucket in nuclearBucket)
                        {
                            NuclearBucket nuclearBucketBucket = nuclearBucketRepository.GetAll().Where(d => d.BucketCode == itemNuclearBucket.BucketCode && d.Stationcode == stationCode).FirstOrDefault();
                            //在桶位置编号表明细存入数据
                            NuclearBucketChange nuclearBucketChange = new NuclearBucketChange();
                            nuclearBucketChange.Detailid = Guid.NewGuid().ToString();
                            nuclearBucketChange.ChangeType = "TRANSFER";
                            nuclearBucketChange.BusinessId = item.TransferId;
                            nuclearBucketChange.BucketId = nuclearBucketBucket.BucketId;
                            nuclearBucketChangeRepository.Create(nuclearBucketChange);

                        }
                    }
                   
                    materialTransferRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("插入材料转运", "调用方法InsertMaterialTransfer()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertMaterialTransfer()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("插入材料转运", outErrorMessage);
            }
        }
        #endregion

        #region 插入材料消耗信息
        /// <summary>
        /// 插入材料消耗
        /// </summary>
        /// <param name="item">材料消耗信息</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertMaterialDrain(MaterialDrain item, NuclearBucket[] nuclearBucket, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertMaterialDrain()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入材料消耗", outErrorMessage);
            }
            try
            {
                INuclearBucketChangeRepository nuclearBucketChangeRepository = ServiceLocator.Current.GetInstance<INuclearBucketChangeRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                IMaterialDrainRepository materialTransferRepository = ServiceLocator.Current.GetInstance<IMaterialDrainRepository>();
                if (nuclearBucket != null)
                {
                    foreach (var itemBucket in nuclearBucket)
                    {
                        IQueryable<NuclearBucket> data = nuclearBucketRepository.GetAll().AsQueryable().Where(s => s.BucketCode == itemBucket.BucketCode).Where(s => s.LocationId == item.OutputLocationId && s.MaterialId == item.MaterialId).Where(d => d.Stationcode == stationCode);
                        if (data.Count() > 0)
                        {
                            List<NuclearBucket> dataList = data.ToList();
                            if (dataList[0].IsDrain == "1")
                            {
                                outErrorMessage += "<br>" + "您填的桶号:" + itemBucket.BucketCode + "已消耗,不能被转运！";
                            }
                            if (dataList[0].Status != "2")
                            {
                                outErrorMessage += "<br>" + "您填的桶号:" + itemBucket.BucketCode + "未被确认！";
                            }
                        }
                        else
                        {
                            outErrorMessage += "<br>" + "该仓库不存在该桶号！";

                        }
                    }
                }
               
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.DrainId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    materialTransferRepository.Create(item);
                    if (nuclearBucket != null)
                    {
                        foreach (var itemNuclearBucket in nuclearBucket)
                        {
                            NuclearBucket nuclearBucketBucket = nuclearBucketRepository.GetAll().Where(d => d.BucketCode == itemNuclearBucket.BucketCode && d.Stationcode == stationCode).FirstOrDefault();
                            //在桶位置编号表明细存入数据
                            NuclearBucketChange nuclearBucketChange = new NuclearBucketChange();
                            nuclearBucketChange.Detailid = Guid.NewGuid().ToString();
                            nuclearBucketChange.ChangeType = "DRAIN";
                            nuclearBucketChange.BusinessId = item.DrainId;
                            nuclearBucketChange.BucketId = nuclearBucketBucket.BucketId;
                            nuclearBucketChangeRepository.Create(nuclearBucketChange);

                        }
                    }
                    materialTransferRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("插入材料消耗", "调用方法InsertMaterialDrain()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertMaterialDrain()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("插入材料消耗", outErrorMessage);
            }
        }
        #endregion

        #region 插入条形码的中间表信息
        /// <summary>
        /// 插入条形码的中间表信息
        /// </summary>
        /// <param name="containerId">容器ID</param>
        /// <param name="type">类型</param>
        /// <param name="barCode">条形码</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">错误信息</param>
        /// <returns></returns>
        [WebMethod]
        [SoapHeader("header")]
        public bool InsertContainerBarCode(string containerId, string type, string barCode, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertContainerBarCode()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用插入标签条形码的中间表", outErrorMessage);
                return false;
            }
            try
            {
              
                IContainerBarRepository containerBarRepository = ServiceLocator.Current.GetInstance<IContainerBarRepository>();
                containerBarRepository.Insert(containerId, type, barCode, stationCode);

            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertContainerBarCode()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入标签条形码的中间表", outErrorMessage);
                return false;
            }
            return true;
        }
        #endregion

        #region 修改条形码的中间表信息
        /// <summary>
        /// 修改条形码的中间表信息
        /// </summary>
        /// <param name="containerId">容器ID</param>
        /// <param name="type">类型</param>
        /// <param name="barCode">条形码</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">错误信息</param>
        /// <returns></returns>
        [WebMethod]
        [SoapHeader("header")]
        public bool UpdateContainerBarCode(string containerId, string type, string barCode, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法UpdateContainerBarCode()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用修改标签条形码的中间表", outErrorMessage);
                return false;
            }
            try
            {

                IContainerBarRepository containerBarRepository = ServiceLocator.Current.GetInstance<IContainerBarRepository>();
                containerBarRepository.Update(containerId, type, barCode, stationCode);

            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法UpdateContainerBarCode()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用修改标签条形码的中间表", outErrorMessage);
                return false;
            }
            return true;
        }
        #endregion

        #region 删除条形码的中间表信息
        /// <summary>
        /// 删除条形码的中间表信息
        /// </summary>
        /// <param name="containerId">容器ID</param>
        /// <param name="type">类型</param>
        /// <param name="barCode">条形码</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">错误信息</param>
        /// <returns></returns>
        [WebMethod]
        [SoapHeader("header")]
        public bool DeleteContainerBarCode(string containerId, string type, string barCode, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法DeleteContainerBarCode()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用删除标签条形码的中间表", outErrorMessage);
                return false;
            }
            try
            {

                IContainerBarRepository containerBarRepository = ServiceLocator.Current.GetInstance<IContainerBarRepository>();
                containerBarRepository.Delete(containerId, type, barCode);

            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法DeleteContainerBarCode()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用删除标签条形码的中间表", outErrorMessage);
                return false;
            }
            return true;
        }
        #endregion

        #region 插入废滤芯源项信息
        /// <summary>
        /// 插入废滤芯源项信息
        /// </summary>
        /// <param name="item">废滤芯</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertWasteCore(NuclearTrackElement item, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertWasteCore()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用插入废滤芯源项信息", outErrorMessage);
            }
            try
            {
                INuclearTrackElementRepository nuclearTrackElementRepository = ServiceLocator.Current.GetInstance<INuclearTrackElementRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                INuclearTrackTechSRepository nuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
                IBasicWasteUnitRepository basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
                INuclearTrackTechBRepository nuclearTrackTechBRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechBRepository>();
                if (string.IsNullOrEmpty(item.ElementCode))
                {
                    string simpleCode = basicWasteUnitRepository.GetSimpleCodeById(item.StationId);
                    string demo = simpleCode + "FI" + DateTime.Now.ToString("yyyy");
                    int num = 0;
                    var query = nuclearTrackElementRepository.GetAll().Where(d => d.ElementCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
                    if (query.Count() > 0)
                    {
                        string maxCode = query.OrderByDescending(d => d.ElementCode).First().ElementCode;
                        num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                        demo += num.ToString("0000");
                    }
                    else
                    {
                        demo += (num + 1).ToString("0000");
                    }
                    item.ElementCode = demo;
                }


                bool bucketCode = false;
                if (item.ContainerId != null && item.ContainerId != "")
                {
                    //判断桶号是否存在 
                    string bucketId = nuclearBucketRepository.IsExistWasteBucket(item.ContainerId, stationCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        outErrorMessage += "<br>" + "您填写的包装容器号" + item.ContainerId + "不正确!";
                       
                    }
                    if (nuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, stationCode))
                    {
                        outErrorMessage += "<br>" + "您填写的包装容器号" + item.ContainerId + "已被技术废物2中208L金属桶使用!";
                    }
                    if (nuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, stationCode))
                    {
                        outErrorMessage += "<br>" + "您填写的包装容器号" + item.ContainerId + "已被技术废物1中暂存包装容器使用!";
                    }
                    int num = nuclearTrackElementRepository.IsRepeatBucketCode(bucketId, stationCode);
                    if (num > 0)
                    {
                        bucketCode = true;
                    };
                    item.ContainerId = bucketId;
                }
                bool bucketCodes = false;
                if (item.InputContainerId != null && item.InputContainerId != "")
                {
                    //判断桶号是否存在 
                    string bucketId = nuclearBucketRepository.IsExistWasteBucket(item.InputContainerId, stationCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        outErrorMessage += "<br>" + "您填写的包装容器号" + item.InputContainerId + "不正确!";

                    }
                    if (nuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, stationCode))
                    {
                        outErrorMessage += "<br>" + "您填写的包装容器号" + item.InputContainerId + "已被技术废物2中208L金属桶使用!";
                    }
                    if (nuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, stationCode))
                    {
                        outErrorMessage += "<br>" + "您填写的包装容器号" + item.InputContainerId + "已被技术废物1中暂存包装容器使用!";
                    }
                    int num = nuclearTrackElementRepository.IsRepeatBucketCode(bucketId, stationCode);
                    if (num > 0)
                    {
                        bucketCodes = true;
                    }
                    item.InputContainerId = bucketId;

                }





                //if (nuclearTrackElementRepository.IsRepeat(item.ElementCode, stationCode))
                //{
                //    outErrorMessage += "<br>" + "您填写的编号重复，请获取最新编号!";
                //}
                //string bucketId = nuclearBucketRepository.IsExistWasteBucket(item.ContainerId, stationCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    outErrorMessage += "<br>" + "您填写的包装容器号" + item.ContainerId + "不正确!";

                //}
                //if (nuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, stationCode))
                //{
                //    outErrorMessage += "<br>" + "您填写的包装容器号" + item.ContainerId + "已被使用。";
                //}
               
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.ElementId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.DealStatus = "0";
                    nuclearTrackElementRepository.Create(item);
                    nuclearTrackElementRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入废滤芯源项信息", "调用方法InsertWasteCore()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertWasteCore()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入废滤芯源项信息", outErrorMessage);
            }
        }
        #endregion 插入废滤芯源项信息

        #region 插入淤积物源项信息
        /// <summary>
        /// 插入淤积物源项信息
        /// </summary>
        /// <param name="item">淤积物</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertWasteDeposit(NuclearTrackDeposit item, string bucketCode,string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertWasteDeposit()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用插入淤积物源项信息", outErrorMessage);
            }
            try
            {
                INuclearTrackDepositRepository nuclearTrackDepositRepository = ServiceLocator.Current.GetInstance<INuclearTrackDepositRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                INuclearTrackTechSRepository nuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
                IBasicWasteUnitRepository basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
                NuclearBucket nuclearBucket = nuclearBucketRepository.GetAll().Where(d => d.BucketCode.Trim() == bucketCode.Trim() && d.Stationcode == stationCode).FirstOrDefault();
                if (nuclearBucket != null)
                {
                    item.StorageContainerId = nuclearBucket.BucketId;
                }
                if (string.IsNullOrEmpty(item.DepositCode))
                {
                    string simpleCode = basicWasteUnitRepository.GetSimpleCodeById(item.StationId);
                    string demo = simpleCode + "SI" + DateTime.Now.ToString("yyyy");
                    int num = 0;
                    var query = nuclearTrackDepositRepository.GetAll().Where(d => d.DepositCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
                    if (query.Count() > 0)
                    {
                        string maxCode = query.OrderByDescending(d => d.DepositCode).First().DepositCode;
                        num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                        demo += num.ToString("0000");
                    }
                    else
                    {
                        demo += (num + 1).ToString("0000");
                    }
                    item.DepositCode = demo;
                }
                if (nuclearTrackDepositRepository.IsRepeat(item.DepositCode, stationCode))
                {
                    outErrorMessage += "您填写的编号重复，请获取最新编号!";
                }
                if (item.StorageContainerId != null)
                {
                    string bucketId = nuclearBucketRepository.IsExistWasteBucket(bucketCode, stationCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        outErrorMessage += "您填写的包装容器号" + bucketCode + "不正确!";

                    }
                    if (nuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, stationCode))
                    {
                        outErrorMessage += "<br>" + "您填写的包装容器号" + bucketCode + "已被使用!";
                    }
                    string existFactory = nuclearBucketRepository.IsExistByFactory(bucketCode, stationCode, item.StoragePositionId);
                    if (string.IsNullOrEmpty(existFactory))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器编号不在所选厂房中";
                    }
                    item.BucketId = bucketId;
                    item.StorageContainerId = bucketId;
                }
              
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.DepositId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.DealStatus = "0";
                    nuclearTrackDepositRepository.Create(item);
                    nuclearTrackDepositRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入淤积物源项信息", "调用方法InsertWasteDeposit()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertWasteDeposit()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入淤积物源项信息", outErrorMessage);
            }
        }
        #endregion 插入淤积物源项信息

        #region 插入废油和溶剂源项信息
        /// <summary>
        /// 插入废油和溶剂源项信息
        /// </summary>
        /// <param name="item">废油和溶剂</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertWasteSolvent(NuclearTrackSolvent item, string bucketCode,string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertWasteSolvent()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用插入废油和溶剂物源项信息", outErrorMessage);
            }
            try
            {
                INuclearTempstockRepository nuclearTempstockRepository = ServiceLocator.Current.GetInstance<INuclearTempstockRepository>();
                INuclearTrackSolventRepository nuclearTrackSolventRepository = ServiceLocator.Current.GetInstance<INuclearTrackSolventRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                INuclearTrackTechSRepository nuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
                IBasicWasteUnitRepository basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
                NuclearBucket nuclearBucket = nuclearBucketRepository.GetAll().Where(d => d.BucketCode.Trim() == bucketCode.Trim() && d.Stationcode == stationCode).FirstOrDefault();
                if (nuclearBucket != null)
                {
                    item.StorageContainerId = nuclearBucket.BucketId;
                }
                if (string.IsNullOrEmpty(item.SolventCode))
                {
                    string simpleCode = basicWasteUnitRepository.GetSimpleCodeById(item.StationId);
                    string demo = simpleCode + "OI" + DateTime.Now.ToString("yyyy");
                    int num = 0;
                    var query = nuclearTrackSolventRepository.GetAll().Where(d => d.SolventCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
                    if (query.Count() > 0)
                    {
                        string maxCode = query.OrderByDescending(d => d.SolventCode).First().SolventCode;
                        num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                        demo += num.ToString("0000");
                    }
                    else
                    {
                        demo += (num + 1).ToString("0000");
                    }
                    item.SolventCode = demo;
                }
                if (nuclearTrackSolventRepository.IsRepeat(item.SolventCode, stationCode))
                {
                    outErrorMessage += "您填写的编号重复，请获取最新编号!";
                }
                if (item.StorageContainerId != null)
                {
                    //判断桶号是否存在 
                    string bucketId = nuclearBucketRepository.IsExistWasteBucket(bucketCode, stationCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器编号" + bucketCode + "不正确!";
                    }
                    string existFactory = nuclearBucketRepository.IsExistByFactory(bucketCode, stationCode, item.StoragePositionId);
                    if (string.IsNullOrEmpty(existFactory))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器编号" + bucketCode + "不在所选厂房中!";
                    }
                    if (nuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, stationCode))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器编号" + bucketCode + "已被使用!";

                    }
                    item.BucketId = bucketId;
                    item.StorageContainerId = bucketId;
                }
               
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.SolventId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.DealStatus = "0";
                    nuclearTrackSolventRepository.Create(item);
                    nuclearTrackSolventRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入废油和溶剂物源项信息", "调用方法InsertWasteSolvent()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertWasteSolvent()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入废油和溶剂物源项信息", outErrorMessage);
            }
        }
        #endregion 插入废油和溶剂源项信息

        #region 插入通风过滤器源项信息
        /// <summary>
        /// 插入通风过滤器源项信息
        /// </summary>
        /// <param name="item">通风过滤器</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertWasteFilter(NuclearTrackFilter item, string bucketCode,string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertWasteFilter()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用插入通风过滤器源项信息", outErrorMessage);
            }
            try
            {
                INuclearTrackFilterRepository nuclearTrackFilterRepository = ServiceLocator.Current.GetInstance<INuclearTrackFilterRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                INuclearTrackTechSRepository nuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
                IBasicWasteUnitRepository basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();

                if (string.IsNullOrEmpty(item.FilterCode))
                {
                    string simpleCode = basicWasteUnitRepository.GetSimpleCodeById(item.StationId);
                    string demo = simpleCode + "AF" + DateTime.Now.ToString("yyyy");
                    int num = 0;
                    var query = nuclearTrackFilterRepository.GetAll().Where(d => d.FilterCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
                    if (query.Count() > 0)
                    {
                        string maxCode = query.OrderByDescending(d => d.FilterCode).First().FilterCode;
                        num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                        demo += num.ToString("0000");
                    }
                    else
                    {
                        demo += (num + 1).ToString("0000");
                    }
                    item.FilterCode = demo;
                }
                if (nuclearTrackFilterRepository.IsRepeat(item.FilterCode, stationCode))
                {
                    outErrorMessage += "您填写的编号重复，请获取最新编号!";
                }
                if (item.StorageContainerId != null)
                {
                    //判断桶号是否存在 
                    string bucketId = nuclearBucketRepository.IsExistWasteBucket(bucketCode, stationCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器编号" + bucketCode + "不正确!";
                    }
                    string existFactory = nuclearBucketRepository.IsExistByFactory(bucketCode, stationCode, item.StoragePositionId);
                    if (string.IsNullOrEmpty(existFactory))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器编号" + bucketCode + "不在所选厂房中!";
                    }
                    if (nuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, stationCode))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器编号" + bucketCode + "已被使用!";

                    }
                    item.BucketId = bucketId;
                    item.StorageContainerId = bucketId;
                }
             
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.FilterId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.DealStatus = "0";
                    nuclearTrackFilterRepository.Create(item);
                    nuclearTrackFilterRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入通风过滤器源项信息", "调用方法InsertWasteFilter()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertWasteFilter()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入通风过滤器源项信息", outErrorMessage);
            }
        }
        #endregion 插入通风过滤器源项信息

        #region 插入技术废物1源项信息
        /// <summary>
        /// 插入技术废物1源项信息
        /// </summary>
        /// <param name="item">技术废物1</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertWasteTech1(NuclearTrackTechB item, string bucketCode,string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertWasteTech1()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用插入技术废物1源项信息", outErrorMessage);
            }
            try
            {
                INuclearTrackTechBRepository nuclearTrackTechBRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechBRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                INuclearTrackTechSRepository nuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
                IBasicWasteUnitRepository basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();

                if (string.IsNullOrEmpty(item.TechBCode))
                {
                    string simpleCode = basicWasteUnitRepository.GetSimpleCodeById(item.StationId);
                    string demo = simpleCode + "TH" + DateTime.Now.ToString("yyyy");
                    int num = 0;
                    var query = nuclearTrackTechBRepository.GetAll().Where(d => d.TechBCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
                    if (query.Count() > 0)
                    {
                        string maxCode = query.OrderByDescending(d => d.TechBCode).First().TechBCode;
                        num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                        demo += num.ToString("0000");
                    }
                    else
                    {
                        demo += (num + 1).ToString("0000");
                    }
                    item.TechBCode = demo;
                }
                if (nuclearTrackTechBRepository.IsRepeat(item.TechBCode, stationCode))
                {
                    outErrorMessage += "您填写的编号重复，请获取最新编号!";
                }
                if (item.StorageContainerId != null)
                {
                    //判断桶号是否存在 
                    string bucketId = nuclearBucketRepository.IsExistWasteBucket(bucketCode, stationCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器编号" + bucketCode + "不正确!";
                    }
                    string existFactory = nuclearBucketRepository.IsExistByFactory(bucketCode, stationCode, item.StoragePositionId);
                    if (string.IsNullOrEmpty(existFactory))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器编号" + bucketCode + "不在所选厂房中!";
                    }
                    if (nuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, stationCode))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器编号" + bucketCode + "已被使用!";

                    }
                    item.BucketId = bucketId;
                    item.StorageContainerId = bucketId;
                }
               
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.TechBId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.DealStatus = "0";
                    nuclearTrackTechBRepository.Create(item);
                    nuclearTrackTechBRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入技术废物1源项信息", "调用方法InsertWasteTech1()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertWasteTech1()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入技术废物1源项信息", outErrorMessage);
            }
        }
        #endregion  插入技术废物1源项信息

        #region 插入技术废物2源项信息
        /// <summary>
        /// 插入技术废物2源项信息
        /// </summary>
        /// <param name="item">技术废物2</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertWasteTech2(NuclearTrackTechS item, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertWasteTech2()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用插入技术废物2源项信息", outErrorMessage);
            }
            try
            {
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                INuclearTrackTechSRepository nuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
                IBasicWasteUnitRepository basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();

                if (string.IsNullOrEmpty(item.TechSCode))
                {
                    string simpleCode = basicWasteUnitRepository.GetSimpleCodeById(item.StationId);
                    string demo = simpleCode + "TH" + DateTime.Now.ToString("yyyy");
                    int num = 0;
                    var query = nuclearTrackTechSRepository.GetAll().Where(d => d.TechSCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
                    if (query.Count() > 0)
                    {
                        string maxCode = query.OrderByDescending(d => d.TechSCode).First().TechSCode;
                        num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                        demo += num.ToString("0000");
                    }
                    else
                    {
                        demo += (num + 1).ToString("0000");
                    }
                    item.TechSCode = demo;
                }
                if (nuclearTrackTechSRepository.IsRepeat(item.TechSCode, stationCode))
                {
                    outErrorMessage += "您填写的编号重复，请获取最新编号!";
                }
                if (item.BucketId != null)
                {
                    //判断桶号是否存在 
                    string bucketId = nuclearBucketRepository.IsExistWasteBucket(item.BucketId, stationCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        outErrorMessage += "<br>" + "您填写208L金属桶编号:" + bucketId + "不存在!";
                    }
                    if (nuclearTrackTechSRepository.IsRepeatBucketCode(bucketId,stationCode))
                    {
                        outErrorMessage += "<br>" + "您填写的208L金属桶编号:" + bucketId + "已经被使用!";
                    }
                    item.BucketId = bucketId;
                }
                item.TechSId = Guid.NewGuid().ToString();
                item.Status = "1";
                item.Stationcode = stationCode;
                item.DealStatus = "0";
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    nuclearTrackTechSRepository.Create(item);
                    nuclearTrackTechSRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入技术废物2源项信息", "调用方法InsertWasteTech2()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertWasteTech2()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入技术废物2源项信息", outErrorMessage);
            }
        }
        #endregion  插入技术废物2源项信息

        #region 插入杂项源项信息
        /// <summary>
        /// 插入杂项源项信息
        /// </summary>
        /// <param name="item">技术废物2</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertWasteSundry(NuclearTrackSundry item, string bucketCode,string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertWasteSundry()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用插入杂项源项信息", outErrorMessage);
            }
            try
            {
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                INuclearTrackSundryRepository nuclearTrackSundryRepository = ServiceLocator.Current.GetInstance<INuclearTrackSundryRepository>();
                IBasicWasteUnitRepository basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
                INuclearTrackTechSRepository nuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();

                if (string.IsNullOrEmpty(item.SundryCode))
                {
                    string simpleCode = basicWasteUnitRepository.GetSimpleCodeById(item.StationId);
                    string demo = simpleCode + "MW" + DateTime.Now.ToString("yyyy");
                    int num = 0;
                    var query = nuclearTrackSundryRepository.GetAll().Where(d => d.SundryCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
                    if (query.Count() > 0)
                    {
                        string maxCode = query.OrderByDescending(d => d.SundryCode).First().SundryCode;
                        num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                        demo += num.ToString("0000");
                    }
                    else
                    {
                        demo += (num + 1).ToString("0000");
                    }
                    item.SundryCode = demo;
                }
                if (nuclearTrackSundryRepository.IsRepeat(item.SundryCode, stationCode))
                {
                    outErrorMessage += "您填写的编号重复，请获取最新编号!";
                }
                if (item.StorageMethods == "0")
                {
                    //判断桶号是否存在 
                    string bucketId = nuclearBucketRepository.IsExistWasteBucket(bucketCode, stationCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器号:" + bucketId + "不存在!";
                    }
                    if (nuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, stationCode))
                    {
                        outErrorMessage += "<br>" + "您填写的暂存包装容器号:" + bucketId + "已被使用!";
                    }
                    item.StorageContainerId = bucketId;
                }
               
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.SundryId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.DealStatus = "0";
                    nuclearTrackSundryRepository.Create(item);
                    nuclearTrackSundryRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入杂项源项信息", "调用方法InsertWasteSundry()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertWasteSundry()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入杂项源项信息", outErrorMessage);
            }
        }
        #endregion  插入杂项源项信息

        #region 插入桶检查信息
        /// <summary>
        /// 插入桶检查信息
        /// </summary>
        /// <param name="item">桶检查信息</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertBucketCheck(NuclearBucketCheck item,  string bucketCode, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertBucketCheck()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入桶检查信息", outErrorMessage);
            }
            try
            {
                INuclearBucketCheckRepository nuclearBucketCheckRepository = ServiceLocator.Current.GetInstance<INuclearBucketCheckRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();

                bool bucketCheck = nuclearBucketRepository.IsExistByCodeAndStation(bucketCode, stationCode);
                if (!bucketCheck)
                {
                    outErrorMessage += "<br>" + "您填的桶号:" + bucketCode + "不存在！";
                }
                var listBucket = nuclearBucketRepository.QueryListByCode(bucketCode, stationCode).ToList();
                if (string.IsNullOrEmpty(listBucket[0].BucketStatus))
                {
                    outErrorMessage += "<br>" + "您填的桶号:" + bucketCode + "没有经过空桶准备！";
                }

                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.CheckId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.BucketId = listBucket[0].BucketId;
                    nuclearBucketCheckRepository.Create(item);
                    nuclearBucketCheckRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入桶检查信息", "调用方法InsertBucketCheck()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertBucketCheck()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入桶检查信息", outErrorMessage);
            }
        }
        #endregion

        #region 插入废物货包接收信息
        ///// <summary>
        ///// 插入桶检查信息
        ///// </summary>
        ///// <param name="item">桶检查信息</param>
        ///// <param name="stationCode">电站编号</param>
        ///// <param name="outErrorMessage">返回的错误信息</param>
        //[WebMethod]
        //[SoapHeader("header")]
        //public void InsertNuclearRubReception(NuclearRubReception item, NuclearRubReceptionD[] nuclearRubReceptionD, string stationCode, out string outErrorMessage)
        //{
        //    outErrorMessage = string.Empty;
        //    if (!this.IsValiToken())
        //    {
        //        outErrorMessage = "调用方法InsertNuclearRubReception()失败。错误信息：您没有访问权限！";
        //        WriteErrorLog("插入废物货包接收信息", outErrorMessage);
        //    }
        //    try
        //    {
        //        INuclearRubReceptionRepository _NuclearRubReceptionRepository = ServiceLocator.Current.GetInstance<INuclearRubReceptionRepository>();
        //        INuclearRubReceptionDRepository _NuclearRubReceptionDRepository = ServiceLocator.Current.GetInstance<INuclearRubReceptionDRepository>();
        //        INuclearWastePackageRepository _NuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();


        //        foreach (var itemNuclearRubReceptionD in nuclearRubReceptionD)
        //        {
        //            NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.PackageId == itemNuclearRubReceptionD.PackageId).FirstOrDefault();
        //            if (nuclearWastePackage == null)
        //            {
        //                outErrorMessage += "<br>" + "您填的桶号:" + nuclearWastePackage.PackageCode + "不存在！";
        //            }
        //            if (nuclearWastePackage.Status != "APPLIED")
        //            {
        //                outErrorMessage += "<br>" + "您填的桶号:" + nuclearWastePackage.PackageCode + "没有被接收！";
        //            }


        //        }
        //        if (string.IsNullOrEmpty(outErrorMessage))
        //        {
        //            item.ReceptId = Guid.NewGuid().ToString();
        //            item.Status = "1";
        //            item.Stationcode = stationCode;
        //            _NuclearRubReceptionRepository.Create(item);

        //            foreach (var nRD in nuclearRubReceptionD)
        //            {
        //                nRD.DetailId = Guid.NewGuid().ToString();
        //                nRD.ReceptId = item.ReceptId;
        //                _NuclearRubReceptionDRepository.Create(nRD);
        //            }

        //            _NuclearRubReceptionRepository.UnitOfWork.Commit();
        //        }
        //        else
        //        {

        //            WriteErrorLog("插入废物货包接收信息", "调用方法InsertNuclearRubReception()失败。错误信息：" + outErrorMessage);
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        outErrorMessage = "调用方法InsertNuclearRubReception()失败。错误信息：" + ex.StackTrace;
        //        WriteErrorLog("插入废物货包接收信息", outErrorMessage);
        //    }
        //}
        #endregion  插入废物货包接收信息

        #region 插入固定信息
        /// <summary>
        /// 插入固定信息
        /// </summary>
        /// <param name="item">桶固定信息</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertFixAtion(NuclearFixation item, string bucketCode, string[] arrTrackCode, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            //if (!this.IsValiToken())
            //{
            //    outErrorMessage = "调用方法InsertFixAtion()失败。错误信息：您没有访问权限！";
            //    WriteErrorLog("插入桶固定信息", outErrorMessage);
            //}
            try
            {
                INuclearFixationRepository nuclearFixationRepository = ServiceLocator.Current.GetInstance<INuclearFixationRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                bool bucketCheck = nuclearBucketRepository.IsExistByCodeAndStation(bucketCode,stationCode);
                if (!bucketCheck)
                {
                    outErrorMessage += "<br>" + "您填的桶号不存在！";
                }
                var listBucket = nuclearBucketRepository.QueryListByCode(bucketCode, stationCode).ToList();
                var listBucketCheck = nuclearFixationRepository.GetFixAtionByBucketId(listBucket[0].BucketId).ToList();
                if (listBucketCheck != null && listBucketCheck.Count != 0)
                {
                    outErrorMessage += "<br>" + "您填的桶号已经经过固定环节！";
                }
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    outErrorMessage += "<br>" + "您填的桶未经过检查或者不是空桶！";
                }
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.FixationId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.BucketId = listBucket[0].BucketId;
                    string[] arrTrackId = new string[500];
                    for (int i = 0; i < arrTrackCode.Length;i++ )
                    {
                        IQueryable<TrackItemVM> query = TrackItemBuilder.GetAllTrackList(arrTrackCode[i], stationCode);
                        if (query != null && query.Count() > 0)
                        {
                            arrTrackId[i] = query.ToList()[0].TrackId;
                        }
                    }
                    nuclearFixationRepository.AddFixAtion(item, arrTrackId);
                    nuclearFixationRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入桶固定信息", "调用方法InsertFixAtion()失败。错误信息：" + outErrorMessage);
                }

            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertFixAtion()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入桶固定信息", outErrorMessage);
            }
        }
        #endregion  插入桶固定信息

        #region 插入浓缩液装桶固化400l金属桶信息
        /// <summary>
        /// 插入浓缩液装桶固化400l金属桶信息
        /// </summary>
        /// <param name="item">浓缩液装桶固化400l金属桶信息</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="trackCode">废物跟踪单号</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertMetelBucketLiquid(NuclearBucketSolution item, string bucketCode, string trackCode, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertLiquidMetelBucket()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入浓缩液装桶固化信息", outErrorMessage);
            }
            try
            {
                INuclearBucketSolutionRepository nuclearBucketSolutionRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolutionRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                bool bucketCheck = nuclearBucketRepository.IsExistByCodeAndStation(bucketCode, stationCode);
                if (!bucketCheck)
                {
                    outErrorMessage += "<br>" + "您填的桶号不存在！";
                }
                var listBucket = nuclearBucketRepository.QueryListByCode(bucketCode, stationCode).ToList();
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    outErrorMessage += "<br>" + "您填的桶未经过检查或者不是空桶！";
                }
                var listBucketSolution = nuclearBucketSolutionRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listBucketSolution != null)
                {
                    outErrorMessage += "<br>" + "您填的桶已经填充过！";
                }
                var trackList = TrackItemBuilder.GetAllTrackList(trackCode,stationCode).ToList();
                if (trackList.Count == 0)
                {
                    outErrorMessage += "<br>" + "您填的废物跟踪单号不存在！";
                }
                var solutionList = nuclearBucketSolutionRepository.GetQueryList().Where(n => n.TrackId == trackCode).ToList();
                if (solutionList.Count > 0)
                {
                    outErrorMessage += "<br>" + "您填的废物跟踪单已经经过处理！";
                }
             
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.SolutionId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.TrackId = trackList.ToList()[0].TrackId;
                    item.BucketId = listBucket[0].BucketId;
                    nuclearBucketSolutionRepository.Create(item);
                    nuclearBucketSolutionRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入浓缩液装桶固化信息", "调用方法InsertLiquidMetelBucket()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertLiquidMetelBucket()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入浓缩液装桶固化信息", outErrorMessage);
            }
        }
        #endregion  插入浓缩液装桶固化信息

        #region 插入废树脂装桶固化400l金属桶信息
        /// <summary>
        /// 插入废树脂装桶固化400l金属桶信息
        /// </summary>
        /// <param name="item">废树脂装桶固化400l金属桶信息</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="arrTrackCode">废物跟踪单号集合</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertMetelBucketResin(NuclearBucketResin item, string bucketCode, string[] arrTrackCode, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertMetelBucketResin()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入废树脂装桶固化信息", outErrorMessage);
            }
            try
            {
                INuclearBucketResinRepository nuclearBucketResinRepository = ServiceLocator.Current.GetInstance<INuclearBucketResinRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                bool bucketCheck = nuclearBucketRepository.IsExistByCodeAndStation(bucketCode, stationCode);
                if (!bucketCheck)
                {
                    outErrorMessage += "<br>" + "您填的桶号不存在！";
                }
                var listBucket = nuclearBucketRepository.QueryListByCode(bucketCode, stationCode).ToList();
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    outErrorMessage += "<br>" + "您填的桶未经过检查或者不是空桶！";
                }
                var listBucketSolution = nuclearBucketResinRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listBucketSolution != null)
                {
                    outErrorMessage += "<br>" + "您填的桶已经填充过！";
                }

                var resinTrackList = TrackItemBuilder.GetTrackList(stationCode).Where(c => c.TrackType == "RESIN" && c.DealStatus == "0").ToList();
                string[] arrTrackId = new string[500];
                for (int i = 0; i < arrTrackCode.Length;i++ )
                {
                    string trackCode = arrTrackCode[i];
                    var trackList = TrackItemBuilder.GetTrackList(stationCode).Where(c => c.TrackType == "RESIN" && c.DealStatus == "0" && c.TrackCode.ToUpper().Trim() == trackCode.ToUpper().Trim()).ToList();
                    if (trackList.Count == 0)
                    {
                        outErrorMessage += "<br>" + "您填的废物跟踪单号:" + trackCode + "不存在或者已经处理过！";
                    }
                    else
                    {
                        arrTrackId[i] = trackList.ToList()[0].TrackId;
                    }
                }

                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.ResinId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.BucketId = listBucket[0].BucketId;
                    nuclearBucketResinRepository.AddBucketResin(item,arrTrackId);
                    nuclearBucketResinRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("插入废树脂装桶固化信息", "调用方法InsertMetelBucketResin()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertMetelBucketResin()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("插入废树脂装桶固化信息", outErrorMessage);
            }
        }
        #endregion  插入废树脂装桶固化400l金属桶信息

        #region 插入干湿料制备及废树脂装桶固化信息
        /// <summary>
        /// 插入干湿料制备及废树脂装桶固化信息
        /// </summary>
        /// <param name="item">干湿料制备及废树脂装桶固化信息</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="arrTrackCode">废物跟踪单号集合</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertBucketResinSolidify(NuclearBucketRSolidify item, string bucketCode, string[] arrTrackCode, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertBucketResinSolidify()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入干湿料制备及废树脂装桶固化信息", outErrorMessage);
            }
            try
            {
                INuclearBucketRSolidifyRepository nuclearBucketRSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketRSolidifyRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                bool bucketCheck = nuclearBucketRepository.IsExistByCodeAndStation(bucketCode, stationCode);
                if (!bucketCheck)
                {
                    outErrorMessage += "<br>" + "您填的桶号不存在！";
                }
                var listBucket = nuclearBucketRepository.QueryListByCode(bucketCode, stationCode).ToList();
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    outErrorMessage += "<br>" + "您填的桶未经过检查或者不是空桶！";
                }
                var listBucketSolution = nuclearBucketRSolidifyRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listBucketSolution != null)
                {
                    outErrorMessage += "<br>" + "您填的桶已经填充过！";
                }

                var resinTrackList = TrackItemBuilder.GetTrackList(stationCode).Where(c => c.TrackType == "RESIN" && c.DealStatus == "0").ToList();
                string[] arrTrackId = new string[500];
                for (int i = 0; i < arrTrackCode.Length; i++)
                {
                    string trackCode = arrTrackCode[i];
                    var trackList = TrackItemBuilder.GetTrackList(stationCode).Where(c => c.TrackType == "RESIN" && c.DealStatus == "0" && c.TrackCode.ToUpper().Trim() == trackCode.ToUpper().Trim()).ToList();
                    if (trackList.Count == 0)
                    {
                        outErrorMessage += "<br>" + "您填的废物跟踪单号:" + trackCode + "不存在或者已经处理过！";
                    }
                    else
                    {
                        arrTrackId[i] = trackList.ToList()[0].TrackId;
                    }
                }

                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.SolidifyRId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.BucketId = listBucket[0].BucketId;
                    nuclearBucketRSolidifyRepository.AddBucketRSolidify(item, arrTrackId);
                    nuclearBucketRSolidifyRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("插入干湿料制备及废树脂装桶固化信息", "调用方法InsertBucketResinSolidify()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertBucketResinSolidify()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("插入干湿料制备及废树脂装桶固化信息", outErrorMessage);
            }
        }
        #endregion 插入干湿料制备及废树脂装桶固化信息

        #region 插入干湿料制备及浓缩液装桶固化
        /// <summary>
        /// 插入干湿料制备及浓缩液装桶固化
        /// </summary>
        /// <param name="item">干湿料制备及浓缩液装桶固化信息</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="trackCode">废物跟踪单号</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertBucketLiquid(NuclearBucketSSolidify item, string bucketCode, string trackCode, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertBucketLiquid()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入干湿料制备及浓缩液装桶固化信息", outErrorMessage);
            }
            try
            {
                INuclearBucketSSolidifyRepository nuclearBucketSSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketSSolidifyRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                bool bucketCheck = nuclearBucketRepository.IsExistByCodeAndStation(bucketCode, stationCode);
                if (!bucketCheck)
                {
                    outErrorMessage += "<br>" + "您填的桶号不存在！";
                }
                var listBucket = nuclearBucketRepository.QueryListByCode(bucketCode, stationCode).ToList();
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    outErrorMessage += "<br>" + "您填的桶未经过检查或者不是空桶！";
                }
                var listBucketSolution = nuclearBucketSSolidifyRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listBucketSolution != null)
                {
                    outErrorMessage += "<br>" + "您填的桶已经填充过！";
                }
                var trackList = TrackItemBuilder.GetAllTrackList(trackCode, stationCode).ToList();
                if (trackList.Count == 0)
                {
                    outErrorMessage += "<br>" + "您填的废物跟踪单号不存在！";
                }
                var solutionList = nuclearBucketSSolidifyRepository.GetQueryList().Where(n => n.TrackId == trackCode).ToList();
                if (solutionList.Count > 0)
                {
                    outErrorMessage += "<br>" + "您填的废物跟踪单已经经过处理！";
                }

                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.SolidifySIdd = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.TrackId = trackList.ToList()[0].TrackId;
                    item.BucketId = listBucket[0].BucketId;
                    nuclearBucketSSolidifyRepository.Create(item);
                    nuclearBucketSSolidifyRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入干湿料制备及浓缩液装桶固化信息", "调用方法InsertBucketLiquid()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertBucketLiquid()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入干湿料制备及浓缩液装桶固化信息", outErrorMessage);
            }
        }
        #endregion  插入干湿料制备及浓缩液装桶固化

        #region 插入湿混料制备及400L金属桶装桶封盖
        /// <summary>
        /// 插入湿混料制备及400L金属桶装桶封盖
        /// </summary>
        /// <param name="item">干湿料制备及浓缩液装桶固化信息</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="arrBucketCode">208L桶编号数组</param>
        /// <param name="arrayDate">208L桶打包日期数组</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertMetelBucketCover(NuclearCoverMetal item, string bucketCode,string[] arrBucketCode,string[] arrayDate, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertMetelBucketCover()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入湿混料制备及400L金属桶装桶封盖", outErrorMessage);
            }
            try
            {
                INuclearCoverMetalRepository nuclearCoverMetalRepository = ServiceLocator.Current.GetInstance<INuclearCoverMetalRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                bool bucketCheck = nuclearBucketRepository.IsExistByCodeAndStation(bucketCode, stationCode);
                if (!bucketCheck)
                {
                    outErrorMessage += "<br>" + "您填的桶号不存在！";
                }
                var listBucket = nuclearBucketRepository.QueryListByCode(bucketCode, stationCode).ToList();
              
                if (listBucket[0].BucketStatus != "PREPARE" && listBucket[0].BucketStatus != "FILL")
                {
                    outErrorMessage += "<br>" + "您填的桶号没经过检查或者填充！";
                }
                var listCoverMetal = nuclearCoverMetalRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listCoverMetal != null)
                {
                    outErrorMessage += "<br>" + "您填的桶号已经封盖！";
                }

                List<NuclearCoverDetail> detailList = new List<NuclearCoverDetail>();
                string metelId = Guid.NewGuid().ToString();
                string[] arrBucketId = new string[500];
                for (int i = 0; i < arrBucketCode.Length; i++)
                {
                    var bucketList = nuclearBucketRepository.QueryListByCode(arrBucketCode[i], stationCode).ToList();
                    if (bucketList != null && bucketList.Count > 0)
                    {
                        var sList = nuclearCoverMetalRepository.GetDetailByBucketId(bucketList[0].BucketId).ToList();
                        if (sList != null && sList.Count > 0)
                        {
                            outErrorMessage += "<br>" + "您填的桶号:" + arrBucketCode[i] + "已经经过压缩打包";
                        }
                        NuclearCoverDetail detail = new NuclearCoverDetail();
                        detail.DetailId = Guid.NewGuid().ToString();
                        detail.CoverId = metelId;
                        detail.BucketId = bucketList[0].BucketId;
                        if (!string.IsNullOrEmpty(arrayDate[i]))
                            detail.BucketDate = Convert.ToDateTime(arrayDate[i]);
                        detailList.Add(detail);
                    }
                    else
                    {
                        NuclearCoverDetail detail = new NuclearCoverDetail();
                        detail.DetailId = Guid.NewGuid().ToString();
                        detail.CoverId = metelId;
                        detail.BucketId = arrBucketId[i];
                        if (!string.IsNullOrEmpty(arrayDate[i]))
                            detail.BucketDate = Convert.ToDateTime(arrayDate[i]);
                        detailList.Add(detail);
                    }
                }
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.MetalId = metelId;
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.BucketId = listBucket[0].BucketId;
                    nuclearCoverMetalRepository.AddCoverMetal(item, detailList);
                    nuclearCoverMetalRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入湿混料制备及400L金属桶装桶封盖", "调用法InsertMetelBucketCover()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertMetelBucketCover()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入湿混料制备及400L金属桶装桶封盖", outErrorMessage);
            }
        }
        #endregion  插入湿混料制备及400L金属桶装桶封盖

        #region 插入湿混料制备及封盖
        /// <summary>
        /// 插入湿混料制备及封盖
        /// </summary>
        /// <param name="item">湿混料制备及封盖信息</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertMetelBucketMix(NuclearCoverMix item, string bucketCode,string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertMetelBucketMix()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入湿混料制备及封盖", outErrorMessage);
            }
            try
            {
                INuclearCoverMixRepository nuclearCoverMixRepository = ServiceLocator.Current.GetInstance<INuclearCoverMixRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                bool bucketCheck = nuclearBucketRepository.IsExistByCodeAndStation(bucketCode, stationCode);
                if (!bucketCheck)
                {
                    outErrorMessage += "<br>" + "您填的桶号不存在！";
                }
                var listBucket = nuclearBucketRepository.QueryListByCode(bucketCode, stationCode).ToList();
                if (listBucket[0].BucketStatus != "PREPARE" && listBucket[0].BucketStatus != "FILL")
                {
                    outErrorMessage += "<br>" + "您填的桶号没经过检查或者填充！";
                }
                var listCoverMetal = nuclearCoverMixRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listCoverMetal != null)
                {
                    outErrorMessage += "<br>" + "您填的桶号已经封盖！";
                }

                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.MixId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    item.BucketId = listBucket[0].BucketId;
                    nuclearCoverMixRepository.AddCoverMix(item);
                    nuclearCoverMixRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入湿混料制备及封盖", "调用方法InsertMetelBucketMix()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertMetelBucketMix()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入湿混料制备及封盖", outErrorMessage);
            }
        }
        #endregion 插入湿混料制备及封盖

        #region 插入高整体容器处理
        /// <summary>
        /// 插入高整体容器处理
        /// </summary>
        /// <param name="item">高整体容器处理信息</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertHighContainerDispose(NuclearWasteHDispose item, string bucketCode,string trackCode, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertHighContainerDispose()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入高整体容器处理", outErrorMessage);
            }
            try
            {
                INuclearWasteHDisposeRepository nuclearWasteHDisposeRepository = ServiceLocator.Current.GetInstance<INuclearWasteHDisposeRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                //判断源项跟踪单号是否存在
                string[] trackCodeArr = trackCode.TrimEnd(',').Split(',');
                foreach (var itemArr in trackCodeArr)
                {
                    IQueryable<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList(itemArr, stationCode);
                    if (iqueryTrackItem.Count() == 0)
                    {
                        outErrorMessage += "<br>" + "源项废物单中不存在该跟踪单号！";
                    }
                    else
                    {
                        TrackItemVM vm = iqueryTrackItem.ToList()[0];
                        item.TrackId = vm.TrackId;
                        item.TrackType = vm.TrackType;
                    }
                }
               

                //判断桶号是否存在 
                string bucketId = nuclearBucketRepository.IsExistWasteBucket(bucketCode, stationCode);
                if (string.IsNullOrEmpty(bucketId))
                {
                    outErrorMessage += "<br>" + "容器号不存在！";
                }

                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.DisposeHId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.ContainerCode = bucketId;
                    item.Stationcode = stationCode;
                    nuclearWasteHDisposeRepository.Create(item);
                    nuclearWasteHDisposeRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入高整体容器处理", "调用方法InsertHighContainerDispose()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertHighContainerDispose()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入高整体容器处理", outErrorMessage);
            }
        }
        #endregion 插入高整体容器处理

        #region 插入封盖后贮存信息
        /// <summary>
        /// 插入封盖后贮存信息
        /// </summary>
        /// <param name="item">高整体容器处理信息</param>
        /// <param name="bucketCode">桶编号</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertQTTransfer(NuclearQtTrans item, string bucketCode, NuclearQtTransDetail[] arrQtTransDetail, NuclearQtTransDetailB[] arrQtTransDetailB, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertQTTransfer()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入封盖后贮存信息", outErrorMessage);
            }
            try
            {
                INuclearQtTransRepository nuclearQtTransRepository = ServiceLocator.Current.GetInstance<INuclearQtTransRepository>();
                INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();

                //判断桶号是否存在 
                bool bucketCheck = nuclearBucketRepository.IsExistByCodeAndStation(bucketCode, stationCode);
                if (!bucketCheck)
                {
                    outErrorMessage += "<br>" + "您填的桶号不存在！";
                }

                //判断是否已经经过封盖后存储
                var listBucket = nuclearBucketRepository.QueryListByCode(bucketCode,stationCode).ToList();
                var listTrans = nuclearQtTransRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listTrans != null)
                {
                    outErrorMessage += "<br>" + "您填的桶号已经经过封盖后贮存！";
                }

                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.QtTransId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    List<NuclearQtTransDetail> detailList = new List<NuclearQtTransDetail>();
                    detailList.AddRange(arrQtTransDetail);
                    if (detailList.Count() > 0)
                    {
                        foreach (var itemDetail in detailList)
                        {
                            itemDetail.QtTransDetailId = Guid.NewGuid().ToString();
                        }
                    }
                    List<NuclearQtTransDetailB> detailListB = new List<NuclearQtTransDetailB>();
                    detailListB.AddRange(arrQtTransDetailB);
                    if (detailListB.Count() > 0)
                    {
                        foreach (var itemDetailB in detailListB)
                        {
                            itemDetailB.QtTransDetailIdB = Guid.NewGuid().ToString();
                        }
                    }
                    nuclearQtTransRepository.AddTrans(item, detailList, detailListB);
                    nuclearQtTransRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入封盖后贮存信息", "调用方法InsertQTTransfer()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertQTTransfer()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入封盖后贮存信息", outErrorMessage);
            }
        }
        #endregion 插入封盖后贮存信息

        #region 插入转运信息
        /// <summary>
        /// 插入转运信息
        /// </summary>
        /// <param name="item">转运信息</param>
        /// <param name="bucketCode">转运信息详细</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertNuclearFcTrans(NuclearFcTrans item, NuclearFcTransDetail[] arrNuclearFcTransDetail, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertNuclearFcTrans()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入转运信息", outErrorMessage);
            }
            try
            {

                INuclearFcTransRepository _NuclearFcTransRepository = ServiceLocator.Current.GetInstance<INuclearFcTransRepository>();
                INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                

                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.FcTransId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;

                    List<NuclearFcTransDetail> detailList = new List<NuclearFcTransDetail>();
                    foreach (var itemFcTransDetail in arrNuclearFcTransDetail)
                    {
                        itemFcTransDetail.FcDetailId = Guid.NewGuid().ToString();
                        itemFcTransDetail.FcTransId = item.FcTransId;
                        //itemFcTransDetail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        itemFcTransDetail.Status = "1";
                        itemFcTransDetail.Stationcode = stationCode;
                        NuclearBucket nuclearBucket = _NuclearBucketRepository.QueryListByCode(itemFcTransDetail.BucketId, stationCode).FirstOrDefault();
                        if (nuclearBucket != null)
                        {
                            itemFcTransDetail.BucketId = nuclearBucket.BucketId;
                        }
                        detailList.Add(itemFcTransDetail);
                        
                    }
                    if (_NuclearFcTransRepository.AddFcTrans(item, detailList))
                    {
                        _NuclearBucketRepository.UnitOfWork.Commit();
                    }
                    else
                    {
                        WriteErrorLog("调用插入转运信息", "调用方法InsertNuclearFcTrans()失败。错误信息：" + outErrorMessage);
                    }
                }
                else
                {
                    WriteErrorLog("调用插入转运信息", "调用方法InsertNuclearFcTrans()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertNuclearFcTrans()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用插入转运信息", outErrorMessage);
            }
        }
        #endregion 

        #region 插入入库记录信息
        /// <summary>
        /// 插入入库记录信息
        /// </summary>
        /// <param name="item">入库记录信息</param>
        /// <param name="bucketCode">入库记录信息详细</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertNuclearTsGoodsIn(NuclearTsGoodsIn item, NuclearGoodsInDetail[] arrNuclearGoodsInDetail, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertNuclearTsGoodsIn()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入入库记录信息", outErrorMessage);
            }
            try
            {
                INuclearTsGoodsInRepository _NuclearTsGoodsInRepository = ServiceLocator.Current.GetInstance<INuclearTsGoodsInRepository>();
                INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.GoodsInId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;

                    List<NuclearGoodsInDetail> detailList = new List<NuclearGoodsInDetail>();
                    foreach (var itemFcTransDetail in arrNuclearGoodsInDetail)
                    {

                        itemFcTransDetail.GoodsInDetailId = Guid.NewGuid().ToString();
                        itemFcTransDetail.GoodsInId = item.GoodsInId;
                        itemFcTransDetail.Status = "1";
                        itemFcTransDetail.Stationcode = stationCode;
                        NuclearBucket  nuclearBucket= _NuclearBucketRepository.QueryListByCode(itemFcTransDetail.BucketId, stationCode).FirstOrDefault();
                        if (nuclearBucket != null)
                        {
                            itemFcTransDetail.BucketId = nuclearBucket.BucketId;
                        }
                       
                        detailList.Add(itemFcTransDetail);

                    }
                    if (_NuclearTsGoodsInRepository.AddGoodsIn(item, detailList))
                    {
                        _NuclearBucketRepository.UnitOfWork.Commit();

                    }
                    else
                    {
                        WriteErrorLog("插入入库记录信息", "调用方法InsertNuclearTsGoodsIn()失败。错误信息：" + outErrorMessage);
                    }
                }
                else
                {
                    WriteErrorLog("插入入库记录信息", "调用方法InsertNuclearTsGoodsIn()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertNuclearTsGoodsIn()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("插入入库记录信息", outErrorMessage);
            }
        }
        #endregion 

        #region 插入出库记录信息
        /// <summary>
        /// 插入出库记录信息
        /// </summary>
        /// <param name="item">出库记录</param>
        /// <param name="bucketCode">出库记录详细</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertNuclearTsGoodsOut(NuclearTsGoodsOut item, NuclearGoodsOutDetail[] arrNuclearGoodsOutDetail, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertNuclearTsGoodsOut()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入出库记录信息", outErrorMessage);
            }
            try
            {
                INuclearTsGoodsOutRepository _NuclearTsGoodsOutRepository = ServiceLocator.Current.GetInstance<INuclearTsGoodsOutRepository>();
                INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                    item.GoodsOutId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;

                    List<NuclearGoodsOutDetail> detailList = new List<NuclearGoodsOutDetail>();
                    foreach (var itemGoodsOutDetail in arrNuclearGoodsOutDetail)
                    {

                        itemGoodsOutDetail.GoodsOutDetailId = Guid.NewGuid().ToString();
                        itemGoodsOutDetail.GoodsOutId = item.GoodsOutId;
                        itemGoodsOutDetail.Status = "1";
                        itemGoodsOutDetail.Stationcode = stationCode;
                        NuclearBucket nuclearBucket = _NuclearBucketRepository.QueryListByCode(itemGoodsOutDetail.BucketId, stationCode).FirstOrDefault();
                        if (nuclearBucket != null)
                        {
                            itemGoodsOutDetail.BucketId = nuclearBucket.BucketId;
                        }
                        detailList.Add(itemGoodsOutDetail);

                    }
                    if (_NuclearTsGoodsOutRepository.AddGoodsOut(item, detailList))
                    {
                        _NuclearBucketRepository.UnitOfWork.Commit();

                    }
                    else
                    {
                        WriteErrorLog("插入出库记录信息", "调用方法InsertNuclearTsGoodsOut()失败。错误信息：" + outErrorMessage);
                    }
                }
                else
                {
                    WriteErrorLog("插入出库记录信息", "调用方法InsertNuclearTsGoodsOut()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (DbEntityValidationException ex)
            {
                outErrorMessage = "调用方法InsertNuclearTsGoodsOut()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("插入出库记录信息", outErrorMessage);
            }
        }
        #endregion 

        #region 调用源项跟踪单信息
        [WebMethod]
        [SoapHeader("header")]
        public TrackItemVM[] GetAllTrackList(string stationCode, out string outErrorMessage)
        {
            TrackItemVM[] arr = null;
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法GetAllTrackList()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用源项跟踪单信息", outErrorMessage);
                return null;
            }

            try
            {
                var trackList = TrackItemBuilder.GetTrackList(stationCode).Where(c => c.DealStatus == "0").ToList();

                if (trackList.Count > 0)
                {
                    arr = new TrackItemVM[trackList.Count];
                    for (int i = 0; i < trackList.Count; i++)
                    {
                        arr[i] = trackList[i];
                    }
                }
                return arr;
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法GetAllTrackList()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用源项跟踪单信息", outErrorMessage);
                return null;
            }
        }

        #endregion 

        #region 调用获得废物跟踪单和打包时间
        [WebMethod]
        [SoapHeader("header")]
        public TrackAndDateVM[] GetTrackAndDate(string stationCode, out string outErrorMessage)
        {
            TrackAndDateVM[] arr = null;
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法GetTrackAndDate()失败。错误信息：您没有访问权限！";
                WriteErrorLog("调用获得废物跟踪单和打包时间", outErrorMessage);
                return null;
            }

            try
            {
                INuclearTrackTechSRepository _NuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
                INuclearTrackSundryRepository _NuclearTrackSundryRepository = ServiceLocator.Current.GetInstance<INuclearTrackSundryRepository>();
                INuclearTrackElementRepository _NuclearTrackElementRepository = ServiceLocator.Current.GetInstance<INuclearTrackElementRepository>();

                List<NuclearTrackTechS> iqueryTrackTechS = _NuclearTrackTechSRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode).Where(d => (d.DealStatus == "0" || d.DealStatus ==null)).ToList();
                List<NuclearTrackSundry> iquerySundry = _NuclearTrackSundryRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode).Where(d => (d.DealStatus == "0" || d.DealStatus == null)).ToList();
                List<NuclearTrackElement> iqueryTrackElement = _NuclearTrackElementRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode).Where(d => (d.DealStatus == "0" || d.DealStatus == null)).ToList();
                //int count=iqueryTrackTechS.Count() + iquerySundry.Count() + iqueryTrackElement.Count();

                List<TrackAndDateVM> trackAndDateList = new List<TrackAndDateVM>();
                if (iqueryTrackTechS.Count > 0)
                {
                    foreach (var item in iqueryTrackTechS)
                    {
                        TrackAndDateVM trackAndDateVM = new TrackAndDateVM();
                        trackAndDateVM.BucketId = item.BucketId;
                        trackAndDateVM.TrackCode = item.TechSCode;
                        trackAndDateVM.DateTimePage = item.ControlDate;
                        trackAndDateList.Add(trackAndDateVM);
                        
                    }

                }

                if (iquerySundry.Count > 0)
                {
                    foreach (var item in iquerySundry)
                    {
                        TrackAndDateVM trackAndDateVM = new TrackAndDateVM();
                        trackAndDateVM.BucketId = item.StorageContainerId;
                        trackAndDateVM.TrackCode = item.SundryCode;
                        trackAndDateVM.DateTimePage = item.ControlDate;
                        trackAndDateList.Add(trackAndDateVM);

                    }

                }

                if (iqueryTrackElement.Count > 0)
                {
                    
                        TrackAndDateVM trackAndDateVM = new TrackAndDateVM();
                        trackAndDateVM.BucketId = iqueryTrackElement[0].StorageContainerId;
                        trackAndDateVM.TrackCode = iqueryTrackElement[0].ElementCode;
                        trackAndDateVM.DateTimePage = iqueryTrackElement[0].InputContainerControlDate;
                        trackAndDateList.Add(trackAndDateVM);
                }


                if (trackAndDateList.Count > 0)
                {
                    arr = new TrackAndDateVM[trackAndDateList.Count];
                    for (int i = 0; i < trackAndDateList.Count; i++)
                    {
                        arr[i] = trackAndDateList[i];
                    }
                }
                return arr;
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法GetTrackAndDate()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("调用获得废物跟踪单和打包时间", outErrorMessage);
                return null;
            }
        }

        #endregion 

        #region 插入废物接收信息
        /// <summary>
        /// 插入废物接收信息
        /// </summary>
        /// <param name="item">废物接收信息</param>
        /// <param name="bucketCode">转运信息详细</param>
        /// <param name="stationCode">电站编号</param>
        /// <param name="outErrorMessage">返回的错误信息</param>
        [WebMethod]
        [SoapHeader("header")]
        public void InsertNuclearRubReception(NuclearRubReception item, NuclearRubReceptionD[] arrNuclearRubReceptionD, string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法InsertNuclearFcTrans()失败。错误信息：您没有访问权限！";
                WriteErrorLog("插入废物接收信息", outErrorMessage);
            }
            try
            {

                INuclearRubReceptionRepository _NuclearRubReceptionRepository = ServiceLocator.Current.GetInstance<INuclearRubReceptionRepository>();
                INuclearRubReceptionDRepository _NuclearRubReceptionDRepository = ServiceLocator.Current.GetInstance<INuclearRubReceptionDRepository>();
                IMaterialTypeRepository _MaterialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
                INuclearWastePackageRepository _NuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
                foreach (var itemNuclearRubReceptionD in arrNuclearRubReceptionD)
                {
                    NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode.Trim() == itemNuclearRubReceptionD.PackageId.Trim() && d.Stationcode == stationCode).FirstOrDefault();
                    if (nuclearWastePackage == null)
                    {
                        outErrorMessage += "<br>" + "废物货包不存在！";
                    }
                    else
                    {
                        string isApplied = _NuclearWastePackageRepository.IsApplied(nuclearWastePackage.PackageCode, stationCode);
                        if (string.IsNullOrEmpty(isApplied))
                        {
                            outErrorMessage += "<br>" + "审批没通过！";
                        }
                        NuclearRubReceptionD nuclearRubReceptionD = _NuclearRubReceptionDRepository.GetAll().Where(d => d.PackageId == nuclearWastePackage.PackageId).FirstOrDefault();
                        if (nuclearRubReceptionD != null)
                        {
                            outErrorMessage += "<br>" + "废物货包号已存在接收列表！";
                        }
                    }
                    if (nuclearWastePackage.Status == "DEALED")
                    {
                        outErrorMessage += "<br>" + "废物包已被下一环节处置！";
                    }

                }

                //GetUserNameFromUserNo
                AscBimsServices.BIMS_WebServiceSoapClient bims = new AscBimsServices.BIMS_WebServiceSoapClient();
             
                
                if (string.IsNullOrEmpty(outErrorMessage))
                {
                   
                    item.ReceptId = Guid.NewGuid().ToString();
                    item.Status = "1";
                    item.Stationcode = stationCode;
                    //item.ReceptionName = GetUserNameFromUserNo(item.ReceptionNo);
                    AscBimsServices.StaffS staffTrans = bims.StaffSByStaffNO(item.TransportNo, "C3AF76305F3D4569");
                    AscBimsServices.StaffS staffRecep = bims.StaffSByStaffNO(item.ReceptionNo, "C3AF76305F3D4569");
                    item.TransportName = staffTrans.STAFF_NAME; 
                    item.ReceptionName = staffRecep.STAFF_NAME; 

                    _NuclearRubReceptionRepository.Create(item);
                    foreach (var itemNuclearRubReceptionD in arrNuclearRubReceptionD)
                    {
                        MaterialType materialType = _MaterialTypeRepository.Get(itemNuclearRubReceptionD.BucketType);
                        itemNuclearRubReceptionD.DetailId = Guid.NewGuid().ToString();
                        itemNuclearRubReceptionD.ReceptId = item.ReceptId;
                        if (materialType.IsBucket == "0")
                        {
                            itemNuclearRubReceptionD.IsCementquelified = itemNuclearRubReceptionD.Isquelified;
                        }
                        if (materialType.IsBucket == "1")
                        {
                            itemNuclearRubReceptionD.IsMetelquelified = itemNuclearRubReceptionD.Isquelified;
                        }
                        NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode.Trim() == itemNuclearRubReceptionD.PackageId.Trim() && d.Stationcode == stationCode).FirstOrDefault();
                        if (nuclearWastePackage != null)
                        {
                            itemNuclearRubReceptionD.PackageId = nuclearWastePackage.PackageId;
                            itemNuclearRubReceptionD.BucketId = nuclearWastePackage.BucketId;
                        }
                        _NuclearRubReceptionDRepository.Create(itemNuclearRubReceptionD);
                    }
                    _NuclearRubReceptionDRepository.UnitOfWork.Commit();
                }
                else
                {
                    WriteErrorLog("调用插入转运信息", "调用方法InsertNuclearRubReception()失败。错误信息：" + outErrorMessage);
                }
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法InsertNuclearRubReception()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("插入废物接收信息", outErrorMessage);
            }
        }
        #endregion 
       
        #region 根据废物包号获得桶号
        /// <summary>
        /// 根据废物包号获得桶号
        /// </summary>
        /// <param name="packageCode"></param>
        /// <param name="outErrorMessage"></param>
        /// <returns></returns>
        [SoapHeader("header")]
        public string GetBucketCodeByPackage(string packageCode,string stationCode, out string outErrorMessage)
        {
            outErrorMessage = string.Empty;
            if (!this.IsValiToken())
            {
                outErrorMessage = "调用方法GetBucketCodeByPackage()失败。错误信息：您没有访问权限！";
                WriteErrorLog("根据废物包号获得桶号", outErrorMessage);
            }
            try
            {

                string bucketCode = string.Empty;
                INuclearWastePackageRepository _NuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
                INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
              

                
                IQueryable<NuclearWastePackage> nuclearWastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode.Trim() == packageCode.Trim() && d.Stationcode == stationCode).AsQueryable();
                IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.Stationcode == stationCode).AsQueryable();
                nuclearBucket = from b in nuclearBucket
                                join p in nuclearWastePackage
                                        on b.BucketId equals p.BucketId
                                select b;
                if (nuclearBucket.Count() > 0)
                {
                    bucketCode= nuclearBucket.ToList()[0].BucketCode;
                }

                return bucketCode;
               
            }
            catch (Exception ex)
            {
                outErrorMessage = "调用方法GetBucketCodeByPackage()失败。错误信息：" + ex.StackTrace;
                WriteErrorLog("根据废物包号获得桶号", outErrorMessage);
                return null;
            }
        }
        #endregion   
    }
}
