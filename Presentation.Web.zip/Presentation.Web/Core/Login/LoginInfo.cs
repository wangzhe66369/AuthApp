﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NET01.CoreFramework;
using System.Configuration;
using NET01.Infrastructure.ORG;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.AscBimsServices;
using RWIS.Infrastructure.Crosscutting;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Core.Login
{
    public class LoginInfo
    {

        #region 私有方法
        /// <summary>
        ///获取当前域用户名
        ///注意：用户名不加Domain前缀 如：PCITMJP
        /// </summary>
        public static string GetDomainUser()
        {

            string loginUserId = HttpContext.Current.Request.ServerVariables["LOGON_USER"];//获取用户名

            if (loginUserId == null || loginUserId == String.Empty)
            {
                throw new Exception("登录配置出错，应该网站配置成域验证");
            }
            int index = loginUserId.IndexOf('\\');
            if (index > 0)
            {
                loginUserId = loginUserId.Remove(0, index + 1);
            }
            loginUserId = loginUserId.ToUpper();
            return loginUserId;

        }

        public static bool SaveLoginInfo(string userId)
        {
            IUserLoginInfoRepository iUserLoginInfoRepository = ServiceLocator.Current.GetInstance<IUserLoginInfoRepository>();
            UserLoginInfo loginInfo = iUserLoginInfoRepository.GetUserLoginInfo(userId);
            string defaultStationCode = "CC";// ConfigurationManager.AppSettings["DefaultConstraint"]; ;
            if (loginInfo != null)
            {
                defaultStationCode = loginInfo.StationCode;
            }

            ApplicationUser user = new ApplicationUser();
            if (AppSetting.Instance.OrgMode == "W")
            {
                //从ASC取人员信息
                BIMS_WebServiceSoapClient client = new BIMS_WebServiceSoapClient();
                var tempUser = client.StaffSByStaffNO(userId.ToUpper(), AppSetting.Instance.AscKey);
                if (!string.IsNullOrEmpty(tempUser.STAFF_NO))
                {
                    user.UserId = userId;
                    user.UserName = tempUser.STAFF_NAME;
                    user.DeptNo = tempUser.DEPT_NO;
                    user.DeptName = tempUser.DEPT_NAME;
                    user.ProjectCode = defaultStationCode;
                    AppContext.CurrentUser = user;
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                //从虚拟组织机构中获取人员信息
                IOrganizationRepository org = ServiceLocator.Current.GetInstance<IOrganizationRepository>();
                var staff = org.GetStaff(userId.ToUpper());
                if (staff != null)
                {
                    user.UserId = userId.ToUpper();
                    user.UserName = staff.Name;
                    user.DeptNo = staff.Organzations.Count > 0 ? staff.Organzations.First().OrganziationNo : "";
                    user.DeptName = staff.Organzations.Count > 0 ? staff.Organzations.First().Name : "";
                    user.ProjectCode = defaultStationCode;
                    AppContext.CurrentUser = user;
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        #endregion
    }
}
