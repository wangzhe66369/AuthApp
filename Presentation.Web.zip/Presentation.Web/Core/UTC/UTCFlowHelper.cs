﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CIT.App.Lib.Uwf.Model;
using NET01.CoreFramework;

namespace RWIS.Presentation.Web.Core.UTC
{
    /// <summary>
    /// 任务中心流程辅助工具
    /// </summary>
    public class UTCFlowHelper
    {

        /// <summary>
        /// 将UTCDesc对象转换为应用程序用户对象
        /// </summary>
        /// <param name="dest">UTCDesc对象</param>
        /// <returns></returns>
        public static UWFUser ConvertAppUserToUWFUser(ApplicationUser appUser)
        {
            UWFUser uwfUser = new UWFUser();
            uwfUser.UserId = appUser.UserId;
            uwfUser.UserName = appUser.UserName;
            uwfUser.DeptID = appUser.DeptNo;
            return uwfUser;
        }
    }
}