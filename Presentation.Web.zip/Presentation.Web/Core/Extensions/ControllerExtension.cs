﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   ControllerExtension.cs
 *   描    述   ：   Controller扩展
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NET01.Infrastructure.Workflow;
using RWIS.Infrastructure.Crosscutting;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using NET01.CoreFramework;
using NET01.Infrastructure.BasicData.Services;
using CIT.UPC.Domain.Repositories;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    ///  Controller扩展
    /// </summary>
    public static class ControllerExtension
    {
        /// <summary>
        /// 创建工作流活动
        /// </summary>
        /// <param name="controller"></param>
        /// <returns></returns>
        public static WorkflowEventAction CreateWorkflowEventAction(this Controller controller)
        {
            WorkflowEventAction action = new WorkflowEventAction();
            action.ProcessUserNo = AppContext.CurrentUser.UserId;
            action.ProcessUserName = AppContext.CurrentUser.UserName;
            action.SubSystemCode = AppSetting.Instance.SystemCode;

            return action;
        }

        /// <summary>
        /// 创建工作流活动
        /// </summary>
        /// <param name="controller"></param>
        /// <returns></returns>
        public static WorkflowEventAction CreateWorkflowEventAction(this Controller controller, WorkflowTask task)
        {
            WorkflowEventAction action = new WorkflowEventAction();
            action.ProcessUserNo = AppContext.CurrentUser.UserId;
            action.ProcessUserName = AppContext.CurrentUser.UserName;
            action.SubSystemCode = AppSetting.Instance.SystemCode;
            action.InstanceId = task.InstanceId;
            action.State = task.CurrentState;
            action.WorkflowName = task.WorkflowName;

            return action;
        }


        #region 附件处理

        /// 保存附件
        /// </summary>
        /// <param name="controller">Controller</param>
        /// <param name="businessId">业务ID</param>
        /// <param name="uloadFileInputId">input控件ID</param>
        /// <param name="formCollection">formCollection</param>
        public static void SaveAttachFile(this Controller controller, string businessId, string uloadFileInputId, FormCollection formCollection)
        {
            IAttachFileRepository attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            List<CIT.UPC.Domain.DomainObjects.AttachFile> attachFiles = GetAttachFilesByFormCollection(controller, businessId, uloadFileInputId, formCollection);
            if (attachFiles.Count > 0)
            {
                attachFiles.ForEach(attach =>
                {
                    attachFileRepository.Create(attach);
                });
                attachFileRepository.UnitOfWork.Commit();
            }

        }

        /// <summary>
        /// 通过窗体获取附件列表信息
        /// </summary>
        /// <param name="businessId">业务ID</param>
        /// <param name="formCollection">附件窗体值</param>
        /// <param name="uloadFileInputId">业务类型</param>
        public static List<CIT.UPC.Domain.DomainObjects.AttachFile> GetAttachFilesByFormCollection(this Controller controller, string businessId, string uloadFileInputId, FormCollection formCollection)
        {
            List<CIT.UPC.Domain.DomainObjects.AttachFile> attachFiles = new List<CIT.UPC.Domain.DomainObjects.AttachFile>();
            if (formCollection[uloadFileInputId + "_guid"] != null)
            {
                string[] arrayGuid;
                string[] arrayBusinessType;
                string[] arrayFileBame;
                string[] arrayFileSize;
                if (formCollection[uloadFileInputId + "_guid"].IndexOf(',') >= 0)
                {
                    arrayGuid = formCollection[uloadFileInputId + "_guid"].Split(',');
                    arrayBusinessType = formCollection[uloadFileInputId + "_businesstype"].Split(',');
                    arrayFileBame = formCollection[uloadFileInputId + "_filename"].Split(',');
                    arrayFileSize = formCollection[uloadFileInputId + "_filesize"].Split(',');
                }
                else
                {
                    arrayGuid = new[] { formCollection[uloadFileInputId + "_guid"] };
                    arrayBusinessType = new[] { formCollection[uloadFileInputId + "_businesstype"] };
                    arrayFileBame = new[] { formCollection[uloadFileInputId + "_filename"] };
                    arrayFileSize = new[] { formCollection[uloadFileInputId + "_filesize"] };
                }
                CIT.UPC.Domain.DomainObjects.AttachFile file = null;
                string userName = AppContext.CurrentUser.UserName;
                string userId = AppContext.CurrentUser.UserId;
                for (int i = 0; i < arrayGuid.Length; i++)
                {
                    file = new CIT.UPC.Domain.DomainObjects.AttachFile();
                    file.BusinessId = businessId;
                    file.BusinessType = arrayBusinessType[i];
                    file.CreateDate = DateTime.Now;
                    file.CreateUserName = userName;
                    file.CreateUserNo = userId;
                    file.FileId = arrayGuid[i];
                    file.FileLength = int.Parse(arrayFileSize[i]);
                    file.FileName = HttpUtility.UrlDecode(arrayFileBame[i]);
                    file.FileType = arrayFileBame[i].Substring(arrayFileBame[i].LastIndexOf('.') + 1);
                    file.FilePath = arrayBusinessType[i] + "/";

                    attachFiles.Add(file);
                }
            }
            return attachFiles;
        }

        #endregion
        /// <summary>
        /// 返回路由至待办的ActionResult
        /// </summary>
        /// <param name="controller"></param>
        /// <returns></returns>
        public static ActionResult RedirectToProcessingTaskAction(this Controller controller)
        {
            return new RedirectResult("~/Basic/Workflow/ProcessingTask");
        }
    }
}