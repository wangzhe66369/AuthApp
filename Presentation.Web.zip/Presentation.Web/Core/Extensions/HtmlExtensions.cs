﻿/********************************************************************************
  *
  *   项目名称   ：   标准化框架
  *   文 件 名   ：   HtmlExtensions.cs
  *   版    本   ：   .Net FrameWork 4.0
  *   描    述   ：   HTML扩展
  *   创 建 者   ：   框架人员
  *   创建日期   ：   2011-12-21 14:00:00
  *    
  *
  *　----------------变更历史----------------------------------------------------　 
  *   修改日期                版本       修改者       修改内容
  *   2011-12-21 14:00:00    1.0.0.0      杨斌         初版　 
  *    
  *

  *   
  *******************************************************************************/

using System;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web.Mvc.Html;
using System.Web.Routing;
using System.Collections.Specialized;
using MvcContrib.Pagination;
using NET01.Infrastructure.Workflow;
using System.Collections.Generic;
using Microsoft.Practices.ServiceLocation;
using System.Linq.Expressions;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.ViewModels.Common;
using RWIS.Presentation.Web.Areas.Basic.ViewModels;
using CIT.App.Lib.Uwf.Model;
using NET01.Presentation.Web.Mvc.Extensions;
using NET01.Infrastructure.BasicData.Services;

namespace RWIS.Presentation.Web.Core
{
    public static class HtmlExtensions
    {
        #region 工作流
        /// <summary>
        /// 输出审批步骤
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="instanceId"></param>
        public static MvcHtmlString PartialApproveStep(this HtmlHelper helper, string instanceId, string divId = "", long? gridWidth = 12)
        {
            WorkflowVM vm = new WorkflowVM();
            vm.InstanceId = instanceId;
            vm.DivId = string.IsNullOrEmpty(divId) ? ("div" + instanceId.Replace("-", "")) : divId;
            vm.GridWidth = gridWidth;
            return helper.Partial("_WorkflowLog", vm);
        }

        /// <summary>
        /// 获取工作流实例创建人文本
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="instanceId"></param>
        /// <returns></returns>
        public static MvcHtmlString WorkflowInstanceCreateUserText(this HtmlHelper helper, string instanceId)
        {
            ApprovalInstance instance = ServiceLocator.Current.GetInstance<IWorkflowRuntime>()
                .GetService<IWorkflowRepository>().GetApprovalInstance(instanceId);

            TagBuilder text = new TagBuilder("span");
            text.InnerHtml = instance.CreateUserName + "(" + instance.CreateUser + ")";
            return MvcHtmlString.Create(text.ToString());
        }
        #endregion


        #region 文本输入
        /// <summary>
        /// 输出大文本字段[目前采用PRE标签]
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static MvcHtmlString LargeText(this HtmlHelper helper, string value)
        {
            // 生成与标题链接有关的HTML代码
            TagBuilder text = new TagBuilder("pre");
            text.AddCssClass("pre");
            text.InnerHtml = value;
            return MvcHtmlString.Create(text.ToString());
        }
        /// <summary>
        /// 输出大文本字段[目前采用PRE标签]
        /// </summary>
        /// <typeparam name="TModel"></typeparam>
        /// <typeparam name="TProperty"></typeparam>
        /// <param name="helper"></param>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static MvcHtmlString LargeTextFor<TModel, TProperty>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TProperty>> expression)
        {
            object data = ModelMetadata.FromLambdaExpression<TModel, TProperty>(expression, helper.ViewData).Model;
            if (data != null)
            {
                TagBuilder text = new TagBuilder("pre");
                text.InnerHtml = data.ToString();
                text.AddCssClass("pre");
                return MvcHtmlString.Create(text.ToString());
            }
            return null;

        }
        #endregion

        #region 文本显示


        /// <summary>
        /// 文本字段[处理日期值]
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static MvcHtmlString Text(this HtmlHelper helper, DateTime? value, string format = "yyyy-MM-dd")
        {
            if (value == null)
            {
                return null;
            }
            return MvcHtmlString.Create(value.Value.ToString(format));
        }

        #endregion

        #region 附件



        #region 附件

        /// <summary>
        /// 输出附件列表
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="instanceId"></param>
        public static MvcHtmlString PartialAttachFiles(this HtmlHelper helper, IEnumerable<CIT.UPC.Domain.DomainObjects.AttachFile> attachFiles, string mode)
        {
            CIT.UPC.Presentation.Web.ViewModels.Common.UploadFileListVM vm = new CIT.UPC.Presentation.Web.ViewModels.Common.UploadFileListVM();

            if (attachFiles == null)
            {
                vm.FileList = new List<CIT.UPC.Domain.DomainObjects.AttachFile>();
            }
            else
            {
                vm.FileList = attachFiles;
            }

            switch (mode)
            {
                case "View":
                    vm.EnableDownLoad = true;
                    vm.EnableDelete = false;
                    break;
                case "Edit":
                    vm.EnableDownLoad = true;
                    vm.EnableDelete = true;
                    break;

                default:
                    vm.EnableDownLoad = true;
                    vm.EnableDelete = false;
                    break;
            }
            return helper.Partial("_UploadFileList", vm);
        }
        #endregion

        #endregion


        //#region 附件

        ///// <summary>
        ///// 输出附件列表
        ///// </summary>
        ///// <param name="helper"></param>
        ///// <param name="instanceId"></param>
        //public static MvcHtmlString PartialAttachFiles(this HtmlHelper helper, IEnumerable<AttachFile> attachFiles, string mode)
        //{
        //    UploadFileListVM vm = new UploadFileListVM();

        //    if (attachFiles == null)
        //    {
        //        vm.FileList = new List<AttachFile>();
        //    }
        //    else
        //    {
        //        vm.FileList = attachFiles;
        //    }

        //    switch (mode)
        //    {
        //        case "View":
        //            vm.EnableDownLoad = true;
        //            vm.EnableDelete = false;
        //            break;
        //        case "Edit":
        //            vm.EnableDownLoad = true;
        //            vm.EnableDelete = true;
        //            break;

        //        default:
        //            vm.EnableDownLoad = true;
        //            vm.EnableDelete = false;
        //            break;
        //    }
        //    return helper.Partial("_UploadFileList", vm);
        //}
        //#endregion

        #region 按纽
        /// <summary>
        /// 输出按钮的HTML
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="buttonId">按钮ID</param>
        /// <param name="buttonText">按钮文本</param>
        /// <param name="cssClass">按钮样式名</param>
        /// <param name="buttonTitle">按钮标题（光标移到按钮上显示的文本）</param>
        /// <param name="onClick">单击事件</param>
        /// <returns>按钮HTML</returns>
        public static MvcHtmlString Button(this HtmlHelper helper, string buttonId, string buttonText, string cssClass, string buttonTitle = null, string onClick = null)
        {
            StringBuilder render = new StringBuilder();
            render.AppendFormat("<input type=\"button\" id=\"{0}\" value=\"{1}\" class=\"ui-btn {2}\" onmouseover=\"this.className='ui-btn {2}-hover'\" onmouseout=\"this.className='ui-btn {2}'\" ", buttonId, buttonText, cssClass);

            if (!string.IsNullOrEmpty(buttonTitle))
            {
                render.Append(String.Format("title=\"{0}\" ", buttonTitle));
            }

            if (onClick != null)
            {
                render.Append(String.Format("onclick=\"{0}\" ", onClick));
            }

            render.Append("/>");
            return MvcHtmlString.Create(render.ToString());
        }

        /// <summary>
        /// 输出连接按纽
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="buttonId">按扭id</param>
        /// <param name="text">控纽文本</param>
        /// <param name="icon">按纽小图标</param>
        /// <returns></returns>
        public static MvcHtmlString LinkButton(this HtmlHelper helper, string buttonId, string text, string icon, string url)
        {
            string onclick = "javascript:window.location.href = '" + url + "'";
            return Button(helper, buttonId, text, icon, onclick);

        }

        #endregion


        #region 下拉列表

        /// 根据枚举类型绑定DropDownList
        /// </summary>
        /// <typeparam name="TModel">TModel</typeparam>
        /// <typeparam name="TProperty">TProperty</typeparam>
        /// <param name="helper">helper</param>
        /// <param name="expression">expression</param>
        /// <param name="enumType">枚举类型</param>
        /// <param name="selectedValue">默认值</param>
        /// <returns></returns>
        public static MvcHtmlString EnumDropDownList(this HtmlHelper helper,
            string name, Type enumType, object selectedValue = null)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>() { { "", "--请选择--" } };
            if (enumType.IsEnum)
            {
                foreach (int value in Enum.GetValues(enumType))
                {
                    //值
                    string val = Enum.GetName(enumType, value);
                    Enum e = (Enum)Enum.Parse(enumType, val);
                    //描述
                    string description = e.GetDescription();
                    dic.Add(val, e.GetDescription());
                }
            }
            var selectList = new SelectList(dic, "Key", "Value", selectedValue);
            return helper.DropDownList(name, selectList, null, null);
        }

        /// <summary>
        /// 根据枚举类型绑定DropDownList
        /// </summary>
        /// <typeparam name="TModel">TModel</typeparam>
        /// <typeparam name="TProperty">TProperty</typeparam>
        /// <param name="helper">helper</param>
        /// <param name="expression">expression</param>
        /// <param name="enumType">枚举类型</param>
        /// <param name="selectedValue">默认值</param>
        /// <returns></returns>
        public static MvcHtmlString EnumDropDownListFor<TModel, TProperty>(this HtmlHelper<TModel> helper,
            Expression<Func<TModel, TProperty>> expression, Type enumType, object selectedValue = null)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>() { { "", "--请选择--" } };
            if (enumType.IsEnum)
            {
                foreach (int value in Enum.GetValues(enumType))
                {
                    //值
                    string val = Enum.GetName(enumType, value);
                    Enum e = (Enum)Enum.Parse(enumType, val);
                    //描述
                    string description = e.GetDescription();
                    dic.Add(val, e.GetDescription());
                }
            }
            var selectList = new SelectList(dic, "Key", "Value", selectedValue);
            return helper.DropDownListFor(expression, selectList, null, null);
        }

        /// <summary>
        /// 根据枚举类型绑定DropDownList
        /// </summary>
        /// <typeparam name="TModel"></typeparam>
        /// <typeparam name="TProperty"></typeparam>
        /// <param name="helper"></param>
        /// <param name="expression"></param>
        /// <param name="enumType">枚举类型</param>
        /// <param name="selectedValue">默认值</param>
        /// <param name="htmlAttributes">html属性</param>
        /// <returns></returns>
        public static MvcHtmlString EnumDropDownListFor<TModel, TProperty>(this HtmlHelper<TModel> helper,
            Expression<Func<TModel, TProperty>> expression, Type enumType, object selectedValue, object htmlAttributes = null)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>() { { "", "--请选择--" } };
            if (enumType.IsEnum)
            {
                foreach (int value in Enum.GetValues(enumType))
                {
                    //值
                    string val = Enum.GetName(enumType, value);
                    Enum e = (Enum)Enum.Parse(enumType, val);
                    //描述
                    string description = e.GetDescription();
                    dic.Add(val, e.GetDescription());
                }
            }
            var selectList = new SelectList(dic, "Key", "Value", selectedValue);
            return helper.DropDownList(ExpressionHelper.GetExpressionText(expression), selectList, null, htmlAttributes);
        }


        /// <summary>
        /// 绑定审批类型
        /// </summary>
        /// <typeparam name="TModel"></typeparam>
        /// <typeparam name="TProperty"></typeparam>
        /// <param name="helper"></param>
        /// <param name="expression"></param>
        /// <param name="baseDataType"></param>
        /// <param name="optionLabel"></param>
        /// <returns></returns>
        public static MvcHtmlString RadioButtonListToOperateType(this HtmlHelper helper, string name, List<ActRoute> actRouteList)
        {
            //字典类型
            var dicDictonaryType = new Dictionary<string, string>();


            if (actRouteList != null)
            {
                actRouteList.ForEach(x => dicDictonaryType.Add(x.TargetActMetaData, x.Name));
            }

            var areaSelectList = new SelectList(dicDictonaryType, "Key", "Value");

            return helper.RadioButtonList(name, areaSelectList);
        }


        #endregion


    }
}

