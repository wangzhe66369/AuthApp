﻿/********************************************************************************
  *
  *   项目名称   ：   标准化框架
  *   文 件 名   ：   DateTimeExtensions.cs
  *   版    本   ：   .Net FrameWork 4.0
  *   描    述   ：   DateTime扩展
  *   创 建 者   ：   框架人员
  *   创建日期   ：   2011-12-21 14:00:00
  *    
  *
  *　----------------变更历史----------------------------------------------------　 
  *   修改日期                版本       修改者       修改内容
  *   2011-12-21 14:00:00    1.0.0.0      杨斌         初版　 
  *    
  *

  *   
  *******************************************************************************/

using System;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web.Mvc.Html;
using System.Web.Routing;
using System.Collections.Specialized;
using MvcContrib.Pagination;
using NET01.Infrastructure.Workflow;
using System.Collections.Generic;
using Microsoft.Practices.ServiceLocation;
using System.Linq.Expressions;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.ViewModels.Common;
using RWIS.Presentation.Web.Areas.Basic.ViewModels;


namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// DateTime扩展类
    /// </summary>
    public static class DateTimeExtensions
    {
        /// <summary>
        /// DateTime?
        /// </summary>
        /// <param name="obj">DateTime?</param>
        /// <returns></returns>
        public static string ToShortDate(this DateTime? obj)
        {
            if (obj == null || !obj.HasValue)
            {
                return string.Empty;
            }
            return ((DateTime)obj).ToString("yyyy-MM-dd");
        }
        /// <summary>
        /// DateTime?
        /// </summary>
        /// <param name="obj">DateTime?</param>
        /// <returns></returns>
        public static string ToShortTime(this DateTime? obj)
        {
            if (obj == null || !obj.HasValue)
            {
                return string.Empty;
            }
            return ((DateTime)obj).ToString("yyyy-MM-dd HH:mm:ss");
        }
    }
}