﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   WorkflowTask.cs
 *   描    述   ：   任务请求上下文
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// 任务请求上下文
    /// </summary>
    public class WorkflowTask
    {
        public string CurrentState { get; set; }
        public string WorkflowName { get; set; }
        public string InstanceId { get; set; }
    }
}