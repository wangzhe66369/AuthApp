﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading;
using System.Globalization;

namespace RWIS.Presentation.Web.Core.Globalization
{
    public class GlobalizationManager
    {
        public const string DefaultCulture = "en-US";
        public const string CultureCookieKey = "RWISLang";


        public static string GetStaticStyle()
        {
            return System.Configuration.ConfigurationManager.AppSettings["StyleServerUrl"] + "/styles/" + System.Configuration.ConfigurationManager.AppSettings["StyleVersion"];
        }

        public static string GetStaticScript()
        {
            return System.Configuration.ConfigurationManager.AppSettings["StyleServerUrl"] + "/scripts";
        }
        /// <summary>
        /// 获取请求的语言名称,默认从Cookie中获取
        /// </summary>
        /// <returns>语言名称:zh-CN/en-US</returns>
        public static string GetRequestLanguage()
        {
            string culture = null;
            HttpRequest Request = HttpContext.Current.Request;
            HttpCookie cookie = Request.Cookies[CultureCookieKey];
            if (cookie == null)
            {
                if ((Request.UserLanguages != null) && (Request.UserLanguages.Length > 0))
                {
                    culture = Request.UserLanguages[0];
                }
            }
            else
            {
                culture = cookie.Value;
            }
            return culture;
        }

        /// <summary>
        /// 设置当前区域信息
        /// </summary>
        /// <param name="lang">语言名称:zh-CN/en-US</param>
        public static void SetCurrentCulture(string lang)
        {
            Thread.CurrentThread.CurrentCulture = GetCultureInfo(lang);
            Thread.CurrentThread.CurrentUICulture = GetCultureInfo(lang);
            if (!string.IsNullOrWhiteSpace(lang))
            {
                if (HttpContext.Current.Request.Cookies[CultureCookieKey] != null)
                {
                    HttpContext.Current.Response.Cookies[CultureCookieKey].Value = lang;
                }
                else
                {
                    HttpContext.Current.Response.Cookies.Add(new HttpCookie(CultureCookieKey, lang));
                }
            }
        }

        public static void SetCurrentCulture()
        {
            GlobalizationManager.SetCurrentCulture(GetRequestLanguage());
        }

        private static CultureInfo currentCultureInfo;
        /// <summary>
        /// 属性：当前区域信息，默认从Cookie中获取。
        /// </summary>
        public static CultureInfo CurrentCultureInfo
        {
            get
            {
                string lang = HttpContext.Current.Response.Cookies[CultureCookieKey].Value;
                if (string.IsNullOrEmpty(lang))
                {
                    lang = DefaultCulture;
                }
                currentCultureInfo = GetCultureInfo(lang);
                return currentCultureInfo;
            }
        }

        /// <summary>
        /// 获取当前区域信息
        /// </summary>
        /// <param name="lang">语言名称:zh-CN/en-US</param>
        /// <returns>区域信息</returns>
        public static CultureInfo GetCultureInfo(string lang)
        {
            try
            {
                return new CultureInfo(lang);
            }
            catch
            {
                return new CultureInfo(DefaultCulture);
            }
        }
    }
}