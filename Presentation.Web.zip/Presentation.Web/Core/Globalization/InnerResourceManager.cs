﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Core.Globalization
{
    public class InnerResourceManager
    {
    }
}