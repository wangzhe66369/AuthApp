﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace RWIS.Presentation.Web.Core.Api
{
    /// <summary>
    /// 请求参数
    /// </summary>
    public class RequestParames
    {
        /// <summary>
        /// 验证用户名
        /// </summary>
        public string ValidateUserCode { get; set; }
        /// <summary>
        /// 验证密码
        /// </summary>
        public string ValidatePwd { get; set; }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="validateCode">验证编码</param>
        /// <param name="validateKey">验证Key</param>
        public RequestParames(string validateCode, string validateKey)
        {
            byte[] bytes = Encoding.Default.GetBytes(string.Format("{0}:{1}", validateCode, validateKey));
            string base64Key = Convert.ToBase64String(bytes);
            Authorization = "Basic " + base64Key;
            Accept = "application/json";
            Method = "Get";
            ContentType = "application/x-www-form-urlencoded";
            AcceptCharset = "utf-8";
        }
        /// <summary>
        /// 请求格式
        /// </summary>
        public string Accept { get; set; }
        /// <summary>
        /// POST/GET
        /// </summary>
        public string Method { get; set; }

        /// <summary>
        /// 文档格式application/x-www-form-urlencoded
        /// </summary>
        public string ContentType { get; set; }
        /// <summary>
        /// 请求编码方式
        /// </summary>
        public string AcceptCharset { get; set; }
        /// <summary>
        /// 授权
        /// </summary>
        public string Authorization { get; set; }
    }
}