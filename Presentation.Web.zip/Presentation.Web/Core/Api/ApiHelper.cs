﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace RWIS.Presentation.Web.Core.Api
{
    /// <summary>
    /// ApiHelper
    /// </summary>
    public class ApiHelper
    {
        /// <summary>
        /// 请求的URL
        /// </summary>
        public string ActionUrl { get; set; }
        /// <summary>
        /// 参数
        /// </summary>
        public IDictionary<string, string> Parames { get; set; }

        /// <summary>
        /// 请求的参数
        /// </summary>
        public RequestParames RequestParames { get; set; }

        /// <summary>
        /// 默认的构造函数
        /// </summary>
        public ApiHelper()
        { }
        /// <summary>
        /// 构造函数
        /// </summary>
        public ApiHelper(string url)
        {
            ActionUrl = url;
        }
        /// <summary>
        /// 获取请求结果
        /// </summary>
        public T GetRequestResult<T>(IDictionary<string, string> parames)
        {
            Uri realUrl = CompositeUri(ActionUrl, parames);
            object result = RequestGetResult(realUrl);
            return (T)result;
        }
        /// <summary>
        /// 获取请求结果
        /// </summary>
        public T GetRequestResult<T>(string url, IDictionary<string, string> parames)
        {
            Parames = parames;
            Uri realUrl = CompositeUri(url, Parames);
            object result = RequestGetResult(realUrl);
            return (T)result;
        }

        /// <summary>
        /// 获取请求结果
        /// </summary>
        public T GetRequestResult<T>(string url, IDictionary<string, string> parames, RequestParames requestParames)
        {
            if (requestParames != null)
            {
                RequestParames = requestParames;
            }
            if (parames != null)
            {
                Parames = parames;
            }
            Uri realUrl = CompositeUri(url, Parames);
            object result = RequestGetResult(realUrl);
            return (T)result;
        }

        /// <summary>
        /// 组装Uri
        /// </summary>
        private Uri CompositeUri(string url, IDictionary<string, string> parames)
        {
            #region 组装URL
            if (parames != null && parames.Count > 0)
            {
                if (!url.EndsWith("/"))
                {
                    url = url + "/";
                }
                url = url + "?";
                foreach (var p in parames)
                {
                    url += string.Format("{0}={1}", p.Key, System.Web.HttpContext.Current.Server.UrlEncode(p.Value));
                    url += "&";
                }
                if (url.EndsWith("&"))
                {
                    url = url.Substring(0, url.Length - 1);
                }
            }
            #endregion

            Uri realUrl = new Uri(url);
            return realUrl;
        }

        /// <summary>
        /// 获取Get请求的结果
        /// </summary>
        private string RequestGetResult(Uri url)
        {
            string requestResult = string.Empty;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Accept = RequestParames.Accept;
                request.Headers.Add(HttpRequestHeader.Authorization, RequestParames.Authorization);
                request.Headers.Add(HttpRequestHeader.AcceptCharset, RequestParames.AcceptCharset);

                request.Method = RequestParames.Method;
                request.ContentType = RequestParames.ContentType;
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                using (Stream stream = response.GetResponseStream())
                {
                    using (StreamReader srd = new StreamReader(stream, Encoding.GetEncoding("gb2312")))
                    {
                        requestResult += srd.ReadToEnd();
                    }
                }
            }
            catch (Exception e)
            {
                requestResult += e.Message;
            }
            return requestResult;
        }
    }
}