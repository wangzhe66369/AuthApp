﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Core
{
    public static class TargetUrlHelper
    {
        /// <summary>
        /// 保存登录链接地址的TargetUrl的值
        /// </summary>
        public static void SaveTargetUrl(this Controller controller)
        {
            var targetUrl = controller.Request["targetUrl"];
            if (!string.IsNullOrEmpty(targetUrl))
            {
                controller.Session["TargetUrl"] = targetUrl;
            }
        }

        /// <summary>
        /// 是否存在TargetUrl
        /// </summary>
        public static bool IsExistsTargetUrl(this Controller controller)
        {
            var targetUrl = controller.Request["targetUrl"];
            if (!string.IsNullOrEmpty(targetUrl))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// 获取TargetUrl in Session
        /// </summary>
        public static string GetDecodeTargetUrlFromSession(this Controller controller)
        {
            var targetUrl = controller.Session["TargetUrl"];
            if (targetUrl != null)
            {
                return HttpUtility.UrlDecode(targetUrl.ToString());
            }
            return null;
        }

        /// <summary>
        /// 移出Session
        /// </summary>
        public static void RemoveTargetUrlFromSession(this Controller controller)
        {
            var targetUrl = controller.Session["TargetUrl"];
            if (targetUrl != null)
            {
                controller.Session.Remove("TargetUrl");
            }
        }

        /// <summary>
        /// URL编码
        /// </summary>
        public static string SetTargetUrlEncode(string url)
        {
            return HttpUtility.UrlEncode(url);
        }
    }
}