﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   RegisterCommonService.cs
 *   描    述   ：   注册应用程序公共的服务
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System.Configuration;
using System.Runtime.Caching;
using Microsoft.Practices.Unity;
using NET01.CoreFramework.Adapters;
using NET01.CoreFramework.Ftp;
using NET01.CoreFramework.Impl.Ftp;
using NET01.CoreFramework.Impl.Mail;
using NET01.CoreFramework.Mail;
using NET01.Infrastructure.Authorization;
using NET01.Infrastructure.ORG;
using NET01.Infrastructure.ORG.Data;

namespace RWIS.Presentation.Web.Core.DI
{
    /// <summary>
    /// 注册应用程序公共的服务
    /// </summary>
    public class RegisterCommonService
    {
        string connectionStringName;
        //string readonlyConnectionStringName ;
        string dbOwner;
        string databaseType;

        /// <summary>
        /// 创建RegisterCommonService实例
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <param name="dbOwner"></param>
        /// <param name="databaseType"></param>
        public RegisterCommonService(string connectionStringName, string dbOwner, string databaseType)
        {
            this.connectionStringName = connectionStringName;
            this.dbOwner = dbOwner;
            this.databaseType = databaseType;
        }
        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="container"></param>
        public void Load(UnityContainer container)
        {
            container.RegisterType<ITypeAdapter, TypeAdapter>();//DToAdapter
            container.RegisterInstance<ObjectCache>(MemoryCache.Default);//注册绶存
            container.RegisterType<ISmtpClient, SmtpClient>();//发布邮件
            container.RegisterType<IAuthorization, DefaultAuthorization>(new ContainerControlledLifetimeManager());////注册授权 单件

            RegisterFtpClient(container);// 注册FTP服务

            //组织机构
            container.RegisterType<IORGUnitOfWork, ORGUnitOfWork>(new InjectionConstructor(connectionStringName, dbOwner));
            container.RegisterType<IOrganizationRepository, OrganizationRepository>((new InjectionConstructor(
                new ResolvedParameter<IORGUnitOfWork>())));
        }
        /// <summary>
        /// 注册FTP服务
        /// </summary>
        /// <param name="container"></param>
        private void RegisterFtpClient(IUnityContainer container)
        {
            string FTPUser = ConfigurationManager.AppSettings["FtpUser"];
            string FTPPass = ConfigurationManager.AppSettings["FtpPass"];
            string FTPHost = ConfigurationManager.AppSettings["FtpHost"];
            string FTPPath = ConfigurationManager.AppSettings["FtpPath"];
            string FTPPort = ConfigurationManager.AppSettings["FtpPort"];

            //注册FTPClient
            container.RegisterType<IFtpClient, FtpClient>(new InjectionConstructor(FTPHost, FTPPort, FTPPath, FTPUser, FTPPass));
        }
    }
}