
/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   RegisterAppServiceGen.cs
 *   描    述   ：   
 *   创 建 者   ：   创建人 
 *   创建日期   ：   2016-04-12 03:00:58
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-04-12 03:00:58    1.0.0.0    创建人       初版　 
 *    
 *
 *   
 *******************************************************************************/
using Microsoft.Practices.Unity;
using RWIS.Domain.Repositories;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Infrastructure.Data.UnitOfWork;
namespace RWIS.Presentation.Web.Core.DI
{
	 /// <summary>
    /// 注册应用程序相关的服务，由代码生成器生成
    /// </summary>
    public class RegisterAppServiceGen
    {
		 /// <summary>
        /// 生成依赖注入信息
        /// <param name="container">容器</param>
        /// </summary>
        public void RegisterService(UnityContainer container)
		{
            //container.RegisterType<ITemployeeRepository, TemployeeRepository>(new InjectionConstructor(
            //    new ResolvedParameter<Net01UnitOfWork>()));
		}

	}
}

