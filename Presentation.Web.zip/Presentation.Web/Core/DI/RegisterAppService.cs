﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   GlobalSettingTask.cs
 *   描    述   ：   注册应用程序相关的服务
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using Microsoft.Practices.Unity;
using NET01.Presentation.Web.Mvc.Ioc;
using RWIS.Application.Implementation;
using RWIS.Application.Interface;
using RWIS.Domain.Repositories;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Infrastructure.Data.UnitOfWork;
using NET01.Infrastructure.ORG;
using OMP.Infrastructure.Data.Repositories;
using OMP.Domain.Repositories;



namespace RWIS.Presentation.Web.Core.DI
{
    /// <summary>
    /// 注册应用程序相关的服务
    /// </summary>
    public class RegisterAppService
    {
        #region 变量
        string connectionStringName;
        string readonlyConnectionStringName;
        string dbOwner;
        string databaseType;
        #endregion

        #region 构造函数
        /// <summary>
        ///  创建RegisterAppService实例
        /// </summary>
        /// <param name="connectionStringName"></param>
        /// <param name="readonlyConnectionStringName"></param>
        /// <param name="dbOwner"></param>
        /// <param name="databaseType"></param>
        public RegisterAppService(string connectionStringName, string readonlyConnectionStringName, string dbOwner, string databaseType)
        {
            this.connectionStringName = connectionStringName;
            this.readonlyConnectionStringName = readonlyConnectionStringName;
            this.dbOwner = dbOwner;
            this.databaseType = databaseType;
        }
        #endregion

        /// <summary>
        /// 加载
        /// </summary>
        /// <param name="container"></param>
        public void Load(UnityContainer container)
        {
            //注册工作流部分
            //**********************注册仓储部分*START**********************************
            //注册工作单元
            container.RegisterType<Net01UnitOfWork>(new HttpRequestLifetimeManager(),
            new InjectionConstructor(connectionStringName, databaseType, dbOwner));
            container.RegisterType<Net01UnitOfWork>("Readonly", new HttpRequestLifetimeManager(),
            new InjectionConstructor(readonlyConnectionStringName, databaseType, dbOwner));//用于读写分离

            container.RegisterType<IUserLoginInfoRepository, UserLoginInfoRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//登陆信息
            //container.RegisterType<IMaterialTestRepository, MaterialTestRepository>(new InjectionConstructor(
            //    new ResolvedParameter<Net01UnitOfWork>())); //材料信息
            container.RegisterType<ISupportDispiteLimitRepository, SupportDispiteLimitRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //处置场限制
            container.RegisterType<IMaterialBatchRepository, MaterialBatchRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //批次业务
            #region 基础数据

            container.RegisterType<ILogRepository, LogRepository>(new InjectionConstructor(
          new ResolvedParameter<Net01UnitOfWork>())); //日志信息

            container.RegisterType<IBasicObjectRepository, BasicObjectRepository>(new InjectionConstructor(
          new ResolvedParameter<Net01UnitOfWork>())); //常量信息

            container.RegisterType<IMaterialDetailRepository, MaterialDetailRepository>(new InjectionConstructor(
                new ResolvedParameter<Net01UnitOfWork>())); //材料明细

            container.RegisterType<IMaterialTypeRepository, MaterialTypeRepository>(new InjectionConstructor(
              new ResolvedParameter<Net01UnitOfWork>())); //材料类型

            container.RegisterType<IBasicIndustryRepository, BasicIndustryRepository>(new InjectionConstructor(
              new ResolvedParameter<Net01UnitOfWork>())); //行业代码

            container.RegisterType<IBasicWasteUnitRepository, BasicWasteUnitRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //废物产生单位

            #endregion 基础数据

            #region 材料管理

            container.RegisterType<IMaterialInputRepository, MaterialInputRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //材料入库

            container.RegisterType<IMaterialTransferRepository, MaterialTransferRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //材料转运

            container.RegisterType<IMaterialDrainRepository, MaterialDrainRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //材料消耗

            container.RegisterType<IMaterialCheckRepository, MaterialCheckRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //材料验收
            ///
            container.RegisterType<INuclearBucketRepository, NuclearBucketRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //桶信息

            container.RegisterType<INuclearBucketBarCodeRepository, NuclearBucketBarCodeRepository>(new InjectionConstructor(
           new ResolvedParameter<Net01UnitOfWork>())); //桶和条形码关联信息

            container.RegisterType<INuclearBucketChangeRepository, NuclearBucketChangeRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //桶的位置明细

            container.RegisterType<INuclearMStockRepository, NuclearMStockRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //材料库存信息
            ///
            container.RegisterType<ICementAcceptRepository, CementAcceptRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //材料验收>水泥桶现场验收检查记录

            container.RegisterType<ICementAcceptDetailRepository, CementAcceptDetailRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //材料验收>水泥桶现场验收检查记录

            container.RegisterType<IMetelAcceptRepository, MetelAcceptRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //材料验收>金属桶现场验收检查记录

            container.RegisterType<IMetelAcceptDetailRepository, MetelAcceptDetailRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //材料验收>金属桶现场验收检查记录

            container.RegisterType<ISolidAcceptDetailRepository, SolidAcceptDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //材料验收>固化材料验收检查记录

            container.RegisterType<ISolidAcceptRepository, SolidAcceptRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //材料验收>固化材料验收检查记录

            container.RegisterType<IOtherAcceptRepository, OtherAcceptRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //材料验收>其他材料检查记录

            #endregion 材料管理

            #region 技术支持

            container.RegisterType<INuclearElementRepository, NuclearElementRepository>(new InjectionConstructor(
                new ResolvedParameter<Net01UnitOfWork>())); //基础数据标准库，核素库
            container.RegisterType<IScalefactorRepository, ScalefactorRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //基础数据标准库，比例因子
            container.RegisterType<ISupportEdsRepository, SupportEdsRepository>(new InjectionConstructor(
              new ResolvedParameter<Net01UnitOfWork>())); //活度计算标准库
            container.RegisterType<ISupportEdsDetailRepository, SupportEdsDetailRepository>(new InjectionConstructor(
              new ResolvedParameter<Net01UnitOfWork>())); //标准谱库
            container.RegisterType<IEvalMethodRepository, EvalMethodRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //评估方法标准库
            container.RegisterType<ISupportSurfaceDealRepository, SupportSurfaceDealRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //近地表处置标准库
            container.RegisterType<ICementTransferRepository, CementTransferRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //评估方法标准库水泥桶转换函数
            container.RegisterType<IMetelTransferRepository, MetelTransferRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //评估方法标准库金属桶转换函数

            container.RegisterType<ISupportSurfaceDealRepository, SupportSurfaceDealRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //近地表处置规定

            container.RegisterType<IEquipInfoRepository, EquipInfoRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物管理-设备信息-设备维护
            container.RegisterType<IEquipDetailRepository, EquipDetailRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物管理-设备信息-设备状态

            #endregion 技术支持

            #region 源项跟踪单

            container.RegisterType<ITrackLiquorRepository, TrackLiquorRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-浓缩液列表
            container.RegisterType<INuclearTrackResinRepository, NuclearTrackResinRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-废树脂列表
            container.RegisterType<INuclearTrackElementRepository, NuclearTrackElementRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-废滤芯列表
            container.RegisterType<INuclearTrackDepositRepository, NuclearTrackDepositRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-淤积物列表
            container.RegisterType<INuclearTrackSolventRepository, NuclearTrackSolventRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-废油和溶剂
            container.RegisterType<INuclearTrackFilterRepository, NuclearTrackFilterRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-通风过滤器列表
            container.RegisterType<INuclearTrackTechBRepository, NuclearTrackTechBRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-技术废物(>2mSv/h)
            container.RegisterType<INuclearTrackTechSRepository, NuclearTrackTechSRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-技术废物(<2mSv/h)
            container.RegisterType<INuclearTrackTechSDraftRepository, NuclearTrackTechSDraftRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-技术废物备份(<2mSv/h)
            container.RegisterType<INuclearTrackSundryRepository, NuclearTrackSundryRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-杂项
            container.RegisterType<INuclearTrackDeconRepository, NuclearTrackDeconRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //废物跟踪单-去污申请单      

            container.RegisterType<INuclearNuclideRepository, NuclearNuclideRepository>(new InjectionConstructor(
               new ResolvedParameter<Net01UnitOfWork>())); //核素分析单
            container.RegisterType<INuclearNuclideSampleRepository, NuclearNuclideSampleRepository>(new InjectionConstructor(
              new ResolvedParameter<Net01UnitOfWork>())); //核素分析单样品信息
            container.RegisterType<INuclearSampleDetailRepository, NuclearSampleDetailRepository>(new InjectionConstructor(
              new ResolvedParameter<Net01UnitOfWork>())); //核素分析单样品明细信息

            #endregion 源项跟踪单


            #region 公共信息

            container.RegisterType<INuclearRubTransDetailRepository, NuclearRubTransDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //废物运输
            container.RegisterType<INuclearRubTransRepository, NuclearRubTransRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //废物运输

            container.RegisterType<IDataManageRepository, DataManageRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //资料管理
            container.RegisterType<INonComformanceRepository, NonComformanceRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //不符合项管理

            container.RegisterType<IDispsiteSpotCheckRepository, DispsiteSpotCheckRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //抽检管理
            container.RegisterType<IDispsiteSpotDetailRepository, DispsiteSpotDetailRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //抽检管理明细

            #endregion 公共信息

            #region"废物处理"

            container.RegisterType<INuclearBucketCheckRepository, NuclearBucketCheckRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //桶检查
            container.RegisterType<INuclearBucketSolutionRepository, NuclearBucketSolutionRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //浓缩液装桶固化400l金属桶
            container.RegisterType<INuclearBucketSolidifyDetailRepository, NuclearBucketSolidifyDetailRepository>(new InjectionConstructor(
           new ResolvedParameter<Net01UnitOfWork>())); //浓缩液装桶固化400l金属桶明细
            container.RegisterType<INuclearBucketResinRepository, NuclearBucketResinRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //废树脂装桶固化400l金属桶
            container.RegisterType<INuclearBucketRSolidifyRepository, NuclearBucketRSolidifyRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //干湿料制备及废树脂装桶固化
            container.RegisterType<INuclearBucketSSolidifyRepository, NuclearBucketSSolidifyRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //干湿料制备及浓缩液装桶固化
            container.RegisterType<INuclearGiftDetailRepository, NuclearGiftDetailRepository>(new InjectionConstructor(
         new ResolvedParameter<Net01UnitOfWork>())); //固化明细
            container.RegisterType<INuclearCoverMetalRepository, NuclearCoverMetalRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //湿混料制备及400L金属桶装桶封盖
            container.RegisterType<INuclearCoverMixRepository, NuclearCoverMixRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //湿混料制备及封盖
            container.RegisterType<INuclearFixationRepository, NuclearFixationRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //湿混料制备及废滤芯、技术废物固定
            container.RegisterType<INuclearFixationDetailRepository, NuclearFixationDetailRepository>(new InjectionConstructor(
           new ResolvedParameter<Net01UnitOfWork>())); //湿混料制备及废滤芯、技术废物固定明细

            container.RegisterType<INuclearSolidifyDetailRepository, NuclearSolidifyDetailRepository>(new InjectionConstructor(
        new ResolvedParameter<Net01UnitOfWork>())); //封盖明细
            #endregion

            #region"暂存管理"

            container.RegisterType<INuclearQtTransRepository, NuclearQtTransRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));//废物货包转运及QT贮存移动单
            container.RegisterType<INuclearQtTransDetailRepository, NuclearQtTransDetailRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));//废物货包转运及QT贮存明细移动单
            container.RegisterType<INuclearQtTransDetailBRepository, NuclearQtTransDetailBRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));//废物货包转运及QT贮存明细移动单
            container.RegisterType<INuclearFcTransRepository, NuclearFcTransRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));//厂房间废物桶转运
            container.RegisterType<INuclearTsGoodsInRepository, NuclearTsGoodsInRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));// QT厂房废物货包入库记录
            container.RegisterType<INuclearTsGoodsOutRepository, NuclearTsGoodsOutRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));//QT厂房废物货包出库记录
            container.RegisterType<INuclearTsEbPrepareRepository, NuclearTsEbPrepareRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));//空桶准备记录
            container.RegisterType<INuclearTsEbPrepareDetailRepository, NuclearTsEbPrepareDetailRepository>(new InjectionConstructor(
          new ResolvedParameter<Net01UnitOfWork>()));//空桶准备明细记录
            container.RegisterType<INuclearTsEbTransRepository, NuclearTsEbTransRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));//空桶运输记录
            container.RegisterType<INuclearTsEbOverRepository, NuclearTsEbOverRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));//水泥桶封盖记录
            container.RegisterType<INuclearTsRbTransRepository, NuclearTsRbTransRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//源项废物运输记录
            container.RegisterType<INuclearTsGoodsRepository, NuclearTsGoodsRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//货包检查
            container.RegisterType<INuclearTsStockRepository, NuclearTsStockRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//盘点管理
            container.RegisterType<INuclearProcessApplyRepository, NuclearProcessApplyRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//处置管理
            container.RegisterType<INuclearTempstockRepository, NuclearTempstockRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//库存信息

            #endregion
            container.RegisterType<IQtTranTicketRepository, QtTranTicketRepository>(new InjectionConstructor(
           new ResolvedParameter<Net01UnitOfWork>())); 

            container.RegisterType<INuclearTsEbPrepareRepository, NuclearTsEbPrepareRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); 
            container.RegisterType<INuclearWasteClearRepository, NuclearWasteClearRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //其他工艺-
            container.RegisterType<INuclearWasteDegradeRepository, NuclearWasteDegradeRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //其他工艺-
            container.RegisterType<INuclearWasteDismantleRepository, NuclearWasteDismantleRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //其他工艺-
            container.RegisterType<INuclearWasteFireRepository, NuclearWasteFireRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //其他工艺-
            container.RegisterType<INuclearWasteHDisposeRepository, NuclearWasteHDisposeRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //其他工艺-
            container.RegisterType<INuclearWasteLDisposeRepository, NuclearWasteLDisposeRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //其他工艺-
            container.RegisterType<INuclearWastePackageRepository, NuclearWastePackageRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //其他工艺-
            container.RegisterType<INuclearWasteSmeltRepository, NuclearWasteSmeltRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //其他工艺-
            container.RegisterType<INuclearSpecialPackageRepository, NuclearSpecialPackageRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //其他工艺-
            container.RegisterType<INuclearWasteOtherTechnologyRepository, NuclearWasteOtherTechnologyRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //其他工艺-
            container.RegisterType<IDispsiteCheckRepository, DispsiteCheckRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//废物货包审核
            container.RegisterType<IDispsiteCheckDetailRepository, DispsiteCheckDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//废物货包审核
            container.RegisterType<INuclearApplyDetailRepository, NuclearApplyDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//
            container.RegisterType<IDispsiteApproveRepository, DispsiteApproveRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//废物货包审批
            container.RegisterType<INuclearApproveDetailRepository, NuclearApproveDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//废物货包审批明细
            container.RegisterType<IDispsiteEvalDetailRepository, DispsiteEvalDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<INuclearOtherTrackRepository, NuclearOtherTrackRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IContainerBarRepository, ContainerBarRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));//条形码

            #region 活度计算
            container.RegisterType<IActivityBucketRepository, ActivityBucketRepository>(new InjectionConstructor(
                 new ResolvedParameter<Net01UnitOfWork>()));//200L废物桶活度计算G
            container.RegisterType<IActivityBucketDetailRepository, ActivityBucketDetailRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //200L废物桶活度计算G明细

            container.RegisterType<IActivityCountViewRepository, ActivityCountViewRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //活度计算查询

            container.RegisterType<INuclearSampleDetailRepository, NuclearSampleDetailRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>())); //样品分析表
            
            container.RegisterType<IActivityCementliquidRepository, ActivityCementliquidRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));
            container.RegisterType<IActivityCliquidDetailRepository, ActivityCliquidDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));  

            container.RegisterType<IActivityCfilterRepository, ActivityCfilterRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));
            container.RegisterType<IActivityCfilterDetailRepository, ActivityCfilterDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IActivityCoreRepository, ActivityCoreRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));
            container.RegisterType<IActivityCoreDetailRepository, ActivityCoreDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IActivityCresinRepository, ActivityCresinRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));
            container.RegisterType<IActivityCresinDetailRepository, ActivityCresinDetailRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IActivityDmeasureRepository, ActivityDmeasureRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));
            container.RegisterType<IActivityDmeasureDetailRepository, ActivityDmeasureDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IActivityHandleValueRepository, ActivityHandleValueRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IActivityHlevelRepository, ActivityHlevelRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));
            container.RegisterType<IActivityHlevelDetailRepository, ActivityHlevelDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IActivityMfilterRepository, ActivityMfilterRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));
            container.RegisterType<IActivityMfilterDetailRepository, ActivityMfilterDetailRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IActivityMliquidRepository, ActivityMliquidRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));
            container.RegisterType<IActivityMliquidDetailRepository, ActivityMliquidDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IActivityMresinRepository, ActivityMresinRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));
            container.RegisterType<IActivityMresinDetailRepository, ActivityMresinDetailRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IActivityOpBucketRepository, ActivityOpBucketRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));
            container.RegisterType<IActivityOpBucketDetailRepository, ActivityOpBucketDetailRepository>(new InjectionConstructor(
             new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IActivityOpBuckethandleRepository, ActivityOpBuckethandleRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));

            container.RegisterType<IIntegratedQueryViewRepository, IntegratedQueryViewRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>()));
            #endregion

            #region"废物处置"
            container.RegisterType<IDispsiteEvalRepository, DispsiteEvalRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //放射性特性评估验算
            container.RegisterType<IDispiteEvalDetailRepository, DispiteEvalDetailRepository>(new InjectionConstructor(
           new ResolvedParameter<Net01UnitOfWork>())); //放射性特性评估明细验算
            container.RegisterType<INuclearRubReceptionRepository, NuclearRubReceptionRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //废物接收
            container.RegisterType<INuclearRubReceptionDRepository, NuclearRubReceptionDRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //废物接收明细
            container.RegisterType<INuclearRubLocationRepository, NuclearRubLocationRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //废物处置定位
            container.RegisterType<INuclearRubConsRepository, NuclearRubConsRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //废物处置施工
            container.RegisterType<INuclearRubFileRepository, NuclearRubFileRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //生成档案
            container.RegisterType<IDispiteConfirmRepository, DispiteConfirmRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //质量确认
            container.RegisterType<IDispiteConfirmDetailRepository, DispiteConfirmDetailRepository>(new InjectionConstructor(
            new ResolvedParameter<Net01UnitOfWork>())); //质量确认明细
            #endregion

            //注册读写分离相关仓储

            //**********************注册仓储部分*END**********************************

            //*************************注册服务层的服务*START******************************

            container.RegisterType<IOrgStaffAppService, OrgStaffAppService>(new InjectionConstructor(
                new ResolvedParameter<IOrganizationRepository>()));//机构应用服务

            //*************************注册服务层的服务*END******************************

            //注入工具生成的服务
            new RegisterAppServiceGen().RegisterService(container);

        }
    }
}
