﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   CommonControllerBase.cs
 *   描    述   ：   Controller基类
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *  
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using RWIS.Infrastructure.Crosscutting;
using NET01.CoreFramework.Logging;
using NET01.CoreFramework;


namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// Controller基类
    /// </summary>
    public class CommonControllerBase : Controller
    {

        private ApplicationUser currentUser;//当前登录用户

          //日志记录器
        private static ILogger log = LoggerFactory.CreateLog();
        /// <summary>
        /// 当前用户
        /// </summary>
        public ApplicationUser CurrentUser
        {
            get
            {
                if (currentUser == null)
                {
                    currentUser = AppContext.CurrentUser;
                }
                return currentUser;
            }
        }

        /// <summary>
        /// 获取日志记录器。通过返回的实现记录日志。
        /// </summary>
        public ILogger Log
        {
            get
            {
                return log;
            }
        }

        #region 脚本输出
        /// <summary>
        /// 注册脚本块（注册后将会在页面上输出脚本块，主要用于在页面上执行脚本）
        /// 注意：需要与Shared/_Layout.cshtml模板相结合.
        /// </summary>
        public void RegisterScriptBlock(string script)
        {
            this.TempData["ScriptBlock"] = script;
        }

        /// <summary>
        /// 注册提示信息，用于在页面输入提示信息,如保存成功后给出提示.
        /// </summary>
        /// <param name="script"></param>
        public void RegisterAlertMessage(string message)
        {
            RegisterScriptBlock(String.Format("alert('{0}');",message));
        }
        #endregion

        /// <summary>
        /// 获取模型验证错误信息
        /// </summary>
        /// <returns></returns>
        public string GetModelValidateErrorMessage()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var kvp in ModelState)
            {
                if (kvp.Value.Errors.Count > 0)
                {
                    sb.Append("key:" + kvp.Key);
                    sb.Append("Errors:");
                    foreach (var err in kvp.Value.Errors)
                    {
                        sb.Append(err.ErrorMessage + ";");
                    }
                }
            }
            return sb.ToString();
        }
    }
}