﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   WebViewPage.cs
 *   描    述   ：   WebViewPage基类
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Presentation.Web.Core;
using RWIS.Infrastructure.Crosscutting;
using NET01.CoreFramework;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// WebViewPage基类
    /// </summary>
    /// <typeparam name="TModel"></typeparam>
    public abstract class WebViewPage<TModel> :NET01.Presentation.Web.Mvc.WebViewPage<TModel>
    {
        private ApplicationUser currentUser;
        /// <summary>
        /// 站点相关信息
        /// </summary>
        public ApplicationUser CurrentUser 
        {
            get
            {
                if (currentUser == null)
                {
                    currentUser =AppContext.CurrentUser;           
                }
                return currentUser;
            }          
        }
        public WebViewPage()
            : base()
        {
        }

    }
}