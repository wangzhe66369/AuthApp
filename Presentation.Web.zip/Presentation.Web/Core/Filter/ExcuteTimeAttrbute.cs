﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Diagnostics;

namespace RWIS.Presentation.Web.Core.Filter
{
    public class ExcuteTimeAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filterContext"></param>
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //请求时间开始
            GetTimer(filterContext, "action").Start();
            base.OnActionExecuting(filterContext);
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            //请求时间结束
            GetTimer(filterContext, "action").Stop();
            base.OnActionExecuted(filterContext);
        }

        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            GetTimer(filterContext, "render").Start();
            base.OnResultExecuting(filterContext);
        }

        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            var renderTimer = GetTimer(filterContext, "render");
            renderTimer.Stop();

            var actionTimer = GetTimer(filterContext, "action");
            //if (actionTimer.ElapsedMilliseconds>=100||renderTimer.ElapsedMilliseconds>=100)
            {
                //string area=string.Empty;
                // string controller=string.Empty;
                // string action=string.Empty;
                //if (filterContext.RouteData.Values.Keys.Contains("area"))
                //{
                //    area=filterContext.RouteData.Values["area"].ToString();
                //}
                //if (filterContext.RouteData.Values.Keys.Contains("controller"))
                //{
                //    controller = filterContext.RouteData.Values["controller"].ToString();
                //}
                //if (filterContext.RouteData.Values.Keys.Contains("action"))
                //{
                //    action = filterContext.RouteData.Values["action"].ToString();
                //}
                //记录日志
                string str = string.Format("监控：{0},执行{1}ms,渲染{2}ms",
                    filterContext.HttpContext.Request.RawUrl,
                    actionTimer.ElapsedMilliseconds, renderTimer.ElapsedMilliseconds);
                CIT.UBA.StatServices.StatService statServer = new CIT.UBA.StatServices.StatService();
                statServer.SaveLog(CIT.UBA.StatServices.OperateType.Button, "system", str);
            }

            base.OnResultExecuted(filterContext);
        }

        private Stopwatch GetTimer(ControllerContext Context, string name)
        {
            string key = "_timer_" + name;
            if (Context.HttpContext.Items.Contains(key))
            {
                return (Stopwatch)Context.HttpContext.Items[key];
            }
            var result = new Stopwatch();
            Context.HttpContext.Items[key] = result;
            return result;
        }

    }
}