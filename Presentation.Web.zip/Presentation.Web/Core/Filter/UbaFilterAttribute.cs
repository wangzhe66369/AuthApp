﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   UbaFilterAttribute.cs
 *   描    述   ：   用户行为分析过滤器
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2013-05-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2013-05-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CIT.UBA.StatServices;
using RWIS.Infrastructure.Crosscutting;
using NET01.CoreFramework;


namespace RWIS.Presentation.Web.Core.Filter
{
    [AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
    public class UbaFilterAttribute : ActionFilterAttribute
    {
        #region 变量
        private string _userId;
        private string _onOff;
        #endregion

        #region 属性
        /// <summary>
        /// 用户员工号
        /// </summary>
        public string UserId
        {
            get
            {
                if (string.IsNullOrEmpty(_userId))
                {
                    if (AppContext.CurrentUser == null)
                    {
                        return string.Empty;
                    }
                    return AppContext.CurrentUser.UserId;
                }
                return this._userId;
            }
            set { _userId = value; }
        }

        /// <summary>
        /// 控制开关 on 开 off 关
        /// </summary>
        public string OnOff
        {
            get
            {
                if (string.IsNullOrEmpty(_onOff))
                {
                    return System.Configuration.ConfigurationManager.AppSettings["UBAOnOff"];
                }
                return this._onOff;
            }
            set { _onOff = value; }
        }

        /// <summary>
        /// 操作类型
        /// </summary>
        public OperateType OperateType { get; set; }

        /// <summary>
        /// 操作描述
        /// </summary>
        public string OperateDescription { get; set; }

        #endregion

        #region 方法

        /// <summary>
        /// 返回结果后执行
        /// </summary>
        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            base.OnResultExecuted(filterContext);

            if (string.IsNullOrEmpty(UserId) || OnOff.ToLower().Equals("off"))
            {
                return;
            }
            try
            {
                StatService statServer = new StatService();
                statServer.SaveLog(OperateType, UserId, OperateDescription);
            }
            catch
            {
            }
        }
        #endregion
    }
}