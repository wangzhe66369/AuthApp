﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   AuthorizationValidateAttribute.cs
 *   描    述   ：   授权验证
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using RWIS.Infrastructure.Crosscutting;
using NET01.Infrastructure.Authorization;
using Microsoft.Practices.ServiceLocation;
using NET01.CoreFramework;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// 授权验证
    /// </summary>
     [AttributeUsage(AttributeTargets.All, AllowMultiple = false)]
    public class AuthorizationValidateAttribute:ActionFilterAttribute
    {
        #region 属性
        /// <summary>
         /// 资源编码
         /// </summary>
         public string ResourceCode{ get; set; }
         /// <summary>
         /// 操作编码
         /// </summary>
         public string OperationCode{get; set;}
        #endregion

         /// <summary>
         /// OnActionExecuting
         /// </summary>
         /// <param name="filterContext"></param>
         public override void OnActionExecuting(ActionExecutingContext filterContext)
         {
             bool hasAccess = false;
             ApplicationUser loginUser = AppContext.CurrentUser;

             //*********************集成工程授权系统*START**********************************
             #region 集成工程授权系统
             IAuthorization auth = ServiceLocator.Current.GetInstance<IAuthorization>();
             if (loginUser != null)
             {
                 if (String.IsNullOrEmpty(this.OperationCode))
                 {
                     hasAccess = auth.CheckAccessResource(this.ResourceCode, loginUser.UserId, loginUser.ProjectCode);
                 }
                 else
                 {
                     List<string> acs = auth.GetAccessControls(loginUser.UserId, loginUser.ProjectCode, this.ResourceCode);
                     hasAccess = acs.Where(ac => ac == this.OperationCode).Count() > 0;
                 }
             }
             #endregion
             //*********************集成工程授权系统*EBD**********************************

             if(!hasAccess)
             {
                 filterContext.Result = new RedirectResult("~/Error/DenyAccess");
             }
      
             //*********************集成UPC授权系统*EBD**********************************
             base.OnActionExecuting(filterContext);
                
            
         }
    }

}