﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   HandleErrorAttribute.cs
 *   描    述   ：   UI异常处理
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.IO;
using NET01.CoreFramework.Logging;
using NET01.CoreFramework.Mail;
using System.Configuration;
using Microsoft.Practices.ServiceLocation;
using NET01.CoreFramework;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// UI异常处理
    /// </summary>
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, Inherited = true, AllowMultiple = true)]
    public class HandleErrorAttribute : ActionFilterAttribute, IExceptionFilter
    {
        /// <summary>
        /// 异常处理
        /// </summary>
        /// <param name="context"></param>
        public void OnException(ExceptionContext context)
        {
            //记录日志
            ILogger log = LoggerFactory.CreateLog();
            log.LogError(context.Exception);

            //记录UBA错误日志
            string userId = string.Empty;
            if (AppContext.CurrentUser != null)
            {
                userId = AppContext.CurrentUser.UserId;
            }
            StatService statServer = new StatService();
            statServer.SaveErrorLog(context.Exception, userId);

            //发送邮件通知管理员
            SendErrorMail(context.Exception);

            context.HttpContext.Response.RedirectToRoute(new RedirectToRouteResult(
            new RouteValueDictionary {
                    {"controller", "Error"}, {"action", "General"}

            }));
            context.HttpContext.Response.Redirect("~/error/General");

        }

        /// <summary>
        /// 发送错误消息邮件
        /// </summary>
        /// <param name="ex">错误消息</param>
        private void SendErrorMail(Exception ex)
        {
            try
            {
                string linkStaffNO = ConfigurationManager.AppSettings["linkStaffNO"];
                string userId = string.Empty;

                if (AppContext.CurrentUser != null)
                {
                    userId = AppContext.CurrentUser.UserId;
                }

                if (!string.IsNullOrEmpty(linkStaffNO))
                {
                    MailMessage msg = new MailMessage();
                    msg.Subject = "IMS系统错误信息提醒";
                    msg.To = linkStaffNO;
                    msg.Body = string.Format("系统编号：{0}<br/>"
                        + "异常类型：{1}<br/>"
                        + "异常时间：{2}<br/>"
                        + "站点主机：{3}<br/>"
                        + "操作人：{4}<br/>"
                        + "异常提示：{5}<br/>"
                        + "异常内容：{6}<br/>",
                        ConfigurationManager.AppSettings["SysCode"],
                        ex.GetType().FullName,
                        DateTime.Now.ToString(),
                        HttpContext.Current.Server.MachineName,
                        userId,
                        ex.Message,
                        ex.ToString()
                        );
                    ISmtpClient smtpClient = ServiceLocator.Current.GetInstance<ISmtpClient>();
                    smtpClient.Send(msg);
                }
            }
            catch (Exception e)
            {
                try
                {
                    //记录日志
                    ILogger log = LoggerFactory.CreateLog();
                    log.LogError(e);
                }
                catch
                {
                    //日志记录再次出错，则不处理异常
                }
            }
        }

    }
}
