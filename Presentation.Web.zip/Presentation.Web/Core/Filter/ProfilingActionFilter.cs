﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   LoginRequiredAttribute.cs
 *   描    述   ：   登录验证
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CIT.App.Lib.SSO.SSOClient;
using RWIS.Infrastructure.Crosscutting;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core.Login;
using StackExchange.Profiling;
using NET01.Infrastructure.Profiler;
using NET01.Infrastructure.Profiler.Configuration;

namespace RWIS.Presentation.Web.Core
{

    [AttributeUsage(AttributeTargets.All, AllowMultiple = false)]
    public class ProfilingActionFilter : ActionFilterAttribute
    {
        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            if (MiniProfiler.Current != null && AppProfilerConfig.Section.ProfilerOnOff.ToLower() == "on")
            {
                //如果请求相应时间大于配置时间，则记录性能分析结果
                if (MiniProfiler.Current.DurationMilliseconds >= AppProfilerConfig.Section.FilterMinDuration)
                {
                    NET01.Infrastructure.Profiler.AppProfiler.SaveMiniProfiler(
                        MiniProfiler.Current, 
                        AppSetting.Instance.SystemCode, 
                        AppContext.CurrentUser == null ? string.Empty : AppContext.CurrentUser.UserId
                        );

                    base.OnResultExecuted(filterContext);
                }
            }
        }

    }

}