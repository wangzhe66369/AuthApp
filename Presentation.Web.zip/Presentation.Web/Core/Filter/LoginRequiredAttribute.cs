﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   LoginRequiredAttribute.cs
 *   描    述   ：   登录验证
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CIT.App.Lib.SSO.SSOClient;
using RWIS.Infrastructure.Crosscutting;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core.Login;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// 登录验证
    /// </summary>
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false)]
    public class LoginRequiredAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {

            if (AppContext.CurrentUser == null)
            {
                System.Web.HttpContext.Current.Session["TargetUrl"] = filterContext.HttpContext.Request.RawUrl;
                try
                {
                    if (AppSetting.Instance.LoginMode == "SSO")//SSO
                    {
                        string userId = string.Empty;
                        IClient ssoClient = new AppClient();
                        if (ssoClient.Login(out userId))
                        {
                            LoginInfo.SaveLoginInfo(userId);
                        }
                    }
                    else if (AppSetting.Instance.LoginMode == "Domain")
                    {
                        string userId = string.Empty;
                        userId = LoginInfo.GetDomainUser();
                        if (LoginInfo.SaveLoginInfo(userId))
                        {
                            if (AppContext.CurrentUser == null || AppContext.CurrentUser.UserId == "")
                            {
                                HttpContext.Current.Response.Redirect("~/Home/Login", true);
                            }
                            else
                            {
                                HttpContext.Current.Response.Redirect("~/Home/Index", true);
                            }
                        }
                        else
                        {
                            HttpContext.Current.Response.Redirect("~/Home/Login", true);
                        }
                    }
                    else
                    {
                        HttpContext.Current.Response.Redirect("~/Home/LogOut", true);
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.InnerException);
                    HttpContext.Current.Response.Redirect("~/Home/LogOut", true);
                }
            }
            else
            {
                base.OnActionExecuting(filterContext);
            }
        }
    }

}