﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CIT.App.Lib.Uwf.Model;
using CIT.App.Lib.Uwf.Client.Factory;
using NET01.Infrastructure.Workflow.PSC.PSCService;
using NET01.CoreFramework;
using RWIS.Presentation.Web.ViewModels.PscViewModels;
using CIT.App.Lib.Uwf.Client.Configs;
using RWIS.Presentation.Web.ViewModelBuilder.PscVMBuilder;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Core.Flow
{
    public class FlowProcess
    {

        /// <summary>
        /// 发起流程
        /// </summary>
        /// <param name="formUuid">表单唯一编号</param>
        /// <param name="instanceName">实例名称</param>
        /// <param name="summary">流程摘要</param>
        /// <param name="fullName">流程全名</param>
        /// <param name="targetActId">目标节点编号</param>
        /// <param name="nextUsers">下一步处理人</param>
        /// <param name="copyUsers">抄送人</param>
        /// <param name="isNewForm">是否为新建表单</param>
        /// <param name="common">提交意见</param>
        /// <returns></returns>
        public string StartWorkflow(string formUuid, string instanceName, string summary, string fullName, string targetActId, List<UWFUser> nextUsers, List<UWFUser> copyUsers, bool isNewForm, string common = "")
        {

            ProcsetCfg ProcsetInfo = ServiceFactory.Instance.WorkflowConfig.GetProcSetByFullName(fullName);
            //获取指定环节配置信息
            var targetAct = ServiceFactory.Instance.WorkflowConfig.GetActByProcIdAndActId(ProcsetInfo.ProcVerId.ToString(), targetActId);
            string instanceid = UWFCommon.StartWorkflowInstance(formUuid, fullName, nextUsers, copyUsers, targetAct.ActId.ToString(), instanceName, summary, common);

            return instanceid;
        }


        /// <summary>
        /// 提交流程
        /// </summary>
        /// <param name="targetActId">目标节点编号</param>
        /// <param name="sn">工作编号</param>
        /// <param name="procInstId">流程实例编号</param>
        /// <param name="actId">当前节点编号</param>
        /// <param name="nextUsers">下一步处理人</param>
        /// <param name="copyUsers">抄送人</param>
        /// <param name="summary">提交意见</param>
        public void SubmitWorkflow(string instanceName, string fullName, string targetActId, string sn, string procInstId, string actId, List<UWFUser> nextUsers, List<UWFUser> copyUsers, string summary = "")
        {
            if (string.IsNullOrEmpty(targetActId))
            {
                throw new ArgumentNullException("targetActId");
            }
            if (string.IsNullOrEmpty(sn))
            {
                throw new ArgumentNullException("sn");
            }
            if (string.IsNullOrEmpty(procInstId))
            {
                throw new ArgumentNullException("procInstId");
            }
            if (string.IsNullOrEmpty(actId))
            {
                throw new ArgumentNullException("actId");
            }

            ProcsetCfg ProcsetInfo = ServiceFactory.Instance.WorkflowConfig.GetProcSetByFullName(fullName);
            //获取指定环节配置信息
            var targetAct = ServiceFactory.Instance.WorkflowConfig.GetActByProcIdAndActId(ProcsetInfo.ProcVerId.ToString(), targetActId);

            UWFUser currentUser = new UWFUser();
            currentUser.UserId = AppContext.CurrentUser.UserId;
            currentUser.UserName = AppContext.CurrentUser.UserName;
            currentUser.DeptID = AppContext.CurrentUser.DeptNo;

            UWFCommon.SubmitWorkflowInstance(currentUser, fullName, targetAct.ActId, nextUsers, copyUsers, instanceName, sn, procInstId, summary, actId);

        }

    }
}