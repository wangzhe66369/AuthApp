﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.ViewModels.PscViewModels;
using CIT.App.Lib.Uwf.Model;

namespace RWIS.Presentation.Web.Core.Flow
{
    public class FlowVM
    {
        #region PSC工作流
        /// <summary>
        /// 环节ID
        /// </summary>
        public string CurrentActId { get; set; }

        /// <summary>
        /// 当前环节名称
        /// </summary>
        public string ActName { get; set; }

        /// <summary>
        /// 当前环节值
        /// </summary>
        public string ActMeta { get; set; }

        /// <summary>
        /// 流程ID
        /// </summary>
        public string InstanceId { get; set; }
        /// <summary>
        /// Uuid
        /// </summary>
        public string Uuid { get; set; }
        /// <summary>
        /// 流程NAME
        /// </summary>
        public string InstanceName { get; set; }
        /// <summary>
        /// 流程类型
        /// </summary>
        public string FlowType { get; set; }
        /// <summary>
        /// 流程状态
        /// </summary>
        public string FlowState { get; set; }

        /// <summary>
        /// 流程全名
        /// </summary>
        public string FullName { get; set; }

        /// <summary>
        /// SN
        /// </summary>
        public string SN { get; set; }

        /// <summary>
        /// 当前运行版本
        /// </summary>
        public int ProcVerId { get; set; }

        ///<summary>
        /// 处理实例ID
        /// </summary>
        public string ProcInstId { get; set; }

        /// <summary>
        /// 流程集实体信息
        /// </summary>
        public ProcsetCfg ProcsetInfo { get; set; }
        /// <summary>
        /// 处理信息
        /// </summary>
        public DealWithVM DealWithInfo { get; set; }

        /// <summary>
        /// 流程日志信息
        /// </summary>
        public WorkflowLogVM WorkflowLogInfo { get; set; }

        /// <summary>
        /// 操作类型列表
        /// </summary>
        public List<ActRoute> ActRouteList { get; set; }

        /// <summary>
        /// 目标节点编号
        /// </summary>
        public string TargetActId { get; set; }

        /// <summary>
        /// 审批操作类型
        /// </summary>
        public AuditType AuditOperateType { get; set; }

        #endregion

        /// <summary>
        /// 意见
        /// </summary>
        public string Comment { get; set; }

        /// <summary>
        /// 业务表单编号
        /// </summary>
        public string FormId { get; set; }

        /// <summary>
        /// 是否支持快捷审批
        /// </summary>
        public string IsFastApprove { get; set; }

        /// <summary>
        /// 是否可以重选审批人
        /// </summary>
        public string IsRepickUser { get; set; }
    }

    /// <summary>
    /// 审批操作类型
    /// </summary>
    public enum AuditType
    {
        /// <summary>
        /// 提交
        /// </summary>
        Submit,

        /// <summary>
        /// 同意  
        /// </summary>
        Agree,

        /// <summary>
        /// 退回
        /// </summary>
        Reject,

        /// <summary>
        /// 结束流程
        /// </summary>
        End,

        /// <summary>
        /// 作废流程
        /// </summary>
        Delete
    }

}