﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   RegisterRouteTask.cs
 *   描    述   ：   注册路由
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Routing;
using NET01.CoreFramework.Startup;
using System.Configuration;

namespace RWIS.Presentation.Web.Core.Startup
{
    public class RegisterRouteTask : IStartupTask
    {
        /// <summary>
        /// 运行
        /// </summary>
        public void Run()
        {
            AreaRegistration.RegisterAllAreas();
            RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterRoutes(RouteTable.Routes);

        }
        /// <summary>
        /// RegisterGlobalFilters
        /// </summary>
        /// <param name="filters"></param>
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            bool isDebug = false;
            Boolean.TryParse(ConfigurationManager.AppSettings["DebugEnabled"], out isDebug);
            if (!isDebug)
            {
                //添加错误处理过滤器
                filters.Add(new HandleErrorAttribute());
            }

            //添加性能监控过滤器
            filters.Add(new ProfilingActionFilter());
        }
        /// <summary>
        /// RegisterRoutes
        /// </summary>
        /// <param name="routes"></param>
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("elmah.axd");
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.IgnoreRoute("*Views/Home/WebForm1.aspx*");


            //自定义的分页路由，示例项目中的“自定义路由分页”示例中用
            routes.MapRoute("Paging", "{controller}/{action}/{page}/{id}",
                            new
                            {
                                controller = "Activity",
                                action = "Index",
                                id = UrlParameter.Optional
                            });

            routes.MapRoute(
                "Default", // 路由名称
                "{controller}/{action}/{id}", // 带有参数的 URL
                new { controller = "Home", action = "Index", id = UrlParameter.Optional }, // 参数默认值
                 new string[] { "RWIS.Presentation.Web.Controllers" }
            );

        }
    }
}
