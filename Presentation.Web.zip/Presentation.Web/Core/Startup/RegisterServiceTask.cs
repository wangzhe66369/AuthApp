﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   RegisterServices.cs
 *   描    述   ：   注册服务，在应用程序启动时执行
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

#region 引用
using System.Configuration;
using Microsoft.Practices.ServiceLocation;
using Microsoft.Practices.Unity;
using NET01.CoreFramework.Startup;
using NET01.Presentation.Web.Mvc.Ioc;
using RWIS.Presentation.Web.Core.DI;
#endregion

namespace RWIS.Presentation.Web.Core.Startup
{
    /// <summary>
    /// 注册服务，在应用程序启动时执行
    /// </summary>
    public class RegisterServiceTask : IStartupTask
    {
        private UnityContainer container = null;
        public RegisterServiceTask(UnityContainer container)
            : base()
        {
            this.container = container;
        }

        public void Run()
        {
            string connectionStringName = "ConnectionString";
            string readonlyConnectionStringName = "ReadonlyConnectionString";
            string dbOwner = ConfigurationManager.AppSettings["DbOwner"].Trim('.');
            string databaseType = ConfigurationManager.AppSettings["DatabaseType"];

            //注册公共服务
            new RegisterCommonService(connectionStringName, dbOwner, databaseType).Load(container);

            //注册当前项目相关
            new RegisterAppService(connectionStringName, readonlyConnectionStringName, dbOwner, databaseType).Load(container);

            //注册基础数据
            new RWIS.Presentation.Web.Core.DI.RegisterCommonService(connectionStringName,
                                                                    dbOwner,
                                                                    databaseType).Load(container);

            new CIT.UPC.Presentation.Web.Core.DI.RegisterAuthModuleService(connectionStringName,
                                                                    connectionStringName,
                                                                    dbOwner,
                                                                    databaseType).Load(container);


        }



    }
}