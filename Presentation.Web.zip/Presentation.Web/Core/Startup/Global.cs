﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   MvcApplication.cs
 *   描    述   ：   应用程序启动
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2013-09-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2013-09-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Linq;
using NET01.CoreFramework.Startup;
using System;
using RWIS.Presentation.Web.Core.Globalization;
using Microsoft.Practices.Unity;
using Microsoft.Practices.ServiceLocation;
using StackExchange.Profiling;
using NET01.Infrastructure.Profiler;
using NET01.Infrastructure.Profiler.Configuration;

namespace RWIS.Presentation.Web.Core.Startup
{
    /// <summary>
    /// 应用程序启动
    /// </summary>
    public class MvcApplication : HttpApplication
    {

        /// <summary>
        /// 启动
        /// </summary>
        protected void Application_Start()
        {
            UnityContainer container = new UnityContainer();
            //ControllerBuilder.Current.SetControllerFactory
            Bootstrapper bootstrapper = new Bootstrapper();
            //注册路由
            bootstrapper.Register(new RegisterRouteTask());
            //注册全局公共项
            bootstrapper.Register(new GlobalSettingTask());
            //注册依赖注入
            bootstrapper.Register(new RegisterServiceTask(container));
            bootstrapper.Run();

            //注册ServiceLocator提供程序
            ServiceLocator.SetLocatorProvider(() => { return new UnityServiceLocator(container); });//设置服务

            //往MVC中注册解释的容器(这是MVC框架实现注入所需要的)
            System.Web.Mvc.DependencyResolver.SetResolver(new NET01.Presentation.Web.Mvc.Ioc.DependencyResolver((IUnityContainer)container));

            if (AppProfilerConfig.Section.ProfilerOnOff.ToLower() == "on")
            {
                MiniProfilerEF.Initialize();
                NET01.Infrastructure.Profiler.AppProfiler.Start();
            }
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            GlobalizationManager.SetCurrentCulture();
            if (AppProfilerConfig.Section.ProfilerOnOff.ToLower() == "on")
            {
                MiniProfiler.Start();
            }
        }

        protected void Application_EndRequest()
        {
            if (AppProfilerConfig.Section.ProfilerOnOff.ToLower() == "on")
            {
                MiniProfiler.Stop();
            }
        }
    }
}
