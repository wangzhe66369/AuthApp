﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   GlobalSettingTask.cs
 *   描    述   ：   全层配置启动任务
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NET01.CoreFramework.Startup;
using NET01.CoreFramework.Logging;
using NNET01.CoreFramework.Impl.Logging;
using NET01.CoreFramework.SessionState;
using NET01.CoreFramework.Impl.SessionState;
using NET01.CoreFramework;
using System.Configuration;
using CIT.UPC.Authorization.Client;
//using CIT.UPC.Authorization.Client;

namespace RWIS.Presentation.Web.Core.Startup
{
    /// <summary>
    /// 全层配置启动任务
    /// </summary>
    public class GlobalSettingTask : IStartupTask
    {
        /// <summary>
        /// 运行
        /// </summary>
        public void Run()
        {
            //注册日志记录
            LoggerFactory.SetCurrent(new EnterpriseLibraryLogFactory());

            //注册会话后端存储
            IBackingStore sessionBackingStore = new BackingStore();
            AppContext.SetSessionBackingStore(sessionBackingStore);

            //注册UPC授权服务
            DefaultAuthorizationFactory factory = new DefaultAuthorizationFactory(
                ConfigurationManager.ConnectionStrings["UpcConnectionString"].ConnectionString,
                ConfigurationManager.AppSettings["OracleType"],
                ConfigurationManager.AppSettings["UpcDbOwner"].TrimEnd('.'),
                ConfigurationManager.AppSettings["SysCode"]);
            AuthorizationFactory.SetCurrent(factory);
        }
    }
}