﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   CheckBoxValidationAttribute.cs
 *   描    述   ：   CheckBoxList验证描述
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2013-07-08 10:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2013-07-08 10:00:00    1.0.0.0     框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Core.Validation
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = true, Inherited = false)]
    public class CheckBoxValidationAttribute : ValidationAttribute, IClientValidatable
    {
        private const string ErrFormat = " 请最少选择 {0} 项,最多选择 {1} 项";

        public int MinSelected { get; set; }
        public int MaxSelected { get; set; }

        public override bool IsValid(object value)
        {
            return true;
        }

        public override string FormatErrorMessage(string name)
        {
            return string.Format(ErrFormat, MinSelected > 0 ? MinSelected.ToString(CultureInfo.InvariantCulture) : "不限", MaxSelected > 0 ? MaxSelected.ToString(CultureInfo.InvariantCulture) : "不限");
        }


        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            var rule = new ModelClientValidationRule
            {
                ValidationType = "chklist",
                ErrorMessage = FormatErrorMessage(metadata.GetDisplayName())
            };
            rule.ValidationParameters["min"] = MinSelected;
            rule.ValidationParameters["max"] = MaxSelected;

            yield return rule;

        }
    }
}