﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   JsonResultHelper.cs
 *   描    述   ：   JsonResult帮助类
 *   创 建 者   ：   设计人员 
 *   创建日期   ：   2016-05-31 
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-05-31           1.0.0.0      设计人员       初版　 
 *    
 *
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;

using RWIS.Domain.DomainObjects;
namespace RWIS.Presentation.Web.Core.Common
{
    public class JsonResultHelper
    {

        /// <summary>
        /// 返回Json结果
        /// </summary>
        /// <param name="result">处理结果</param>
        /// <param name="msg">提示消息</param>
        public static JsonResult JsonResult(bool result, string msg)
        {
            var objects = new Dictionary<string, object> { { "result", result }, { "msg", msg } };
            return JsonResult(objects, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 返回Json结果
        /// </summary>
        /// <param name="result">处理结果</param>
        /// <param name="msg">提示消息</param>
        /// <param name="jsonRequestBehavior">请求Json的行为</param>
        public static JsonResult JsonResult(bool result, string msg, JsonRequestBehavior jsonRequestBehavior)
        {
            var objects = new Dictionary<string, object> { { "result", result }, { "msg", msg } };
            return JsonResult(objects, jsonRequestBehavior);
        }

        /// <summary>
        /// 返回Json结果
        /// </summary>
        /// <param name="result">返回结果</param>
        /// <param name="msg">提醒信息</param>
        /// <param name="objects">其他参数</param>
        public static JsonResult JsonResult(bool result, string msg, Dictionary<string, object> objects)
        {
            if (objects != null)
            {
                if (!objects.ContainsKey("result"))
                {
                    objects.Add("result", result);
                }
                if (!objects.ContainsKey("msg"))
                {
                    objects.Add("msg", msg);
                }
            }
            return JsonResult(objects, JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        /// 返回Json结果
        /// </summary>
        /// <param name="result">返回结果</param>
        /// <param name="msg">提醒信息</param>
        /// <param name="objects">其他参数</param>
        /// <param name="jsonRequestBehavior">Json请求行为</param>
        public static JsonResult JsonResult(bool result, string msg, Dictionary<string, object> objects, JsonRequestBehavior jsonRequestBehavior)
        {
            if (objects != null)
            {
                if (!objects.ContainsKey("result"))
                {
                    objects.Add("result", result);
                }
                if (!objects.ContainsKey("msg"))
                {
                    objects.Add("msg", msg);
                }
            }
            return JsonResult(objects, jsonRequestBehavior);
        }


        /// <summary>
        /// 返回Json结果
        /// </summary>
        /// <param name="result">处理结果</param>
        /// <param name="opretionType">操作类型</param>
        public static JsonResult JsonResult(bool result, OpretionType opretionType)
        {
            return JsonResult(result, opretionType, null);
        }
        /// <summary>
        /// 返回Json结果
        /// </summary>
        /// <param name="result">处理结果</param>
        /// <param name="opretionType">操作类型</param>
        /// <param name="objects">附加信息</param>
        public static JsonResult JsonResult(bool result, OpretionType opretionType, Dictionary<string, object> objects)
        {
            string template = string.Format("{0}{1}", opretionType.GetDescription(), result ? "成功" : "失败");
            if (objects != null)
            {
                if (!objects.ContainsKey("result"))
                {
                    objects.Add("result", result);
                }
                if (!objects.ContainsKey("msg"))
                {
                    objects.Add("msg", template);
                }
            }
            return JsonResult(objects, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 返回Json结果
        /// </summary>
        /// <param name="result">处理结果</param>
        /// <param name="opretionType">操作类型</param>
        /// <param name="annexMsg">附加提示</param>
        /// <param name="objects">附加信息</param>
        public static JsonResult JsonResult(bool result, OpretionType opretionType, string annexMsg, Dictionary<string, object> objects)
        {
            string template = string.Format("{0}{1}{2}", opretionType.GetDescription(), result ? "成功" : "失败", annexMsg);
            if (objects != null)
            {
                if (!objects.ContainsKey("result"))
                {
                    objects.Add("result", result);
                }
                if (!objects.ContainsKey("msg"))
                {
                    objects.Add("msg", template);
                }
            }
            return JsonResult(objects, JsonRequestBehavior.AllowGet);
        }


        #region 私有方法
        /// <summary>
        /// 返回JsonResult
        /// </summary>
        private static JsonResult JsonResult(Dictionary<string, object> objects, JsonRequestBehavior jsonRequestBehavior)
        {
            var r = new JsonResult
            {
                Data = objects,
                JsonRequestBehavior = jsonRequestBehavior
            };
            return r;
        }

        #endregion

        /// <summary>
        /// 操作枚举
        /// </summary>
        public enum OpretionType
        {
            [Description("保存")]
            Save,
            [Description("新增")]
            Add,
            [Description("更新")]
            Update,
            [Description("删除")]
            Delete,
            [Description("提交")]
            Submit,
            [Description("导入")]
            Import,
            [Description("导出")]
            Export
        }
    }
}