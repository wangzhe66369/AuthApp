﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Collections;
using System.Configuration;
using System.Reflection;

using NPOI.HSSF.UserModel;
using NPOI.HSSF.Util;
using NPOI.SS.UserModel;
using NPOI.HPSF;
using NPOI.XSSF.UserModel;

namespace RWIS.Presentation.Web.Core.Common
{
    public class ImportExportHelper
    {
        #region 将文件输出到页面
        /// <summary>
        /// 将文件输出到页面
        /// </summary>
        /// <param name="page"></param>
        /// <param name="fileStream">文件流</param>
        /// <param name="saveFileName">用户默认保存名称</param>
        public static void Export<T>(MemoryStream stream)
        {
            var classProperty = ImportExportHelper.GetSheetNameAttribute(typeof(T));

            string saveFileName = string.Format("{0}_{1}.xls", "错误信息", DateTime.Now.ToString("yyyy-MM-dd"));
            string encodefileName = ToHexString(saveFileName);

            System.Web.HttpContext context = System.Web.HttpContext.Current;
            if (context.Request.Browser.Browser.Contains("IE"))
            {
                string ext = encodefileName.Substring(encodefileName.LastIndexOf('.'));//得到扩展名
                string name = encodefileName.Remove(encodefileName.Length - ext.Length);//得到文件名称
                name = name.Replace(".", "%2e");
                saveFileName = name + ext;
            }
            else
            {
                saveFileName = encodefileName;
            }

            context.Response.Clear();
            context.Response.AddHeader("content-disposition", String.Format("attachment;filename={0}", saveFileName));
            stream.WriteTo(context.Response.OutputStream);
            stream.Flush();
            stream.Dispose();
            context.Response.OutputStream.Dispose();
            context.Response.End();
        }
        #endregion

        #region 将文件输出到页面
        /// <summary>
        /// 将文件输出到页面
        /// </summary>
        /// <param name="page"></param>
        /// <param name="fileStream">文件流</param>
        /// <param name="saveFileName">用户默认保存名称</param>
        public static void SaveFile<T>(FileStream stream)
        {
            var classProperty = ImportExportHelper.GetSheetNameAttribute(typeof(T));

            string saveFileName = string.Format("{0}_{1}.xls", classProperty.SheetName, DateTime.Now.ToString("yyyy-MM-dd"));
            string encodefileName = ToHexString(saveFileName);

            System.Web.HttpContext context = System.Web.HttpContext.Current;
            if (context.Request.Browser.Browser.Contains("IE"))
            {
                string ext = encodefileName.Substring(encodefileName.LastIndexOf('.'));//得到扩展名
                string name = encodefileName.Remove(encodefileName.Length - ext.Length);//得到文件名称
                name = name.Replace(".", "%2e");
                saveFileName = name + ext;
            }
            else
            {
                saveFileName = encodefileName;
            }

            //字节数组
            int size = 600;
            byte[] buffer = new byte[size];
            for (var i = 0; i < size; i++)
            {
                //byte类型的数最大不能超过255，用256取模实现
                buffer[i] = (byte)(i % 256);
            }
            stream.Write(buffer, 0, buffer.GetLength(0));
            stream.Close();

        }
        #endregion

        #region 生成Sheet页
        /// <summary>
        /// 生成Sheet页
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list">IList数据源</param>
        /// <param name="workbook">HSSFWorkbook</param>
        /// <param name="sheet">HSSFSheet</param>
        public static void FillSheet<T>(IList<T> list, HSSFWorkbook workbook, HSSFSheet sheet)
        {
            DataTable dataTable = ImportExportHelper.GetExportData<T>(list);
            if (dataTable != null)
            {
                var rowIndex = 0;
                var cellIndex = 0;
                var headerRow = sheet.CreateRow(rowIndex);
                var headerFont = workbook.CreateFont();
                var headerCellStyle = workbook.CreateCellStyle();

                #region EXCEL表格样式设置

                // 标题字体。
                //headerFont.FontName = "Arial";
                //headerFont.FontHeightInPoints = (short)13;
                //headerFont.Boldweight = (short)700;
                //headerFont.Color = HSSFColor.White.Index;

                //// 标题样式。
                //headerCellStyle.WrapText = false;
                //headerCellStyle.SetFont(headerFont);

                //// 设置标题单元格样式：纯色填充时FillForegroundColor值必须
                //// 和FillBackgroundColor值一致，且必须FillPattern设置为非NO_FILL。
                //headerCellStyle.FillPattern = FillPattern.LessDots;
                //headerCellStyle.FillForegroundColor = HSSFColor.SkyBlue.Index;
                //headerCellStyle.FillBackgroundColor = HSSFColor.SkyBlue.Index;

                //// 设置单元格的水平对齐、垂直对齐方式。
                //headerCellStyle.Alignment = HorizontalAlignment.Center;
                //headerCellStyle.VerticalAlignment = VerticalAlignment.Center;

                #endregion

                #region 添加标题
                ICell cell = null;
                foreach (DataColumn column in dataTable.Columns)
                {
                    cell = headerRow.CreateCell(cellIndex, CellType.String);
                    cellIndex++;
                    cell.SetCellValue(column.ColumnName);
                    sheet.AutoSizeColumn(cellIndex);
                    cell.CellStyle = headerCellStyle;
                }

                headerRow.Height = (short)500;
                rowIndex++;
                #endregion

                #region 填充数据
                foreach (DataRow dataRow in dataTable.Rows)
                {
                    cellIndex = 0;
                    var row = sheet.CreateRow(rowIndex);
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        cell = row.CreateCell(cellIndex, CellType.String);
                        cellIndex++;
                        cell.SetCellValue(Convert.ToString(dataRow[column]));
                    }

                    rowIndex++;
                    //if (rowIndex > 40000)
                    //{
                    //    break;
                    //}
                }
                #endregion

                //设置列的自动宽度。
                //for (var index = 0; index < dataTable.Columns.Count; index++)
                //{
                //    sheet.AutoSizeColumn(index);
                //}

                // 冻结首行。
                //sheet.CreateFreezePane(0, 1);
            }
        }


        /// <summary>
        /// 生成Sheet页
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list">数据源</param>
        /// <param name="strFileName">文件名</param>
        public static void FillSheet<T>(IList<T> list, string strFileName)
        {
            DataTable dataTable = ImportExportHelper.GetExportData<T>(list);
            if (dataTable != null)
            {
                HttpResponse resp = HttpContext.Current.Response;
                resp.Clear();
                strFileName = HttpUtility.UrlEncode(strFileName, System.Text.Encoding.UTF8);
                resp.AddHeader("content-disposition", string.Format("attachment;filename={0}.xls", strFileName));
                resp.Charset = "GB2312";
                resp.ContentEncoding = System.Text.Encoding.GetEncoding("GB2312");
                resp.ContentType = "application/ms-excel";

                StringBuilder strHeader = new StringBuilder();
                foreach (DataColumn column in dataTable.Columns)
                {
                    strHeader.Append(column.ColumnName.Trim() + "\t");
                }
                resp.Write(strHeader.ToString() + "\n");

                StringBuilder strTmp = new StringBuilder();
                string tem;

                int i = 0;
                foreach (DataRow dataRow in dataTable.Rows)
                {
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        tem = dataRow[column].ToString().Trim().Replace("\r\n", "");
                        tem = tem.Replace("\n", "");
                        tem = tem.Replace("\t", "");
                        tem = tem.Replace("\r", "");
                        strTmp.Append(tem + "\t");
                    }
                    strTmp = strTmp.Append("\n");

                    i++;
                }

                dataTable.Clear();
                dataTable = null;
                list.Clear();
                list = null;


                resp.Write(strTmp.ToString());
                resp.Flush();
                resp.End();
            }
        }

        /// <summary>
        /// 写入Excel文件
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list">数据源</param>
        /// <param name="strFileName">文件名</param>
        public static void WriteExcelFile<T>(IList<T> list, string strFileName)
        {
            string filePath = HttpContext.Current.Server.MapPath("~/Temp/");
            filePath = HttpContext.Current.Server.MapPath(filePath);
            strFileName += ".xls";

            IList<ExportOption> options = GetExportOptions(typeof(T));
            var classProperty = GetSheetNameAttribute(typeof(T));

            StringBuilder strHeader = new StringBuilder();
            foreach (ExportOption option in options)
            {
                strHeader.Append(option.DisplayName + "\t");
            }

            StringBuilder strTmp = new StringBuilder();
            string tem = string.Empty;
            //int i = 0;
            object obj = null;
            using (StreamWriter stream = new StreamWriter(filePath + strFileName, false, Encoding.Unicode))
            {
                stream.WriteLine(strHeader.ToString());

                foreach (var source in list)
                {
                    foreach (var option in options)
                    {

                        obj = source.GetType().GetProperty(option.PropertyName).GetValue(source, null);
                        if (obj != null)
                        {
                            tem = obj.ToString();
                            tem = tem.Replace("\r\n", "");
                            tem = tem.Replace("\n", "");
                            tem = tem.Replace("\t", "");
                            tem = tem.Replace("\r", "");
                            strTmp.Append(tem);
                        }
                        strTmp.Append("\t");
                    }

                    stream.WriteLine(strTmp.ToString());
                    strTmp.Clear();
                }
                list.Clear();
                list = null;

                stream.Flush();
                stream.Close();
            }

            //return strFileName;
        }

        #region 下载导出附件
        /// <summary>
        /// 下载导出附件
        /// </summary>
        /// <param name="suggestId"></param>
        public static void DownExcelFile(string fileName)
        {
            string filePath = HttpContext.Current.Server.MapPath("~/Temp/");
            filePath = HttpContext.Current.Server.MapPath(filePath);
            fileName = HttpUtility.UrlDecode(fileName) + ".xls";
            HttpResponse resp = HttpContext.Current.Response;
            FileInfo fileInfo = new FileInfo(filePath + fileName);
            resp.Clear();
            resp.AddHeader("Content-Disposition", "attachment; filename=" + HttpUtility.UrlEncode(fileName, System.Text.Encoding.UTF8));
            resp.AddHeader("Content-Length", fileInfo.Length.ToString());
            resp.ContentType = "application/octet-stream";
            resp.WriteFile(fileInfo.FullName);
            resp.End();
            resp.Flush();
            resp.Clear();

            fileInfo.Delete();
        }

        /// <summary>
        /// 文件删除
        /// </summary>
        /// <param name="fileName"></param>
        public static void DeleteExcelFile(string fileName)
        {
            string filePath = HttpContext.Current.Server.MapPath("~/Temp/");
            filePath = HttpContext.Current.Server.MapPath(filePath);
            fileName = HttpUtility.UrlDecode(fileName) + ".xls";
            if (File.Exists(filePath + fileName))
            {
                FileInfo fileInfo = new FileInfo(filePath + fileName);
                fileInfo.Delete();
            }
        }
        #endregion

        public static void FillSheet<T>(DataTable dataTable, IList<T> list, HSSFWorkbook workbook, HSSFSheet sheet)
        {
            if (dataTable != null)
            {
                var rowIndex = 0;
                var cellIndex = 0;
                var headerRow = sheet.CreateRow(rowIndex);
                var headerFont = workbook.CreateFont();
                var headerCellStyle = workbook.CreateCellStyle();

                #region EXCEL表格样式设置

                // 标题字体。
                headerFont.FontName = "Arial";
                headerFont.FontHeightInPoints = (short)13;
                headerFont.Boldweight = (short)700;
                headerFont.Color = HSSFColor.White.Index;

                // 标题样式。
                headerCellStyle.WrapText = true;
                headerCellStyle.SetFont(headerFont);

                // 设置标题单元格样式：纯色填充时FillForegroundColor值必须
                // 和FillBackgroundColor值一致，且必须FillPattern设置为非NO_FILL。
                headerCellStyle.FillPattern = FillPattern.LessDots;
                headerCellStyle.FillForegroundColor = HSSFColor.SkyBlue.Index;
                headerCellStyle.FillBackgroundColor = HSSFColor.SkyBlue.Index;

                // 设置单元格的水平对齐、垂直对齐方式。
                headerCellStyle.Alignment = HorizontalAlignment.Center;
                headerCellStyle.VerticalAlignment = VerticalAlignment.Center;

                #endregion

                #region 添加标题
                foreach (DataColumn column in dataTable.Columns)
                {
                    if (column.ColumnName.ToUpper().Contains("_FK"))
                    {
                        continue;
                    }

                    var cell = headerRow.CreateCell(cellIndex, CellType.String);
                    cellIndex++;
                    cell.SetCellValue(column.ColumnName);
                    sheet.AutoSizeColumn(cellIndex);
                    cell.CellStyle = headerCellStyle;
                }

                headerRow.Height = (short)500;
                rowIndex++;
                #endregion

                #region 填充数据
                foreach (DataRow dataRow in dataTable.Rows)
                {
                    cellIndex = 0;
                    var row = sheet.CreateRow(rowIndex);
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        var cell = row.CreateCell(cellIndex, CellType.String);
                        cellIndex++;
                        cell.SetCellValue(Convert.ToString(dataRow[column]));
                    }

                    rowIndex++;
                }
                #endregion

                // 设置列的自动宽度。
                for (var index = 0; index < dataTable.Columns.Count; index++)
                {
                    sheet.AutoSizeColumn(index);
                }

                // 冻结首行。
                //sheet.CreateFreezePane(0, 1);
            }
        }
        #endregion

        #region 将Excel文件数据解析成DataSet对象
        /// 将Excel文件数据解析成DataSet对象
        /// </summary>
        /// <param name="strPath">Excel文件路径</param>
        /// <returns>DataSet对象</returns>
        public static DataSet ExcelToData(string strPath)
        {
            return ExcelToData(strPath, false);
        }
        #endregion

        #region 将Excel文件数据解析成DataSet对象
        /// <summary>
        /// 将Excel文件数据解析成DataSet对象
        /// </summary>
        /// <param name="strPath">Excel文件路径</param>
        /// <param name="isSingleColumn">是否为单列，从第一行开始(没有列头)</param>
        /// <returns>DataSet对象</returns>
        public static DataSet ExcelToData(string strPath, bool isSingleColumn)
        {
            var result = new DataSet();
            string rowErrorMsg = string.Empty;
            using (FileStream fs = System.IO.File.OpenRead(string.Format(@"{0}", strPath)))
            {
                IWorkbook workbook = NPOI.SS.UserModel.WorkbookFactory.Create(fs);
                //HSSFWorkbook workbook = new HSSFWorkbook(fs);
                // var properties = GetExportOptions(typeof(T)).Where(p => p.IsExportIgnore == false).ToList();

                var sheetCount = workbook.NumberOfSheets;
                // var sheetCount = 1;
                string cellStr = string.Empty;
                var rowIndex = 0;
                var sheetName = string.Empty;
                ISheet sheet = null;
                IRow headerRow = null;
                IRow row = null;
                DataTable dataTable = null;
                DataRow dtRow = null;
                int cellCount = 0;
                int columnIndex = 0;

                for (int i = 0; i < sheetCount; i++)
                {
                    rowIndex = 0;
                    sheetName = workbook.GetSheetName(i);
                    sheet = workbook.GetSheet(sheetName);
                    headerRow = sheet.GetRow(rowIndex++);

                    dataTable = new DataTable(sheetName);

                    if (headerRow == null)
                    {
                        break;
                    }

                    // 取得数据列信息。
                    cellCount = headerRow.Cells.Count;

                    //如果为单列
                    if (isSingleColumn)
                    {
                        dataTable.Columns.Add("row1");
                        cellCount = 1;
                        rowIndex = 0;
                    }
                    else
                    {
                        for (int j = 0; j < cellCount; j++)
                        {
                            cellStr = headerRow.Cells[j].StringCellValue;
                            dataTable.Columns.Add(cellStr);
                        }
                    }
                    row = sheet.GetRow(rowIndex);
                    //获取当前Sheet的所有数据。
                    while (row != null)
                    {
                        dtRow = dataTable.NewRow();
                        for (int k = 0; k < cellCount; k++)
                        {
                            if (row.Cells.Count <= k)
                            {
                                break;
                            }
                            columnIndex = row.Cells[k].ColumnIndex;
                            dtRow[columnIndex] = row.Cells[k].ToString();
                        }
                        rowIndex++;

                        dataTable.Rows.Add(dtRow);
                        row = sheet.GetRow(rowIndex);
                    }
                    result.Tables.Add(dataTable);
                }
            }
            return result;
        }
        #endregion

        #region 获取需要导出的数据
        /// <summary>
        /// 获取需要导出的数据
        /// </summary>
        /// <typeparam name="T">数据类型</typeparam>
        /// <param name="sources">表头字段</param>
        /// <param name="options">表名</param>
        /// <returns>数据表对象</returns>
        public static DataTable GetExportData<T>(IList<T> sources, IList<ExportOption> options = null)
        {
            DataTable dt = new DataTable();
            options = options ?? GetExportOptions(typeof(T));
            var classProperty = GetSheetNameAttribute(typeof(T));

            foreach (ExportOption option in options)
            {
                dt.Columns.Add(option.DisplayName);
            }
           // dt.TableName = classProperty.SheetName;
            dt.TableName = "错误信息";
            if (sources != null && sources.Count > 0)
            {
                DataRow dataRow = null;
                object obj = null;
                foreach (var source in sources)
                {
                    dataRow = dt.NewRow();
                    foreach (var option in options)
                    {
                        if (!option.IsExportIgnore && source != null)
                        {
                            obj = source.GetType().GetProperty(option.PropertyName).GetValue(source, null);
                            if (obj != null)
                            {
                                dataRow[option.DisplayName] = obj.ToString();
                            }
                        }
                    }
                    dt.Rows.Add(dataRow);
                }
                sources.Clear();
                sources = null;
            }
            return dt;

            //DataTable dt = new DataTable();
            //var sheetName = GetSheetNameAttribute(typeof(T)).SheetName;
            //var columnName = GetColumnNameAttribute(typeof(T)).ColumnName;

            //string[] arrColumnNames = columnName.Split(',');
            //foreach (string columnNames in arrColumnNames)
            //{
            //    dt.Columns.Add(columnNames);
            //}
            //dt.TableName = sheetName;

            //if (sources != null && sources.Count > 0)
            //{
            //    foreach (var source in sources)
            //    {
            //        var dataRow = dt.NewRow();
            //        foreach (var strColumnName in arrColumnNames)
            //        {
            //            object obj = source.GetType().GetProperty(strColumnName).GetValue(source, null);
            //            if (obj != null)
            //            {
            //                dataRow[strColumnName] = obj.ToString();
            //            }
            //        }
            //        dt.Rows.Add(dataRow);
            //    }
            //}

            //return dt;
        }
        #endregion

        #region 获取数据类型的默认导入导出选项
        /// <summary>
        /// 获取数据类型的默认导入导出选项
        /// </summary>
        /// <typeparam name="T">数据类型</typeparam>
        /// <returns>导入导出选项集合</returns>
        public static IList<ExportOption> GetExportOptions(Type type)
        {
            var result = new List<ExportOption>();
            var properties = type.GetProperties();

            if (properties != null && properties.Length > 0)
            {
                foreach (var property in properties)
                {
                    if (!(property.PropertyType.IsValueType || property.PropertyType == typeof(string)))
                    {
                        continue;
                    }

                    var order = int.MinValue;
                    var isExportIgnore = false;
                    var displayName = property.Name;
                    var formatString = string.Empty;
                    var isAllowNull = true;
                    var attrs = property.GetCustomAttributes(typeof(ExportAttribute), true);

                    if (attrs != null && attrs.Length > 0)
                    {
                        var attr = attrs[0] as ExportAttribute;
                        if (!attr.IsExportVisible)
                        {
                            continue;
                        }

                        order = attr.Order;
                        formatString = attr.FormatString;
                        isExportIgnore = attr.IsExportIgnore;
                        isAllowNull = attr.IsAllowNull;

                        if (!string.IsNullOrWhiteSpace(attr.DisplayName))
                        {
                            displayName = attr.DisplayName;
                        }
                    }
                    else
                    {
                        continue;
                    }
                    result.Add(new ExportOption()
                    {
                        Order = order,
                        DisplayName = displayName,
                        FormatString = formatString,
                        PropertyName = property.Name,
                        IsExportIgnore = isExportIgnore,
                        IsAllowNull = isAllowNull
                    });
                }
            }
            return result.OrderBy(e => e.Order).ToList();
        }
        #endregion

        #region 获取class的特性值

        /// <summary>
        /// 获取sheet名称
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static SheetNameAttribute GetSheetNameAttribute(Type type)
        {
            return type.GetCustomAttributes(typeof(SheetNameAttribute), false).FirstOrDefault() as SheetNameAttribute;
        }

        /// <summary>
        /// 获取表头名称
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static ColumnNameAttribute GetColumnNameAttribute(Type type)
        {
            return type.GetCustomAttributes(typeof(ColumnNameAttribute), false).FirstOrDefault() as ColumnNameAttribute;
        }

        #endregion

        #region 文件名乱码处理
        /// <summary>
        /// 为字符串中的非英文字符编码Encodes non-US-ASCII characters in a string.
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static string ToHexString(string s)
        {
            char[] chars = s.ToCharArray();
            StringBuilder builder = new StringBuilder();
            for (int index = 0; index < chars.Length; index++)
            {
                bool needToEncode = NeedToEncode(chars[index]);
                if (needToEncode)
                {
                    string encodedString = ToHexString(chars[index]);
                    builder.Append(encodedString);
                }
                else
                {
                    builder.Append(chars[index]);
                }
            }
            return builder.ToString();
        }
        /// <summary>
        ///指定一个字符是否应该被编码 Determines if the character needs to be encoded.
        /// </summary>
        /// <param name="chr"></param>
        /// <returns></returns>
        public static bool NeedToEncode(char chr)
        {
            string reservedChars = "$-_.+!*'(),@=&";
            if (chr > 127)
                return true;
            if (char.IsLetterOrDigit(chr) || reservedChars.IndexOf(chr) >= 0)
                return false;
            return true;
        }
        /// <summary>
        /// 为非英文字符串编码Encodes a non-US-ASCII character.
        /// </summary>
        /// <param name="chr"></param>
        /// <returns></returns>
        static string ToHexString(char chr)
        {
            UTF8Encoding utf8 = new UTF8Encoding();
            byte[] encodedBytes = utf8.GetBytes(chr.ToString());
            StringBuilder builder = new StringBuilder();
            for (int index = 0; index < encodedBytes.Length; index++)
            {
                builder.AppendFormat("%{0}", Convert.ToString(encodedBytes[index], 16));
            }
            return builder.ToString();
        }
        #endregion 文件名乱码处理

        #region 获取类的所有属性名称
        /// <summary>
        /// 获取类的所有属性名称
        /// </summary>
        /// <typeparam name="T">类</typeparam>
        /// <param name="t"></param>
        /// <returns></returns>
        public static string getProperties<T>(T t)
        {
            string strProperties = string.Empty;
            if (t == null)
            {
                return strProperties;
            }
            PropertyInfo[] properties = t.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);

            if (properties.Length <= 0)
            {
                return strProperties;
            }
            foreach (PropertyInfo item in properties)
            {
                strProperties += string.Format("{0},", item.Name);
            }
            return strProperties.TrimEnd(',');
        }
        #endregion
    }

    /// <summary>
    /// 新增Class导入导出特性
    /// </summary>
    [Serializable]
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public class SheetNameAttribute : Attribute
    {
        #region 构造方法
        /// <summary>
        /// 构造方法。
        /// </summary>
        /// <param name="tableName">数据库表名</param>
        public SheetNameAttribute(string sheetName)
        {
            this.SheetName = sheetName;
        }
        #endregion

        #region 属性

        /// <summary>
        /// 获取或者设置Sheet名称。
        /// </summary>
        public string SheetName { get; set; }

        #endregion
    }

    [Serializable]
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public class ColumnNameAttribute : Attribute
    {
        #region 构造方法
        /// <summary>
        /// 构造方法。
        /// </summary>
        /// <param name="tableName">数据库表头名称</param>
        public ColumnNameAttribute(string columnName)
        {
            this.ColumnName = columnName;
        }
        #endregion

        #region 属性

        /// <summary>
        /// 获取或者设置表头名称。
        /// </summary>
        public string ColumnName { get; set; }

        #endregion
    }

    /// <summary>
    /// 新增class属性的导出特性
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class ExportAttribute : Attribute
    {
        #region 构造方法

        /// <summary>
        /// 默认构造方法。
        /// </summary>
        public ExportAttribute()
        {
            this.Order = 1000;
            this.IsExportVisible = true;
            this.IsAllowNull = true;
        }

        #endregion

        #region 属性

        /// <summary>
        /// 获取或者设置导入导出时数据库表字段的显示名称。
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 获取或者设置显示顺序。
        /// </summary>
        public int Order { get; set; }

        /// <summary>
        /// 获取或者设置数据输出格式。
        /// </summary>
        public string FormatString { get; set; }

        /// <summary>
        /// 获取或者设置导出时是否可见。
        /// </summary>
        public bool IsExportVisible { get; set; }

        /// <summary>
        /// 获取或者设置是否导出时忽略。
        /// </summary>
        public bool IsExportIgnore { get; set; }

        /// <summary>
        /// 导入时是否允许为空。
        /// </summary>
        public bool IsAllowNull { get; set; }

        #endregion
    }

    public class ExportOption
    {
        #region 构造函数
        public ExportOption() { }
        #endregion

        #region 属性

        /// <summary>
        /// 获取或者设置导入导出时数据库表字段的显示名称。
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 获取或者设置显示顺序。
        /// </summary>
        public int Order { get; set; }

        /// <summary>
        /// 获取或者设置数据输出格式。
        /// </summary>
        public string FormatString { get; set; }

        /// <summary>
        /// 属性名称_暂定
        /// </summary>
        public string PropertyName { get; set; }

        /// <summary>
        /// 获取或者设置是否导出时忽略。
        /// </summary>
        public bool IsExportIgnore { get; set; }

        /// <summary>
        /// 导入时是否允许为空。
        /// </summary>
        public bool IsAllowNull { get; set; }

        #endregion
    }

}