﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using NET01.CoreFramework;
using CIT.UPC.Authorization.Client;
using Microsoft.Practices.ServiceLocation;

namespace RWIS.Presentation.Web.Core
{
    public class CommonHelper
    {
        IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
        /// <summary>
        /// 根据UuId获取下拉列表
        /// </summary>
        /// <param name="codeString"></param>
        /// <returns></returns>
        //public List<SelectListItem> GetSelectItemUuIdByStrName(List<BasicObject> basicObjectList)
        //{
        //    List<SelectListItem> list = new List<SelectListItem>();
        //    list.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
        //    foreach (var item in basicObjectList)
        //    {
        //        list.Add(new SelectListItem { Text = item.Name, Value = item.Uuid.ToString() });
        //    }
        //    return list;
        //}

        /// <summary>
        /// 根据code获取下拉列表
        /// </summary>
        /// <param name="codeString"></param>
        /// <returns></returns>
        //public List<SelectListItem> GetSelectItemCodeByStrName(List<BasicObject> basicObjectList)
        //{
        //    List<SelectListItem> list = new List<SelectListItem>();
        //    list.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
        //    foreach (var item in basicObjectList)
        //    {
        //        list.Add(new SelectListItem { Text = item.Name, Value = item.Code.ToString() });
        //    }
        //    return list;
        //}

       



        /// <summary>
        /// 将decimal装换为科学技术法0.00E+00格式.
        /// </summary>
        /// <param name="de"></param>
        /// <returns></returns>
        public string StringFormatGetE(decimal de)
        {
          string strE= String.Format("{0:0.00}", (String.Format("{0:E1}", de)));
          return strE;
        }

        /// <summary>
        /// 精确到小数点后几位
        /// </summary>
        /// <param name="de"></param>
        /// <returns></returns>
        public string StringFormatAccurate(decimal de)
        {
            string strE = String.Format("{0:0.000000}", de);
            return strE;
        }

        /// <summary>
        /// 得到列对象
        /// </summary>
        /// <param name="colM">列名</param>
        /// <param name="isHidden">是否隐藏</param>
        /// <returns></returns>
        public MaterialStockDetailVM GetColMs(string colM, bool isHidden)
        {
            MaterialStockDetailVM sample = new MaterialStockDetailVM();
            sample.name = colM;
            sample.index = colM;
            sample.align = "center";
            if (isHidden)
            {
                sample.hidden = "true";
            }
            return sample;
        }

        #region 根据资源编号、员工号以及约束得到当前菜单的操作列表
        //根据资源编号、员工号以及约束得到当前菜单的操作列表
        public static string GetOperationList(string resourceCode)
        {
            string operationList = "";
            try
            {
                IAuthorization auth = AuthorizationFactory.Create();
                auth.ClearCache();
                string[] arrOperation = auth.GetUserAccessOperations(AppContext.CurrentUser.UserId, resourceCode, AppContext.CurrentUser.ProjectCode);

                foreach (var item in arrOperation)
                {
                    operationList += item + ",";
                }
                if (operationList.Length > 0)
                {
                    operationList = operationList.TrimEnd(',');
                }
            }
            catch
            {
                operationList = "Submit,Confirm";
            }
            return operationList;
        }
        #endregion

        /// <summary>
        /// 将日期格式化
        /// </summary>
        /// <param name="dt">日期</param>
        /// <param name="strDt">想要装换的日期格式,如yyyy-MM-dd</param>
        /// <returns></returns>
        public DateTime DateFormat(Nullable<DateTime> dt,string strDt)
        {
            DateTime ftDt = Convert.ToDateTime(dt.HasValue ? dt.Value.ToString(strDt) : string.Empty);
            return ftDt;
        }

        /// <summary>
        /// 根据code生成Text = item.Name, Value = item.Code的List<SelectListItem>
        /// </summary>
        /// <param name="strName">code</param>
        /// <returns></returns>
        public List<SelectListItem> GetSelectItemCodeByStrName(string strName)
        {
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();

            BasicObject basicObject = iBasicObjectRepository.GetFiltered(b => b.Code.ToUpper() == strName.ToUpper()).FirstOrDefault();
            List<BasicObject> basicObjectList = iBasicObjectRepository.GetFiltered(b => b.ParentUuid == basicObject.Uuid).ToList();

            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            foreach (var item in basicObjectList)
            {
                list.Add(new SelectListItem { Text = item.Name, Value = item.Code.ToString() });
            }
            return list;
        }

        /// <summary>
        /// 根据code生成Text = item.Name, Value = item.Uuid的List<SelectListItem>
        /// </summary>
        /// <param name="strName">code</param>
        /// <returns></returns>
        public List<SelectListItem> GetSelectItemUuIdByStrName(string strName)
        {
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();

            BasicObject basicObject = iBasicObjectRepository.GetFiltered(b => b.Code.ToUpper() == strName.ToUpper()).FirstOrDefault();
            List<BasicObject> basicObjectList = iBasicObjectRepository.GetFiltered(b => b.ParentUuid == basicObject.Uuid).ToList();

            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            foreach (var item in basicObjectList)
            {
                list.Add(new SelectListItem { Text = item.Name, Value = item.Uuid.ToString() });
            }
            return list;
        }

        /// <summary>
        /// 根据当前code值返回name
        /// </summary>
        /// <param name="code">当前code值</param>
        /// <param name="strName">父code如:Factory</param>
        /// <returns></returns>
        public string GetSelectItemNameByCode(string code, string strName)
        {
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            BasicObject basicObject = iBasicObjectRepository.GetFiltered(b => b.Code.ToUpper() == strName.ToUpper()).FirstOrDefault();
            List<BasicObject> basicObjectList = iBasicObjectRepository.GetFiltered(b => b.ParentUuid == basicObject.Uuid).ToList();

            string name = "";
            foreach (var item in basicObjectList)
            {
                if (item.Code == code)
                {
                    name = item.Name;
                }
            }
            return name;
        }

        /// <summary>
        /// 根据UuId获取name
        /// </summary>
        /// <param name="uUId"></param>
        /// <param name="strName"></param>
        /// <returns></returns>
        public string GetSelectItemNameByUuId(string uUId, string strName)
        {
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            BasicObject basicObject = iBasicObjectRepository.GetFiltered(b => b.Code.ToUpper() == strName.ToUpper()).FirstOrDefault();
            List<BasicObject> basicObjectList = iBasicObjectRepository.GetFiltered(b => b.ParentUuid == basicObject.Uuid).ToList();

            string name = "";
            foreach (var item in basicObjectList)
            {
                if (item.Uuid == uUId)
                {
                    name = item.Name;
                }
            }
            return name;
        }

        /// <summary>
        /// 获取电站列表
        /// </summary>
        /// <returns></returns>
        public List<SelectListItem> GetStationList()
        {
            IBasicWasteUnitRepository iBasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
            IQueryable<BasicWasteUnit> QueryStationList = iBasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);

            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            foreach (var item in QueryStationList)
            {
                list.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitCode.ToString() });
            }
            return list;
        }

        /// <summary>
        /// 根据code获得电站名称
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public string GetStationNameByCode(string code)
        {
            IBasicWasteUnitRepository iBasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
            IQueryable<BasicWasteUnit> QueryStationList = iBasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            string name = "";
            foreach (var item in QueryStationList)
            {
                if (item.UnitCode == code)
                {
                    name = item.UnitName;
                }
            }
            return name;
        }

        /// <summary>
        /// 转换成字符串格式
        /// </summary>
        /// <param name="objStr"></param>
        /// <returns></returns>
        public static string ConverToString(object objStr)
        {
            string convertStr = string.Empty;
            if (objStr == null)
            {
                return string.Empty;
            }
            else
            {
                convertStr = objStr.ToString();
            }
            return convertStr;
        }
    }
}