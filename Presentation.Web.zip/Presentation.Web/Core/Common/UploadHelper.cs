﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Core.Common
{
    public class UploadHelper
    {
        #region 字段

        /// <summary>
        /// 文件上传路径
        /// </summary>

        //HttpContext.Current.Server.MapPath("/public/Temp/");//~/Temp/
        private static string path = ConfigurationManager.AppSettings["Temp"];
        // private static string path = HttpContext.Current.Server.MapPath("~/Temp/");//~/Temp/
        /// <summary>
        /// 文件上传类型限制
        /// </summary>
        // private static string fileExts = ConfigurationManager.AppSettings["FileType"];
        private static string fileExts = "xls,xlsx";
        /// <summary>
        /// 文件上传大小限制
        /// </summary>
        private static int size = 51200;

        #endregion

        #region 构造函数

        public UploadHelper()
        {
        }

        #endregion


        #region 上传单类型多个文件，传入文件集为空时返回""，上传失败时返回null
        /// <summary>
        /// 上传单类型多个文件，传入文件集为空时返回""，上传失败时返回null
        /// </summary>
        /// <param name="files">待上传文件集</param> 
        /// <returns>已上传文件名</returns>
        public static string SaveFile(System.Web.HttpFileCollectionBase files)
        {
            string result = string.Empty, strMsg = string.Empty;
            try
            {
                string name = string.Empty, newName = string.Empty;
                for (int i = 0; i < files.Count; i++)
                {
                    System.Web.HttpPostedFileBase file = files[i];
                    name = System.IO.Path.GetFileName(file.FileName);
                    //检查扩展名是否满足条件
                    if (fileExts.Contains(name.Substring(name.LastIndexOf('.') + 1).ToLower()))
                    {
                        if (name != "")
                        {
                            if (file.ContentLength > size * 1024)
                            {
                                //错误消息以 上传文件 开头，表示 失败
                                strMsg = name + "上传文件因大小超过" + size + "KB，将被忽略";
                                //result = string.Format("{\"result\":false,\"msg\":\"{0}\"}", strMsg);
                            }
                            else
                            {
                                newName = GetUniqueName(name);
                                ExistDirectory(path);
                                file.SaveAs(path + newName);
                                strMsg += string.Concat(path + newName, ";");
                                //result = string.Format("{\"result\":true,\"msg\":\"{0}\"}", strMsg);
                            }
                        }
                    }
                    else
                    {
                        throw new Exception("上传文件" + name + "扩展名不符合要求，上传失败！");
                    }
                }
            }
            catch (Exception ex)
            {
                strMsg = "上传文件失败！" + ex.Message;
                //result = string.Format("{\"result\":false,\"msg\":\"{0}\"}", strMsg);
            }

            return strMsg;
        }
        #endregion

        #region 上传单类型多个文件，传入文件集为空时返回""，上传失败时返回null
        /// <summary>
        /// 上传单类型多个文件，传入文件集为空时返回""，上传失败时返回null
        /// </summary>
        /// <param name="files">待上传文件集</param> 
        /// <returns>已上传文件名</returns>
        [HttpPost]
        public static UploadResult AjaxSaveFile(System.Web.HttpFileCollectionBase files)
        {
            bool isSuccess = false;
            string strResult = string.Empty;
            UploadResult uploadResult = new UploadResult();

            try
            {
                string name = string.Empty, newName = string.Empty;
                for (int i = 0; i < files.Count; i++)
                {
                    System.Web.HttpPostedFileBase file = files[i];
                    name = System.IO.Path.GetFileName(file.FileName);
                    //检查扩展名是否满足条件
                    if (fileExts.Contains(name.Substring(name.LastIndexOf('.') + 1).ToLower()))
                    {
                        if (name != "")
                        {
                            if (file.ContentLength > size * 1024)
                            {
                                strResult = name + "因大小超过" + size + "KB，将被忽略";
                            }
                            else
                            {
                                newName = GetUniqueName(name);
                                ExistDirectory(path);
                                file.SaveAs(path + newName);

                                strResult += string.Concat(path + newName, ";");
                                isSuccess = true;
                            }
                        }
                    }
                    else
                    {
                        strResult = "上传文件扩展名不符合要求，上传失败！";
                    }
                }
            }
            catch
            {
                strResult = "上传文件失败！";
            }

            uploadResult.IsSuccess = isSuccess;
            uploadResult.Result = strResult;
            return uploadResult;
        }
        #endregion

        /// <summary>
        /// 根据分类，获取保存地址
        /// </summary>
        /// <param name="uType"></param>
        /// <returns></returns>
        public static string GetSavePath(UploadType uType)
        {
            string uploadPath = string.Empty;
            switch (uType)
            {
                case UploadType.WelcomeImg:
                    uploadPath = ConfigurationManager.AppSettings["Project"];
                    break;

                case UploadType.ReviewSuggest:
                    uploadPath = ConfigurationManager.AppSettings["RepairCatalogReview"];
                    break;

                case UploadType.UpdateImport:
                    uploadPath = ConfigurationManager.AppSettings["ImportUpdatePath"];
                    break;

                case UploadType.DeviceTrend:
                    uploadPath = ConfigurationManager.AppSettings["DeviceTrend"];
                    break;
            }
            return uploadPath;
        }

        /// <summary>
        /// 根据分类，获取下载地址
        /// </summary>
        /// <param name="uType"></param>
        /// <returns></returns>
        //public static string GetDownLoadPath(UploadType uType)
        //{
        //    string uploadPath = string.Empty;

        //    switch (uType)
        //    {
        //        case UploadType.ReviewSuggest:
        //            uploadPath = HttpContext.Current.Server.MapPath("~/Temp/") + GetSavePath(uType);
        //            break;
        //    }

        //    return uploadPath;
        //} 

        /// <summary>
        /// 上传保存单个文件
        /// </summary>
        /// <param name="file"></param>
        /// <param name="uType"></param>
        /// <returns></returns>
        public static string SaveSingleFile(HttpPostedFileBase file, UploadType uType)
        {
            string result = string.Empty;
            string strMsg = string.Empty;

            //获取文件上传路径
            string uploadPath = GetSavePath(uType);

            try
            {
                string name = string.Empty, newName = string.Empty;


                name = System.IO.Path.GetFileName(file.FileName);
                string extName = System.IO.Path.GetExtension(name).ToLower();
                //移除 "." 字符
                extName = extName.Remove(0, 1);

                //检查扩展名是否满足条件
                if (fileExts.Contains(extName))
                {
                    if (file.ContentLength > size * 1024)
                    {
                        strMsg = name + "因大小超过" + size + "KB，将被忽略";
                    }
                    else
                    {
                        newName = GetUniqueName(name);
                        ExistDirectory(uploadPath);
                        file.SaveAs(uploadPath + newName);

                        strMsg = newName;
                    }
                }
                else
                {
                    throw new Exception("上传文件" + name + "扩展名不符合要求，上传失败！");
                }

            }
            catch (Exception ex)
            {
                strMsg = "上传文件失败！" + ex.Message;
            }

            return strMsg;
        }

        #region 删除单个或多个文件
        /// <summary>
        /// 删除单个或多个文件
        /// </summary>
        /// <param name="file">文件名(以“;”结尾)</param>
        /// <returns>是否删除成功</returns>
        public static bool DeleteFile(string filesName)
        {
            bool result;
            if (string.IsNullOrEmpty(filesName))
            {
                result = true;
            }
            else
            {
                if (!filesName.EndsWith(";"))
                {
                    filesName += ";";
                }
                string[] files = filesName.Split(';');
                try
                {
                    for (int i = 0; i < files.Length - 1; i++)
                    {
                        if (System.IO.File.Exists(files[i]))
                        {
                            System.IO.File.Delete(files[i]);
                        }
                    }
                    result = true;
                }
                catch
                {
                    result = false;
                }
            }
            return result;
        }
        #endregion

        #region 辅助方法

        /// <summary>
        /// 获取唯一的文件名称
        /// </summary>
        /// <param name="name">原文件名</param>
        /// <returns>以“_序数”为后缀的唯一文件名</returns>
        private static string GetUniqueName(string name)
        {
            string preName;
            string extension;
            string newName = name;
            int num = 0;
            while (System.IO.File.Exists(path + newName))
            {
                num++;
                preName = name.Substring(0, name.LastIndexOf(".")).Replace(" ", "").Replace("#", "").Replace("\"", "");
                extension = name.Substring(name.LastIndexOf("."));
                newName = preName + "_" + num.ToString() + extension;
            }
            return newName;
        }

        /// <summary>
        /// 获取唯一的文件名称
        /// </summary>
        /// <param name="name">原文件名</param>
        /// <param name="mapPath">绝对路径</param>
        /// <returns>以“_序数”为后缀的唯一文件名</returns>
        public static string GetUniqueName(string name, string mapPath)
        {
            string preName = string.Empty;
            string extension = string.Empty;
            string newName = name;
            int num = 0;

            while (System.IO.File.Exists(mapPath + newName))
            {
                num++;
                preName = name.Substring(0, name.LastIndexOf(".")).Replace(" ", "").Replace("#", "").Replace("\"", "");
                extension = name.Substring(name.LastIndexOf("."));
                newName = preName + "_" + num.ToString() + extension;
            }
            return newName;
        }

        /// <summary>
        /// 查询文件夹目录是否存在，如果不存在则创建文件夹
        /// </summary>
        /// <param name="strPath">目录名称</param>
        private static void ExistDirectory(string strPath)
        {
            string filePath = strPath;
            if (!System.IO.Directory.Exists(filePath))
            {
                System.IO.Directory.CreateDirectory(filePath);
            }
        }

        #endregion
    }


    /// <summary>
    /// 上传文件类型枚举
    /// </summary>
    public enum UploadType
    {
        /// <summary>
        /// 欢迎图片
        /// </summary>
        WelcomeImg = 1,
        /// <summary>
        /// 大纲评审附件
        /// </summary>
        ReviewSuggest = 10,

        /// <summary>
        /// 覆盖导入保存文件
        /// </summary>
        UpdateImport = 20,

        /// <summary>
        /// 设备趋势统计图表文件
        /// </summary>
        DeviceTrend = 30
    }

    /// <summary>
    /// 上传文件返回结果
    /// </summary>
    public class UploadResult
    {
        public bool IsSuccess { get; set; }
        public string Result { get; set; }
    }
}