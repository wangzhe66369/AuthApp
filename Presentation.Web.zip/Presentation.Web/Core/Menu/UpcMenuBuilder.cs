﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   UpcMenuBuilder.cs
 *   描    述   ：   根据框架集成的授权模块/统一授权中心生成菜单
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2013-08-15 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2013-08-15 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System.Collections.Generic;
using System.Web.Mvc;
using NET01.CoreFramework;
using UpcAuthClient = CIT.UPC.Authorization.Client;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Core;
using System.Configuration;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// 根据框架集成的授权模块/统一授权中心生成菜单
    /// </summary>
    public class UpcMenuBuilder : MenuBuilder
    {
        /// <summary>
        /// 创建CnpecMenuBuilder实现
        /// </summary>
        /// <param name="controller"></param>
        public UpcMenuBuilder(Controller controller)
            : base(controller)
        { }

        /// <summary>
        /// 获取菜单数据脚本
        /// </summary>
        /// <returns></returns>
        public override string GetMenuJavaScript()
        {
            List<Menu> menuModules = new List<Menu>();
            ApplicationUser loginUser = AppContext.CurrentUser;
            string projectCode = AppContext.CurrentUser.ProjectCode;
            UpcAuthClient.IAuthorization auth = UpcAuthClient.AuthorizationFactory.Create();
            auth.ClearCache();
            UpcAuthClient.Resource[] accessMenuResources = auth.GetUserAccessMenuResources(loginUser.UserId.ToUpper(), projectCode);
            foreach (var menuRes in accessMenuResources)
            {
                menuModules.Add(BuidMenu(menuRes));
            }
            var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            return serializer.Serialize(menuModules);

        }


        /// <summary>
        /// 构建菜单
        /// </summary>
        /// <param name="menuResource"></param>
        /// <returns></returns>
        private Menu BuidMenu(UpcAuthClient.Resource menuResource)
        {
            Menu menu = new Menu();
            menu.icon = controller.Url.Content("~/Content/GlobalStyle/images/ui-icon_home.gif");
            menu.name = menuResource.ResourceName;
            menu.css = "edit";
            menu.target = "mainFrame";
            menu.url = controller.Url.Content("~/" + menuResource.Url);
            menu.name = menuResource.ResourceName;
            if (menuResource.HasChildren)
            {
                List<Menu> children = new List<Menu>();
                foreach (UpcAuthClient.Resource child in menuResource.Children)
                {
                    children.Add(BuidMenu(child));
                }
                menu.items = children;
            }
            else
            {
                menu.items = new List<Menu>();
            }
            return menu;
        }
    }
}