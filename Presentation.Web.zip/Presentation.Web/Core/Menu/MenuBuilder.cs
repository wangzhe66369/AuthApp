﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   MenuBuilder.cs
 *   描    述   ：   创建菜单Json脚本， MenuBuilder基类
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2013-08-15 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2013-08-15 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System.Collections.Generic;
using System.Web.Mvc;
using NET01.CoreFramework;
namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// 创建菜单Json脚本， MenuBuilder基类
    /// </summary>
    public abstract class MenuBuilder
    {
        protected Controller controller;
        /// <summary>
        /// 构建函数
        /// </summary>
        /// <param name="controller"></param>
        public MenuBuilder(Controller controller)
        {
            this.controller = controller;
        }
        /// <summary>
        /// 获取菜单数据脚本
        /// </summary>
        /// <returns></returns>
        public abstract string GetMenuJavaScript();
    }

    /// <summary>
    /// 菜单模块(用于生成菜单树JSON数据)
    /// </summary>
    public class Menu
    {
        public string name { get; set; }
        public string icon { get; set; }
        public string id { get; set; }
        public string css { get; set; }
        public string target { get; set; }
        public string url { get; set; }
        public bool expand { get; set; }
        public string style { get; set; }
        
        public List<Menu> items { get; set; }
    }
}