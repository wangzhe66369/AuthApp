﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   CnpecMenuBuilder.cs
 *   描    述   ：   根据框工程IMS授权系统生成菜单
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2013-08-15 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2013-08-15 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System.Collections.Generic;
using System.Web.Mvc;
using NET01.CoreFramework;
using System.Linq;
using NET01.Infrastructure.Authorization;
using Microsoft.Practices.ServiceLocation;


namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// 根据框工程IMS授权系统生成菜单
    /// </summary>
    public class CnpecMenuBuilder : MenuBuilder
    {
        /// <summary>
        /// 创建CnpecMenuBuilder实现
        /// </summary>
        /// <param name="controller"></param>
        public CnpecMenuBuilder(Controller controller)
            : base(controller)
        { }

        /// <summary>
        /// 获取菜单数据脚本
        /// </summary>
        /// <returns></returns>
        public override string GetMenuJavaScript()
        {
            List<Menu> menuModules = new List<Menu>();

            ApplicationUser loginUser = AppContext.CurrentUser;
            IAuthorization auth = ServiceLocator.Current.GetInstance<IAuthorization>();
            List<Resource> menuResources = auth.GetUserResources(loginUser.UserId, loginUser.ProjectCode);

            var leve1Menu=menuResources.Where(r=>string.IsNullOrEmpty(r.ParentId));
            foreach (var menuRes in leve1Menu)
            {
                menuModules.Add(BuidMenu(menuRes, menuResources));
            }
            var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            return serializer.Serialize(menuModules);
        }


        /// <summary>
        /// 构建菜单
        /// </summary>
        /// <param name="menuResource"></param>
        /// <returns></returns>
        private Menu BuidMenu(Resource resource, List<Resource> menuResources)
        {

            Menu menu = new Menu();
           // menu.icon =  RWIS.Presentation.Web.Core.Globalization.GlobalizationManager.GetStaticStyle()+"/GlobalStyle/images/ui-icon_home.gif";
            menu.icon = controller.Url.Content("~/Content/GlobalStyle/images/ui-icon_home.gif");
            menu.name = resource.Name;
            menu.css = "edit";
            menu.target = "mainFrame";
            menu.url = controller.Url.Content("~/" + resource.Url);
            var childrenMenuResources = menuResources.Where(r => r.ParentId==resource.ResourceId);
            if (childrenMenuResources.Count() > 0)
            {
                List<Menu> children = new List<Menu>();
                foreach (Resource child in childrenMenuResources)
                {
                    children.Add(BuidMenu(child,menuResources));
                }
                menu.items = children;
            }
            return menu;
        }

    }

   
}