
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// T4代码生成器菜单工具类
    /// </summary>
    public class T4MenuBuilderGen
    {
		/// <summary>
        /// 获取T4生成的菜单列表
        /// </summary>
        /// <param name="controller">控制器</param>
        /// <returns>菜单列表</returns>
        public List<Menu> GetT4MenuList(Controller controller)
        {
			return new List<Menu>()
            {
						new Menu(){
                    name = "Temployee管理",
                    css = "edit",
                    target = "mainFrame",
                    url = controller.Url.Action("Index", "Temployee",new { Area = "GenTest" })
                },
					};
		}

	}
}

