﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   HardCodingMenuBuilder.cs
 *   描    述   ：   菜单Builder,直接编码生成菜单树
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2013-08-15 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2013-08-15 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System.Collections.Generic;
using System.Web.Mvc;
using NET01.CoreFramework;
using System.Configuration;
using System;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// 菜单Builder,直接编码生成才单树
    /// </summary>
    public class HardCodingMenuBuilder : MenuBuilder
    {
        /// <summary>
        /// 创建CnpecMenuBuilder实现
        /// </summary>
        /// <param name="controller"></param>
        public HardCodingMenuBuilder(Controller controller)
            : base(controller)
        { }

        /// <summary>
        /// 获取菜单数据脚本
        /// </summary>
        /// <returns></returns>
        public override string GetMenuJavaScript()
        {
            List<Menu> menuModules = BuidMenu();
            var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            return serializer.Serialize(menuModules);
        }

        /// <summary>
        /// 构建默认的工作台
        /// </summary>
        /// <returns></returns>
        private List<Menu> BuidMenu()
        {
            var iconUrl = controller.Url.Content("~/Content/GlobalStyle/images/ui-icon_home.gif");
            List<Menu> menuModules = new List<Menu>()
            {       

                     new Menu(){
                               icon = iconUrl,
                                name = "材料管理",
                                css = "edit",
                                target = "mainFrame",
                                items = new List<Menu>() { 
                                   
                                    new Menu(){
                                           icon = iconUrl,
                                            name = "材料入库",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("Index", "MaterialInput", new { Area = "MaterialManage"})},
                                      new Menu(){
                                           icon = iconUrl,
                                            name = "材料转运",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("Index", "MaterialTransfer", new { Area = "MaterialManage"})}, 
                                       new Menu(){
                                           icon = iconUrl,
                                            name = "材料消耗",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("Index", "MaterialDrain", new { Area = "MaterialManage"})},
                                       new Menu(){
                                           icon = iconUrl,
                                            name = "材料库存信息",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("Index", "MaterialStockDetail", new { Area = "MaterialManage"})},
                                       new Menu(){
                                           icon = iconUrl,
                                            name = "材料验收",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("Index", "MaterialCheck", new { Area = "MaterialManage"}),
                                            items = new List<Menu>() {
                                          
                                             new Menu(){
                                            name = "金属桶验收单",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexMetel", "MaterialCheck", new { Area = "MaterialManage"})}, 
                                              new Menu(){
                                            name = "水泥桶验收单",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexCement", "MaterialCheck", new { Area = "MaterialManage"})}, 
                                              new Menu(){
                                            name = "固化材料验收单",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexSolid", "MaterialCheck", new { Area = "MaterialManage"})}, 
                                              new Menu(){
                                            name = "其它验收单",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexOther", "MaterialCheck", new { Area = "MaterialManage"})}, 
                                            }
                                       }
                                
                                  },
                        },   


                       new Menu()
                        {
                        icon = iconUrl,
                        name = "设备信息",
                        css = "edit",
                        target = "mainFrame",
                        items = new List<Menu>() {
                                 new Menu(){
                                        name = "设备维护",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "EquipInfo", new { Area = "EquipManage"})}, 
                                        new Menu(){
                                        name = "设备状态",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "EquipDetail", new { Area = "EquipManage"})}, 
                        }
                        },
                          new Menu()
                        {
                        icon = iconUrl,
                        name = "废物桶管理",
                        css = "edit",
                        target = "mainFrame",
                        items = new List<Menu>() {
                             new Menu(){
                                            name = "桶信息",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("Index", "BucketInfo", new { Area = "MaterialManage"})},
                             new Menu(){
                                        name = "空桶准备记录",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "EmptyPrepare", new { Area = "TemporaryStorage"})},
                              new Menu(){
                                        name = "空桶运输记录",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "EmptyTrans", new { Area = "TemporaryStorage"})},
                        }
                        },
                       new Menu()
                        {
                        icon = iconUrl,
                        name = "废物跟踪单",
                        css = "edit",
                        target = "mainFrame",
                        items = new List<Menu>() {
                          
                                        new Menu(){
                                        name = "浓缩液列表",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "TrackLiquor", new { Area = "WasteTracking"})}, 
                                        new Menu(){
                                        name = "废树脂列表",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearTrackResin", new { Area = "WasteTracking"})}, 
                                        new Menu(){
                                        name = "废滤芯列表",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearTrackElement", new { Area = "WasteTracking"})}, 
                                        new Menu(){
                                        name = "淤积物列表",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearTrackDeposit", new { Area = "WasteTracking"})}, 
                                        new Menu(){
                                        name = "废油和溶剂",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearTrackSolvent", new { Area = "WasteTracking"})},
                                    
                                        new Menu(){
                                        name = "通风过滤器列表",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearTrackFilter", new { Area = "WasteTracking"})}, 
                                        new Menu(){
                                        name = "技术废物(>2mSv/h)",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearTrackTechB", new { Area = "WasteTracking"})}, 
                                        new Menu(){
                                        name = "技术废物(<2mSv/h)",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearTrackTechS", new { Area = "WasteTracking"})}, 
                                        new Menu(){
                                        name = "杂项",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearTrackSundry", new { Area = "WasteTracking"})}, 
                                        new Menu(){
                                        name = "去污申请单列表",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearTrackDecon", new { Area = "WasteTracking"})}, 
                                        new Menu(){
                                        name = "核素分析单列表",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearNuclide", new { Area = "WasteTracking"})}, 
                          }
                        },

                    new Menu()
                        {
                        icon = iconUrl,
                        name = "废物管理",
                        css = "edit",
                        target = "mainFrame",
                        items = new List<Menu>() {
                             

   
                       new Menu(){
                                name = "废物处理",
                                css = "edit",
                                target = "mainFrame",
                                items = new List<Menu>() {
                                                                  
      
                                      new Menu(){
                                        name = "桶信息",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "BucketInfo", new { Area = "MaterialManage"})},
                                        new Menu(){
                                        name = "桶检查",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "BucketCheck", new { Area = "WasteTreatment"})},
                                        new Menu(){
                                        name = "固定",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "FixAtion", new { Area = "WasteTreatment"})},
                                        
                        }
                    },
                       new Menu(){
                                        name = "水泥固化",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "CementSolidify", new { Area = "WasteTreatment"}),
                                        items=new List<Menu>(){
                                        new Menu(){
                                        name = "浓缩液装桶固化",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("BucketSolutionDetail", "CementSolidify", new { Area = "WasteTreatment"})},
                                        new Menu(){
                                        name = "废树脂装桶固化",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("BucketResinDetail", "CementSolidify", new { Area = "WasteTreatment"})},
                                        new Menu(){
                                        name = "干湿料制备及废树脂",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("BucketRSolidifyDetail", "CementSolidify", new { Area = "WasteTreatment"})},
                                        new Menu(){
                                        name = "干湿料制备及浓缩液",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("BucketSSolidifyDetail", "CementSolidify", new { Area = "WasteTreatment"})},
                                        }
                                        },
                                        new Menu(){
                                        name = "超压",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "BucketCover", new { Area = "WasteTreatment"}),
                                        items=new List<Menu>(){
                                        new Menu(){
                                        name = "400L金属桶封盖",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("CoverMetal", "BucketCover", new { Area = "WasteTreatment"})},
                                        }
                                        
                                        },
                                        new Menu(){
                                        name = "封盖",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("IndexM", "BucketCover", new { Area = "WasteTreatment"}),
                                        items=new List<Menu>(){
                                        new Menu(){
                                        name = "湿混料制备及封盖",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("CoverMix", "BucketCover", new { Area = "WasteTreatment"})},
                                        }
                                        
                                        },

                     new Menu(){
                                           icon = iconUrl,
                                            name = "其他工艺",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("Index", "OtherTechnology", new { Area = "OtherTechnology"}),
                                            items = new List<Menu>() {
                                          
                                             new Menu(){
                                            name = "废物焚烧",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexFire", "OtherTechnology", new { Area = "OtherTechnology"})}, 
                                              new Menu(){
                                            name = "废物降解",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexDegrades", "OtherTechnology", new { Area = "OtherTechnology"})}, 
                                              new Menu(){
                                            name = "高整体容器处理",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexHDispose", "OtherTechnology", new { Area = "OtherTechnology"})}, 
                                              new Menu(){
                                            name = "极低放废物处理",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexLDispose", "OtherTechnology", new { Area = "OtherTechnology"})}, 
                                            new Menu(){
                                            name = "废物解控",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexClear", "OtherTechnology", new { Area = "OtherTechnology"})}, 
                                            new Menu(){
                                            name = "废物熔炼",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexSmelt", "OtherTechnology", new { Area = "OtherTechnology"})}, 
                                            new Menu(){
                                            name = "废物拆解",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexDismantle", "OtherTechnology", new { Area = "OtherTechnology"})}, 
                                            new Menu(){
                                            name = "特殊包装",
                                            css = "edit",
                                            target = "mainFrame",
                                            url = controller.Url.Action("IndexPackage", "OtherTechnology", new { Area = "OtherTechnology"})}, 
                        }
                    },       
                    
                     new Menu(){
                                name = "活度计算",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "ActivityCount", new { Area = "Activity"}), 
                                items = new List<Menu>() {
                                new Menu(){
                                name = "200L废物桶",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "WasteBucket", new { Area = "Activity"})}, 
                                  new Menu(){
                                name = "C1浓缩液",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "Cementliquid", new { Area = "Activity"})},
                                  new Menu(){
                                name = "C4过滤器",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "Cfilter", new { Area = "Activity"})},
                                  new Menu(){
                                name = "多芯桶",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "Core", new { Area = "Activity"})},
                                  new Menu(){
                                name = "C1树脂",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "Cresin", new { Area = "Activity"})},
                                  new Menu(){
                                name = "活度直接测量",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "Dmeasure", new { Area = "Activity"})},
                                  new Menu(){
                                name = "高放废物",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "Hlevel", new { Area = "Activity"})},
                                  new Menu(){
                                name = "400L过滤器",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "Mfilter", new { Area = "Activity"})},
                                  new Menu(){
                                name = "400L浓缩液",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "Mliquid", new { Area = "Activity"})},
                                  new Menu(){
                                name = "400L废树脂",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "Mresin", new { Area = "Activity"})},
                                  new Menu(){
                                name = "400L超压废物桶",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "OpBucket", new { Area = "Activity"})}
                        }
                    },
                 }


              },
              new Menu(){
                                icon = iconUrl,
                                name = "暂存管理",
                                css = "edit",
                                target = "mainFrame",
                                items = new List<Menu>() {
                   
                                        new Menu(){
                                        name = "水泥桶封盖记录",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "TsEbover", new { Area = "TemporaryStorage"})},
                                        new Menu(){
                                        name = "源项废物运输记录",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "TsRbTrans", new { Area = "TemporaryStorage"})},
                                        new Menu(){
                                        name = "货包检查",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "GoodsCheck", new { Area = "TemporaryStorage"})},
                                        new Menu(){
                                        name = "盘点管理",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "StockManage", new { Area = "TemporaryStorage"})},
                                        new Menu(){
                                        name = "暂存库存信息",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "InventoryPosition", new { Area = "TemporaryStorage"}),
                                        items=new List<Menu>(){
                                        new Menu(){
                                        name = "定位图",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("PositionImg", "InventoryPosition", new { Area = "TemporaryStorage"})},
                                        //new Menu(){
                                        //name = "源项信息",
                                        //css = "edit",
                                        //target = "mainFrame",
                                        //url = controller.Url.Action("TsRbInfo", "InventoryPosition", new { Area = "TemporaryStorage"})},
                                        }
                                        },
                                        new Menu(){
                                        name = "转运",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "Transport", new { Area = "TemporaryStorage"}),
                                        items=new List<Menu>(){
                                        new Menu(){
                                        name = "废物货包及QT移动单",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("QTTransfer", "Transport", new { Area = "TemporaryStorage"})},

                                        new Menu(){
                                        name = "QT移动单",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("IndexQt", "Transport", new { Area = "TemporaryStorage"})},

                                        new Menu(){
                                        name = "厂房间废物桶",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("FactoryTransfer", "Transport", new { Area = "TemporaryStorage"})},
                                        }
                                        },
                                        new Menu(){
                                        name = "厂房废物货包记录",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "PackageRecord", new { Area = "TemporaryStorage"}),
                                        items=new List<Menu>(){
                                        new Menu(){
                                        name = "厂房废物货包入库",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("RecordIn", "PackageRecord", new { Area = "TemporaryStorage"})},
                                        new Menu(){
                                        name = "厂房废物货包出库",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("RecordOut", "PackageRecord", new { Area = "TemporaryStorage"})},
                                        }
                                        },
                                }
              },
               new Menu()
                        {
                        icon = iconUrl,
                        name = "处置管理",
                        css = "edit",
                        target = "mainFrame",
                        items = new List<Menu>() {
                        new Menu(){
                                name = "处理申请",

                                css = "edit",
                                target = "mainFrame",
                               
                                url = controller.Url.Action("Index", "DisposeApply", new { Area = "DisposeManage"})}, 
                                
                     }
                    }, 
              new Menu()
                        {
                        icon = iconUrl,
                        name = "处置场废物管理",
                        css = "edit",
                        target = "mainFrame",
                        items = new List<Menu>() {

                      new Menu(){
                                name = "废物货包审核",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "WastePacageCheck", new { Area = "WastePackageCheck"})}, 

                      new Menu(){
                                name = "废物货包申报认定",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "DeclareConfirm", new { Area = "WastePackageCheck"})}, 

                        new Menu(){
                                name = "抽检管理",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "DispsiteSpotCheck", new { Area = "DispsiteSpotCheck"})}, 
                         new Menu(){
                                name = "废物处置",
                                css = "edit",
                                target = "mainFrame",
                                items = new List<Menu>() {
                                   new Menu(){
                                        name = "废物接收",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearRubReception", new { Area = "WasteDisposal"})},
                                    new Menu(){
                                        name = "废物处置定位",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearRubLocation", new { Area = "WasteDisposal"})}, 
                                    new Menu(){
                                        name = "废物处置施工",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearRubCons", new { Area = "WasteDisposal"})},
                                    new Menu(){
                                        name = "档案生成",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "NuclearRubFile", new { Area = "WasteDisposal"})}
                                 
                                 }
                         
                         }, 
                      
                        new Menu(){
                                name = "废物运输",
                                css = "edit",
                                target = "mainFrame",
                               
                                url = controller.Url.Action("Index", "RubTransfer", new { Area = "RubTransfer"})}, 
                             
                     new Menu() {
                              name = "查询统计",
                              css = "edit",
                              target = "mainFrame",
                              items = new List<Menu>() {
                              new Menu(){
                                        name = "综合查询",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "IntegratedQuery", new { Area = "QueryStatistic"})},
                              new Menu(){
                                        name = "废物汇总",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "WasteStatistic", new { Area = "QueryStatistic"})},
                              new Menu(){
                                        name = "活度报表",
                                        css = "edit",
                                        target = "mainFrame",
                                        url = controller.Url.Action("Index", "ActivityReport", new { Area = "QueryStatistic"})},                             
                              }
                         },

                     },

                    }, 
                   
              
                

                  
                     new Menu()
                        {
                        icon = iconUrl,
                        name = "基础数据管理",
                        css = "edit",
                        target = "mainFrame",
                        items = new List<Menu>() {
                                new Menu(){
                                    name = "常量管理",
                                    css = "edit",
                                    target = "mainFrame",
                                    url = controller.Url.Action("Index", "BasicObject", new { Area = "SystemManage"})},  
                                new Menu(){
                                    name = "材料管理",
                                    css = "edit",
                                    target = "mainFrame",
                                    url = controller.Url.Action("Index", "MaterialType", new { Area = "MaterialManage"})},
                                new Menu(){
                                    name = "行业信息",
                                    css = "edit",
                                    target = "mainFrame",
                                    url = controller.Url.Action("Index", "BasicIndustry", new { Area = "SystemManage"})},
                                new Menu(){
                                    name = "废物产生单位",
                                    css = "edit",
                                    target = "mainFrame",
                                    url = controller.Url.Action("Index", "BasicWasteUnit", new { Area = "SystemManage"})}
                        }
                    },

                     new Menu()
                        {
                       icon = iconUrl,
                        name = "公共信息管理",
                        css = "edit",
                        target = "mainFrame",
                        items = new List<Menu>() {
                         new Menu(){
                                name = "资料管理",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "DataManage", new { Area = "PublicInfo"})}, 
                         new Menu(){
                                name = "不符合项管理",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "NonComformance", new { Area = "PublicInfo"})}, 
                                                                        
                        }
                    },
                     new Menu()
                        {
                        icon = iconUrl,
                        name = "技术支持",
                        css = "edit",
                        target = "mainFrame",
                        items = new List<Menu>() {
                                new Menu(){
                                name = "基础数据标准库",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "NuclearElement", new { Area = "Support"})}, 
                                 new Menu(){
                                name = "活度计算标准库",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "SupportEds", new { Area = "Support"})}, 
                                new Menu(){
                                name = "评估方法标准库",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "EvalMethod", new { Area = "Support"})},
                                new Menu(){
                                name = "近地表处置规定",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "EvalMethod", new { Area = "Support"})},
                                new Menu(){
                                name = "近地表处置规定",
                                css = "edit",
                                target = "mainFrame",
                                url = controller.Url.Action("Index", "SupportDispiteLimit", new { Area = "Support"})},
                        }
                    },
            };

            //if (Convert.ToBoolean(ConfigurationManager.AppSettings["UpcIsEmbedSystem"]))
            //{
            //    Menu psMenu = new Menu()
            //         {
            //             icon = iconUrl,
            //             name = "UPC授权",
            //             css = "edit",
            //             target = "mainFrame",
            //             #region UPC授权子菜单
            //             items = new List<Menu>() 
            //        {
            //            new Menu(){
            //                name = "子系统管理",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("ManageSubSystem", "SubSystem", new { Area = "AuthCommon"})
            //            },
            //            new Menu(){
            //                name = "约束维护",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("Enter", "AuthModule", new { Area = "AuthCommon",type="ConstraintConfig"})
            //            },
            //            new Menu(){
            //                name = "操作维护",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("Enter", "AuthModule", new { Area = "AuthCommon",type="OperationConfig"})
            //            },
            //            new Menu(){
            //                name = "资源配置",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("Enter", "AuthModule", new { Area = "AuthCommon",type="ResourceConfig"})
            //            },
            //            new Menu(){
            //                name = "角色配置",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("Enter", "AuthModule", new { Area = "AuthCommon",type="RoleConfig"})
            //            },
            //            new Menu(){
            //                name = "业务管理员授权",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("Enter", "AuthModule", new { Area = "AuthCommon",type="BusManagerAuth"})
            //            },
            //            new Menu(){
            //                name = "人员机构授权",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("Enter", "AuthModule", new { Area = "AuthCommon",type="UserOrgAuth"})
            //            },
            //            new Menu(){
            //                name = "人员授权查询",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("Enter", "AuthModule", new { Area = "AuthCommon",type="QueryUserAuth"})
            //            },
            //            new Menu(){
            //                name = "机构授权查询",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("Enter", "AuthModule", new { Area = "AuthCommon",type="QueryOrgAuth"})
            //            },
            //            new Menu(){
            //                name = "错误日志查询",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("Enter", "AuthModule", new { Area = "AuthCommon",type="QueryErrLog"})
            //            },
            //            new Menu(){
            //                name = "操作日志查询",
            //                css = "edit",
            //                target = "mainFrame",
            //                url = controller.Url.Action("Enter", "AuthModule", new { Area = "AuthCommon",type="QueryOperationLog"})
            //            }
            //        }
            //             #endregion
            //         };
            //    menuModules.Add(psMenu);
            //}


            return menuModules;
        }

    }
}
