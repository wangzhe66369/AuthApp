﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   AccessControl.cs
 *   描    述   ：   访问控制
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// 操作编码静态类
    /// </summary>
    public static class OperationCode
    {
         public const string Add ="Add";
         public const string Apply ="Apply";
         public const string Audit ="Audit";
         public const string Authorization ="Authorization";
         public const string Balance ="Balance";
         public const string Collect ="Collect";
         public const string Count ="Count";
         public const string Delete ="Delete";
         public const string Edit ="Edit";
         public const string Input ="Input";
         public const string Look ="Look";
         public const string Make ="Make";
         public const string Manage ="Manage";
         public const string Output ="Output";
         public const string Print ="Print";
         public const string QAEConfirm ="QAEConfirm";
         public const string Report ="Report";
         public const string Research ="Research";
         public const string Return ="Return";
         public const string Run ="Run";
         public const string Save ="Save";
         public const string Set ="Set";
         public const string Start ="Start";
         public const string Submit ="Submit";
    }

 

}
