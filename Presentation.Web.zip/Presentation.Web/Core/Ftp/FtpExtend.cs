﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   FtpExtend.cs
 *   描    述   ：    FTP扩展类
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Core.Ftp
{
    /// <summary>
    /// FTP扩展类
    /// </summary>
    public static class FtpExtend
    {
        /// <summary>
        /// 文件扩展名对应文件类型转换表
        /// </summary>
        public static string FileGetMIMEType(this string strFileType)
        {
            string strReturn = "";
            switch (strFileType.ToLower())
            {
                case "avi":   //视频文件
                    strReturn = "video/x-msvideo";
                    break;
                case "aif":   //声音文件
                case "aiff":
                case "aifc":
                    strReturn = "audio/x-aiff";
                    break;
                case "au":    //声音文件
                case "snd":
                    strReturn = "audio/basic";
                    break;
                case "ai":
                case "eps":
                case "ps":
                    strReturn = "application/postscript";
                    break;
                case "asd":
                case "asn":
                    strReturn = "application/astound";
                    break;
                case "exe":   //二进制数据文件
                case "com":
                case "dll":
                case "class":
                    strReturn = "application/octet-stream";
                    break;
                case "bin":
                    strReturn = "application/x-macbinary";
                    break;
                case "csv":
                    strReturn = "text/comma-separated-values";
                    break;
                case "css":     //Css(样式表文件)
                    strReturn = "text/css";
                    break;
                case "dwg":    //AutoCAD文件
                    strReturn = "application/acad";
                    break;
                case "dxf":    //AutoCAD文件
                    strReturn = "application/dxf";
                    break;
                case "dcr":
                case "dir":
                case "dxr":
                    strReturn = "application/x-director";
                    break;
                case "docx":
                     strReturn = "application/vnd.openxmlformats-officedocument.wordprocessingml.template";  //Word类型文件
                    break;           
                case "doc":
                case "dot":
                    strReturn = "application/msword";  //Word类型文件
                    break;
                case "dotx":
                    strReturn = "application/vnd.openxmlformats-officedocument.wordprocessingml.template";  
                    break;
                case "gz":       //GNU压缩格式文件
                    strReturn = "application/gzip";
                    break;
                case "gif":
                    strReturn = "image/gif";
                    break;
                case "hlp":
                case "chm":
                    strReturn = "application/mshelp";
                    break;
                case "htm":
                case "html":
                case "shtml":
                    strReturn = "text/html";
                    break;
                case "js":
                    strReturn = "text/javascript";
                    break;
                case "jpeg":
                case "jpg":
                case "jpe":
                    strReturn = "image/jpeg";
                    break;
                case "mpeg":
                case "mpg":
                case "mpe":
                    strReturn = "video/mpeg";
                    break;
                case "mp3":
                    strReturn = "audio/mpeg";
                    break;
                case "qt":
                case "mov":
                    strReturn = "video/quicktime";
                    break;
                case "mdb":
                    strReturn = "application/msaccess";
                    break;
                case "ppt":
                case "ppz":
                case "pps":
                case "pot":
                    strReturn = "application/mspowerpoint";
                    break;
                case "pptx":
                    strReturn = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
                    break;
                case "pdf":
                    strReturn = "application/pdf";
                    break;
                case "rar":
                    strReturn = "application/octet-stream";
                    break;
                case "rtf":
                    strReturn = "application/rtf";
                    break;
                case "rtx":
                    strReturn = "text/richtext";
                    break;
                case "ram":
                case "ra":
                    strReturn = "audio/x-pn-realaudio";
                    break;
                case "rm":
                case "rmvb":
                    strReturn = "application/vnd.rn-realmedia";
                    break;
                case "swf":
                case "cab":
                    strReturn = "application/x-shockwave-flash";
                    break;
                case "txt":
                    strReturn = "text/plain";
                    break;

                case "xls":
                case "xla":
                    strReturn = "application/vnd.ms-excel";
                    break;
               case "xlsx":
                    strReturn = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                    break;
                case "z":
                    strReturn = "application/x-compress";
                    break;
                case "zip":
                    strReturn = "application/x-zip-compressed";
                    break;
                default:
                    strReturn = "application/octet-stream";
                    break;
            }
            return strReturn;
        }
    }
}