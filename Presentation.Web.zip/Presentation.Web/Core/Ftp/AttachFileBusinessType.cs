﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Core
{
    /// <summary>
    /// 附件业务类型
    /// </summary>
    public class AttachFileBusinessType
    {

        /// <summary>
        /// 材料管理
        /// </summary>
        public const string MaterialManage = "MaterialManage";

        /// <summary>
        /// 盘点
        /// </summary>
        public const string Inventory = "Inventory";

        /// <summary>
        /// 处置申请
        /// </summary>
        public const string ApplyDeal = "ApplyDeal";

        /// <summary>
        /// 废物货包审核
        /// </summary>
        public const string WastePackageCheck = "WastePackageCheck";

        /// <summary>
        /// 废物货包审批
        /// </summary>
        public const string WastePackageDisposal = "WastePackageDisposal";

        /// <summary>
        /// 档案
        /// </summary>
        public const string Document = "Document";
    }
}