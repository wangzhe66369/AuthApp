﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   FtpFileStore.cs
 *   描    述   ：   FTP操作
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using NET01.CoreFramework.Ftp;
using Microsoft.Practices.ServiceLocation;
using System.Configuration;


namespace RWIS.Presentation.Web.Core.Ftp
{
    /// <summary>
    ///  FTP操作
    /// </summary>
    public class FtpFileStore
    {
        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="fileBase">上传文件对象</param>
        /// <param name="uloadFileInputId">业务类型(文件夹)</param>
        /// <returns>Guid</returns>
        public static Guid SaveUploadedFile(HttpPostedFileBase fileBase, string businessType)
        {
            var identifier = Guid.NewGuid();
            try
            {
                IFtpClient ftp = ServiceLocator.Current.GetInstance<IFtpClient>();

                if (!string.IsNullOrEmpty(businessType))
                {
                    ftp.SetDirectory(businessType, true);
                }

                var filename = identifier + fileBase.FileName.Substring(fileBase.FileName.LastIndexOf('.'));
                ftp.Upload(fileBase.InputStream, filename);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return identifier;
        }

        /// <summary>
        /// 下载文件
        /// </summary>
        public static Stream DownFile(string fileName, string businessType)
        {
            try
            {
                IFtpClient ftp = ServiceLocator.Current.GetInstance<IFtpClient>();
                ftp.SetDirectory(businessType, false);
                return ftp.Download(fileName);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// 删除文件
        /// </summary>
        public static void DeleteFile(string fileName, string businessType)
        {
            try
            {
                IFtpClient ftp = ServiceLocator.Current.GetInstance<IFtpClient>();
                ftp.SetDirectory(businessType, false);
                ftp.Delete(fileName);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        /// <summary>
        /// 下载文件流
        /// </summary>
        public static Stream DownFileMemoryStream(string fileName, string businessType)
        {
            Stream stream = DownFile(fileName, businessType);
            return stream.CopyToMemory();
        }
        /// <summary>
        /// 判断文件是否存在
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="businessType"></param>
        /// <returns></returns>
        public static bool IsExistsFile(string fileName, string businessType)
        {
            IFtpClient ftp = ServiceLocator.Current.GetInstance<IFtpClient>();
            ftp.SetDirectory(businessType, false);
            return ftp.FileExist(fileName);
        }
    }
}