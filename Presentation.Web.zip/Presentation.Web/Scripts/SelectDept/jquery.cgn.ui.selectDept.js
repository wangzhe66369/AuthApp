﻿/*
* Name:SelectDept 部门选择组件
* Author:PCITOYT
* Version:1.0

* Version:1.1    
* 1、将_createContent转移到绑定事件中，保证每次使用时才创建内容
* 2、添加是否初始化内容的私有属性：contentIsInit
*
* Depends:
 *	jquery-1.8.3.js
 *	jquery.ui-1.10.1.js
 *	jquery.ztree-3.5.js
 *	jquery.ztree.excheck-3.5.js
 *  jquery.ztree.exhide-3.5.js
*/
(function ($, undefined) {

    var _consts = {
        id: {
            DIV: "_deptselection",
            LOADING: "_loading",
			DATA_NOT_FOUND:"_notFound",
            DIALOG: "_dialog",
			TIP:"_tip",
			INPUT:"_input",
			TREE:"_tree",
			LANG_JS:"_deptselection_lang"
        }
	};

    $.widget("cgnui.selectDept", {
        version: "1.0",
        deptselectionId: "",
		fileName:"cgn.ui.selectdept.js",
	    requestCount:0,
		initData:[],
		matchedNodes:[],
		tempSelectedDept:[],
		selectedDept:[],
		loadedDept:[],
		//0：查询未开始  1：查询完毕
		searchStatus: 0,
		//对话框内容是是否初始化
		contentIsInit: false,
	    //计时器对象
		timeCount:null,
        options: {
			//附加容器
            appendTo: "body",
		    //超时时间30s
			timeout:30000,
			//语言
			lang:'zh-cn',
			//触发事件类型
			eventType:"click",
            height: 420,
            width: 400,
			//是否为模态窗口
            modal: true,
			//标题名称
            title: "",
			//是否多选
            selectedMulti: false,
		    //默认选中的id
			selectedId:null,
			//数据源
			source:null,
			rootId:null,
			//属性映射
			dataMapping:{
				idKey:"Id",
				pIdKey:"PId",
				name:"Name",
				title:"Name",
				children:"children",
				checked:"Checked",
				matched:"matched",
				url:"url"
			},
			search:{
				//查询关键字名称
				key:"keyWord",
				//前端搜索属性(仅数据源为数组时适用)
				clientSearchAttrs:'',
				//搜索提示信息
				inputTip:'',
				//最小查询字符数
				minChars: 3,
				//延时时间
				delay: 500
			},
			//数据默认为json
			dataType:"json",
			//jsonp回调函数，当dataType="jsonp"时设置
			jsonpCallback:"callback",
			//是否异步
			async:false,
			//最大选择数，默认不限制
		    maxSelectNum:0,
		    //点击确认按钮回调的函数
            ok: null,
		    //点击取消按钮回调的函数
            cancel: null
        },

        _create: function () {
			
            var self = this,
                doc = this.element[0].ownerDocument,
                maxZ = 0,
                thisZ;
            self.deptselectionId = self.element[0].id + _consts.id.DIV;

			

            //set control Z-index To max
            $('.ui-dialog').each(function () {
                if (this !== self.element[0]) {
                    thisZ = $(this).css('z-index');
                    if (!isNaN(thisZ)) {
                        maxZ = Math.max(maxZ, thisZ);
                    }
                }
            });
            $.ui.dialog.maxZ = maxZ;


			
			//获取js文件所在目录
			var js=document.scripts;
			var jsPath;
			for(var i=js.length;i>0;i--){
			 if(js[i-1].src.toLowerCase().indexOf(self.fileName)>-1){
			   var langScript=js[i-1];
			   jsPath=js[i-1].src.substring(0,js[i-1].src.lastIndexOf("/")+1);
			   break;
			 }
			}

			var existsLang=false;

			var url=jsPath+"lang/";

			//检查语言文件是否存在
			for(var i=js.length;i>0;i--){
				if(js[i-1].src.toLowerCase().indexOf(url)>-1){
					existsLang=true;
					break;
				}
			}

			//如果不存在，则动态加载语言文件
			if(!existsLang){
				//设置语言
				self.options.lang=self._getRealLang();
				var jsUrl=jsPath+"lang/"+self.options.lang+".js";
				//加载语言文件
				self._loadLang(jsUrl,url,function(){
					//在init时候创建弹出框内容
                    //self._createContent();
				});
			}
			
        },

		_createContent:function(){
		    var self = this;

			if (self.contentIsInit) {
			    return false;
			}
			
			//内部容器宽度
			var innerContainerWidth=self.options.width - 32;

			var remainHeight=self.options.selectedMulti?230:150;

			if(!self.options.title){
				self.options.title=$cgn_ui_selectDept_lang.titleText;
			}
			if(!self.options.search.inputTip){
				self.options.search.inputTip=$cgn_ui_selectDept_lang.inputTipText;
			}
			
			 //输入控件
            self.inputControl = $("<input></input>")
                .attr("id", self.deptselectionId+_consts.id.INPUT)
                .attr("type", "text")
				.attr("maxLength",30)
				.val(self.options.search.inputTip)
				.bind("keyup",function(event){
					if(event.keyCode==16||(event.keyCode>=37&&event.keyCode<=40)){
						return ;
					}
					if(event.keyCode==13){
						var text= $.trim(self.inputControl.val());
						if(text.length>0&&text.length<self.options.search.minChars){
							alert($cgn_ui_selectDept_lang.minInputCharText.replace("{0}",self.options.search.minChars));
							return;
						}
						if(self.searchStatus==0){
							self._prepareSearch(self);
						}else{
							//回车快捷选择
							self._shortcutSelect(self);
						}
					}else{
						self._prepareSearch(self);
					}
				})
				.bind("focus",function(){
					if(this.value==self.options.search.inputTip){
						this.value='';
						this.style.color='#000';
					}
				})
				.bind("blur",function(){
					if(!this.value){
						this.value=self.options.search.inputTip;
						this.style.color='#999'
					}
				})
                .addClass("ui-deptselection-input")
				.css("background-position",innerContainerWidth-15+"px"+" 6px")
				.css("width",innerContainerWidth);
			
			//加载提示
            self.dataLoading = $("<div></div>").append($cgn_ui_selectDept_lang.loadingText)
                .attr("id", self.element[0].id + _consts.id.LOADING)
                .addClass("mvcui-deptselection-loading")
				.css("width",innerContainerWidth)
				.hide();

			//没有找到数据
            self.dataNotFound = $("<div></div>").append($cgn_ui_selectDept_lang.dataNotFoundText)
                .attr("id", self.element[0].id + _consts.id.DATA_NOT_FOUND)
                .addClass("mvcui-deptselection-dataNotFound")
				.css("width",innerContainerWidth)
				.hide();

			//树
            self.ztree = $("<ul></ul>")
                .addClass("ztree")
				.bind("keyup",function(event){
					if(event.keyCode==13){
						self._confirmClose();
					}
				})
				.css("background-color","#fffff")
                .css("height", self.options.height - remainHeight)
                .css("width", innerContainerWidth)
                .attr("id", self.deptselectionId+_consts.id.TREE)
				.css("overflow-y","auto")
                .attr("EnableMulti", self.options.selectedMulti);
			
			//选择提示
            self.selectedDeptMsg=$("<span></span>")
				.addClass("ui-deptselection-selectedtip")
				.append($cgn_ui_selectDept_lang.selectedDeptText);

		    //部门选择限制提示
			self.addMsg=$("<span></span>")
				.append($cgn_ui_selectDept_lang.maxSelectedNumText.replace("{0}",self.options.maxSelectNum))
                .addClass("ui-deptselection-warnning")
				.css("display","none")
				.attr("id", self.deptselectionId+_consts.id.TIP);


			//所选部门显示区域
            self.chooseUserArea = $("<ul></ul>")
                .addClass("chosen-choices")
				.attr("id",self.deptselectionId+"_container");


		    //部门选择对话框表格容器
            self.deptselectionMainTable = $("<table></table>")
				.addClass("mainContainer")
				.attr("cellpadding", "0")
				.attr("cellspacing", "0");
			
			//容器
			var ztreeContainer=$("<div></div>").addClass("ui-deptselection-ztreeContainer");
			ztreeContainer.append(self.dataLoading);
			ztreeContainer.append(self.dataNotFound);
			ztreeContainer.append(self.ztree);

            $("<tr></tr>").append($("<td></td>").append(self.inputControl)).appendTo(self.deptselectionMainTable);
            $("<tr></tr>").append($("<td></td>").append(ztreeContainer)).appendTo(self.deptselectionMainTable);

			//如果是多选就显示容器面板
			if(self.options.selectedMulti){
				$("<tr></tr>").append($("<td></td>").append(self.selectedDeptMsg).append(self.addMsg)).appendTo(self.deptselectionMainTable);
				$("<tr></tr>").append($("<td></td>").append(self.chooseUserArea)).appendTo(self.deptselectionMainTable);
			}

            self.dialogContainer = $("<div></div>")
                .attr("title", self.options.title)
                .attr("id", self.element[0].id + _consts.id.DIALOG)
                .addClass("mvcui-deptselection")
                .append(self.deptselectionMainTable)
                .appendTo(self.options.appendTo==null?$("body"):$(self.options.appendTo));

			self.dialogContainer.dialog({
                autoOpen: false,
                height: self.options.height,
                width: self.options.width,
                modal: self.options.modal,
				closeText:$cgn_ui_selectDept_lang.closeText,
                resizable: false,
                buttons: [
                {
                    text: $cgn_ui_selectDept_lang.okText,
                    icons: { primary: "ui-icon-ok" },
                    click: function () {						
                        if (typeof self.options.ok === "function") {
                            self.element.trigger("ok.selectDept");
                        }
                        $(this).dialog("close");
                    }
                }, {
                    text: $cgn_ui_selectDept_lang.cancelText,
                    icons: { primary: "ui-icon-cancel" },
                    click: function () { 
						if(self.options.cancel&&typeof self.options.cancel === "function"){
							self.options.cancel();
						}
						$(this).dialog("close"); 
					}
                }],
				beforeClose:function(){
					if(event.keyCode==0){
						//return false;
					}
				}
            });
            //内容初始化完毕
            self.contentIsInit = true;
		},

        destroy: function () {
            $.Widget.prototype.destroy.call(this);
        },

		
        _setOption: function (key, value) {
           // $.Widget.prototype._setOption.apply(this, arguments);
			/*
            if (key === "source") {
                this._initSource();
            }
            if (key === "disabled" && value && this.xhr) {
                this.xhr.abort();
            }
			*/
        },

        _init: function () {
           var self = this;
		   
		   //最小字符数1
		   if(self.options.search.minChars<=0){
			  self.options.search.minChars==1;
		   }

            if (typeof self.options.ok === "function") {
                self.element.bind('ok.selectDept', function (event, parames) {
					//赋值给选择部门
					self.selectedDept=self.tempSelectedDept.slice(0);

                    var returnItems = self.selectedDept;
					if(!self.options.selectedMulti){
						returnItems=returnItems.length>0?returnItems[0]:null;
					}

                    //执行事件
                    self.options.ok.apply("", [event, returnItems]);
                    //阻止事件冒泡
                    event.stopPropagation();
                });
            }

            self.element.bind(self.options.eventType, function () {
                self._createContent();
				var that=this;
				self.dialogContainer.dialog("open");
				//清空输入框的值
				self.inputControl.val("");
				//初始化数据源
				self._initSource();
			})
        },

		//初始化数据源
        _initSource: function () {
		   
           var self = this;
		   
		   this.dataNotFound.hide();
           if (typeof self.options.source === "string") {	
				//检查是否已经请求
			    if(self.requestCount>0)
			    {
					self._renewStatus();
					 //赋值给临时部门
					self.tempSelectedDept=self.selectedDept.slice(0);
					
					self._refreshSelectedNode(self.selectedDept);

					if(self.options.selectedMulti){
						self._refreshSelectedDeptContainer(self.selectedDept);
					}
			    }else{
					$.ajax({
						url: self.options.source,
						timeout:self.options.timeout,
						dataType:self.options.dataType,
						jsonp:self.options.jsonpCallback,
						data:{"selectedId":self.options.selectedId,"rootId":self.options.rootId},
						success: function (d) {
							 self.initData=d.data.slice(0);
							 if(d.selectedDept){
								self.selectedDept=d.selectedDept;
							 }
							 self._response(d.data);
							 if(d.data.length==0){
								self.dataNotFound.show();
							 }
							 self._fillData();
							 self.requestCount++;
						},
						beforeSend:function(){
							self._showLoading();
						},
						complete:function(){
							self.dataLoading.hide();
						},error:function(e){
							alert("error:"+e.statusText);
						}
					});
				}
            }else{
				self.initData=self.options.source.slice(0);
				if(self.initData.length>0){
					self._response(self.initData);
				}

                //赋值给临时部门
				self.tempSelectedDept=self.selectedDept.slice(0);
				
				self._refreshSelectedNode(self.selectedDept);

				if(self.options.selectedMulti){
					self._refreshSelectedDeptContainer(self.selectedDept);
				}
            }
        },

		//恢复到初始状态
		_renewStatus: function () {
		   var self = this;
			if(self.initData.length>0){
				self._response(self.initData);
			}
			//根据临时选择部门恢复选择状态
			self._refreshSelectedNode(self.tempSelectedDept);

			if(self.options.selectedMulti){
				self._refreshSelectedDeptContainer(self.tempSelectedDept);
			}
        },

		_fillData:function(){
			var self=this;

			if(self.options.selectedId&&self.selectedDept.length==0){
				 if (typeof self.options.source === "string"&&self.options.async) {	
					
				 }else{
					 
					var selectedIdArr=self.options.selectedId.split(',');
					var sDept=[];
					for(var i=0;i<self.initData.length;i++){
						var item=self.initData[i];
						if(item){
							if(self.options.selectedMulti){
								for(var j=0;j<selectedIdArr.length;j++){
									if(selectedIdArr[j]){
										if(item[self.options.dataMapping.idKey]==selectedIdArr[j]){
											sDept.push(item);
										}	
									}
								}
							}else{
								if(selectedIdArr[0]){
									if(item[self.options.dataMapping.idKey]==selectedIdArr[0]){
										sDept.push(item);
									}	
								}
							}
						}
					}

					self.selectedDept=sDept.slice(0);
					
				 }
			}

			//赋值给临时部门
			self.tempSelectedDept=self.selectedDept.slice(0);
			
			self._refreshSelectedNode(self.selectedDept);

			if(self.options.selectedMulti){
				self._refreshSelectedDeptContainer(self.selectedDept);
			}
		},

		//加载tree数据
        _response: function (content) {
			var self=this;
            if (content) {

                var setting = {
                    view: { 
						selectedMulti: false
					},
                    check: { enable: true,
                        chkStyle: "radio",
                        radioType: "all",
						chkboxType: { "Y": "", "N": "" }
                    },
                    data: { 
						key:{
							checked:self.options.dataMapping.checked,
							children:self.options.dataMapping.children,
							name:self.options.dataMapping.name,
							title:self.options.dataMapping.title,
							url:self.options.dataMapping.url
						},
						simpleData: { 
							enable: true,
							idKey:self.options.dataMapping.idKey,
							pIdKey:self.options.dataMapping.pIdKey 
						}
                    },
					async:{
						enable:self.options.async,
						url:function(){
							return self.options.source;
						},
						dataType:"jsonp",
						autoParam:[self.options.dataMapping.idKey],
						otherParam:[],
						dataFilter:function(treeId, parentNode, responseData){
							return responseData.data;
						}
					},
                    callback: {
						beforeCheck:function(treeId, treeNode){
							if(self.options.selectedMulti&&self.options.maxSelectNum>0){
								if(!treeNode[self.options.dataMapping.checked]){
									if(self.tempSelectedDept.length>=self.options.maxSelectNum){
										$("#"+self.deptselectionId+_consts.id.TIP).show();
										return false;
									}
								}
								$("#"+self.deptselectionId+_consts.id.TIP).hide();
							}
							return true;
						},
						onCheck:function(event,treeId,treeNode){
							//根据节点状态添加或移除一个部门
							if(self.options.selectedMulti){  
								if(treeNode[self.options.dataMapping.checked]){
									self._addDept(treeNode);
									//自动定位到滚动条底部
									$(self.chooseUserArea).scrollTop($(self.chooseUserArea).get(0).scrollHeight);
								}else{
									self._removeDept(treeNode[self.options.dataMapping.idKey]);
								}
							}else{
								if(self.tempSelectedDept&&self.tempSelectedDept.length>0){
									self._removeDept(self.tempSelectedDept[0][self.options.dataMapping.idKey]);
								}
								if(treeNode[self.options.dataMapping.checked]){
									self._addDept(treeNode);
								}
							}
						},
						onClick:function(event,treeId,treeNode){
		
							var treeObj=self._getZTree();
							
							var flag=true;
							if(self.options.selectedMulti&&self.options.maxSelectNum>0){
								if(!treeNode[self.options.dataMapping.checked]){
									if(self.tempSelectedDept.length>=self.options.maxSelectNum){
										$("#"+self.deptselectionId+_consts.id.TIP).show();
										flag= false;
									}
								}
							}
							if(flag){
								$("#"+self.deptselectionId+_consts.id.TIP).hide();
								//自定触发onCheck事件
								treeObj.checkNode(treeNode,!treeNode[self.options.dataMapping.checked]);
								treeObj.setting.callback.onCheck(event,treeId,treeNode);
							}
						},
                        onDblClick: function (event, treeId, treeNode) {
							if (treeNode&&!self.options.selectedMulti) {

								if(self.tempSelectedDept&&self.tempSelectedDept.length>0){
									self._removeDept(self.tempSelectedDept[0][self.options.dataMapping.idKey]);
								}

								//if(!treeNode[self.options.dataMapping.checked]){
									treeNode[self.options.dataMapping.checked]=true;
									self._addDept(treeNode);
								//}

								var elementId = treeId.split('_')[0];
								$("#" + elementId).trigger("ok.selectDept", { IsDlbClick: true, TreeNode: treeNode });
								self.dialogContainer.dialog("close");
							}
						},
						onAsyncError :function(data){
							alert("zTree加载数据失败！");
						},
						onAsyncSuccess :function(event,treeId,treeNode,msg){
							if(msg.data&&msg.data.length>0){
								self.dataNotFound.hide();
								var treeObj=self._getZTree();
								$(treeObj.transformToArray(treeObj.getNodes())).each(function(i,node){
									self._checkedNode(node);
								});

								if(treeNode&&treeNode.children){
									$(treeNode.children).each(function(i,node){
										//添加部门到已加载部门列表
										self._addDeptToList(node);
									});
								}	
							}else{
								self.dataNotFound.show();
							}
							
							self.dataLoading.hide();								
						},
						beforeAsync: function(){
							self._showLoading();
						},
						onExpand:function(event,treeId,treeNode){
							$(treeNode.children).each(function(i,node){
								self._checkedNode(node);
							});
						}
                    }
                };

                if (this.options.selectedMulti) {
                    setting.check.chkStyle = "checkbox";
                    setting.callback.onDblClick = null;
                }

				$.fn.zTree.init(this.ztree, setting, content);
            }
        },


		//添加一个部门
		_addDept:function(dept){
			var self=this;
			self._addDeptToList(dept);
			self.tempSelectedDept.push(dept);
			//刷新已选部门列表
			self._refreshSelectedDeptContainer(self.tempSelectedDept);
		},

		//添加一个部门到列表
		_addDeptToList:function(dept){
			var self=this;
			if(self._deptIsExists(dept[self.options.dataMapping.idKey],self.loadedDept)){
				return;
			}
			self.loadedDept.push(dept);
		},

		//勾选节点
		_checkedNode:function(node){
			var self=this;
			if(self._deptIsExists(node[self.options.dataMapping.idKey],self.tempSelectedDept)){
				self._getZTree().checkNode(node,true);
			}
		},

		//刷新勾选节点
		_refreshCheckedNode:function(node){
			var self=this;
			var flag=self._deptIsExists(node[self.options.dataMapping.idKey],self.tempSelectedDept);
			self._getZTree().checkNode(node,flag);
		},


		//获取已经加载的部门列表
		_getLoadedDept:function (){
			var self=this;
			
			return self.loadedDept;
		},

	    //移除一个部门
		_removeDept:function(id){
			var self=this;
			var d;
			$(self.tempSelectedDept).each(function(i,e){
				if(e[self.options.dataMapping.idKey]==id){
					d=e;
				}
			});

			if(d){
				//移除临时列表中的一个部门
				self.tempSelectedDept.splice($.inArray(d,self.tempSelectedDept),1); 
			}
			self._refreshSelectedDeptContainer(self.tempSelectedDept);
		},

		 //从容器中移除一个部门面板
		_removePanelFromContainer:function(id){
			var self=this;
			//移除一个部门
			self._removeDept(id);

			//根据临时部门重新绑定Container
			self._refreshSelectedDeptContainer(self.tempSelectedDept);
			self._refreshSelectedNode(self.tempSelectedDept);
			//显示选择上限提示
			if(self.options.maxSelectNum>0&&self.tempSelectedDept.length<=self.options.maxSelectNum){
				$("#"+self.deptselectionId+_consts.id.TIP).hide();
			}
		},

	    //刷新选择的节点
		_refreshSelectedNode:function (deptList) {
			var self = this;
            var treeObj = self._getZTree();

			$.each(treeObj.transformToArray(treeObj.getNodes()),function (i, node) {
				self._refreshCheckedNode(node);
            });
        },
	
		//刷新选择的部门
        _refreshSelectedDeptContainer: function (deptList) {
            var self = this;
			self.chooseUserArea.empty();
			$.each(deptList,function (i, item) {

				var id=item[self.options.dataMapping.idKey];
				var name=item[self.options.dataMapping.name];
				var deptTemplate = "{0}.{2}".replace("{0}", i+1).replace("{2}", name);
				
				this.User = $("<li></li>")
				.addClass("search-choice")
				.bind("keydown", function (event) {
					return false;
				})
				$("<span id='"+id+"'></span>").append(deptTemplate).appendTo(this.User);
				$("<a></a>")
				.bind("click",function(){
					self._removePanelFromContainer(id);
				})
				.appendTo(this.User);
				this.User.appendTo(self.chooseUserArea);
            });
        },


		//准备查询
		_prepareSearch:function(obj){
			var self=obj;
			var text= $.trim(self.inputControl.val());

            var treeObj = self._getZTree();

			if(!treeObj){
				return ;
			}

			if(self.options.timeCount){
				//不管存不存在延时执行函数，先清除
				clearTimeout(self.options.timeCount);
			}


			if(text.length==0){
				this.dataNotFound.hide();
				//恢复查询状态
				self.searchStatus=0;
				if(typeof this.options.source === "string"){
					self._renewStatus();
				}else{
					var allNode = treeObj.transformToArray(treeObj.getNodes());  
					treeObj.showNodes(allNode);
				}
			}else if(text.length>=self.options.search.minChars){

				self.searchStatus=1;
				//最小计时器为300ms
				self.options.search.delay=self.options.search.delay<300?300:self.options.search.delay;

				//只要有输入则不执行查询操作
				self.options.timeCount = setTimeout(function(){
					if(typeof self.options.source === "string"){
						self._executeSearch(obj,treeObj,text);
					}else{
						self._executeNodeSearch(obj,treeObj,text);
					}
				},self.options.search.delay<300?300:self.options.search.delay);	
			}

		},

		//执行远程查询
		_executeSearch:function(obj,treeObj,text){
			var self=obj;
			//编码查询条件
			text=encodeURIComponent(text);
			if(self.options.async){
				treeObj.setting.async.otherParam={"keyWord":text,"rootId":self.options.rootId};
				$.fn.zTree.init(self.ztree, treeObj.setting);
				treeObj.setting.async.otherParam={"keyWord":null,"rootId":self.options.rootId};
			}else{
				$.ajax({
					url: self.options.source,
					dataType:self.options.dataType,					
					timeout:self.options.timeout,
					data:{"keyWord":text,"rootId":self.options.rootId},
					jsonp:self.options.jsonpCallback,
					success: function (d) {
						 self._response(d.data);
						 self._fillData();
						 if(d.data.length==0){
							self.dataNotFound.show();
						 }
					},
					beforeSend:function(){
						self._showLoading();
					},
					complete:function(){
						self.dataLoading.hide();
					}
				});
			}
		},
		
		//执行节点搜索
		_executeNodeSearch:function(obj,treeObj,text){
			var self=obj;
			self.matchedNodes=[];
			self.options.search.clientSearchAttrs=self.options.search.clientSearchAttrs||self.options.dataMapping.name;
			var searchKeysArr=self.options.search.clientSearchAttrs.split(',');

			var allNode = treeObj.transformToArray(treeObj.getNodes());  
			$(allNode).each(function(i,node){
				//清空匹配项
				node[self.options.dataMapping.matched]=false;
			});

			self.matchedNodes = treeObj.getNodesByFilter(function(node){
				var flag=false;
				for(var key in searchKeysArr){
					if(node[searchKeysArr[key]]){
						flag= node[searchKeysArr[key]].indexOf(text)>-1;
						if(flag){
							node[self.options.dataMapping.matched]=true;
							break;
						}
					}					
				}
				return flag;
			}); 

			treeObj.hideNodes(allNode);  

			for(var i=0;i<self.matchedNodes.length;i++){
				 self._findChildren(self.matchedNodes[i],self); 
			}  

			for(var i=0;i<self.matchedNodes.length;i++){
				 self._findParent(treeObj,self.matchedNodes[i]);  
			}  

			if(self.matchedNodes.length==0){
				self.dataNotFound.show();
			}else{
				self.dataNotFound.hide();
			}
			
			treeObj.showNodes(self.matchedNodes);
		},

		//快捷选择
		_shortcutSelect:function(self){
			var treeObj = self._getZTree();
			if(treeObj){
				var nodes=treeObj.transformToArray(treeObj.getNodes());  
				var treeNode=null;
				//获取匹配的第一个节点
				for(var i=0;i<nodes.length;i++){
					if(nodes[i][self.options.dataMapping.matched]){
						treeNode=nodes[i];
						break;
					}
				}
				if(treeNode){
					if(!treeNode[self.options.dataMapping.checked]){
						if(!self.options.selectedMulti){  //单选
							if(self.tempSelectedDept&&self.tempSelectedDept.length>0){
								self._removeDept(self.tempSelectedDept[0][self.options.dataMapping.idKey]);
							}
							treeObj.checkNode(treeNode,true);
							self._addDept(treeNode);
							self._confirmClose();
						}else{
							treeObj.checkNode(treeNode,true);
							self._addDept(treeNode);
							self.inputControl.select();
						}
					}					
				}
			}
		},

		//确认关闭
		_confirmClose:function(){
			var self=this;
			self.element.trigger("ok.selectDept");
		    self.dialogContainer.dialog("close");
		},
		
		//查找父节点
		_findParent:function(treeObj,node){  
			 var self=this;
             var pNode = node.getParentNode();  
             if(pNode != null){  
				 treeObj.expandNode(pNode,true,false,false);  
                 self.matchedNodes.push(pNode);  
                 self._findParent(treeObj,pNode);  
             }  
         }, 

		//查找子节点
	    _findChildren:function(node,o){  
			 var self=o;
			 if(node.children&&node.children.length>0){
				$(node.children).each(function(i,e){
					self.matchedNodes.push(e);  
					self._findChildren(e,self);  
				});
			 }
         }, 

		//部门是否存在
		_deptIsExists:function(id,deptList){
			var self=this;
			var isExists=false;
			if(id&&deptList){
				for(var i=0;i<deptList.length;i++){
					if(id==deptList[i][self.options.dataMapping.idKey]){
						isExists=true;
						break;
					}
				}
			}
			return isExists;
		},

		
		//获取zTree树
		_getZTree:function(){
			var self=this;
			return $.fn.zTree.getZTreeObj(self.deptselectionId+_consts.id.TREE);
		},

		//加载语言包
	   _loadLang:function (jsUrl,url, fn) { 

		    var self=this;

			var js=document.scripts;
			var script=null;
			var headHtml=$("head")[0].innerHTML;
			//检查js文件是否已经加载
			if(headHtml.indexOf(url)==-1){
				script = $("<script></script>")
				.attr("type","text/javascript")
				.attr("id",_consts.id.LANG_JS)
				.attr("src",jsUrl);

				document.getElementsByTagName("head")[0].appendChild(script.get(0)); 
			}else{
				script=$("#"+_consts.id.LANG_JS);
			}

			if($.browser.msie){   //IE
				script.bind("readystatechange",function () { 
					 if (script.get(0).readyState == 'loaded' || script.get(0).readyState == 'complete') { 
						fn instanceof Function && fn.call(); 
					} 
				}); 
			}else{   //其它
				script.bind("load",function () { 
					fn instanceof Function && fn.call(); 
				}); 
			}

		} ,


	   //获取语言
	   _getRealLang:function(){
			var self=this;
			if(!self.options.lang||self.options.lang=='auto'){
			   return navigator.browserLanguage.toLowerCase();
			}
			return self.options.lang;
		},

		//显示正在加载中
		_showLoading:function(){
			var self=this;
			self.dataNotFound.hide();
			self.dataLoading.show();
		}
    });

	/*
	* 扩展方法
	*/
	$.fn.extend({

		
		//卫星库部门
		selectCGNDept:function(opts){
			var options={
				dataMapping:{
					idKey:"DeptId",
					pIdKey:"DeptParentId",
					name:"DeptName",
					title:"DeptNamePath"
				},
				dataType:"jsonp",
				async:true,
				search:{
					//查询关键字名称
					keyName:"keyWord"
				}
			};
			options=$.extend({},options,opts);
			$(this).selectDept(options);
		},

	    //虚拟组织机构
		selectVirtualOrg:function(opts){
			var options={
				dataMapping:{
					idKey:"OrgId",
					pIdKey:"ParentOrg",
					name:"OrgName",
					title:"OrgName"
				},
				dataType:"jsonp",
				async:true,
				search:{
					//查询关键字名称
					keyName:"keyWord"
				}
			};
			options=$.extend({},options,opts);
			$(this).selectDept(options);
		},

        //工程虚拟组织机构        selectCNPECVirtualOrg: function (opts) {
			var options={
				dataMapping:{
				    idKey: "OrgId",
					pIdKey:"ParentOrg",
					name:"OrgName",
					title:"OrgName"
	            },
	            rootId: "4700",
				dataType:"jsonp",
				async:true,
				search:{
					//查询关键字名称
				    keyName: "keyWord",
                    //最小配置字符数（输入两个字符就开始查询）
                    minChars:2
				}
			};
			options=$.extend({},options,opts);
			$(this).selectDept(options);
		}

	});

})(jQuery);
