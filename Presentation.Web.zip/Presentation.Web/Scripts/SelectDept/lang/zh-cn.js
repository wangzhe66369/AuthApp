﻿var $cgn_ui_selectDept_lang={
okText:"确定",
cancelText:"取消",
closeText:"关闭",
titleText:"选择部门",
loadingText:"数据加载中......",
dataNotFoundText:"没有找到符合条件的数据",
inputTipText:"请输入部门三字码/名称",
selectedDeptText:"已选部门",
maxSelectedNumText:"最多只能选择{0}个部门",
minInputCharText:"至少输入{0}个字符"
};