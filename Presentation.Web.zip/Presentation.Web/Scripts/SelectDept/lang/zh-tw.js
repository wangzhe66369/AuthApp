﻿var $cgn_ui_selectDept_lang={
okText:"確定",
cancelText:"取消",
closeText:"關閉",
titleText:"選擇部門",
loadingText:"數據加載中......",
dataNotFoundText:"沒有找到符合條件的數據",
inputTipText:"請輸入部門編碼/名稱",
selectedDeptText:"已選部門",
maxSelectedNumText:"最多只能選擇{0}個部門",
minInputCharText:"至少輸入{0}個字符"
};