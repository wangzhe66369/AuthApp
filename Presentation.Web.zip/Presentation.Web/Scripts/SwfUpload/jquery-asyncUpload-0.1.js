﻿(function ($) {
    $.fn.makeAsyncUploader = function (options) {
        return this.each(function () {
            //获取上传控件的ID
            var id = $(this).attr("id");
            var container = $("<span class='asyncUploader'/>");
            container.append($("<div class='ProgressBar'><div>&nbsp;</div></div>"));
            container.append($("<span id='" + id + "_completedMessage'/>"));
            container.append($("<span id='" + id + "_uploading'>Uploading... <input type='button' value='取消'/></span>"));
            container.append($("<span id='" + id + "_swf'/>"));
            container.append($("<input type='hidden' name='" + id + "_filename'/>"));
            container.append($("<input type='hidden' name='" + id + "_guid'/>"));
            container.append($("<input type='hidden' name='" + id + "_filesize'/>"));
            container.append($("<input type='hidden' name='" + id + "_businesstype'/>"));
            $(this).before(container).remove();
            $("div.ProgressBar", container).hide();
            $("span[id$=_uploading]", container).hide();

            //默认实例
            var swfu;
            var width = 99, height = 20;
            if (options) {
                width = options.width || width;
                height = options.height || height;
            }
            var defaults = {
                flash_url: "swfupload.swf",
                upload_url: "/Home/AsyncUpload",
                file_size_limit: "100 MB",
                file_types: "*.*",
                file_types_description: "All Files",
                debug: false,

                button_image_url: "blankButton.png",
                button_width: width,
                button_height: height,
                button_placeholder_id: id + "_swf",
                button_text: "<span class='theFont'>选择上传文件</span>",
                button_text_style: ".theFont { font-size: 12; }",
                button_text_left_padding: (width - 80) / 2,
                button_text_top_padding: 0,

                //删除文件的Action
                delete_url: null,
                //下载文件的Action
                download_url: null,

                // 当用户选择上传文件时，开始上传文件
                file_queued_handler: function (file) {
                    swfu.addFileParam(file.id, "BusinessType", options.existingBusinessType);
                    swfu.startUpload();
                },

                // 当用户错误的时候
                file_queue_error_handler: function (file, code, msg) { alert("对不起文件没有上传: " + msg); },

                // 当用户错误的时候
                upload_error_handler: function (file, code, msg) { alert("对不起文件没有上传: " + msg); },

                // 开始上传
                upload_start_handler: function () {
                    swfu.setButtonDimensions(0, height);
                    $("input[name$=_filename]", container).val("");
                    $("input[name$=_guid]", container).val("");
                    $("input[name$=_filesize]", container).val("");
                    $("div.ProgressBar div", container).css("width", "0px");
                    $("div.ProgressBar", container).show();
                    $("span[id$=_uploading]", container).show();
                    $("span[id$=_completedMessage]", container).html("").hide();

                    if (options.disableDuringUpload)//多个按钮被禁用
                        var ctrl = options.disableDuringUpload.split(',');
                        for (var i = 0; i < ctrl.length; i++) {
                            $(ctrl[i]).attr("disabled", "disabled");
                        }
                },

                // 上传成功后调用
                upload_success_handler: function (file, response) {
                    $("input[name$=_filename]", container).val(file.name);
                    $("input[name$=_guid]", container).val(response);
                    $("input[name$=_filesize]", container).val(file.size);
                    showUploadFileMessage(file.name);
                },

                // 上传完成后调用
                upload_complete_handler: function () {
                    var clearup = function () {
                        $("div.ProgressBar", container).hide();
                        $("span[id$=_completedMessage]", container).show();
                        $("span[id$=_uploading]", container).hide();
                        swfu.setButtonDimensions(width, height);
                    };
                    if ($("input[name$=_filename]", container).val() != "") // Success
                        $("div.ProgressBar div", container).animate({ width: "100%" }, { duration: "fast", queue: false, complete: clearup });
                    else // Fail
                        clearup();

                    if (options.disableDuringUpload)//多个按钮被禁用后释放
                        var ctrl = options.disableDuringUpload.split(',');
                        for (var i = 0; i < ctrl.length; i++){
                            $(ctrl[i]).removeAttr("disabled");
                        }
                },

                // 上传进度条
                upload_progress_handler: function (file, bytes, total) {
                    var percent = 100 * bytes / total;
                    $("div.ProgressBar div", container).animate({ width: percent + "%" }, { duration: 500, queue: false });
                }
            };
            swfu = new SWFUpload($.extend(defaults, options || {}));

            //取消上传
            $("span[id$=_uploading] input[type='button']", container).click(function () {
                swfu.cancelUpload(null, false);
            });


            // 存在上传文件加载文件效果
            if (options.existingGuid || "" != "") {
                $("input[name$=_guid]", container).val(options.existingGuid);
            }
            if (options.existingFileSize || "" != "") {
                $("input[name$=_filesize]", container).val(options.existingFileSize);
            }
            if (options.existingBusinessType || "" != "") {
                $("input[name$=_businesstype]", container).val(options.existingBusinessType);
            }

            if (options.existingFilename || "" != "") {
                $("input[name$=_filename]", container).val(options.existingFilename);
                var filehtml = options.existingFilename;
                showUploadFileMessage(filehtml).show();
            }

            //显示上传的HTML
            function showUploadFileMessage(filename) {
                $("input[name$=_guid]", container).val();
                if (options.download_url != null) {
                    filename = "<a id='" + id + "_download_link' href='" + options.download_url + "/?fileId=" +
                        $("input[name$=_guid]", container).val()
                        + "&fileName=" + $("input[name$=_filename]", container).val()
                        + "&businessType=" + options.existingBusinessType + "'>" + filename + "</a>";
                }
                var message = $("span[id$=_completedMessage]", container).html("已上传 <b>{0}</b> ({1} KB)"
                        .replace("{0}", filename)
                        .replace("{1}", options.existingFileSize ? Math.round(options.existingFileSize / 1024) : "")
                );
                if (options.delete_url != null) {
                    message.append("<a id='" + id + "_delete_link' href='#'>X</a>");
                    $("a[id$=_delete_link]", container).bind("click", function () {
                        $.ajax({
                            url: options.delete_url,
                            type: "POST",
                            dataType: "Text",
                            data: {
                                fileId: $("input[name$=_guid]", container).val(),
                                fileName: $("input[name$=_filename]", container).val(),
                                businessType: options.existingBusinessType
                            },
                            success: function (data) {
                                if (data == "True") {
                                    $("span[id$=_completedMessage]", container).hide();
                                    $("input[name$=_filename]", container).val("");
                                    $("input[name$=_guid]", container).val("");
                                    $("input[name$=_filesize]", container).val("");
                                }
                                else {
                                    alert('删除失败！');
                                }
                            }
                        });
                    });
                }
                return message;
            }
        });
    };
})(jQuery);