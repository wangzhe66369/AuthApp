﻿//    $(function () {
//        $("#flashUpfile").makeMultiFileAsyncUploader({
//              //提交处理的URL
//              upload_url: "@Url.Content("~/Home/AsyncUpload")",
//              delete_url:"@Url.Content("~/Home/DeleteFile")",
//              download_url:"@Url.Content("~/Home/DownFile")",

//				file_size_limit : "102400",	// 100MB
//				file_types : "*.*",
//				file_types_description : "All Files",
//				file_upload_limit : 10,
//				file_queue_limit : 0,

//				button_image_url: "@Url.Content("~/Scripts/SwfUpload/XPButtonUploadText_61x22.png")",
//				button_width: 61,
//				button_height: 22,
//				
//				flash_url : "@Url.Content("~/Scripts/SwfUpload/swfupload.swf")",
//				flash9_url : "@Url.Content("~/Scripts/swfupload/swfupload_fp9.swf")",
//              disableDuringUpload: 'INPUT[type="submit"]',
//              //业务类型
//              existingBusinessType:"PlanSolution"
//              
//        });
//    })


(function ($) {
    $.fn.makeMultiFileAsyncUploader = function (options) {
        return this.each(function () {
            //获取上传控件的ID
            var id = $(this).attr("id");
            var container = $("<span class='asyncUploader'/>");
            container.append($("<span id='" + id + "_swf'/>"));
            //container.append($("<input  id='" + id + "_Cansel' type='button' 
            //value='取消上传' disabled='disabled' />"));
            container.append($("<table id='" + id + 
            "_Uploadfile' class='swfuploadfileListTable' style='margin-top:5px;'"+
            "cellpadding='0' cellspacing='0' border='0'>" +
            "<thhead><tr><th>文件名</th><th>文件大小(Bite)</th><th>进度</th>" +
            "<th style='width:40px;'>状态</th><th style='width:60px;'>操作</th></tr></thhead></table>"));
            $(this).before(container).remove();
            $("table[id$=_Uploadfile]", container).hide();

            var defaults = {
                //是否显示上传的进度面板
                isshow: true,
                //后台处理
                upload_url: "/Home/AsyncUpload",
                post_params: {},

                // 文件上传设置
                file_size_limit: "102400", // 100MB
                file_types: "*.*",
                file_types_description: "All Files",
                file_upload_limit: 10,
                file_queue_limit: 0,

                //按钮设置
                button_image_url: "/Scripts/swfupload/XPButtonUploadText.png",
                button_placeholder_id: id + "_swf",
                button_text: null,
                button_text_style: null,
                button_width: 61,
                button_height: 22,

                // Flash 设置
                flash_url: "/Scripts/swfupload/swfupload.swf",
                flash9_url: "/Scripts/swfupload/swfupload_fp9.swf",

                //调试设置
                debug: false,
                //在上传期间禁用对象
                disableDuringUpload: null,

                //删除文件的Action
                delete_url: null,
                //下载文件的Action
                download_url: null,
                //自定义设置
                custom_settings: {
                    progressTarget: id + "_Uploadfile"
                    //cancelButtonId: id + "_Cansel"
                },
                // 事件处理
                swfupload_preload_handler: preLoad,
                swfupload_load_failed_handler: loadFailed,
                file_dialog_start_handler: function () { },
                file_queued_handler: fileQueued,
                file_queue_error_handler: fileQueueError,
                file_dialog_complete_handler: fileDialogComplete,
                upload_start_handler: uploadStart,
                upload_progress_handler: uploadProgress,
                upload_error_handler: uploadError,
                upload_success_handler: uploadSuccess,
                upload_complete_handler: uploadComplete
            };
            //flash对象
            var swfu = new SWFUpload($.extend(defaults, options || {}));

            //加载准备
            function preLoad() {
                if (!this.support.loading) {
                    alert("SWFUpload需要Flash Player 9.028 以上版本.");
                    return false;
                }
                return true;
            }
            //加载失败
            function loadFailed() {
                alert("加载 SWFUpload 遇到问题.");
            }
            //文件队列
            function fileQueued(file) {
                try {
                    var progress = new fileUploadStatus(file, this.customSettings.progressTarget);
                    progress.setStatus("Pending");
                    //添加文件参数
                    swfu.addFileParam(file.id, "BusinessType", options.existingBusinessType);

                } catch (ex) {
                    this.debug(ex);
                }
            }
            //文件队列错误
            function fileQueueError(file, errorCode, message) {
                try {
                    if (errorCode === SWFUpload.QUEUE_ERROR.QUEUE_LIMIT_EXCEEDED) {
                        alert("上传文件数量过多.\n" + (message === 0 ? "您已到达上载限制." : "还能上传 " + (message > 1 ? message + " 个文件." : "1个文件.")));
                        return;
                    }

                    var progress = new fileUploadStatus(file, this.customSettings.progressTarget);
                    progress.setStatus("Error");


                    switch (errorCode) {
                        case SWFUpload.QUEUE_ERROR.FILE_EXCEEDS_SIZE_LIMIT:
                            progress.setStatus("上传文件超过设置大小.");
                            this.debug("Error Code: 文件太大, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
                            break;
                        case SWFUpload.QUEUE_ERROR.ZERO_BYTE_FILE:
                            progress.setStatus("不能上传空文件.");
                            this.debug("Error Code: Zero byte file, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
                            break;
                        case SWFUpload.QUEUE_ERROR.INVALID_FILETYPE:
                            progress.setStatus("未知的文件类型.");
                            this.debug("Error Code: Invalid File Type, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
                            break;
                        case SWFUpload.QUEUE_ERROR.QUEUE_LIMIT_EXCEEDED:
                            alert("You have selected too many files.  " + (message > 1 ? "You may only add " + message + " more files" : "You cannot add any more files."));
                            break;
                        default:
                            if (file !== null) {
                                progress.setStatus("未知的错误");
                            }
                            this.debug("Error Code: " + errorCode + ", File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
                            break;
                    }
                } catch (ex) {
                    this.debug(ex);
                }
            }
            //文件选择完成 上传文件
            function fileDialogComplete(numFilesSelected, numFilesQueued) {
                try {
                    if (this.getStats().files_queued > 0) {
                        //document.getElementById(this.customSettings.cancelButtonId).disabled = false;
                        //是否显示上传进度面板，默认显示
                        if (options.isshow == undefined || options.isshow) {
                            $("table[id$=_Uploadfile]", container).show();
                        }
                        else {
                            $("table[id$=_Uploadfile]", container).hide();
                        }
                    }
                    /* 选择文件对话框关闭后开始自动上传 */
                    this.startUpload();
                } catch (ex) {
                    this.debug(ex);
                }
            }
            //开始上传
            function uploadStart(file) {
                try {
                    var progress = new fileUploadStatus(file, this.customSettings.progressTarget);
                    progress.setStatus("Uploading");

                    //上传期间对象禁止操作
                    if (options.disableDuringUpload) {
                        var ctrl = options.disableDuringUpload.split(',');
                        for (var i = 0; i < ctrl.length; i++) {
                            $(ctrl[i]).attr("disabled", "disabled");
                        }
                    }

                }
                catch (ex) {
                    this.debug(ex);
                }
                return true;
            }
            //上传进程
            function uploadProgress(file, bytesLoaded, bytesTotal) {
                try {
                    var percent = Math.ceil((bytesLoaded / bytesTotal) * 100);

                    var progress = new fileUploadStatus(file, this.customSettings.progressTarget);
                    progress.setStatus("Uploading");
                    progress.setProgress(percent);

                } catch (ex) {
                    this.debug(ex);
                }
            }
            //上传成功
            function uploadSuccess(file, response) {
                try {
                    var progress = new fileUploadStatus(file, this.customSettings.progressTarget, id, options.existingBusinessType, response, options.delete_url, options.download_url);
                    progress.setStatus("Complete");
                } catch (ex) {
                    this.debug(ex);
                }
            }
            //上传完成
            function uploadComplete(file) {
                try {
                    /*  自动继续上传 */
                    if (this.getStats().files_queued === 0) {
                        //document.getElementById(this.customSettings.cancelButtonId).disabled = true;
                    } else {
                        this.startUpload();
                    }
                    //文件上传完成恢复控件可用
                    if (options.disableDuringUpload) {
                        var ctrl = options.disableDuringUpload.split(',');
                        for (var i = 0; i < ctrl.length; i++) {
                            $(ctrl[i]).removeAttr("disabled");
                        }
                    }
                } catch (ex) {
                    this.debug(ex);
                }
            }
            //上传错误
            function uploadError(file, errorCode, message) {
                try {
                    var progress = new fileUploadStatus(file, this.customSettings.progressTarget);
                    progress.setStatus("Error");

                    switch (errorCode) {
                        case SWFUpload.UPLOAD_ERROR.HTTP_ERROR:
                            progress.setStatus("上传错误: " + message);
                            this.debug("Error Code: HTTP Error, File name: " + file.name + ", Message: " + message);
                            break;
                        case SWFUpload.UPLOAD_ERROR.MISSING_UPLOAD_URL:
                            progress.setStatus("配置错误");
                            this.debug("Error Code: No backend file, File name: " + file.name + ", Message: " + message);
                            break;
                        case SWFUpload.UPLOAD_ERROR.UPLOAD_FAILED:
                            progress.setStatus("上传失败.");
                            this.debug("Error Code: Upload Failed, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
                            break;
                        case SWFUpload.UPLOAD_ERROR.IO_ERROR:
                            progress.setStatus("服务器IO错误");
                            this.debug("Error Code: IO Error, File name: " + file.name + ", Message: " + message);
                            break;
                        case SWFUpload.UPLOAD_ERROR.SECURITY_ERROR:
                            progress.setStatus("权限错误");
                            this.debug("Error Code: Security Error, File name: " + file.name + ", Message: " + message);
                            break;
                        case SWFUpload.UPLOAD_ERROR.UPLOAD_LIMIT_EXCEEDED:
                            progress.setStatus("上传超过限制.");
                            this.debug("Error Code: Upload Limit Exceeded, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
                            break;
                        case SWFUpload.UPLOAD_ERROR.SPECIFIED_FILE_ID_NOT_FOUND:
                            progress.setStatus("未找到文件.");
                            this.debug("Error Code: The file was not found, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
                            break;
                        case SWFUpload.UPLOAD_ERROR.FILE_VALIDATION_FAILED:
                            progress.setStatus("Failed Validation.  Upload skipped.");
                            this.debug("Error Code: File Validation Failed, File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
                            break;
                        case SWFUpload.UPLOAD_ERROR.FILE_CANCELLED:
                            if (this.getStats().files_queued === 0) {
                                //document.getElementById(this.customSettings.cancelButtonId).disabled = true;
                            }
                            progress.setStatus("Cancelled");
                            //progress.setCancelled();
                            break;
                        case SWFUpload.UPLOAD_ERROR.UPLOAD_STOPPED:
                            progress.setStatus("Stopped");
                            break;
                        default:
                            progress.setStatus("未知的错误: " + errorCode);
                            this.debug("Error Code: " + errorCode + ", File name: " + file.name + ", File size: " + file.size + ", Message: " + message);
                            break;
                    }
                } catch (ex) {
                    this.debug(ex);
                }
            }

        });
    };
})(jQuery);

//文件上传状态
//file 文件对象
//fileholder 文件容器
//swfId  选择上传组件ID
//bussnesstype 业务编码
//guid 文件的GUId
//deleteurl 删除文件的URL
//downloadurl 下载文件的url
var fileUploadStatus = function (file, fileholder, swfId, bussnesstype, guid, deleteurl, downloadurl) {
    this.setStatus = function (state) {
        switch (state) {
            case "Cancelled":
                cancelQueue();
                break;
            case "Stopped":
                changeFileState("Stopped");
                break;
            case "Upload Failed":
                changeFileState("Upload Failed");
                break;
            case "Pending":
                addFileToHolder();
                setcancelButton("Add");
                break;
            case "Uploading":
                changeFileProcess("1");
                break;
            case "Complete":
                uploadFinished();
                break;
            case "None":
                removeAllFromHolder();
                break;
            case "Error":
                changeFileState("Error");
                setcancelButton("Remove");
                break;
            default:
                break;
        }
    };
    //设置上传状态
    this.setProgress = function (percent) {
        changeFileProcess(percent);
    };
    //设置取消按钮
    function setcancelButton(op) {
        var swfflashfile = getFileInTableTr();
        if (op == "Remove") {
            if (swfflashfile.length > 0) {
                $(".linkbtn_file_cancel", swfflashfile[0]).remove();
            }
        }
        else {
            if ($(".linkbtn_file_cancel", swfflashfile[0]).length <= 0) {
                $($("td", swfflashfile[0])[4]).append("<a class='linkbtn_file_cancel' href='#' onclick=\"setCancel('" + file.id + "');\">取消</a>");
            }
        }
    }
    //设置下载按钮
    function setDownButton() {
        var swfflashfile = getFileInTableTr();
        if (swfflashfile.length > 0) {
            var url = "#";
            if (downloadurl != null) {
                url = downloadurl + "/?fileId={0}&fileName={1}&businessType={2}";
                url = url.replace("{0}", guid).replace("{1}", file.name).replace("{2}", bussnesstype);
            }
            $($("td", swfflashfile[0])[4]).append("<a class='linkbtn_file_download' href='" + url + "'>下载</a>");
        }
    }
    //设置删除按钮
    function setDeleteButton() {
        var swfflashfile = getFileInTableTr();
        if (swfflashfile.length > 0) {
            $($("td", swfflashfile[0])[4]).append("<a class='linkbtn_file_delete' href='#'>删除</a>");
            $(".linkbtn_file_delete", swfflashfile[0]).bind("click", function (obj) {
                deleteSelectFile(deleteurl, guid, file.name, file.id, bussnesstype, obj);
            });
        }
    }

    //改变上传文件的进度
    function changeFileProcess(percent) {
        var swfflashfile = getFileInTableTr();
        if (swfflashfile.length > 0) {
            $("div.ProgressBar div", swfflashfile[0]).animate({ width: percent + "%" }, { duration: 500, queue: false });
        }
    }
    function cancelQueue() {
        changeFileState("Cancelled");
        var swfflashfile = getFileInTableTr();
        if (swfflashfile)
            swfflashfile.remove();
    }
    //改变上传文件的状态
    function changeFileState(state) {
        var swfflashfile = getFileInTableTr();
        if (swfflashfile.length > 0) {
            if (state == "Error") {
                $("td", swfflashfile[0])[3].innerHTML = "<font style='color:Red;'>Error</font>";
            } else {
                $("td", swfflashfile[0])[3].innerHTML = state;
            }
        }
    }
    //上传文件完成
    function uploadFinished() {
        var swfflashfile = getFileInTableTr();
        if (swfflashfile.length > 0) {
            $("td", swfflashfile[0])[3].innerHTML = "完成";
            uploadfileValueToHtml($("td", swfflashfile[0])[0]);
        }
        changeFileProcess("100");  //上传进度条为100
        setcancelButton("Remove"); //移除取消上传按钮
        setDeleteButton();         //显示删除文件按钮
        //setDownButton();           //显示下载文件按钮
    }
    //从容器中移除文件
    function removeFileFromHolder(fileId) {
        var swfflashfile = $("tr[id$=" + fileId + "]", $("#" + fileholder));
        if (swfflashfile.length > 0) {
            $(swfflashfile[0]).remove();
        }
    }
    //移除容器中所有的文件
    function removeAllFromHolder() {
        $("#" + fileholder + " tr").each(function (i) {
            if (i != 0) {
                $(this).remove();
            }
        });
    }
    //添加文件到容器
    function addFileToHolder() {
        var appendHtml = "<tr id='{0}'><td>{1}</td><td>{2}</td><td><div class='ProgressBar'><div></div></div></td><td>{3}&nbsp;</td><td>&nbsp;</td></tr>";
        appendHtml = appendHtml.replace("{0}", file.id).replace("{1}", file.name).replace("{2}", file.size).replace("{3}", "");
        $("#" + fileholder).append(appendHtml);
    }

    //公用选取对象方法
    function getFileInTableTr() {
        return $("tr[id$=" + file.id + "]", $("#" + fileholder));
    }

    //赋值文件上传
    function uploadfileValueToHtml(fileholderobj) {
        if (fileholderobj) {
            var filename = document.createElement("input");
            $(filename).attr("name", swfId + "_filename");
            $(filename).attr("value", encodeURIComponent(file.name)); //文件名编码，解决附件中包含逗号无法上传的问题
            $(filename).attr("type", "hidden");

            var fileguid = document.createElement("input");
            $(fileguid).attr("name", swfId + "_guid");
            $(fileguid).attr("value", guid);
            $(fileguid).attr("type", "hidden");

            var filesize = document.createElement("input");
            $(filesize).attr("name", swfId + "_filesize");
            $(filesize).attr("value", file.size);
            $(filesize).attr("type", "hidden");

            var filebtype = document.createElement("input");
            $(filebtype).attr("name", swfId + "_businesstype");
            $(filebtype).attr("value", bussnesstype);
            $(filebtype).attr("type", "hidden");

            $(fileholderobj).append(filename);
            $(fileholderobj).append(fileguid);
            $(fileholderobj).append(filesize);
            $(fileholderobj).append(filebtype);
        }
    }
};

//删除选择的文件
function deleteSelectFile(deleteUrl, fileGuid, fileName, fileId, bussinessType, obj) {
    $.ajax({
        url: deleteUrl,
        type: "POST",
        dataType: "Text",
        data: {
            fileId: fileGuid,
            fileName: fileName,
            businessType: bussinessType
        },
        success: function (data) {
            if (data == "True") {
                //移除自己
                var objgrandfather = obj.currentTarget.parentElement.parentElement;
                if (objgrandfather) {
                    $(objgrandfather).remove();
                }
                //上传文件个数限制处理
                setFileUploadNum(fileId);
            }
            else {
                alert('删除失败！');
            }
        }
    });
}

//设置上传个数
function setFileUploadNum(fileId) {
    var instanceobj = getFileInstanceByFileId(fileId);
    if (instanceobj) {
        instanceobj.setFileUploadLimit(instanceobj.settings.file_upload_limit + 1);
    }
}
//取消上传
function setCancel(fileId) {
    var instanceobj = getFileInstanceByFileId(fileId);
    if (instanceobj) {
        instanceobj.cancelUpload(fileId);
    }
    return false;
};
//获取上传文件的实例
function getFileInstanceByFileId(fileId) {
    var swfuploadinstanceIndexstr = fileId.substring(0, fileId.lastIndexOf('_'));
    return SWFUpload.instances[swfuploadinstanceIndexstr];
}
