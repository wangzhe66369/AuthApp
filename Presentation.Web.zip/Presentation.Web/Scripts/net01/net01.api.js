﻿if (net01 == undefined || net01 == null) {
    net01 = {};
}

//调用公共api
net01.api = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    settings: {
        username: null,
        password: null,
        data: {
            Operate: null,
            Text:null,
            Key:null
        },
        onSuccess: null,
        onFailure: null
    },
    //设置证书
    setCredentials: function (username, password) {
        ///<param name="username">用户名</param>
        ///<param name="password">密码</param>
        this.settings.username = username;
        this.settings.password = password;
    },
    //异步调用
    invokeCall: function (uri) {
        ///<param name="uri">请求URL</param>
        if (this.settings.data.Key.length != 5) {
            alert("Key长度必须等于 5 位字符");
        }
        var that = this;
        $.ajax({
            url: uri,
            data: { key: this.settings.data.Key,text:this.settings.data.Text,op:this.settings.data.Operate},
            type: "GET",
            dataType: "jsonp",
            contentType: "application/json;charset=utf-8",
            processData: true,
            beforeSend: function (request) {
                request.setRequestHeader("Authorization", "Basic " + that.encode(("{0}:{1}").replace("{0}", that.settings.username).replace("{1}", that.settings.password)));
            },
            success: function (data) {
                if (that.settings.onSuccess != null) {
                    that.settings.onSuccess(data);
                }
            },
            error: function (response) {
                if (that.settings.onFailure != null) {
                    that.settings.onFailure(response);
                    return;
                }
            }
        });
    },
    //base64 编码
    encode: function (input) {
        ///<param name="input">输入</param>

        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = this._utf8_encode(input);
        while (i < input.length) {

            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);

            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;

            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }

            output = output +
			this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
			this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
        }
        return output;
    },
    //_utf8格式编码
    _utf8_encode: function (string) {
        ///<param name="string">输入字符</param>

        string = string.replace(/\r\n/g, "\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);

            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
        }
        return utftext;
    }
};