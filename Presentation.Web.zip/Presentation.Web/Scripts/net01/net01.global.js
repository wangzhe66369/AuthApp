﻿var net01Global = {};
net01Global.skin = "default";
net01Global.lang = "zh-cn";
net01Global.sysCode = net01.comm.getSysCodeByMeta();
net01Global.ChangeSkin = function (skin) {
    /// <summary>
    /// 换肤
    /// </summary>

    this.skin = skin;
    //改变主框架的风格
    net01Global.ChangeMainPageSkin();
    //改变框架内页面的风格
    net01Global.ChangeChildPageSkin();
    //将皮肤保存在cookie
    net01Global.UpdateSkinForCookie();
};

net01Global.UpdateSkinForCookie = function () {
    //将皮肤保存在cookie
    $.cookie(net01Global.sysCode + '_Skin', this.skin, { expires: 365 });
};

net01Global.ChangeMainPageSkin = function () {
    /// <summary>
    /// 改变主框架的风格
    /// </summary>
    var mainPageThemes = this.GetThemes("skin", window.document);
    var globalCss = this.GetThemes("global", window.document);
    if (globalCss !== undefined && globalCss.attr("href") !== null) {
        var newMainPageThemesPath = this.GetNewThemesPath(globalCss.attr("href"));
        mainPageThemes.attr("href", newMainPageThemesPath);

        //将框架/项目皮肤完整的URL保存在cookie
        $.cookie(net01Global.sysCode + '_Skin_Path', newMainPageThemesPath, { expires: 365, path: '/' });

    }
};

net01Global.ChangeChildPageSkin = function () {
    /// <summary>
    /// 改变框架内页面的风格
    /// </summary>
    var childPageThemes = this.GetThemes("skin", window.frames["mainFrame"].document);
    var globalCss = this.GetThemes("global", window.document);
    if (globalCss !== undefined && globalCss.attr("href") !== null) {
        var newChildPageThemesPath = this.GetNewThemesPath(globalCss.attr("href"));
        childPageThemes.attr("href", newChildPageThemesPath);
    }
};

net01Global.GetThemes = function (themesId, document) {
    /// <summary>
    /// 获取皮肤的对象
    /// </summary>
    /// <param name="themesId">皮肤对象的Id</param> 
    /// <param name="document">查找的文档对象</param> 

    var dom = $(document);
    return $(dom.find("#" + themesId)[0]);
};

net01Global.GetNewThemesPath = function (themesUrl, skin) {
    /// <summary>
    /// 返回新皮肤的路径
    /// </summary>
    /// <param name="themesUrl">原来皮肤的路径</param> 
    /// <param name="skin">皮肤名称</param> 

    if (themesUrl === undefined) {
        return null;
    }
    if (skin != undefined && skin != null) {
        this.skin = skin;
    }
    var arr = themesUrl.toUpperCase().split("GLOBALSTYLE");
    return arr[0] + "THEMES/" + this.skin + "/SITE.MIN.CSS";
};

net01Global.LoadDefaultSkin = function () {
    /// <summary>
    /// 从cookie中加载个人配置的皮肤
    /// </summary>
    var defaultSkin = $.cookie(net01Global.sysCode + '_Skin');
    if (defaultSkin != undefined && defaultSkin != null) {
        this.skin = $.cookie(net01Global.sysCode + '_Skin');
    }
    net01Global.ChangeSkin(this.skin);
};

$(function () {
    //加载默认的皮肤
    net01Global.LoadDefaultSkin();
});


