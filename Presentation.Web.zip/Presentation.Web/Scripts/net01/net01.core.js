﻿var net01 = {};
//查询
net01.search = {
    //折叠条件区域
    toggleCondition: function (btn, containerId) {
        ///<param name="btn">按钮</param>
        ///<param name="containerId">控制容器ID</param>
        var $btn = $(btn);
        if ($btn.val() == "更多筛选条件") {
            $btn.attr("class", "ui-btn ui-btn-hidden");
            $btn.val("精简筛选条件");
        }
        else {
            $btn.attr("class", "ui-btn ui-btn-view");
            $btn.val("更多筛选条件");
        }
        $('#' + containerId).toggle();
    }
};
net01.iframe = {
    dispose: function (jqIframe) {
        /// <summary>
        /// 释放iframe资源，避免iframe内存泄露
        /// </summary>
        ///<param name="jqIframe">iframe对象</param>

        jqIframe.attr('src', 'about:blank');
        jqIframe.get(0).contentWindow.document.write('');
        jqIframe.get(0).contentWindow.document.close();
        if ($.browser.msie) {
            CollectGarbage();
        }
    }
};
net01.css = {
    loadTopWindowCss: function (skinId, globalId) {
        /// <summary>
        /// 加载顶部窗口的样式
        /// </summary>
        ///<param name="skinId">皮肤样式link对象的Id</param>
        ///<param name="skinId">全局样式link对象的Id</param>

        var newthemesPath, topObj = net01.comm.getTopWindow();

        if (topObj.net01Global == undefined) {
            //从cookie中获取皮肤的样式地址_Skin_Path
            newthemesPath = $.cookie(net01.comm.getSysCodeByMeta() + '_Skin_Path');

        } else {
            newthemesPath = topObj.net01Global.GetNewThemesPath($("#" + globalId).attr("href"), topObj.net01Global.skin);
        }
        if (newthemesPath != undefined && newthemesPath != null) {
            $("#" + skinId).attr("href", newthemesPath);
        }
    }
};
net01.uba = {
    Login: function (url, userId, sysCode, projectCode, onOff) {
        /// <summary>
        /// 记录登录日志
        /// </summary>
        ///<param name="url">UBA链接</param>
        ///<param name="userId">员工号</param>
        ///<param name="sysCode">系统代码</param>
        ///<param name="projectCode">子系统代码</param>
        ///<param name="onOff">开关</param>
        if (onOff.toLowerCase() === "off") {
            return;
        }
        $.ajax({
            url: url + "Services/UBALogServer.asmx/SaveRequestLoginLog",
            dataType: "jsonp",
            jsonp: "jsonpcallback",
            data: { userId: userId, sysCode: sysCode, screenWidth: screen.width, screenHeight: screen.height, projectCode: projectCode }
        });
    },
    Menu: function (url, userId, sysCode, menuName, projectCode, onOff) {
        /// <summary>
        /// 记录菜单日志
        /// </summary>
        ///<param name="url">UBA链接</param>
        ///<param name="u.serId">员工号</param>
        ///<param name="sysCode">系统代码</param>
        ///<param name="menuName">菜单名称</param>
        ///<param name="projectCode">子系统代码</param>
        ///<param name="onOff">开关</param>
        if (onOff.toLowerCase() === "off") {
            return;
        }
        $.ajax({
            url: url + "Services/UBALogServer.asmx/SaveMenuLog",
            dataType: "jsonp",
            jsonp: "jsonpcallback",
            data: { userId: userId, sysCode: sysCode, menuName: menuName, projectCode: projectCode }
        });
    }
};

net01.comm = {
    getTopWindow: function () {
        /// <summary>
        /// 获取顶部窗口
        /// </summary>
        var ansycFrame = window.top != window.self;
        var win;
        if (ansycFrame) {
            win = window.top;
        }
        else {
            win = window.top;
            while (win.opener) {
                win = win.opener.top;
            }
        }
        return win;
    },
    getSysCodeByMeta: function () {
        /// <summary>
        /// 根据Meta获取系统代码
        /// </summary>
        var syscodemeta = $("meta[name=syscode]");
        var syscodename = null;
        if (syscodemeta.length > 0) {
            syscodename = syscodemeta.get(0).content;
        }
        return syscodename;
    }
};


function getCookie(cookie_name) {
    var allcookies = document.cookie;
    var cookie_pos = allcookies.indexOf(cookie_name);   //索引的长度

    // 如果找到了索引，就代表cookie存在，反之，就说明不存在。
    if (cookie_pos != -1) {
        cookie_pos += cookie_name.length + 1;     // 把cookie_pos放在值的开始，只要给值加1即可
        var cookie_end = allcookies.indexOf(";", cookie_pos);

        if (cookie_end == -1) {
            cookie_end = allcookies.length;
        }
        var value = unescape(allcookies.substring(cookie_pos, cookie_end)); //这里就可以得到你想要的cookie的值了。。。
    }
    return value;
}
function GetLang() {
    return getCookie("RWISLang");
}
function loadJsFile(jsFullFileName) {
    /// <summary>
    /// 加载Javascript文件
    /// </summary>
    /// <param name="jsFullFileName">javascript文件路径</param>

    //创建标签
    var fileref = document.createElement('script');
    //定义属性type的值为text/javascript 
    fileref.setAttribute("type", "text/javascript");
    //文件的地址 
    fileref.setAttribute("src", jsFullFileName);
    if (typeof fileref != "undefined") {
        var headHtml = $("head")[0].innerHTML;
        //检查js文件是否已经加载
        if (headHtml.indexOf(jsFullFileName) == -1) {
            document.getElementsByTagName("head")[0].appendChild(fileref);
        }
    }
}