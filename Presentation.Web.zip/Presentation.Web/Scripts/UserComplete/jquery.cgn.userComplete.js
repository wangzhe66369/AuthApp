/**
 UserComplete v1.0 is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>
 - Jquery version required: 1.6.x
 *
 * Name:UserComplete
 * Author:PCITOYT
 *
*/

(function( $, undefined ) {
  $.fn.userComplete = function(opt) {
    return this.queue( function() { 
      function init() {
        createUserComplete();
        addInput(0);
		InitVar();
      }

      function createUserComplete() {
        holder = $('<ul class="holder"></ul>').width(options.width);
        if (options.attachto) {
          if (typeof(options.attachto) == "object") {
            options.attachto.append(holder);
          } else {
            $(options.attachto).append(holder);
          }
        } else {
          element.after(holder);
        }
        complete = $('<div class="userComplete-auto">').width(options.width);
        if (options.complete_text != "") {
          var completeText = options.complete_text;
          complete.append('<div class="default"><div style="float:left;margin-left:5px;margin-top:5px;">' + completeText +  '</div></div>');
          if (options.remove_all_text) {
            complete.children('.default').append($('<a href="" class="select_all_items">' + options.remove_all_text + '</a>').click(function(){$(element).trigger('removeAll'); return false;}));
          }
		  
        }
        complete.hover(function() {complete_hover = 0;}, function() {complete_hover = 1;});
        feed = $('<ul id="'+elemid+'_feed"></ul>').width(options.width);
        holder.after(complete.prepend(feed));
        elPrepare();
      }

	  function InitVar(){
		isLoaclDataSource=!(typeof options.source === "string");
		if(isLoaclDataSource){
			loadedUserList=options.source;
		}
		if(options.selectedId){
			loadDefaultUser();
		}
	  }

      function elPrepare() {
        name = element.attr("id");

        var temp_elem = $('<'+element.get(0).tagName+' name="'+name+'" id="'+elemid+'" multiple="multiple" class="' + element.get(0).className + ' hidden">').data('cache', {});
        
        $.each(element.children('option'), function(i, option) {
          option = $(option);
          temp_elem.data('cache')[option.val()] =  option.text();
          if (option.hasClass("selected")) {
            var id = addItem(option.text(), option.val(), true, option.hasClass("locked"));
            temp_elem.append('<option value="'+option.val()+'" selected="selected" id="opt_'+id+'"class="selected">'+option.text()+'</option>');
          }
        });
        
        element.after(temp_elem);
        element.remove();
        element = temp_elem;
        
        //public method to add new item
        $(element).bind("addItem", function(event, data) {
          addItem(data.title, data.value, 0, 0, 0);
        });
        
        //public method to remove item
        $(element).bind("removeItem", function(event, data) {
          var item = holder.children('li[rel=' + data.value + ']');
          if (item.length) {
            removeItem(item);
          }
        });
        
        //public method to remove item
        $(element).bind("destroy", function(event, data) {
          holder.remove();
          complete.remove();
          element.show();
        });
        
        //public method 移除所有子项
        $(element).bind("removeAll", function(event, data) {
			selectedUserList=[];
			var items = holder.children('li');
			for(var i=0;i<items.length;i++) {
				var item=$(items[i]);
				if(item.attr("rel")&&item.attr("rel")!=""){
					removeItem(item);
				}
			}
            feed.parent().hide()
        });
        
      }
	
	   //根据编号获取人员信息
	  function _getStaffInfo(staffNO,staffList,deptName){
		var staff=null;
		if (staffNO && staffList) {
			for (var i = 0; i < staffList.length; i++) {
				if(deptName&&deptName!=''){
					if(staffNO == staffList[i][options.dataMapping.staffNO]&&deptName== staffList[i][options.dataMapping.deptName]){
						staff = staffList[i];
						break;
					}
				}else{
					if(staffNO == staffList[i][options.dataMapping.staffNO]){
						staff = staffList[i];
						break;
					}
				}
			}
		}
		return staff;
	  }


	  //获取格式化后的选择项文本
	  function _getItemFormatText(value,list){
			var staff=_getStaffInfo(value,list);
			var text=_formatItemText(staff);
			return text;
	  }

	 //获取格式化后的成员文本
	  function _getMemberFormatText(value,list,deptName){
			var staff=_getStaffInfo(value,list,deptName);
			var text=_formatMemberText(staff);
			return text;
	  }

	  function _formatItemText(staff){
		var text;
		if(staff){
			text= "["+staff[options.dataMapping.staffNO]+"] "+staff[options.dataMapping.staffName];
		}
		return text;
	  }

	  function _formatMemberText(staff){
		var text;
		if(staff){
			text= "["+staff[options.dataMapping.staffNO]+"] "+staff[options.dataMapping.staffName];
			if(staff[options.dataMapping.deptName]&&staff[options.dataMapping.deptName]!=""){
				text=text+" ("+staff[options.dataMapping.deptName]+")";
			}
		}
		return text;
	  }


	  //查询数据
	  function search(text, data) {
		  var temp = new Array();
		  var regex = new RegExp((options.filter_begin ? '^' : '') + text, (options.filter_case ? "g": "gi"));
		  for(var i=0;i<data.length;i++){
			if(data[i]){
				_elem=data[i];
				for(var attr in _elem){
				  if(typeof _elem[attr] ==="string"){
					  if (_elem[attr].search(regex) != -1) {
						temp.push(_elem);
						break;
					  }
				  }
			  }
			}
		  }
		  return temp;
	  }

	   //员工是否存在
      function staffExists(staffNO, data) {
            var isExists = false;
            if (staffNO&&staffNO!="" && data) {
                for (var i = 0; i < data.length; i++) {
                    if (staffNO.toUpperCase() == data[i][options.dataMapping.staffNO].toUpperCase()) {
                        isExists = true;
                        break;
                    }
                }
            }
            return isExists;
        }
	  
	  //检查是否存在相似记录
	  function existsSimilarStaff(etext){
		 var flag=false;
		 var mateUserCount=0;
		 if(etext&&etext!=''&&loadedUserList&&loadedUserList.length>10){
			 if((!chineseCheck(etext)&&etext.split(' ').length>=2)
				 ||(chineseCheck(etext)&&etext.length>=2)){
				 for(var i=0;i<loadedUserList.length;i++){
					var staffNamePY=loadedUserList[i][options.dataMapping.staffNamePY].toUpperCase();
					etext=etext.toUpperCase();
					var staffName=loadedUserList[i][options.dataMapping.staffName].toUpperCase();
					if(staffNamePY.indexOf(etext)==0){
						mateUserCount++;
					}
					if(staffName.indexOf(etext)==0){
						mateUserCount++;
					}
				 }
			 }
		 }
		 flag=mateUserCount>10;
		
		return flag;
	  }

	  function chineseCheck(str){
			return  /^[\u4e00-\u9fa5]*$/.test(str);
	  }

      
	  /*
	  *添加项
	  * text:文本
	  * value:值
	  * preadded:是否追加在最前面
	  * locked:是否锁定添加项
	  * focusme:添加项后是否聚焦
	  */
      function addItem(text, value, preadded, locked, focusme) {
        if (!maxItems()) {
          return false;
        }
		//还原匹配模式
		isWholeMate=false;
		
        var liclass = "bit-box" + (locked ? " locked": "");
        var id = randomId();
        var txt = document.createTextNode(xssDisplay(text));
        var aclose = $('<a class="closebutton" href="#"></a>');

        var nameContainer = $("<span class='nameContainer'></span>").append(txt);
        var li = $('<li class="' + liclass + '" rel="' + value + '" id="pt_' + id + '"></li>').prepend(nameContainer).append(aclose);

        holder.append(li);

        aclose.click( function() {
          removeItem($(this).parent("li"));
          return false;
        });
        if (!preadded) {
          $("#" + elemid + "_annoninput").remove();
          addInput(focusme);
          var _item = $('<option value="'+xssDisplay(value, 1)+'" id="opt_'+id+'" class="selected" selected="selected">'+xssDisplay(text)+'</option>');
          element.append(_item);
          if (options.onselect) {
            //funCall(options.onselect, _item);
			var staff=_getStaffInfo(value,selectedUserList);
			if(staff==null){
				staff=_getStaffInfo(value,loadedUserList);
			}
			if(staff){
				var func=options.onselect;
				func.call(func, staff);
			}
          }
          element.change();
        }
        holder.children("li.bit-box.deleted").removeClass("deleted");
        clear_feed(1);
        return id;
      }
	  
	  /*移除项*/
      function removeItem(item) {
        if (!item.hasClass('locked')) {
          item.fadeOut("fast");
          var id = item.attr('id');
		  var value=item.attr("rel");
          if (options.onremove) {
			var staff=_getStaffInfo(value,selectedUserList);
			if(staff){
				var func=options.onremove;
				func.call(func, staff);
			}
          }
          if (id) {
             $("#o" + id + "").remove();
          } else {
            element.children('option[value="' + item.attr("rel") + '"]').remove();
          }
          item.remove();
          element.change();
          deleting = 0;
		  removeStaff(value);
        }
      }

	  //从已选人员中移除一个人
      function removeStaff(staffNO) {
            if(staffNO&&staffNO!=""&&selectedUserList){
				var d;
				$(selectedUserList).each(function (i, e) {
					if (e[options.dataMapping.staffNO].toUpperCase() == staffNO.toUpperCase()) {
						d = e;
					}
				});

				if (d) {
					//移除临时列表中的一个人员以及加载列表的一个人员
					selectedUserList.splice($.inArray(d, self.selectedUserList), 1);
				}
			}
        }

      function addInput(focusme) {
        var li = $('<li class="bit-input" id="'+elemid + '_annoninput">');
        var input = $('<input type="text" class="maininput" size="' + options.input_min_size + '" autocomplete="off">');
        //if (options.input_tabindex > 0) input.attr("tabindex", options.input_tabindex);
        if (options.input_name != "") input.attr("name", options.input_name);

        holder.append(li.append(input));

        input.focus( function() {
          isactive = true;
          if (maxItems()) {
            complete.fadeIn("fast");
          }
        });
        
        input.blur( function() {
          isactive = false;
          if (complete_hover) {
            complete.fadeOut("fast");
        } else {
            //解决达到最大数量时，无法失去焦点问题
            //input.focus();
          }

          if (options.addonblur) {
            focuson = feed.children("li[class!=mateTip]:visible:first");
            if (focuson.length > 0) {
              var option = focuson;
			  var value=option.attr("rel");
			  var staff=_getStaffInfo(value,loadedUserList);
			  if(staff){
				  if(!staffExists(staff[options.dataMapping.staffNO],selectedUserList)){
					  var text=_formatItemText(staff);
					  selectedUserList.push(staff);
					  addItem(text, value, 0, 0, 1); 
				  }
			  }
            }
          }
        });
        
        holder.click( function() {
          if (options.input_min_size < 0 && feed.length) {
            load_feed(xssPrevent(input.val(), 1));
          }
          input.focus();
          if (feed.length && input.val().length > options.input_min_size) {
            feed.show();
          } else {
            clear_feed(1);
            complete.children(".default").show();
          }
        });
        
        input.keypress( function(event) {
          if (event.keyCode == _key.enter) {
            return false;
          }
          //auto expand input
          var newsize = (options.input_min_size > input.val().length) ? options.input_min_size : (input.val().length + 1);
          input.attr("size", newsize).width(parseInt(input.css('font-size')) * newsize);
        });

        input.keyup( function(event) {

          var etext = xssPrevent(input.val(), 1);

		  //按下ctrl键，开启完全匹配模式
		  if(event.keyCode == _key.ctrl){
				isWholeMate=!isWholeMate;	
		  }
          
          if (event.keyCode == _key.backspace && etext.length == 0) {
            clear_feed(1);
            if (!holder.children("li.bit-box:last").hasClass('locked')) {
              if (holder.children("li.bit-box.deleted").length == 0) {
                holder.children("li.bit-box:last").addClass("deleted");
                return false;
              } else {
                if (deleting) {
                  return;
                }
                deleting = 1;
                holder.children("li.bit-box.deleted").fadeOut("fast", function() {
                  removeItem($(this));
                  return false;
                });
              }
            }
          }

          if (event.keyCode != _key.downarrow && event.keyCode != _key.uparrow && event.keyCode!= _key.leftarrow && event.keyCode!= _key.rightarrow && etext.length >= options.input_min_size) {
			load_feed(etext);
            complete.children(".default").hide();
            feed.show();
          }
        });
        if (options.oncreate) {
          funCall(options.oncreate, input);
        }
        if (focusme) {
          setTimeout( function() {
            input.focus();
            complete.children(".default").show();
          }, 1);
        }
      }

      function addMembers(etext, data) {

        feed.html('');

		//添加输入文本作为选择项
        //addTextItem(etext);

        var maximum = options.maxshownitems;
        var content = '';
		
		var source=null;

        if(isLoaclDataSource){
			source=search(etext,data).slice(0);
		}else{
			source=data;
		}

		$.each(source, function (i, obj) {
		  if (maximum) {
			var val=obj[options.dataMapping.staffNO];
			//var text=_getMemberFormatText(val,source);
			
			var text=_getMemberFormatText(val,source,obj[options.dataMapping.deptName]);

			if (options.filter_selected && element.children('option[value="' + val + '"]').hasClass("selected")) {
			  //nothing here...
			} else {
			  content += '<li rel="' + val + '">' + text + '&nbsp;</li>';
			  counter++;
			  maximum--;
			}
		  }
		});

		memberListTiper=$('<li class="mateTip" style="text-align:center;color:gray;cursor:auto;"></li>');

		if(!isWholeMate){
			if(existsSimilarStaff(etext)){
				memberListTiper.text('查找到多条类似记录，按Ctrl键可精确查找');
			}else if(source.length==0){
				memberListTiper.text('没有找到相关记录');
			}
		}else{
			if(source.length>0){
				memberListTiper.text("精确查找到以下记录，按Ctrl键可模糊查找");
			}else{
				memberListTiper.text("没有找到相关记录，按Ctrl键可模糊查找");
			}
		}	

		if(memberListTiper.text()==""){
			memberListTiper.hide();
		}else{
			memberListTiper.show();
		}

		feed.append(memberListTiper);
        feed.append(content);
		
        if (options.firstselected) {
          focuson = feed.children("li[class!=mateTip]:visible:first");
          focuson.addClass("auto-focus");
        }
        
        if (counter > options.height) {
          feed.css({
            "height": (options.height * 24) + "px",
            "overflow": "auto"
          });
        } else {
          feed.css("height", "auto");
        }
        
        if (maxItems() && complete.is(':hidden')) {
          complete.show();
        }
      }

      function itemIllumination(text, etext) {
        var string_regex_adder = options.filter_begin ? '': '(.*)';
        var regex_result = options.filter_begin ? '<em>$1</em>$2' : '$1<em>$2</em>$3';
        var string_regex = string_regex_adder + (options.filter_case ? "(" + etext + ")(.*)" : "(" + etext.toLowerCase() + ")(.*)");
        try {
          var regex = new RegExp(string_regex, ((options.filter_case) ? "g":"gi"));
          var text = text.replace(regex, regex_result);
        } catch(ex) {};
        return text;
      }

      function bindFeedEvent() {
        feed.children("li[class!=mateTip]").mouseover( function() {
          feed.children("li").removeClass("auto-focus");
          focuson = $(this);
          focuson.addClass("auto-focus");
        });
        feed.children("li[class!=mateTip]").mouseout( function() {
          $(this).removeClass("auto-focus");
          focuson = null;
        });
      }

      function removeFeedEvent() {
        feed.unbind("mouseover").unbind("mouseout").mousemove( function() {
          bindFeedEvent();
          feed.unbind("mousemove");
        });
      }
		
	  //绑定选择下拉项事件（鼠标点击、tab、enter）
      function bindEvents() {
        var maininput = $("#" + elemid + "_annoninput").children(".maininput");
        bindFeedEvent();
        
        feed.children("li").unbind("mousedown").mousedown( function() {
			var option = focuson;
			var value=option.attr("rel");
			var staff=_getStaffInfo(value,loadedUserList);

			if(staff){
				  if(!staffExists(value,selectedUserList)){
					  var text=_formatItemText(staff);
					  selectedUserList.push(staff);
					  addItem(text, value, 0, 0, 1); 
					  clear_feed(1);
					  complete.hide();
				  }
		   }
        });
        
        maininput.unbind("keydown");
        maininput.keydown( function(event) {
          if (event.keyCode != _key.backspace) {
            holder.children("li.bit-box.deleted").removeClass("deleted");
          }

          if ((event.keyCode == _key.enter  || event.keyCode == _key.comma) && checkFocusOn()) {
            var option = focuson;
			var value=option.attr("rel");
			var staff=_getStaffInfo(value,loadedUserList);

			if(staff){
				  if(!staffExists(value,selectedUserList)){
					  var text=_formatItemText(staff);
					  selectedUserList.push(staff);
					  addItem(text, value, 0, 0, 1); 
				  }
			  }

            return _preventDefault(event);
          }

          if (event.keyCode == _key.downarrow) {
            nextItem('first');
          }
          if (event.keyCode == _key.uparrow) {
            nextItem('last');
          }
        });
      }
      
      function nextItem(position) {
        removeFeedEvent();
        if (focuson == null || focuson.length == 0) {
          focuson = feed.children("li[class!=mateTip]:visible:" + position);
          feed.get(0).scrollTop = position == 'first' ? 0 : parseInt(focuson.get(0).scrollHeight, 10) * (parseInt(feed.children("li[class!=mateTip]:visible").length, 10) - Math.round(options.height / 2));
        } else {
          focuson.removeClass("auto-focus");
          focuson = position == 'first' ? focuson.nextAll("li[class!=mateTip]:visible:first") : focuson.prevAll("li[class!=mateTip]:visible:first");
          var prev = parseInt(focuson.prevAll("li[class!=mateTip]:visible").length, 10);
          var next = parseInt(focuson.nextAll("li[class!=mateTip]:visible").length, 10);
          if (((position == 'first' ? prev : next) > Math.round(options.height / 2) || (position == 'first' ? prev : next) <= Math.round(options.height / 2)) && typeof(focuson.get(0)) != "undefined") {
            feed.get(0).scrollTop = parseInt(focuson.get(0).scrollHeight, 10) * (prev - Math.round(options.height / 2));
          }
        }
        feed.children("li").removeClass("auto-focus");
        focuson.addClass("auto-focus");
      }
      
      function _preventDefault(event) {
        complete.hide();
        event.preventDefault();
        focuson = null;
        return false;
      }

      function maxItems() {
          return options.maxitems != 0 && (holder.children("li.bit-box").length < options.maxitems);
      }

      function addTextItem(value) {
        if (maxItems()) {
          feed.children("li[fckb=1]").remove();
          if (value.length == 0) {
            return;
          }
          var li = $('<li rel="'+value+'" fckb="1">').html(xssDisplay(value));
          feed.prepend(li);
          counter++;
        }
        return;
      }

      function funCall(func, item) {
        var _object = {};
        for (i = 0; i < item.get(0).attributes.length; i++) {
          if (item.get(0).attributes[i].nodeValue != null) {
            _object["_" + item.get(0).attributes[i].nodeName] = item.get(0).attributes[i].nodeValue;
          }
        }
        return func.call(func, _object);
      }

      function checkFocusOn() {
        if (focuson == null || focuson.length == 0) {
          return false;
        }
        return true;
      }
      
      function xssPrevent(string, flag) {
        if (typeof flag != "undefined") {
          for(i = 0; i < string.length; i++) {
            var charcode = string.charCodeAt(i);
            if ((_key.exclamation <= charcode && charcode <= _key.slash) ||
                (_key.colon <= charcode && charcode <= _key.at) ||
                (_key.squarebricket_left <= charcode && charcode <= _key.apostrof)) {
              string = string.replace(string[i], escape(string[i]));
            }
          }
          string = string.replace(/(\{|\}|\*)/i, "\\$1");
        }
        return string.replace(/script(.*)/g, "");
      }
      
      function xssDisplay(string, flag) {
        string = string.toString();
        string = string.replace('\\', "");
        if (typeof flag != "undefined") {
          return string;
        }
        return unescape(string);
      }
      
      function clear_feed(flag) {
        feed.children().remove();
        if (flag) {
          feed.hide();
        }
      }

      function load_feed(etext){
		etext=$.trim(etext);
        counter = 0;
        if (options.source && maxItems()) {

            getBoxTimeout++;
            var getBoxTimeoutValue = getBoxTimeout;
			  if (isLoaclDataSource) {
			    addMembers(etext, loadedUserList);
				bindEvents();
			  }else{
				setTimeout( function() {
							  if (getBoxTimeoutValue != getBoxTimeout){ 
								  return;
							  }
							  $.ajax({
									url:options.source,
									data:{"keyWord": encodeURIComponent(etext),"topCount":options.maxshownitems,"wholeMate":isWholeMate},
									dataType:options.dataType,
									success:function(d) {
										if (!isactive) return; // prevents opening the selection again after the focus is already off
										loadedUserList=d.data;
										addMembers(etext, d.data);
										bindEvents();
									},
									error:function(e){
									alert(e);
								  }
						  });			  
						}, 
				options.delay);
			  }	  
        } else {
		  //超过最大选择数量
          //addMembers(etext);
          //bindEvents();
        }
      }
	  
	  //加载默认用户
	  function loadDefaultUser(){
		   if (isLoaclDataSource) {
			loadedUserList = options.source.slice(0);
				if(options.selectedId&&options.selectedId!=""){
					options.selectedId=options.selectedId.replace(';',',');
					var selectedIdArray=options.selectedId.split(',');
					for(var i=0;i<selectedIdArray.length;i++){
						var selectedId=selectedIdArray[i];
						if(selectedId&&selectedId!=""){
							for(var j=0;j<loadedUserList.length;j++){
								var value=loadedUserList[j][options.dataMapping.staffNO];
								if(selectedId.toUpperCase()==value.toUpperCase()){
									selectedUserList.push(loadedUserList[j]);
									var text=_getItemFormatText(value,selectedUserList);
									addItem(text,value,0,0,0);
									break;
								}
							}
						}
					}
				}
		   }else{
			   $.ajax({
				url:options.source,
				data:{"selectedId": options.selectedId,"topCount":options.maxshownitems},
				dataType:options.dataType,
				success:function(d) {
							selectedUserList=d.selectedPerson;
							for(var i=0;i<selectedUserList.length;i++){
								var value=selectedUserList[i][options.dataMapping.staffNO];
								var text=_getItemFormatText(value,selectedUserList);
								addItem(text,value,0,0,0);
							}
						},
				error:function(a,b,c,d){
						alert(a);
					  }
			  });	
		   }
	  }

      var options = $.extend({
        source: null,
        width: 512,
		//高度，默认最大显示数量的高度，超过高度会出现滚动条
        height: "10",

		//是否在失去焦点是选择第一个元素
        addonblur: false,

		//是否默认选择第一个元素，默认为true
        firstselected: true,

		//大小写是否敏感，默认为false
        filter_case: false,

		//是否过滤已选择项
        filter_selected: true,

		//是否只从开始过滤，默认为false
        filter_begin: false,

		//下拉提示信息
        complete_text: "输入员工号/拼音/简称/姓名查询",

		//全部移除提示文本
        remove_all_text:  "清空",

		//数据默认为json
		dataType: "json",

		//最大显示数量
        maxshownitems: 30,

		//最大选择数量
        maxitems: 30,

        oncreate: null,
		//选择项事件
        onselect: null,

		//移除项事件
        onremove: null,

		//附加容器
        attachto: null,

		//查询延时时间
        delay: 350,

		//tabindex序号
        input_tabindex: 0,

		//最小匹配长度
        input_min_size: 1,

		//输入框name属性名
        input_name: "",

		//默认选择人员的编号，多个使用英文逗号","或分号";"分隔
		selectedId:"",

		//对象映射信息
		dataMapping: {
						staffNO: "StaffNO",
						staffName: "StaffName",
						staffNameEn: "StaffNameEn",
						staffNamePY:"StaffNamePY",
						deptBCD: "OrgBCD",
						deptName: "OrgName"
					}
      },
      opt);

      //system variables
      var holder = null;
      var feed = null;
      var complete = null;
      var counter = 0;
      
      var isactive = false;
      var focuson = null;
      var deleting = 0;
      var complete_hover = 1;

      var element = $(this);
      var elemid = element.attr("id");
      var getBoxTimeout = 0;

	  //下拉成员列表提示容器
	  var memberListTiper=null;
	 
	  //已选择的用户列表
	  var selectedUserList=[];
	  //查询到的用户列表
	  var loadedUserList=[];

	  //是否完全匹配
	  var isWholeMate=false;
	  
	  //是否为本地数据源
	  var isLoaclDataSource=false;

      var _key = { 'enter': 13,
                   'tab': 9,
				   'ctrl':17,
                   'comma': 188,
                   'backspace': 8,
                   'leftarrow': 37,
                   'uparrow': 38,
                   'rightarrow': 39,
                   'downarrow': 40,
                   'exclamation': 33,
                   'slash': 47,
                   'colon': 58,
                   'at': 64,
                   'squarebricket_left': 91,
                   'apostrof': 96
                 };
      
      var randomId = function() {
        var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
        var randomstring = '';
        for (var i = 0; i < 32; i++) {
            var rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum, rnum + 1);
        }
        return randomstring;
      };

      //initialization
      init();

      return selectedUserList;
    });
  };
})(jQuery);
