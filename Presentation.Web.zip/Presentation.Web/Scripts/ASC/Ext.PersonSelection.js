﻿

(function ($) {
    //单选
    $.fn.SinglePersonSelection = function (options) {
        var defaults = {
            cstyle: "gray",
            idept_id: "",
            dept_area: "",
            staff_no_ns: "",
            msg_ns: "",
            callback: null
        };

        var settings = $.extend(defaults, options || {});
        var self = $(this);
        self.click(function () {
            /* 工程专用
            var ascPersonSelection = new ProjectPersonSelect();
            */
            //广核用
            var ascPersonSelection = new PersonSelect();

            ascPersonSelection.cstyle = settings.cstyle; 		//风格样式
            ascPersonSelection.dept_area = settings.dept_area;  	//部门范围
            ascPersonSelection.idept_id = settings.dept_area;    	//默认部门
            ascPersonSelection.staff_no_ns = settings.staff_no_ns; //禁选人员
            ascPersonSelection.msg_ns = settings.msg_ns; 		//禁选原因
            self.ascPersonSelection = ascPersonSelection;

            var ascRe = ascPersonSelection.PopSinglePerson();
            if (settings.callback != null) {
                var callbackObj = null;
                if (ascRe != null) {
                    //员工号 员工姓名 部门编码路径 部门名称路径
                    callbackObj = { staffNo: ascRe[0], staffName: ascRe[1],
                        deptIdPath: ascRe[2], deptNamePath: ascRe[3]
                    };
                }
                settings.callback.call(null, callbackObj);
            }
        });
    };

    //多选 
    $.fn.MultiPersonSelection = function (options) {
        var defaults = {
            cstyle: "gray",
            nstyle: "3",
            idept_id: "",
            dept_area: "",
            staff_no: "",
            staff_no_ns: "",
            msg_ns: "",
            dataType: "",
            callback: null
        };

        var settings = $.extend(defaults, options || {});
        var self = $(this);
        self.click(function () {

            /* 工程专用
            var ascPersonSelection = new ProjectPersonSelect();
            */

            //广核用
            var ascPersonSelection = new PersonSelect();

            ascPersonSelection.cstyle = settings.cstyle; 		//风格样式
            ascPersonSelection.nstyle = settings.nstyle; 	//导航方式
            ascPersonSelection.dept_area = settings.dept_area;  	//部门范围
            ascPersonSelection.idept_id = settings.dept_area;    	//默认部门
            ascPersonSelection.staff_no = settings.staff_no; 	//默认人员
            ascPersonSelection.staff_no_ns = settings.staff_no_ns; //禁选人员
            ascPersonSelection.msg_ns = settings.msg_ns; 		//禁选原因
            self.ascPersonSelection = ascPersonSelection;

            if (jQuery.isFunction(settings.staff_no)) {
                ascPersonSelection.staff_no = settings.staff_no.call(null);
            }
            else {
                ascPersonSelection.dept_id = settings.dept_id;
            }
            var ascRe = ascPersonSelection.PopMulitiPerson();
            if (settings.callback != null) {
                var callbackObj = null;
                if (ascRe != null) {
                    //员工号 员工姓名 部门编码路径 部门名称路径
                    if (settings.dataType === "array") {
                        callbackObj = new Array(); //创建一个数组
                        if (ascRe[0] != "") {
                            var arrStaffNos = ascRe[0].split(';');
                            var arrSstaffNames = ascRe[1].split(';');
                            var arrDeptIdPaths = new Array() ;
                            if (ascRe[2] != null) {
                                arrDeptIdPaths = ascRe[2].split(';');
                            }
                            var arrDeptNamePaths = new Array();
                            if (ascRe[3] != null) {
                                arrDeptNamePaths = ascRe[3].split(';');
                            }

                            for (var i = 0; i < arrStaffNos.length; i++) {
                                var staff = new Object();
                                staff.staffNo = arrStaffNos[i];
                                staff.staffName = arrSstaffNames[i];
                                staff.deptIdPath = arrDeptIdPaths[i];
                                staff.deptNamePath = arrDeptNamePaths[i];
                                callbackObj.push(staff);
                            }
                        }
                    }
                    else {
                        callbackObj = { staffNo: ascRe[0], staffName: ascRe[1],
                            deptIdPath: ascRe[2], deptNamePath: ascRe[3]
                        };
                    }
                }
                settings.callback.call(null, callbackObj);
            }
        });
    };
})(jQuery);











