﻿/**************配置参数 Start*************************/
var ProductAddress = "JTV-APP05-P|JTV-APP13"; //产品环境域名或主机名,两个主机名之间以"|"隔开
/**************配置参数 End*************************/


/**************以下代码请勿修改*************************/
var IsTestService = true; //是否为测试环境
if (("|" + ProductAddress.toLowerCase() + "|").indexOf("|" + location.host.toLowerCase().split(':')[0] + "|") >= 0) {
    IsTestService = false;
}
var ServiceName = IsTestService ? "http://t28/system/asc" : "http://sc-sz";
var RelativePathConfig = "";
var height = "480px";
var width = "325px";
var width1 = "680px";
//当浏览器为IE6.0时,重新设置弹出框高度
var ua = navigator.userAgent;
if (ua.lastIndexOf("MSIE 6.0") != -1) {
    if (ua.lastIndexOf("Windows NT 5.1") != -1) {
        //alert("xp.ie6.0");    
        height = "520px";
        width = "330px";
        width1 = "685px";
    }
}
/**************人员选择-广核通用 Start*************************/
function PersonSelect() {
    //属性
    this.cstyle = "Gray"; //风格颜色
    this.dept_type = "0"; //部门查询方式
    this.dept_area = "";  //人员范围
    this.idept_id = "";   //默认部门
    this.nstyle = "1";   //导航方式
    this.staff_no = "";  //默认选择人员,多选人员属性
    this.staff_no_ns = ""; //禁选人员
    this.msg_ns = "";  //禁选说明
}

//单选人员
PersonSelect.prototype.PopSinglePerson = function () {
    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.dept_type;
    args[2] = this.nstyle;
    args[3] = this.dept_area;
    args[4] = this.idept_id;
    args[5] = this.staff_no_ns;
    args[6] = this.msg_ns;

    var url = RelativePathConfig + '/';
    var returnval = window.showModalDialog(url + "sltSinPerson.htm", args, "dialogHeight:" + height + ";dialogWidth:600px;edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}

//多选人员
PersonSelect.prototype.PopMulitiPerson = function () {
    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.dept_type;
    args[2] = this.nstyle;
    args[3] = this.dept_area;
    args[4] = this.idept_id;
    args[5] = this.staff_no;
    args[6] = this.staff_no_ns;
    args[7] = this.msg_ns;

    var url = RelativePathConfig + '/';    
    var returnval = window.showModalDialog(url + "sltMulPerson.htm", args, "dialogHeight:" + height + ";dialogWidth:" + width1 + ";edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}

/**************人员选择-广核通用 End*************************/

/**************部门选择-广核通用 Start*************************/
function DeptSelect() {
    //属性
    this.cstyle = "Gray"; //风格颜色
    this.dept_type = "0";
    this.dept_area = ""; //部门范围
    this.dept_rank = ""; //部门级别
    this.depth_ns = "";    //可选深度
    this.dept_id = "";  //已选部门[多选部门属性]
    this.dept_no = "";  //已选部门编号[多选部门属性]


}

DeptSelect.prototype.PopSingleDepth = function () {
    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.dept_type;
    args[2] = this.dept_area;
    args[3] = this.dept_rank;
    args[4] = this.depth_ns;
    args[5] = this.depth_ns_msg;

    var url = RelativePathConfig + '/';
    var returnval = window.showModalDialog(url + "sltSinDept.htm", args, "dialogHeight:" + height + ";dialogWidth:" + width + ";edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}

DeptSelect.prototype.PopMulitiDepth = function () {

    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.dept_type;
    args[2] = this.dept_area;
    args[3] = this.dept_rank;
    args[4] = this.depth_ns;
    args[5] = this.depth_ns_msg;
    args[6] = this.dept_id;
    args[7] = this.dept_no;

    var url = RelativePathConfig + '/';
    var returnval = window.showModalDialog(url + "sltMulDept.htm", args, "dialogHeight:" + height + ";dialogWidth:" + width1 + ";edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}
/**************部门选择-广核通用 End*************************/




/**************人员选择-工程专用 Start*************************/
function ProjectPersonSelect() {

    //属性
    this.cstyle = "Gray"; //风格颜色    
    this.dept_area = ""; 	//人员范围
    this.idept_id = ""; 	//默认部门
    this.staff_no = ""; 	//默认人员

}

//单选人员
ProjectPersonSelect.prototype.PopSinglePerson = function () {
    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.dept_area;
    args[2] = this.idept_id;

    var url = RelativePathConfig + '/';
    var returnval = window.showModalDialog(url + "sltSinProPerson.htm", args, "dialogHeight:" + height + ";dialogWidth:600px;edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}

//多选人员
ProjectPersonSelect.prototype.PopMulitiPerson = function () {
    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.dept_area;
    args[2] = this.idept_id;
    args[3] = this.staff_no;


    var url = RelativePathConfig + '/';
    //alert(url);
    var returnval = window.showModalDialog(url + "sltMulProPerson.htm", args, "dialogHeight:" + height + ";dialogWidth:600px;edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}
/**************人员选择-工程专用 End*************************/

/**************部门选择-工程专用 Start*************************/
function ProjectDeptSelect() {
    //属性    
    this.cstyle = "gray"; //风格颜色
    this.dept_area = ""; //部门范围
    this.dept_rank = ""; //部门级别
    this.depth_ns = "";    //禁选深度
    this.depth_ns_msg = ""; //禁选原因
    this.dept_id = "";  //已选部门[多选部门属性]
    this.dept_no = "";  //已选部门编号[多选部门属性]


}

ProjectDeptSelect.prototype.PopSingleDepth = function () {
    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.dept_area;
    args[2] = this.dept_rank;
    args[3] = this.depth_ns;
    args[4] = this.depth_ns_msg;

    var url = RelativePathConfig + '/';
    var returnval = window.showModalDialog(url + "sltSinProDept.htm", args, "dialogHeight:" + height + ";dialogWidth:" + width + ";edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}

ProjectDeptSelect.prototype.PopMulitiDepth = function () {

    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.dept_area;
    args[2] = this.dept_rank;
    args[3] = this.depth_ns;
    args[4] = this.depth_ns_msg;
    args[5] = this.dept_id;
    args[6] = this.dept_no;

    var url = RelativePathConfig + '/';
    var returnval = window.showModalDialog(url + "sltMulProDept.htm", args, "dialogHeight:" + height + ";dialogWidth:" + width1 + ";edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}

/**************部门选择-工程专用 End*************************/

/**************人员手机号码选择 Start*************************/
function PersonPhoneSelect() {

    //属性
    this.cstyle = "Gray"; //风格颜色
    this.dept_area = "";  //人员范围
    this.idept_id = "";   //默认部门
    this.staff_no = ""; //已选人员
}

PersonPhoneSelect.prototype.PopPersonPhone = function () {
    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.dept_area;
    args[2] = this.idept_id;
    args[3] = this.staff_no;



    var url = RelativePathConfig + '/';
    var returnval = window.showModalDialog(url + "sltPersonPhone.htm", args, "dialogHeight:" + height + ";dialogWidth:" + width1 + ";edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}
/**************人员手机号码选择 End*************************/

/**************常量人员选择 Start*************************/
function CosPersonSelect() {

    //属性
    this.cstyle = "Gray"; //风格颜色    
    this.cos_staff_no = "";
}
//单选人员
CosPersonSelect.prototype.PopSinglePerson = function () {
    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.cos_staff_no;


    var url = RelativePathConfig + '/';
    var returnval = window.showModalDialog(url + "sltSinCosPerson.htm", args, "dialogHeight:" + height + ";dialogWidth:600px;edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}
//多选人员

CosPersonSelect.prototype.PopMulitiPerson = function () {
    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.cos_staff_no;



    var url = RelativePathConfig + '/';
    var returnval = window.showModalDialog(url + "sltMulCosPerson.htm", args, "dialogHeight:" + height + ";dialogWidth:600px;edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}
/**************常量人员选择 End*************************/


/**************单选项目 Start*************************/
function ProjectSelect() {

    //属性
    this.cstyle = "Gray"; //风格颜色
    this.simple_name_ns = ""; //禁选项目简称
    this.msg_ns = ""; //禁选原因
}
//单选项目
ProjectSelect.prototype.PopProject = function () {
    var args = new Array();

    args[0] = this.cstyle;
    args[1] = this.simple_name_ns;
    args[2] = this.msg_ns;

    var url = RelativePathConfig + '/';
    var returnval = window.showModalDialog(url + "sltProject.htm", args, "dialogHeight:" + height + ";dialogWidth:600px;edge:Raised;center:Yes;help:no;resizable:no;status:no;scroll:no");
    return returnval;
}

/**************单选项目 End*************************/
