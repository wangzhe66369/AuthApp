﻿

(function ($) {
    //RelativePathConfig = "Plugins/org/ASC_Select"; //调用文件相对于页面文件的地址配置
    //单选
    $.fn.SingleDeptSelection = function (options) {
        var defaults = {
            cstyle: "gray",
            dept_area: "",
            dept_rank: "",
            depth_ns: "",
            depth_ns_msg: "",
            callback: null
        };

        var settings = $.extend(defaults, options || {});
        var self = $(this);
        self.click(function () {

            /* 工程专用
            var ascDeptSelection = new ProjectDeptSelect();
            */
            //广核用
            var ascDeptSelection = new DeptSelect();

            ascDeptSelection.cstyle = settings.cstyle;
            ascDeptSelection.dept_area = settings.dept_area;
            ascDeptSelection.dept_rank = settings.dept_rank;
            ascDeptSelection.depth_ns = settings.depth_ns;
            ascDeptSelection.depth_ns_msg = settings.depth_ns_msg;

            var ascRe = ascDeptSelection.PopSingleDepth();

            if (settings.callback != null) {
                var callbackObj = null;
                if (ascRe != null) {
                    //部门ID //部门编号	//部门id路径 //部门中文路径 //部门简称 	//部门全称//部门级别//部门深度
                    callbackObj = { deptId: ascRe[0], deptNo: ascRe[1],
                        deptIdPath: ascRe[2], deptPath: ascRe[3],
                        deptNameShort: ascRe[4], deptName: ascRe[5],
                        deptLevel: ascRe[6], deptRank: ascRe[7]
                    };
                }
                settings.callback.call(null, callbackObj);
            }
        });
        

    };

    //多选 
    $.fn.MultiDeptSelection = function (options) {
        var defaults = {
            cstyle: "gray",
            dept_area: "",
            dept_rank: "",
            depth_ns: "",
            depth_ns_msg: "",
            dept_id: "",
            dept_no: "",
            dept_no_handler: null,
            dept_id_handler: null,
            callback: null
        };

        var settings = $.extend(defaults, options || {});
        var self = $(this);
        self.click(function () {

            /* 工程专用
            var ascDeptSelection = new ProjectDeptSelect();
             */
            //广核用
            var ascDeptSelection = new DeptSelect();

            ascDeptSelection.cstyle = settings.cstyle;
            ascDeptSelection.dept_area = settings.dept_area;
            ascDeptSelection.dept_rank = settings.dept_rank;
            ascDeptSelection.depth_ns = settings.depth_ns;
            ascDeptSelection.depth_ns_msg = settings.depth_ns_msg;
            if (jQuery.isFunction(settings.dept_id)) {
                ascDeptSelection.dept_id = settings.dept_id.call(null);
            }
            else {
                ascDeptSelection.dept_id = settings.dept_id;
            }
            if (jQuery.isFunction(settings.dept_no)) {
                ascDeptSelection.dept_no = settings.dept_no.call(null);
            }
            else {
                ascDeptSelection.dept_id = settings.dept_no;
            }

            var ascRe = ascDeptSelection.PopMulitiDepth();
            if (settings.callback != null) {
                var callbackObj = null;
                if (ascRe != null) {
                    //部门ID //部门编号	//部门id路径 //部门中文路径 //部门简称 	//部门全称//部门级别//部门深度
                    callbackObj = { deptId: ascRe[0], deptNo: ascRe[1],
                        deptIdPath: ascRe[2], deptPath: ascRe[3],
                        deptNameShort: ascRe[4], deptName: ascRe[5],
                        deptLevel: ascRe[6], deptRank: ascRe[7]
                    };
                }
                settings.callback.call(null, callbackObj);
            }
        });

    };
})(jQuery);











