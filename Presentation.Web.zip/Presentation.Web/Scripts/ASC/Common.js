//��ʾ��ʾ��Ϣ
function ShowMouseMenu(txt) {
    var vTop = 0;
    var DivH = 80;
    changeContent(txt);
    if (event.clientX + 240 > document.body.clientWidth)
        MouseMenu.style.left = event.clientX + document.body.scrollLeft - 240;
    else
        MouseMenu.style.left = event.clientX + document.body.scrollLeft;

    if (event.clientY + DivH > document.body.clientHeight) {
        if (event.clientY < DivH)
            vTop = event.clientY + document.body.scrollTop - DivH + (DivH - event.clientY);
        else
            vTop = event.clientY + document.body.scrollTop - DivH;
        if (vTop < 100 && event.clientX < 228) vTop = 100;
    }
    else
        vTop = event.clientY + document.body.scrollTop + 5;
    MouseMenu.style.top = vTop;
    MouseMenu.style.visibility = 'visible';
}
//������ʾ��
function setHidden() {
    MouseMenu.style.visibility = 'hidden';
}

//��������ʾ�ı�����
function changeContent(txt) {
    var str
    str = "<table border='1' width='240' style='border-collapse: collapse;' bordercolor='#000000' bgcolor='#BBC9FF'>";
    str += "<TR><TD style='font-size:10pt;color:black'>";
    str += txt;
    str += "</TD></TR></Table>";
    MouseMenu.innerHTML = str;
}