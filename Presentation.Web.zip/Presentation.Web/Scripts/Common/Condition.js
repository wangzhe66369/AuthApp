﻿
function SelectedAjax(ActivityVal, select, methodName, controllersName, areaName) {
    $.ajax({
        url: '@Url.Action("' + methodName + '", "' + controllersName + '", new { Area = "' + areaName + '" })',
        datatype: 'json',
        type: "Post",
        data: {
            activityId: ActivityVal
        },
        processData: true,
        success: function (data) {
            var jsonResult = jQuery.parseJSON(data);
            if (ActivityVal.indexOf("day") >= 0) {
//                var strs = ActivityVal.split("-");
//                var str0 = strs[0];
//                var textSelect = $("#Flexible").find("option:selected").text();

//                if ($("[name='"+str0+"']").length === 0) {
//                    var tabHtml = '<tr>'
//                                            + ' <th width="100">'+textSelect+'</th>'
//                                            + ' <th width="10">  &nbsp;</th>'
//                                            + ' <td width="100">'
//                                             + ' <input id = "EdsId" name="EdsId" style="width: 167px">'
//                                            + ' </select> '
//                                            + ' </td>'
//                                             + '<td style="text-align: left;">'
//                                            + '<span title="删除" onclick="deleteRow(this);" class="ui-icon ui-icon-delete" style="cursor: pointer"></span>'
//                                            + '</td>'
//                                            + ' <td>&nbsp </td>'
//                                            + '</tr>';
//                    select.after(tabHtml);
//                }

            } else if (ActivityVal.indexOf("input") >= 0) {

                var strs = ActivityVal.split("-");
                var str0 = strs[0];
                var textSelect = $("#Flexible").find("option:selected").text();

                if ($("[name='" + str0 + "']").length === 0) {
                    var tabHtml = '<tr>'
                                            + ' <th width="100">' + textSelect + '</th>'
                                            + ' <th width="10">  &nbsp;</th>'
                                            + ' <td width="100">'
                                             + ' <input id = "' + str0 + '" name="' + str0 + '" style="width: 167px">'
                                            + ' </select> '
                                            + ' </td>'
                                             + '<td style="text-align: left;">'
                                            + '<span title="删除" onclick="deleteRow(this);" class="ui-icon ui-icon-delete" style="cursor: pointer"></span>'
                                            + '</td>'
                                            + ' <td>&nbsp </td>'
                                            + '</tr>';
                    select.after(tabHtml);
                }

            } else {



            }
            //            switch (ActivityVal) {

            //                case "ActivityCount":
            //                    if ($("[name='ActivityCountType']").length === 0) {

            //                        var tabHtml = '<tr>'
            //                                + ' <th width="100"> 活度计算类型</th>'
            //                                + ' <th width="10">  &nbsp;</th>'
            //                                + ' <td width="100">'
            //                                + ' <select id = "ActivityCountType" name="ActivityCountType" style="width: 167px">'
            //                                + ' </select> '
            //                                + ' </td>'
            //                                 + '<td style="text-align: left;">'
            //                                + '<span title="删除" onclick="deleteRow(this);" class="ui-icon ui-icon-delete" style="cursor: pointer"></span>'
            //                                + '</td>'
            //                                + ' <td>&nbsp </td>'
            //                                + '</tr>';

            //                        select.after(tabHtml);
            //                        for (var i in jsonResult) {
            //                            $("#ActivityCountType").append('<option value="' + jsonResult[i].Code + '">' + jsonResult[i].Name + '</option>')
            //                        }
            //                    }

            //                    break;
            //                case "WasteType":
            //                    if ($("[name='WasteType']").length === 0) {
            //                        var tabHtml = '<tr>'
            //                                + ' <th width="100"> 废物类型</th>'
            //                                + ' <th width="10">  &nbsp;</th>'
            //                                + ' <td width="100">'
            //                                + ' <select id = "WasteType" name="WasteType" style="width: 167px">'
            //                                + ' </select> '
            //                                + ' </td>'
            //                                 + '<td style="text-align: left;">'
            //                                + '<span title="删除" onclick="deleteRow(this);" class="ui-icon ui-icon-delete" style="cursor: pointer"></span>'
            //                                + '</td>'
            //                                + ' <td>&nbsp </td>'
            //                                + '</tr>';

            //                        select.after(tabHtml);
            //                        for (var i in jsonResult) {
            //                            $("#WasteType").append('<option value="' + jsonResult[i].Code + '">' + jsonResult[i].Name + '</option>')
            //                        }
            //                    }
            //                    break;
            //                case "EdsId":
            //                    if ($("[name='EdsId']").length === 0) {
            //                        var tabHtml = '<tr>'
            //                                + ' <th width="100"> 能谱序号</th>'
            //                                + ' <th width="10">  &nbsp;</th>'
            //                                + ' <td width="100">'
            //                                 + ' <input id = "EdsId" name="EdsId" style="width: 167px">'
            //                                + ' </select> '
            //                                + ' </td>'
            //                                 + '<td style="text-align: left;">'
            //                                + '<span title="删除" onclick="deleteRow(this);" class="ui-icon ui-icon-delete" style="cursor: pointer"></span>'
            //                                + '</td>'
            //                                + ' <td>&nbsp </td>'
            //                                + '</tr>';
            //                        select.after(tabHtml);
            //                    }
            //                    break;

            //                default:

            //            }
        }
    });

}
function deleteRow(event) {

    $(event).parent().parent().remove();
}