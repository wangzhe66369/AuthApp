﻿//得到天数
function GetDayNum(startDate, endDate) {
    var sDate = startDate;
    var eDate = endDate;
    var sArr = sDate.split('-');
    var eArr = eDate.split('-');
    var sRDate = new Date(sArr[0], sArr[1], sArr[2]);
    var eRDate = new Date(eArr[0], eArr[1], eArr[2]);
    var result = (eRDate - sRDate) / (24 * 60 * 60 * 1000);
    return result;
}

//获取后台数据自动填充,方法路径,参数,控件Id
function AutoCompleteByAJax(strUrl, strId) {
    $('#' + strId).autocomplete({
        source: function (request, response) {
            $.ajax({
                url: strUrl,
                data: { keyword: request.term },
                type: "GET",
                dataType: "json",
                success: function (data, status) {
                    response($.map(data.autoCompleteList, function (item) {
                        return {
                            label: item.Name,
                            value: item.Name
                        };
                    }));
                }
            });
        }
    });
}

