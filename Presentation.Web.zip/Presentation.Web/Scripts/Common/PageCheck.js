﻿$(function () {
    $(".JustAllowFloat").keypress(function (e) {
        if (($(this).val() == "" || $(this).val().indexOf(".") > 0) && e.keyCode == 46) return false;
        if ($(this).val().indexOf(".") > 0 && $(this).val().split(".")[1].length >= 3) return false;
        if ((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode == 46)) {
            return true;
        }
        return false;
    });
    $(".Wdate").attr("readonly", "readonly");
});