﻿
var ExjqGridPage = function (jqGridElementId, jqGridPagerElementId, rowList) {
    /// <summary>
    /// 扩展jqGrid Tree 翻页
    /// </summary>
    ///<param name="jqGridElementId">jqGrid列表对象ID</param>
    ///<param name="jqGridPagerElementId">jqGrid列表翻页对象ID</param>
    ///<param name="rowList">jqGrid列表翻页下拉框集合</param>

    var that = $("#" + jqGridElementId);
    var btnArray = new Array();
    this.JqGridElementId = jqGridElementId;
    this.ContainerId = jqGridPagerElementId;
    this.RowList = rowList;
    this.Page = that.jqGrid('getGridParam', 'page');
    this.PageSize = that.jqGrid('getGridParam', 'postData').treePageSize;
    this.TotalRecord = that.jqGrid('getGridParam', 'records');
    this.HasPreviousPage = function () {
        if (this.Page <= 1) {
            return false;
        } else {
            return true;
        }
    };
    this.HasNextPage = function () {
        var record = this.TotalRecord - this.PageSize * this.Page;
        if (record > 0) {
            return true;
        } else {
            return false;
        }
    };

    //添加按钮方法
    this.CustomButtonAdd = function (btn) {
        var k = new customBtn();
        k.caption = btn.caption;
        k.onClickButton = btn.onClickButton;
        k.title = btn.title;

        btnArray.push(k);
    };
    //自定义按钮对象
    var customBtn = function () {
        this.caption = null;
        this.onClickButton = null;
        this.title = null;
        this.cursor = "pointer";

        return this;
    };

    this.OutPagerHtml = function () {
        var container = $("#" + jqGridPagerElementId);
        container.html("");

        this.MainDiv = $("<div class='ui-function-box ui-pager ui-state-default ui-jqgrid-pager ui-corner-bottom' id='div-pager' style='width: 100%; overflow: visible; border-top-width: 0;' dir='ltr' sizset='true' />");
        this.PagerDiv = $("<div class='ui-pager-control' id='pg_div-pager' role='group' sizset='false' />");
        //翻页导航条区域
        this.PagerMainTable = $("<table class='ui-pg-table' role='row' style='width: 100%; height: 100%; table-layout: fixed;' border='0' cellSpacing='0' cellPadding='0' sizset='false' ></table>");
        //翻页导航条内容
        this.PagerContentTable = $("<table class='ui-pg-table' style='table-layout: auto;' border='0' cellSpacing='0' cellPadding='0'></table>");
        //自定义导航条按钮
        this.CustomBtnTable = $("<table class='ui-pg-table navtable' style='float: left; table-layout: auto;' border='0' cellSpacing='0' cellPadding='0'></table>");

        //首页
        this.first = $("<td class='ui-pg-button ui-corner-all' id='first_div-pager'><span class='ui-icon ui-icon-seek-first'></span></td>");
        //上一页
        this.prev = $("<td class='ui-pg-button ui-corner-all' id='prev_div-pager'><span class='ui-icon ui-icon-seek-prev'></span></td>");
        //转到
        this.jump = $("<input class='ui-pg-input' role='textbox' type='text' size='2' maxLength='7'  value='0' />");
        //设置显示当前页
        this.jump.val(this.Page);
        this.jump.attr("JqGridElementId", this.JqGridElementId);
        this.jump.bind("keyup", function (event) {
            if (event.keyCode == "13") {
                $('#' + $(this).attr("JqGridElementId")).jqGrid('setGridParam', {
                    page: parseInt(this.value)
                }).trigger("reloadGrid");
            }
        });
        //{共 * 页}
        var _modPage = (this.TotalRecord % this.PageSize) > 0 ? 1 : 0;
        var _totalPage = parseInt(this.TotalRecord / this.PageSize) + parseInt(_modPage);
        this.totalPage = _totalPage == 0 ? 0 : _totalPage;
        this.totalPageHtml = "共 <span id='sp_1_div-pager'>" + this.totalPage + "</span>页";

        //下一页
        this.next = $("<td class='ui-pg-button ui-corner-all' id='next_div-pager'><span class='ui-icon ui-icon-seek-next'></span></td>");
        //尾页
        this.last = $("<td class='ui-pg-button ui-corner-all' id='last_div-pager'><span class='ui-icon ui-icon-seek-end'></span></td>");
        //下拉框每页显示记录数
        var selectPageSize = document.createElement("select");
        for (var i = 0; i < this.RowList.length; i++) {
            var oOption = document.createElement("OPTION");
            oOption.text = this.RowList[i];
            oOption.value = this.RowList[i];
            selectPageSize.options.add(oOption);
        }
        $(selectPageSize).val(this.PageSize);
        $(selectPageSize).attr("JqGridElementId", this.JqGridElementId)
                    .attr("class", "ui-pg-selbox")
                    .bind("change", function () {
                        var self = $(this);
                        $('#' + self.attr("JqGridElementId")).jqGrid('setGridParam', {
                            page: 1,
                            postData: { 'treePageSize': parseInt(self.children('option:selected').val()) }
                        }).trigger("reloadGrid");
                    });
        this.pageOfPageSize = $("<td></td>").append($(selectPageSize));

        //显示 *-*，共*条
        if (this.TotalRecord > 0) {
            this.displayRecordTxt = "显示" + ((this.PageSize * (this.Page - 1)) + 1) + " - ";
            this.displayRecordTxt = this.displayRecordTxt + ((this.TotalRecord > (this.PageSize * this.Page)) ? (this.PageSize * this.Page) : (this.TotalRecord));
            this.displayRecordTxt = this.displayRecordTxt + "　共 " + this.TotalRecord + " 条";
        }
        else {
            this.displayRecordTxt = "无数据显示";
        }
        
        //禁用首页和上一页
        if (!this.HasPreviousPage()) {
            this.first.addClass("ui-state-disabled");
            this.prev.addClass("ui-state-disabled");
        } else {

            //首页
            this.first.bind("click", function () {
                $("#" + jqGridElementId).jqGrid('setGridParam', { page: 1 }).trigger("reloadGrid");
            });
            //上一页
            this.prev.attr("currentPage", this.Page); //增加当前页属性
            this.prev.bind("click", function () {
                $("#" + jqGridElementId).jqGrid('setGridParam', { page: parseInt(parseInt($(this).attr("currentPage")) - 1) }).trigger("reloadGrid");
            });
        }
        //禁用下一页和最后一页
        if (!this.HasNextPage()) {
            this.next.addClass("ui-state-disabled");
            this.last.addClass("ui-state-disabled");
        } else {
            //下一页
            this.next.attr("currentPage", this.Page); //增加当前页属性
            this.next.bind("click", function () {
                $("#" + jqGridElementId).jqGrid('setGridParam', { page: parseInt($(this).attr("currentPage")) + 1 }).trigger("reloadGrid");
            });

            //末页      
            this.last.attr("maxPage", this.totalPage); //增加当前页属性
            this.last.bind("click", function () {
                $("#" + jqGridElementId).jqGrid('setGridParam', { page: parseInt($(this).attr("maxPage")) }).trigger("reloadGrid");
            });
        }
        //自定义按钮内容
        var customBtnTableTr = $("<tr></tr>");
        for (var b = 0; b < btnArray.length; b++) {
            var div = $("<div class='ui-pg-div'></div>")
                        .append($(btnArray[b].caption))
                        .bind("click", btnArray[b].onClickButton);
            var td = $("<td></td>")
                        .attr("title", btnArray[b].title)
                        .append(div);
            customBtnTableTr.append(td);
        }
        this.CustomBtnTable.append(customBtnTableTr);

        //翻页内容
        this.PagerContentTable
                    .append(
                        $("<tr></tr>")
                        .append(this.first)//首页
                        .append(this.prev) //上一页
                        .append($("<td class='ui-pg-button ui-state-disabled' style='width: 4px;'><span class='ui-separator'></span></td>"))
                        .append($("<td></td>").append(this.jump).append(this.totalPageHtml))//跳转和共多少页
                        .append($("<td class='ui-pg-button ui-state-disabled' style='width: 4px;'><span class='ui-separator'></span></td>"))
                        .append(this.next)//下一页
                        .append(this.last)//末页
                        .append(this.pageOfPageSize)//下拉框
                        );

        this.PagerMainTable.append(
                    $("<tr></tr>")
                    .append($("<td align='left' id='div-pager_left'></td>").append(this.CustomBtnTable))
                    .append($("<td align='center' id='div-pager_center' style='white-space: pre;' sizset='false' ></td>").append(this.PagerContentTable))
                    .append($("<td align='right' id='div-pager_right'></td>").append(this.displayRecordTxt))
                );

        this.MainDiv.append(this.PagerDiv.append(this.PagerMainTable));
        $("#" + jqGridPagerElementId).append(this.MainDiv);
    };
};