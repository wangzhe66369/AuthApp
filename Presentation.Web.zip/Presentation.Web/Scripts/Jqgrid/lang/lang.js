﻿$(function () {
    if (GetLang() == "zh-CN") {
        loadJsFile("/RWIS/Scripts/Jqgrid/lang/grid.locale-cn.js");
    }
    else if (GetLang() == "en-US") {
        loadJsFile("/RWIS/Scripts/Jqgrid/lang/grid.locale-en.js");
    }
});