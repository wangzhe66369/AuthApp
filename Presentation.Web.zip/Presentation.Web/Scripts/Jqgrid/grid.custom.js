﻿// 自动创建列设置弹出框
function CreateCustomTable(gridId, displayColNameString) {
    var colNames = $("#" + gridId).jqGrid('getGridParam', 'colNames');
    var colModel = $("#" + gridId).jqGrid('getGridParam', 'colModel');
    $('body').append("<table id='" + gridId + "CustomTable' style='display: none;cursor:scorll'></table>");
    var tableObject = $("#" + gridId + "CustomTable");
    var displayColNameString = displayColNameString == "" || displayColNameString == undefined ? "" : "," + displayColNameString + ",";
    var trString, colModelName;
    $.each(colNames, function (index) {
        if (colModel[index].frozen == true || colModel[index].hidden == true || colNames[index] == "") {
            return;
        }
        colModelName = colModel[index].name;
        if (displayColNameString == "" || displayColNameString.indexOf("," + colModelName + ",") != -1) {
            trString = "<tr><td><input type='checkbox' value='" + colModelName + "' checked='true' onclick='ToggleColumn(this);' />" + colNames[index] + "</td>";
            jQuery("#list").jqGrid('showCol', colModelName).trigger("reloadGrid");
        }
        else {
            trString = "<tr><td><input type='checkbox' value='" + colModelName + "' onclick='ToggleColumn(this);' />" + colNames[index] + "</td>";
            jQuery("#list").jqGrid('hideCol', colModelName).trigger("reloadGrid");
        }
        tableObject.append(trString);
    });
}  

// 弹出设置框
function ShowCustomTable(gridId) {
    $("#" + gridId + "CustomTable").dialog({
        title: "设置",
        height: 400
    });
}
// 显示隐藏列
function ToggleColumn(obj) {
    var columnModelName = $(obj).val();
    if ($(obj).prop("checked")) {
        jQuery("#list").jqGrid('showCol', columnModelName).trigger("reloadGrid");
    }
    else {
        jQuery("#list").jqGrid('hideCol', columnModelName).trigger("reloadGrid");
    }
}