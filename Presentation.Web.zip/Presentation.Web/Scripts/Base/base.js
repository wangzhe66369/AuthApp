﻿$(function () {
    $("h3 > span").bind("click", function () {
        $(this).toggleClass(function () {
            if ($(this).is('.ui-icon-direction-up')) {
                $(this).removeClass("ui-icon-direction-up");
                return 'ui-icon-direction-down';
            } else {
                $(this).removeClass("ui-icon-direction-down");
                return 'ui-icon-direction-up';
            }
        });
        $(this).parent().next("table,div").toggle();
    });

    $.fn.lock = function (options) {
        var self = $(this);
        self.loadingbar("init",
            {
                showText: true,
                desc:"处理中，请稍后...",
                isMask: true
            });
        };

    $.fn.unlock = function (options) {
        $("#wrapper").loadingbar("remove");
    };


});
