﻿//
//net01 mvc  人员选择组件
//v1.0
//
(function ($, undefined) {
    var _selectedLinkObj = null,
        _selectedUserTRArray = new Array(),
        caches = {};

    var _consts = {
        id: {
            DIV: "_personselection",
            INPUT: "_input",
            SELECT: "_select"

        }
    };

    $.widget("ui.personselection", {
        version: "1.0",
        personselectionId: "",
        options: {
            autoOpen: false,
            height: 520,
            width: 575,
            modal: true,
            resizable: false,
            title: "人员选择对话框",
            appendTo: "body",
            dept: {
                source: [],
                callback: {
                    selectedComplete: null
                }
            },
            user: {
                minLength: 4,
                delay: 100,
                source: []
            },
            columnHead: ["员工号", "姓名", "部门"],
            maxListRows: 50,
            maxSelectedNum: 10,
            source: [],
            response: null,
            callback: {
                confirmClick: null
            }
        },

        _create: function () {
            var self = this,
                doc = this.element[0].ownerDocument;
            self.personselectionId = self.element[0].id + _consts.id.DIV;

            this.personselectiontable = $("<table></table>");
            //输入控件
            this.inputControl = $("<input></input>")
                .attr("id", self.element[0].id + _consts.id.INPUT)
                .attr("type", "text")
                .addClass("ui-personselection-input");
            //选择控件
            this.selectControl = $("<input></input>")
                .attr("id", self.element[0].id + _consts.id.SELECT)
                .attr("type", "text")
                .attr("readonly", "true")
                .addClass("ui-personselection-select");
            //选择控件的图片
            this.selectControlImg = $("<a></a>")
                .attr("href", "#")
                .addClass("ui-personselection-selectimg")
                .bind("click", function (event) {
                    self.selectControl.trigger('click');
                    return false;
                });
            //添加提醒信息
            this.addMsg = $("<span>只能选择" + self.options.maxSelectedNum + "个员工号。</span>")
                .addClass("ui-personselection-warnning");
            //添加人员按钮
            this.addUserBtn = $("<button>添加人员</button>&nbsp;&nbsp;&nbsp;&nbsp;")
                .addClass("ui-personselection-addselecteduserbtn")
                .bind("click", function (event) {
                    self._addSelectedUser();
                });
            //选择提示信息
            this.chooseMsg = $("<span>按Ctrl键可多选，显示搜索结果的前" + self.options.maxListRows + "条。</span>")
                .addClass("ui-personselection-information");
            //用户信息列表头部
            this.userlisthead = $("<table><thead><tr class='ui-widget-header'><th style='width:100px;'>" + self.options.columnHead[0] + "</th><th style='width:200px;'>" + self.options.columnHead[1] + "</th><th style='width:250px;'>" + self.options.columnHead[2] + "</th></tr></thead></table>")
                .attr("width", "100%")
                .addClass("ui-widget ui-widget-content");
            //用户信息列表实体
            this.userlist = $("<table width='100%' cellpadding='0' cellspacing='0' border='0'  class='ui-personselection-usertable'></table>");
            //所选用户显示区域
            this.chooseUserArea = $("<div></div>")
                .addClass("ui-personselection-textarea")
                .attr("contentEditable", "true")
                .bind("keydown", function (event) {
                    return false;
                });

            //用户对话框表格容器
            this.personselectionMainTable = $("<table></table>")
                .attr("width", "98%").attr("border", "0").attr("align", "center").attr("cellpadding", "0").attr("cellspacing", "0");
            $("<tr><td>请输入员工号、姓名的拼音或中文：</td><td>点击下拉列表，从部门中选取：</td></tr>").appendTo(this.personselectionMainTable);
            $("<tr></tr>").append($("<td></td>").append(this.inputControl)).append($("<td style='position:relative;'></td>").append(this.selectControl).append(this.selectControlImg)).appendTo(this.personselectionMainTable);
            $("<tr></tr>").append($("<td></td>").attr("colspan", "2").append(this.chooseMsg)).appendTo(this.personselectionMainTable);

            $("<tr></tr>").append($("<td></td>").attr("colspan", "2").append(this.userlisthead).append($("<div></div>").addClass("ui-personselection-usersdiv").append(this.userlist))).appendTo(this.personselectionMainTable);
            $("<tr></tr>").append($("<td></td>").attr("colspan", "2").append(this.addUserBtn).append(this.addMsg)).appendTo(this.personselectionMainTable);
            $("<tr></tr>").append($("<td></td>").attr("colspan", "2").append(this.chooseUserArea)).appendTo(this.personselectionMainTable);

            //用户对话框
            this.personselection = $("<div></div>")
                .addClass("ui-personselection")
                .attr("maxSelectedNum", self.options.maxSelectedNum)
                .attr("title", self.options.title)
                .attr("id", self.personselectionId)
                .append(this.personselectionMainTable)
                .appendTo($(this.options.appendTo || "body", doc)[0])
                .bind("confirmClickCallback.personselection", self.options.callback.confirmClick);


            this.element.bind('click.personselection', function (event) {
                self.personselection.dialog("open");
            });

            //self._initautocompleteSource();
        },

        _initSource: function () {
            if (this.options.source != null && this.options.source.length > 0) {
                var self = this, array;
                if ($.isArray(this.options.source)) {
                    array = this.options.source;
                    this.source = function (request, response) {
                        response(array);
                    };
                }
                if (array != null && array.length > 0) {
                    $(array).each(function () {
                        self._addSelectedUserToContainer(this.Code, this.Name);
                    });
                }
            }
            this._initSelectable();
        },

        _init: function () {
            var self = this;
            
            this.personselection.dialog({
                autoOpen: self.options.autoOpen,
                height: self.options.height,
                width: self.options.width,
                modal: self.options.modal,
                resizable: self.options.resizable,
                buttons: [
                {
                    text: "确认",
                    icons: { primary: "ui-icon-ok" },
                    click: function () {
                        self.personselection.trigger("confirmClickCallback.personselection", self._getUserInfoFormContainer());
                        $(this).dialog("close");
                    }
                }, {
                    text: "取消",
                    icons: { primary: "ui-icon-cancel" },
                    click: function () { $(this).dialog("close"); }
                }],
                close: function () { $(this).dialog("close"); },
                open: function () {
                    self._resetControlerValue();
                }
            });
            //监听对话框打开事件
            this.personselection.on("dialogopen", function (event, ui) {
                //重置部门选择框的值
                self.selectControl.val("");
            });

            this.selectControl.mvczTree({
                source: self.options.dept.source,
                height:self.options.height-200,
                callback: {
                    selectedComplete: function (event, e, id, treeNode) {
                        var r;
                        if (self.options.dept.callback.selectedComplete == null) {
                            r = self.selectedComplete(event, e, id, treeNode);
                        } else if ($.isFunction(self.options.dept.callback.selectedComplete)) {
                            r = self.options.dept.callback.selectedComplete(event, e, id, treeNode);
                        }
                        //缓存部门选择的结果
                        self.data.setSelectedDeptsCache(self.personselectionId, treeNode);
                        //执行查询功能
                        var minLength = self.inputControl.autocomplete("option", "minLength");
                        //处理文本框内容为空，选择部门后无效问题
                        self.inputControl.autocomplete("option", "minLength", 0);
                        self.inputControl.autocomplete("search", self.inputControl.val());
                        self.inputControl.autocomplete("option", "minLength", minLength);
                    }
                }
            });
            this.inputControl.autocomplete({
                delay: self.options.user.delay,
                minLength: self.options.user.minLength,
                autoFocus: true,
                searchResult: [],
                source: function () {
                    if (typeof self.options.user.source === "string") {
                        $.ajax({
                            url: self.options.user.source,
                            type: "GET",
                            dataType: "json",
                            success: function (data, status) {
                                self._setUserListSource(data);
                            }
                        });
                    } else {
                        this.source = self.options.user.source;
                    }
                },
                response: function (event, ui) {
                    self._setUserListSource(ui.content);
                }
            }).data("ui-autocomplete")._renderItem = function (ul, item) {//自动下拉提示不显示
                ul.attr("class", "");
                return $("");
            };

            self._initSource();
            $.extend($.fn.mvcpersonselection.data, self.data);
        },
        _response: function (e, data) {
            $("#" + this.id.split("_")[0]).personselection("option", "loadusersource", data);
        },
        _normalize: function (items) {
        },

        _setOptions: function (options) {
            var self = this;
            $.each(options, function (key, value) {
                self._setOption(key, value);
            });
        },

        _setOption: function (key, value) {
            $.Widget.prototype._setOption.apply(this, arguments);
            if (key === "source") {
                this._initSource();
            } else if (key === "loadusersource") {
                this._setUserListSource(value);
            }
        },
        _initSelectable: function () {
            var self = this;
            $(self.userlist).selectable({
                stop: function () {
                    _selectedUserTRArray = [];
                    $(".ui-selected", this).each(function () {
                        _selectedUserTRArray.push(this);
                    });
                },
                filter: "tr"
            });
        },
        _resetControlerValue: function () {
            var self = this;
            self.inputControl.val("");
            self.userlist.find("tr").each(function () {
                $(this).remove();
            });
            //self.chooseUserArea.html("");
        },

        selectedComplete: function (event, e, id, treeNode) {
            var zTree = $.fn.zTree.getZTreeObj(id),
			    nodes = zTree.getSelectedNodes(),
			    v = "";
            nodes.sort(function (a, b) { return a.id - b.id; });

            for (var i = 0, l = nodes.length; i < l; i++) {
                v += nodes[i].name + ",";
            }
            if (v.length > 0) v = v.substring(0, v.length - 1);
            var obj = $("#" + id.replace("_ztree", ""));
            obj.attr("value", v);

            return v;
        },
        bindUserListSource: function () {
            var self = this;
            $(self.userlist).find("tr").each(function () {
                $(this).remove();
            });

            $(self.source).each(function () {
                $("<tr></tr>")
                    .bind("dblclick", function () {
                        var td = this.children;
                        //检测人员所选数量是否超过限制
                        var r = self._chkChoosedUserNum();
                        if (!r) {
                            alert("所选人数已超过限制!");
                            return;
                        }
                        self._addSelectedUserToContainer(td[0].innerText, td[1].innerText);
                    })
                    .append("<td style='width:110px;'>" + this.Code + "</td>")
                    .append("<td style='width:200px;'>" + this.Name + "</td>")
                    .append("<td style='width:250px'>" + self._tool.nullStringToEmpty(this.Dept) + "</td>")
                    .appendTo(self.userlist);
            });
        },
        _setUserListSource: function (datasource) {
            var self = this;
            $(self.userlist).find("tr").each(function () {
                $(this).remove();
            });
            var source = self.source;
            if (datasource != null) {
                source = datasource;
            }
            $(source).each(function () {
                $("<tr></tr>")
                        .bind("dblclick", function () {
                            var td = this.children;
                            //检测人员所选数量是否超过限制
                            var r = self._chkChoosedUserNum();
                            if (!r) {
                                alert("所选人数已超过限制!");
                                return;
                            }
                            self._addSelectedUserToContainer(td[0].innerText, td[1].innerText);
                        })
                        .append("<td style='width:110px;'>" + this.Code + "</td>")
                        .append("<td style='width:200px;'>" + this.Name + "</td>")
                        .append("<td style='width:250px'>" + self._tool.nullStringToEmpty(this.Dept) + "</td>")
                        .appendTo(self.userlist);
            });
        },
        _addSelectedUser: function () {
            var self = this;
            if (_selectedUserTRArray.length <= 0) {
                return;
            }
            $.each(_selectedUserTRArray, function (i, item) {
                //检测人员所选数量是否超过限制
                var r = self._chkChoosedUserNum();
                if (!r) {
                    alert("所选人数已超过限制!");
                    return;
                }
                var td = item.children;
                self._addSelectedUserToContainer(td[0].innerText, td[1].innerText);
            });
            _selectedUserTRArray = [];
        },

        _addSelectedUserToContainer: function (code, name) {
            var self = this;
            var userTemplate = "{0}({1})".replace("{0}", code).replace("{1}", name);

            this.User = $("<label style='text-decoration:underline;'>" + userTemplate + "</label>")
                .bind("click", function (event) {
                    _selectedLinkObj = $(event.target);
                    self.chooseUserArea.find("label").removeClass("ui-personselection-userstable-selecteduser");
                    _selectedLinkObj.addClass("ui-personselection-userstable-selecteduser");

                })
                .bind("keydown", function (event) {
                    //                switch (event.originalEvent.key) {
                    //                    case "Del":
                    //                    case "Backspace":
                    //                    case "Spacebar":
                    //                       
                    //                        break;
                    //                    default:
                    //                        break;
                    //                }
                    return false;
                })
                .bind("dblclick", function (event) {
                    _selectedLinkObj = event.target;
                    $(_selectedLinkObj).remove();

                    //移除选择人员后面的"; "符号
                    var chooseUserContentItems = $(self.chooseUserArea).contents();
                    for (var i = 0; i < chooseUserContentItems.length; i++) {
                        if (i + 1 <= chooseUserContentItems.length) {
                            if ($(chooseUserContentItems[i]).text() == "; " && ($(chooseUserContentItems[i - 1]).text == "" || $(chooseUserContentItems[i + 1]).text() == "; ")) {
                                $(chooseUserContentItems[i]).remove();
                            }
                        }
                    }
                    var firstContents = $(self.chooseUserArea).contents().first();
                    if ($(firstContents).text() == "; ") {
                        $(firstContents).remove();
                    }
                    event.stopPropagation();
                });
            //            this.userRemove = $("<a href='#'></a>")
            //            .addClass("ui-personselection-userstable-selecteduser-removex")
            //            .bind("click", function (event) {
            //                _selectedLinkObj = $(event.target).parent();

            //                $(_selectedLinkObj).remove();

            //                //移除选择人员后面的"; "符号
            //                var chooseUserContentItems = $(self.chooseUserArea).contents();
            //                for (var i = 0; i < chooseUserContentItems.length; i++) {
            //                    if (i + 1 <= chooseUserContentItems.length) {
            //                        if ($(chooseUserContentItems[i]).text() == "; " && ($(chooseUserContentItems[i - 1]).text == "" || $(chooseUserContentItems[i + 1]).text() == "; ")) {
            //                            $(chooseUserContentItems[i]).remove();
            //                        }
            //                    }
            //                }
            //                var firstContents = $(self.chooseUserArea).contents().first();
            //                if ($(firstContents).text() == "; ") {
            //                    $(firstContents).remove();
            //                }
            //            })
            //            .appendTo(this.User);

            this.User.appendTo(self.chooseUserArea);
            self.chooseUserArea.append("; ");
        },
        _getUserInfoFormContainer: function () {
            var self = this, obj, u, arr;
            this.selectedUsers = [];
            self.chooseUserArea.find("label").each(function () {
                obj = this.innerText;
                arr = obj.replace(")", "").split('(');
                u = { Code: arr[0], Name: arr[1].replace("X", "") };
                self.selectedUsers.push(u);
            });
            this.selectedUsers = "{users:" + JSON.stringify(this.selectedUsers) + "}";
            return eval("(" + this.selectedUsers + ")");
        },
        _chkChoosedUserNum: function () {
            var self = this;
            var selectedUserNum = self.chooseUserArea.find("label").length;
            if (selectedUserNum >= self.options.maxSelectedNum) {
                return false;
            }
            return true;
        },
        _tool: {
            nullStringToEmpty: function (value) {
                if (value == null) {
                    return "";
                }
                return value;
            }
        },
        data: {
            getSelectedDepts: function (personselectionId) {
                return caches[personselectionId];
            },
            setSelectedDeptsCache: function (personselectionId, cache) {
                caches[personselectionId] = cache;
            }

        },
        destroy: function () {
            this.chooseUserArea.remove();
            this.inputControl.remove();
            this.selectControl.remove();
            this.personselectionMainTable.remove();
            this.element.remove();
            $.Widget.prototype.destroy.call(this);
        }
    });
    $.fn.mvcpersonselection = {
        _consts: {
            id: {
                DIV: "_personselection",
                INPUT: "_input",
                SELECT: "_select"
            }
        },
        data: {
            getSelectedDepts: null
        },
        getSelectedDepts: function (personselectionId) {
            var o = this.data.getSelectedDepts(personselectionId + _consts.id.DIV);
            return o ? o : null;
        }
    };
})(jQuery);

/*
json2.js
2012-10-08
See http://www.JSON.org/js.html
This code should be minified before deployment.
See http://javascript.crockford.com/jsmin.html
*/
if (typeof JSON !== 'object') {
    JSON = {};
}

(function () {
    'use strict';

    function f(n) {
        // Format integers to have at least two digits.
        return n < 10 ? '0' + n : n;
    }

    if (typeof Date.prototype.toJSON !== 'function') {

        Date.prototype.toJSON = function (key) {

            return isFinite(this.valueOf())
                ? this.getUTCFullYear() + '-' +
                    f(this.getUTCMonth() + 1) + '-' +
                    f(this.getUTCDate()) + 'T' +
                    f(this.getUTCHours()) + ':' +
                    f(this.getUTCMinutes()) + ':' +
                    f(this.getUTCSeconds()) + 'Z'
                : null;
        };

        String.prototype.toJSON =
            Number.prototype.toJSON =
            Boolean.prototype.toJSON = function (key) {
                return this.valueOf();
            };
    }

    var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
        gap,
        indent,
        meta = {    // table of character substitutions
            '\b': '\\b',
            '\t': '\\t',
            '\n': '\\n',
            '\f': '\\f',
            '\r': '\\r',
            '"': '\\"',
            '\\': '\\\\'
        },
        rep;


    function quote(string) {
        escapable.lastIndex = 0;
        return escapable.test(string) ? '"' + string.replace(escapable, function (a) {
            var c = meta[a];
            return typeof c === 'string'
                ? c
                : '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
        }) + '"' : '"' + string + '"';
    }


    function str(key, holder) {
        var i,          // The loop counter.
            k,          // The member key.
            v,          // The member value.
            length,
            mind = gap,
            partial,
            value = holder[key];
        if (value && typeof value === 'object' &&
                typeof value.toJSON === 'function') {
            value = value.toJSON(key);
        }
        if (typeof rep === 'function') {
            value = rep.call(holder, key, value);
        }
        switch (typeof value) {
            case 'string':
                return quote(value);

            case 'number':
                return isFinite(value) ? String(value) : 'null';

            case 'boolean':
            case 'null':
                return String(value);
            case 'object':
                if (!value) {
                    return 'null';
                }

                gap += indent;
                partial = [];

                if (Object.prototype.toString.apply(value) === '[object Array]') {

                    length = value.length;
                    for (i = 0; i < length; i += 1) {
                        partial[i] = str(i, value) || 'null';
                    }
                    v = partial.length === 0
                    ? '[]'
                    : gap
                    ? '[\n' + gap + partial.join(',\n' + gap) + '\n' + mind + ']'
                    : '[' + partial.join(',') + ']';
                    gap = mind;
                    return v;
                }
                if (rep && typeof rep === 'object') {
                    length = rep.length;
                    for (i = 0; i < length; i += 1) {
                        if (typeof rep[i] === 'string') {
                            k = rep[i];
                            v = str(k, value);
                            if (v) {
                                partial.push(quote(k) + (gap ? ': ' : ':') + v);
                            }
                        }
                    }
                } else {
                    for (k in value) {
                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                            v = str(k, value);
                            if (v) {
                                partial.push(quote(k) + (gap ? ': ' : ':') + v);
                            }
                        }
                    }
                }
                v = partial.length === 0
                ? '{}'
                : gap
                ? '{\n' + gap + partial.join(',\n' + gap) + '\n' + mind + '}'
                : '{' + partial.join(',') + '}';
                gap = mind;
                return v;
        }
    }

    if (typeof JSON.stringify !== 'function') {
        JSON.stringify = function (value, replacer, space) {

            var i;
            gap = '';
            indent = '';

            if (typeof space === 'number') {
                for (i = 0; i < space; i += 1) {
                    indent += ' ';
                }

                // If the space parameter is a string, it will be used as the indent string.

            } else if (typeof space === 'string') {
                indent = space;
            }
            rep = replacer;
            if (replacer && typeof replacer !== 'function' &&
                    (typeof replacer !== 'object' ||
                    typeof replacer.length !== 'number')) {
                throw new Error('JSON.stringify');
            }

            return str('', { '': value });
        };
    }

    if (typeof JSON.parse !== 'function') {
        JSON.parse = function (text, reviver) {
            var j;

            function walk(holder, key) {

                var k, v, value = holder[key];
                if (value && typeof value === 'object') {
                    for (k in value) {
                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                            v = walk(value, k);
                            if (v !== undefined) {
                                value[k] = v;
                            } else {
                                delete value[k];
                            }
                        }
                    }
                }
                return reviver.call(holder, key, value);
            }
            text = String(text);
            cx.lastIndex = 0;
            if (cx.test(text)) {
                text = text.replace(cx, function (a) {
                    return '\\u' +
                        ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                });
            }
            if (/^[\],:{}\s]*$/
                    .test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@')
                        .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')
                        .replace(/(?:^|:|,)(?:\s*\[)+/g, ''))) {
                j = eval('(' + text + ')');
                return typeof reviver === 'function'
                    ? walk({ '': j }, '')
                    : j;
            }
            throw new SyntaxError('JSON.parse');
        };
    }
} ());
