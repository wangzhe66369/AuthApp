﻿/*
*   Create Author: PCITLXJ
*   Create Date:   2013-03-28
* jQuery Progress Bar
使用方法:
$(".someclass").progressBar();
$("#progressbar").progressBar();
$("#progressbar").progressBar(45);							// 当前进度
$("#progressbar").progressBar({showText: false });			
$("#progressbar").progressBar(45, {showText: false });		
*/
(function($) {
	$.extend({
		progressBar: new function() {
			this.defaults = {
				steps			: 20,			// 到达目标所采取的步长，设定的值越高，进度越慢
				stepDuration	: 20,			// setInterval的时间参数，单位ms
				max				: 100,			// 最大值
				showText		: true,			// 在进度条旁边用百分数或者分数显示进度与否，默认为true
				textFormat		: 'percentage',	// ShowText的显示形式，“percentage”表示百分数，“fraction”表示分数
				width			: 120,			// 进度条图片的宽度，一般不用改的，除非你不用插件自带的图片，那时您需要计算自己的图的宽度
				height			: 12,			// 进度条图片的高度，一般不用改的，除非你不用插件自带的图片，那时您需要计算自己的图的高度
				callback		: null,			// 回调函数，当进度达到目标值的时候触发的函数，默认没有
				boxImage: 'images/progressbar.gif', // boxImage : 包着进度条的图片
				barImage: 
                {
                    0:'images/progressbg_red.gif',
                    30:'images/progressbg_orange.gif',
                    50:'images/progressbg_black.gif',
                    70:'images/progressbg_green.gif',
                    90:'images/progressbg_yellow.gif'
                },//进度条的图片，默认有5个，这个形式的参数主要是为了多彩进度条而设置的// 内部参数无须传入
				running_value	: 0,
				value			: 0,
				image			: null,
                opacity         : 35,                   //遮罩透明度
                backgroundColor:"#FFF",                 //遮罩颜色
                isMask          : false,                //是否遮罩
                zIndex          : 1002,
                containerObj    :$(this),
                left            : 0,
                top             : 0
			};
            this.remove = function ()
            {
                $(this).find("div[isProgressbarPanel='true']").remove();
//                this.bar = null;
                $.progressBar.defaults.containerObj.bar = null;
                //this.bar = null;
            };
			/* 公共方法 */
			this.construct = function(arg1, arg2) {
				var argvalue	= null;
				var argconfig	= null;

				if (arg1 != null) {
					if (!isNaN(arg1)) {
						argvalue = arg1;
						if (arg2 != null) {
							argconfig = arg2;
						}
					} else {
						argconfig = arg1;
					}
				}

				return this.each(function() {
					var pb		= this;
					var config	= this.config;

					if (argvalue != null && this.bar != null && this.config != null && $(this).find("div[isProgressbarPanel='true']").length > 0) 
                    {
						this.config.value 		= parseInt(argvalue)
						if (argconfig != null)
							pb.config			= $.extend(this.config, argconfig);
						config	= pb.config;
					} 
                    else 
                    {
						var $this				= $(this);
						var config				= $.extend({}, $.progressBar.defaults, argconfig);
						config.id				= $this.attr('id') ? $this.attr('id') : Math.ceil(Math.random() * 100000);	// random id, if none provided
                        
                        var clientHeight=(window.screen.availHeight<$this.height())?window.screen.availHeight:$this.height();
                        var clientwidth=(window.screen.availWidth<$this.width())?window.screen.availWidth:$this.width();
                        config.top = (clientHeight - config.height) / 2.0;
                        config.left = (clientwidth - config.width) / 2.0;
						if (argvalue == null)
							argvalue	= $this.html().replace("%","")	// 取得百分比

						config.value			= parseInt(argvalue);
						config.running_value	= 0;
						config.image			= getBarImage(config);

						var numeric = ['steps', 'stepDuration', 'max', 'width', 'height', 'running_value', 'value'];
						for (var i=0; i<numeric.length; i++)
							config[numeric[i]] = parseInt(config[numeric[i]]);

						if (config.value > config.max)
							config.value = config.max;
						//$this.html("");
//                        $.progressBar.defaults.containerObj = $this;
                        $this.find("div[isProgressbarPanel='true']").remove();
						var bar					= document.createElement('img');
						var text				= document.createElement('span');
						var $bar				= $(bar);
						var $text				= $(text);
						pb.bar					= $bar;
                        if($this.parent() != undefined)
                            $this.parent().css("position","relative");
						$bar.attr('id', config.id + "_pbImage");
						$text.attr('id', config.id + "_pbText");
						$text.html(getText(config));
						$bar.attr('title', getText(config));
						$bar.attr('alt', getText(config));
						$bar.attr('src', config.boxImage);
						$bar.attr('width', config.width);
						$bar.css("width", config.width + "px");
						$bar.css("height", config.height + "px");
						$bar.css("background-image", "url(" + config.image + ")");
						$bar.css("background-position", ((config.width * -1)) + 'px 50%');
						$bar.css("padding", "0");
						$bar.css("margin", "0");
                        var initHtml = format(config);
                        $this.append(initHtml);
//						$this.append($bar);
//						$this.append($text);
                        $this.find("div[isProgressContainer='true']").append($bar);
                        $this.find("div[isProgressContainer='true']").append($text);
                        $.progressBar.defaults.containerObj = pb;
					}

					function getPercentage(config) {
						return Math.round(config.running_value * 100 / config.max);
					}

					function getBarImage(config) {
						var image = config.barImage;
						if (typeof(config.barImage) == 'object') {
							for (var i in config.barImage) {
								if (getPercentage(config) >= parseInt(i)) {
									image = config.barImage[i];
								} else { break; }
							}
						}
						return image;
					}

					function getText(config) {
						if (config.showText) {
							if (config.textFormat == 'percentage') {
								return " " + getPercentage(config) + "%";
							} else if (config.textFormat == 'fraction') {
								return " " + config.running_value + '/' + config.max;
							}
						}
					}
                    //获取格式化数据
                    function format (params) {
                        var html = "";
                        if(params.isMask)
                        {
                            html = "<div isProgressbarPanel=\"true\" style=\"z-index:" + params.zIndex + ";\">" +
								            "<iframe frameborder=\"0\" src=\"about:blank\" style=\"top:0; left:0; width: 100%; height:100%;position:absolute;filter: alpha(opacity=1);opacity: 0.01;moz-opacity:0.01;\"></iframe>" +
								            "<DIV style=\"top:0; left: 0px; width: 100%; height:100%; position:absolute;filter: alpha(opacity=" + params.opacity + ");opacity: " + (params.opacity / 100) + ";moz-opacity:" + (params.opacity / 100) + ";background-color: " + params.backgroundColor + ";margin:0px;padding:0px;\"></DIV>" +
								            "<DIV isProgressContainer=\"true\" style=\"top:"+params.top+"px; left: "+params.left+"px; width:" + (params.width+50) + "px; height:" + (params.height+2) + "px; position:absolute;margin:0px;padding:0px;\"></DIV>" +
								            "</div>";
                        }
                        else 
                        {
                            html = "<DIV  isProgressbarPanel=\"true\" isProgressContainer=\"true\" style=\"z-index:" + params.zIndex + ";top:"+params.top+"px; left: "+params.left+"px; width:" + (params.width+50) + "px; height:" + (params.height+2) + "px; position:absolute;margin:0px;padding:0px;\"></DIV>";
                        }
                        return html;
                    }
					config.increment = Math.round((config.value - config.running_value)/config.steps);
					if (config.increment < 0)
						config.increment *= -1;
					if (config.increment < 1)
						config.increment = 1;

					var t = setInterval(function() {
						var pixels	= config.width / 100;			// Define how many pixels go into 1%

						if (config.running_value > config.value) {
							if (config.running_value - config.increment  < config.value) {
								config.running_value = config.value;
							} else {
								config.running_value -= config.increment;
							}
						}
						else if (config.running_value < config.value) {
							if (config.running_value + config.increment  > config.value) {
								config.running_value = config.value;
							} else {
								config.running_value += config.increment;
							}
						}

						if (config.running_value == config.value)
							clearInterval(t);

						var $bar	= $("#" + config.id + "_pbImage");
						var $text	= $("#" + config.id + "_pbText");
						var image	= getBarImage(config);
						if (image != config.image) {
							$bar.css("background-image", "url(" + image + ")");
							config.image = image;
						}
						$bar.css("background-position", (((config.width * -1)) + (getPercentage(config) * pixels)) + 'px 50%');
						$bar.attr('title', getText(config));
						$text.html(getText(config));

						if (config.callback != null && typeof(config.callback) == 'function')
							config.callback(config);

						pb.config = config;
					}, config.stepDuration);
				});
			};
		}
	});
	$.fn.extend({
        progressBar: $.progressBar.construct,
        progressBarRemove: $.progressBar.remove
	});

})(jQuery);