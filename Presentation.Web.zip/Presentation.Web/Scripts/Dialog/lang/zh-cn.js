﻿var $mvc_dialog_tipTypes=["提示","询问","警告","确认","错误"];
var $mvc_dialog_buttonText={okText:"确定",cancelText:"取消"};