﻿var $mvc_dialog_tipTypes=["提示","詢問","警告","確認","錯誤"];
var $mvc_dialog_buttonText={okText:"確定",cancelText:"取消"};