﻿/*!
* jQuery cgn.UI OpTips 1.0
* http://jqueryui.com

* Depends:
*	jquery.ui.core.js
*	jquery.ui.widget.js
*	jquery.ui.draggable.js
*	jquery.ui.mouse.js
*	jquery.ui.position.js
*/
(function ($, undefined) {

    $.widget("cgnui.optips", {
        version: "1.0.0",
        language: "zh-cn",
        fileName: "jquery.cgn.ui.optips.js",
        options: {
            appendTo: "body",
            autoOpen: true,
            closeOnEscape: true,
            closeText: "close",
            dialogClass: "",
            draggable: true,
            hide: null,
            height: "auto",
            maxHeight: null,
            maxWidth: null,
            minHeight: 50,
            minWidth: 100,
            modal: false, //遮罩非遮罩
            topShow: false, //是否最外层显示
            tipType: null, //提示的类型："information", "question", "warning", "confirmation", "error", "custom"
            tipClassName: null, //样式名称
            time: 0,     //倒计时，0无效
            position: {
                my: "center",
                at: "center",
                of: window,
                collision: "fit",
                // Ensure the titlebar is always visible
                using: function (pos) {
                    var topOffset = $(this).css(pos).offset().top;
                    if (topOffset < 0) {
                        $(this).css("top", pos.top - topOffset);
                    }
                }
            },
            show: null,
            width: 250,

            // callbacks
            beforeClose: null,
            close: null,  //关闭层回调
            drag: null,
            dragStart: null,
            dragStop: null,
            focus: null,
            open: null
        },

        _create: function () {
            this.originalCss = {
                display: this.element[0].style.display,
                width: this.element[0].style.width,
                minHeight: this.element[0].style.minHeight,
                maxHeight: this.element[0].style.maxHeight,
                height: this.element[0].style.height
            };
            this.originalPosition = {
                parent: this.element.parent(),
                index: this.element.parent().children().index(this.element)
            };

            this._createWrapper();             //创建包封容器

            this.closebutton = $("<input />")  //关闭按钮
			.attr("type", "button")
			.attr("class", "ui-btn ui-btn-closelayer")
			.attr("value", "×");

            this._on(this.closebutton, {
                click: function (event) {
                    event.preventDefault();
                    this.close(event);
                    return;
                }
            });

            var tipContent = this._createTipContent(); //提示内容
            this.element.empty()               //清空原有元素
			.append(this.closebutton)          //添加关闭按钮
			.append(tipContent);               //添加提示内容

            this.element
				.show()
				.removeAttr("title")
				.addClass("ui-optips-content ")
				.appendTo(this.uiDialog);

            if (this.options.draggable && $.fn.draggable) {
                this._makeDraggable();
            }
            this._isOpen = false;
        },

        _init: function () {
            if (this.options.autoOpen) {
                this.open();
            }
        },

        _appendTo: function () {
            var element = this.options.appendTo;
            if (element && (element.jquery || element.nodeType)) {
                return $(element);
            }
            return this.document.find(element || "body").eq(0);
        },

        _destroy: function () {
            var next,
			originalPosition = this.originalPosition;

            this._destroyOverlay();
            this.closebutton.remove();
            this.element
			.removeUniqueId()
			.removeClass("ui-optips-content ")
			.css(this.originalCss)
            // Without detaching first, the following becomes really slow
			.detach();

            this.uiDialog.stop(true, true).remove();

            next = originalPosition.parent.children().eq(originalPosition.index);
            // Don't try to place the dialog next to itself (#8613)
            if (next.length && next[0] !== this.element[0]) {
                next.before(this.element);
            } else {
                originalPosition.parent.append(this.element);
            }
        },

        widget: function () {
            return this.uiDialog;
        },

        disable: $.noop,
        enable: $.noop,

        close: function (event) {
            var that = this;

            if (!this._isOpen || this._trigger("beforeClose", event) === false) {
                return;
            }

            this._isOpen = false;
            this._destroyOverlay();

            if (!this.opener.filter(":focusable").focus().length) {
                // Hiding a focused element doesn't trigger blur in WebKit
                // so in case we have nothing to focus on, explicitly blur the active element
                // https://bugs.webkit.org/show_bug.cgi?id=47182
                $(this.document[0].activeElement).blur();
            }

            this._hide(this.uiDialog, this.options.hide, function () {
                that._trigger("close", event);
            });

            //关闭后，移除元素
            this.element.parent().remove();

            //清除timeout
            that.element.trigger("clearTimeOut", that.setT);
        },

        isOpen: function () {
            return this._isOpen;
        },

        moveToTop: function () {
            this._moveToTop();
        },

        _moveToTop: function (event, silent) {
            var moved = !!this.uiDialog.nextAll(":visible").insertBefore(this.uiDialog).length;
            if (moved && !silent) {
                this._trigger("focus", event);
            }
            return moved;
        },

        open: function () {
            if (this._isOpen) {
                if (this._moveToTop()) {
                    this._focusTabbable();
                }
                return;
            }

            this.opener = $(this.document[0].activeElement);

            this._size();
            this._position();
            this._createOverlay();
            this._moveToTop(null, true);
            this._show(this.uiDialog, this.options.show);

            this._focusTabbable();

            this._isOpen = true;
            this._trigger("open");
            this._trigger("focus");
        },

        _focusTabbable: function () {
            // Set focus to the first match:
            // 1. First element inside the dialog matching [autofocus]
            // 2. Tabbable element inside the content element
            // 3. Tabbable element inside the buttonpane
            // 4. The close button
            // 5. The dialog itself
            var hasFocus = this.element.find("[autofocus]");
            if (!hasFocus.length) {
                hasFocus = this.element.find(":tabbable");
            }
            if (!hasFocus.length) {
                hasFocus = this.uiDialog;
            }
            hasFocus.eq(0).focus();
        },

        _keepFocus: function (event) {
            function checkFocus() {
                var activeElement = this.document[0].activeElement,
				isActive = this.uiDialog[0] === activeElement ||
					$.contains(this.uiDialog[0], activeElement);
                if (!isActive) {
                    this._focusTabbable();
                }
            }
            event.preventDefault();
            checkFocus.call(this);
            // support: IE
            // IE <= 8 doesn't prevent moving focus even with event.preventDefault()
            // so we check again later
            this._delay(checkFocus);
        },
        //创建包封对象
        _createWrapper: function () {
            this.uiDialog = $("<div>")
			.addClass("ui-optips ui-widget ui-corner-all ui-front " +
				this.options.dialogClass)
			.hide()
			.attr({
			    // Setting tabIndex makes the div focusable
			    tabIndex: -1,
			    role: "optips"
			})
			.appendTo(this._appendTo());

            this._on(this.uiDialog, {
                keydown: function (event) {
                    if (this.options.closeOnEscape && !event.isDefaultPrevented() && event.keyCode &&
						event.keyCode === $.ui.keyCode.ESCAPE) {
                        event.preventDefault();
                        this.close(event);
                        return;
                    }

                    // prevent tabbing out of dialogs
                    if (event.keyCode !== $.ui.keyCode.TAB) {
                        return;
                    }
                    var tabbables = this.uiDialog.find(":tabbable"),
					first = tabbables.filter(":first"),
					last = tabbables.filter(":last");

                    if ((event.target === last[0] || event.target === this.uiDialog[0]) && !event.shiftKey) {
                        first.focus(1);
                        event.preventDefault();
                    } else if ((event.target === first[0] || event.target === this.uiDialog[0]) && event.shiftKey) {
                        last.focus(1);
                        event.preventDefault();
                    }
                },
                mousedown: function (event) {
                    if (this._moveToTop(event)) {
                        this._focusTabbable();
                    }
                }
            });

            // We assume that any existing aria-describedby attribute means
            // that the dialog content is marked up properly
            // otherwise we brute force the content as the description
            if (!this.element.find("[aria-describedby]").length) {
                this.uiDialog.attr({
                    "aria-describedby": this.element.uniqueId().attr("id")
                });
            }
        },
        //设置可拖拽
        _makeDraggable: function () {
            var that = this,
				options = this.options;

            function filteredUi(ui) {
                return {
                    position: ui.position,
                    offset: ui.offset
                };
            }

            this.uiDialog.draggable({
                cancel: ".ui-btn-closelayer",
                handle: ".ui-optips-content",
                containment: "document",
                start: function (event, ui) {

                    that._trigger("dragStart", event, filteredUi(ui));
                },
                drag: function (event, ui) {
                    that._trigger("drag", event, filteredUi(ui));
                },
                stop: function (event, ui) {
                    options.position = [
					ui.position.left - that.document.scrollLeft(),
					ui.position.top - that.document.scrollTop()
				];
                    that._trigger("dragStop", event, filteredUi(ui));
                }
            });
        },
        //位置
        _position: function () {
            // Need to show the dialog to get the actual offset in the position plugin
            var isVisible = this.uiDialog.is(":visible");
            if (!isVisible) {
                this.uiDialog.show();
            }
            this.uiDialog.position(this.options.position);
            if (!isVisible) {
                this.uiDialog.hide();
            }
        },
        //设置属性
        _setOptions: function (options) {
            var that = this; ;

            $.each(options, function (key, value) {
                that._setOption(key, value);
            });
        },
        //设置属性
        _setOption: function (key, value) {
            /*jshint maxcomplexity:15*/
            var isDraggable, uiDialog = this.uiDialog;

            if (key === "dialogClass") {
                uiDialog
				.removeClass(this.options.dialogClass)
				.addClass(value);
            }

            if (key === "disabled") {
                return;
            }

            this._super(key, value);

            if (key === "appendTo") {
                this.uiDialog.appendTo(this._appendTo());
            }

            if (key === "buttons") {
                this._createButtons();
            }

            if (key === "closeText") {
                this.uiDialogTitlebarClose.button({
                    // Ensure that we always pass a string
                    label: "" + value
                });
            }

            if (key === "draggable") {
                isDraggable = uiDialog.is(":data(ui-draggable)");
                if (isDraggable && !value) {
                    uiDialog.draggable("destroy");
                }

                if (!isDraggable && value) {
                    this._makeDraggable();
                }
            }

            if (key === "position") {
                this._position();
            }
        },

        _size: function () {
            // If the user has resized the dialog, the .ui-dialog and .ui-dialog-content
            // divs will both have width and height set, so we need to reset them
            var nonContentHeight, minContentHeight, maxContentHeight,
			options = this.options;

            // Reset content sizing
            this.element.show().css({
                width: "auto",
                minHeight: 0,
                maxHeight: "none",
                height: 0
            });

            if (options.minWidth > options.width) {
                options.width = options.minWidth;
            }

            // reset wrapper sizing
            // determine the height of all the non-content elements
            nonContentHeight = this.uiDialog.css({
                height: "auto",
                width: options.width
            })
			.outerHeight();
            minContentHeight = Math.max(0, options.minHeight - nonContentHeight);
            maxContentHeight = typeof options.maxHeight === "number" ?
			Math.max(0, options.maxHeight - nonContentHeight) :
			"none";

            if (options.height === "auto") {
                this.element.css({
                    minHeight: minContentHeight,
                    maxHeight: maxContentHeight,
                    height: "auto"
                });
            } else {
                this.element.height(Math.max(0, options.height - nonContentHeight));
            }
        },
        //遮罩
        _createOverlay: function () {
            if (!this.options.modal) {
                return;
            }

            if (!$.cgnui.optips.overlayInstances) {
                // Prevent use of anchors and inputs.
                // We use a delay in case the overlay is created from an
                // event that we're going to be cancelling. (#2804)
                this._delay(function () {
                    // Handle .dialog().dialog("close") (#4065)
                    if ($.cgnui.optips.overlayInstances) {
                        this._on(this.document, {
                            focusin: function (event) {
                                if (!$(event.target).closest(".ui-dialog").length) {
                                    event.preventDefault();
                                    //暂时先不启用
                                    //$(".ui-dialog:visible:last .ui-dialog-content")
                                    //.data("ui-dialog")._focusTabbable();
                                }
                            }
                        });
                    }
                });
            }

            this.overlay = $("<div>")
			.addClass("ui-widget-overlay ui-front")
			.appendTo(this.document[0].body);
            this._on(this.overlay, {
                mousedown: "_keepFocus"
            });
            $.cgnui.optips.overlayInstances++;
        },

        _destroyOverlay: function () {
            if (!this.options.modal) {
                return;
            }

            $.cgnui.optips.overlayInstances--;
            if (!$.cgnui.optips.overlayInstances) {
                this._off(this.document, "focusin");
            }
            this.overlay.remove();
        },

        _createTipContent: function () {

            //构建对话框内容
            var container = $("<div></div>").addClass("ui-optips-container");

            /*添加特定提示*/
            var tipCssList = ["info_tip", "ques_tip", "warn_tip", "conf_tip", "error_tip", this.options.tipClassName];
            var tipTypes = ["information", "question", "warning", "confirmation", "error", "custom"];
            var tipTexts = ["提示", "询问", "警告", "确认", "错误"];

            if (this.options.tipType != null && this.options.tipType != "custom") {  //自定义
                //获取语言文件中变量值
                for (var i = 0; i < tipTypes.length; i++) {
                    if (tipTypes[i].indexOf(this.options.tipType.toLowerCase()) == 0) {
                        this.options.tipType = tipTypes[i];
                        this.options.tipClassName = tipCssList[i];
                        break;
                    }
                }
                container.append(this._renderIcon(this.options.tipClassName));
                container.append(this._renderText());
                this._autoTime(); //默认加载倒计时提示
            }
            else {
                var content = $(this.options.content).html();
                container.append(this._renderCustom(content));
            }
            return $(container);
        },
        //自定义
        _renderCustom: function (html) {
            return html;
        },
        //图标
        _renderIcon: function (className) {
            var tipIconContainer = $("<div></div>").addClass("ui-optips-tip-Container"); //容器
            $("<div></div>").addClass("ui-optips-tip-image").addClass(className).appendTo(tipIconContainer)
            return tipIconContainer;
        },
        //文字
        _renderText: function () {
            var tipTextContainer = $("<div></div>").addClass("ui-optips-content-container").css("width", this.options.width - 80); //容器
            $("<div></div>").addClass("ui-optips-content").append($(this.element).html()).appendTo(tipTextContainer);
            return tipTextContainer;
        },
        //自动时间
        _autoTime: function () {
            var self = this;
            if (this.options.time <= 0) {
                return;
            }

            self.element.bind("clearTimeOut", function (event, parames) {
                clearTimeout(parames);
            });

            //倒计时类
            var autoTime = function (second, refresh, callback) {
                var that = this;
                this.sec = second;
                this.templateTxt = "<b style='color:Red;'> {0} </b>";
                this.refresh = refresh;
                this.callback = callback;
                this.begin = function () {
                    if (that.sec < 1) {
                        clearTimeout(self.setT);
                        that.callback(self); //回调
                        return;
                    }
                    if (that.refresh != null) {
                        that.refresh(self, that.templateTxt.replace("{0}", that.sec));
                    }
                    that.sec--;
                    self.setT = setTimeout(that.begin, 1000);
                }
            }
            //开启自动倒计时
            var auto = new autoTime(this.options.time, this._updateTime, this._closeAndCallback);
            auto.begin();
        },
        //更新倒计时数字
        _updateTime: function (self, html) {
            var textContainer = $(self.element).find(".ui-optips-content-container");
            var b = textContainer.find("b");
            if (b.length > 0) {
                b.html($(html).html());
            }
            else {
                textContainer.append(html);
            }
        },
        //关闭回调
        _closeAndCallback: function (self) {
            self.close();
        }
    });

    $.cgnui.optips.overlayInstances = 0;

    // DEPRECATED
    if ($.uiBackCompat !== false) {
        // position option with array notation
        // just override with old implementation
        $.widget("cgnui.optips", $.cgnui.optips, {
            _position: function () {
                var position = this.options.position,
				myAt = [],
				offset = [0, 0],
				isVisible;

                if (position) {
                    if (typeof position === "string" || (typeof position === "object" && "0" in position)) {
                        myAt = position.split ? position.split(" ") : [position[0], position[1]];
                        if (myAt.length === 1) {
                            myAt[1] = myAt[0];
                        }

                        $.each(["left", "top"], function (i, offsetPosition) {
                            if (+myAt[i] === myAt[i]) {
                                offset[i] = myAt[i];
                                myAt[i] = offsetPosition;
                            }
                        });

                        position = {
                            my: myAt[0] + (offset[0] < 0 ? offset[0] : "+" + offset[0]) + " " +
							myAt[1] + (offset[1] < 0 ? offset[1] : "+" + offset[1]),
                            at: myAt.join(" ")
                        };
                    }

                    position = $.extend({}, $.cgnui.optips.prototype.options.position, position);
                } else {
                    position = $.cgnui.optips.prototype.options.position;
                }

                // need to show the dialog to get the actual offset in the position plugin
                isVisible = this.uiDialog.is(":visible");
                if (!isVisible) {
                    this.uiDialog.show();
                }
                this.uiDialog.position(position);
                if (!isVisible) {
                    this.uiDialog.hide();
                }
            }
        });
    }
} (jQuery));


$(function () {
    $.extend({
        optips: {
            /*询问*/
            confirm: function (parame) {
                parame.tipType = "question";
                this.show(parame);
            },
            /*end of 询问*/

            /*警告*/
            warning: function (parame) {
                parame.tipType = "warning";
                this.show(parame);
            },
            /*end of 警告*/

            /*提示*/
            alert: function (parame) {
                parame.tipType = "information";
                this.show(parame);
            },
            /*end of 提示*/

            /*确认*/
            succeed: function (parame) {
                parame.tipType = "confirmation";
                this.show(parame);
            },
            /*end of 确认*/

            /*错误*/
            error: function (parame) {
                parame.tipType = "error";
                this.show(parame);
            },
            /*end of 错误*/

            /* 显示*/
            show: function (parame) {
                var content = parame.content;
                var options = $.extend(parame, options || {});
                if (options.topShow) {
                    if (typeof (options.content) == "string") {
                        content = $("<div><div>" + options.content + "</div></div>").html();
                    } else {
                        content = $(options.content).html();
                    }
                    this.getTop().$(content).optips(options);
                } else {
                    if (typeof (options.content) == "string") {
                        content = $("<div>" + options.content + "</div>");
                    }
                    $(content).optips(options);
                }
            },
            /*end of 显示*/

            /*关闭*/
            close: function (that) {
                try {
                    $(that).optips("close");
                } catch (e) {
                    this.getTop().$(that).optips("close");
                }

            },
            /*end of 关闭*/

            /*容器对象*/
            getTop: function () {
                var _top = window;
                if (this.testTop()) {
                    _top = window.top;
                }
                return _top;
            },
            /*end of 容器对象*/

            /*检查容器*/
            testTop: function () {
                return window.top != window.self;
            }
            /*end of 检查容器*/
        }
    });
});