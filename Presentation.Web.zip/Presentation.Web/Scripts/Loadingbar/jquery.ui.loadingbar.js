﻿/*
loadingbar 
Create Author:  PCITLXJ
Create Date:    2013-03-28
*/
(function ($) {
    var methods = {
        init: function (options) {
            return this.each(function () {
                var $this = $(this);
                var settings = $this.data("Frame_work_loadingbar");
                if (typeof (settings) == "undefined") {
                    var defaults = {
                        showText: true, 							    // 是否显示文字描述 default : true
                        width: 200,
                        height: 32, 								// 默认显示宽度
                        boxImage: 'images/ui-loading.gif', 			    // Loading图片配置
                        desc: '正在加载，请稍等...',                     //默认显示的描述信息
                        /*
                        参考UI模版
                        提醒:ui-state-visite,#9fd868
                        消息：ui-state-default，#F1F8FC
                        警告:ui-state-highlight,#FFFCF0
                        错误:ui-state-error,#FFF7F7
                        */
                        bgColor: '#F1F8FC',                             //默认背景
                        uiState: 'ui-state-default',
                        zIndex: 1001,
                        top: 0,
                        left: 0,
                        opacity: 35,                                     //遮罩透明度
                        backgroundColor: "#FFF",                         //遮罩颜色
                        isMask: false,                                   //是否遮罩
                        containerObj: null,                           //当前容器对象
                        containerObjId: ""                               //容器ID
                    }
                    settings = $.extend({}, defaults, options);

                }
                else {
                    settings = $.extend({}, settings, options);
                }
                if (settings.containerObjId == "" && ($this.attr("loadBarContainerID") == undefined || $this.attr("loadBarContainerID") == "")) {
                    if ($this.parent() != undefined)
                        $this.parent().css("position", "relative");

                    //如果容器高度大于当前页面高度则显示在页面中间
                    var clientHeight = (window.screen.availHeight < $this.height()) ? window.screen.availHeight : $this.height();
                    var clientwidth = (window.screen.availWidth < $this.width()) ? window.screen.availWidth : $this.width();
                    settings.top = (clientHeight - settings.height - 2) / 2.0;
                    settings.left = (clientwidth - settings.width - 10) / 2.0;
                    var containerName = $this.attr('id') ? $this.attr('id') : Math.ceil(Math.random() * 100000);
                    containerName += "_framework_loadingBar";
                    $this.attr("loadBarContainerID", containerName); // random id, if none provided
                    settings.containerObjId = containerName;
                    var html = methods.format(settings);
                    $this.append(html);
                    $this.data("Frame_work_loadingbar", settings);
                }
                else {
                    methods.show();
                }
            });
        },
        show: function () {
            return $(this).each(function () {
                var $this = $(this);
                var settings = $this.data('Frame_work_loadingbar');
                if (typeof (settings) != "undefined" && settings != null) {
                    $this.find("div[id='" + settings.containerObjId + "']").show();
                }
            });
        },
        hide: function () {
            return $(this).each(function () {
                var $this = $(this);
                var settings = $this.data('Frame_work_loadingbar');
                if (typeof (settings) != "undefined" && settings != null) {
                    $this.find("div[id='" + settings.containerObjId + "']").hide();
                }
            });
        },
        remove: function () {
            return $(this).each(function () {
                var $this = $(this);
                var settings = $this.data('Frame_work_loadingbar');
                if (typeof (settings) != "undefined" && settings != null) {
                    $this.find("div[id='" + settings.containerObjId + "']").remove();
                    settings.containerObjId = "";
                    $this.removeData('Frame_work_ladingbar');
                    $this.attr("loadBarContainerID", "");
                    $this.data("Frame_work_loadingbar", settings);
                }
            });

        },
        // 格式化参数
        format: function (opts) {
            var context = "";
            if (opts.showText) {
                context = "<div class=\"ui-widget\" style=\"margin-top: 5px; width:" + opts.width + "px; \"><div class=\"" + opts.uiState + " ui-corner-all\" style=\"padding: 2px;height:" + opts.height + "px;background: " + opts.bgColor + " none; vertical-align:middle;\"><span class=\"ui-icon\" style=\"float:left;background: url(" + opts.boxImage + "); background-repeat:no-repeat; height:31px; width:35px\"></span><strong style=\" line-height:32px;\">" + opts.desc + "</strong></div></div>";
            }
            else {
                context = "<span class=\"ui-icon\" style=\"float:left;background: url(" + opts.boxImage + "); background-repeat:no-repeat; height:31px; width:31px\"></span>";
            }
            var html = "";
            if (opts.isMask) {
                html = "<div isMainPanel=\"true\" id=\"" + opts.containerObjId + "\" style=\"z-index:" + opts.zIndex + ";\">" +
        								"<iframe frameborder=\"0\" src=\"about:blank\" style=\"top:0; left:0; width: 100%; height:100%;position:absolute;filter: alpha(opacity=1);opacity: 0.01;moz-opacity:0.01;\"></iframe>" +
        								"<DIV style=\"top:0; left: 0px; width: 100%; height:100%; position:absolute;filter: alpha(opacity=" + opts.opacity + ");opacity: " + (opts.opacity / 100) + ";moz-opacity:" + (opts.opacity / 100) + ";background-color: " + opts.backgroundColor + ";margin:0px;padding:0px;\"></DIV>" +
        								"<DIV style=\"top:" + opts.top + "px; left: " + opts.left + "px; width:" + (opts.width + 5) + "px; height:" + (opts.height + 2) + "px; position:absolute;margin:0px;padding:0px;\">" + context + "</DIV>" +
        								"</div>";
            }
            else {
                html = "<DIV id=\"" + opts.containerObjId + "\" isMainPanel=\"true\" style=\"z-index:" + opts.zIndex + ";top:" + opts.top + "px; left: " + opts.left + "px; width:" + (opts.width + 5) + "px; height:" + (opts.height + 2) + "px; position:absolute;margin:0px;padding:0px;\">" + context + "</DIV>";
            }
            return html;
        }
    };
    $.fn.loadingbar = function (method) {
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        }
        else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        }
        else {
            $.error('Method ' + method + ' does not exist on jQuery.loadingbar');
        }
    };
})(jQuery);