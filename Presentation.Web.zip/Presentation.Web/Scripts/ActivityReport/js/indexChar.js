﻿//表盘1/表盘2总数
questionPropertySum;
//表盘1指标数
questionPropertyStartSum;


//表盘2指标
questionApplyEndCount;
questionPropertyEndSum;
//表盘2整改关闭率
scaleValue;



// 基于准备好的dom，初始化echarts实例

//违规预警年趋势图
var myChart = echarts.init(document.getElementById('chartYjnqs'));
//指标盘1
var myGauge = echarts.init(document.getElementById('gauge1'));
//指标盘2
var myGauge2 = echarts.init(document.getElementById('gauge2'));
//违规预警及疑似问题分类统计
var myChart2 = echarts.init(document.getElementById('chartFltj'));

//以下是--问题年趋势图的处理
//获取后台的12个月的数据

var yearQsArray = array.split('-');//存储12个月份数据的数组
var nowDate = new Date();
var nowYear = nowDate.getFullYear();
var yearQsArrayTmp = new Array();
//将小于当年的数据放在前面，等于当前的放置在后面
var oldYear=0;//标记从哪一位开始是小于当前年的
for(var i=0;i<yearQsArray.length;i++){
   if(nowYear>yearQsArray[i].substr(0,4)){
        oldYear = i;
        break;
   }
}
var tmpI = 0;
for(var i=oldYear;i<yearQsArray.length;i++)
{
    yearQsArrayTmp[tmpI] = yearQsArray[i];
    tmpI++;
}
for(var i=0;i<oldYear;i++)
{
    yearQsArrayTmp[tmpI] = yearQsArray[i];
    tmpI++;
}
//console.log(yearQsArrayTmp);
//用于测试，正式上线时删除
//yearQsArrayTmp = ["201507,5,3", "201508,35,2", "201509,20,10", "201510,28,15", "201511,0,0", "201512,33,23", "201601,40,10", "201602,49,20", "201603,40,10", "201604,21,11", "201605,15,3", "201606,47,1"];
//用于测试，正式上线时删除 结束


option = {
    title: {
        text: '函询问题年趋势图',
        subtext: '',
		textStyle:{
			color: '#4387df',
			fontWeight:'normal',
		},
    },
    tooltip: {
        trigger: 'axis'
    },
    legend: {
        //data:['关闭问题数量', '函询问题数量']
        data:[
            {
                name:'关闭问题数量',
                textStyle:{
                    color:'green'
                }
            },
             {
                name:'函询问题数量',
                icon:iconImage,
                textStyle:{
                    color:'#009FCC'
                }
            }
        ]
    },
    toolbox: {
        show: true,
        feature: {
            dataView: {show: false,readOnly: false},
            restore: {},
            saveAsImage: {}
        }
    },
    dataZoom: {
        show: true,
        start: 0,
        end: 100
    },
    xAxis: [
        {
            type: 'category',
            boundaryGap: true,
			splitLine:{
				show:false,
			},
                        axisLabel: { interval: 0, rotate: 45, margin: 2, textStyle: {color:"#222"} },
            data:[]
        },
        {
            type: 'category',
            boundaryGap: true,
			splitLine:{
				show:true,
			},
            data:[]
        }
    ],
    yAxis: [
        {
            type: 'value',
            scale: true,
			splitLine:{
				show:true,
			},
            name: '关闭问题数量',
            max: 20,
            min: 0,
            boundaryGap: [0.2, 0.2]
        },
        {
            type: 'value',
            scale: true,
			splitLine:{
				show:false,
			},
            name: '函询问题数量',
            max: 20,
            min: 0,
            boundaryGap: [0.2, 0.2]
        }
    ],
    series: [
        {
            name:'问题数量',
            type:'bar',
            xAxisIndex: 1,
            yAxisIndex: 1,
            barMaxWidth:'10px',
            barGap:'10%',
            data:[]
        },
        {
            name:'关闭问题数量',
            type:'line',
            data:[]
        }
    ]
};
for(var i=0;i<yearQsArrayTmp.length;i++)
{
    option.xAxis[0].data.push(yearQsArrayTmp[i].split(',')[0].substr(2));
    option.xAxis[1].data.push(yearQsArrayTmp[i].split(',')[2]);
    var dataObj1 = {value:0,itemStyle:{normal:{color:'#009FCC'}}};
    dataObj1.value=yearQsArrayTmp[i].split(',')[1];
    var dataObj2 = {value:0,itemStyle:{normal:{color:'yellow'}}};
    dataObj2.value=yearQsArrayTmp[i].split(',')[2];
    option.series[0].data.push(dataObj1);
    option.series[1].data.push(dataObj2);
}
//以上是--问题年趋势图的处理完毕


//指标盘1
optionGauge1 = {
    tooltip : {
        formatter: "{a} <br/>{b} : {c}"
    },
    toolbox: {
        show : true,
        feature : {
            mark : {show: true},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
    series : [
        {
            name:'当月函询问题数量',
            type:'gauge',
            detail : {formatter:'{value}'},
            data:[{value: questionPropertyStartSum, name: questionPropertyStartSum}],
			axisLine:{
				show: true,
				lineStyle: {
					color: [
						[1/3,'#33FF33'],
						[2/3, '#EEEE00'],
						[1, '#C63300']
					]
				},
			},
			max:15,
			//splitNumber:(questionPropertySum>20)?(questionPropertySum/10):questionPropertySum,
            splitNumber:15,
			axisTick: {show:false},
         
          
        }
    ]
};
myGauge.setOption(optionGauge1, true);

 
//指标盘2
optionGauge2 = {
    tooltip : {
        formatter: "{a} <br/>{b} : {c}%"
    },
    toolbox: {
        show : true,
        feature : {
            mark : {show: true},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
    series : [
        {
            name:'关闭率',
            type:'gauge',
            detail : {formatter:'{value}%'},
            data:[{value: scaleValue, name: questionApplyEndCount+'/'+questionPropertyStartSum}],
			axisLine:{
				show: true,
				lineStyle: {
					color: [
						[0.3,'#C63300'],
						[0.6, '#EEEE00'],
						[1, '#33FF33']
					],
					width: 30
				},
                
			},
            axisTick: {show:true},
//            axisLabel: {           // 坐标轴文本标签，详见axis.axisLabel
//                show: true,
//                formatter: function(v){
//                    switch (v+''){
//                        case '10': return '10%';
//						case '20': return '20%';
//                        case '30': return '30%';
//						case '40': return '40%';
//						case '50': return '50%';
//                        case '60': return '60%';
//						case '70': return '70%';
//						case '80': return '80%';
//                        case '90': return '90%';
//						case '100': return '100%';
//                        default: return '';
//                    }
//                },
//                textStyle: {       // 其余属性默认使用全局文本样式，详见TEXTSTYLE
//                    color: '#333'
//                }
//            }
        }
    ]
};
myGauge2.setOption(optionGauge2, true);
//var timeTicket2;
//clearInterval(timeTicket2);
//timeTicket2 = setInterval(function (){
//    optionGauge2.series[0].data[0].value = (Math.random()*100).toFixed(2) - 0;
//    myGauge2.setOption(optionGauge2, true);
//},2000); 
myChart.setOption(option,true);

//违规预警及疑似问题分类统计
var questionTypeSumArray = null;
questionTypeSumArray = questionTypeSum.split('-');
if(questionTypeSum!=null&&questionTypeSum!=""){
    questionTypeSum = questionTypeSum.substr(0,questionTypeSum.length-1);
    questionTypeSumArray = new Array();
    questionTypeSumArray = questionTypeSum.split('-');
}
optionMyChart2 = {
    title : {
        text: '函询问题分类统计',
        textStyle:{
			color: '#4387df',
			fontWeight:'normal',
		},
    },
    tooltip : {
        trigger: 'axis'
         //formatter: "{a} <br/>{b} : {c}"
    },
    legend: {
        data:['', '']
    },
    grid:{
        left:100
    },
    toolbox: {
        show : true,
        feature : {
            mark : {show: true},
            dataView : {show: false, readOnly: false},
            magicType: {show: true, type: ['line', 'bar']},
            restore : {show: true},
            saveAsImage : {show: true}
        }
    },
    calculable : true,
    xAxis : [
        {
            type : 'value',
            boundaryGap : [0, 0.01]
        }
    ],
    yAxis : [
        {
            type : 'category',
            data : []
        }
    ],
    series : [
        {
            name:nowDate.getFullYear() + ''+(nowDate.getMonth()+1),
            type:'bar',
            //barWidth:'20',
            data:[]
        }
    ]
};
var strColor = ['#0000FF','#FF6600','#51ae0d'];
for(var i=0;i<questionTypeSumArray.length;i++){
    optionMyChart2.yAxis[0].data.push(questionTypeSumArray[i].split(',')[0]);
    var dataObjTypeSum1 = {value:0,itemStyle:{normal:{color:strColor[Math.ceil(Math.random()*3)-1]}}};
   // var dataObjTypeSum1 = {value:0,itemStyle:{normal:{color:'#FFFF00'}}};
    dataObjTypeSum1.value = questionTypeSumArray[i].split(',')[1];
    optionMyChart2.series[0].data.push(dataObjTypeSum1);
}
myChart2.setOption(optionMyChart2,true);         
//违规预警及疑似问题分类统计 结束        