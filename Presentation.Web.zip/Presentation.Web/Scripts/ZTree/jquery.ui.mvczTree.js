﻿//
//net01 mvc  tree组件
//v1.0
//
(function ($, undefined) {
    var requestIndex = 0;
    var _consts = {
        id: {
            TREE: "_ztree",
            DIV: "_menuContent"

        }
    };
    $.widget("ui.mvczTree", {
        version: "1.0",
        options: {
            appendTo: "body",
            width: "auto",
            height: "auto",
            disabled: false,
            source: null,
            callback: {
                beforeClick: null,
                selectedComplete: null
            },
            data: {
                simpleData: {
                    enable: true
                }
            },
            view: {
                selectedMulti: false
            },
            hideMenu: null,
            zIndex:null //自定义Z-Index
        },

        _create: function () {
            var self = this,
                doc = this.element[0].ownerDocument,
                maxZ = 0,
                thisZ;
            var treeId = self.element[0].id + _consts.id.TREE;
            var menuContentId = self.element[0].id + _consts.id.DIV;

            //set control Z-index To max
            $('.ui-dialog').each(function () {
                if (this !== self.element[0]) {
                    thisZ = $(this).css('z-index');
                    if (!isNaN(thisZ)) {
                        maxZ = Math.max(maxZ, thisZ);
                    }
                }
            });
            if (self.options.zIndex != null && self.options.zIndex > 0) {
                $.ui.dialog.maxZ = zIndex;
            } else {
                $.ui.dialog.maxZ = maxZ; 
            }
            

            this.tree = $("<ul></ul>")
                .css("margin-top", "0")
                .css("width", $(self.element[0]).width() - 8)
                .addClass("ztree")
                .attr("id", treeId);

            if (self.options.width !== "auto") {
                this.tree.css("width", self.options.width);
            }
            if (self.options.height !== "auto") {
                this.tree.css("height", self.options.height);
            }

            this.menuContent = $("<div></div>")
                .attr("id", menuContentId)
                .addClass("menuContent")
                .css("display", "none")
                .css("position", "absolute")
                .css('z-index', $.ui.dialog.maxZ + 500)
                .append(this.tree)
                .appendTo($(this.options.appendTo || "body", doc)[0]);

            this.element.attr("treeId", treeId)
            .attr("menuContentId", menuContentId)
            .bind("keydown.mvczTree", function (event) {
                if (self.options.disabled || self.element.attr("readonly")) {
                    return;
                }
            })
            .bind("click.mvczTree", function (event) {
                var cityObj = $(self.element[0]);
                var cityOffset = $(self.element[0]).offset();
                $("#" + $(this).attr("menuContentId")).css({ left: cityOffset.left + "px", top: cityOffset.top + cityObj.outerHeight() + "px" }).slideDown("fast");
                $("body").bind("mousedown", $(this).attr("menuContentId"), self.onBodyDown);

            })
            .bind("focus.mvczTree", function (event) {
                if (self.options.disabled) {
                    return;
                }
            })
            .bind('selectedcomplete.mvczTree', undefined, function (event, obj,id, treeNode) {
                //执行事件
                self.options.callback.selectedComplete.apply(null, [event, obj, id, treeNode]);
                $("body").trigger("mousedown", event);
                //阻止事件冒泡
                event.stopPropagation();
            });

            this.response = function () {
                return self._response.apply(self, arguments);
            };
            this._initSource();
        },

        _initSource: function () {
            var self = this, array, url;
            if ($.isArray(this.options.source)) {
                array = this.options.source;
                this.source = function (request, response) {
                    response(array);
                };
            } else if (typeof this.options.source === "string") {
                url = this.options.source;
                this.source = function (request, response) {
                    if (self.xhr) {
                        self.xhr.abort();
                    }
                    self.xhr = $.ajax({
                        url: url,
                        data: request,
                        dataType: "json",
                        async: true,
                        autocompleteRequest: ++requestIndex,
                        success: function (data, status) {
                            response(self._normalize(data));
                        },
                        error: function () {
                            if (this.autocompleteRequest === requestIndex) {
                                response([]);
                            }
                        }
                    });
                };
            } else if ($.isFunction(this.options.source)) {
                this.source = this.options.source;
            }
            this.source(null, this.response);
        },
        _init: function () {

        },
        _destroy: function () {
            this.element.remove();
            this.menu.element.remove();
            this.menuContent.remove();
        },
        _response: function (content) {
            var self = this;
            if (!self.options.disabled && content && content.length) {
                self.options.callback.onClick = self.onSelectedComplete;
                content = self._normalize(content);
                self.options.hideMenu = self.hideMenu;
                $.fn.zTree.init($("#" + self.element.attr("treeId")), self.options, content);
            }
        },
        _normalize: function (items) {
            if (items.length && items[0].id) {
                return items;
            }
            return $.map(items, function (item) {
                return { id: item.Id, pId: item.PId, name: item.Name, open: item.Open };
            });
        },
        hideMenu: function (contentId) {
            $("#" + contentId).fadeOut("fast");
            $("body").unbind("mousedown");
        },
        onBodyDown: function (event) {
            if (!(event.target.id == event.data || $(event.target).parents("#" + event.data).length > 0)) {
                var zTree = $.fn.zTree.getZTreeObj($("#" + event.data + " UL").first().attr("id"));
                if (zTree!=null) {
                    zTree.setting.hideMenu(event.data);
                }
            }
        },
        onSelectedComplete: function (e, id, treeNode) {
            var element = id.replace(_consts.id.TREE, "");
            $("#" + element).trigger("selectedcomplete.mvczTree", [e, id, treeNode]);
        }
    });
})(jQuery);