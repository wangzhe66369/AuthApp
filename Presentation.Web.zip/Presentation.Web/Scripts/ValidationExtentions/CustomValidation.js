﻿jQuery.validator.unobtrusive.adapters.add("chklist", ['min', 'max'],
    function (options) {
        options.rules['chklist'] = {
            min: options.params.min,
            max: options.params.max
        };
        options.messages['chklist'] = options.message;
    }
);

jQuery.validator.addMethod("chklist", function (value, element, params) {
    var retVal = false;
    var that = $("input[name='" + element.name + "']");
    var count = 0;
    that.each(function () {
        if ($(this).is(':checked')) {
            count++;
        }
    });
    //only min choose
    if (parseInt(params.max) === 0) {
        if (count >= params.min) {
            retVal = true;
        }
    } else {
        if (count >= params.min && count <= params.max) {
            retVal = true;
        }
    }
    var chkError = function (controls, v) {
        controls.each(function () {
            var self = $(this);

            if (v == false) {
                self.attr("class", "input-validation-error");
                self.attr("temp-class", self.attr("class")); //
            } else {
                self.removeClass("input-validation-error");
            }
        });
    };
    chkError(that, retVal);
    return retVal;
});