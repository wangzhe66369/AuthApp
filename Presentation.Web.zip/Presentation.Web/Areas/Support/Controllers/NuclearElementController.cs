﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   NuclearElementController.cs
 *   描    述   ：   基础数据标准库Controller
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using RWIS.Domain.DomainObjects.View;

using NET01.CoreFramework;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using RWIS.Presentation.Web.Areas.Support.ViewModels;

using MvcContrib.Sorting;
using RWIS.Domain.DomainObjects.View.Support;

namespace RWIS.Presentation.Web.Areas.Support.Controllers
{
    public class NuclearElementController : Controller
    {
        INuclearElementRepository _NuclearElementRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IScalefactorRepository _ScalefactorRepository;

        public NuclearElementController(INuclearElementRepository _NuclearElementRepository, IBasicObjectRepository _BasicObjectRepository, IScalefactorRepository _ScalefactorRepository)
        {
            this._NuclearElementRepository = _NuclearElementRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._ScalefactorRepository = _ScalefactorRepository;
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "基础数据标准库")]
        public ActionResult Index()
        {
            BaseStandardVM vm = new BaseStandardVM();
            vm.OperationList = CommonHelper.GetOperationList("NuclearElement_Manage");
            //加载状态
            vm.StatusList = new List<SelectListItem>();
            vm.StatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.StatusList.Add(new SelectListItem { Text = "未确认", Value = "0" });
            vm.StatusList.Add(new SelectListItem { Text = "已确认", Value = "1" });
            //是否可测量
            vm.ElementClassList = new List<SelectListItem>();
            //vm.ElementClassList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.ElementClassList.Add(new SelectListItem { Text = "可测量", Value = "1" });
            vm.ElementClassList.Add(new SelectListItem { Text = "不可测量 ", Value = "0" });

            //加载核素类型
            vm.ElementTypeList = new List<SelectListItem>();
            vm.ElementTypeList.Add(new SelectListItem { Text = "执照相关核素库", Value = "Licence" });
            vm.ElementTypeList.Add(new SelectListItem { Text = "处置安全相关核素库", Value = "DealSafe" });
            vm.ElementTypeList.Add(new SelectListItem { Text = "其他核素库 ", Value = "Other" });

            //加载比例因子类型
            vm.FactorTypeList = new List<SelectListItem>();
            vm.FactorTypeList.Add(new SelectListItem { Text = "中广核PWR", Value = "CGN" });
            vm.FactorTypeList.Add(new SelectListItem { Text = "法国EDF", Value = "FRANCE" });
            vm.FactorTypeList.Add(new SelectListItem { Text = "美国NRC", Value = "AMERICAN" });
            vm.FactorTypeList.Add(new SelectListItem { Text = "其他核电", Value = "OTHER" });

            //加载废物类型
            vm.NuClearTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> nuClearTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> nuClearTypeList = new List<BasicObject>();
            if (nuClearTypeQuery!=null && nuClearTypeQuery.Count() > 0)
             {
                 nuClearTypeList = nuClearTypeQuery.ToList();
                 foreach (var item in nuClearTypeList)
                 {
                     vm.NuClearTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                 }
             }
             

             //加载指标核素、加载DTM核素
             vm.QuotaElementList = new List<SelectListItem>();
             vm.DTMElementList = new List<SelectListItem>();
             IQueryable<NuclearElement> quotaElementQuery = _NuclearElementRepository.GetAll().AsQueryable().Where(d => d.Status == "1").OrderBy(c=>c.ElementName);
             List<NuclearElement> quotaElementList = new List<NuclearElement>();
             if (quotaElementQuery!=null&&quotaElementQuery.Count() > 0)
             {
                 quotaElementList = quotaElementQuery.ToList();
                 foreach (var item in quotaElementList)
                 {
                     vm.QuotaElementList.Add(new SelectListItem { Text = item.ElementName, Value = item.ElementId });
                     vm.DTMElementList.Add(new SelectListItem { Text = item.ElementName, Value = item.ElementId });
                 }
             }
             
            return View(vm);
        }
        public ActionResult Add()
        {
            return View();
        }
        public ActionResult DetailView(string id)
        {
            NuclearElement model = _NuclearElementRepository.Get(id);
            BaseStandardVM vm = new BaseStandardVM();
            vm.NuclearElement = model;
            return View("DetailView", vm);
        }
        public ActionResult AddScalefactor()
        {
            return View();
        }
        public ActionResult DetailScaleView(string id)
        {
            Scalefactor model = _ScalefactorRepository.Get(id);
            BaseStandardVM vm = new BaseStandardVM();
            vm.Scalefactor = model;
            BasicObject basicObjectNuClearType = _BasicObjectRepository.Get(model.WasteTypeId);
            if (basicObjectNuClearType != null)
            {
                vm.WasteTypeName = basicObjectNuClearType.Name;
            }
            else {
                vm.WasteTypeName = "";
            }
            NuclearElement nuclearElement = _NuclearElementRepository.Get(model.QuotaElementId);
            NuclearElement nuclearElements = _NuclearElementRepository.Get(model.DtmElementId);
            if (nuclearElement != null && nuclearElements != null)
            {
                model.QuotaElementId = nuclearElement.ElementName;
                model.DtmElementId = nuclearElements.ElementName;
            }
            else 
            {
                model.QuotaElementId = "";
                model.DtmElementId = "";
            }
            vm.Scalefactor = model;
            return View("DetailScaleView", vm);
        }
        public ActionResult Edit(string id)
        {  
            NuclearElement model = _NuclearElementRepository.Get(id);      
            return View("Edit", model);
        }
        public ActionResult EditScalefactor(string id)
        {
            Scalefactor model = _ScalefactorRepository.Get(id);
            return View("EditScalefactor", model);
        }
        public ActionResult Confirm(string id)
        {
            NuclearElement model = _NuclearElementRepository.Get(id);
            return View("Confirm", model);
        }

        /// <summary>
        /// 查询可测核素库列表
        /// </summary>
        /// <param name="keyWord">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetMeterNuclearElementList(NuclearElementCondition nuclearElementCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearElementView> data = this._NuclearElementRepository.QueryList(nuclearElementCondition).Where(c=>c.ElementClass=="1");
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearElementView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ElementId,
                    List = new List<object>() {
                    d.ElementId,
                    d.ElementTypeName,
                    d.ElementType,
                    d.ElementName,
                    d.HalfLife,
                    d.DecayHeat,
                    d.IaeaValue,
                    d.LowerValue,
                    d.LimitValue1,
                    d.LimitValue2,
                    d.LimitValue3,
                    d.Status,
                    d.ElementClass
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }


        /// <summary>
        /// 查询核素库列表
        /// </summary>
        /// <param name="keyWord">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNuclearElementList(NuclearElementCondition nuclearElementCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearElementView> data = this._NuclearElementRepository.QueryList(nuclearElementCondition);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearElementView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ElementId,
                    List = new List<object>() {
                    d.ElementId,
                    d.ElementTypeName,
                    d.ElementType,
                    d.ElementName,
                    d.HalfLife,
                    d.DecayHeat,
                    d.IaeaValue,
                    d.LowerValue,
                    d.LimitValue1,
                    d.LimitValue2,
                    d.LimitValue3,
                    d.Status,
                    d.ElementClass
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询比例因子列表
        /// </summary>
        /// <param name="keyWord">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetScalefactorList(NuclearElementCondition nuclearElementCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<ScalefactorView> data = this._ScalefactorRepository.QueryList(nuclearElementCondition);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<ScalefactorView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.FactorId,
                    List = new List<object>() {
                    d.FactorId,
                    d.FactorTypeName,
                    d.FactorType,
                    d.Source,
                    d.UnitType,
                    d.WasteTypeName,
                    d.QuotaElementName,
                    d.DtmElementName,
                    d.WasteTypeId,
                    d.QuotaElementId,
                    d.DtmElementId,
                    d.Scalevalue,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 新增核素库信息
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(BaseStandardVM model, FormCollection formCollection)
        {
            if (this._NuclearElementRepository.IsRepeat(model.NuclearElement.ElementName))
            {
                return Json("{\"result\":false,\"msg\":\"核素名重复。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                model.NuclearElement.ElementId = Guid.NewGuid().ToString();
                model.NuclearElement.Status = "0";
                model.NuclearElement.CreateUserNo = AppContext.CurrentUser.UserId;
                model.NuclearElement.CreateUserName = AppContext.CurrentUser.UserName;
                model.NuclearElement.CreateDate = DateTime.Now;
                model.NuclearElement.Stationcode = AppContext.CurrentUser.ProjectCode;
                this._NuclearElementRepository.Create(model.NuclearElement);
                this._NuclearElementRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch 
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 新增比例因子
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddScalefactor(BaseStandardVM model, FormCollection formCollection)
        {
            try
            {
                model.Scalefactor.FactorId = Guid.NewGuid().ToString();
                model.Scalefactor.Status = "0";
                model.Scalefactor.CreateUserNo = AppContext.CurrentUser.UserId;
                model.Scalefactor.CreateUserName = AppContext.CurrentUser.UserName;
                model.Scalefactor.CreateDate = DateTime.Now;
                model.Scalefactor.Stationcode = AppContext.CurrentUser.ProjectCode;
                this._ScalefactorRepository.Create(model.Scalefactor);
                this._ScalefactorRepository.UnitOfWork.Commit();  
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除核素库
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._NuclearElementRepository.DeleteById(idVal);
                    }
                    this._NuclearElementRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除比例因子
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult DeleteScalefactor(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._ScalefactorRepository.DeleteById(idVal);
                    }
                    this._ScalefactorRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 编辑核素库
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(BaseStandardVM model, FormCollection formCollection)
        {
            //判断核素名是否重复
            //string newElementName = model.NuclearElement.ElementName;
            //model.NuclearElement = _NuclearElementRepository.Get(model.NuclearElement.ElementId);
            if (model.NuclearElement.ElementName != model.NewElementName && this._NuclearElementRepository.IsRepeat(model.NuclearElement.ElementName))
            {
                return Json("{\"result\":false,\"msg\":\"核素名重复。\"}", JsonRequestBehavior.AllowGet);
            }
            //model.NuclearElement = _NuclearElementRepository.Get(model.NuclearElement.ElementId);
            UpdateModel(model);
            try
            {
                model.NuclearElement.Status = "0";
                model.NuclearElement.CreateUserNo = AppContext.CurrentUser.UserId;
                model.NuclearElement.CreateUserName = AppContext.CurrentUser.UserName;
                model.NuclearElement.CreateDate = DateTime.Now;
                model.NuclearElement.Stationcode = AppContext.CurrentUser.ProjectCode;
                this._NuclearElementRepository.Update(model.NuclearElement);
                this._NuclearElementRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 编辑比例因子
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult EditScalefactor(BaseStandardVM model, FormCollection formCollection)
        {
            try
            {
                model.Scalefactor = _ScalefactorRepository.Get(model.Scalefactor.FactorId);
                UpdateModel(model);
                model.Scalefactor.Status = "0";  
                this._ScalefactorRepository.Update(model.Scalefactor);
                this._ScalefactorRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认核素库
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "核素信息确认")]
        public JsonResult Confirm(BaseStandardVM model, FormCollection formCollection)
        {
            //判断核素名是否重复
            //string newElementName = model.NuclearElement.ElementName;
            //model.NuclearElement = _NuclearElementRepository.Get(model.NuclearElement.ElementId);
            if (model.NuclearElement.ElementName != model.NewElementName && this._NuclearElementRepository.IsRepeat(model.NuclearElement.ElementName))
            {
                return Json("{\"result\":false,\"msg\":\"核素名重复。\"}", JsonRequestBehavior.AllowGet);
            }
            //model.NuclearElement = _NuclearElementRepository.Get(model.NuclearElement.ElementId);
            UpdateModel(model);
            try
            {
                model.NuclearElement.Status = "1";
                model.NuclearElement.CreateUserNo = AppContext.CurrentUser.UserId;
                model.NuclearElement.CreateUserName = AppContext.CurrentUser.UserName;
                model.NuclearElement.CreateDate = DateTime.Now;
                model.NuclearElement.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.NuclearElement.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.NuclearElement.ConfirmDate = DateTime.Now;
                this._NuclearElementRepository.Update(model.NuclearElement);
                this._NuclearElementRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// 批量确认
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ConfirmBatch(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearElement nuclearElement = _NuclearElementRepository.Get(idVal);
                        nuclearElement.Status = "1";
                        this._NuclearElementRepository.Update(nuclearElement);
                    }
                    this._NuclearElementRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，确认失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认比例因子
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "比例因子确认")]
        public JsonResult ConfirmScalefactor(BaseStandardVM model, FormCollection formCollection)
        {
            try
            {
                model.Scalefactor = _ScalefactorRepository.Get(model.Scalefactor.FactorId);
                UpdateModel(model);
                model.Scalefactor.Status = "1";
                model.Scalefactor.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.Scalefactor.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.Scalefactor.ConfirmDate = DateTime.Now;
                this._ScalefactorRepository.Update(model.Scalefactor);
                this._ScalefactorRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        ///// <summary>
        ///// 确认核素库
        ///// </summary>
        ///// <param name="ElementId"></param>
        ///// <param name="formCollection"></param>
        ///// <returns></returns>
        //[HttpPost]
        //public JsonResult Confirm(string elementId, FormCollection formCollection)
        //{
        //    try
        //    {
        //        NuclearElement model = this._NuclearElementRepository.Get(elementId);
        //        if (model != null)
        //        {
        //            model.Status = "2";                 
        //            model.ConfirmUserNo = AppContext.CurrentUser.UserId;
        //            model.ConfirmUserName = AppContext.CurrentUser.UserName;
        //            model.ConfirmDate = DateTime.Now;
        //            this._NuclearElementRepository.Update(model);
        //            this._NuclearElementRepository.UnitOfWork.Commit();
        //            return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
        //        }
        //        else
        //        {
        //            return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
        //        }
        //    }
        //    catch
        //    {
        //        return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
        //    }
        //}

        ///// <summary>
        ///// 确认比例因子
        ///// </summary>
        ///// <param name="FactorId"></param>
        ///// <param name="formCollection"></param>
        ///// <returns></returns>
        //[HttpPost]
        //public JsonResult ConfirmScalefactor(string FactorId, FormCollection formCollection)
        //{
        //    try
        //    {
        //        Scalefactor model = this._ScalefactorRepository.Get(FactorId);
        //        if (model != null)
        //        {
        //            model.Status = "2";
        //            model.ConfirmUserNo = AppContext.CurrentUser.UserId;
        //            model.ConfirmUserName = AppContext.CurrentUser.UserName;
        //            model.ConfirmDate = DateTime.Now;
        //            this._ScalefactorRepository.Update(model);
        //            this._ScalefactorRepository.UnitOfWork.Commit();
        //            return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
        //        }
        //        else
        //        {
        //            return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
        //        }
        //    }
        //    catch
        //    {
        //        return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
        //    }
        //}
    }
}
