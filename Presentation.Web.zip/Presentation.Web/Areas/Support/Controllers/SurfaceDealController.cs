﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View.Support;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.Support.ViewModels;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.Support.Controllers
{
    public class SurfaceDealController : Controller
    {
        INuclearElementRepository _NuclearElementRepository;
        ISupportSurfaceDealRepository _SupportSurfaceDealRepository;

        public SurfaceDealController(INuclearElementRepository _NuclearElementRepository, ISupportSurfaceDealRepository _SupportSurfaceDealRepository)
        {
            this._NuclearElementRepository = _NuclearElementRepository;
            this._SupportSurfaceDealRepository = _SupportSurfaceDealRepository;
        }

       [UbaFilter(OperateType = OperateType.Page, OperateDescription = "近地表处置规定")]
        public ActionResult Index()
        {
            SurfaceDealVM vm = new SurfaceDealVM();
            vm.OperationList = CommonHelper.GetOperationList("Surface_Deal");//权限控制

            //加载指标核素、加载DTM核素
            vm.QuotaElementList = new List<SelectListItem>();
            IQueryable<NuclearElement> quotaElementQuery = _NuclearElementRepository.GetAll().AsQueryable().Where(d => d.Status == "1").OrderBy(c=>c.ElementName);
            List<NuclearElement> quotaElementList = new List<NuclearElement>();
            if (quotaElementQuery.Count() > 0)
            {
                quotaElementList = quotaElementQuery.ToList();
            }
            foreach (var item in quotaElementList)
            {
                vm.QuotaElementList.Add(new SelectListItem { Text = item.ElementName, Value = item.ElementId });
            }
            return View(vm);
        }

        public ActionResult EditSupportSurface(string id)
        {
            SupportSurfaceDeal model = _SupportSurfaceDealRepository.Get(id);
            return View("EditSupportSurface", model);
        }

        /// <summary>
        /// 查询核素库列表
        /// </summary>
        /// <param name="keyWord">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetSurfaceDealList(SurfaceDealCondition surfaceDealCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<SurfaceDealView> data = this._SupportSurfaceDealRepository.QueryList(surfaceDealCondition);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<SurfaceDealView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DealId,
                    List = new List<object>() {
                    d.DealId,
                    d.ElementId,                     
                    d.ElementName,
                     d.Column1,
                     d.Column2,
                     d.Column3,
                    d.Status,
                    //d.CreateDate
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddSupportSurface(SurfaceDealVM model, FormCollection formCollection)
        {
            if (this._SupportSurfaceDealRepository.IsRepeat(model.SupportSurfaceDeal.ElementId))
            {
                return Json("{\"result\":false,\"msg\":\"核素名重复。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                model.SupportSurfaceDeal.Status = "0";
                model.SupportSurfaceDeal.DealId = Guid.NewGuid().ToString();
                model.SupportSurfaceDeal.CreateUserNo = AppContext.CurrentUser.UserId;
                model.SupportSurfaceDeal.CreateUserName = AppContext.CurrentUser.UserName;
                model.SupportSurfaceDeal.CreateDate = DateTime.Now;
                model.SupportSurfaceDeal.Stationcode = AppContext.CurrentUser.ProjectCode;

                this._SupportSurfaceDealRepository.Create(model.SupportSurfaceDeal);
                this._SupportSurfaceDealRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult EditSupportSurface(SurfaceDealVM model, FormCollection formCollection)
        {
            

            try
            {
                model.SupportSurfaceDeal = _SupportSurfaceDealRepository.Get(model.SupportSurfaceDeal.DealId);
                UpdateModel(model);
                model.SupportSurfaceDeal.Status = "0";

                this._SupportSurfaceDealRepository.Update(model.SupportSurfaceDeal);
                this._SupportSurfaceDealRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        ///确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "近地表处置规定确认")]
        public JsonResult ConfirmSupportSurface(SurfaceDealVM model, FormCollection formCollection)
        {
            try
            {
                model.SupportSurfaceDeal = _SupportSurfaceDealRepository.Get(model.SupportSurfaceDeal.DealId);
                UpdateModel(model);
                model.SupportSurfaceDeal.Status = "2";
                model.SupportSurfaceDeal.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.SupportSurfaceDeal.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.SupportSurfaceDeal.ConfirmDate = DateTime.Now;

                this._SupportSurfaceDealRepository.Update(model.SupportSurfaceDeal);
                this._SupportSurfaceDealRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {

                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._SupportSurfaceDealRepository.DeleteById(idVal);
                    }
                    this._SupportSurfaceDealRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                 else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            }
        }

    }

