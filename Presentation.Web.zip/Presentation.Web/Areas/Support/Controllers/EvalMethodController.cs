﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   EvalMethodController.cs
 *   描    述   ：   评估方法标准库Controller
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.Support.ViewModels;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using MvcContrib.Sorting;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;


namespace RWIS.Presentation.Web.Areas.Support.Controllers
{
    public class EvalMethodController : Controller
    {
        INuclearElementRepository _NuclearElementRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IEvalMethodRepository _EvalMethodRepository;
        ICementTransferRepository _CementTransferRepository;
        IMetelTransferRepository _MetelTransferRepository;
        public EvalMethodController(INuclearElementRepository _NuclearElementRepository, IBasicObjectRepository _BasicObjectRepository, IEvalMethodRepository _EvalMethodRepository,ICementTransferRepository _CementTransferRepository,IMetelTransferRepository _MetelTransferRepository)
        {
            this._NuclearElementRepository = _NuclearElementRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._EvalMethodRepository = _EvalMethodRepository;
            this._CementTransferRepository = _CementTransferRepository;
            this._MetelTransferRepository = _MetelTransferRepository;
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "评估方法标准库页面")]
        public ActionResult Index()
        {
            EvalMethodVM vm = new EvalMethodVM();
            //加载核素类型
            vm.EvalMethodTypeList = new List<SelectListItem>();
            vm.EvalMethodTypeList.Add(new SelectListItem { Text = "废物衰变热", Value = "A", Selected = true });
            vm.EvalMethodTypeList.Add(new SelectListItem { Text = "∑D300a", Value = "B" });
            vm.EvalMethodTypeList.Add(new SelectListItem { Text = "总a", Value = "C" });
            //核素名
            vm.ElementNameList = new List<SelectListItem>();
            IQueryable<NuclearElement> ElementNameQuery = _NuclearElementRepository.GetAll().AsQueryable().Where(d => d.Status == "2");
            List<NuclearElement> elementNameList = new List<NuclearElement>();
            if (ElementNameQuery.Count() > 0)
            {
                elementNameList = ElementNameQuery.ToList();
            }
            foreach (var item in elementNameList)
            {
                vm.ElementNameList.Add(new SelectListItem { Text = item.ElementName, Value = item.ElementId });               
            }
            //加载水泥桶类型
            vm.BucketTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> bucketTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("BucketType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> bucketTypeTypeList = new List<BasicObject>();
            if (bucketTypeQuery!=null && bucketTypeQuery.Count() > 0)
            {
                bucketTypeTypeList = bucketTypeQuery.ToList();
            }
            foreach (var item in bucketTypeTypeList)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            return View(vm);
        }
        public ActionResult Add()
        {
            return View();
        }
        public ActionResult DetailView(string id)
        {
            EvalMethod model = _EvalMethodRepository.Get(id);
            EvalMethodVM vm = new EvalMethodVM();
            NuclearElement nuclearElement = _NuclearElementRepository.Get(model.ElementId);
            if (nuclearElement != null)
            {
                model.ElementId = nuclearElement.ElementName;
            }
            else {
                model.ElementId = "";
            }
            vm.EvalMethod = model;
            return View("DetailView", vm);
        }
       
        public ActionResult Edit(string id)
        {
            EvalMethod model = _EvalMethodRepository.Get(id);
            return View("Edit", model);
        }

        /// <summary>
        /// 查询评估方法列表
        /// </summary>
        /// <param name="keyWord">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetEvalMethodList(string keyWord, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<EvalMethodView> data = this._EvalMethodRepository.QueryList(keyWord).OrderBy("ElementName", SortDirection.Descending);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<EvalMethodView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.MethodId,
                    List = new List<object>() {
                    d.MethodId,
                    d.TypeName,
                    d.Type,
                    d.ElementName,
                    d.ElementId,
                    d.HalfLife,
                    d.DecayHeat, 
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

      
       

        /// <summary>
        /// 新增评估方法
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Add(EvalMethodVM model, FormCollection formCollection)
        {
 
            try
            {
                model.EvalMethod.Status = "0";
                model.EvalMethod.MethodId = Guid.NewGuid().ToString();
                model.EvalMethod.CreateUserNo = AppContext.CurrentUser.UserId;
                model.EvalMethod.CreateUserName = AppContext.CurrentUser.UserName;
                model.EvalMethod.CreateDate = DateTime.Now;
                model.EvalMethod.Stationcode = AppContext.CurrentUser.ProjectCode;

                //EvalMethod evalMethod = new EvalMethod();
                //evalMethod = model.EvalMethod;
                //evalMethod.HalfLife = Convert.ToDecimal(model.EvalMethod.HalfLife);
                this._EvalMethodRepository.Create(model.EvalMethod);
                this._EvalMethodRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        
        /// <summary>
        /// 删除评估方法
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._EvalMethodRepository.DeleteById(idVal);
                    }
                    this._EvalMethodRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        
        /// <summary>
        /// 编辑评估方法
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Edit(EvalMethodVM model, FormCollection formCollection)
        {
            try
            {
                model.EvalMethod.Status = "0";
                model.EvalMethod.CreateUserNo = AppContext.CurrentUser.UserId;
                model.EvalMethod.CreateUserName = AppContext.CurrentUser.UserName;
                model.EvalMethod.CreateDate = DateTime.Now;
                model.EvalMethod.Stationcode = AppContext.CurrentUser.ProjectCode;  
                this._EvalMethodRepository.Update(model.EvalMethod);
                this._EvalMethodRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认评估方法
        /// </summary>
        /// <param name="methodId"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "评估方法标准库确认")]
        public JsonResult Confirm(string methodId, FormCollection formCollection)
        {
            try
            {
                EvalMethod model = this._EvalMethodRepository.Get(methodId);
                if (model != null)
                {
                    model.Status = "1";
                    model.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.ConfirmDate = DateTime.Now;
                    this._EvalMethodRepository.Update(model);
                    this._EvalMethodRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }       
    }
}
