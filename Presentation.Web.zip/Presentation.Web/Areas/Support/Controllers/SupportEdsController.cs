﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   SupportEdsController.cs
 *   描    述   ：   标准谱库Controller
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.Support.ViewModels;
using RWIS.Domain.DomainObjects;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.DomainObjects.View.Support;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using RWIS.Domain.DomainObjects.View;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.Support.Controllers
{
    /// <summary>
    /// 标准谱库Controller
    /// </summary>
    public class SupportEdsController : Controller
    {
        ISupportEdsRepository _SupportEdsRepository;
        ISupportEdsDetailRepository _SupportEdsDetailRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearElementRepository _NuclearElementRepository;
        public SupportEdsController(ISupportEdsRepository _SupportEdsRepository, ISupportEdsDetailRepository _SupportEdsDetailRepository, IBasicObjectRepository _BasicObjectRepository, INuclearElementRepository _NuclearElementRepository)
        {
            this._SupportEdsRepository = _SupportEdsRepository;
            this._SupportEdsDetailRepository = _SupportEdsDetailRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearElementRepository = _NuclearElementRepository;
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "活度计算标准库")]
        public ActionResult Index()
        {
            SupportEdsVM vm = new SupportEdsVM();
            vm.OperationList = CommonHelper.GetOperationList("Eds_Manage");
            //加载废物类型
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery!=null && wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
                vm.WasteTypeIdList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in wasteTypeIdList)
                {
                    vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            ////加载废物货包类型
            //vm.WasteTypeBagList = new List<SelectListItem>();
            //vm.WasteTypeBagList.Add(new SelectListItem { Text = "树脂废物", Value = "A", Selected = true });
            //vm.WasteTypeBagList.Add(new SelectListItem { Text = "浓缩液", Value = "B" });
            //vm.WasteTypeBagList.Add(new SelectListItem { Text = "技术类废物", Value = "E" });
            //加载谱类型
            vm.EdsTypeList = new List<SelectListItem>();
            vm.EdsTypeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.EdsTypeList.Add(new SelectListItem { Text = "标准谱", Value = "S" });
            vm.EdsTypeList.Add(new SelectListItem { Text = "测量谱", Value = "M" });
            vm.EdsTypeList.Add(new SelectListItem { Text = "计算谱", Value = "C" });

            //加载核素名
            vm.ElementNameList = new List<SelectListItem>();
            IQueryable<NuclearElement> elementNameQuery = _NuclearElementRepository.GetAll().AsQueryable().Where(d => d.Status == "1");
            List<NuclearElement> elementNameList = new List<NuclearElement>();
            if (elementNameQuery!=null&&elementNameQuery.Count() > 0)
            {
                elementNameList = elementNameQuery.ToList();
                foreach (var item in elementNameList)
                {
                    vm.ElementNameList.Add(new SelectListItem { Text = item.ElementName, Value = item.ElementId });
                }
            }
            
            return View(vm);
        }

        public ActionResult Add()
        {
            SupportEdsVM vm = new SupportEdsVM();
            vm.OperationList = CommonHelper.GetOperationList("Eds_Manage");
            //加载废物类型
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery!=null&&wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
                foreach (var item in wasteTypeIdList)
                {
                    vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            //加载谱类型
            vm.EdsTypeList = new List<SelectListItem>();
            vm.EdsTypeList.Add(new SelectListItem { Text = "标准谱", Value = "S", Selected = true });
            vm.EdsTypeList.Add(new SelectListItem { Text = "测量谱", Value = "M" });
            vm.EdsTypeList.Add(new SelectListItem { Text = "计算谱", Value = "C" });

            //加载核素类型
            vm.ElementTypeList = new List<SelectListItem>();
            vm.ElementTypeList.Add(new SelectListItem { Text = "执照相关核素库", Value = "Licence", Selected = true });
            vm.ElementTypeList.Add(new SelectListItem { Text = "处置安全相关核素库", Value = "DealSafe" });
            vm.ElementTypeList.Add(new SelectListItem { Text = "其他核素库 ", Value = "Other" });
            SupportEds model = new SupportEds();
            vm.SupportEds = model;
            return View(vm);
        }
        public ActionResult DetailView(string id, string edsSerialCode)
        {

            SupportEdsVM vm = new SupportEdsVM();
            vm.OperationList = CommonHelper.GetOperationList("Eds_Manage");
            //加载废物类型
            vm.WasteTypeIdList = new List<SelectListItem>();
            SupportEds model = _SupportEdsRepository.Get(id);
            vm.SupportEds = model;
            BasicObject wasteTypeIdQuery = _BasicObjectRepository.Get(model.WasteTypeId);
            if (wasteTypeIdQuery != null)
            { 
               ViewBag.WasteTypeId=wasteTypeIdQuery.Name;
            }
            //List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            //if (wasteTypeIdQuery != null && wasteTypeIdQuery.Count() > 0)
            //{
            //    wasteTypeIdList = wasteTypeIdQuery.ToList();
            //    foreach (var item in wasteTypeIdList)
            //    {
            //        vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            //    }
            //}
            if (model.EdsType == "S")
            {
                ViewBag.EdsType = "标准谱";
            }
            if (model.EdsType == "M")
            {
                ViewBag.EdsType = "测量谱";
            }
            if (model.EdsType == "C")
            {
                ViewBag.EdsType = "计算谱";
            }
            //加载谱类型
            vm.EdsTypeList = new List<SelectListItem>();
            vm.EdsTypeList.Add(new SelectListItem { Text = "标准谱", Value = "S", Selected = true });
            vm.EdsTypeList.Add(new SelectListItem { Text = "测量谱", Value = "M" });
            vm.EdsTypeList.Add(new SelectListItem { Text = "计算谱", Value = "C" });



            ////加载核素名
            //vm.ElementNameList = new List<SelectListItem>();
            //IQueryable<NuclearElement> elementNameQuery = _NuclearElementRepository.GetAll().AsQueryable().Where(d => d.Status == "1");
            //List<NuclearElement> elementNameList = new List<NuclearElement>();
            //if (elementNameQuery != null && elementNameQuery.Count() > 0)
            //{
            //    elementNameList = elementNameQuery.ToList();
            //    foreach (var item in elementNameList)
            //    {
            //        vm.ElementNameList.Add(new SelectListItem { Text = item.ElementName, Value = item.ElementId });
            //    }
            //}

            //加载核素类型
            vm.ElementTypeList = new List<SelectListItem>();
            vm.ElementTypeList.Add(new SelectListItem { Text = "执照相关核素库", Value = "Licence", Selected = true });
            vm.ElementTypeList.Add(new SelectListItem { Text = "处置安全相关核素库", Value = "DealSafe" });
            vm.ElementTypeList.Add(new SelectListItem { Text = "其他核素库 ", Value = "Other" });
           
            List<SupportEdsDetail> SupportEdsDetailQuery = _SupportEdsDetailRepository.GetAll().Where(d => d.EdsId == model.EdsId).ToList();
            ///如果数字类型不为空，截取小数点后三位
            for (int i = 0; i < SupportEdsDetailQuery.Count(); i++)
            {
                if (SupportEdsDetailQuery[i].PercentValue != null)
                {
                    if (SupportEdsDetailQuery[i].PercentValue.Value.ToString().IndexOf('.') > 0)
                        SupportEdsDetailQuery[i].PercentValue = Convert.ToDouble(String.Format("{0:00.000}", SupportEdsDetailQuery[i].PercentValue));
                }
            }
            //IQueryable<SupportEdsDetail> DetailIdQuery = _SupportEdsDetailRepository.GetAll().Where(d => d.DetailId == id).AsQueryable();
            //foreach (var itemList in DetailIdQuery)
            //{  
            //    NuclearElement nuclearElement = _NuclearElementRepository.Get(itemList.ElementId);
            //    if (nuclearElement != null)
            //    {
            //        vm.ElementName = nuclearElement.ElementName;
            //        vm.HalfLife = nuclearElement.HalfLife;
            //    }
            //    else
            //    {
            //        vm.ElementName = "";
            //        vm.HalfLife = null;
            //    }
            //    vm.PercentValue = itemList.PercentValue;
            //    if (vm.PercentValue != null)
            //    {
            //        if (vm.PercentValue.Value.ToString().IndexOf('.') > 0)
            //            vm.PercentValue = Convert.ToDouble(String.Format("{0:00.000}", vm.PercentValue));
            //    }
            //    vm.SupportEdsDetail = itemList;
            //    SupportEds model = _SupportEdsRepository.Get(itemList.EdsId);
            //    BasicObject basicObjectNuClearType = _BasicObjectRepository.Get(model.WasteTypeId);
            //    if (basicObjectNuClearType != null)
            //    {
            //        vm.WasteTypeName = basicObjectNuClearType.Name;
            //    }
            //    vm.SupportEds = model; 
            //}
            ViewBag.edsSerialCode = edsSerialCode;
            return View("DetailView", vm);
        }

        public ActionResult GetSupportEdsListAll(string edsSerialCode, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<SupportEdsView> data = this._SupportEdsRepository.QueryLisByCode(edsSerialCode);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<SupportEdsView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DetailId,
                    List = new List<object>() {
                    d.DetailId,
                    d.EdsId,
                    d.EdsSerialCode,
                    d.Year,
                    d.EdsType,
                    d.WasteTypeName,
                    d.ElementName,
                    d.HalfLife,
                    d.PercentValue,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        public ActionResult Edit(string id)
        {
            SupportEdsVM vm = new SupportEdsVM();
            vm.OperationList = CommonHelper.GetOperationList("Eds_Manage");
            //加载废物类型
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery!=null&&wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
                foreach (var item in wasteTypeIdList)
                {
                    vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }  
            }
            
            //加载谱类型
            vm.EdsTypeList = new List<SelectListItem>();
            vm.EdsTypeList.Add(new SelectListItem { Text = "标准谱", Value = "S", Selected = true });
            vm.EdsTypeList.Add(new SelectListItem { Text = "测量谱", Value = "M" });
            vm.EdsTypeList.Add(new SelectListItem { Text = "计算谱", Value = "C" });

            //加载核素名
            vm.ElementNameList = new List<SelectListItem>();
            IQueryable<NuclearElement> elementNameQuery = _NuclearElementRepository.GetAll().AsQueryable().Where(d => d.Status == "1");
            List<NuclearElement> elementNameList = new List<NuclearElement>();
            if (elementNameQuery!=null&&elementNameQuery.Count() > 0)
            {
                elementNameList = elementNameQuery.ToList();
                foreach (var item in elementNameList)
                {
                    vm.ElementNameList.Add(new SelectListItem { Text = item.ElementName, Value = item.ElementId });
                }
            }
            
            //加载核素类型
            vm.ElementTypeList = new List<SelectListItem>();
            vm.ElementTypeList.Add(new SelectListItem { Text = "执照相关核素库", Value = "Licence", Selected = true });
            vm.ElementTypeList.Add(new SelectListItem { Text = "处置安全相关核素库", Value = "DealSafe" });
            vm.ElementTypeList.Add(new SelectListItem { Text = "其他核素库 ", Value = "Other" });
            SupportEds model = _SupportEdsRepository.Get(id);
            vm.SupportEds = model;
            List<SupportEdsDetail> SupportEdsDetailQuery = _SupportEdsDetailRepository.GetAll().Where(d => d.EdsId == model.EdsId).ToList();
            ///如果数字类型不为空，截取小数点后三位
            for (int i = 0; i < SupportEdsDetailQuery.Count(); i++)
            {
                if (SupportEdsDetailQuery[i].PercentValue != null)
                {
                    if (SupportEdsDetailQuery[i].PercentValue.Value.ToString().IndexOf('.') > 0)
                        SupportEdsDetailQuery[i].PercentValue = Convert.ToDouble(String.Format("{0:00.000}", SupportEdsDetailQuery[i].PercentValue));
                }
            }
            return View("Edit", vm);
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetSupportEdsList(SupportEdsCondition supportEdsCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<SupportEdsView> data = this._SupportEdsRepository.QueryList(supportEdsCondition).GroupBy(d=>d.EdsSerialCode).Select(g=>g.FirstOrDefault());
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<SupportEdsView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DetailId,
                    List = new List<object>() {
                    d.DetailId,
                    d.EdsId,
                    d.EdsSerialCode,
                    d.Year,
                    d.EdsType,
                    d.WasteTypeName,
                    d.ElementName,
                    d.HalfLife,
                    d.PercentValue,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }


        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetSupportEds(SupportEdsCondition supportEdsCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<SupportEdsView> data = this._SupportEdsRepository.GetEdsList(supportEdsCondition);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<SupportEdsView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.EdsId,
                    List = new List<object>() {
                    d.EdsId,
                    d.EdsSerialCode,
                    d.Year,
                    d.EdsType,
                    d.WasteTypeName,
                    d.WasteTypeId,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetSupportEdsDetailList(string EdsId, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<SupportEdsDetailView> data = this._SupportEdsDetailRepository.QueryList(EdsId).Where(d => d.EdsId == EdsId).AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<SupportEdsDetailView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DetailId,
                    List = new List<object>() {
                    d.DetailId,
                    d.EdsId,
                    d.ElementId,
                    d.ElementName,
                    d.HalfLife,
                    d.Activity,
                    d.PercentValue
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        public ActionResult GetDetailList(string EdsId)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 1000000000, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            //获取数据
            string strEdsId = _SupportEdsRepository.GetIdByCode(EdsId, AppContext.CurrentUser.ProjectCode);
            IQueryable<SupportEdsDetailView> data = this._SupportEdsDetailRepository.QueryList(strEdsId).AsQueryable();
            List<SupportEdsDetailView> list = new List<SupportEdsDetailView>();
            if (data.Count() > 0)
            {
                list = data.ToList();
            }

            //行ColNames  list
            List<string> listColNs = new List<string>();
            //行ColModels list
            List<MaterialStockDetailVM> listColMs = new List<MaterialStockDetailVM>();
            
            //表头
            listColNs.Add("样品号");
            MaterialStockDetailVM sampleNum = new MaterialStockDetailVM();
            sampleNum.name = "SampleNum";
            sampleNum.index = "SampleNum";
            sampleNum.align = "center";
            listColMs.Add(sampleNum);

            listColNs.Add("取样日期");
            MaterialStockDetailVM sampleDate = new MaterialStockDetailVM();
            sampleDate.name = "SampleDate";
            sampleDate.index = "SampleDate";
            sampleDate.align = "center";
            listColMs.Add(sampleDate);

            //列
            for (int i = 0; i < 2; i++)
            {
         

            }
            foreach (var item in list)
            {
                MaterialStockDetailVM model = new MaterialStockDetailVM();
                model.name = item.ElementName;
                model.index = item.ElementName;
                model.align = "center";

                listColNs.Add(item.ElementName);
                listColMs.Add(model);
            }
            var resultObj = new
            {
                ColNs = listColNs,
                ColMs = listColMs
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(SupportEdsVM model, FormCollection formCollection)
        {
            try
            {
                if (this._SupportEdsRepository.IsRepeat(model.SupportEds.EdsSerialCode, AppContext.CurrentUser.ProjectCode))
                {
                    return Json("{\"result\":false,\"msg\":\"能谱序号重复。\"}", JsonRequestBehavior.AllowGet);
                }
                model.SupportEds.EdsId = Guid.NewGuid().ToString();
                model.SupportEds.Status = "0";
                model.SupportEds.CreateUserNo = AppContext.CurrentUser.UserId;
                model.SupportEds.CreateUserName = AppContext.CurrentUser.UserName;
                model.SupportEds.CreateDate = DateTime.Now;
                model.SupportEds.Stationcode = AppContext.CurrentUser.ProjectCode;
                this._SupportEdsRepository.Create(model.SupportEds);
                if (!string.IsNullOrEmpty(model.SupportEdsDetails))
                {
                    //新增核素信息
                    string[] arrSupportEdsDetailList = model.SupportEdsDetails.Split(';');
                    for (int i = 0; i < arrSupportEdsDetailList.Length; i++)
                    {
                        SupportEdsDetail supportEdsDetail = new SupportEdsDetail();
                        string[] arrSupportEdsDetailt = arrSupportEdsDetailList[i].Split(',');
                        if (arrSupportEdsDetailt.Length == 4)
                        {
                            supportEdsDetail.DetailId = Guid.NewGuid().ToString();
                            supportEdsDetail.EdsId = model.SupportEds.EdsId;

                            supportEdsDetail.ElementId = arrSupportEdsDetailt[0];
                            string percentValue = arrSupportEdsDetailt[3];
                            if (string.IsNullOrEmpty(percentValue)) percentValue = "0";
                            supportEdsDetail.PercentValue = Convert.ToDouble(percentValue);


                            this._SupportEdsDetailRepository.Create(supportEdsDetail);
                        }
                    }

                }
                this._SupportEdsRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }   

        [HttpPost]
        public JsonResult Delete(string DetailId)
        {
            try
            {
                string[] idArr = DetailId.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                
                
                foreach (string item in idArr)
                {
                    IQueryable<SupportEdsDetail> DetailIdQuery = _SupportEdsDetailRepository.GetAll().Where(d => d.DetailId == item).AsQueryable();
                    List<SupportEdsDetail> DetailIdQueryList = DetailIdQuery.ToList();
                    this._SupportEdsDetailRepository.DeleteById(item);
                    this._SupportEdsDetailRepository.UnitOfWork.Commit();

                    foreach (var items in DetailIdQueryList)
                    {
                        IQueryable<SupportEdsDetail> DetailIdSQuery = _SupportEdsDetailRepository.GetAll().Where(d => d.EdsId == items.EdsId).AsQueryable();
                        List<SupportEdsDetail> DetailIdSQueryList = DetailIdSQuery.ToList();
                        if (DetailIdSQueryList.Count() == 0)
                        {
                            foreach (var itemes in DetailIdQueryList)
                            {
                                this._SupportEdsRepository.DeleteById(itemes.EdsId);
                                this._SupportEdsRepository.UnitOfWork.Commit();
                            }
                        }
                    }  
                }        
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);           
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
       

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public JsonResult Edit(SupportEdsVM model, FormCollection formCollection)
        {
            try
            {
                string newEdsSerialCode = model.SupportEds.EdsSerialCode;
                //更新能谱库
                model.SupportEds = _SupportEdsRepository.Get(model.SupportEds.EdsId);

                //判断能谱序号是否重复
                if (model.SupportEds.EdsSerialCode != newEdsSerialCode && this._SupportEdsRepository.IsRepeat(model.SupportEds.EdsSerialCode, AppContext.CurrentUser.ProjectCode))
                {
                    return Json("{\"result\":false,\"msg\":\"能谱序号重复。\"}", JsonRequestBehavior.AllowGet);
                }
                UpdateModel(model);
                model.SupportEds.Status = "0";
                this._SupportEdsRepository.Update(model.SupportEds);
                //根据能谱ID查询能谱详细
                IQueryable<SupportEdsDetail> data = this._SupportEdsDetailRepository.QueryListByDetailId(model.SupportEds.EdsId);
                List<SupportEdsDetail> listData = data.ToList();
                //删除金属桶验收单详细的数据
                foreach (var item in listData)
                {
                    this._SupportEdsDetailRepository.DeleteById(item.DetailId);
                }
                
                if (!string.IsNullOrEmpty(model.SupportEdsDetails))
                {
                    //新增核素信息
                    string[] arrSupportEdsDetailList = model.SupportEdsDetails.Split(';');
                    for (int i = 0; i < arrSupportEdsDetailList.Length; i++)
                    {
                        SupportEdsDetail supportEdsDetail = new SupportEdsDetail();
                        string[] arrSupportEdsDetailt = arrSupportEdsDetailList[i].Split(',');
                        if (arrSupportEdsDetailt.Length == 5)
                        {
                            supportEdsDetail.DetailId = Guid.NewGuid().ToString();
                            supportEdsDetail.EdsId = model.SupportEds.EdsId;
                            supportEdsDetail.ElementId = arrSupportEdsDetailt[0];
                            string activity = arrSupportEdsDetailt[3];
                            string percentValue = arrSupportEdsDetailt[4];
                            if (string.IsNullOrEmpty(percentValue)) percentValue = "0";
                            supportEdsDetail.PercentValue = Convert.ToDouble(percentValue);
                            supportEdsDetail.Activity = Convert.ToDouble(activity);
                            this._SupportEdsDetailRepository.Create(supportEdsDetail);
                        }
                    }
                }
                this._SupportEdsRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);              
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(SupportEdsVM model, FormCollection formCollection)
        {
            try
            {
                if (string.IsNullOrEmpty(model.SupportEds.EdsId))
                {
                    model.SupportEds.EdsId = Guid.NewGuid().ToString();
                    model.SupportEds.Status = "1";
                    model.SupportEds.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.SupportEds.CreateUserName = AppContext.CurrentUser.UserName;
                    model.SupportEds.CreateDate = DateTime.Now;
                    model.SupportEds.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._SupportEdsRepository.Create(model.SupportEds);
                    if (!string.IsNullOrEmpty(model.SupportEdsDetails))
                    {
                        //新增核素信息
                        string[] arrSupportEdsDetailList = model.SupportEdsDetails.Split(';');
                        for (int i = 0; i < arrSupportEdsDetailList.Length; i++)
                        {
                            SupportEdsDetail supportEdsDetail = new SupportEdsDetail();
                            string[] arrSupportEdsDetailt = arrSupportEdsDetailList[i].Split(',');
                            if (arrSupportEdsDetailt.Length == 5)
                            {
                                supportEdsDetail.DetailId = Guid.NewGuid().ToString();
                                supportEdsDetail.EdsId = model.SupportEds.EdsId;
                                supportEdsDetail.ElementId = arrSupportEdsDetailt[0];
                                string activity = arrSupportEdsDetailt[3];
                                string percentValue = arrSupportEdsDetailt[4];
                                if (string.IsNullOrEmpty(percentValue)) percentValue = "0";
                                supportEdsDetail.PercentValue = Convert.ToDouble(percentValue);
                                supportEdsDetail.Activity = Convert.ToDouble(activity);
                                this._SupportEdsDetailRepository.Create(supportEdsDetail);
                            }
                        }
                    }
                    this._SupportEdsRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    //更新能谱库
                    model.SupportEds = _SupportEdsRepository.Get(model.SupportEds.EdsId);
                    UpdateModel(model);
                    model.SupportEds.Status = "1";
                    this._SupportEdsRepository.Update(model.SupportEds);
                    //根据能谱ID查询能谱详细
                    IQueryable<SupportEdsDetail> data = this._SupportEdsDetailRepository.QueryListByDetailId(model.SupportEds.EdsId);
                    List<SupportEdsDetail> listData = data.ToList();
                    //删除金属桶验收单详细的数据
                    foreach (var item in listData)
                    {
                        this._SupportEdsDetailRepository.DeleteById(item.DetailId);
                    }
                    if (!string.IsNullOrEmpty(model.SupportEdsDetails))
                    {
                        //新增核素信息
                        string[] arrSupportEdsDetailList = model.SupportEdsDetails.Split(';');
                        for (int i = 0; i < arrSupportEdsDetailList.Length; i++)
                        {
                            SupportEdsDetail supportEdsDetail = new SupportEdsDetail();
                            string[] arrSupportEdsDetailt = arrSupportEdsDetailList[i].Split(',');
                            if (arrSupportEdsDetailt.Length == 5)
                            {
                                supportEdsDetail.DetailId = Guid.NewGuid().ToString();
                                supportEdsDetail.EdsId = model.SupportEds.EdsId;
                                supportEdsDetail.ElementId = arrSupportEdsDetailt[0];
                                string activity = arrSupportEdsDetailt[3];
                                string percentValue = arrSupportEdsDetailt[4];
                                if (string.IsNullOrEmpty(percentValue)) percentValue = "0";
                                supportEdsDetail.PercentValue = Convert.ToDouble(percentValue);
                                supportEdsDetail.Activity = Convert.ToDouble(activity);
                                this._SupportEdsDetailRepository.Create(supportEdsDetail);
                            }
                        }
                    }
                    this._SupportEdsRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "活度计算标准库确认")]
        public JsonResult Confirm(SupportEdsVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                model.SupportEds.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.SupportEds.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.SupportEds.ConfirmDate = DateTime.Now;
                model.SupportEds.Stationcode = AppContext.CurrentUser.ProjectCode;
                model.SupportEds.Status = "2";

                if (string.IsNullOrEmpty(model.SupportEds.EdsId))
                {
                    model.SupportEds.EdsId = Guid.NewGuid().ToString();
              
                    model.SupportEds.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.SupportEds.CreateUserName = AppContext.CurrentUser.UserName;
                    model.SupportEds.CreateDate = DateTime.Now;
                  
                    this._SupportEdsRepository.Create(model.SupportEds);
                    if (!string.IsNullOrEmpty(model.SupportEdsDetails))
                    {
                        //新增核素信息
                        string[] arrSupportEdsDetailList = model.SupportEdsDetails.Split(';');
                        for (int i = 0; i < arrSupportEdsDetailList.Length; i++)
                        {
                            SupportEdsDetail supportEdsDetail = new SupportEdsDetail();
                            string[] arrSupportEdsDetailt = arrSupportEdsDetailList[i].Split(',');
                            if (arrSupportEdsDetailt.Length == 5)
                            {
                                supportEdsDetail.DetailId = Guid.NewGuid().ToString();
                                supportEdsDetail.EdsId = model.SupportEds.EdsId;
                                supportEdsDetail.ElementId = arrSupportEdsDetailt[0];
                                string activity = arrSupportEdsDetailt[3];
                                string percentValue = arrSupportEdsDetailt[4];
                                if (string.IsNullOrEmpty(percentValue)) percentValue = "0";
                                supportEdsDetail.PercentValue = Convert.ToDouble(percentValue);
                                supportEdsDetail.Activity = Convert.ToDouble(activity);
                                this._SupportEdsDetailRepository.Create(supportEdsDetail);
                            }
                        }
                    }
                    this._SupportEdsRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    //更新能谱库
                    model.SupportEds = _SupportEdsRepository.Get(model.SupportEds.EdsId);
                    UpdateModel(model);
                    model.SupportEds.Status = "2";
                    this._SupportEdsRepository.Update(model.SupportEds);
                    //根据能谱ID查询能谱详细
                    IQueryable<SupportEdsDetail> data = this._SupportEdsDetailRepository.QueryListByDetailId(model.SupportEds.EdsId);
                    List<SupportEdsDetail> listData = data.ToList();
                    //删除能谱详细的数据
                    foreach (var item in listData)
                    {
                        this._SupportEdsDetailRepository.DeleteById(item.DetailId);
                    }
                    if (!string.IsNullOrEmpty(model.SupportEdsDetails))
                    {
                        //新增核素信息
                        string[] arrSupportEdsDetailList = model.SupportEdsDetails.Split(';');
                        for (int i = 0; i < arrSupportEdsDetailList.Length; i++)
                        {
                            SupportEdsDetail supportEdsDetail = new SupportEdsDetail();
                            string[] arrSupportEdsDetailt = arrSupportEdsDetailList[i].Split(',');
                            if (arrSupportEdsDetailt.Length == 5)
                            {
                                supportEdsDetail.DetailId = Guid.NewGuid().ToString();
                                supportEdsDetail.EdsId = model.SupportEds.EdsId;
                                supportEdsDetail.ElementId = arrSupportEdsDetailt[0];
                                string activity = arrSupportEdsDetailt[3];
                                string percentValue = arrSupportEdsDetailt[4];
                                if (string.IsNullOrEmpty(percentValue)) percentValue = "0";
                                supportEdsDetail.PercentValue = Convert.ToDouble(percentValue);
                                supportEdsDetail.Activity = Convert.ToDouble(activity);
                                this._SupportEdsDetailRepository.Create(supportEdsDetail);
                            }
                        }
                    }
                    this._SupportEdsRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "活度计算标准库确认")]
        public JsonResult ConfirmSupportEds(string EdsId, FormCollection formCollection)
        {
            //if (!ModelState.IsValid)
            //{
            //    return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            //}
            try
            {
                SupportEds model = this._SupportEdsRepository.Get(EdsId);
                if (model != null)
                {
                    model.Status = "2";
                    model.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.ConfirmDate = DateTime.Now;
                    this._SupportEdsRepository.Update(model);
                    this._SupportEdsRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
    }
}
