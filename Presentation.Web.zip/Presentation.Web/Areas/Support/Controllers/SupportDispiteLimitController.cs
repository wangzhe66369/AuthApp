﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.DomainObjects.View;
using MvcContrib.UI.Grid;
using RWIS.Presentation.Web.Areas.Support.ViewModels;

using RWIS.Domain.DomainObjects;
using NET01.CoreFramework;
using RWIS.Domain.DomainObjects.View.SupportDispiteLimitCondition;
using MvcContrib.Sorting;

namespace RWIS.Presentation.Web.Areas.Support.Controllers
{
    public class SupportDispiteLimitController : Controller
    {
        //
        // GET: /Support/SupportDispiteLimit/

         ISupportDispiteLimitRepository _SupportDispiteLimitRepository;
         INuclearElementRepository _NuclearElementRepository;
         IBasicObjectRepository _BasicObjectRepository;
         public SupportDispiteLimitController(ISupportDispiteLimitRepository _SupportDispiteLimitRepository, 
             INuclearElementRepository _NuclearElementRepository,
              IBasicObjectRepository _BasicObjectRepository
             )
        {
            this._SupportDispiteLimitRepository = _SupportDispiteLimitRepository;
            this._NuclearElementRepository = _NuclearElementRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
           
        }
        /// <summary>
        /// 初始页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            SupportDispiteLimitVM vm = new SupportDispiteLimitVM();
            //vm.OperationList = CommonHelper.GetOperationList("Surface_Deal");//权限控制
            //加载指标核素、加载DTM核素
            vm.QuotaElementList = new List<SelectListItem>();
            IQueryable<NuclearElement> quotaElementQuery = _NuclearElementRepository.GetAll().AsQueryable().Where(d => d.Status == "1").OrderBy(c=>c.ElementName);
            List<NuclearElement> quotaElementList = new List<NuclearElement>();
            if (quotaElementQuery.Count() > 0)
            {
                quotaElementList = quotaElementQuery.ToList();
            }
            foreach (var item in quotaElementList)
            {
                vm.QuotaElementList.Add(new SelectListItem { Text = item.ElementName, Value = item.ElementId });
            }

            //处置场
            vm.DispitePositionList = new List<SelectListItem>();
            IQueryable<BasicObject> dispitePositionQuery = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> dispitePositionList = new List<BasicObject>();
            if (dispitePositionQuery.Count() > 0)
            {
                dispitePositionList = dispitePositionQuery.ToList();
            }
            foreach (var item in dispitePositionList)
            {
                vm.DispitePositionList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            return View(vm);
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveSupport(SupportDispiteLimitVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                model.SupportDispiteLimit.Status = "0";
                model.SupportDispiteLimit.LimitId = Guid.NewGuid().ToString();
                model.SupportDispiteLimit.CreateUserNo = AppContext.CurrentUser.UserId;
                model.SupportDispiteLimit.CreateUserName = AppContext.CurrentUser.UserName;
                model.SupportDispiteLimit.CreateDate = DateTime.Now;
                model.SupportDispiteLimit.Stationcode = AppContext.CurrentUser.ProjectCode;

                this._SupportDispiteLimitRepository.Create(model.SupportDispiteLimit);
                this._SupportDispiteLimitRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        ///确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult ConfirmSupport(SupportDispiteLimitVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                model.SupportDispiteLimit = _SupportDispiteLimitRepository.Get(model.SupportDispiteLimit.LimitId);
                UpdateModel(model);
                model.SupportDispiteLimit.Status = "1";
                model.SupportDispiteLimit.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.SupportDispiteLimit.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.SupportDispiteLimit.ConfirmDate = DateTime.Now;

                this._SupportDispiteLimitRepository.Update(model.SupportDispiteLimit);
                this._SupportDispiteLimitRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {

                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._SupportDispiteLimitRepository.DeleteById(idVal);
                    }
                    this._SupportDispiteLimitRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }

       
        }


        /// <summary>
        /// 查询可测核素库列表
        /// </summary>
        /// <param name="keyWord">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetMeterNuclearElementList(SupportDispiteLimitCondition condition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<SupportDispiteLimitView> data = this._SupportDispiteLimitRepository.QueryList(condition).OrderBy("CreateDate", SortDirection.Descending);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<SupportDispiteLimitView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.LimitId,
                    List = new List<object>() {
                    d.LimitId,
                    d.ElementId,
                    d.DispitePositionId,
                    d.ElementName,
                    d.DispitePositionName,
                    d.DoseContribute,
                    d.SpecificActivity,
                    d.Status
                    
                    }
                    });
            });
           
           
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }


    }
}
