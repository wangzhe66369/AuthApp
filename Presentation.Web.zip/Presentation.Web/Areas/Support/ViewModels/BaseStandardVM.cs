﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects.View;

namespace RWIS.Presentation.Web.Areas.Support.ViewModels
{
    public class BaseStandardVM
    {
        /// <summary>
        /// 核素实体
        /// </summary>
        public NuclearElement NuclearElement { get; set; }

        /// <summary>
        /// 比例因子实体
        /// </summary>
        public Scalefactor Scalefactor { get;set; }

        /// <summary>
        /// 核素类型 
        /// </summary>
        public List<SelectListItem> ElementTypeList { get; set; }

        /// <summary>
        /// 比例因子类型 
        /// </summary>
        public List<SelectListItem> FactorTypeList { get; set; }

        /// <summary>
        /// 废物类型 
        /// </summary>
        public List<SelectListItem> NuClearTypeList { get; set; }

        /// <summary>
        /// 指标核素
        /// </summary>
        public List<SelectListItem> QuotaElementList { get; set; }

        /// <summary>
        /// DTM核素
        /// </summary>
        public List<SelectListItem> DTMElementList { get; set; }

        /// <summary>
        /// 是否可测量
        /// </summary>
        public List<SelectListItem> ElementClassList { get; set; }

        /// <summary>
        /// 状态 
        /// </summary>
        public List<SelectListItem> StatusList { get; set; }

        /// <summary>
        /// 废物类型名称 
        /// </summary>
        public string  WasteTypeName { get; set; }

        /// <summary>
        /// 指标核素名称 
        /// </summary>
        public string QuotaElementName { get; set; }

        /// <summary>
        /// DTM核素名称 
        /// </summary>
        public string DtmElementName { get; set; }

        /// <summary>
        /// 核素名称 
        /// </summary>
        public string NewElementName { get; set; }

        //当前页面所有操作
        public string OperationList { get; set; }
    }
}