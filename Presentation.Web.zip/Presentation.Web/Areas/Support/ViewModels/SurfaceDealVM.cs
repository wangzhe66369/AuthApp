﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.Support.ViewModels
{
    public class SurfaceDealVM
    {


        /// <summary>
        /// 近地表处置规定 实体
        /// </summary>
        public SupportSurfaceDeal SupportSurfaceDeal { get; set; }

        /// <summary>
        /// 核素实体
        /// </summary>
        public NuclearElement NuclearElement { get; set; }

        /// <summary>
        /// 核素名 
        /// </summary>
        public List<SelectListItem> ElementNameList { get; set; }

        /// <summary>
        /// 指标核素
        /// </summary>
        public List<SelectListItem> QuotaElementList { get; set; }

        /// <summary>
        /// 权限验证
        /// </summary>
        public string OperationList { get; set; }
    }
}
