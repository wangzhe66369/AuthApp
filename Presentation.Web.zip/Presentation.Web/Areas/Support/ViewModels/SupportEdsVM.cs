﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects.View;

namespace RWIS.Presentation.Web.Areas.Support.ViewModels
{
     public class SupportEdsVM
    {
        /// <summary>
        /// 活度计算实体
        /// </summary>
         public SupportEds SupportEds { get; set; }

         /// <summary>
         /// 标准谱库
         /// </summary>
         public SupportEdsDetail SupportEdsDetail { get; set; }

         /// <summary>
         /// 核素库
         /// </summary>
         public NuclearElement NuclearElement { get; set; }

         /// <summary>
         /// 废物类型 
         /// </summary>
         public List<SelectListItem> WasteTypeIdList { get; set; }

         /// <summary>
         /// 谱类型 
         /// </summary>
         public List<SelectListItem> EdsTypeList { get; set; }

         /// <summary>
         /// 废物货包类型 
         /// </summary>
         public List<SelectListItem> WasteTypeBagList { get; set; }

         /// <summary>
         /// 核素名 
         /// </summary>
         public List<SelectListItem> ElementNameList { get; set; }
         
         /// <summary>
         /// 核素库类型
         /// </summary>
         public List<SelectListItem> ElementTypeList { get; set; }

         /// <summary>
         /// 页面寄存器
         /// </summary>
         public string SupportEdsDetails { get; set; }

         /// <summary>
         /// 源项类型名称
         /// </summary>
         public string WasteTypeName { get; set; }

         /// <summary>
         /// 半衰期
         /// </summary>
         public Nullable<decimal> HalfLife { get; set; }

         /// <summary>
         /// 比例值
         /// </summary>
         public Nullable<double> PercentValue { get; set; }

         /// <summary>
         /// 核素名称
         /// </summary>
         public string ElementName { get; set; }
         //当前页面所有操作
         public string OperationList { get; set; }
    }
}