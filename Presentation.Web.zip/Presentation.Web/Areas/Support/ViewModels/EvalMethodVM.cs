﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.Support.ViewModels
{
    public class EvalMethodVM
    {
        /// <summary>
        /// 评估方法实体
        /// </summary>
        public EvalMethod EvalMethod { get; set; }

        /// <summary>
        /// 水泥桶函数转换方法实体
        /// </summary>
        public CementTransfer CementTransfer { get; set; }

        /// <summary>
        /// 金属桶函数转换方法实体
        /// </summary>
        public MetelTransfer MetelTransfer { get; set; }

        /// <summary>
        /// 类型 
        /// </summary>
        public List<SelectListItem> EvalMethodTypeList { get; set; }

        /// <summary>
        /// 核素名 
        /// </summary>
        public List<SelectListItem> ElementNameList { get; set; }

        /// <summary>
        /// 水泥桶 
        /// </summary>
        public List<SelectListItem> BucketTypeList { get; set; }


    }
}
