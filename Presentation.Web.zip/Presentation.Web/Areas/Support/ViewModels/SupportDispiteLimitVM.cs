﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.Support.ViewModels
{
    public class SupportDispiteLimitVM
    {
        /// <summary>
        /// 处置场限制
        /// </summary>
        public SupportDispiteLimit SupportDispiteLimit { get; set; }


        /// <summary>
        /// 指标核素
        /// </summary>
        public List<SelectListItem> QuotaElementList { get; set; }

        /// <summary>
        /// 处置场
        /// </summary>
        public List<SelectListItem> DispitePositionList { get; set; }
    }
}