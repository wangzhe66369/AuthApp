﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   WasteUnitBuilder.cs
 *   描    述   ：   废物产生单位查询
 *   创 建 者   ：   PXMWSWG[苏武刚]
 *   创建日期   ：   2016-10-15 
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *    2016-10-15             1.0.0.0    苏武刚       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Practices.ServiceLocation;

using RWIS.Presentation.Web.Areas.SystemManage.ViewModels;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.SystemManage.ViewModelBuilder
{
    public class WasteUnitBuilder
    {
        /// <summary>
        /// 根据查询条件得到废物产生单位信息
        /// </summary>
        /// <param name="jqCondition">查询条件</param>
        /// <returns></returns>
        public static IQueryable<BasicWasteUnitVM> BuilderWasteUnitForSeach(BasicWasteUnitCondition jqCondition)
        {
            IBasicIndustryRepository _basicIndustryRepository = ServiceLocator.Current.GetInstance<IBasicIndustryRepository>();
            IBasicWasteUnitRepository _basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
            IQueryable<BasicIndustry> iqueryBasicIndustry = _basicIndustryRepository.GetAll().AsQueryable();
            IQueryable<BasicWasteUnit> iqueryBasicWasteUnit = _basicWasteUnitRepository.GetAll().AsQueryable();
            var query = from w in iqueryBasicWasteUnit
                        join b in iqueryBasicIndustry on w.IndustryId equals b.IndustryId into bEmpt
                        from b in bEmpt.DefaultIfEmpty()
                        select new BasicWasteUnitVM { 
                        BasicWasteUnit=w,
                        BasicIndustryName=b.IndustryName,
                        BasicIndustryId=b.IndustryId
                        };
            if (!string.IsNullOrEmpty(jqCondition.WasteUnitCode))
            {
                query = query.Where(c=>c.BasicWasteUnit.UnitCode.ToUpper().Trim().Contains(jqCondition.WasteUnitCode.ToUpper().Trim()));
            }
            if (!string.IsNullOrEmpty(jqCondition.WasteUnitName))
            {
                query = query.Where(c => c.BasicWasteUnit.UnitName.ToUpper().Trim().Contains(jqCondition.WasteUnitName.ToUpper().Trim()));
            }
            if (!string.IsNullOrEmpty(jqCondition.IndustryName))
            {
                query = query.Where(c => c.BasicIndustryName.ToUpper().Trim().Contains(jqCondition.IndustryName.ToUpper().Trim()));
            }
            return query;
        }
    }
}