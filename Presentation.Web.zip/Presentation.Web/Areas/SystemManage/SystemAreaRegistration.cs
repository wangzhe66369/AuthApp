﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.SystemManage
{
    public class BasicAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "SystemManage";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "SystemManage_default",
                "SystemManage/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional },
                 new string[] { "RWIS.Presentation.Web.Areas.SystemManage.Controllers" }
            );
        }
    }
}
