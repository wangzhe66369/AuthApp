﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;


namespace RWIS.Presentation.Web.Areas.SystemManage.ViewModels.BasicObjectViewModels
{
    public class BasicObjectVM
    {
        /// <summary>
        /// 基础数据对象
        /// </summary>
        public BasicObject BasicObject { get; set; }
        /// <summary>
        /// 数据类型
        /// </summary>
        public SelectList Type { get; set; }

        public IQueryable<BasicObject> Resoures { get; set; }

        public string JsonResoures { get; set; }

        /// <summary>
        /// 是否适合多电站
        /// </summary>
        public List<SelectListItem> IsmultiStationList { get; set; }
        public List<SelectListItem> IsmultiStationsList { get; set; }
    }
}