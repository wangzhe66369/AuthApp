﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.SystemManage.ViewModels
{
    public class ProjectVM
    {
        public string ProjectCode { set; get; }
    }
}