﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   BasicWasteUnitVM.cs
 *   描    述   ：   废物产生单位页面显示实体
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-15
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-15             1.0.0.0    PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.SystemManage.ViewModels
{
    public class BasicWasteUnitVM
    {
        public BasicWasteUnit BasicWasteUnit { set; get; }
        public string BasicIndustryName { set; get; }
        public string BasicIndustryId { set; get; }
       
        //行业信息列表
        public List<SelectListItem> BasicIndustryList { get; set; }

        //行业信息列表
        public SelectList IsStartList { get; set; }

        //所属电站信息
        public List<SelectListItem> StationList { get; set; }
    }
}