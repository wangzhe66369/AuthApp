﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   BasicWasteUnitCondition.cs
 *   描    述   ：   废物产生单位检索条件
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-15
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-15             1.0.0.0    PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.SystemManage.ViewModels
{
    public class BasicWasteUnitCondition
    {
        public string WasteUnitCode { set; get; }
        public string WasteUnitName { set; get; }
        public string IndustryName { set; get; }
        public string KeyWord { set; get; }
    }
}