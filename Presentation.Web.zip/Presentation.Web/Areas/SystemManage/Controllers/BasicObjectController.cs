﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Presentation.Web.Core;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using RWIS.Presentation.Web.Areas.SystemManage.ViewModels.BasicObjectViewModels;
using NET01.CoreFramework;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Text;

using RWIS.Infrastructure.Crosscutting;

namespace RWIS.Presentation.Web.Areas.SystemManage.Controllers
{
    public class BasicObjectController : Controller
    {
        IBasicObjectRepository repository;

        public BasicObjectController(IBasicObjectRepository repository)
        {
            this.repository = repository;
        }
        //
        // GET: /SystemManage/PsmObject/
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "基础数据管理")]
        public ActionResult Index()
        {
            var vm = new BasicObjectVM();

            //加载是否区分多电站
            vm.IsmultiStationList = new List<SelectListItem>();
            vm.IsmultiStationList.Add(new SelectListItem { Text = "是", Value = "1" });
            vm.IsmultiStationList.Add(new SelectListItem { Text = "否", Value = "0" });
        
            StringBuilder sbResult = new StringBuilder();

            IQueryable<BasicObject> resources = repository.GetBasicObjects("", "",AppContext.CurrentUser.ProjectCode).OrderBy(d=>d.Name);
            sbResult.Append("[");
            foreach (var item in resources)
            {
                if (item.ParentUuid == "0000" || item.ParentUuid == "")
                {
                    sbResult.Append("{");
                    sbResult.Append(string.Format("id: '{0}', pId: '{1}', name: '{2}',open: false,drag:false,childOuter:false,code:'{3}',type:'{4}',"
                                                 + "status:'{5}',remark:'{6}',nodeIndex:'{7}',ismultiStation:'{8}'"
                        , item.Uuid, item.ParentUuid, item.Name + "[" + item.Code + "]", item.Code, item.Type,
                        item.Status, item.Remark, item.SortNumber, item.IsmultiStation
                        ));
                    sbResult.Append("},");
                }
                else
                {
                    sbResult.Append("{");
                    sbResult.Append(string.Format("id: '{0}', pId: '{1}', name: '{2}',open: false,childOuter:false,code:'{3}',type:'{4}',"
                                                 + "status:'{5}',remark:'{6}',nodeIndex:'{7}',ismultiStation:'{8}'"
                        , item.Uuid, item.ParentUuid, item.Name + "[" + item.Code + "]", item.Code, item.Type,
                        item.Status, item.Remark, item.SortNumber, item.IsmultiStation
                        ));
                    sbResult.Append("},");
                } 
            }
            if (sbResult.Length > 2)//判断是否有数据
                sbResult.Remove(sbResult.Length - 1, 1);//去除最后一个,号
            sbResult.Append("]");
            vm.JsonResoures = sbResult.ToString();
            return View(vm);

        }

        //
        // GET: /SystemManage/PsmObject/Delete/5

        [HttpPost]
        public JsonResult Delete(string uuid)
        {
            try
            {
                string[] arrIds;
                if (uuid.Contains(","))
                {
                    arrIds = uuid.Split(',');
                }
                else
                {
                    arrIds = new[] { uuid };
                }
                foreach (string id in arrIds)
                {
                    repository.DeleteById(id);
                }
                repository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败," + ex.Message + "\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="resourceId">资源Id</param>
        /// <param name="parentId">父节点Id</param>
        /// <param name="nodeIndex">同级节点排序号/param>
        /// <param name="resourceCode">资源编码</param>
        /// <param name="resourceName">资源名称</param>
        /// <param name="resourceEnName">资源英文名称</param>
        /// <param name="resourceUrl">资源Url名称</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SaveResource(string uuid, string pId, int nodeIndex, string Code, string Name,
             string Status, string Remark, string  IsmultiStation)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string strResult = string.Empty;
                    BasicObject model = new BasicObject();
                    model.CreateTime = DateTime.Now;
                    model.ParentUuid = pId==""?"0000":pId;
                    model.CreateUserId = AppContext.CurrentUser.UserId;
                    model.CreateUserName = AppContext.CurrentUser.UserName;
                    model.Code = Code;//编号
                    model.Name = Name;//名称
                    model.Type = AppSetting.Instance.SystemCode;//项目编码
                    model.Status = Status;//
                    model.SortNumber = nodeIndex;
                    model.Remark = Remark;//
                    model.IsmultiStation=IsmultiStation;//是否适合多电站的

                    model.StationCode = AppContext.CurrentUser.ProjectCode;
                    //AppContext.CurrentUser.UserId;
                    //AppContext.CurrentUser.UserName;
                    //AppContext.CurrentUser.ProjectCode

                    if (uuid.Length > 10)//修改资源数据
                    {
                        if (repository.CheckCodeExistsByType(uuid, Code, "", ""))
                        {
                            return Json(new { result = false, message = "编码已经存在！", ResourceId = strResult }, JsonRequestBehavior.AllowGet);
                        }
                        model.Uuid = uuid;
                        repository.Update(model);
                        repository.UnitOfWork.Commit();
                        strResult = uuid; //返回修改资源Id
                    }
                    else//新增资源
                    {
                        if (repository.CheckCodeExistsByType("", Code, "", ""))
                        {
                            return Json(new { result = false, message = "编码已经存在！", ResourceId = strResult }, JsonRequestBehavior.AllowGet);
                        }
                        model.Uuid = System.Guid.NewGuid().ToString();//Guid
                        repository.Create(model);
                        repository.UnitOfWork.Commit();
                        strResult = model.Uuid; //返回修改资源Id
                    }
                    return Json(new { result = true, message = "保存成功！", ResourceId = strResult ,Code=Code}, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    throw new ApplicationException("验证错误。前端填写的数据验证不通过!");
                }
            }
            catch (Exception ex)
            {

                return Json(new { result = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 拖动节点
        /// </summary>
        /// <param name="resourceId">资源Id</param>
        /// <param name="parentId">父Id</param>
        /// <param name="nodeIndex">拖拽节点在同级节点中的序号</param>
        /// <returns></returns>
        public JsonResult DragResource(string resourceId, string parentId, int nodeIndex)
        {
            bool bReturn = false;
            try
            {
                if (resourceId.Length > 10)
                {
                    BasicObject resource = repository.Get(resourceId);//获取资源数据

                    resource.ParentUuid =parentId == "" ? "0000" : parentId;

                    resource.SortNumber = nodeIndex;
                    repository.Update(resource);//更新节点父Id
                    //获取同一级别其他资源
                    var levelResource = repository.GetSubobjectsById(parentId)
                        .Where(m => m.Uuid != resourceId)
                        .OrderBy(m => m.SortNumber).ToList();
                    var iCount = levelResource.Count();
                    for (int i = 0; i < iCount; i++)
                    {
                        var r = levelResource.ElementAt(i);
                        if (i >= nodeIndex)//当前节点位置上的排序加一
                        {
                            r.SortNumber = i + 1;
                        }
                        else
                        {
                            r.SortNumber = i;
                        }
                        this.repository.Update(r);//更新节点父Id
                    }
                    this.repository.UnitOfWork.Commit();
                    bReturn = true;
                }
            }
            catch
            {
                bReturn = false;
            }
            return Json(bReturn, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 验证资源编码是否存在
        /// </summary>
        /// <param name="code">资源编码</param>
        /// <param name="oldCode">旧资源编码</param>
        /// <param name="systemId">子系统Id</param>
        /// <returns>资源编码存在则不通过</returns>
        public JsonResult CheckCode(string fixCode,string code, string ResourceId)
        {
            bool isValidate = false;

            if (repository.CheckCodeExistsByType(ResourceId, fixCode+code, "", ""))
            {
                isValidate = false;
            }
            else
            {
                isValidate = true;
            }
            return Json(isValidate, JsonRequestBehavior.AllowGet);
        }
    }
}
