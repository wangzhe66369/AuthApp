﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   BasicIndustryController.cs
 *   描    述   ：   行业代码Controller
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-15
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-15             1.0.0.0    PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;

using CIT.UBA.StatServices;
using NET01.CoreFramework;
using NET01.Presentation.Web.Mvc.JqGrid;

using RWIS.Presentation.Web.Core;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Core.Filter;
using RWIS.Infrastructure.Crosscutting;
using RWIS.Presentation.Web.Areas.SystemManage.ViewModels.BasicObjectViewModels;
using RWIS.Presentation.Web.Areas.SystemManage.ViewModels;

namespace RWIS.Presentation.Web.Areas.SystemManage.Controllers
{
    public class BasicIndustryController : Controller
    {
        IBasicIndustryRepository _basicIndustryRepository;

        public BasicIndustryController(IBasicIndustryRepository _basicIndustryRepository)
        {
            this._basicIndustryRepository = _basicIndustryRepository;
        }

        #region 页面

        /// <summary>
       /// 行业首页
       /// </summary>
       /// <returns></returns>
        public ActionResult Index()
        {
            return View();
        }

        #endregion 页面

        #region 操作

        /// <summary>
        /// 提交或修改行业信息
        /// </summary>
        /// <param name="model">行业实体</param>
        /// <returns></returns>
        public JsonResult CommitIndustry(BasicIndustry model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    model.CreateDate = DateTime.Now;
                    model.CreateUserName = AppContext.CurrentUser.UserName;
                    model.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.Status = "1";
                    if (string.IsNullOrEmpty(model.IndustryId))
                    {
                        //判断行业编码是否重复
                        if(this._basicIndustryRepository.IsRepeatCode(model.IndustryCode))
                        {
                              return Json("{\"result\":false,\"msg\":\"行业编码重复。\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断行业名称是否重复
                        if (this._basicIndustryRepository.IsRepeatName(model.IndustryName))
                        {
                            return Json("{\"result\":false,\"msg\":\"行业名称重复。\"}", JsonRequestBehavior.AllowGet);
                        }
                        model.IndustryId = Guid.NewGuid().ToString();
                        _basicIndustryRepository.Create(model);
                    }
                    else
                    {
                        BasicIndustry basicIndustry = this._basicIndustryRepository.Get(model.IndustryId);
                        //判断行业编码是否重复
                        if (basicIndustry.IndustryCode != model.IndustryCode && this._basicIndustryRepository.IsRepeatCode(model.IndustryCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"行业编码重复。\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断行业名称是否重复
                        if (basicIndustry.IndustryName != model.IndustryName && this._basicIndustryRepository.IsRepeatName(model.IndustryName))
                        {
                            return Json("{\"result\":false,\"msg\":\"行业名称重复。\"}", JsonRequestBehavior.AllowGet);
                        }
                        UpdateModel(basicIndustry);
                        _basicIndustryRepository.Update(basicIndustry);
                    }
                    _basicIndustryRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    throw new ApplicationException("验证错误。前端填写的数据验证不通过!");
                }
            }
            catch(Exception ex)
            {
                return Json(new { result = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

      
        /// <summary>
        /// 确认行业信息
        /// </summary>
        /// <param name="industryId">行业ID</param>
        /// <returns></returns>
        public JsonResult ConfirmIndustry(string industryId)
        {
            BasicIndustry model = this._basicIndustryRepository.Get(industryId);
            if (model != null)
            {
                model.Status = "2";
                this._basicIndustryRepository.Update(model);
                this._basicIndustryRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("{\"result\":true,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 查询所有的行业信息
        /// </summary>
        /// <param name="keyWord">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetIndustryList(BasicWasteUnitCondition basicWasteUnitCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<BasicIndustry> data = this._basicIndustryRepository.QueryList(basicWasteUnitCondition.KeyWord);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<BasicIndustry>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.IndustryId,
                    List = new List<object>() {
                    d.IndustryId,
                    d.IndustryCode,
                    d.IndustryName,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 删除行业信息
        /// </summary>
        /// <param name="industryId">行业ID</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Delete(string industryId)
        {
            try
            {
                this._basicIndustryRepository.DeleteById(industryId);
                this._basicIndustryRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #endregion 操作
    }
}
