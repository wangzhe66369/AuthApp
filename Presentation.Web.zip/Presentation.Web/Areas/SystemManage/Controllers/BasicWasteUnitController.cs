﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   BasicWasteUnitController.cs
 *   描    述   ：   废物产生单位Controller
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-15
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-15             1.0.0.0    PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;

using CIT.UBA.StatServices;
using NET01.CoreFramework;
using NET01.Presentation.Web.Mvc.JqGrid;

using RWIS.Presentation.Web.Core;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Core.Filter;
using RWIS.Infrastructure.Crosscutting;
using RWIS.Presentation.Web.Areas.SystemManage.ViewModels.BasicObjectViewModels;
using RWIS.Presentation.Web.Areas.SystemManage.ViewModels;
using RWIS.Presentation.Web.Areas.SystemManage.ViewModelBuilder;
namespace RWIS.Presentation.Web.Areas.SystemManage.Controllers
{
    public class BasicWasteUnitController : Controller
    {
        IBasicWasteUnitRepository _basicWasteUnitRepository ;
        IBasicIndustryRepository _basicIndustryRepository;
        public BasicWasteUnitController(IBasicWasteUnitRepository _basicWasteUnitRepository, IBasicIndustryRepository _basicIndustryRepository)
        {
            this._basicWasteUnitRepository = _basicWasteUnitRepository;
            this._basicIndustryRepository = _basicIndustryRepository;
        }

        #region 页面

        /// <summary>
       /// 废物产生单位首页
       /// </summary>
       /// <returns></returns>
        public ActionResult Index()
        {
            BasicWasteUnitVM vm = new BasicWasteUnitVM();

            //加载电站信息
            IQueryable<BasicWasteUnit> iqueryWasteUnit = this._basicWasteUnitRepository.GetAll().AsQueryable().Where(c => c.Status == "2" && (c.ParentUnitID == "" || c.ParentUnitID==null));
            vm.StationList = new List<SelectListItem>();
            if (iqueryWasteUnit.Count() > 0)
            {
               
                foreach (var item in iqueryWasteUnit)
                {
                    SelectListItem selectItem = new SelectListItem();
                    selectItem.Text = item.UnitName;
                    selectItem.Value = item.UnitId;
                    vm.StationList.Add(selectItem);
                }
                SelectListItem firstItem = new SelectListItem();
                firstItem.Text ="";
                firstItem.Value ="";
                vm.StationList.Insert(0, firstItem);
            }

            //加载行业信息 
            IQueryable<BasicIndustry> iqueryIndustry = this._basicIndustryRepository.GetAll().Where(c => c.Status == "2").AsQueryable().OrderBy(c => c.IndustryCode);
            if (iqueryIndustry.Count() > 0)
            {
                vm.BasicIndustryList = new List<SelectListItem>();
                foreach (var item in iqueryIndustry)
                {
                    SelectListItem selectItem = new SelectListItem();
                    selectItem.Text = item.IndustryName;
                    selectItem.Value = item.IndustryId;
                    vm.BasicIndustryList.Add(selectItem);
                }
            }

            //加载是否启用列表
            List<SelectListItem> _dealWithResultList = new List<SelectListItem>();
            _dealWithResultList.Add(new SelectListItem { Text = "是", Value = "1" });
            _dealWithResultList.Add(new SelectListItem { Text = "否", Value = "0" });
            vm.IsStartList = new SelectList(_dealWithResultList, "Value", "Text", "checked");
            return View(vm);
        }

        #endregion 页面

        #region 操作

        /// <summary>
        /// 提交或修改废物产生单位
        /// </summary>
        /// <param name="model">废物产生单位</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult CommitWasteUnit(BasicWasteUnitVM vm,FormCollection form)
        {
            try
            {
                //如果是项目
                if (!string.IsNullOrEmpty(vm.BasicWasteUnit.ParentUnitID))
                {
                    BasicWasteUnit model = _basicWasteUnitRepository.Get(vm.BasicWasteUnit.ParentUnitID);
                    if (model != null)
                    {
                        vm.BasicWasteUnit.IndustryId = model.IndustryId;
                    }

                    vm.BasicWasteUnit.IsStart = "0";
                    vm.BasicWasteUnit.UnitLevel = "2";
                }
                else
                {
                    vm.BasicWasteUnit.UnitLevel = "1";
                }

                if (ModelState.IsValid)
                {
                    vm.BasicWasteUnit.CreateDate = DateTime.Now;
                    vm.BasicWasteUnit.CreateUserName = AppContext.CurrentUser.UserName;
                    vm.BasicWasteUnit.CreateUserNo = AppContext.CurrentUser.UserId;
                    vm.BasicWasteUnit.Status = "1";
                    if (string.IsNullOrEmpty(vm.BasicWasteUnit.UnitId))
                    {
                       
                        //判断废物产生单位编码是否重复
                        if (this._basicIndustryRepository.IsRepeatCode(vm.BasicWasteUnit.UnitCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"废物产生单位编码重复。\"}", JsonRequestBehavior.AllowGet);
                        }

                        vm.BasicWasteUnit.UnitId = Guid.NewGuid().ToString();
                        vm.BasicWasteUnit.Path = !string.IsNullOrEmpty(vm.BasicWasteUnit.ParentUnitID) == true ? vm.BasicWasteUnit.ParentUnitID + "," + vm.BasicWasteUnit.UnitId : vm.BasicWasteUnit.UnitId;
                        _basicWasteUnitRepository.Create(vm.BasicWasteUnit);
                    }
                    else
                    {
                        BasicWasteUnit basicWasteUnit = this._basicWasteUnitRepository.Get(vm.BasicWasteUnit.UnitId);
                        //判断废物产生单位编码是否重复
                        if (basicWasteUnit.UnitCode != vm.BasicWasteUnit.UnitCode && this._basicWasteUnitRepository.IsRepeatCode(vm.BasicWasteUnit.UnitCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"废物产生单位编码重复。\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断废物产生单位名称是否重复
                        //if (basicWasteUnit.UnitName != vm.BasicWasteUnit.UnitName && this._basicWasteUnitRepository.IsRepeatName(vm.BasicWasteUnit.UnitName))
                        //{
                        //    return Json("{\"result\":false,\"msg\":\"废物产生单位名称重复。\"}", JsonRequestBehavior.AllowGet);
                        //}
                        UpdateModel(basicWasteUnit);
                        basicWasteUnit.SimpleCode = vm.BasicWasteUnit.SimpleCode;
                        basicWasteUnit.UnitCode = vm.BasicWasteUnit.UnitCode;
                        basicWasteUnit.UnitName = vm.BasicWasteUnit.UnitName;
                        basicWasteUnit.IsStart = vm.BasicWasteUnit.IsStart;
                        _basicWasteUnitRepository.Update(basicWasteUnit);
                    }
                    _basicWasteUnitRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    throw new ApplicationException("验证错误。前端填写的数据验证不通过!");
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// 确认废物产生单位信息
        /// </summary>
        /// <param name="wasteUnitId">废物产生单位ID</param>
        /// <returns></returns>
        public JsonResult ConfirmWasteUnit(string wasteUnitId)
        {
            BasicWasteUnit model = this._basicWasteUnitRepository.Get(wasteUnitId);
            if (model != null)
            {
                model.Status = "2";
                this._basicWasteUnitRepository.Update(model);
                this._basicWasteUnitRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("{\"result\":true,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 查询所有的废物产生单位信息
        /// </summary>
        /// <param name="keyWord">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetWasteUnitList(BasicWasteUnitCondition condition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<BasicWasteUnitVM> data = WasteUnitBuilder.BuilderWasteUnitForSeach(condition).OrderBy(c=>c.BasicWasteUnit.Path);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<BasicWasteUnitVM>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.BasicWasteUnit.UnitId,
                    List = new List<object>() {
                    d.BasicWasteUnit.UnitId,
                    d.BasicWasteUnit.UnitName,
                     d.BasicWasteUnit.UnitCode,
                    d.BasicIndustryName,
                    d.BasicWasteUnit.Status,
                    d.BasicWasteUnit.SimpleCode,
                    d.BasicWasteUnit.IsStart,
                    d.BasicWasteUnit.ParentUnitID==null?string.Empty: d.BasicWasteUnit.ParentUnitID
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 删除废物所在单位信息
        /// </summary>
        /// <param name="wasteUnitId">废物所在单位ID</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Delete(string wasteUnitId)
        {
            try
            {
                this._basicWasteUnitRepository.DeleteById(wasteUnitId);
                this._basicWasteUnitRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #endregion 操作
    }
}
