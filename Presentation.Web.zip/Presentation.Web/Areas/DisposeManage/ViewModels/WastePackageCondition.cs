﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.DisposeManage.ViewModels
{
    public class WastePackageCondition
    {
        public string WastePackageCode { set; get; }
        public string BucketCode { set; get; }
        public string Status { set; get; }
    }
}