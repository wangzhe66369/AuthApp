﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.DisposeManage.ViewModels
{
    public class DisposeApplyVM
    {
        /// <summary>
        /// 厂房下拉列表
        /// </summary>
        public List<SelectListItem> FactoryList { get; set; }
        /// <summary>
        /// 处置场下拉列表
        /// </summary>
        public List<SelectListItem> DispitePositionList { get; set; }
        /// <summary>
        /// 指定信息
        /// </summary>
        public NuclearProcessApply ApplyModel { get; set; }
        /// <summary>
        /// 明细信息列表
        /// </summary>
        public List<ApplyDetailList> DetailList { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> AttachFiles { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 检索条件
    /// </summary>
    public class ApplyCondition
    {
        /// <summary>
        /// 申报单号
        /// </summary>
        public string ApplyCode { get; set; }

        /// <summary>
        /// 申请人
        /// </summary>
        public string ApplyName { get; set; }

        /// <summary>
        /// 申报日期(起)
        /// </summary>
        public string ApplyStartDate { get; set; }

        /// <summary>
        /// 申报日期(止)
        /// </summary>
        public string ApplyEndDate { get; set; }

        /// <summary>
        /// 暂存位置
        /// </summary>
        public string Position { get; set; }
    }
    public class ApplyList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string ApplyId { get; set; }
        /// <summary>
        /// 申报单号
        /// </summary>
        public string ApplyCode { get; set; }
        /// <summary>
        /// 包总数
        /// </summary>
        public string PackageSum { get; set; }
        /// <summary>
        /// 认定单号
        /// </summary>
        public string FirmCode { get; set; }
        /// <summary>
        /// 暂存位置
        /// </summary>
        public string Position { get; set; }
        /// <summary>
        /// 运输方式
        /// </summary>
        public string TransFlag { get; set; }
        /// <summary>
        /// 申报日期
        /// </summary>
        public string ApplyDate { get; set; }
        /// <summary>
        /// 申报人
        /// </summary>
        public string ApplyName { get; set; }
        /// <summary>
        /// 当前状态
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 相关附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> AttachFiles { get; set; }
        /// <summary>
        /// 附件字段（值为空）
        /// </summary>
        public string Attachment { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
    public class ApplyDetailList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string DetailId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public string Status { get; set; }
    }
}