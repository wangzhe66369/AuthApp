﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.DisposeManage.ViewModels
{
    public class WastePackageVM
    {
        public NuclearWastePackage NuclearWastePackage { set; get; }
        public string BucketCode { set; get; }
        public string WasteType { set; get; }
        public DateTime? ConfirmDate { set; get; }
        public List<SelectListItem> StatusList { set; get; }
    }
}