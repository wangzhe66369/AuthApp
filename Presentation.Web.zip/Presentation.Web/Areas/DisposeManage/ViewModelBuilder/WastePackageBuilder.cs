﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   WastePackageBuilder.cs
 *   描    述   ：   废物货包查询类
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-28 18:45:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-28 18:45:00    1.0.0.0     PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System.Linq;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Areas.DisposeManage.ViewModels;

namespace RWIS.Presentation.Web.Areas.DisposeManage.ViewModelBuilder
{
    public class WastePackageBuilder
    {
        /// <summary>
        /// 得到所有的废物货包信息
        /// </summary>
        /// <returns></returns>
        public static IQueryable<WastePackageVM> GetAllPackage(WastePackageCondition applyCondition)
        {
            INuclearWastePackageRepository _NuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
            INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            var iqueryPackage = _NuclearWastePackageRepository.GetAll().AsQueryable().Where(c=>c.Stationcode==AppContext.CurrentUser.ProjectCode);
            var iqueryBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(c => c.Stationcode == AppContext.CurrentUser.ProjectCode);
            var query = from p in iqueryPackage
                        join b in iqueryBucket on p.BucketId equals b.BucketId
                        select new WastePackageVM
                        {
                            NuclearWastePackage = p,
                            BucketCode = b.BucketCode,
                            WasteType=b.WasteType,
                            ConfirmDate=p.ConfirmDate
                        };
            if (!string.IsNullOrEmpty(applyCondition.WastePackageCode))
            {
                query = query.Where(c => c.NuclearWastePackage.PackageCode.ToUpper().Trim().Contains(applyCondition.WastePackageCode.ToUpper().Trim()));
            }
            if (!string.IsNullOrEmpty(applyCondition.BucketCode))
            {
                query = query.Where(c => c.BucketCode.ToUpper().Trim().Contains(applyCondition.BucketCode.ToUpper().Trim()));
            }
            if (!string.IsNullOrEmpty(applyCondition.Status))
            {
                if (applyCondition.Status == "UNAPPLY")
                    query = query.Where(c => c.NuclearWastePackage.Status == applyCondition.Status || string.IsNullOrEmpty(c.NuclearWastePackage.Status));
                else
                    query = query.Where(c => c.NuclearWastePackage.Status == applyCondition.Status);
            }
            query = query.OrderByDescending(c => c.ConfirmDate);
            return query;
        }
    }
}