﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.DisposeManage
{
    public class DisposeManageAreaRegistion : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "DisposeManage";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "DisposeManage_default",
                "DisposeManage/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}