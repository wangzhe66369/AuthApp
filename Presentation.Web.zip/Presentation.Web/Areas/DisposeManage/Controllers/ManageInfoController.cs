﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.DisposeManage.Controllers
{
    public class ManageInfoController : Controller
    {
        //
        // GET: /DisposeManage/ManageInfo/

        public ActionResult Index()
        {
            return View();
        }

    }
}
