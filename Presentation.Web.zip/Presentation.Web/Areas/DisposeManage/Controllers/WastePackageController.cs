﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   WastePackageController.cs
 *   描    述   ：   废物货包信息Controller
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-28
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-28             1.0.0.0    PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.DisposeManage.ViewModels;
using RWIS.Presentation.Web.Areas.DisposeManage.ViewModelBuilder;

namespace RWIS.Presentation.Web.Areas.DisposeManage.Controllers
{
    public class WastePackageController : Controller
    {
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        public WastePackageController(INuclearWastePackageRepository _NuclearWastePackageRepository)
        {
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
        }

        public ActionResult Index()
        {
            WastePackageVM vm = new WastePackageVM();
            //加载是否启用列表 UNAPPLY:未申请处置  UNCHECKED:未审核 CHECKED:已审核 APPLIED：已申报  RECEPTED：已接收 DEALED:已处置 RETURN:已退回
            List<SelectListItem> statusList = new List<SelectListItem>();
            statusList.Add(new SelectListItem { Text = "请选择", Value = "" });
            statusList.Add(new SelectListItem { Text = "未申请处置", Value = "UNAPPLY" });
            statusList.Add(new SelectListItem { Text = "未审核", Value = "UNCHECKED" });
            statusList.Add(new SelectListItem { Text = "已审核", Value = "CHECKED" });
            statusList.Add(new SelectListItem { Text = "已申报", Value = "APPLIED" });
            statusList.Add(new SelectListItem { Text = "已接收", Value = "RECEPTED" });
            statusList.Add(new SelectListItem { Text = "已处置", Value = "DEALED" });
            statusList.Add(new SelectListItem { Text = "已拒收", Value = "UNRECEPTED" });
            vm.StatusList = statusList;
            return View(vm);
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetPackageList(WastePackageCondition applyCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<WastePackageVM> data = WastePackageBuilder.GetAllPackage(applyCondition);

            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<WastePackageVM>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.NuclearWastePackage.PackageId,
                    List = new List<object>() {
                    d.NuclearWastePackage.PackageCode,
                    d.BucketCode,
                    d.WasteType,
                    d.NuclearWastePackage.Status,
                    string.IsNullOrEmpty( d.NuclearWastePackage.XPosition)?string.Empty:"X="+d.NuclearWastePackage.XPosition+";Y="+d.NuclearWastePackage.YPosition+";Z="+d.NuclearWastePackage.ZPosition
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
    }
}
