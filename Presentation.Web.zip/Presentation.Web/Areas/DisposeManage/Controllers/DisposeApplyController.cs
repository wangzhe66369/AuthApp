﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.DisposeManage.ViewModels;
using RWIS.Presentation.Web.Core.Ftp;
using RWIS.Presentation.Web.Core;
using CIT.UPC.Domain.Repositories;
using CIT.UPC.Domain.DomainObjects;
using Microsoft.Practices.ServiceLocation;
using System.Web.Mvc.Html;
using System.Web;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using System.Configuration;
using NET01.Infrastructure.Authorization;
using CIT.UPC.Authorization.Client;
using RWIS.Presentation.Web.Core.Common;
using System.Data;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModelBuilder;
namespace RWIS.Presentation.Web.Areas.DisposeManage.Controllers
{
    public class DisposeApplyController : Controller
    {
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearProcessApplyRepository _NuclearProcessApplyRepository;
        IDispsiteCheckRepository _DispsiteCheckRepository;
        IDispsiteApproveRepository _DispsiteApproveRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        public DisposeApplyController(INuclearProcessApplyRepository NuclearProcessApplyRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository
            , IDispsiteCheckRepository DispsiteCheckRepository
            , IDispsiteApproveRepository DispsiteApproveRepository
            , INuclearWastePackageRepository _NuclearWastePackageRepository)
        {
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NuclearProcessApplyRepository = NuclearProcessApplyRepository;
            this._DispsiteCheckRepository = DispsiteCheckRepository;
            this._DispsiteApproveRepository = DispsiteApproveRepository;
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "处理申请")]
        public ActionResult Index()
        {
            DisposeApplyVM vm = new DisposeApplyVM();
            vm.OperationList = CommonHelper.GetOperationList("Dispose_Apply");
            vm.FactoryList = new List<SelectListItem>();
            vm.FactoryList.Add(new SelectListItem { Text = "请选择", Value = "0" });
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            return View(vm);
        }

        /// <summary>
        /// 导入浓缩液固化
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        public ActionResult ImportBucketCode(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的电缆数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    {
                        //删除文件
                        if (System.IO.File.Exists(strNewImportPath))
                        {
                            System.IO.File.Delete(strNewImportPath);
                        }
                        jsonResult = JsonResultHelper.JsonResult(false, "数据必须是EXCEL格式!");
                        jsonResult.ContentType = "text/html";
                        return jsonResult;
                    }
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);

                        TableBuilder.ImportSSolidify(ds, strNewImportPath);
                        //if (mes == "NoTrack")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "废物跟踪单号不存在！");
                        //}
                        //if (mes == "NoBucketCode")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "桶号不存在！");
                        //}

                    }
                }

                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }


        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "处理申请明细")]
        public ActionResult Detail()
        {

            string uid = Request["uid"];
            string detailFlag = "add";
            DisposeApplyVM vm = new DisposeApplyVM();
            vm.OperationList = CommonHelper.GetOperationList("Dispose_Apply");
            vm.FactoryList = new List<SelectListItem>();
            vm.DispitePositionList = new List<SelectListItem>();
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> query = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition", AppContext.CurrentUser.ProjectCode);
            if (query != null && query.Count() > 0)
            {
                listBasicObject = query.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.DispitePositionList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            vm.DetailList = new List<ApplyDetailList>();
            vm.ApplyModel = new NuclearProcessApply();
            ViewBag.UserName = AppContext.CurrentUser.UserName;
            ViewBag.UserId = AppContext.CurrentUser.UserId;
            ViewBag.DateTime = DateTime.Now.ToString("yyyy-MM-dd");
            if (!string.IsNullOrEmpty(uid))
            {
                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(uid, "DisposeApply");
                vm.AttachFiles = (List<AttachFile>)listAttachFile;
                var dataList = _NuclearProcessApplyRepository.GetDetailListByApplyId(uid).ToList();
                if (dataList != null && dataList.Count > 0)
                {
                    foreach (NuclearApplyDetail detail in dataList)
                    {
                        ApplyDetailList model = new ApplyDetailList();
                        model.DetailId = detail.ApplyDetailId;
                        if (!string.IsNullOrEmpty(detail.BucketId))
                        {
                            var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId);
                            if (bucketModel == null) continue;
                            model.BucketCode = bucketModel.BucketCode;
                            if (bucketModel.BucketStatus == "EMPTY" || string.IsNullOrEmpty(bucketModel.BucketStatus))
                                model.Status = "空桶";
                            if (bucketModel.BucketStatus == "PREPARE")
                                model.Status = "桶准备";
                            if (bucketModel.BucketStatus == "FILL")
                                model.Status = "填充";
                            if (bucketModel.BucketStatus == "COVER")
                                model.Status = "封盖";
                        }
                        vm.DetailList.Add(model);
                    }
                }
                vm.ApplyModel = _NuclearProcessApplyRepository.GetApplyModelById(uid);
                detailFlag = "edit";
                ViewBag.UserName = vm.ApplyModel.ApplyName;
                ViewBag.UserId = vm.ApplyModel.ApplyNo;
                ViewBag.DateTime = vm.ApplyModel.ApplyDate.HasValue ? Convert.ToDateTime(vm.ApplyModel.ApplyDate.ToString()).ToString("yyyy-MM-dd") : string.Empty;
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            return View(vm);
        }



        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(ApplyCondition applyCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var query = _NuclearProcessApplyRepository.GetApplyQuery().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();

            if (!string.IsNullOrEmpty(applyCondition.ApplyCode))
            {
                query = query.Where(n => n.ApplyCode.ToUpper().Contains(applyCondition.ApplyCode.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(applyCondition.ApplyName))
            {
                query = query.Where(n => n.ApplyName.ToUpper().Contains(applyCondition.ApplyName.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(applyCondition.Position) && applyCondition.Position != "0")
                query = query.Where(n => n.StoragePositionId == applyCondition.Position).ToList();
            if (!string.IsNullOrEmpty(applyCondition.ApplyStartDate))
            {
                DateTime sDate = Convert.ToDateTime(applyCondition.ApplyStartDate);
                query = query.Where(n => n.CreateDate >= sDate).ToList();
            }
            if (!string.IsNullOrEmpty(applyCondition.ApplyEndDate))
            {
                DateTime sDate = Convert.ToDateTime(applyCondition.ApplyEndDate).AddDays(1);
                query = query.Where(n => n.CreateDate < sDate).ToList();
            }
            //query = query.OrderByDescending(n => n.CreateDate).ToList();
            List<ApplyList> pList = new List<ApplyList>();
            if (query != null)
            {
                for (int i = 0; i < query.Count; i++)
                {
                    ApplyList apply = new ApplyList();
                    apply.ApplyId = query[i].ProcessApplyId;
                    apply.ApplyCode = query[i].ApplyCode;
                    apply.PackageSum = query[i].PackageCount.ToString();
                    string queryID = query[i].ProcessApplyId;
                    var modelCheck = _DispsiteCheckRepository.GetDispsiteCheckQuery().Where(d => d.ProcessApplyId == queryID).FirstOrDefault();
                    if (modelCheck != null)
                    {
                        var modelApprove = _DispsiteApproveRepository.GetDispsiteApproveQuery().Where(d => d.ChekcId == modelCheck.CheckId).FirstOrDefault();
                        if (modelApprove != null)
                        {
                            apply.FirmCode = modelApprove.IdentityCode;
                        }
                    }

                    var basicModel = _BasicObjectRepository.GetBasicById(query[i].StoragePositionId);
                    if (basicModel != null)
                        apply.Position = basicModel.Name;
                    if (query[i].TransFlag == "Self")
                        apply.TransFlag = "自行";
                    if (query[i].TransFlag == "Delegate")
                        apply.TransFlag = "委托";
                    if (query[i].ApplyDate != null)
                        apply.ApplyDate = Convert.ToDateTime(query[i].ApplyDate.ToString()).ToShortDateString();
                    apply.ApplyName = query[i].ApplyName;
                    apply.Status = query[i].Status;
                    //IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                    //IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(apply.ApplyId, "DisposeApply");
                    //apply.AttachFiles = (List<AttachFile>)listAttachFile;
                    apply.Attachment = string.Empty;
                    apply.CreateDate = query[i].CreateDate;
                    pList.Add(apply);
                }
            }
            pList = pList.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<ApplyList> data = pList.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<ApplyList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ApplyId,
                    List = new List<object>() {
                    d.ApplyId,
                    d.ApplyCode,
                    d.PackageSum,
                    d.FirmCode,
                    d.Position,
                    d.TransFlag,
                    d.ApplyDate,
                    d.ApplyName,
                    d.Status,
                    d.AttachFiles
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "处理申请添加")]
        public ActionResult AddApply(DisposeApplyVM model, FormCollection formCollection)
        {
            try
            {
                NuclearProcessApply apply = new NuclearProcessApply();
                apply = model.ApplyModel;
                apply.ProcessApplyId = Guid.NewGuid().ToString();
                apply.CreateUserNo = AppContext.CurrentUser.UserId;
                apply.CreateUserName = AppContext.CurrentUser.UserName;
                apply.CreateDate = DateTime.Now;
                apply.Status = Request.Form["submitType"];
                apply.Stationcode = AppContext.CurrentUser.ProjectCode;
                apply.IsViewAttach = "0";

                #region"添加明细"

                List<NuclearApplyDetail> detailList = new List<NuclearApplyDetail>();
                string[] arrayBucketCode = null;
                string strBucketCode = Request.Form["hidBucketCode"];
                int packageNum = 0;
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearApplyDetail detail = new NuclearApplyDetail();
                        detail.ApplyDetailId = Guid.NewGuid().ToString();
                        detail.ProcessApplyId = apply.ProcessApplyId;
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.BucketId == detail.BucketId).FirstOrDefault();
                        if (nuclearWastePackage != null)
                        {
                            detail.PackageId = nuclearWastePackage.PackageId;
                        }
                        
                        detailList.Add(detail);
                        packageNum++;
                    }
                }
                apply.PackageCount = packageNum;
                #endregion

                this.SaveAttachFile(apply.ProcessApplyId, "UploadApply", formCollection);
                if (apply.Status == "2")
                {
                    apply.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    apply.ConfirmUserName = AppContext.CurrentUser.UserName;
                    apply.ConfirmDate = DateTime.Now;

                    CIT.UPC.Authorization.Client.IAuthorization iAuthorization = AuthorizationFactory.Create();
                    AuthUser[] arrAhthUserCreate = { };
                    AuthUser[] arrAhthUserConfirm = { };
                    arrAhthUserCreate = iAuthorization.GetUsersInRoleReturnObject("RWIS_DISPITE_INPUT", AppContext.CurrentUser.ProjectCode);
                    arrAhthUserConfirm = iAuthorization.GetUsersInRoleReturnObject("RWIS_DISPITE_CONFIRM", AppContext.CurrentUser.ProjectCode);

                    string copyUsers = string.Empty;
                    string recieveUser = string.Empty;

                    if (arrAhthUserCreate != null && arrAhthUserCreate.Length > 0)
                    {
                        for (int t = 0; t < arrAhthUserCreate.Length; t++)
                        {
                            recieveUser += arrAhthUserCreate[t].UserNo + ",";
                        }
                        recieveUser = recieveUser.TrimEnd(new char[] { ',' });
                    }
                    if (arrAhthUserConfirm != null && arrAhthUserConfirm.Length > 0)
                    {
                        for (int t = 0; t < arrAhthUserConfirm.Length; t++)
                        {
                            copyUsers += arrAhthUserConfirm[t].UserNo + ",";
                        }
                        copyUsers = copyUsers.TrimEnd(new char[] { ',' });
                    }

                    NET01.CoreFramework.Mail.ISmtpClient smtpClent = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<NET01.CoreFramework.Mail.ISmtpClient>();
                    var mailService = new RWIS.Application.Implementation.MailService(smtpClent);
                    string sendTitle = string.Format("处理申请确认提醒");
                    string systemAddress = ConfigurationManager.AppSettings["SystemAddress"];
                    string sendContent = "<div style='font-size:14px; line-height:25px;'>您好：<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + model.ApplyModel.ConfirmUserName + "[" + model.ApplyModel.CreateUserNo + "]在" + DateTime.Now + "发起了废物货包处置申请，申请单号是<span style='font-size:14px;color:#2248DD'>" + model.ApplyModel.ApplyCode + "</span>，请点击<a style='text-decoration:underline; color:blue;' href=" + systemAddress + ">废物货包审查</a>进入系统审查，谢谢！";
                    mailService.SendMailService(recieveUser, copyUsers, sendTitle, sendContent);
                   
                }
                foreach (var item in detailList)
                {
                    NuclearWastePackage nuclearWastePackage = this._NuclearWastePackageRepository.GetPackageByBucketId(item.BucketId);
                    if (nuclearWastePackage != null)
                    {
                        nuclearWastePackage.Status = "UNCHECKED";
                        this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                    }
                }
                if (_NuclearProcessApplyRepository.AddApply(apply, detailList))
                {
                    _NuclearProcessApplyRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "处理申请修改及确认")]
        public ActionResult UpdateApply(DisposeApplyVM model, FormCollection formCollection)
        {
            try
            {
                model.ApplyModel.Status = Request.Form["submitType"];

                #region"添加明细"

                List<NuclearApplyDetail> detailList = new List<NuclearApplyDetail>();
                string[] arrayBucketCode = null;
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ", "");
                int packageNum = 0;
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearApplyDetail detail = new NuclearApplyDetail();
                        detail.ApplyDetailId = Guid.NewGuid().ToString();
                        detail.ProcessApplyId = model.ApplyModel.ProcessApplyId;
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;

                        NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.BucketId == detail.BucketId).FirstOrDefault();
                        if (nuclearWastePackage != null)
                        {
                            detail.PackageId = nuclearWastePackage.PackageId;
                        }

                        detail.Status = "0";
                        detailList.Add(detail);
                        packageNum++;
                    }
                }
                model.ApplyModel.PackageCount = packageNum;
                #endregion

                this.SaveAttachFile(model.ApplyModel.ProcessApplyId, "UploadApply", formCollection);
                if (model.ApplyModel.Status == "2")
                {
                    model.ApplyModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.ApplyModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.ApplyModel.ConfirmDate = DateTime.Now;

                    CIT.UPC.Authorization.Client.IAuthorization iAuthorization = AuthorizationFactory.Create();
                    AuthUser[] arrAhthUserCreate = { };
                    AuthUser[] arrAhthUserConfirm = { };
                    AuthUser[] arrAhthUserManager = { };
                    arrAhthUserCreate = iAuthorization.GetUsersInRoleReturnObject("RWIS_BL_DISPITE_INPUT", AppContext.CurrentUser.ProjectCode);
                    arrAhthUserConfirm = iAuthorization.GetUsersInRoleReturnObject("RWIS_BL_DISPITE_CONFIRM", AppContext.CurrentUser.ProjectCode);
                    arrAhthUserManager = iAuthorization.GetUsersInRoleReturnObject("RWIS_BL_IDENTITY_MANAGER", AppContext.CurrentUser.ProjectCode);

                    string copyUsers = string.Empty;
                    string recieveUser = string.Empty;

                    if (arrAhthUserCreate != null && arrAhthUserCreate.Length > 0)
                    {
                        for (int t = 0; t < arrAhthUserCreate.Length; t++)
                        {
                            recieveUser += arrAhthUserCreate[t].UserNo + ",";
                        }
                        recieveUser = recieveUser.TrimEnd(new char[] { ',' });
                    }
                    if (arrAhthUserConfirm != null && arrAhthUserConfirm.Length > 0)
                    {
                        for (int t = 0; t < arrAhthUserConfirm.Length; t++)
                        {
                            copyUsers += arrAhthUserConfirm[t].UserNo + ",";
                        }
                        copyUsers = copyUsers.TrimEnd(new char[] { ',' });
                    }
                    if (arrAhthUserManager != null && arrAhthUserManager.Length > 0)
                    {
                        for (int t = 0; t < arrAhthUserManager.Length; t++)
                        {
                            copyUsers += arrAhthUserManager[t].UserNo + ",";
                        }
                        copyUsers = copyUsers.TrimEnd(new char[] { ',' });
                    }

                    NET01.CoreFramework.Mail.ISmtpClient smtpClent = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<NET01.CoreFramework.Mail.ISmtpClient>();
                    var mailService = new RWIS.Application.Implementation.MailService(smtpClent);
                    string sendTitle = string.Format("处理申请确认提醒");
                    string systemAddress = ConfigurationManager.AppSettings["SystemAddress"];
                    string sendContent = "<div style='font-size:14px; line-height:25px;'>您好：<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + model.ApplyModel.ConfirmUserName + "[" + model.ApplyModel.CreateUserNo + "]在" + DateTime.Now + "发起了废物货包处置申请，申请单号是<span style='font-size:14px;color:#2248DD'>" + model.ApplyModel.ApplyCode + "</span>，请点击<a style='text-decoration:underline; color:blue;' href=" + systemAddress + ">废物货包审查</a>进入系统审查，谢谢！";
                    mailService.SendMailService(recieveUser, copyUsers, sendTitle, sendContent);
                   
                }

                foreach (var item in detailList)
                {
                    NuclearWastePackage nuclearWastePackage = this._NuclearWastePackageRepository.GetPackageByBucketId(item.BucketId);
                    if (nuclearWastePackage != null)
                    {
                        nuclearWastePackage.Status = "UNCHECKED";
                        this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                    }
                }
                if (_NuclearProcessApplyRepository.UpdateApply(model.ApplyModel, detailList))
                {
                    _NuclearProcessApplyRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "处理申请删除")]
        public ActionResult DeleteApply()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearProcessApplyRepository.DeleteApply(id))
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmApply(DisposeApplyVM model, FormCollection formCollection)
        {
            try
            {
                NuclearProcessApply apply = new NuclearProcessApply();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    apply = _NuclearProcessApplyRepository.GetApplyModelById(uid);
                else
                    apply = _NuclearProcessApplyRepository.GetApplyModelById(model.ApplyModel.ProcessApplyId);
                apply.Status = "2";
                apply.ConfirmUserNo = AppContext.CurrentUser.UserId;
                apply.ConfirmUserName = AppContext.CurrentUser.UserName;
                apply.ConfirmDate = DateTime.Now;

                if (_NuclearProcessApplyRepository.UpdateApply(apply, null))
                {
                    _NuclearProcessApplyRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 检查桶号是否可用
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckBucketCode()
        {
            string bucketCode = Request["code"];
            bool bucketCheck = _NuclearBucketRepository.IsExistPackage(bucketCode, AppContext.CurrentUser.ProjectCode);
            if (!bucketCheck)
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶还未生成废物货包。\"}", JsonRequestBehavior.AllowGet);
            }
            else
            {
                string bucketStatus = string.Empty;
                var modelBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.BucketCode == bucketCode && n.Stationcode == AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                if (modelBucket != null)
                {
                    if (modelBucket.BucketStatus == "EMPTY" || string.IsNullOrEmpty(modelBucket.BucketStatus))
                        bucketStatus = "空桶";
                    if (modelBucket.BucketStatus == "PREPARE")
                        bucketStatus = "桶准备";
                    if (modelBucket.BucketStatus == "FILL")
                        bucketStatus = "填充";
                    if (modelBucket.BucketStatus == "COVER")
                        bucketStatus = "封盖";
                }

                return Json("{\"result\":true,\"msg\":\"" + bucketStatus + "\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            var query = from b in _NuclearBucketRepository.GetAll().AsQueryable()
                        join p in _NuclearWastePackageRepository.GetAll().AsQueryable()
                        on b.BucketId equals p.BucketId
                        where b.Stationcode.ToUpper().Trim() == stationCode.Trim().ToUpper()
                        && (b.IsOutSend == "0" || b.IsOutSend == null) && (p.Status == "" || p.Status == null) && p.Status.ToUpper().Trim() != "UNPASSINSPECT"
                        select b;
            query = query.Where(c => c.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()));
            List<NuclearBucket> list = new List<NuclearBucket>();
            if (query.Count() > 0)
            {
                list = query.ToList();
            }
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 更新附件查看状态
        /// </summary>
        /// <returns></returns>
        public ActionResult UpdateAttachStatus()
        {
            try
            {
                string id = Request["id"];
                var model = _NuclearProcessApplyRepository.GetApplyModelById(id);
                model.IsViewAttach = "1";
                if (_NuclearProcessApplyRepository.UpdateApply(model, null))
                {
                    _NuclearProcessApplyRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 根据主键ID获取指定的附件
        /// </summary>
        /// <returns></returns>
        public ActionResult GetAttachById()
        {
            string id = Request["id"];
            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "DispsiteApprove");
            var attachList = (List<AttachFile>)listAttachFile;
            if (attachList != null)
            {
                CIT.UPC.Presentation.Web.ViewModels.Common.UploadFileListVM vm = new CIT.UPC.Presentation.Web.ViewModels.Common.UploadFileListVM();
                vm.FileList = attachList;
                vm.EnableDownLoad = true;
                vm.EnableDelete = false;
                System.Text.StringBuilder str = new System.Text.StringBuilder();
                str.Append("<table class='swfuploadfileListTable' cellpadding='0' cellspacing='0' border='0' style='width:100%;' ><thhead><tr><th style='text-align: center;'>文件名</th><th style='text-align: center;'>文件大小(k)</th><th style='width:60px; text-align: center;'>操作</th></tr></thhead>");
                string opHtml;
                string downloadurl = Url.Action("DownFile", "Ftp", new { Area = "Basic" }) + "/?fileId={0}&fileName={1}&businessType={2}";
                foreach (var f in attachList)
                {
                    string dlurl = string.Format(downloadurl, f.FileId, f.FileName, f.BusinessType);
                    if (vm.EnableDelete)
                    {
                        opHtml = "<td><a href='javascript:void(0)' onclick='deletefile('" + f.FileId + "','" + f.FileName + "',this)'>删除</a>&nbsp;<a href='" + dlurl + "'>下载</a></td>";
                    }
                    else
                    {
                        opHtml = "<td style='text-align: center;'><a href='" + dlurl + "'>下载</a></td>";
                    }
                    str.Append("<tr><td style='text-align: center;'>" + f.FileName + "</td><td style='text-align: center;'>" + f.FileLength + "</td>" + opHtml + "</tr>");
                }
                str.Append("</table>");
                return Json("{\"result\":true,\"msg\":\"" + str.ToString() + "\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 附件
        /// </summary>
        /// <param name="formCollection"></param>
        /// <returns></returns>

        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], "DisposeApply");
            }
            return null;
        }
        /// <summary>
        /// 下载文件
        /// 
        /// </summary>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }
    }
}

