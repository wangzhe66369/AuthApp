﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   ElementAnalyseVM.cs
 *   描    述   ：   核素分析单明细实体
 *   创 建 者   ：   PXMWSWG[苏武刚]
 *   创建日期   ：   2016-10-2 
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-2              1.0.0.0    苏武刚       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModels
{
    public class ElementAnalyseVM
    {
        /// <summary>
        /// 分析单ID
        /// </summary>
        public string AnalyseId { get; set; }

        /// <summary>
        /// 样品ID
        /// </summary>
        public string SampleId { get; set; }

        /// <summary>
        /// 能谱序号
        /// </summary>
        public string EDSCode { get; set; }

        /// <summary>
        /// 分析日期
        /// </summary>
        public Nullable<System.DateTime> AnalyseDate { get; set; }

        /// <summary>
        /// 分析单位
        /// </summary>
        public string AnalyseUnit { get; set; }

        /// <summary>
        /// 样品编号
        /// </summary>
        public string SampleCode { get; set; }

        /// <summary>
        /// 取样日期
        /// </summary>
        public Nullable<System.DateTime> SampleDate { get; set; }

        /// <summary>
        /// 确认日期
        /// </summary>
        public Nullable<System.DateTime> ConfirmDate { get; set; }
    }
}