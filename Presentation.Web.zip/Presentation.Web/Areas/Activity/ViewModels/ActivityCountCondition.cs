﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModels
{
    /// <summary>
    /// 活度计算查询条件
    /// </summary>
    public class ActivityCountCondition
    {
        /// <summary>
        /// 活度计算类型列表
        /// </summary>
        public List<SelectListItem> ActivityCountTypeList { get; set; }

        /// <summary>
        /// 废物类型列表
        /// </summary>
        public List<SelectListItem> WasteTypeList { get; set; }

        /// <summary>
        /// 桶编号
        /// </summary>
        public string BucketCode { get; set; }

        /// <summary>
        /// 桶Id
        /// </summary>
        public string BucketId { get; set; }

        /// <summary>
        /// 能谱序号
        /// </summary>
        public string EdsId { get; set; }

        /// <summary>
        /// 废物类型
        /// </summary>
        public string WasteType { get; set; }

        /// <summary>
        /// 废物类型名称
        /// </summary>
        public string WasteTypeName { get; set; }

        /// <summary>
        /// 活度计算类型
        /// </summary>
        public string ActivityCountType { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public string Status { get; set; }

        public string _operationList = CommonHelper.GetOperationList("ActivityCount");

        /// <summary>
        /// 统一授权
        /// </summary>
        public string OperationList
        {
            get
            {
                return _operationList;
            }
            set
            {
                _operationList = value;
            }
        }

        /// <summary>
        /// 当前页数
        /// </summary>
        public string PageIndex { get; set; }
    }

    public class ActivityCountCode
    {
        /// <summary>
        /// 名字
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// code
        /// </summary>
        public string Code { get; set; }

    }




}
