﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;
using RWIS.Presentation.Web.Core;
namespace RWIS.Presentation.Web.Areas.Activity.ViewModels
{
    public class MfilterVM
    {
        public string EdsCode { get; set; }
        public string BucketCode { get; set; }
        public string FactorType { get; set; }
        /// <summary>
        /// 比例因子类型 
        /// </summary>
        public List<SelectListItem> FactorTypeList { get; set; }

        /// <summary>
        ///400L过滤器活度计算表K 
        /// </summary>
        public ActivityMfilter Activity { get; set; }

        /// <summary>
        ///400L过滤器活度计算表K明细
        /// </summary>
        public ActivityMfilterDetail ActivityDetail { get; set; }


        /// <summary>
        /// 活度计算明细
        /// </summary>
        public List<ActivityMfilterDetail> ActivityDetailList { get; set; }

        /// <summary>
        /// 电站列表
        /// </summary>
        public List<SelectListItem> StationList { get; set; }

        /// <summary>
        /// 废物类型列表
        /// </summary>
        public List<SelectListItem> WasteTypeList { get; set; }

        /// <summary>
        /// 核素名称
        /// </summary>
        public string ElementName { get; set; }

        /// <summary>
        /// 核素分析单ID
        /// </summary>
        public string AnalyseId { get; set; }

        public string _controlName = "Mfilter";

        /// <summary>
        /// 控制器名
        /// </summary>
        public string ControlName
        {
            get
            {
                return _controlName;
            }
            set
            {
                _controlName = value;
            }
        }

        public string _operationList = CommonHelper.GetOperationList("Mfilter");

        /// <summary>
        /// 统一授权
        /// </summary>
        public string OperationList
        {
            get
            {
                return _operationList;
            }
            set
            {
                _operationList = value;
            }
        }

        /// <summary>
        /// 是否是查看模式 0:编辑,1:查看
        /// </summary>
        public string IsVeiw { get; set; }

        /// <summary>
        /// 电站名称
        /// </summary>
        public string StationName { get; set; }

        /// <summary>
        /// 废物类型名称
        /// </summary>
        public string WasteTypeName { get; set; }

        /// <summary>
        /// 当前页数
        /// </summary>
        public string PageIndex { get; set; }

        public string WasteTypeId { get; set; }
    }
}