﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder
{
    public class CementLiquidBuilder
    {
        /// <summary>
        /// 根据提交表单计算出Detail信息
        /// </summary>
        /// <param name="cementLiquidVM"></param>
        public static List<ActivityCliquidDetail> BuilderActivityDetailInfo(CementLiquidVM cementLiquidVM)
        {
            //根据桶编号获取桶ID
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            string bucketId = iNuclearBucketRepository.Get(cementLiquidVM.Activity.BucketId).BucketId;
            //桶Id为空直接返回空
            if (string.IsNullOrEmpty(bucketId))
            {
                return null;
            }

            //能谱信息
            string edsId = cementLiquidVM.Activity.ElemAnalysisId;
            ISupportEdsRepository iSupportEdsRepository = ServiceLocator.Current.GetInstance<ISupportEdsRepository>();

            IQueryable<SupportEds> iquerySupportEds = iSupportEdsRepository.GetAll().AsQueryable().Where(c => c.EdsId == edsId);
            SupportEds supportEds = iSupportEdsRepository.Get(edsId);

            ISupportEdsDetailRepository isupportEdsDetailRepository = ServiceLocator.Current.GetInstance<ISupportEdsDetailRepository>();
            IQueryable<SupportEdsDetail> iquerySupportEdsDetail = isupportEdsDetailRepository.GetAll().AsQueryable();

            //核素信息
            INuclearElementRepository iNuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = iNuclearElementRepository.GetAll().AsQueryable();
            IQueryable<NuclearElement> iqueryCantestElement = iqueryNuclearElement.Where(c => c.ElementClass == "1");
            IQueryable<NuclearElement> iqueryUntestElement = iqueryNuclearElement.Where(c=>c.ElementClass=="0");

            //比例因子信息
            string wasteTypeId = cementLiquidVM.Activity.WasteTypeId;
            string factorType = cementLiquidVM.Activity.FactorType;
            IScalefactorRepository iScalefactorRepository = ServiceLocator.Current.GetInstance<IScalefactorRepository>();
            IQueryable<Scalefactor> iqueryScalefactor = iScalefactorRepository.GetAll().AsQueryable().Where(c => c.WasteTypeId == wasteTypeId && c.FactorType == factorType);
            List<NewActivity> query = new List<NewActivity>();
            if (supportEds.EdsType == "M")
            {
                query = ((from a in iquerySupportEds
                          join d in iquerySupportEdsDetail on a.EdsId equals d.EdsId
                          join b in iqueryCantestElement
                          on d.ElementId equals b.ElementId
                          select new NewActivity
                          {
                              ElementId = b.ElementId,
                              ElementName = b.ElementName,
                              ElementClass = b.ElementClass,
                              HalfLife = b.HalfLife,
                              InitialActivity = d.Activity,
                          }

                                                       ).Union(
                                                       from b in iqueryUntestElement
                                                       select new NewActivity
                                                       {
                                                           ElementId = b.ElementId,
                                                           ElementName = b.ElementName,
                                                           ElementClass = b.ElementClass,
                                                           HalfLife = b.HalfLife,
                                                           InitialActivity = 0,
                                                       }
                                                       )).ToList();
            }
            else {

                query = ((from a in iquerySupportEds
                          join d in iquerySupportEdsDetail on a.EdsId equals d.EdsId
                          join b in iqueryCantestElement
                          on d.ElementId equals b.ElementId
                          select new NewActivity
                          {
                              ElementId = b.ElementId,
                              ElementName = b.ElementName,
                              ElementClass = b.ElementClass,
                              HalfLife = b.HalfLife,
                              InitialActivity = d.PercentValue,
                          }

                                           ).Union(
                                           from b in iqueryUntestElement
                                           select new NewActivity
                                           {
                                               ElementId = b.ElementId,
                                               ElementName = b.ElementName,
                                               ElementClass = b.ElementClass,
                                               HalfLife = b.HalfLife,
                                               InitialActivity = 0,
                                           }
                                           )).ToList();
            }
             

            //桶重量
            decimal bucketWeight = Convert.ToDecimal(cementLiquidVM.Activity.BucketWeight);

            //空桶重
            decimal emptyBucketWeight = Convert.ToDecimal(cementLiquidVM.Activity.EmptyBucketWeight);

            //封盖重
            decimal coverWeight = Convert.ToDecimal(cementLiquidVM.Activity.CoverWeight);

            //初始活度总和
            var sumInitAct = query.Sum(e => e.InitialActivity);

            //推算伽玛核素活度
            decimal gActivity = Convert.ToDecimal(Convert.ToDecimal(sumInitAct) * cementLiquidVM.Activity.LiquidVolime / 1000);

            //常量
            decimal constValue = Convert.ToDecimal(9.8);

            //活度计算明细
            cementLiquidVM.ActivityDetailList = new List<ActivityCliquidDetail>();

            CommonHelper commonHelper = new CommonHelper();

            //添加可测核素信息
            foreach (var item in query)
            {
                if (item.ElementClass == "1")
                {
                    CementLiquidVM vM = new CementLiquidVM();
                    ActivityCliquidDetail bucketDetail = new ActivityCliquidDetail();
                    bucketDetail.ElementId = item.ElementId;
                    bucketDetail.HalfLife = item.HalfLife;

                    //初始活度以及初始活度比例
                    bucketDetail.InitialActivity = Convert.ToDecimal(item.InitialActivity);
                    bucketDetail.InitialActivityRate = Convert.ToDecimal(item.InitialActivity / sumInitAct) * 100;
                    bucketDetail.InitialActivityRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.InitialActivityRate)));

                    //核素能谱
                    bucketDetail.ElementLevel = gActivity * bucketDetail.InitialActivityRate / 100;
                    bucketDetail.ElementLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.ElementLevel)));

                    //内容物资比活度
                    bucketDetail.SpecificActivity = Convert.ToDecimal(bucketDetail.ElementLevel / (bucketWeight - emptyBucketWeight-coverWeight) * constValue);
                    bucketDetail.SpecificActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.SpecificActivity)));

                    cementLiquidVM.ActivityDetailList.Add(bucketDetail);
                }
            }

            //将特殊元素移到元素末尾
            foreach (var item in query)
            {
                if (item.ElementName.Trim().ToUpper().Equals("TSPU241"))
                {
                    query.Remove(item);
                    query.Add(item);
                    break;
                }
            }

            //添加不可测核素信息
            foreach (var item in query)
            {
                if (item.ElementClass == "0")
                {
                    CementLiquidVM vM = new CementLiquidVM();
                    ActivityCliquidDetail detail = new ActivityCliquidDetail();
                    detail.ElementId = item.ElementId;
                    detail.HalfLife = item.HalfLife;

                    //初始活度以及初始活度比例
                    detail.InitialActivity = Convert.ToDecimal(item.InitialActivity);
                    detail.InitialActivityRate = Convert.ToDecimal(item.InitialActivity / sumInitAct) * 100;
                    detail.InitialActivityRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(detail.InitialActivityRate)));

                    //核素能谱
                    string dtmElementId = item.ElementId;
                    Scalefactor scaleFactor = null;
                    var scaleFactorFilter = iqueryScalefactor.Where(c => c.DtmElementId == dtmElementId); //根据不可测的核素ID查找对应的比例因子
                    if (scaleFactorFilter.Count() > 0) //如果存在该核素的比例因子
                    {
                        scaleFactor = scaleFactorFilter.ToList()[0];
                        string quotaElementId = scaleFactor.QuotaElementId;

                        ActivityCliquidDetail model = null;
                        List<ActivityCliquidDetail> list = cementLiquidVM.ActivityDetailList.Where(c => c.ElementId == quotaElementId).ToList(); //根据不可测核素ID的得到指标核素ID，并根据指标核素ID查到其对应的核素能谱
                        if (list.Count > 0) //如果存在指标核素ID查到其对应的核素能谱
                        {
                            model = list[0];
                            detail.ElementLevel = model.ElementLevel * scaleFactor.Scalevalue;
                            detail.ElementLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(detail.ElementLevel)));
                        }
                    }
                    else //如果不存在该核素的比例因子，则该核素的核素能谱为0
                    {
                        detail.ElementLevel = 0;
                        //H3的核素能谱为0.4
                        if (item.ElementName.Trim().ToUpper() == "H3")
                        {
                            detail.ElementLevel = Convert.ToDecimal(0.4);
                        }
                    }

                    //是否燃料破损
                    if (cementLiquidVM.Activity.IsDamage == "0")
                    {
                        if (item.ElementName.ToUpper().Contains("PU239"))
                        {
                            detail.ElementLevel = 0;
                        }
                    }

                    //内容物资比活度
                    detail.SpecificActivity = Convert.ToDecimal(detail.ElementLevel / (bucketWeight - emptyBucketWeight-coverWeight) * constValue);
                    detail.SpecificActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(detail.SpecificActivity)));
                    cementLiquidVM.ActivityDetailList.Add(detail);
                }

            }

           return cementLiquidVM.ActivityDetailList;
        }
    }
}