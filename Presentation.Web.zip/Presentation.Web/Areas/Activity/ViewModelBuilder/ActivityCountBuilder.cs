﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using MvcContrib.Sorting;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder
{
    public class ActivityCountBuilder
    {
        public static IQueryable<ActivityCount> BuilderActivityCountInfo(ActivityCountCondition activityCountCondition)
        {
 
            //活度计算
            IActivityCountViewRepository iActivityCountViewRepository = ServiceLocator.Current.GetInstance<IActivityCountViewRepository>();
            IQueryable<ActivityCountView> activityCountView = iActivityCountViewRepository.GetAll().AsQueryable();

            //桶信息
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IQueryable<NuclearBucket> nuclearBucket = iNuclearBucketRepository.GetAll().AsQueryable();

            IBasicObjectRepository iBasicObjectRepository=ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
             IQueryable<BasicObject> basicObject = iBasicObjectRepository.GetAll().AsQueryable();

            ISupportEdsRepository iSupportEdsRepository=ServiceLocator.Current.GetInstance<ISupportEdsRepository>();
             IQueryable<SupportEds> supportEds = iSupportEdsRepository.GetAll().AsQueryable();

            string stationcode = AppContext.CurrentUser.ProjectCode;

            var query =   from a in activityCountView
                            join s in supportEds on a.ElemAnalysisId equals s.EdsId
                            join b in basicObject on s.WasteTypeId equals b.Uuid
                            join n in nuclearBucket on a.BucketId equals n.BucketId
                            where n.Stationcode == stationcode
                            select new ActivityCount
                            {
                                CalcuId=a.CalcuId,//主键Id
                                ActivityCountType = a.ActivityCountType,//活度计算类型
                                BucketCode = n.BucketCode,//桶号
                                BucketId=n.BucketId,
                                WasteTypeName = b.Name,//废物类型
                                WasteTypeId = b.Uuid,
                                ElemAnalysisId = s.EdsSerialCode,//能普序号
                                Status = a.Status, //确认状态
                                ViewModel=a.ViewModel,//实体名称
                                ConfirmDate=a.ConfirmDate,
                                StationCode=a.StationCode,
                                TransferFun=a.TransferFun
                            };
            //实体中ActivityCountType对应的是活度计算类型名称,ViewModel对应的是实体名称
            if (!string.IsNullOrEmpty(activityCountCondition.ActivityCountType))
            {
                query = query.Where(c => c.ViewModel.Trim().ToUpper() == activityCountCondition.ActivityCountType.Trim().ToUpper());
            }
            if (!string.IsNullOrEmpty(activityCountCondition.WasteType))
            {
                query = query.Where(c => c.WasteTypeId.Trim().ToUpper() == activityCountCondition.WasteType.Trim().ToUpper());
            }
            if (!string.IsNullOrEmpty(activityCountCondition.BucketCode))
            {
                query = query.Where(c => c.BucketCode.Trim().ToUpper().Contains(activityCountCondition.BucketCode.Trim().ToUpper()));
            }
            if (!string.IsNullOrEmpty(activityCountCondition.BucketId))
            {
                query = query.Where(c => c.BucketId == activityCountCondition.BucketId);
            }
            if (!string.IsNullOrEmpty(activityCountCondition.EdsId))
            {
                query = query.Where(c => c.ElemAnalysisId.Trim().ToUpper().Contains( activityCountCondition.EdsId.Trim().ToUpper()));
            }
            if (!string.IsNullOrEmpty(activityCountCondition.Status))
            {
                query = query.Where(c => c.Status == activityCountCondition.Status);
            }
            return query; 
        }
    }
}