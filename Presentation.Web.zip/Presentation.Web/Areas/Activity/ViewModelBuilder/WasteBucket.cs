﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder
{
    public class NewActivity
    {
        /// <summary>
        /// 核素ID
        /// </summary>
        public string ElementId { get; set; }

        /// <summary>
        /// 核素名称
        /// </summary>
        public string ElementName { get; set; }

        /// <summary>
        /// 是否可测1:可测,0:不可测
        /// </summary>
        public string ElementClass { get; set; }

        /// <summary>
        /// 半衰期
        /// </summary>
        public Nullable<decimal> HalfLife { get; set; }

        /// <summary>
        /// 初始活度
        /// </summary>
        public Nullable<double> InitialActivity { get; set; }

    }

    public class InitActivity
    {
        /// <summary>
        /// 核素ID
        /// </summary>
        public string ElementId { get; set; }

        /// <summary>
        /// 核素名称
        /// </summary>
        public string ElementName { get; set; }

        /// <summary>
        /// 是否可测1:可测,0:不可测
        /// </summary>
        public string ElementClass { get; set; }

        /// <summary>
        /// 半衰期
        /// </summary>
        public Nullable<decimal> HalfLife { get; set; }

        /// <summary>
        /// 初始活度
        /// </summary>
        public Nullable<decimal> InitialActivity { get; set; }
    }
}