﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core;
using System.Text;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder
{
    public class OpBuckethandleBuilder
    {

    }
}