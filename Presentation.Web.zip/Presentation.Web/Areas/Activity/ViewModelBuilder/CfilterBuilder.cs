﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder
{
    public class CfilterBuilder
    {
        /// <summary>
        /// 根据提交表单计算出Detail信息
        /// </summary>
        /// <param name="activityVM"></param>
        public static List<ActivityCfilterDetail> BuilderActivityDetailInfo(CfilterVM activityVM)
        {
            //根据桶编号获取桶ID
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            string bucketId = iNuclearBucketRepository.Get(activityVM.Activity.BucketId).BucketId;
            //桶Id为空直接返回空
            if (string.IsNullOrEmpty(bucketId))
            {
                return null;
            }

            //能谱信息
            string edsId = activityVM.Activity.ElemAnalysisId;
            ISupportEdsRepository iSupportEdsRepository = ServiceLocator.Current.GetInstance<ISupportEdsRepository>();
            IQueryable<SupportEds> iquerySupportEds = iSupportEdsRepository.GetAll().AsQueryable().Where(c => c.EdsId == edsId);
            SupportEds supportEds = iSupportEdsRepository.Get(edsId);

            ISupportEdsDetailRepository isupportEdsDetailRepository = ServiceLocator.Current.GetInstance<ISupportEdsDetailRepository>();
            IQueryable<SupportEdsDetail> iquerySupportEdsDetail = isupportEdsDetailRepository.GetAll().AsQueryable();

            //核素信息
            INuclearElementRepository iNuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = iNuclearElementRepository.GetAll().AsQueryable();
            IQueryable<NuclearElement> iqueryCantestElement = iqueryNuclearElement.Where(c => c.ElementClass == "1");
            IQueryable<NuclearElement> iqueryUntestElement = iqueryNuclearElement.Where(c => c.ElementClass == "0");

            //比例因子信息
            string wasteTypeId = activityVM.Activity.WasteTypeId;
            string factorType = activityVM.Activity.FactorType;
            IScalefactorRepository iScalefactorRepository = ServiceLocator.Current.GetInstance<IScalefactorRepository>();
            IQueryable<Scalefactor> iqueryScalefactor = iScalefactorRepository.GetAll().AsQueryable().Where(c => c.WasteTypeId == wasteTypeId && c.FactorType == factorType);
             List<NewActivity> query = new List<NewActivity>();
             if (supportEds.EdsType == "M")
             {
                 query = ((from a in iquerySupportEds
                                             join d in iquerySupportEdsDetail on a.EdsId equals d.EdsId
                                             join b in iqueryCantestElement
                                             on d.ElementId equals b.ElementId
                                             select new NewActivity
                                             {
                                                 ElementId = b.ElementId,
                                                 ElementName = b.ElementName,
                                                 ElementClass = b.ElementClass,
                                                 HalfLife = b.HalfLife,
                                                 InitialActivity = d.Activity,
                                             }

                                            ).Union(
                                            from b in iqueryUntestElement
                                            select new NewActivity
                                            {
                                                ElementId = b.ElementId,
                                                ElementName = b.ElementName,
                                                ElementClass = b.ElementClass,
                                                HalfLife = b.HalfLife,
                                                InitialActivity = 0,
                                            }
                                            )).ToList();
             }
             else
             {
                 query = ((from a in iquerySupportEds
                           join d in iquerySupportEdsDetail on a.EdsId equals d.EdsId
                           join b in iqueryCantestElement
                           on d.ElementId equals b.ElementId
                           select new NewActivity
                           {
                               ElementId = b.ElementId,
                               ElementName = b.ElementName,
                               ElementClass = b.ElementClass,
                               HalfLife = b.HalfLife,
                               InitialActivity = d.PercentValue,
                           }

                                              ).Union(
                                              from b in iqueryUntestElement
                                              select new NewActivity
                                              {
                                                  ElementId = b.ElementId,
                                                  ElementName = b.ElementName,
                                                  ElementClass = b.ElementClass,
                                                  HalfLife = b.HalfLife,
                                                  InitialActivity = 0,
                                              }
                                              )).ToList();
             }
            //桶重量
            decimal bucketWeight = Convert.ToDecimal(activityVM.Activity.BucketWeight);

            //空桶重量
            decimal emptyBucketWeight = Convert.ToDecimal(activityVM.Activity.EmptyBucketWeight);

            //封盖重量
            decimal coverWeight = Convert.ToDecimal(activityVM.Activity.CoverWeight);

            //屏蔽重量
            decimal shieldWeight = Convert.ToDecimal(activityVM.Activity.ShieldWeight);

            //平均剂量率
            decimal avgDoseRate = Convert.ToDecimal(activityVM.Activity.AvgDoseRate);

            //转换函数
            decimal transferFun = Convert.ToDecimal(activityVM.Activity.TransferFun);

            //初始活度总和
            var sumInitAct = query.Sum(e => e.InitialActivity);

            //推算伽玛核素活度
            decimal gActivity = Convert.ToDecimal(activityVM.Activity.AvgDoseRate * activityVM.Activity.TransferFun);

            //常量
            decimal constValue = Convert.ToDecimal(9.8);

            //活度计算明细
            activityVM.ActivityDetailList = new List<ActivityCfilterDetail>();

            CommonHelper commonHelper = new CommonHelper();

            //添加可测核素信息
            foreach (var item in query)
            {
                if (item.ElementClass == "1")
                {
                    CfilterVM vM = new CfilterVM();
                    ActivityCfilterDetail activityDetail = new ActivityCfilterDetail();
                    activityDetail.ElementId = item.ElementId;
                    activityDetail.HalfLife = item.HalfLife;

                    //初始活度以及初始活度比例
                    activityDetail.InitialActivity = Convert.ToDecimal(item.InitialActivity);
                    activityDetail.InitialActivityRate = Convert.ToDecimal(item.InitialActivity) / Convert.ToDecimal(sumInitAct) * 100;
                    activityDetail.InitialActivityRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.InitialActivityRate)));

                    //核素能谱
                    activityDetail.ElementLevel = gActivity * activityDetail.InitialActivityRate / 100;
                    activityDetail.ElementLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.ElementLevel)));

                    //内容物资比活度
                    activityDetail.SpecificActivity = Convert.ToDecimal(activityDetail.ElementLevel / (bucketWeight - emptyBucketWeight - coverWeight - shieldWeight * constValue/1000) * constValue);
                    activityDetail.SpecificActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.SpecificActivity)));

                    activityVM.ActivityDetailList.Add(activityDetail);
                }
            }

            //将特殊元素移到元素末尾
            foreach (var item in query)
            {
                if (item.ElementName.Trim().ToUpper().Equals("TSPU241"))
                {
                    query.Remove(item);
                    query.Add(item);
                    break;
                }
            }

            //添加不可测核素信息
            foreach (var item in query)
            {
                if (item.ElementClass == "0")
                {
                    CfilterVM vM = new CfilterVM();
                    ActivityCfilterDetail detail = new ActivityCfilterDetail();
                    detail.ElementId = item.ElementId;
                    detail.HalfLife = item.HalfLife;

                    //初始活度以及初始活度比例
                    detail.InitialActivity = Convert.ToDecimal(item.InitialActivity);
                    detail.InitialActivityRate = Convert.ToDecimal(item.InitialActivity / sumInitAct) * 100;
                    detail.InitialActivityRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(detail.InitialActivityRate)));

                    //核素能谱
                    string dtmElementId = item.ElementId;
                    Scalefactor scaleFactor = null;
                    var scaleFactorFilter = iqueryScalefactor.Where(c => c.DtmElementId == dtmElementId); //根据不可测的核素ID查找对应的比例因子
                    if (scaleFactorFilter.Count() > 0) //如果存在该核素的比例因子
                    {
                        scaleFactor = scaleFactorFilter.ToList()[0];
                        string quotaElementId = scaleFactor.QuotaElementId;

                        ActivityCfilterDetail model = null;
                        List<ActivityCfilterDetail> list = activityVM.ActivityDetailList.Where(c => c.ElementId == quotaElementId).ToList(); //根据不可测核素ID的得到指标核素ID，并根据指标核素ID查到其对应的核素能谱
                        if (list.Count > 0) //如果存在指标核素ID查到其对应的核素能谱
                        {
                            model = list[0];
                            detail.ElementLevel = model.ElementLevel * scaleFactor.Scalevalue;
                            detail.ElementLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(detail.ElementLevel)));
                        }
                    }
                    else //如果不存在该核素的比例因子，则该核素的核素能谱为0
                    {
                        detail.ElementLevel = 0;

                        //H3的核素能谱为0.01*过滤器数目
                        if (item.ElementName.Trim().ToUpper() == "H3")
                        {
                            detail.ElementLevel = Convert.ToDecimal(0.01) * activityVM.Activity.FilterCount;
                        }
                    }

                    //是否燃料破损
                    if (activityVM.Activity.IsDamage == "0")
                    {
                        if (item.ElementName.ToUpper().Contains("PU239"))
                        {
                            detail.ElementLevel = 0;
                        }
                    }

                    //内容物资比活度
                    detail.SpecificActivity = Convert.ToDecimal(detail.ElementLevel / (bucketWeight - emptyBucketWeight - coverWeight - shieldWeight * constValue/1000) * constValue);
                    detail.SpecificActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(detail.SpecificActivity)));
                    activityVM.ActivityDetailList.Add(detail);
                }

            }

            return activityVM.ActivityDetailList;
        }
    }
}