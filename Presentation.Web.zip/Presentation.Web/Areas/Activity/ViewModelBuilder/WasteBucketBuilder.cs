﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder
{
    public class WasteBucketBuilder
    {
        /// <summary>
        /// 得到核素分析单信息
        /// </summary>
        /// <param name="stationCode">电站编号</param>
        /// <param name="keyWord">关键字</param>
        /// <returns></returns>
        public static IQueryable<ElementAnalyseVM> GetElementAnalyse(string stationCode, string keyWord)
        {
            //得到核素分析单信息
            INuclearNuclideRepository iNuclearNuclideRepository = ServiceLocator.Current.GetInstance<INuclearNuclideRepository>();
            IQueryable<NuclearNuclide> iqueryNuclearNuclide = iNuclearNuclideRepository.GetAll().AsQueryable().Where(c => c.Status == "2");

            //得到核素分析单样品信息
            INuclearNuclideSampleRepository iNuclearNuclideSampleRepository = ServiceLocator.Current.GetInstance<INuclearNuclideSampleRepository>();
            IQueryable<NuclearNuclideSample> iqueryNuclearNuclideSample = iNuclearNuclideSampleRepository.GetAll().AsQueryable();

            //得到能谱信息
            ISupportEdsRepository iSupportEdsRepository = ServiceLocator.Current.GetInstance<ISupportEdsRepository>();
            IQueryable<SupportEds> iquerySupportEds = iSupportEdsRepository.GetAll().AsQueryable();

            //得到桶信息
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IQueryable<NuclearBucket> iqueryNuclearBucket = iNuclearBucketRepository.GetAll().AsQueryable();

            //得到已做过活度计算的桶信息
            IActivityCountViewRepository iActivityCountViewRepository = ServiceLocator.Current.GetInstance<IActivityCountViewRepository>();
            IQueryable<ActivityCountView> activityCountView = iActivityCountViewRepository.GetAll().AsQueryable();

            //联合查询
            var query = from n in iqueryNuclearNuclide
                        join s in iqueryNuclearNuclideSample on n.NuclideId equals s.NuclideId
                        join e in iquerySupportEds on n.EdsId equals e.EdsId into edsEmpt
                        from e in edsEmpt.DefaultIfEmpty()
                        join b in iqueryNuclearBucket on s.SampleNum equals b.BucketId
                        select new ElementAnalyseVM
                        {
                            AnalyseId = n.NuclideId,
                            SampleId = s.SampleId,
                            EDSCode = e.EdsSerialCode,
                            AnalyseDate = n.AnalyzeDate,
                            AnalyseUnit = n.AnalyzeCompany,
                            SampleCode = b.BucketCode,
                            SampleDate = s.SamplingDate,
                            ConfirmDate = n.ConfirmDate
                        };

            if (!string.IsNullOrEmpty(keyWord))
            {
                keyWord = keyWord.ToUpper();
                query = query.Where(c => c.EDSCode.ToUpper().Contains(keyWord) || c.SampleCode.ToUpper().Contains(keyWord) || c.AnalyseUnit.ToUpper().Contains(keyWord));
            }
            query = query.OrderBy("ConfirmDate", SortDirection.Descending);
            return query;

        }

        /// <summary>
        /// 根据提交表单计算出Detail信息
        /// </summary>
        /// <param name="activityBucketVM"></param>
        public static List<ActivityBucketDetail> BuilderActivityDetailInfo(ActivityBucketVM activityBucketVM)
        {
            //根据桶编号获取桶ID
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            string bucketId = iNuclearBucketRepository.Get(activityBucketVM.Activity.BucketId).BucketId;
            //桶Id为空直接返回空
            if (string.IsNullOrEmpty(bucketId))
            {
                return null;
            }

            //能谱信息
            string edsId=activityBucketVM.Activity.ElemAnalysisId;
            ISupportEdsRepository iSupportEdsRepository = ServiceLocator.Current.GetInstance<ISupportEdsRepository>();
            IQueryable<SupportEds> iquerySupportEds = iSupportEdsRepository.GetAll().AsQueryable().Where(c => c.EdsId == edsId);
            ISupportEdsDetailRepository isupportEdsDetailRepository = ServiceLocator.Current.GetInstance<ISupportEdsDetailRepository>();
            IQueryable<SupportEdsDetail> iquerySupportEdsDetail = isupportEdsDetailRepository.GetAll().AsQueryable();
            SupportEds supportEds = iSupportEdsRepository.Get(edsId);

            //核素信息
            INuclearElementRepository iNuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = iNuclearElementRepository.GetAll().AsQueryable();
            IQueryable<NuclearElement> iqueryCantestElement = iqueryNuclearElement.Where(c => c.ElementClass == "1");
            IQueryable<NuclearElement> iqueryUntestElement = iqueryNuclearElement.Where(c => c.ElementClass == "0");

            //比例因子信息
            string wasteTypeId = activityBucketVM.Activity.WasteTypeId;
            string factorType = activityBucketVM.Activity.FactorType;
            IScalefactorRepository iScalefactorRepository = ServiceLocator.Current.GetInstance<IScalefactorRepository>();
            IQueryable<Scalefactor> iqueryScalefactor = iScalefactorRepository.GetAll().AsQueryable().Where(c => c.WasteTypeId == wasteTypeId && c.FactorType == factorType);
             List<NewActivity> query = new List<NewActivity>();
             if (supportEds.EdsType == "M")
             {
               query = ((from a in iquerySupportEds
                                             join d in iquerySupportEdsDetail on a.EdsId equals d.EdsId
                                             join b in iqueryCantestElement
                                             on d.ElementId equals b.ElementId
                                             select new NewActivity
                                             {
                                                 ElementId = b.ElementId,
                                                 ElementName = b.ElementName,
                                                 ElementClass = b.ElementClass,
                                                 HalfLife = b.HalfLife,
                                                 InitialActivity = d.Activity,
                                             }

                                            ).Union(
                                            from b in iqueryUntestElement
                                            select new NewActivity
                                            {
                                                ElementId = b.ElementId,
                                                ElementName = b.ElementName,
                                                ElementClass = b.ElementClass,
                                                HalfLife = b.HalfLife,
                                                InitialActivity = 0,
                                            }
                                            )).ToList();
             }
             else {
                 query = ((from a in iquerySupportEds
                           join d in iquerySupportEdsDetail on a.EdsId equals d.EdsId
                           join b in iqueryCantestElement
                           on d.ElementId equals b.ElementId
                           select new NewActivity
                           {
                               ElementId = b.ElementId,
                               ElementName = b.ElementName,
                               ElementClass = b.ElementClass,
                               HalfLife = b.HalfLife,
                               InitialActivity = d.PercentValue,
                           }

                                                ).Union(
                                                from b in iqueryUntestElement
                                                select new NewActivity
                                                {
                                                    ElementId = b.ElementId,
                                                    ElementName = b.ElementName,
                                                    ElementClass = b.ElementClass,
                                                    HalfLife = b.HalfLife,
                                                    InitialActivity = 0,
                                                }
                                                )).ToList();
             }
            //桶重量
            decimal bucketWeight = Convert.ToDecimal(activityBucketVM.Activity.BucketWeight);

            //平均剂量率
            decimal avgDoseRate = Convert.ToDecimal(activityBucketVM.Activity.AvgDoseRate);

            //转换函数
            decimal transferFun = Convert.ToDecimal(activityBucketVM.Activity.TransferFun);

            //桶内屏蔽重量
            decimal shieldWeight = Convert.ToDecimal(activityBucketVM.Activity.ShieldWeight);

            //天数.
            DateTime starTime = (DateTime)activityBucketVM.Activity.EffcetDate;
            DateTime endTime = (DateTime)activityBucketVM.Activity.ReferDate;
            double days = (starTime - endTime).TotalDays;

            //初始活度总和
            var sumInitAct = query.Sum(e => e.InitialActivity);

            //计算能谱活度总和
            var sumCalLev = query.Sum(e => Convert.ToDecimal(e.InitialActivity) * Convert.ToDecimal(Math.Exp(Convert.ToDouble(-0.693) / Convert.ToDouble(e.HalfLife) * days)));

            //推算伽玛核素活度
            decimal gActivity = Convert.ToDecimal(activityBucketVM.Activity.AvgDoseRate) * Convert.ToDecimal(activityBucketVM.Activity.TransferFun);

            //常量
            decimal constValue = Convert.ToDecimal(9.8);

            //200L废物桶活度计算G明细
            activityBucketVM.ActivityDetailList = new List<ActivityBucketDetail>();

            CommonHelper commonHelper = new CommonHelper();

            //添加可测核素信息
            foreach (var item in query)
            {
                if (item.ElementClass == "1")
                {
                    ActivityBucketVM vM = new ActivityBucketVM();
                    ActivityBucketDetail bucketDetail = new ActivityBucketDetail();
                    bucketDetail.ElementId = item.ElementId;
                    bucketDetail.HalfLife = item.HalfLife;

                    //初始活度以及初始活度比例
                    bucketDetail.InitialActivity = Convert.ToDecimal(item.InitialActivity);
                    bucketDetail.InitialActivityRate = Convert.ToDecimal(item.InitialActivity) / Convert.ToDecimal(sumInitAct) * 100;
                    bucketDetail.InitialActivityRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.InitialActivityRate)));

                    //计算能谱=初始活度*e(-0.693/半衰期*天数)
                    bucketDetail.CalcuLevel = Convert.ToDecimal(item.InitialActivity) * Convert.ToDecimal(Math.Exp(Convert.ToDouble(-0.693) / Convert.ToDouble(item.HalfLife) * days));
                    bucketDetail.CalcuLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.CalcuLevel)));

                    bucketDetail.CalcuLevelRate = bucketDetail.CalcuLevel / sumCalLev * 100;
                    bucketDetail.CalcuLevelRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.CalcuLevelRate)));

                    //核素能谱
                    bucketDetail.ElementLevel = gActivity * bucketDetail.CalcuLevelRate / 100;
                    bucketDetail.ElementLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.ElementLevel)));

                    //内容物资比活度
                    bucketDetail.SpecificActivity = Convert.ToDecimal(bucketDetail.ElementLevel / (bucketWeight - shieldWeight * constValue/1000) * constValue);
                    bucketDetail.SpecificActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.SpecificActivity)));

                    activityBucketVM.ActivityDetailList.Add(bucketDetail);
                }
            }

            //将特殊元素移到元素末尾
            foreach (var item in query)
            {
                if (item.ElementName.Trim().ToUpper().Equals("TSPU241"))
                {
                    query.Remove(item);
                    query.Add(item);
                    break;
                }
            }

            //添加不可测核素信息
            foreach (var item in query)
            {
                if (item.ElementClass == "0")
                {
                    ActivityBucketVM vM = new ActivityBucketVM();
                    ActivityBucketDetail bucketDetail = new ActivityBucketDetail();
                    bucketDetail.ElementId = item.ElementId;
                    bucketDetail.HalfLife = item.HalfLife;

                    //初始活度以及初始活度比例
                    bucketDetail.InitialActivity = Convert.ToDecimal(item.InitialActivity);
                    bucketDetail.InitialActivityRate = Convert.ToDecimal(item.InitialActivity) / Convert.ToDecimal(sumInitAct) * 100;
                    bucketDetail.InitialActivityRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.InitialActivityRate)));

                    //计算能谱以及计算能谱比例
                    bucketDetail.CalcuLevel = 0;
                    bucketDetail.CalcuLevelRate = 0;

                    //核素能谱
                    string dtmElementId = item.ElementId;
                    Scalefactor scaleFactor = null;
                    var scaleFactorFilter = iqueryScalefactor.Where(c => c.DtmElementId == dtmElementId); //根据不可测的核素ID查找对应的比例因子
                    if (scaleFactorFilter.Count() > 0) //如果存在该核素的比例因子
                    {
                        scaleFactor = scaleFactorFilter.ToList()[0];
                        string quotaElementId = scaleFactor.QuotaElementId;

                        ActivityBucketDetail model = null;
                        List<ActivityBucketDetail> list = activityBucketVM.ActivityDetailList.Where(c => c.ElementId == quotaElementId).ToList(); //根据不可测核素ID的得到指标核素ID，并根据指标核素ID查到其对应的核素能谱
                        if (list.Count > 0) //如果存在指标核素ID查到其对应的核素能谱
                        {
                            model = list[0];
                            bucketDetail.ElementLevel = model.ElementLevel * scaleFactor.Scalevalue;
                            bucketDetail.ElementLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.ElementLevel)));
                        }
                    }
                    else //如果不存在该核素的比例因子，则该核素的核素能谱为0
                    {
                        bucketDetail.ElementLevel = 0;
                    }
                    //是否燃料破损
                    if (activityBucketVM.Activity.IsDamage=="0")
                    {
                        if (item.ElementName.ToUpper().Trim().Contains("PU239"))
                        {
                            bucketDetail.ElementLevel = 0;
                        }
                    }

                    //内容物资比活度
                    bucketDetail.SpecificActivity = Convert.ToDecimal(bucketDetail.ElementLevel / (bucketWeight - shieldWeight * constValue/1000) * constValue);
                    bucketDetail.SpecificActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.SpecificActivity)));
                    activityBucketVM.ActivityDetailList.Add(bucketDetail);
                }

            }

            return activityBucketVM.ActivityDetailList;
        }

    }
}