﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder
{
    public class CresinBuilder
    {
        /// <summary>
        /// 根据提交表单计算出Detail信息
        /// </summary>
        /// <param name="activityVM"></param>
        public static List<ActivityCresinDetail> BuilderActivityDetailInfo(CresinVM activityVM)
        {
            //根据桶编号获取桶ID
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            string bucketId = iNuclearBucketRepository.Get(activityVM.Activity.BucketId).BucketId;
            //桶Id为空直接返回空
            if (string.IsNullOrEmpty(bucketId))
            {
                return null;
            }

            //能谱信息
            string edsId = activityVM.Activity.ElemAnalysisId;
            ISupportEdsRepository iSupportEdsRepository = ServiceLocator.Current.GetInstance<ISupportEdsRepository>();
            IQueryable<SupportEds> iquerySupportEds = iSupportEdsRepository.GetAll().AsQueryable().Where(c => c.EdsId == edsId);
            ISupportEdsDetailRepository isupportEdsDetailRepository = ServiceLocator.Current.GetInstance<ISupportEdsDetailRepository>();
            IQueryable<SupportEdsDetail> iquerySupportEdsDetail = isupportEdsDetailRepository.GetAll().AsQueryable();
            SupportEds supportEds = iSupportEdsRepository.Get(edsId);

            //核素信息
            INuclearElementRepository iNuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = iNuclearElementRepository.GetAll().AsQueryable();
            IQueryable<NuclearElement> iqueryCantestElement = iqueryNuclearElement.Where(c => c.ElementClass == "1");
            IQueryable<NuclearElement> iqueryUntestElement = iqueryNuclearElement.Where(c => c.ElementClass == "0");

            //比例因子信息
            string wasteTypeId = activityVM.Activity.WasteTypeId;
            string factorType = activityVM.Activity.FactorType;
            IScalefactorRepository iScalefactorRepository = ServiceLocator.Current.GetInstance<IScalefactorRepository>();
            IQueryable<Scalefactor> iqueryScalefactor = iScalefactorRepository.GetAll().AsQueryable().Where(c => c.WasteTypeId == wasteTypeId && c.FactorType == factorType);
             List<NewActivity> query = new List<NewActivity>();
             if (supportEds.EdsType == "M")
             {
                 query = ((from a in iquerySupportEds
                           join d in iquerySupportEdsDetail on a.EdsId equals d.EdsId
                           join b in iqueryCantestElement
                           on d.ElementId equals b.ElementId
                           select new NewActivity
                           {
                               ElementId = b.ElementId,
                               ElementName = b.ElementName,
                               ElementClass = b.ElementClass,
                               HalfLife = b.HalfLife,
                               InitialActivity = d.Activity,
                           }

                                            ).Union(
                                            from b in iqueryUntestElement
                                            select new NewActivity
                                            {
                                                ElementId = b.ElementId,
                                                ElementName = b.ElementName,
                                                ElementClass = b.ElementClass,
                                                HalfLife = b.HalfLife,
                                                InitialActivity = 0,
                                            }
                                      )).ToList();
             }
             else
             {
                 query = ((from a in iquerySupportEds
                           join d in iquerySupportEdsDetail on a.EdsId equals d.EdsId
                           join b in iqueryCantestElement
                           on d.ElementId equals b.ElementId
                           select new NewActivity
                           {
                               ElementId = b.ElementId,
                               ElementName = b.ElementName,
                               ElementClass = b.ElementClass,
                               HalfLife = b.HalfLife,
                               InitialActivity = d.PercentValue,
                           }

                                                             ).Union(
                                                             from b in iqueryUntestElement
                                                             select new NewActivity
                                                             {
                                                                 ElementId = b.ElementId,
                                                                 ElementName = b.ElementName,
                                                                 ElementClass = b.ElementClass,
                                                                 HalfLife = b.HalfLife,
                                                                 InitialActivity = 0,
                                                             }
                                                       )).ToList();
             }
            //桶重量
            decimal bucketWeight = Convert.ToDecimal(activityVM.Activity.BucketWeight);

            //空桶重量
            decimal emptyBucketWeight = Convert.ToDecimal(activityVM.Activity.EmptyBucketWeight);

            //封盖重量
            decimal coverWeight = Convert.ToDecimal(activityVM.Activity.CoverWeight);

            //封盖重量
            decimal shieldWeight = Convert.ToDecimal(activityVM.Activity.ShieldWeight);

            //平均剂量率
            decimal avgDoseRate = Convert.ToDecimal(activityVM.Activity.AvgDoseRate);

            //转换函数
            decimal transferFun = Convert.ToDecimal(activityVM.Activity.TransferFun);

            //天数.
            DateTime starTime = (DateTime)activityVM.Activity.EffcetDate;
            DateTime endTime = (DateTime)activityVM.Activity.SampleMeasureDate;//有效-样品
            double days = (starTime - endTime).TotalDays;

            //初始活度总和
            var sumInitAct = query.Sum(e => e.InitialActivity);

            //计算能谱活度总和
            var sumCalLev = query.Sum(e => Convert.ToDecimal(e.InitialActivity) * Convert.ToDecimal(Math.Exp(Convert.ToDouble(-0.693) / Convert.ToDouble(e.HalfLife) * days)));

            //推算伽玛核素活度
            decimal gActivity = Convert.ToDecimal(activityVM.Activity.AvgDoseRate) * Convert.ToDecimal(activityVM.Activity.TransferFun);

            //常量
            decimal constValue = Convert.ToDecimal(9.8);

            //200L废物桶活度计算G明细
            activityVM.ActivityDetailList = new List<ActivityCresinDetail>();

            CommonHelper commonHelper = new CommonHelper();

            //添加可测核素信息
            foreach (var item in query)
            {
                if (item.ElementClass == "1")
                {
                    CresinVM vM = new CresinVM();
                    ActivityCresinDetail activityDetail = new ActivityCresinDetail();
                    activityDetail.ElementId = item.ElementId;
                    activityDetail.HalfLife = item.HalfLife;

                    //初始活度以及初始活度比例
                    activityDetail.InitialActivity = Convert.ToDecimal(item.InitialActivity);
                    activityDetail.InitialActivityRate = Convert.ToDecimal(item.InitialActivity / sumInitAct) * 100;
                    activityDetail.InitialActivityRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.InitialActivityRate)));

                    //计算能谱=初始活度*e(-0.693/半衰期*天数)
                    activityDetail.CalcuLevel = Convert.ToDecimal(item.InitialActivity) * Convert.ToDecimal(Math.Exp(Convert.ToDouble(-0.693) / Convert.ToDouble(item.HalfLife) * days));
                    activityDetail.CalcuLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.CalcuLevel)));

                    activityDetail.CalcuLevelRate = activityDetail.CalcuLevel / sumCalLev * 100;
                    activityDetail.CalcuLevelRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.CalcuLevelRate)));

                    //核素能谱
                    activityDetail.ElementActivity = gActivity * activityDetail.CalcuLevelRate / 100;
                    activityDetail.ElementActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.ElementActivity)));

                    //内容物资比活度
                    activityDetail.SpecificActivity = Convert.ToDecimal(activityDetail.ElementActivity / (bucketWeight - emptyBucketWeight - coverWeight - shieldWeight * constValue/1000) * constValue);
                    activityDetail.SpecificActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.SpecificActivity)));

                    activityVM.ActivityDetailList.Add(activityDetail);
                }
            }

            //将特殊元素移到元素末尾
            foreach (var item in query)
            {
                if (item.ElementName.Trim().ToUpper().Equals("TSPU241"))
                {
                    query.Remove(item);
                    query.Add(item);
                    break;
                }
            }

            //添加不可测核素信息
            foreach (var item in query)
            {
                if (item.ElementClass == "0")
                {
                    CresinVM vM = new CresinVM();
                    ActivityCresinDetail bucketDetail = new ActivityCresinDetail();
                    bucketDetail.ElementId = item.ElementId;
                    bucketDetail.HalfLife = item.HalfLife;

                    //初始活度以及初始活度比例
                    bucketDetail.InitialActivity = Convert.ToDecimal(item.InitialActivity);
                    bucketDetail.InitialActivityRate = Convert.ToDecimal(item.InitialActivity / sumInitAct) * 100;
                    bucketDetail.InitialActivityRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.InitialActivityRate)));

                    //计算能谱以及计算能谱比例
                    bucketDetail.CalcuLevel = 0;
                    bucketDetail.CalcuLevelRate = 0;

                    //核素能谱
                    string dtmElementId = item.ElementId;
                    Scalefactor scaleFactor = null;
                    var scaleFactorFilter = iqueryScalefactor.Where(c => c.DtmElementId == dtmElementId); //根据不可测的核素ID查找对应的比例因子
                    if (scaleFactorFilter.Count() > 0) //如果存在该核素的比例因子
                    {
                        scaleFactor = scaleFactorFilter.ToList()[0];
                        string quotaElementId = scaleFactor.QuotaElementId;

                        ActivityCresinDetail model = null;
                        List<ActivityCresinDetail> list = activityVM.ActivityDetailList.Where(c => c.ElementId == quotaElementId).ToList(); //根据不可测核素ID的得到指标核素ID，并根据指标核素ID查到其对应的核素能谱
                        if (list.Count > 0) //如果存在指标核素ID查到其对应的核素能谱
                        {
                            model = list[0];
                            bucketDetail.ElementActivity = model.ElementActivity * scaleFactor.Scalevalue;
                            bucketDetail.ElementActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.ElementActivity)));
                        }
                    }
                    else //如果不存在该核素的比例因子，则该核素的核素能谱为0
                    {
                        bucketDetail.ElementActivity = 0;
                    }

                    //是否燃料破损
                    if (activityVM.Activity.IsDamage == "0")
                    {
                        if (item.ElementName.ToUpper().Trim().Contains("PU239") || item.ElementName.ToUpper().Trim().Contains("SR90"))
                        {
                            bucketDetail.ElementActivity = 0;
                        }
                    }

                    //内容物资比活度
                    bucketDetail.SpecificActivity = Convert.ToDecimal(bucketDetail.ElementActivity / (bucketWeight - emptyBucketWeight - coverWeight - shieldWeight * constValue / 1000) * constValue);
                    bucketDetail.SpecificActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.SpecificActivity)));
                    activityVM.ActivityDetailList.Add(bucketDetail);
                }

            }

            return activityVM.ActivityDetailList;
        }
    }
}