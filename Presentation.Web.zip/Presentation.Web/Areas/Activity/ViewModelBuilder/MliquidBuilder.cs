﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder
{
    public class MliquidBuilder
    {
        /// <summary>
        /// 根据提交表单计算出Detail信息
        /// </summary>
        /// <param name="mliquidVM"></param>
        public static List<ActivityMliquidDetail> BuilderActivityDetailInfo(MliquidVM mliquidVM)
        {
            //根据桶编号获取桶ID
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            string bucketId = iNuclearBucketRepository.Get(mliquidVM.Activity.BucketId).BucketId;
            //桶Id为空直接返回空
            if (string.IsNullOrEmpty(bucketId))
            {
                return null;
            }

            //能谱信息
            string edsId = mliquidVM.Activity.ElemAnalysisId;
            ISupportEdsRepository iSupportEdsRepository = ServiceLocator.Current.GetInstance<ISupportEdsRepository>();
            SupportEds supportEds =iSupportEdsRepository.Get(edsId);
            IQueryable<SupportEds> iquerySupportEds = iSupportEdsRepository.GetAll().AsQueryable().Where(c => c.EdsId == edsId);
            ISupportEdsDetailRepository isupportEdsDetailRepository = ServiceLocator.Current.GetInstance<ISupportEdsDetailRepository>();
            IQueryable<SupportEdsDetail> iquerySupportEdsDetail = isupportEdsDetailRepository.GetAll().AsQueryable();

            //核素信息
            INuclearElementRepository iNuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = iNuclearElementRepository.GetAll().AsQueryable();
            IQueryable<NuclearElement> iqueryCantestElement = iqueryNuclearElement.Where(c => c.ElementClass == "1");
            IQueryable<NuclearElement> iqueryUntestElement = iqueryNuclearElement.Where(c => c.ElementClass == "0");

            //比例因子信息
            string wasteTypeId = mliquidVM.Activity.WasteTypeId;
            string factorType = mliquidVM.Activity.FactorType;
            IScalefactorRepository iScalefactorRepository = ServiceLocator.Current.GetInstance<IScalefactorRepository>();
            IQueryable<Scalefactor> iqueryScalefactor = iScalefactorRepository.GetAll().AsQueryable().Where(c => c.WasteTypeId == wasteTypeId && c.FactorType == factorType);
            List<NewActivity> query = new List<NewActivity>();
            if (supportEds.EdsType == "M")
            {
                 query = ((from a in iquerySupportEds
                                            join d in iquerySupportEdsDetail on a.EdsId equals d.EdsId
                                            join b in iqueryCantestElement
                                            on d.ElementId equals b.ElementId
                                            select new NewActivity
                                            {
                                                ElementId = b.ElementId,
                                                ElementName = b.ElementName,
                                                ElementClass = b.ElementClass,
                                                HalfLife = b.HalfLife,
                                                InitialActivity = d.Activity,
                                            }

                                          ).Union(
                                          from b in iqueryUntestElement
                                          select new NewActivity
                                          {
                                              ElementId = b.ElementId,
                                              ElementName = b.ElementName,
                                              ElementClass = b.ElementClass,
                                              HalfLife = b.HalfLife,
                                              InitialActivity = 0,
                                          }
                                          )).ToList();
            }
            else {
                 query = ((from a in iquerySupportEds
                                            join d in iquerySupportEdsDetail on a.EdsId equals d.EdsId
                                            join b in iqueryCantestElement
                                            on d.ElementId equals b.ElementId
                                            select new NewActivity
                                            {
                                                ElementId = b.ElementId,
                                                ElementName = b.ElementName,
                                                ElementClass = b.ElementClass,
                                                HalfLife = b.HalfLife,
                                                InitialActivity = d.PercentValue,
                                            }

                                            ).Union(
                                            from b in iqueryUntestElement
                                            select new NewActivity
                                            {
                                                ElementId = b.ElementId,
                                                ElementName = b.ElementName,
                                                ElementClass = b.ElementClass,
                                                HalfLife = b.HalfLife,
                                                InitialActivity = 0,
                                            }
                                            )).ToList();
            }

           

            //桶重量
            decimal bucketWeight = Convert.ToDecimal(mliquidVM.Activity.BucketWeight);

            //浓缩液重量
            decimal liquidWeight = Convert.ToDecimal(mliquidVM.Activity.LiquidWeight);

            ////天数.
            //DateTime starTime = (DateTime)MliquidVM.Activity.EffcetDate;
            //DateTime endTime = (DateTime)MliquidVM.Activity.ReferDate;
            //double days = (starTime - endTime).TotalDays;

            //初始活度总和
            var sumInitAct = query.Sum(e => e.InitialActivity);

            ////计算能谱活度总和
            //var sumCalLev = query.Sum(e => e.InitialActivity * Convert.ToDecimal(Math.Exp(Convert.ToDouble(-0.693) / Convert.ToDouble(e.HalfLife) * days)));

            //推算伽玛核素活度
            decimal gActivity = Convert.ToDecimal(sumInitAct)*Convert.ToDecimal(mliquidVM.Activity.LiquidVolime)/1000;

            //常量
            decimal constValue = Convert.ToDecimal(9.8);

            //活度计算明细
            mliquidVM.ActivityDetailList = new List<ActivityMliquidDetail>();

            CommonHelper commonHelper = new CommonHelper();

            //添加可测核素信息
            foreach (var item in query)
            {
                if (item.ElementClass == "1")
                {
                    MliquidVM vM = new MliquidVM();
                    ActivityMliquidDetail activityDetail = new ActivityMliquidDetail();
                    activityDetail.ElementId = item.ElementId;
                    activityDetail.HalfLife = item.HalfLife;

                    //初始活度以及初始活度比例
                    activityDetail.InitialActivity = Convert.ToDecimal(item.InitialActivity);
                    activityDetail.InitialActivityRate = Convert.ToDecimal(item.InitialActivity / sumInitAct) * 100;
                    activityDetail.InitialActivityRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.InitialActivityRate)));

                    ////计算能谱=初始活度*e(-0.693/半衰期*天数)
                    //bucketDetail.CalcuLevel = item.InitialActivity * Convert.ToDecimal(Math.Exp(Convert.ToDouble(-0.693) / Convert.ToDouble(item.HalfLife) * days));
                    //bucketDetail.CalcuLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.CalcuLevel)));

                    //bucketDetail.CalcuLevelRate = bucketDetail.CalcuLevel / sumCalLev * 100;
                    //bucketDetail.CalcuLevelRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(bucketDetail.CalcuLevelRate)));

                    //核素能谱
                    activityDetail.ElementLevel = gActivity * activityDetail.InitialActivityRate / 100;
                    activityDetail.ElementLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.ElementLevel)));

                    //内容物资比活度
                    activityDetail.SpecificActivity = Convert.ToDecimal(activityDetail.ElementLevel / (bucketWeight / constValue * 1000 - liquidWeight) * 1000);
                    activityDetail.SpecificActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.SpecificActivity)));

                    mliquidVM.ActivityDetailList.Add(activityDetail);
                }
            }



            //将特殊元素移到元素末尾
            foreach (var item in query)
            {
                if (item.ElementName.Trim().ToUpper().Equals("TSPU241"))
                {
                    query.Remove(item);
                    query.Add(item);
                    break;
                }
            }

            //添加不可测核素信息
            foreach (var item in query)
            {
                if (item.ElementClass == "0")
                {
                    MliquidVM vM = new MliquidVM();
                    ActivityMliquidDetail activityDetail = new ActivityMliquidDetail();
                    activityDetail.ElementId = item.ElementId;
                    activityDetail.HalfLife = item.HalfLife;

                    //初始活度以及初始活度比例
                    activityDetail.InitialActivity = Convert.ToDecimal(item.InitialActivity);
                    activityDetail.InitialActivityRate = Convert.ToDecimal(item.InitialActivity / sumInitAct )* 100;
                    activityDetail.InitialActivityRate = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.InitialActivityRate)));

                    ////计算能谱以及计算能谱比例
                    //detail.CalcuLevel = 0;
                    //detail.CalcuLevelRate = 0;

                    //核素能谱
                    string dtmElementId = item.ElementId;
                    Scalefactor scaleFactor = null;
                    var scaleFactorFilter = iqueryScalefactor.Where(c => c.DtmElementId == dtmElementId); //根据不可测的核素ID查找对应的比例因子
                    if (scaleFactorFilter.Count() > 0) //如果存在该核素的比例因子
                    {
                        scaleFactor = scaleFactorFilter.ToList()[0];
                        string quotaElementId = scaleFactor.QuotaElementId;

                        ActivityMliquidDetail model = null;
                        List<ActivityMliquidDetail> list = mliquidVM.ActivityDetailList.Where(c => c.ElementId == quotaElementId).ToList(); //根据不可测核素ID的得到指标核素ID，并根据指标核素ID查到其对应的核素能谱
                        if (list.Count > 0) //如果存在指标核素ID查到其对应的核素能谱
                        {
                            model = list[0];
                            activityDetail.ElementLevel = model.ElementLevel * scaleFactor.Scalevalue;
                            activityDetail.ElementLevel = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.ElementLevel)));
                        }
                    }
                    else //如果不存在该核素的比例因子，则该核素的核素能谱为0
                    {
                        activityDetail.ElementLevel = 0;

                        //H3的核素能谱为0.4
                        if (item.ElementName.Trim().ToUpper() == "H3")
                        {
                            activityDetail.ElementLevel = Convert.ToDecimal(0.4);
                        }
                    }

                    //是否燃料破损
                    if (mliquidVM.Activity.IsDamage == "0")
                    {
                        if (item.ElementName.ToUpper().Contains("PU239"))
                        {
                            activityDetail.ElementLevel = 0;
                        }
                    }

                    //内容物资比活度
                    activityDetail.SpecificActivity = Convert.ToDecimal(activityDetail.ElementLevel / (bucketWeight / constValue * 1000 - liquidWeight) * 1000);
                    activityDetail.SpecificActivity = Convert.ToDecimal(commonHelper.StringFormatAccurate(Convert.ToDecimal(activityDetail.SpecificActivity)));
                    mliquidVM.ActivityDetailList.Add(activityDetail);
                }

            }

            return mliquidVM.ActivityDetailList;
        }
    }
}