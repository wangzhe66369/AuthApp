﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder
{
    /// <summary>
    /// 活度计算
    /// </summary>
    public class ActivityCount
    {
        /// <summary>
        ///主键Id
        /// </summary>
        public string CalcuId { get; set; }

        /// <summary>
        /// 活度计算类型
        /// </summary>
        public string ActivityCountType { get; set; }

        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }

        /// <summary>
        /// 桶Id
        /// </summary>
        public string BucketId { get; set; }

        /// <summary>
        /// 废物类型名称
        /// </summary>
        public string WasteTypeName { get; set; }

        /// <summary>
        /// 废物类型Id
        /// </summary>
        public string WasteTypeId { get; set; }


        /// <summary>
        /// 能谱序号
        /// </summary>
        public string ElemAnalysisId { get; set; }

        /// <summary>
        /// 确认状态 0:保存,1:提交,2:确认
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 实体类名 ConfirmDate StationCode TransferFun
        /// </summary>
        public string ViewModel { get; set; }

        /// <summary>
        /// 确认时间
        /// </summary>
        public Nullable<System.DateTime> ConfirmDate { get; set; }

        /// <summary>
        /// 电站
        /// </summary>
        public string StationCode { get; set; }

        /// <summary>
        /// 转换函数 
        /// </summary>
        public Nullable<decimal> TransferFun { get; set; }

    }
}