﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using NET01.CoreFramework;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using System.Configuration;
using NET01.CoreFramework.Mail;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using RWIS.Domain.DomainObjects.View.Support;

namespace RWIS.Presentation.Web.Areas.Activity.Controllers
{
    //200L废物桶活度计算G主表
    public class WasteBucketController : Controller
    {
        //
        // GET: /Activity/WasteBucket/
        #region 构造函数
        IBasicObjectRepository iBasicObjectRepository;
        IActivityBucketRepository iActivityBucketRepository;
        IActivityBucketDetailRepository iActivityBucketDetailRepository;
        INuclearElementRepository iNuclearElementRepository;
        INuclearBucketRepository iNuclearBucketRepository;
        CommonHelper commonHelper = new CommonHelper();
        ISupportEdsRepository iSupportEdsRepository; ISmtpClient smtpClent;
        public WasteBucketController(IActivityBucketRepository _iActivityBucketRepository, IActivityBucketDetailRepository _iActivityBucketDetailRepository,
            IBasicObjectRepository _iBasicObjectRepository
            , INuclearElementRepository _iNuclearElementRepository
            , INuclearBucketRepository _iNuclearBucketRepository
            , ISupportEdsRepository _iSupportEdsRepository)
        {
            this.iActivityBucketRepository = _iActivityBucketRepository;
            this.iActivityBucketDetailRepository = _iActivityBucketDetailRepository;
            this.iBasicObjectRepository = _iBasicObjectRepository;
            this.iNuclearElementRepository = _iNuclearElementRepository;
            this.iNuclearBucketRepository = _iNuclearBucketRepository;
            this.iSupportEdsRepository = _iSupportEdsRepository;
        }
        #endregion

        #region 页面初始化
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "200L废物桶页面")]
        public ActionResult Index(string strId, string isView, string pageIndex)
        {
            ActivityBucketVM activityVM = new ActivityBucketVM();
            ActivityBucket activity = new ActivityBucket();

            //编辑模式
            activityVM.IsVeiw = "0";//编辑

            activityVM.StationList = commonHelper.GetStationList();
            activityVM.WasteTypeList = commonHelper.GetSelectItemUuIdByStrName("NuClearType");

            //保存当前页数
            activityVM.PageIndex = pageIndex;

            //strId为空新增
            if (!string.IsNullOrEmpty(strId))
            {
                activity = iActivityBucketRepository.Get(strId);
                //将桶Id转为桶编号
                activity.BucketId = iNuclearBucketRepository.GetCodeById(activity.BucketId, AppContext.CurrentUser.ProjectCode);

                //将id转成能谱序号
                SupportEdsCondition condition = new SupportEdsCondition();
                condition.EdsId = activity.ElemAnalysisId;
                IQueryable<SupportEdsView> iqueryEds = iSupportEdsRepository.QueryList(condition);
                if (iqueryEds != null && iqueryEds.Count() > 0)
                {
                    SupportEdsView model = iqueryEds.ToList()[0];
                    activityVM.EdsCode = model.EdsSerialCode;
                    activityVM.WasteTypeName = model.WasteTypeName;
                }

                //查看模式
                if (isView == "1")
                {
                    activityVM.IsVeiw = "1";
                    activityVM.StationName = commonHelper.GetStationNameByCode(activity.Stationcode);
                }
            }
            activityVM.Activity = activity;

            //加载比例因子类型
            activityVM.FactorTypeList = new List<SelectListItem>();
            activityVM.FactorTypeList.Add(new SelectListItem { Text = "中广核PWR", Value = "CGN" });
            activityVM.FactorTypeList.Add(new SelectListItem { Text = "法国EDF", Value = "FRANCE" });
            activityVM.FactorTypeList.Add(new SelectListItem { Text = "美国NRC", Value = "AMERICAN" });
            activityVM.FactorTypeList.Add(new SelectListItem { Text = "其他核电", Value = "OTHER" });
            return View(activityVM);
        }
        #endregion

        #region 获取信息
        /// <summary>
        /// 获取核素数据
        /// </summary>
        /// <param name="bucketId">桶Id</param>
        /// <param name="edsId">能谱序号</param>
        /// <returns></returns>
        public JsonResult GetActivityDetailJson(ActivityBucketVM activityBucketVM)
        {
            try
            {
                //将桶编号转为桶Id
                activityBucketVM.Activity.BucketId = iNuclearBucketRepository.GetIdByCode(activityBucketVM.Activity.BucketId, AppContext.CurrentUser.ProjectCode);
                List<ActivityBucketDetail> activityBucketDetailList = WasteBucketBuilder.BuilderActivityDetailInfo(activityBucketVM);

                var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 100000000 };
                jqGridResponse.TotalRecordsCount = activityBucketDetailList.Count;

                //平均剂量率
                decimal avgDoseRate = Convert.ToDecimal(activityBucketVM.Activity.AvgDoseRate);

                //转换函数
                decimal transferFun = Convert.ToDecimal(activityBucketVM.Activity.TransferFun);

                //推算伽玛核素活度,平均剂量率*转换函数
                decimal estimateGamActivity = avgDoseRate * transferFun;

                //科学计数法 
                decimal eNotation = estimateGamActivity;

                //补充计算之后活度
                decimal addCalcuActivity = Convert.ToDecimal(activityBucketDetailList.Sum(e => e.ElementLevel));

                if (activityBucketDetailList != null && activityBucketDetailList.Count > 0)
                {


                    activityBucketDetailList.ForEach(d =>
                    {
                        jqGridResponse.Records.Add(new JqGridRecord()
                        {
                            Id = d.CalcuLd,
                            List = new List<object>() 
                            {
                                d.CalcuLd,
                                iNuclearElementRepository.Get(d.ElementId).ElementName,
                                d.HalfLife,
                                d.InitialActivity,
                                String.Format("{0:00.00}",d.InitialActivityRate) ,
                                d.CalcuLevel,
                                String.Format("{0:00.00}", d.CalcuLevelRate),
                                d.ElementLevel ,
                                d.SpecificActivity
                                
                            }
                        });
                    });
                }
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = 99,
                    List = new List<object>() 
                            {
                                "99",
                                "",
                                "",
                                "合计:",
                                "",
                                activityBucketDetailList.Sum(e => e.CalcuLevel),
                                100,
                                activityBucketDetailList.Sum(e => e.ElementLevel),
                                activityBucketDetailList.Sum(e => e.SpecificActivity) ,
                                commonHelper.StringFormatAccurate(estimateGamActivity),
                                commonHelper.StringFormatAccurate(estimateGamActivity),
                                commonHelper.StringFormatAccurate(addCalcuActivity)
                            }
                });

                return jqGridResponse.ToJsonResult();
            }
            catch (Exception)
            {

                return null;
            }
        }

        #endregion

        #region 得到核素分析单信息
        /// <summary>
        /// 得到核素分析单信息
        /// </summary>
        /// <param name="keyWord">关键字查询条件</param>
        /// <param name="jqCondition">查询条件</param>
        /// <param name="sidx">当前排序的列</param>
        /// <param name="sord">排序列</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页显示的行数</param>
        /// <returns></returns>
        public JsonResult GetAnalyseList(string keyWord, string sidx, string sord, int page, int rows)
        {
            try
            {

                IQueryable<ElementAnalyseVM> iqueryElementAnalyse = WasteBucketBuilder.GetElementAnalyse(AppContext.CurrentUser.ProjectCode, keyWord);
                var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 100000000 };
                jqGridResponse.TotalRecordsCount = iqueryElementAnalyse.Count();
                var pagedViewModel = new PagedViewModel<ElementAnalyseVM>
                {
                    Query = iqueryElementAnalyse,
                    GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                    DefaultSortColumn = sidx,
                    Page = page,
                    PageSize = rows,
                }
               .Setup();

                pagedViewModel.PagedList.ToList().ForEach(d =>
                    {
                        jqGridResponse.Records.Add(new JqGridRecord()
                        {
                            Id = d.AnalyseId,
                            List = new List<object>() 
                            {
                                d.AnalyseId,
                                d.SampleId,
                                d.EDSCode,
                                d.AnalyseDate.HasValue?d.AnalyseDate.Value.ToString("yyyy-MM-dd"):string.Empty,
                                d.AnalyseUnit,
                                d.SampleCode,
                                d.SampleDate.HasValue?d.SampleDate.Value.ToString("yyyy-MM-dd"):string.Empty
                            }
                        });
                    });

                return jqGridResponse.ToJsonResult();
            }
            catch (Exception)
            {

                return null;
            }
        }
        #endregion 得到核素分析单信息

        #region 保存.草稿.确认信息

        /// <summary>
        /// 保存活度计算主表信息
        /// </summary>
        /// <param name="activityVM">实体</param>
        [HttpPost]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "200L废物桶确认")]
        public JsonResult SaveActivityInfo(ActivityBucketVM activityVM, string status)
        {
            //将桶编号转为桶Id
            string bucketId = iNuclearBucketRepository.GetIdByCode(activityVM.Activity.BucketId, AppContext.CurrentUser.ProjectCode);
            string calcuId = "";//主表Id
            //if (!string.IsNullOrEmpty(activityVM.Activity.BucketId))
            //{
            //    ActivityCountCondition activityCountCondition = new ActivityCountCondition();
            //    IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition).Where(d => d.BucketCode == activityVM.Activity.BucketId);
            //    if (activityCountList.Count() > 0)
            //    {
            //        return JsonResultHelper.JsonResult(false, "桶号重复");
            //    }
            //}
            ActivityBucket activity = new ActivityBucket();
            activity = activityVM.Activity;
            activity.BucketId = bucketId;
            if (!string.IsNullOrEmpty(activityVM.Activity.BucketId))
            {
                ActivityCountCondition activityCountCondition = new ActivityCountCondition();
                IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition).Where(d => d.BucketCode == activityVM.Activity.BucketId);
                if (activityCountList.Count() > 0)
                {
                    return JsonResultHelper.JsonResult(false, "桶号重复");
                }
            }

            //主键Id不存在就新增,存在就修改
            if (string.IsNullOrEmpty(activityVM.Activity.CalcuId))
            {
                activity.CalcuId = Guid.NewGuid().ToString();
                activity.Status = status;
                calcuId = activity.CalcuId;

                activity.CreateUserNo = AppContext.CurrentUser.UserId;
                activity.CreateUserName = AppContext.CurrentUser.UserName;
                activity.CreateDate = DateTime.Now;

                iActivityBucketRepository.Create(activity);
            }
            else
            {
                //修改状态
                activity.Status = status;
                //status == "2"确认时添加确认人信息
                if (status == "2")
                {
                    activity.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    activity.ConfirmUserName = AppContext.CurrentUser.UserName;
                    activity.ConfirmDate = DateTime.Now;
                }
                iActivityBucketRepository.Update(activity);

                //先删除明细表数据,再插入数据
                calcuId = activity.CalcuId;
                var query = iActivityBucketDetailRepository.GetAll().Where(c => c.CalcuLd == calcuId).AsQueryable();
                if (query.Count() > 0)
                {
                    List<ActivityBucketDetail> activityBucketDetail = query.ToList();
                    foreach (var item in activityBucketDetail)
                    {
                        iActivityBucketDetailRepository.Delete(item);
                    }
                }
            }
            //activityBucketVM的桶编号已转为桶Id
            List<ActivityBucketDetail> activityBucketDetailList = WasteBucketBuilder.BuilderActivityDetailInfo(activityVM);
            //插入明细数据
            foreach (var item in activityBucketDetailList)
            {
                item.DetailId = Guid.NewGuid().ToString();
                item.CalcuLd = calcuId;
                iActivityBucketDetailRepository.Create(item);
            }
            try
            {
                iActivityBucketRepository.UnitOfWork.Commit();
            }
            catch (Exception)
            {

                throw;
            }

            return JsonResultHelper.JsonResult(true, "数据提交成功！");
        }
        #endregion

        public JsonResult GetNameCodeListByData(List<object> objList)
        {
            return null;
        }

        public void SendEmail()
        {
            string sendTitle = string.Format("采购风险监管平台任务提醒");
            var systemAddress = ConfigurationManager.AppSettings["SystemAddress"]; //系统链接地址
            string sendContent =  "您好!<br/><br/>您在采购风险监管平台中有1条关于的任务，请及时处理。<br/><br/>" + "<a href='" + systemAddress + "'>单击此处登录系统</a><br/><br/>本邮件是系统自动通知邮件，请勿回复。";
            //发送邮件
            var mailService = new RWIS.Application.Implementation.MailService(smtpClent);
            mailService.SendMailService("PXMWZZY", string.Empty, sendTitle, sendContent);

        }

        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = iNuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && e.IsOutSend == null && (e.BucketStatus == "FILL" || e.BucketStatus == "COVER")).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}