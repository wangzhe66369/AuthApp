﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using NET01.CoreFramework;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using RWIS.Domain.DomainObjects.View.Support;

namespace RWIS.Presentation.Web.Areas.Activity.Controllers
{
    public class CresinController : Controller
    {
        //
        // GET: /Activity/Cresin/

        #region 构造函数
        IBasicObjectRepository iBasicObjectRepository;
        CommonHelper commonHelper = new CommonHelper();
        INuclearBucketRepository iNuclearBucketRepository;
        INuclearElementRepository iNuclearElementRepository;

        IActivityCresinRepository iActivityCresinRepository;
        IActivityCresinDetailRepository iActivityCresinDetailRepository;
        ISupportEdsRepository iSupportEdsRepository;
        public CresinController(IBasicObjectRepository _iBasicObjectRepository, INuclearBucketRepository _iNuclearBucketRepository
            , INuclearElementRepository _iNuclearElementRepository
            , IActivityCresinRepository _iActivityCresinRepository
            , IActivityCresinDetailRepository _iActivityCresinDetailRepository
            , ISupportEdsRepository _iSupportEdsRepository)
        {
            this.iBasicObjectRepository = _iBasicObjectRepository;
            this.iNuclearBucketRepository = _iNuclearBucketRepository;
            this.iNuclearElementRepository = _iNuclearElementRepository;
            this.iActivityCresinRepository = _iActivityCresinRepository;
            this.iActivityCresinDetailRepository = _iActivityCresinDetailRepository;
            this.iSupportEdsRepository = _iSupportEdsRepository;
        }
        #endregion

        #region 页面初始化
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "C1树脂页面")]
        public ActionResult Index(string strId, string isView, string pageIndex)
        {
            CresinVM cresinVM = new CresinVM();
            ActivityCresin activityCresin = new ActivityCresin();

            //编辑模式
            cresinVM.IsVeiw = "0";//编辑

            cresinVM.StationList = commonHelper.GetStationList();
            cresinVM.WasteTypeList = commonHelper.GetSelectItemUuIdByStrName("NuClearType");

            //保存当前页数
            cresinVM.PageIndex = pageIndex;

            //strId为空新增
            if (!string.IsNullOrEmpty(strId))
            {
                activityCresin = iActivityCresinRepository.Get(strId);
                //将桶Id转为桶编号
                activityCresin.BucketId = iNuclearBucketRepository.GetCodeById(activityCresin.BucketId, AppContext.CurrentUser.ProjectCode);

                //将id转成能谱序号
                SupportEdsCondition condition = new SupportEdsCondition();
                condition.EdsId = activityCresin.ElemAnalysisId;
                IQueryable<SupportEdsView> iqueryEds = iSupportEdsRepository.QueryList(condition);
                if (iqueryEds != null && iqueryEds.Count() > 0)
                {
                    SupportEdsView model = iqueryEds.ToList()[0];
                    cresinVM.EdsCode = model.EdsSerialCode;
                    cresinVM.WasteTypeName = model.WasteTypeName;
                }

                //查看模式
                if (isView == "1")
                {
                    cresinVM.IsVeiw = "1";

                    cresinVM.StationName = commonHelper.GetStationNameByCode(activityCresin.Stationcode);
                    cresinVM.WasteTypeName = commonHelper.GetSelectItemNameByUuId(activityCresin.WasteTypeId, "NuClearType");
                }
            }
            cresinVM.Activity = activityCresin;
            //加载比例因子类型
            cresinVM.FactorTypeList = new List<SelectListItem>();
            cresinVM.FactorTypeList.Add(new SelectListItem { Text = "中广核PWR", Value = "CGN" });
            cresinVM.FactorTypeList.Add(new SelectListItem { Text = "法国EDF", Value = "FRANCE" });
            cresinVM.FactorTypeList.Add(new SelectListItem { Text = "美国NRC", Value = "AMERICAN" });
            cresinVM.FactorTypeList.Add(new SelectListItem { Text = "其他核电", Value = "OTHER" });
            return View(cresinVM);
        }
        #endregion

        #region 获取信息
        /// <summary>
        /// 获取核素数据
        /// </summary>
        /// <param name="bucketId">桶Id</param>
        /// <param name="edsId">能谱序号</param>
        /// <returns></returns>
        public JsonResult GetActivityDetailJson(CresinVM activityVM)
        {
            try
            {
                //将桶编号转为桶Id
                activityVM.Activity.BucketId = iNuclearBucketRepository.GetIdByCode(activityVM.Activity.BucketId, AppContext.CurrentUser.ProjectCode);
                List<ActivityCresinDetail> activityDetailList = CresinBuilder.BuilderActivityDetailInfo(activityVM);

                var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 100000000 };
                jqGridResponse.TotalRecordsCount = activityDetailList.Count;

                //平均剂量率
                decimal avgDoseRate = Convert.ToDecimal(activityVM.Activity.AvgDoseRate);

                //转换函数
                decimal transferFun = Convert.ToDecimal(activityVM.Activity.TransferFun);

                //推算伽玛核素活度,平均剂量率*转换函数
                decimal estimateGamActivity = avgDoseRate * transferFun;

                //科学计数法 
                decimal eNotation = estimateGamActivity;

                //补充计算之后活度
                decimal addCalcuActivity = Convert.ToDecimal(activityDetailList.Sum(e => e.ElementActivity));

                if (activityDetailList != null && activityDetailList.Count > 0)
                {
                    activityDetailList.ForEach(d =>
                    {
                        jqGridResponse.Records.Add(new JqGridRecord()
                        {
                            Id = d.CalcuLd,
                            List = new List<object>() 
                            {
                                d.CalcuLd,
                                iNuclearElementRepository.Get(d.ElementId).ElementName,
                                d.HalfLife,
                                d.InitialActivity,
                                String.Format("{0:00.00}",d.InitialActivityRate) ,
                                 commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                    d.CalcuLevel
                                    )
                                )
                                ,

                                 String.Format("{0:00.00}", d.CalcuLevelRate),

                                 commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                   d.ElementActivity
                                    )
                                )
                                ,
                                 commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                    d.SpecificActivity
                                    )
                                )
                                
                            }
                        });
                    });
                }
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = 99,
                    List = new List<object>() 
                            {
                                "99",
                                "",
                                "",
                                "合计:",
                                "",
                                commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                    activityDetailList.Sum(e => e.CalcuLevel)
                                    )
                                ),
                                //activityBucketDetailList.Sum(e => e.CalcuLevelRate),
                                100,
                                 commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                    activityDetailList.Sum(e => e.ElementActivity)
                                    )
                                ),
                                 commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                    activityDetailList.Sum(e => e.SpecificActivity)
                                    )
                                ),
                                commonHelper.StringFormatAccurate(estimateGamActivity),
                                commonHelper.StringFormatAccurate(estimateGamActivity),
                                commonHelper.StringFormatAccurate(addCalcuActivity)
                            }
                });



                return jqGridResponse.ToJsonResult();
            }
            catch (Exception)
            {

                return null;
            }
        }

        #endregion

        #region 保存.草稿.确认信息

        /// <summary>
        /// 保存活度计算主表信息
        /// </summary>
        /// <param name="activityVM">实体</param>
        [HttpPost]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "C1树脂确认")]
        public JsonResult SaveActivityInfo(CresinVM activityVM, string status)
        {
            //if (!string.IsNullOrEmpty(activityVM.Activity.BucketId))
            //{
            //    ActivityCountCondition activityCountCondition = new ActivityCountCondition();
            //    IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition).Where(d => d.BucketCode == activityVM.Activity.BucketId);
            //    if (activityCountList.Count() > 0)
            //    {
            //        return JsonResultHelper.JsonResult(false, "桶号重复");
            //    }
            //}
            //将桶编号转为桶Id
            string bucketId = iNuclearBucketRepository.GetIdByCode(activityVM.Activity.BucketId, AppContext.CurrentUser.ProjectCode);
            string calcuId = "";//主表Id

            ActivityCresin activity = new ActivityCresin();
            activity = activityVM.Activity;
            activity.BucketId = bucketId;
            if (!string.IsNullOrEmpty(activityVM.Activity.BucketId))
            {
                ActivityCountCondition activityCountCondition = new ActivityCountCondition();
                IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition).Where(d => d.BucketCode == activityVM.Activity.BucketId);
                if (activityCountList.Count() > 0)
                {
                    return JsonResultHelper.JsonResult(false, "桶号重复");
                }
            }
            //将能谱id转换能谱序号
            //string eId = iSupportEdsRepository.GetIdByCode(activityVM.Activity.ElemAnalysisId, AppContext.CurrentUser.ProjectCode);
            //activity.ElemAnalysisId = eId;

            //主键Id不存在就新增,存在就修改
            if (string.IsNullOrEmpty(activityVM.Activity.CalcuId))
            {
                activity.CalcuId = Guid.NewGuid().ToString();
                activity.Status = status;
                calcuId = activity.CalcuId;

                activity.CreateUserNo = AppContext.CurrentUser.UserId;
                activity.CreateUserName = AppContext.CurrentUser.UserName;
                activity.CreateDate = DateTime.Now;

                iActivityCresinRepository.Create(activity);
            }
            else
            {
                //修改状态
                activity.Status = status;

                //status == "2"确认时添加确认人信息
                if (status == "2")
                {
                    activity.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    activity.ConfirmUserName = AppContext.CurrentUser.UserName;
                    activity.ConfirmDate = DateTime.Now;
                }
                iActivityCresinRepository.Update(activity);

                //先删除明细表数据,再插入数据
                calcuId = activity.CalcuId;
                var query = iActivityCresinDetailRepository.GetAll().Where(c => c.CalcuLd == calcuId).AsQueryable();
                if (query.Count() > 0)
                {
                    List<ActivityCresinDetail> activityBucketDetail = query.ToList();
                    foreach (var item in activityBucketDetail)
                    {
                        iActivityCresinDetailRepository.Delete(item);
                    }
                }
            }
            //activityBucketVM的桶编号已转为桶Id
            List<ActivityCresinDetail> activityBucketDetailList = CresinBuilder.BuilderActivityDetailInfo(activityVM);
            //插入明细数据
            foreach (var item in activityBucketDetailList)
            {
                item.DetailId = Guid.NewGuid().ToString();
                item.CalcuLd = calcuId;
                iActivityCresinDetailRepository.Create(item);
            }
            iActivityCresinRepository.UnitOfWork.Commit();

            return JsonResultHelper.JsonResult(true, "数据修改成功！");
        }
        #endregion
    }
}
