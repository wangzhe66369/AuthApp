﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Presentation.Web.Core;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using NET01.Infrastructure.DomainCore;
using System.Reflection;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using Microsoft.Practices.ServiceLocation;
using Newtonsoft.Json;

namespace RWIS.Presentation.Web.Areas.Activity.Controllers
{
    //活度计算
    public class ActivityCountController : Controller
    {
        //
        // GET: /Activity/ActivityCount/
        #region 构造函数
        IBasicObjectRepository iBasicObjectRepository;
        CommonHelper commonHelper = new CommonHelper();
        IActivityBucketRepository iActivityBucketRepository;
        IActivityCementliquidRepository iActivityCementliquidRepository;
        IActivityCfilterRepository iActivityCfilterRepository;
        IActivityCoreRepository iActivityCoreRepository;
        IActivityCresinRepository iActivityCresinRepository;
        IActivityDmeasureRepository iActivityDmeasureRepository;
        IActivityHandleValueRepository iActivityHandleValueRepository;
        IActivityHlevelRepository iActivityHlevelRepository;
        IActivityMfilterRepository iActivityMfilterRepository;
        IActivityMliquidRepository iActivityMliquidRepository;
        IActivityMresinRepository iActivityMresinRepository;
        IActivityOpBucketRepository iActivityOpBucketRepository;

        IActivityBucketDetailRepository iActivityBucketDetailRepository;
        IActivityCliquidDetailRepository iActivityCliquidDetailRepository;
        IActivityCfilterDetailRepository iActivityCfilterDetailRepository;
        IActivityCoreDetailRepository iActivityCoreDetailRepository;
        IActivityCresinDetailRepository iActivityCresinDetailRepository;
        IActivityDmeasureDetailRepository iActivityDmeasureDetailRepository;
        IActivityHlevelDetailRepository iActivityHlevelDetailRepository;
        IActivityMfilterDetailRepository iActivityMfilterDetailRepository;
        IActivityMliquidDetailRepository iActivityMliquidDetailRepository;
        IActivityMresinDetailRepository iActivityMresinDetailRepository;
        IActivityOpBucketDetailRepository iActivityOpBucketDetailRepository;
        IActivityOpBuckethandleRepository iActivityOpBuckethandleRepository;

        public ActivityCountController(IBasicObjectRepository _iBasicObjectRepository, IActivityBucketRepository _iActivityBucketRepository,
        IActivityCementliquidRepository _iActivityCementliquidRepository,
        IActivityCfilterRepository _iActivityCfilterRepository,
        IActivityCoreRepository _iActivityCoreRepository,
        IActivityCresinRepository _iActivityCresinRepository,
        IActivityDmeasureRepository _iActivityDmeasureRepository,
        IActivityHandleValueRepository _iActivityHandleValueRepository,
        IActivityHlevelRepository _iActivityHlevelRepository,
        IActivityMfilterRepository _iActivityMfilterRepository,
        IActivityMliquidRepository _iActivityMliquidRepository,
        IActivityMresinRepository _iActivityMresinRepository,
        IActivityBucketDetailRepository _iActivityBucketDetailRepository,
        IActivityCliquidDetailRepository _iActivityCliquidDetailRepository,
        IActivityCfilterDetailRepository _iActivityCfilterDetailRepository,
        IActivityCoreDetailRepository _iActivityCoreDetailRepository,
        IActivityCresinDetailRepository _iActivityCresinDetailRepository,
        IActivityDmeasureDetailRepository _iActivityDmeasureDetailRepository,
        IActivityHlevelDetailRepository _iActivityHlevelDetailRepository,
        IActivityMfilterDetailRepository _iActivityMfilterDetailRepository,
        IActivityMliquidDetailRepository _iActivityMliquidDetailRepository,
        IActivityMresinDetailRepository _iActivityMresinDetailRepository,
        IActivityOpBucketDetailRepository _iActivityOpBucketDetailRepository,
        IActivityOpBucketRepository _iActivityOpBucketRepository,
        IActivityOpBuckethandleRepository _iActivityOpBuckethandleRepository)
        {
            this.iBasicObjectRepository = _iBasicObjectRepository;

            this.iActivityBucketRepository = _iActivityBucketRepository;
            this.iActivityCementliquidRepository = _iActivityCementliquidRepository;
            this.iActivityCfilterRepository = _iActivityCfilterRepository;
            this.iActivityCoreRepository = _iActivityCoreRepository;
            this.iActivityCresinRepository = _iActivityCresinRepository;
            this.iActivityDmeasureRepository = _iActivityDmeasureRepository;
            this.iActivityHandleValueRepository = _iActivityHandleValueRepository;
            this.iActivityHlevelRepository = _iActivityHlevelRepository;
            this.iActivityMfilterRepository = _iActivityMfilterRepository;
            this.iActivityMliquidRepository = _iActivityMliquidRepository;
            this.iActivityMresinRepository = _iActivityMresinRepository;
            this.iActivityOpBucketRepository = _iActivityOpBucketRepository;
            this.iActivityBucketDetailRepository = _iActivityBucketDetailRepository;
            this.iActivityCliquidDetailRepository = _iActivityCliquidDetailRepository;
            this.iActivityCfilterDetailRepository = _iActivityCfilterDetailRepository;
            this.iActivityCoreDetailRepository = _iActivityCoreDetailRepository;
            this.iActivityCresinDetailRepository = _iActivityCresinDetailRepository;
            this.iActivityDmeasureDetailRepository = _iActivityDmeasureDetailRepository;
            this.iActivityHlevelDetailRepository = _iActivityHlevelDetailRepository;
            this.iActivityMfilterDetailRepository = _iActivityMfilterDetailRepository;
            this.iActivityMliquidDetailRepository = _iActivityMliquidDetailRepository;
            this.iActivityMresinDetailRepository = _iActivityMresinDetailRepository;
            this.iActivityOpBucketDetailRepository = _iActivityOpBucketDetailRepository;
            this.iActivityOpBuckethandleRepository = _iActivityOpBuckethandleRepository;
        }
        #endregion

        #region 页面初始化
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "活度计算查询页面")]
        public ActionResult Index(string pageIndex)
        {
            ActivityCountCondition activityCountCondition = PageIndex();
            activityCountCondition.PageIndex = pageIndex;
 
            return View(activityCountCondition);
        }
        #endregion

        #region 获取所有桶活度计算数据

        public JsonResult GetAllActivityCountJson(ActivityCountCondition activityCountCondition, string sidx, string sord, int page, int rows)
        {
            try
            {
                IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition);

                //定义JqGiid类
                var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

                var pagedViewModel = new PagedViewModel<ActivityCount>
                {
                    Query = activityCountList,
                    GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                    DefaultSortColumn = sidx,
                    Page = page,
                    PageSize = rows,
                }
            .Setup();

                jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

                if (activityCountList != null && activityCountList.Count() > 0)
                {
                    pagedViewModel.PagedList.ToList().ForEach(d =>
                    {
                        jqGridResponse.Records.Add(new JqGridRecord()
                        {
                            Id = d.CalcuId,
                            List = new List<object>() 
                            {
                                d.CalcuId,
                                d.ViewModel,
                                d.ActivityCountType,
                                d.BucketCode,
                                d.WasteTypeName,
                                d.ElemAnalysisId,
                                d.Status,
                                commonHelper.GetStationNameByCode(d.StationCode),
                                d.ConfirmDate.HasValue?d.ConfirmDate.Value.ToString("yyyy-MM-dd"):string.Empty
                            }
                        });
                    });
                }

                return jqGridResponse.ToJsonResult();
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

        #region 根据子类型跳转到对应页面

        /// <summary>
        /// 根据viewModel删除不同数据
        /// </summary>
        /// <param name="viewModel"></param>
        /// <param name="strId"></param>
        /// <returns></returns>
        public ActionResult PageFactoryByClassName(string viewModel, string strId)
        {
            if (!string.IsNullOrEmpty(strId))
            {
                switch (viewModel)
                {
                    case "ActivityBucket":
                        iActivityBucketRepository.DeleteById(strId);

                        var query = iActivityBucketDetailRepository.GetAll().Where(c => c.CalcuLd == strId).AsQueryable();
                        if (query.Count() > 0)
                        {
                            List<ActivityBucketDetail> activityList = query.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityBucketDetailRepository.Delete(item);
                            }
                        }
                        break;

                    case "ActivityCementliquid":
                        iActivityCementliquidRepository.DeleteById(strId);

                        var queryActivityCementliquid = iActivityCliquidDetailRepository.GetAll().Where(c => c.CalcuLd == strId).AsQueryable();
                        if (queryActivityCementliquid.Count() > 0)
                        {
                            List<ActivityCliquidDetail> activityList = queryActivityCementliquid.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityCliquidDetailRepository.Delete(item);
                            }
                        }
                        break;

                    case "ActivityCfilter":
                        iActivityCfilterRepository.DeleteById(strId);

                        var queryActivityCfilter = iActivityCfilterDetailRepository.GetAll().Where(c => c.CalcuLd == strId).AsQueryable();
                        if (queryActivityCfilter.Count() > 0)
                        {
                            List<ActivityCfilterDetail> activityList = queryActivityCfilter.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityCfilterDetailRepository.Delete(item);
                            }
                        }
                        break;

                    case "ActivityCore":
                        iActivityCoreRepository.DeleteById(strId);

                        var queryActivityCore = iActivityCoreDetailRepository.GetAll().Where(c => c.CalcuLd == strId).AsQueryable();
                        if (queryActivityCore.Count() > 0)
                        {
                            List<ActivityCoreDetail> activityList = queryActivityCore.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityCoreDetailRepository.Delete(item);
                            }
                        }
                        break;

                    case "ActivityCresin":
                        iActivityCresinRepository.DeleteById(strId);

                        var queryActivityCresin = iActivityCresinDetailRepository.GetAll().Where(c => c.CalcuLd == strId).AsQueryable();
                        if (queryActivityCresin.Count() > 0)
                        {
                            List<ActivityCresinDetail> activityList = queryActivityCresin.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityCresinDetailRepository.Delete(item);
                            }
                        }
                        break;

                    case "ActivityDmeasure":
                        iActivityDmeasureRepository.DeleteById(strId);

                        var queryActivityDmeasure = iActivityDmeasureDetailRepository.GetAll().Where(c => c.CalcuLd == strId).AsQueryable();
                        if (queryActivityDmeasure.Count() > 0)
                        {
                            List<ActivityDmeasureDetail> activityList = queryActivityDmeasure.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityDmeasureDetailRepository.Delete(item);
                            }
                        }
                        break;

                    case "ActivityHlevel":
                        iActivityHlevelRepository.DeleteById(strId);

                        var queryActivityHlevel = iActivityHlevelDetailRepository.GetAll().Where(c => c.CalcuLd == strId).AsQueryable();
                        if (queryActivityHlevel.Count() > 0)
                        {
                            List<ActivityHlevelDetail> activityList = queryActivityHlevel.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityHlevelDetailRepository.Delete(item);
                            }
                        }
                        break;

                    case "ActivityMfilter":
                        iActivityMfilterRepository.DeleteById(strId);

                        var queryActivityMfilter = iActivityMfilterDetailRepository.GetAll().Where(c => c.CalcuLd == strId).AsQueryable();
                        if (queryActivityMfilter.Count() > 0)
                        {
                            List<ActivityMfilterDetail> activityList = queryActivityMfilter.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityMfilterDetailRepository.Delete(item);
                            }
                        }
                        break;

                    case "ActivityMliquid":
                        iActivityMliquidRepository.DeleteById(strId);

                        var queryActivityMliquid = iActivityMliquidDetailRepository.GetAll().Where(c => c.CalcuLd == strId).AsQueryable();
                        if (queryActivityMliquid.Count() > 0)
                        {
                            List<ActivityMliquidDetail> activityList = queryActivityMliquid.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityMliquidDetailRepository.Delete(item);
                            }
                        }
                        break;

                    case "ActivityMresin":
                        iActivityMresinRepository.DeleteById(strId);

                        var queryActivityMresin = iActivityMresinDetailRepository.GetAll().Where(c => c.CalcuLd == strId).AsQueryable();
                        if (queryActivityMresin.Count() > 0)
                        {
                            List<ActivityMresinDetail> activityList = queryActivityMresin.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityMresinDetailRepository.Delete(item);
                            }
                        }
                        break;

                    case "ActivityOpBucket":
                        iActivityOpBucketRepository.DeleteById(strId);

                        var queryActivityOpBucket = iActivityOpBucketDetailRepository.GetAll().Where(c => c.CalcuId == strId).AsQueryable();
                        if (queryActivityOpBucket.Count() > 0)
                        {
                            List<ActivityOpBucketDetail> activityList = queryActivityOpBucket.ToList();
                            foreach (var item in activityList)
                            {
                                iActivityOpBucketDetailRepository.Delete(item);
                            }
                        }

                        //删除桶饼信息
                        var hdquery = iActivityOpBuckethandleRepository.GetAll().Where(c => c.CalcuId == strId).AsQueryable();
                        if (hdquery.Count() > 0)
                        {
                            List<ActivityOpBuckethandle> activityOpBuckethandle = hdquery.ToList();
                            foreach (var item in activityOpBuckethandle)
                            {
                                iActivityOpBuckethandleRepository.Delete(item);
                            }
                        }
                        break;
                    default:
                        break;
                }
                iActivityBucketRepository.UnitOfWork.Commit();
            }
            ActivityCountCondition activityCountCondition = PageIndex();

            return View("Index",activityCountCondition);
        }
        #endregion

        #region 自定义方法

        public ActivityCountCondition PageIndex()
        {
            ActivityCountCondition activityCountCondition = new ActivityCountCondition();
            activityCountCondition.ActivityCountTypeList = commonHelper.GetSelectItemCodeByStrName("ActivityCountType");
            activityCountCondition.WasteTypeList = commonHelper.GetSelectItemUuIdByStrName("NuClearType");

            return activityCountCondition;
        }
        #endregion

        [HttpPost]
        public JsonResult SelectedActivityCount(string activityId)
        {

            try
            {
             
                IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
                 BasicObject basicObject =new BasicObject();
                if (activityId == "ActivityCount")
                {
                    basicObject = iBasicObjectRepository.GetFiltered(b => b.Code.ToUpper() == "ActivityCountType").FirstOrDefault();
                }
                if (activityId == "WasteType")
                {
                    basicObject = iBasicObjectRepository.GetFiltered(b => b.Code.ToUpper() == "NuClearType").FirstOrDefault();
                }
               
                List<BasicObject> basicObjectList = iBasicObjectRepository.GetFiltered(b => b.ParentUuid == basicObject.Uuid).ToList();
             
                List<ActivityCountCode> ActivityCountCodeList =new List<ActivityCountCode>();

                ActivityCountCode activityCount = new ActivityCountCode();
                activityCount.Name = "请选择";
                activityCount.Code = "";
                ActivityCountCodeList.Add(activityCount);
                if (activityId == "ActivityCount")
                {
                    foreach (var item in basicObjectList)
                    {
                        ActivityCountCode activityCountCode = new ActivityCountCode();
                        activityCountCode.Name = item.Name;
                        activityCountCode.Code = item.Code.ToString();
                        ActivityCountCodeList.Add(activityCountCode);
                    }
                }
                if (activityId == "WasteType")
                {
                    foreach (var item in basicObjectList)
                    {
                        ActivityCountCode activityCountCode = new ActivityCountCode();
                        activityCountCode.Name = item.Name;
                        activityCountCode.Code = item.Uuid.ToString();
                        ActivityCountCodeList.Add(activityCountCode);
                    }
                
                }
               

                string str=JsonConvert.SerializeObject(ActivityCountCodeList);


                return Json(str, JsonRequestBehavior.AllowGet);

              
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"没有查询到桶的信息。\"}", JsonRequestBehavior.AllowGet);
            }
        }
    }
}
