﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using NET01.CoreFramework;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using RWIS.Domain.DomainObjects.View.Support;
namespace RWIS.Presentation.Web.Areas.Activity.Controllers
{
    public class CoreController : Controller
    {
        //
        // GET: /Activity/Core/

        #region 构造函数
        IBasicObjectRepository iBasicObjectRepository;
        CommonHelper commonHelper = new CommonHelper();
        INuclearBucketRepository iNuclearBucketRepository;
        INuclearElementRepository iNuclearElementRepository;

        IActivityCoreRepository iActivityCoreRepository;
        IActivityCoreDetailRepository iActivityCoreDetailRepository;
        ISupportEdsRepository iSupportEdsRepository;
        public CoreController(IBasicObjectRepository _iBasicObjectRepository, INuclearBucketRepository _iNuclearBucketRepository
            , INuclearElementRepository _iNuclearElementRepository
            , IActivityCoreRepository _iActivityCoreRepository
            , IActivityCoreDetailRepository _iActivityCoreDetailRepository
            , ISupportEdsRepository _iSupportEdsRepository)
        {
            this.iBasicObjectRepository = _iBasicObjectRepository;
            this.iNuclearBucketRepository = _iNuclearBucketRepository;
            this.iNuclearElementRepository = _iNuclearElementRepository;
            this.iActivityCoreRepository = _iActivityCoreRepository;
            this.iActivityCoreDetailRepository = _iActivityCoreDetailRepository;
            this.iSupportEdsRepository = _iSupportEdsRepository;
        }
        #endregion

        #region 页面初始化
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "多芯桶页面")]
        public ActionResult Index(string strId, string isView, string pageIndex)
        {
            CoreVM coreVM = new CoreVM();
            ActivityCore activityCore = new ActivityCore();

            //编辑模式
            coreVM.IsVeiw = "0";//编辑

            coreVM.StationList = commonHelper.GetStationList();
            coreVM.WasteTypeList = commonHelper.GetSelectItemUuIdByStrName("NuClearType");

            //保存当前页数
            coreVM.PageIndex = pageIndex;

            //strId为空新增
            if (!string.IsNullOrEmpty(strId))
            {
                activityCore = iActivityCoreRepository.Get(strId);
                //将桶Id转为桶编号
                activityCore.BucketId = iNuclearBucketRepository.GetCodeById(activityCore.BucketId, AppContext.CurrentUser.ProjectCode);

                //将id转成能谱序号
                SupportEdsCondition condition = new SupportEdsCondition();
                condition.EdsId = activityCore.ElemAnalysisId;
                IQueryable<SupportEdsView> iqueryEds = iSupportEdsRepository.QueryList(condition);
                if (iqueryEds != null && iqueryEds.Count() > 0)
                {
                    SupportEdsView model = iqueryEds.ToList()[0];
                    coreVM.EdsCode = model.EdsSerialCode;
                    coreVM.WasteTypeName = model.WasteTypeName;
                }

                //查看模式
                if (isView == "1")
                {
                    coreVM.IsVeiw = "1";
                    coreVM.StationName = commonHelper.GetStationNameByCode(activityCore.Stationcode);
                    coreVM.WasteTypeName = commonHelper.GetSelectItemNameByUuId(activityCore.WasteTypeId, "NuClearType");
                }
            }
            coreVM.Activity = activityCore;

            //加载比例因子类型
            coreVM.FactorTypeList = new List<SelectListItem>();
            coreVM.FactorTypeList.Add(new SelectListItem { Text = "中广核PWR", Value = "CGN" });
            coreVM.FactorTypeList.Add(new SelectListItem { Text = "法国EDF", Value = "FRANCE" });
            coreVM.FactorTypeList.Add(new SelectListItem { Text = "美国NRC", Value = "AMERICAN" });
            coreVM.FactorTypeList.Add(new SelectListItem { Text = "其他核电", Value = "OTHER" });
            return View(coreVM);
        }
        #endregion

        #region 获取信息
        /// <summary>
        /// 获取核素数据
        /// </summary>
        /// <param name="bucketId">桶Id</param>
        /// <param name="edsId">能谱序号</param>
        /// <returns></returns>
        public JsonResult GetActivityDetailJson(CoreVM activityVM)
        {
            try
            {
                //将桶编号转为桶Id
                activityVM.Activity.BucketId = iNuclearBucketRepository.GetIdByCode(activityVM.Activity.BucketId, AppContext.CurrentUser.ProjectCode);
                List<ActivityCoreDetail> activityDetailList = CoreBuilder.BuilderActivityDetailInfo(activityVM);

                var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 100000000 };
                jqGridResponse.TotalRecordsCount = activityDetailList.Count;

                //平均剂量率
                decimal avgDoseRate = Convert.ToDecimal(activityVM.Activity.AvgDoseRate);

                //转换函数
                decimal transferFun = Convert.ToDecimal(activityVM.Activity.TransferFun);

                //推算伽玛核素活度,平均剂量率*转换函数
                decimal estimateGamActivity = avgDoseRate * transferFun;

                //科学计数法 
                decimal eNotation = estimateGamActivity;

                //补充计算之后活度
                decimal addCalcuActivity = Convert.ToDecimal(activityDetailList.Sum(e => e.ElementLevel));

                if (activityDetailList != null && activityDetailList.Count > 0)
                {
                    activityDetailList.ForEach(d =>
                    {
                        jqGridResponse.Records.Add(new JqGridRecord()
                        {
                            Id = d.CalcuLd,
                            List = new List<object>() 
                            {
                                d.CalcuLd,
                                iNuclearElementRepository.Get(d.ElementId).ElementName,
                                d.HalfLife,
                                d.InitialActivity,
                                String.Format("{0:00.00}",d.InitialActivityRate) ,
                                 commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                    d.CalcuLevel
                                    )
                                )
                                ,

                                 String.Format("{0:00.00}", d.CalcuLevelRate),

                                 commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                   d.ElementLevel
                                    )
                                )
                                ,
                                 commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                    d.SpecificActivity
                                    )
                                )
                                
                            }
                        });
                    });
                }
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = 99,
                    List = new List<object>() 
                            {
                                "99",
                                "",
                                "",
                                "合计:",
                                "",
                                commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                    activityDetailList.Sum(e => e.CalcuLevel)
                                    )
                                ),
                                //activityBucketDetailList.Sum(e => e.CalcuLevelRate),
                                100,
                                 commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                    activityDetailList.Sum(e => e.ElementLevel)
                                    )
                                ),
                                 commonHelper.StringFormatGetE(
                                Convert.ToDecimal(
                                    activityDetailList.Sum(e => e.SpecificActivity)
                                    )
                                ),
                                commonHelper.StringFormatAccurate(estimateGamActivity),
                                commonHelper.StringFormatAccurate(estimateGamActivity),
                                commonHelper.StringFormatAccurate(addCalcuActivity)
                            }
                });



                return jqGridResponse.ToJsonResult();
            }
            catch (Exception)
            {

                return null;
            }
        }

        #endregion

        #region 保存.草稿.确认信息

        /// <summary>
        /// 保存活度计算主表信息
        /// </summary>
        /// <param name="activityVM">实体</param>
        [HttpPost]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "多芯桶确认")]
        public JsonResult SaveActivityInfo(CoreVM activityVM, string status)
        {
            //if (!string.IsNullOrEmpty(activityVM.Activity.BucketId))
            //{
            //    ActivityCountCondition activityCountCondition = new ActivityCountCondition();
            //    IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition).Where(d => d.BucketCode == activityVM.Activity.BucketId);
            //    if (activityCountList.Count() > 0)
            //    {
            //        return JsonResultHelper.JsonResult(false, "桶号重复");
            //    }
            //}
            //将桶编号转为桶Id
            string bucketId = iNuclearBucketRepository.GetIdByCode(activityVM.Activity.BucketId, AppContext.CurrentUser.ProjectCode);
            string calcuId = "";//主表Id

            ActivityCore activity = new ActivityCore();
            activity = activityVM.Activity;
            activity.BucketId = bucketId;

            ////将能谱id转换能谱序号
            //string eId = iSupportEdsRepository.GetIdByCode(activityVM.Activity.ElemAnalysisId, AppContext.CurrentUser.ProjectCode);
            //activity.ElemAnalysisId = eId;
            if (!string.IsNullOrEmpty(activityVM.Activity.BucketId))
            {
                ActivityCountCondition activityCountCondition = new ActivityCountCondition();
                IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition).Where(d => d.BucketCode == activityVM.Activity.BucketId);
                if (activityCountList.Count() > 0)
                {
                    return JsonResultHelper.JsonResult(false, "桶号重复");
                }
            }
            //主键Id不存在就新增,存在就修改
            if (string.IsNullOrEmpty(activityVM.Activity.CalcuId))
            {
                activity.CalcuId = Guid.NewGuid().ToString();
                activity.Status = status;
                calcuId = activity.CalcuId;

                activity.CreateUserNo = AppContext.CurrentUser.UserId;
                activity.CreateUserName = AppContext.CurrentUser.UserName;
                activity.CreateDate = DateTime.Now;

                iActivityCoreRepository.Create(activity);
            }
            else
            {
                //修改状态
                activity.Status = status;

                //status == "2"确认时添加确认人信息
                if (status == "2")
                {
                    activity.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    activity.ConfirmUserName = AppContext.CurrentUser.UserName;
                    activity.ConfirmDate = DateTime.Now;
                }
                iActivityCoreRepository.Update(activity);

                //先删除明细表数据,再插入数据
                calcuId = activity.CalcuId;
                var query = iActivityCoreDetailRepository.GetAll().Where(c => c.CalcuLd == calcuId).AsQueryable();
                if (query.Count() > 0)
                {
                    List<ActivityCoreDetail> activityBucketDetail = query.ToList();
                    foreach (var item in activityBucketDetail)
                    {
                        iActivityCoreDetailRepository.Delete(item);
                    }
                }
            }
            //activityBucketVM的桶编号已转为桶Id
            List<ActivityCoreDetail> activityBucketDetailList = CoreBuilder.BuilderActivityDetailInfo(activityVM);
            //插入明细数据
            foreach (var item in activityBucketDetailList)
            {
                item.DetailId = Guid.NewGuid().ToString();
                item.CalcuLd = calcuId;
                iActivityCoreDetailRepository.Create(item);
            }
            iActivityCoreRepository.UnitOfWork.Commit();

            return JsonResultHelper.JsonResult(true, "数据修改成功！");
        }
        #endregion
    }
}
