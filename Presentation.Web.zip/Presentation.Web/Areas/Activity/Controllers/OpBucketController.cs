﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using NET01.CoreFramework;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using Newtonsoft.Json;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using RWIS.Domain.DomainObjects.View.Support;

namespace RWIS.Presentation.Web.Areas.Activity.Controllers
{
    public class OpBucketController : Controller
    {
        //
        // GET: /Activity/OpBucket/

        #region 构造函数
        IBasicObjectRepository iBasicObjectRepository;
        CommonHelper commonHelper = new CommonHelper();
        INuclearBucketRepository iNuclearBucketRepository;
        INuclearElementRepository iNuclearElementRepository;

        IActivityOpBucketRepository iActivityOpBucketRepository;
        IActivityOpBucketDetailRepository iActivityOpBucketDetailRepository;
        IActivityOpBuckethandleRepository iActivityOpBuckethandleRepository;
        IActivityBucketRepository iActivityBucketRepository;
        ISupportEdsRepository iSupportEdsRepository;
        IActivityCountViewRepository iActivityCountViewRepository;
        public OpBucketController(IBasicObjectRepository _iBasicObjectRepository, INuclearBucketRepository _iNuclearBucketRepository
            , INuclearElementRepository _iNuclearElementRepository
            , IActivityOpBucketRepository _iActivityOpBucketRepository
            , IActivityOpBucketDetailRepository _iActivityOpBucketDetailRepository
            , IActivityOpBuckethandleRepository _iActivityOpBuckethandleRepository
            , IActivityBucketRepository _iActivityBucketRepository
            , ISupportEdsRepository _iSupportEdsRepository
            , IActivityCountViewRepository _iActivityCountViewRepository)
        {
            this.iBasicObjectRepository = _iBasicObjectRepository;
            this.iBasicObjectRepository = _iBasicObjectRepository;
            this.iNuclearBucketRepository = _iNuclearBucketRepository;
            this.iNuclearElementRepository = _iNuclearElementRepository;
            this.iActivityOpBucketRepository = _iActivityOpBucketRepository;
            this.iActivityOpBucketDetailRepository = _iActivityOpBucketDetailRepository;
            this.iActivityOpBuckethandleRepository = _iActivityOpBuckethandleRepository;
            this.iActivityBucketRepository = _iActivityBucketRepository;
            this.iSupportEdsRepository = _iSupportEdsRepository;
            this.iActivityCountViewRepository = _iActivityCountViewRepository;
        }
        #endregion

        #region 页面初始化
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "400L超压桶页面")]
        public ActionResult Index(string strId, string isView, string pageIndex)
        {
            OpBucketVM opBucketVM = new OpBucketVM();
            ActivityOpBucket activityOpBucket = new ActivityOpBucket();

            //编辑模式
            opBucketVM.IsVeiw = "0";//编辑

            opBucketVM.StationList = commonHelper.GetStationList();
            opBucketVM.WasteTypeList = commonHelper.GetSelectItemUuIdByStrName("NuClearType");

            //保存当前页数
            opBucketVM.PageIndex = pageIndex;

            //strId为空新增
            if (!string.IsNullOrEmpty(strId))
            {
                activityOpBucket = iActivityOpBucketRepository.Get(strId);
                //将桶Id转为桶编号
                activityOpBucket.BucketId = iNuclearBucketRepository.GetCodeById(activityOpBucket.BucketId, AppContext.CurrentUser.ProjectCode);

                //将id转成能谱序号
                SupportEdsCondition condition = new SupportEdsCondition();
                condition.EdsId = activityOpBucket.ElemAnalysisId;
                IQueryable<SupportEdsView> iqueryEds = iSupportEdsRepository.QueryList(condition);
                if (iqueryEds != null && iqueryEds.Count() > 0)
                {
                    SupportEdsView model = iqueryEds.ToList()[0];
                    opBucketVM.EdsCode = model.EdsSerialCode;
                    opBucketVM.WasteTypeName = model.WasteTypeName;
                }

                //查看模式
                if (isView == "1")
                {
                    opBucketVM.IsVeiw = "1";
                    opBucketVM.StationName = commonHelper.GetStationNameByCode(activityOpBucket.Stationcode);
                    opBucketVM.WasteTypeName = commonHelper.GetSelectItemNameByUuId(activityOpBucket.WasteTypeId, "NuClearType");
                }
            }
            opBucketVM.Activity = activityOpBucket;

            //加载比例因子类型
            opBucketVM.FactorTypeList = new List<SelectListItem>();
            opBucketVM.FactorTypeList.Add(new SelectListItem { Text = "中广核PWR", Value = "CGN" });
            opBucketVM.FactorTypeList.Add(new SelectListItem { Text = "法国EDF", Value = "FRANCE" });
            opBucketVM.FactorTypeList.Add(new SelectListItem { Text = "美国NRC", Value = "AMERICAN" });
            opBucketVM.FactorTypeList.Add(new SelectListItem { Text = "其他核电", Value = "OTHER" });
            return View(opBucketVM);
        }
        #endregion

        #region 创建桶饼表头信息

        public JsonResult GetBucketHandleDetailJson()
        {
            try
            {
                //定义JqGiid类
                var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 1000000000, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

                //行ColNames  list
                List<string> listColNs = new List<string>();
                //行ColModels list
                List<MaterialStockDetailVM> listColMs = new List<MaterialStockDetailVM>();

                //表头
                //listColNs.Add("HANDLE_ID");
                //listColMs.Add(commonHelper.GetColMs("HandleId", true));

                listColNs.Add("桶饼信息");
                listColMs.Add(commonHelper.GetColMs("HandleName", false));

                listColNs.Add("桶号");
                listColMs.Add(commonHelper.GetColMs("BucketCode", false));

                listColNs.Add("桶重量(KN)");
                listColMs.Add(commonHelper.GetColMs("BucketWeight", false));

                listColNs.Add("平均剂量率(mSv/h)");
                listColMs.Add(commonHelper.GetColMs("AvgDoseRate", false));

                listColNs.Add("转换函数GBq/(mSv/h)");
                listColMs.Add(commonHelper.GetColMs("TransferFun", false));

                listColNs.Add("打包时间");
                listColMs.Add(commonHelper.GetColMs("StrPackageDate", false));

                listColNs.Add("相差天数(天)");
                listColMs.Add(commonHelper.GetColMs("DayNum", false));

                var resultObj = new
                {
                    ColNs = listColNs,
                    ColMs = listColMs
                };
                return Json(resultObj, JsonRequestBehavior.AllowGet);

            }
            catch (Exception)
            {

                return null;
            }
        }
        #endregion

        #region 获取信息
        /// <summary>
        /// 获取核素数据
        /// </summary>
        /// <param name="bucketId">桶Id</param>
        /// <param name="edsId">能谱序号</param>
        /// <returns></returns>
        public JsonResult GetActivityDetailJson(OpBucketVM activityVM, string list)
        {
            try
            {
                List<BucketHandle> bucketHandleList = JsonToList(list);

                //将桶编号转为桶Id
                activityVM.Activity.BucketId = iNuclearBucketRepository.GetIdByCode(activityVM.Activity.BucketId, AppContext.CurrentUser.ProjectCode);

                OpBucketVM vm = OpBucketBuilder.BuilderActivityDetailInfo(activityVM, bucketHandleList); ;
                List<ActivityOpBucketDetail> activityDetailList = vm.ActivityDetailList;

                var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 100000000 };
                jqGridResponse.TotalRecordsCount = activityDetailList.Count;

                //推算伽玛核素活度
                decimal gamActivity = Convert.ToDecimal(vm.GamActivity);

                //补充计算之后活度
                decimal addCalcuActivity = Convert.ToDecimal(activityDetailList.Sum(e => e.TotalActivity));

                if (activityDetailList != null && activityDetailList.Count > 0)
                {
                    activityDetailList.ForEach(d =>
                    {
                        jqGridResponse.Records.Add(new JqGridRecord()
                        {
                            Id = d.DetailId,
                            List = new List<object>() 
                            {
                                iNuclearElementRepository.Get(d.ElementId).ElementName,
                                d.HalfLife,
                                commonHelper.StringFormatGetE(Convert.ToDecimal(d.TotalActivity)),
                                commonHelper.StringFormatGetE(Convert.ToDecimal(d.SpecificActivity)),
                                "",
                                ""
                            }
                        });
                    });
                }
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = 99,
                    List = new List<object>() 
                            {
                                "",
                                "合计:",
                                commonHelper.StringFormatGetE(Convert.ToDecimal(activityDetailList.Sum(e => e.TotalActivity))),
                                commonHelper.StringFormatGetE(Convert.ToDecimal(activityDetailList.Sum(e => e.SpecificActivity))),
                                commonHelper.StringFormatGetE(gamActivity),
                                commonHelper.StringFormatGetE(addCalcuActivity)
                            }
                });

                List<List<string>> actList = activityDetailList.Last().BukHandleList;
                //桶活度从2开始放置
                for (int i = 0; i < jqGridResponse.Records.Count - 1; i++)
                {
                    List<string> newList = new List<string>();
                    foreach (var item in actList[i])
                    {
                        newList.Add(commonHelper.StringFormatGetE(Convert.ToDecimal(item)));
                    }
                    jqGridResponse.Records[i].List.InsertRange(2, newList);
                }

                //将最后合计行的动态桶饼列补齐
                List<string> colTotal = new List<string>();
                for (int i = 0; i < actList[0].Count; i++)
                {
                    colTotal.Add("");
                }
                jqGridResponse.Records.Last().List.InsertRange(2, colTotal);

                return jqGridResponse.ToJsonResult();
            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion

        #region 保存.草稿.确认信息

        /// <summary>
        /// 保存活度计算主表信息
        /// </summary>
        /// <param name="activityVM">实体</param>
        [HttpPost]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "400L超压桶确认")]
        public JsonResult SaveActivityInfo(OpBucketVM activityVM, string status, string list)
        {
            List<BucketHandle> bucketHandleList = JsonToList(list);

            //if (!string.IsNullOrEmpty(activityVM.Activity.BucketId))
            //{
            //    ActivityCountCondition activityCountCondition = new ActivityCountCondition();
            //    IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition).Where(d => d.BucketCode == activityVM.Activity.BucketId);
            //    if (activityCountList.Count() > 0)
            //    {
            //        return JsonResultHelper.JsonResult(false, "桶号重复");
            //    }
            //}
            //将桶编号转为桶Id
            string bucketId = iNuclearBucketRepository.GetIdByCode(activityVM.Activity.BucketId, AppContext.CurrentUser.ProjectCode);
            string calcuId = "";//主表Id

            ActivityOpBucket activity = new ActivityOpBucket();
            activity = activityVM.Activity;
            activity.BucketId = bucketId;
            if (!string.IsNullOrEmpty(activityVM.Activity.BucketId))
            {
                ActivityCountCondition activityCountCondition = new ActivityCountCondition();
                IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition).Where(d => d.BucketCode == activityVM.Activity.BucketId);
                if (activityCountList.Count() > 0)
                {
                    return JsonResultHelper.JsonResult(false, "桶号重复");
                }
            }
            
            //主键Id不存在就新增,存在就修改
            if (string.IsNullOrEmpty(activityVM.Activity.CalcuId))
            {
                activity.CalcuId = Guid.NewGuid().ToString();
                activity.Status = status;
                calcuId = activity.CalcuId;
                activity.CreateUserNo = AppContext.CurrentUser.UserId;
                activity.CreateUserName = AppContext.CurrentUser.UserName;
                activity.CreateDate = DateTime.Now;

                iActivityOpBucketRepository.Create(activity);
            }
            else
            {
                //修改状态
                activity.Status = status;

                //status == "2"确认时添加确认人信息
                if (status == "2")
                {
                    activity.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    activity.ConfirmUserName = AppContext.CurrentUser.UserName;
                    activity.ConfirmDate = DateTime.Now;
                }
                iActivityOpBucketRepository.Update(activity);

                //先删除明细表数据,再插入数据
                calcuId = activity.CalcuId;
                var query = iActivityOpBucketDetailRepository.GetAll().Where(c => c.CalcuId == calcuId).AsQueryable();
                if (query.Count() > 0)
                {
                    List<ActivityOpBucketDetail> activityBucketDetail = query.ToList();
                    foreach (var item in activityBucketDetail)
                    {
                        iActivityOpBucketDetailRepository.Delete(item);
                    }
                }

                //删除桶饼信息
                var hdquery = iActivityOpBuckethandleRepository.GetAll().Where(c => c.CalcuId == calcuId).AsQueryable();
                if (hdquery.Count() > 0)
                {
                    List<ActivityOpBuckethandle> activityOpBuckethandle = hdquery.ToList();
                    foreach (var item in activityOpBuckethandle)
                    {
                        iActivityOpBuckethandleRepository.Delete(item);
                    }
                }
            }

            //activityBucketVM的桶编号已转为桶Id
            OpBucketVM vm = OpBucketBuilder.BuilderActivityDetailInfo(activityVM, bucketHandleList);
            List<ActivityOpBucketDetail> activityBucketDetailList = vm.ActivityDetailList;
            //插入明细数据
            foreach (var item in activityBucketDetailList)
            {
                item.DetailId = Guid.NewGuid().ToString();
                item.CalcuId = calcuId;
                iActivityOpBucketDetailRepository.Create(item);
            }

            //插入桶饼信息
            for (int i = 0; i < bucketHandleList.Count; i++)
            {
                ActivityOpBuckethandle activityOpBuckethandle = new ActivityOpBuckethandle();
                activityOpBuckethandle.HandleId = Guid.NewGuid().ToString();
                //根据每个桶饼的code得到桶饼Id
                string strBucketId = iNuclearBucketRepository.GetIdByCode(bucketHandleList[i].ColumnsInfoList[0].BucketCode, AppContext.CurrentUser.ProjectCode);
                activityOpBuckethandle.BucketId = strBucketId;
                activityOpBuckethandle.CalcuId = activity.CalcuId;
                //Json字符串0:BucketCode,1:BucketWeight,2:AvgDoseRate,3:TransferFun,4:PackageDate,
                activityOpBuckethandle.BucketWeight = Convert.ToDecimal(bucketHandleList[i].ColumnsInfoList[1].Value);
                activityOpBuckethandle.AvgDoseRate = Convert.ToDecimal(bucketHandleList[i].ColumnsInfoList[2].Value);
                activityOpBuckethandle.TransferFun = Convert.ToDecimal(bucketHandleList[i].ColumnsInfoList[3].Value);
                activityOpBuckethandle.PackageDate = Convert.ToDateTime(bucketHandleList[i].ColumnsInfoList[4].Value);

                iActivityOpBuckethandleRepository.Create(activityOpBuckethandle);
            }
            try
            {
                iActivityOpBucketRepository.UnitOfWork.Commit();
            }
            catch (Exception)
            {

                throw;
            }
            return JsonResultHelper.JsonResult(true, "数据修改成功！");
        }
        #endregion

        #region 创建活度计算明细表头

        public JsonResult GetActivityDetailTabHeadJson(string list)
        {
            try
            {
                List<BucketHandle> bucketHandleList = JsonToList(list);

                //定义JqGiid类
                var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 1000000000, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

                //行ColNames  list
                List<string> listColNs = new List<string>();
                //行ColModels list
                List<MaterialStockDetailVM> listColMs = new List<MaterialStockDetailVM>();

                listColNs.Add("放射性核素");
                listColMs.Add(commonHelper.GetColMs("ElementId", false));

                listColNs.Add("半衰期(days)");
                listColMs.Add(commonHelper.GetColMs("HalfLife", false));

                for (int i = 0; i < bucketHandleList.Count; i++)
                {
                    listColNs.Add("桶饼" + (i + 1) + "初始活度(GBq)");
                    listColMs.Add(commonHelper.GetColMs("BucketHandle" + (i + 1), false));
                }

                listColNs.Add("总计活度(GBq)");
                listColMs.Add(commonHelper.GetColMs("TotalActivity", false));

                listColNs.Add("内容物质量比活度(MBq/Kg)");
                listColMs.Add(commonHelper.GetColMs("SpecificActivity", false));

                listColNs.Add("推算伽玛核素活度");
                listColMs.Add(commonHelper.GetColMs("GamActivity", true));

                listColNs.Add("补充计算之后活度");
                listColMs.Add(commonHelper.GetColMs("AddCalcuActivity", true));

                var resultObj = new
                {
                    ColNs = listColNs,
                    ColMs = listColMs
                };
                return Json(resultObj, JsonRequestBehavior.AllowGet);

            }
            catch (Exception)
            {

                return null;
            }
        }
        #endregion

        #region 自定义方法

        /// <summary>
        /// 将Json转换List
        /// </summary>
        /// <param name="list">前台json字符串</param>
        public List<BucketHandle> JsonToList(string list)
        {
            List<BucketHandle> bucketHandleList = new List<BucketHandle>();

            string strJson = list.Trim('[', ']');
            string[] strList = strJson.Replace("],[", "*").Split('*');
            for (int i = 0; i < strList.Count(); i++)
            {
                strList[i] = "[" + strList[i] + "]";
                List<ColumnsInfo> columnsInfoList = JsonConvert.DeserializeObject<List<ColumnsInfo>>(strList[i]);
                BucketHandle bucketHandle = new BucketHandle();
                bucketHandle.ColumnsInfoList = columnsInfoList;
                bucketHandleList.Add(bucketHandle);
            }
            return bucketHandleList;
        }

        public JsonResult GetAllBucket(string keyword)
        {
            string stationCode = AppContext.CurrentUser.ProjectCode;
            //全部桶号
            IQueryable<NuclearBucket> bucketlist = iNuclearBucketRepository.GetAll().AsQueryable();

            var nuList = from n in bucketlist
                          where n.Stationcode == stationCode && n.IsDrain == "1" && n.IsOutSend == null
                          select new AutoComplete
                          {
                              Name = n.BucketCode,
                              Code = n.BucketId
                          };
            //所有桶Id
            List<string> all = new List<string>();
            foreach (var item in nuList)
            {
                all.Add(item.Name);
            }
            //做过活度计算的桶Id
            List<string> some = new List<string>();

            //需要显示的桶Id
            List<string> query = new List<string>();

            List<AutoComplete> autoCompleteList =new List<AutoComplete>();

            //得到已做过活度计算的桶信息
            IQueryable<ActivityCountView> activityCountView = iActivityCountViewRepository.GetAll().AsQueryable();
            try
            {
                var actList = (from a in activityCountView
                               join n in bucketlist on a.BucketId equals n.BucketId
                              
                               select new AutoComplete
                               {
                                   Name = n.BucketCode,
                                   Code = a.BucketId
                               }).ToList();
                foreach (var item in actList)
                {
                    some.Add(item.Name);
                }
                query = all.Except(some).Where(n => n.Trim().Contains(keyword.Trim())).Take(10).ToList();
            }
            catch (Exception)
            {
                throw;
            }

            if (query.Count > 0)
            {
                for (int i = 0; i < query.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = query[i];
                    autoComplete.Code = query[i];
                    autoCompleteList.Add(autoComplete);
                }
            }

            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region 获取桶饼信息

        public JsonResult GetBucketHandleInfoById(OpBucketVM activityVM, string calId)
        {
            try
            {
                List<ActivityOpBuckethandle> activityOpBuckethandleList = new List<ActivityOpBuckethandle>();
                activityOpBuckethandleList = iActivityOpBuckethandleRepository.GetAll().Where(e => e.CalcuId == calId).ToList();

                for (int i = 0; i < activityOpBuckethandleList.Count; i++)
                {
                    activityOpBuckethandleList[i].BucketCode = iNuclearBucketRepository.GetCodeById(activityOpBuckethandleList[i].BucketId, AppContext.CurrentUser.ProjectCode);
                    double dayNum = (Convert.ToDateTime(activityVM.Activity.EffcetDate) - Convert.ToDateTime(activityOpBuckethandleList[i].PackageDate)).TotalDays;
                    activityOpBuckethandleList[i].DayNum = dayNum;
                    activityOpBuckethandleList[i].StrPackageDate = activityOpBuckethandleList[i].PackageDate.HasValue ? activityOpBuckethandleList[i].PackageDate.Value.ToString("yyyy-MM-dd") : string.Empty;
                }

                var resultObj = new
                {
                    activityOpBuckethandleList
                };
                return Json(resultObj, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {

                throw;
            }

        }
        #endregion
    }
}
