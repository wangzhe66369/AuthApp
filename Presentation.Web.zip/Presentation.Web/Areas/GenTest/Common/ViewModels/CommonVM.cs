﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.MaterialManage.Common.ViewModels
{
    public class CommonVM
    {
        /// <summary>
        /// 地点
        /// </summary>
        public List<SelectListItem> LocationList { get; set; }
    }
}