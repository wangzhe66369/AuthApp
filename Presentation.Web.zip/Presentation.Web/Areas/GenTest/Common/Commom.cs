﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.MaterialManage.Common.ViewModels;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;
using Microsoft.Practices.ServiceLocation;
using NET01.CoreFramework;

namespace RWIS.Presentation.Web.Areas.MaterialManage.Common
{
    public static class CommomMetod
    {
      
        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>
        public static CommonVM GetLoction()
        {
            IBasicObjectRepository _BasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            CommonVM vm = new CommonVM();
            //加载状态类型
            vm.LocationList = new List<SelectListItem>();
            IQueryable<BasicObject> locationListQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> locationList = new List<BasicObject>();
            if (locationListQuery.Count() > 0)
            {
                locationList = locationListQuery.ToList();
            }
            foreach (var item in locationList)
            {
                vm.LocationList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            return vm;
        }
    }
}