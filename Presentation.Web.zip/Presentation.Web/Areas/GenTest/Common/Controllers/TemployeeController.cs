/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   TemployeeControllers.cs
 *   描    述   ：   
 *   创 建 者   ：   创建人 
 *   创建日期   ：   2016-04-12 02:58:48
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-04-12 02:58:48    1.0.0.0    创建人       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Core.Filter;
using RWIS.Presentation.Web.Core;
using NET01.CoreFramework;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;

namespace RWIS.Presentation.Web.Areas.Controllers
{
    
    public class TemployeeController:CommonControllerBase
    {
    		ITemployeeRepository _TemployeeRepository;
    
            public TemployeeController(ITemployeeRepository _TemployeeRepository)
            {
                this._TemployeeRepository = _TemployeeRepository;
            }
    
    		[HttpGet]
            public ActionResult Add()
            {
                return View();
            }
    
    		[HttpGet]
            public ActionResult Edit(string id)
            {
                Temployee model = _TemployeeRepository.Get(id);
                return View("Edit", model);
            }
    
    		[HttpGet]
            public ActionResult DetailView(string id)
            {
               Temployee model = _TemployeeRepository.Get(id);
                return View("View", model);
            }
    
    		[HttpGet]
            public ActionResult Index()
            {
                return View();
            }
    
            [HttpPost]
            [ValidateAntiForgeryToken]
            public JsonResult Add(Temployee model, FormCollection formCollection)
            {
                if (!ModelState.IsValid)
                {
                    return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
                }
                
                try
                {
                    model.Id = Guid.NewGuid().ToString();
                    this._TemployeeRepository.Create(model);
                    this._TemployeeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    this.Log.LogError(ex);
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
    
    		[HttpPost]
            [ValidateAntiForgeryToken]
            public JsonResult Update(Temployee model, FormCollection formCollection)
            {
                if (!ModelState.IsValid)
                {
                    return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
                }
                
                try
                {
                    this._TemployeeRepository.Update(model);
                    this._TemployeeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                catch (Exception ex)
                {
                    this.Log.LogError(ex);
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
    
    		[HttpPost]
            public JsonResult Delete(string id)
            {
                try
                {
    				if (!string.IsNullOrEmpty(id))
                    {
                        string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (string idVal in idArr)
                        {
                            this._TemployeeRepository.DeleteById(idVal);
                        }
    					this._TemployeeRepository.UnitOfWork.Commit();
    					return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                    }else{
    					return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
    				}
                }
                catch (Exception ex)
                {
                    this.Log.LogError(ex);
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
    
    		public ActionResult GetPagerList(string usercode,string sord, int page, int rows, string sidx)
            {
                var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
    
                IQueryable<Temployee> data = this._TemployeeRepository.QueryList(usercode);
                //IQueryable<Temployee> data = this._TemployeeRepository.QueryList("code065563");
    
                var pagedViewModel = new PagedViewModel<Temployee>
                {
                    Query = data,
                    GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : SortDirection.Descending },
                    DefaultSortColumn = sidx,
                    Page = page,
                    PageSize = rows,
                }
                .Setup();
    
                jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
    
                pagedViewModel.PagedList.ToList().ForEach(d =>
                {
                    jqGridResponse.Records.Add(new JqGridRecord()
                    {
                        Id = d.Id,
                        List = new List<object>()  { 
                            d.Id,
    d.UserCode,
    d.UserName,
    d.Sex,
    d.Age,
    
                            }
                    });
                });
    
                return jqGridResponse.ToJsonResult();
            }
    				
    
    }
    
}


