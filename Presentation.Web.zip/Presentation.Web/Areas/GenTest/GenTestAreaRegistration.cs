﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.GenTest
{
    public class GenTestAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "GenTest";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "GenTest_default",
                "GenTest/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional },
                 new string[] { "RWIS.Presentation.Web.Areas.Controllers" }
            );
        }
    }
}
