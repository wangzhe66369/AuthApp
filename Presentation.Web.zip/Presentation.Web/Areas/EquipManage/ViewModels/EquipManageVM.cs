﻿/********************************************************************************
 *
 *   项目名称   ：   废物管理
 *   文 件 名   ：   EquipManageVM.cs
 *   描    述   ：   设备管理VM
 *   创 建 者   ：   PXMWAHY
 *   创建日期   ：   2016-01-08 11:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-01-08 11:00:00    1.0.0.0    PXMWAHY       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.ViewModels.Common;

namespace RWIS.Presentation.Web.Areas.EquipManage.ViewModels
{
    /// <summary>
    /// 设备管理VM
    /// </summary>
    public class EquipManageVM
    {
        /// <summary>
        /// 设备信息实体
        /// </summary>
        public EquipInfo EquipInfo { get; set; }

        /// <summary>
        /// 设备状态实体
        /// </summary>
        public EquipDetail EquipDetail { get; set; }

        /// <summary>
        /// 设备分类
        /// </summary>
        public List<SelectListItem> EquipTypeIdList { get; set; }

        /// <summary>
        /// 单位TypeStatus
        /// </summary>
        public List<SelectListItem> UnitIdList { get; set; }

        /// <summary>
        /// 状态类型
        /// </summary>
        public List<SelectListItem> TypeStatusList { get; set; }

        /// <summary>
        /// 可用性
        /// </summary>
        public List<SelectListItem> UsabilityList { get; set; }

        /// <summary>
        /// 编辑时显示可用性
        /// </summary>
        public List<SelectListItem> RodiodList { get; set; }

        /// <summary>
        /// 上传照片
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> EquipInfoFiles { get; set; }
        public UploadFileListVM UploadFileListVM { get; set; }
        /// <summary>
        /// 单位名称
        /// </summary>
        public string UuidName { get; set; }

        /// <summary>
        /// 设备分类名称
        /// </summary>
        public string EquipTypeName { get; set; }

        /// <summary>
        /// 使用寿命
        /// </summary>
        public string UseDays { get; set; }

        /// <summary>
        /// 设备状态类型名称
        /// </summary>
        public string TypeStatusName { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }

        public decimal OldDetailNum { get; set; }
        /// <summary>
        /// 设备名称
        /// </summary>
        public string EquipName { get; set; }
        /// <summary>
        /// 功能位置
        /// </summary>
        public string FunctionPosition { get; set; }
    }
}