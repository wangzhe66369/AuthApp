﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   EquipDetailController.cs
 *   描    述   ：   EquipDetailController
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using RWIS.Presentation.Web.Areas.EquipManage.ViewModels;
using NET01.CoreFramework;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Domain.DomainObjects.View.EquipManage;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.EquipManage.Controllers
{
    /// <summary>
    /// 设备状态Controller
    /// </summary>
    public class EquipDetailController : Controller
    {
        IEquipDetailRepository _EquipDetailRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IEquipInfoRepository _EquipInfoRepository;
        public EquipDetailController(IEquipDetailRepository _EquipDetailRepository, IBasicObjectRepository _BasicObjectRepository, IEquipInfoRepository _EquipInfoRepository)
        {
            this._EquipDetailRepository = _EquipDetailRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._EquipInfoRepository = _EquipInfoRepository;
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "设备信息页面")]
        public ActionResult Index()
        {
            return View();
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "设备状态页面")]
        public ActionResult EquipDetailStatus(string id)
        {
            EquipManageVM vm = new EquipManageVM();
            vm.OperationList = CommonHelper.GetOperationList("Equip_Detail");
            vm.EquipInfo = _EquipInfoRepository.Get(id);
            if (vm.EquipInfo == null)
            {
                vm.EquipInfo = new EquipInfo();
            }
            vm.EquipInfo.EquipId = id;
            //加载可用性
            vm.UsabilityList = new List<SelectListItem>();
            vm.UsabilityList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.UsabilityList.Add(new SelectListItem { Text = "可用", Value = "1" });
            vm.UsabilityList.Add(new SelectListItem { Text = "不可用", Value = "0" });
            //加载显示可用性
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "可用", Value = "1" });
            vm.RodiodList.Add(new SelectListItem { Text = "不可用", Value = "0" });
            //加载状态类型
            //vm.TypeStatusList = new List<SelectListItem>();
            IQueryable<BasicObject> typeStatusQuery = _BasicObjectRepository.GetSubobjectsByCode("EquipStatus",AppContext.CurrentUser.ProjectCode);
            if (typeStatusQuery != null)
            {
                List<BasicObject> typeStatusList = new List<BasicObject>();
                if (typeStatusQuery.Count() > 0)
                {
                    typeStatusList = typeStatusQuery.ToList();
                }
                //foreach (var item in typeStatusList)
                //{
                //    vm.TypeStatusList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                //}
                SelectList SelectList = new SelectList(typeStatusList, "Uuid", "Name");
                ViewData["EquipStatus"] = SelectList;
            }
            return View(vm);
        }
        public ActionResult DetailView(string id)
        {
            EquipManageVM vm = new EquipManageVM();
            EquipInfo model = _EquipInfoRepository.Get(id);
            vm.EquipInfo = _EquipInfoRepository.Get(id);
            if (vm.EquipInfo == null)
            {
                vm.EquipInfo = new EquipInfo();
            }
            vm.EquipInfo.EquipId = id;
            
            vm.EquipInfo = model;
            BasicObject basicObjectEquiptype = _BasicObjectRepository.Get(model.EquipTypeId);
            if (basicObjectEquiptype != null)
            {
                vm.EquipTypeName = basicObjectEquiptype.Name;
            }
            else {
                vm.EquipTypeName = "";
            }
            return View("DetailView", vm);
        }
        public ActionResult DetailStatusView(string id)
        {
            EquipDetail model = _EquipDetailRepository.Get(id);
            EquipManageVM vm = new EquipManageVM();
            vm.EquipInfo = _EquipInfoRepository.Get(model.EquipId);
            if (vm.EquipInfo == null)
            {
                vm.EquipInfo = new EquipInfo();
            }
            vm.EquipInfo.EquipId = vm.EquipInfo.EquipId;
            //加载可用性
            vm.UsabilityList = new List<SelectListItem>();
            vm.UsabilityList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.UsabilityList.Add(new SelectListItem { Text = "可用", Value = "1" });
            vm.UsabilityList.Add(new SelectListItem { Text = "不可用", Value = "0" });
            //加载显示可用性
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "可用", Value = "1", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "不可用", Value = "0" });
            //加载状态类型
            //vm.TypeStatusList = new List<SelectListItem>();
            IQueryable<BasicObject> typeStatusQuery = _BasicObjectRepository.GetSubobjectsByCode("TypeStatus",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> typeStatusList = new List<BasicObject>();
            if (typeStatusQuery!=null&&typeStatusQuery.Count() > 0)
            {
                typeStatusList = typeStatusQuery.ToList();
                SelectList SelectList = new SelectList(typeStatusList, "Uuid", "Name");
                ViewData["TypeStatus"] = SelectList;
            }
           
            vm.EquipDetail = model;
            BasicObject basicObjectTypeStatus = _BasicObjectRepository.Get(model.TypeStatus);
            if (basicObjectTypeStatus != null)
            {
                vm.TypeStatusName = basicObjectTypeStatus.Name;
            }
            else {
                vm.TypeStatusName = "";
            }
            return View("DetailStatusView", vm);
        }
        public ActionResult Add()
        {
            EquipManageVM vm = new EquipManageVM();

            //加载可用性
            vm.UsabilityList = new List<SelectListItem>();
            vm.UsabilityList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.UsabilityList.Add(new SelectListItem { Text = "可用", Value = "1" });
            vm.UsabilityList.Add(new SelectListItem { Text = "不可用", Value = "0" });
            //加载显示可用性
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "可用", Value = "1", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "不可用", Value = "0" });
            //加载状态类型
            //vm.TypeStatusList = new List<SelectListItem>();
            IQueryable<BasicObject> typeStatusQuery = _BasicObjectRepository.GetSubobjectsByCode("TypeStatus",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> typeStatusList = new List<BasicObject>();
            if (typeStatusQuery.Count() > 0)
            {
                typeStatusList = typeStatusQuery.ToList();
            }
            //foreach (var item in typeStatusList)
            //{
            //    vm.TypeStatusList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            //}
            SelectList SelectList = new SelectList(typeStatusList, "Uuid", "Name");
            ViewData["TypeStatus"] = SelectList;
            return View(vm);
        }

        [HttpGet]
        public ActionResult Edit(string id)
        {
            EquipManageVM vm = new EquipManageVM();
            //加载显示可用性
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "可用", Value = "1" });
            vm.RodiodList.Add(new SelectListItem { Text = "不可用", Value = "0" });
            EquipDetail model = _EquipDetailRepository.Get(id);
            vm.EquipDetail = model;
            return View("Edit", vm);
        }

        /// <summary>
        /// 查询设备信息列表
        /// </summary>
        /// <param name="equipDetailCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetEquipDetailList(EquipDetailCondition equipDetailCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<EquipView> data = this._EquipInfoRepository.QueryDetailList(equipDetailCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<EquipView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.EquipId,
                    List = new List<object>() {
                    d.EquipId,
                    d.FunctionPosition,
                    d.EquipType,
                    d.Bulk,
                    d.EquipSpec,
                    d.EquipType == "过滤器设备"?d.UpdateDate.HasValue?d.UpdateDate.Value.ToString("yyyy-MM-dd"):string.Empty:null,
                    (d.EquipType == "除盐床设备"||d.EquipType == "过滤器设备")?
                    d.UpdateDate.HasValue?
                    DateTime.Now.Date != d.UpdateDate?
                    (DateTime.Now.Date - d.UpdateDate).ToString().Substring(0,(DateTime.Now.Date - d.UpdateDate).ToString().IndexOf('.')):"0":null:null,
                    d.EquipType=="过滤器设备"?(d.ProductDate.HasValue?d.ProductDate.Value.ToString("yyyy-MM-dd"):""):string.Empty,
                     (d.EquipType == "除盐床设备"||d.EquipType == "过滤器设备")? (d.UpdateDate.HasValue? ((Convert.ToDateTime(DateTime.Now.ToString("yyy-MM-dd"))-Convert.ToDateTime(d.UpdateDate.Value.ToString("yyy-MM-dd"))).TotalDays>4*365?"是":"" ) :""):""
                    
                    }

                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult(); 
               
        }

        /// <summary>
        /// 查询设备状态列表
        /// </summary>
        /// <param name="equipDetailCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetEquipDetailNewList(EquipDetailCondition equipDetailCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<EquipDetailView> data = this._EquipDetailRepository.QueryList(equipDetailCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<EquipDetailView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DetailId,
                    List = new List<object>() {
                    d.DetailId,
                    d.TypeStatusName,
                    d.TypeStatus,
                    d.EventDesc,
                    d.DetailNum,
                    d.Usabilitys,
                    d.Usability,     
                    d.Status ,
                    d.EventDate.HasValue?d.EventDate.Value.ToString("yyyy-MM-dd"):string.Empty,
                    d.EventReason,
                    d.Treatment,
                    d.Remark,
                    d.CreateUserNo,
                    d.CreateUserName,
                    d.CreateDate
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 增加设备状态信息
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(EquipManageVM model, FormCollection formCollection)
        {

            try
            {
                if (model.EquipDetail.DetailId == null)
                {
                    model.EquipDetail.EquipId = model.EquipInfo.EquipId;
                    model.EquipDetail.Status = "0";//状态
                    model.EquipDetail.DetailId = Guid.NewGuid().ToString();
                    model.EquipDetail.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.EquipDetail.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.EquipDetail.CreateDate = DateTime.Now.Date;//创建时间
                    model.EquipDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._EquipDetailRepository.Create(model.EquipDetail);//提交数据库
                    this._EquipDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else 
                {
                    model.EquipDetail.EquipId = model.EquipInfo.EquipId;
                    model.EquipDetail.Status = "0";//状态 
                    model.EquipDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._EquipDetailRepository.Update(model.EquipDetail);//提交数据库
                    this._EquipDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除设备状态信息
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    EquipDetail equipDetail = this._EquipDetailRepository.Get(id);
                    if (equipDetail.Status == "2")
                    {
                        EquipInfo equipInfo = this._EquipInfoRepository.Get(equipDetail.EquipId);
                        //equipInfo.Bulk = equipInfo.Bulk + equipDetail.DetailNum; ;//记录体积容量
                        this._EquipInfoRepository.Update(equipInfo);//提交数据库     
                    }
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._EquipDetailRepository.DeleteById(idVal);
                    }
                    this._EquipDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        ///// <summary>
        ///// 编辑设备状态信息
        ///// </summary>
        ///// <param name="model">model</param>
        ///// <param name="formCollection"></param>
        ///// <returns></returns>
        //[HttpPost]
        //public JsonResult Edit(EquipManageVM model, FormCollection formCollection)
        //{
        //    try
        //    {
        //        //model.EquipDetail = _EquipDetailRepository.Get(model.EquipDetail.DetailId);
        //        //UpdateModel(model);
        //        model.EquipDetail.EquipId = model.EquipInfo.EquipId;
        //        model.EquipDetail.Status = "0";//状态 
        //        model.EquipDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
        //        this._EquipDetailRepository.Update(model.EquipDetail);//提交数据库
        //        this._EquipDetailRepository.UnitOfWork.Commit();
        //        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
        //    }
        //    catch
        //    {
        //        return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
        //    }
        //}

        /// <summary>
        /// 提交设备状态信息
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(EquipManageVM model, FormCollection formCollection)
        {
            //model.EquipDetail = _EquipDetailRepository.Get(model.EquipDetail.DetailId);
            //UpdateModel(model);
            try
            {
                if (model.EquipDetail.DetailId != null)
                {
                    model.EquipDetail.EquipId = model.EquipInfo.EquipId;
                    model.EquipDetail.Status = "1";//状态
                    model.EquipDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                    EquipInfo equipInfo = this._EquipInfoRepository.Get(model.EquipInfo.EquipId);
                    model.EquipDetail.CurrentNum = equipInfo.Bulk;//体积当前量
                    this._EquipDetailRepository.Update(model.EquipDetail);//提交数据库
                    this._EquipDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else if (model.EquipDetail.DetailId == null)
                {

                    model.EquipDetail.DetailId = Guid.NewGuid().ToString();
                    model.EquipDetail.EquipId = model.EquipInfo.EquipId;
                    model.EquipDetail.Status = "1";//状态
                    model.EquipDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.EquipDetail.CreateUserName = AppContext.CurrentUser.UserName;
                    model.EquipDetail.CreateDate = DateTime.Now.Date;
                    model.EquipDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                    EquipInfo equipInfo = this._EquipInfoRepository.Get(model.EquipInfo.EquipId);
                    model.EquipDetail.CurrentNum = equipInfo.Bulk;//体积当前量
                    this._EquipDetailRepository.Create(model.EquipDetail);//提交数据库
                    this._EquipDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":true,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认设备状态信息
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "设备状态确认")]
        public JsonResult Confirm(EquipManageVM model, FormCollection formCollection)
        {
            try
            {
                if (model.EquipDetail.DetailId != null)
                {
                    model.EquipDetail.EquipId = model.EquipInfo.EquipId;
                    
                    model.EquipDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.EquipDetail.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.EquipDetail.ConfirmDate = DateTime.Now.Date;//确认时间
                    model.EquipDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._EquipDetailRepository.Update(model.EquipDetail);
                    EquipInfo equipInfo = this._EquipInfoRepository.Get(model.EquipInfo.EquipId);
                    if (model.EquipDetail.Status.Trim() == "已确认")
                    {
                        if (model.EquipDetail.DetailNum > model.OldDetailNum)
                        {
                            equipInfo.Bulk = equipInfo.Bulk + (model.EquipDetail.DetailNum - model.OldDetailNum);
                        }
                        else
                        {
                            equipInfo.Bulk = equipInfo.Bulk - (model.OldDetailNum - model.EquipDetail.DetailNum);
                        }
                    }
                    else
                    {
                        equipInfo.Bulk = equipInfo.Bulk + model.EquipDetail.DetailNum;
                    }
                    
                    model.EquipDetail.Status = "2";//状态
                    model.EquipDetail.CurrentNum = equipInfo.Bulk;//体积当前量
                    equipInfo.UpdateDate = model.EquipDetail.ConfirmDate;//更新时间
                    //UpdateDate.HasValue?d.UpdateDate.Value.ToString("yyyy-MM-dd"):string.Empty,
                    equipInfo.UpdateUserName = AppContext.CurrentUser.UserName;//更新人名称
                    equipInfo.UpdateUserNo = AppContext.CurrentUser.UserId;//更新人员工号
                    this._EquipInfoRepository.Update(equipInfo);//提交数据库                 
                    this._EquipDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else if (model.EquipDetail.DetailId == null)
                {
                    model.EquipDetail.DetailId = Guid.NewGuid().ToString();
                    model.EquipDetail.EquipId = model.EquipInfo.EquipId;
                    model.EquipDetail.Status = "2";
                    model.EquipDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.EquipDetail.CreateUserName = AppContext.CurrentUser.UserName;
                    model.EquipDetail.CreateDate = DateTime.Now.Date;
                    model.EquipDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.EquipDetail.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.EquipDetail.ConfirmDate = DateTime.Now.Date;//确认时间   
                    model.EquipDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                    EquipInfo equipInfo = this._EquipInfoRepository.Get(model.EquipInfo.EquipId);
                    equipInfo.Bulk = equipInfo.Bulk + model.EquipDetail.DetailNum;
                    model.EquipDetail.CurrentNum = equipInfo.Bulk;//体积当前量
                    equipInfo.UpdateDate = model.EquipDetail.ConfirmDate;//更新时间
                    equipInfo.UpdateUserName = AppContext.CurrentUser.UserName;//更新人名称
                    equipInfo.UpdateUserNo = AppContext.CurrentUser.UserId;//更新人员工号
                    this._EquipDetailRepository.Create(model.EquipDetail);//提交数据库  
                    this._EquipInfoRepository.Update(equipInfo);//提交数据库  
                    this._EquipDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
    }
}
