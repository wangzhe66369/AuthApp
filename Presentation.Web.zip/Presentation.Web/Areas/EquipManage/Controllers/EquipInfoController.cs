﻿/********************************************************************************
 *
 *   项目名称   ：   废物管理
 *   文 件 名   ：   BridgeFrameController.cs
 *   描    述   ：   设备信息Controller
 *   创 建 者   ：   PXMWAHY
 *   创建日期   ：   2015-12-28 11:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2015-12-28 11:00:00    1.0.0.0    PXMWAHY       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.EquipManage.ViewModels;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Domain.DomainObjects.View.EquipManage;
using RWIS.Presentation.Web.Core.Ftp;
using RWIS.Presentation.Web.Core;
using CIT.UPC.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using CIT.UPC.Domain.DomainObjects;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.EquipManage.Controllers
{
    /// <summary>
    /// 设备信息Controller
    /// </summary>
    public class EquipInfoController : Controller
    {
        IEquipInfoRepository _EquipInfoRepository;
        IBasicObjectRepository _BasicObjectRepository;
        ITrackLiquorRepository _TrackLiquorRepository;
        INuclearTrackResinRepository _NuclearTrackResinRepository;
        INuclearTrackElementRepository _NuclearTrackElementRepository;
        INuclearTrackFilterRepository _NuclearTrackFilterRepository;
        public EquipInfoController(IEquipInfoRepository _EquipInfoRepository, IBasicObjectRepository _BasicObjectRepository, ITrackLiquorRepository _TrackLiquorRepository
            , INuclearTrackResinRepository _NuclearTrackResinRepository, INuclearTrackElementRepository _NuclearTrackElementRepository, INuclearTrackFilterRepository _NuclearTrackFilterRepository)
        {
            this._EquipInfoRepository = _EquipInfoRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._TrackLiquorRepository = _TrackLiquorRepository;
            this._NuclearTrackResinRepository = _NuclearTrackResinRepository;
            this._NuclearTrackElementRepository = _NuclearTrackElementRepository;
            this._NuclearTrackFilterRepository = _NuclearTrackFilterRepository;
        }

        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "设备信息页面")]
        public ActionResult Index()
        {
            EquipManageVM vm = new EquipManageVM();
            vm.OperationList = CommonHelper.GetOperationList("Equip_Info");
            //加载设备分类
            vm.EquipTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> EquipTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Equiptype", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> equipTypeIdList = new List<BasicObject>();
            if (EquipTypeIdQuery!=null&&EquipTypeIdQuery.Count() > 0)
            {
                equipTypeIdList = EquipTypeIdQuery.ToList();
                vm.EquipTypeIdList.Add(new SelectListItem { Text = "请选择", Value = "" });
                foreach (var item in equipTypeIdList)
                {
                    vm.EquipTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            //SelectList SelectList = new SelectList(equipTypeIdList, "Uuid", "Name");
            //ViewData["Equiptype"] = SelectList;
            return View(vm);
        }
        public ActionResult Add()
        {
            EquipManageVM vm = new EquipManageVM();
            vm.OperationList = CommonHelper.GetOperationList("Equip_Info");
            ////加载设备分类
            IQueryable<BasicObject> EquipTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Equiptype",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> equipTypeIdList = new List<BasicObject>();
            if (EquipTypeIdQuery!=null&&EquipTypeIdQuery.Count() > 0)
            {
                equipTypeIdList = EquipTypeIdQuery.ToList();   
            }
            SelectList SelectList = new SelectList(equipTypeIdList, "Uuid", "Name");
            ViewData["Equiptype"] = SelectList;

            //加载单位
            vm.UnitIdList = new List<SelectListItem>();
            IQueryable<BasicObject> UnitIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Unit",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> unitIdList = new List<BasicObject>();
            if (UnitIdQuery!=null&&UnitIdQuery.Count() > 0)
            {
                unitIdList = UnitIdQuery.ToList();
                foreach (var item in unitIdList)
                {
                    vm.UnitIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
           
            return View(vm);
        }
        public ActionResult DetailView(string id)
        {
            EquipInfo model = _EquipInfoRepository.Get(id);
            EquipManageVM vm = new EquipManageVM();
            vm.EquipInfo = model; 
            BasicObject basicObjectUnit = _BasicObjectRepository.Get(model.UnitId);
            BasicObject basicObjectEquiptype = _BasicObjectRepository.Get(model.EquipTypeId);
            if (basicObjectUnit != null)
            {
                vm.UuidName = basicObjectUnit.Name;
            }
            else {
                vm.UuidName = "";
            }
            if (basicObjectEquiptype != null)
            {
                vm.EquipTypeName = basicObjectEquiptype.Name;
            }
            else {
                vm.EquipTypeName = "";
            }

            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "QuestionReport");
            vm.EquipInfoFiles = (List<AttachFile>)listAttachFile;
            ViewBag.BusinessType = "QuestionReport";
            return View("DetailView", vm);
        }
        [HttpGet]
        public ActionResult Edit(string id)
        {
            EquipManageVM vm = new EquipManageVM();
            vm.OperationList = CommonHelper.GetOperationList("Equip_Info");
            //加载设备分类
            IQueryable<BasicObject> EquipTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Equiptype", AppContext.CurrentUser.ProjectCode);  
            List<BasicObject> equipTypeIdList = new List<BasicObject>();
            if (EquipTypeIdQuery!=null&&EquipTypeIdQuery.Count() > 0)
            {
                equipTypeIdList = EquipTypeIdQuery.ToList();
                
            }
            SelectList SelectList = new SelectList(equipTypeIdList, "Uuid", "Name");
            ViewData["Equiptype"] = SelectList;
            //加载单位
            vm.UnitIdList = new List<SelectListItem>();
            IQueryable<BasicObject> UnitIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Unit", AppContext.CurrentUser.ProjectCode);  
            List<BasicObject> unitIdList = new List<BasicObject>();
            if (UnitIdQuery!=null&&UnitIdQuery.Count() > 0)
            {
                unitIdList = UnitIdQuery.ToList();
                foreach (var item in unitIdList)
                {
                    vm.UnitIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            

            EquipInfo model = _EquipInfoRepository.Get(id);
            vm.EquipInfo = model;
            vm.EquipName = model.EquipName;
            vm.FunctionPosition = model.FunctionPosition;
            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "QuestionReport");
            vm.EquipInfoFiles = (List<AttachFile>)listAttachFile;
            ViewBag.BusinessType = "QuestionReport";
            return View("Edit", vm);
        }

        public ActionResult ConfirmEquipInfo(string id)
        {
            EquipManageVM vm = new EquipManageVM();
            EquipInfo model = _EquipInfoRepository.Get(id);
            vm.EquipInfo = model;
            return View("ConfirmEquipInfo", model);
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetEquipInfoList(EquipInfoCondition equipInfoCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<EquipInfoView> data = this._EquipInfoRepository.QueryList(equipInfoCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode); 
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<EquipInfoView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.EquipId,
                    List = new List<object>() {
                    d.EquipId,
                    d.EquipName,
                    d.FunctionPosition,
                    d.GraphicPosition,
                    d.Purpose,                                     
                    //d.TechParameter,
                    d.EquipSpec,
                    d.ConfirmUserName,
                    d.ConfirmDate.HasValue?d.ConfirmDate.Value.ToString("yyyy-MM-dd"):string.Empty,
                    d.Remark,
                    d.Status       
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 新增设备信息
        /// </summary>
        /// <param name="equipmentComponent">设备对象</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(EquipManageVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            //if (this._EquipInfoRepository.IsRepeat(model.EquipInfo.EquipName, AppContext.CurrentUser.ProjectCode))
            //{
            //    return Json("{\"result\":false,\"msg\":\"您填写的设备名称已存在!\"}", JsonRequestBehavior.AllowGet);
            //}
            if (this._EquipInfoRepository.IsRepeats(model.EquipInfo.FunctionPosition, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的功能位置已存在!\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                model.EquipInfo.EquipId = Guid.NewGuid().ToString();
                model.EquipInfo.Status = "0";
                model.EquipInfo.Stationcode = AppContext.CurrentUser.ProjectCode;
                model.EquipInfo.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                model.EquipInfo.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                model.EquipInfo.CreateDate = DateTime.Now;//创建时间
                this._EquipInfoRepository.Create(model.EquipInfo);
                this._EquipInfoRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.EquipInfo.EquipId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        EquipInfo equipInfo = this._EquipInfoRepository.Get(idVal);
                        IQueryable<TrackLiquor> trackLiquor = this._TrackLiquorRepository.GetAll().Where(d => d.SystemCode == equipInfo.FunctionPosition).AsQueryable();
                        if (trackLiquor != null && trackLiquor.Count() > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"删除失败，该设备已被浓缩液源项废物占用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        IQueryable<NuclearTrackResin> nuclearTrackResin = this._NuclearTrackResinRepository.GetAll().Where(d => d.SystemCode == equipInfo.FunctionPosition).AsQueryable();
                        if (nuclearTrackResin != null && nuclearTrackResin.Count() > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"删除失败，该设备已被废树脂源项废物占用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        IQueryable<NuclearTrackElement> nuclearTrackElement = this._NuclearTrackElementRepository.GetAll().Where(d => d.SystemCode == equipInfo.FunctionPosition).AsQueryable();
                        if (nuclearTrackElement != null && nuclearTrackElement.Count() > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"删除失败，该设备已被废滤芯源项废物占用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        IQueryable<NuclearTrackFilter> nuclearTrackFilter = this._NuclearTrackFilterRepository.GetAll().Where(d => d.SystemCode == equipInfo.FunctionPosition).AsQueryable();
                        if (nuclearTrackFilter != null && nuclearTrackFilter.Count() > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"删除失败，该设备已被通风过滤器源项废物占用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        this._EquipInfoRepository.DeleteById(idVal);
                    }
                    this._EquipInfoRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 编辑设备信息
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Edit(EquipManageVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            string newEquipName = model.EquipName;
            string newFunctionPosition = model.FunctionPosition;
            //判断设备名称是否重复
            //if (model.EquipInfo.EquipName != newEquipName && this._EquipInfoRepository.IsRepeat(model.EquipInfo.EquipName, AppContext.CurrentUser.ProjectCode))
            //{
            //    return Json("{\"result\":false,\"msg\":\"您填写的设备名称已存在!\"}", JsonRequestBehavior.AllowGet);
            //}

            //判断功能位置是否重复
            if (model.EquipInfo.FunctionPosition != newFunctionPosition && this._EquipInfoRepository.IsRepeats(model.EquipInfo.FunctionPosition, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的功能位置已存在!\"}", JsonRequestBehavior.AllowGet);
            }
            model.EquipInfo = _EquipInfoRepository.Get(model.EquipInfo.EquipId);
            UpdateModel(model);
            try
            {
                model.EquipInfo.Status = "0";
                model.EquipInfo.ConfirmUserNo = null;
                model.EquipInfo.ConfirmUserName = null;
                model.EquipInfo.ConfirmDate = null;
                this._EquipInfoRepository.Update(model.EquipInfo);
                this._EquipInfoRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.EquipInfo.EquipId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交设备信息
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(EquipManageVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            string newEquipName = model.EquipName;
            string newFunctionPosition = model.FunctionPosition;
            //判断设备名称是否重复
            //if (model.EquipInfo.EquipName != newEquipName && this._EquipInfoRepository.IsRepeat(model.EquipInfo.EquipName, AppContext.CurrentUser.ProjectCode))
            //{
            //    return Json("{\"result\":false,\"msg\":\"您填写的设备名称已存在!\"}", JsonRequestBehavior.AllowGet);
            //}

            //判断功能位置是否重复
            if (model.EquipInfo.FunctionPosition != newFunctionPosition && this._EquipInfoRepository.IsRepeats(model.EquipInfo.FunctionPosition, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的功能位置已存在!\"}", JsonRequestBehavior.AllowGet);
            }
            model.EquipInfo = _EquipInfoRepository.Get(model.EquipInfo.EquipId);
            UpdateModel(model);
            try
            {
                if (model.EquipInfo.EquipId != null)
                {
                    //model.EquipInfo = _EquipInfoRepository.Get(model.EquipInfo.EquipId);
                    //UpdateModel(model);
                    model.EquipInfo.Status = "1";
                    model.EquipInfo.ConfirmUserNo = null;
                    model.EquipInfo.ConfirmUserName = null;
                    model.EquipInfo.ConfirmDate = null;
                    this._EquipInfoRepository.Update(model.EquipInfo);
                    this._EquipInfoRepository.UnitOfWork.Commit();
                    this.SaveAttachFile(model.EquipInfo.EquipId, "UploadOther", formCollection);
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else if (model.EquipInfo.EquipId == null)
                {
                    model.EquipInfo.EquipId = Guid.NewGuid().ToString();
                    model.EquipInfo.Status = "1";
                    model.EquipInfo.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.EquipInfo.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.EquipInfo.CreateUserName = AppContext.CurrentUser.UserName;
                    model.EquipInfo.CreateDate = DateTime.Now;
                    this._EquipInfoRepository.Create(model.EquipInfo);
                    this._EquipInfoRepository.UnitOfWork.Commit();
                    this.SaveAttachFile(model.EquipInfo.EquipId, "UploadOther", formCollection);
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":true,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认设备信息
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Confirm(EquipManageVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            string newEquipName = model.EquipName;
            string newFunctionPosition = model.FunctionPosition;
            //判断设备名称是否重复
            //if (model.EquipInfo.EquipName != newEquipName && this._EquipInfoRepository.IsRepeat(model.EquipInfo.EquipName, AppContext.CurrentUser.ProjectCode))
            //{
            //    return Json("{\"result\":false,\"msg\":\"您填写的设备名称已存在!\"}", JsonRequestBehavior.AllowGet);
            //}

            //判断功能位置是否重复
            if (model.EquipInfo.FunctionPosition != newFunctionPosition && this._EquipInfoRepository.IsRepeats(model.EquipInfo.FunctionPosition, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的功能位置已存在!\"}", JsonRequestBehavior.AllowGet);
            }
            model.EquipInfo = _EquipInfoRepository.Get(model.EquipInfo.EquipId); 
            UpdateModel(model);
            try
            {
                if (model.EquipInfo.EquipId != null)
                {
                    model.EquipInfo.Status = "2";
                    model.EquipInfo.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.EquipInfo.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.EquipInfo.ConfirmDate = DateTime.Now;
                    this._EquipInfoRepository.Update(model.EquipInfo);
                    this._EquipInfoRepository.UnitOfWork.Commit();
                    this.SaveAttachFile(model.EquipInfo.EquipId, "UploadOther", formCollection);
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else if (model.EquipInfo.EquipId == null)
                {
                    model.EquipInfo.EquipId = Guid.NewGuid().ToString();
                    model.EquipInfo.Status = "2";
                    model.EquipInfo.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.EquipInfo.CreateUserName = AppContext.CurrentUser.UserName;
                    model.EquipInfo.CreateDate = DateTime.Now;
                    model.EquipInfo.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.EquipInfo.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.EquipInfo.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.EquipInfo.ConfirmDate = DateTime.Now;
                    this._EquipInfoRepository.Create(model.EquipInfo);
                    this._EquipInfoRepository.UnitOfWork.Commit();
                    this.SaveAttachFile(model.EquipInfo.EquipId, "UploadOther", formCollection);
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "设备信息确认")]
        public JsonResult ConfirmEquipInfo(string EquipId, FormCollection formCollection)
        {
            try
            {
                EquipInfo model = this._EquipInfoRepository.Get(EquipId);
                if (model != null)
                {
                    model.Status = "2";
                    //model.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.ConfirmDate = DateTime.Now;
                    this._EquipInfoRepository.Update(model);
                    this._EquipInfoRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 附件
        /// </summary>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], "QuestionReport");
            }
            return null;
        }
        /// <summary>
        /// 下载文件
        /// 
        /// </summary>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }
    }
}

