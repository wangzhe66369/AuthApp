﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.EquipManage
{
    public class EquipManageAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "EquipManage";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "EquipManage_default",
                "EquipManage/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
