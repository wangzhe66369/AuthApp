﻿/********************************************************************************
 *
 *   项目名称   ：   核电废物信息系统
 *   文 件 名   ：   RubTransferVM.cs
 *   描    述   ：   RubTransferVM
 *   创 建 者   ：   郑浩宇 
 *   创建日期   ：   2016-09-13 12:01:45
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-13 12:01:45    1.0.0.0    郑浩宇       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.RubTransfer.Models
{
    /// <summary>
    /// RubTransferVM
    /// </summary>
    public class RubTransferVM
    {

        /// <summary>
        /// 废物运输实体
        /// </summary>
        public NuclearRubTrans NuclearRubTrans { get; set; }

        /// <summary>
        /// 废物运输详细实体
        /// </summary>
        public NuclearRubTransDetail NuclearRubTransDetail { get; set; }

        /// <summary>
        /// 物质来自下拉列表
        /// </summary>
        public List<SelectListItem> MatterFromList { get; set; }

        /// <summary>
        /// 物质来自
        /// </summary>
        public string MatterFromName { get; set; }

        /// <summary>
        /// 物质运往
        /// </summary>
        public string MatterToName { get; set; }

        /// <summary>
        /// 物质运往下拉列表
        /// </summary>
        public List<SelectListItem> MatterToList { get; set; }

        /// <summary>
        /// 页面寄存器
        /// </summary>
        public string RubTransDetails { get; set; }

        /// <summary>
        /// 权限验证
        /// </summary>
        public string OperationList { get; set; }
    }
}
