﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.RubTransfer
{
    public class RubTransferAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "RubTransfer";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "RubTransfer_default",
                "RubTransfer/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
