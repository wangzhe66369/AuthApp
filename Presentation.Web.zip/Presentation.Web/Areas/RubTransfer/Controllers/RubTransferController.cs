﻿/********************************************************************************
 *
 *   项目名称   ：   核电废物信息系统
 *   文 件 名   ：   RubTransferController.cs
 *   描    述   ：   RubTransferController
 *   创 建 者   ：   郑浩宇 
 *   创建日期   ：   2016-09-13 12:01:45
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-13 12:01:45    1.0.0.0    郑浩宇       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.PublicInfo.Models;
using MvcContrib.UI.Grid;
using NET01.Presentation.Web.Mvc.JqGrid;
using NET01.CoreFramework;
using RWIS.Domain.DomainObjects.View;

using RWIS.Presentation.Web.Core.Ftp;
using RWIS.Presentation.Web.Areas.RubTransfer.Models;
using RWIS.Domain.DomainObjects.View.RubTransfer;
using NPOI.XWPF.UserModel;
using NPOI.OpenXmlFormats.Wordprocessing;
using System.IO;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
 
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.SS.Util;
using RWIS.Presentation.Web.Core;


namespace RWIS.Presentation.Web.Areas.RubTransfer.Controllers
{
    public class RubTransferController : Controller
    {
        INuclearRubTransDetailRepository _NuclearRubTransDetailRepository;
        INuclearRubTransRepository _NuclearRubTransRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;

        public RubTransferController(INuclearWastePackageRepository _NuclearWastePackageRepository,INuclearRubTransDetailRepository _NuclearRubTransDetailRepository, INuclearRubTransRepository _NuclearRubTransRepository, IBasicObjectRepository _BasicObjectRepository)
        {
            this._NuclearRubTransDetailRepository = _NuclearRubTransDetailRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearRubTransRepository = _NuclearRubTransRepository;
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
        }

       [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物运输")]
        public ActionResult Index()
        {
            RubTransferVM vm = new RubTransferVM();
            vm.OperationList = CommonHelper.GetOperationList("Rub_Transfer");//权限控制


            vm.MatterFromList = new List<SelectListItem>();
            vm.MatterToList = new List<SelectListItem>();
            IQueryable<BasicObject> MatterFromQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> matterFromList = new List<BasicObject>();


            IQueryable<BasicObject> matterToQuery = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> matterToList = new List<BasicObject>();
            if (MatterFromQuery.Count() > 0)
            {
                matterFromList = MatterFromQuery.ToList();
                matterToList = matterToQuery.ToList();
                matterFromList.AddRange(matterToList);
            }
            foreach (var item in matterFromList)
            {
                vm.MatterFromList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            foreach (var item in matterFromList)
            {
                vm.MatterToList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            ////加载物质来自下拉列表
            //vm.MatterFromList = new List<SelectListItem>();
            //IQueryable<BasicObject> MatterFromQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            //List<BasicObject> matterFromList = new List<BasicObject>();
            //if (MatterFromQuery.Count() > 0)
            //{
            //    matterFromList = MatterFromQuery.ToList();
            //}
            //foreach (var item in matterFromList)
            //{
            //    vm.MatterFromList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            //}


            ////加载物质运往下拉列表
            //vm.MatterToList = new List<SelectListItem>();
            //IQueryable<BasicObject> matterToQuery = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition",AppContext.CurrentUser.ProjectCode);
            //List<BasicObject> matterToList = new List<BasicObject>();
            //if (matterToQuery!=null && matterToQuery.Count() > 0)
            //{
            //    matterToList = matterToQuery.ToList();
            //}
            //foreach (var item in matterToList)
            //{
            //    vm.MatterToList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            //}
            return View(vm);
        }

        public ActionResult Add()
        {
            RubTransferVM vm = new RubTransferVM();
            vm.OperationList = CommonHelper.GetOperationList("Rub_Transfer");//权限控制

            vm.MatterFromList = new List<SelectListItem>();
            vm.MatterToList = new List<SelectListItem>();
            IQueryable<BasicObject> MatterFromQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> matterFromList = new List<BasicObject>();


            IQueryable<BasicObject> matterToQuery = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> matterToList = new List<BasicObject>();
            if (MatterFromQuery.Count() > 0)
            {
                matterFromList = MatterFromQuery.ToList();
                matterToList = matterToQuery.ToList();
                matterFromList.AddRange(matterToList);
            }
            foreach (var item in matterFromList)
            {
                vm.MatterFromList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            foreach (var item in matterFromList)
            {
                vm.MatterToList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            ////加载物质来自下拉列表
            //vm.MatterFromList = new List<SelectListItem>();
            //IQueryable<BasicObject> MatterFromQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            //List<BasicObject> matterFromList = new List<BasicObject>();
            //if (MatterFromQuery.Count() > 0)
            //{
            //    matterFromList = MatterFromQuery.ToList();
            //}
            //foreach (var item in matterFromList)
            //{
            //    vm.MatterFromList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            //}


            ////加载物质运往下拉列表
            //vm.MatterToList = new List<SelectListItem>();
            //IQueryable<BasicObject> matterToQuery = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition",AppContext.CurrentUser.ProjectCode);
            //List<BasicObject> matterToList = new List<BasicObject>();
            //if (matterToQuery!=null && matterToQuery.Count() > 0)
            //{
            //    matterToList = matterToQuery.ToList();
            //}
            //foreach (var item in matterToList)
            //{
            //    vm.MatterToList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            //}
            return View(vm);
        }

        public ActionResult Edit(string id)
        {
            RubTransferVM vm = new RubTransferVM();
            vm.OperationList = CommonHelper.GetOperationList("Rub_Transfer");//权限控制

            vm.MatterFromList = new List<SelectListItem>();
            vm.MatterToList = new List<SelectListItem>();
            IQueryable<BasicObject> MatterFromQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> matterFromList = new List<BasicObject>();


            IQueryable<BasicObject> matterToQuery = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> matterToList = new List<BasicObject>();
            if (MatterFromQuery.Count() > 0)
            {
                matterFromList = MatterFromQuery.ToList();
                matterToList = matterToQuery.ToList();
                matterFromList.AddRange(matterToList);
            }
            foreach (var item in matterFromList)
            {
                vm.MatterFromList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            foreach (var item in matterFromList)
            {
                vm.MatterToList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            ////加载物质来自下拉列表
            //vm.MatterFromList = new List<SelectListItem>();
            //IQueryable<BasicObject> MatterFromQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            //List<BasicObject> matterFromList = new List<BasicObject>();
            //if (MatterFromQuery.Count() > 0)
            //{
            //    matterFromList = MatterFromQuery.ToList();
            //}
            //foreach (var item in matterFromList)
            //{
            //    vm.MatterFromList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            //}

            ////加载物质运往下拉列表
            //vm.MatterToList = new List<SelectListItem>();
            //IQueryable<BasicObject> matterToQuery = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition",AppContext.CurrentUser.ProjectCode);
            //List<BasicObject> matterToList = new List<BasicObject>();
            //if (matterToQuery!=null && matterToQuery.Count() > 0)
            //{
            //    matterToList = matterToQuery.ToList();
            //}
            //foreach (var item in matterToList)
            //{
            //    vm.MatterToList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            //}
            NuclearRubTrans model = _NuclearRubTransRepository.Get(id);
            vm.NuclearRubTrans = model;
            return View("Edit", vm);
        }

       new public ActionResult View(string id)
        {
            RubTransferVM vm = new RubTransferVM();
            NuclearRubTrans model = _NuclearRubTransRepository.Get(id);
            vm.NuclearRubTrans = model;
            BasicObject BasicObject = new BasicObject();
            BasicObject basicObjectMatterFrom = _BasicObjectRepository.Get(model.MatterFrom);
            BasicObject basicObjectMatterTo = _BasicObjectRepository.Get(model.MatterFrom);

            vm.MatterFromName = basicObjectMatterFrom.Name;
            vm.MatterToName = basicObjectMatterTo.Name;


            return View(vm);
        }

        public ActionResult AddDetail(RubTransferVM model, FormCollection formCollection)
        {
            string packageId = this._NuclearWastePackageRepository.IsExist(model.NuclearRubTransDetail.PackageId, AppContext.CurrentUser.ProjectCode);
            if (string.IsNullOrEmpty(packageId))
            {
                return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
            }
            model.NuclearRubTransDetail.PackageId = packageId;
            return View(model);
        }

        [HttpGet]
        public ActionResult Commit(string id)
        {
            RubTransferVM vm = new RubTransferVM();
            NuclearRubTransDetail model = _NuclearRubTransDetailRepository.Get(id);
            vm.NuclearRubTransDetail = model;
            return View("Commit", vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Save(RubTransferVM model, FormCollection formCollection)
        {
           

            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubTrans.TransId))
                {
                    //新增废物运输主单
                    model.NuclearRubTrans.TransId = Guid.NewGuid().ToString();
                    model.NuclearRubTrans.CreateDate = DateTime.Now;
                    model.NuclearRubTrans.CreateUserName = AppContext.CurrentUser.UserName;
                    model.NuclearRubTrans.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearRubTrans.Status = "0";
                    model.NuclearRubTrans.Stationcode = AppContext.CurrentUser.ProjectCode;
                    string evalNuclearRubTrans_RadioactionLabel = Request.Form["NuclearRubTrans_RadioactionLabel"];
                    if (evalNuclearRubTrans_RadioactionLabel == "1")
                        model.NuclearRubTrans.RadioactionLabel = "1";
                    else
                        model.NuclearRubTrans.RadioactionLabel = "0";

                    string evalNuclearRubTrans_RadiationFlag = Request.Form["NuclearRubTrans_RadiationFlag"];
                    if (evalNuclearRubTrans_RadiationFlag == "1")
                        model.NuclearRubTrans.RadiationFlag = "1";
                    else
                        model.NuclearRubTrans.RadiationFlag = "0";

                    string evalNuclearRubTrans_TransRight = Request.Form["NuclearRubTrans_TransRight"];
                    if (evalNuclearRubTrans_TransRight == "1")
                        model.NuclearRubTrans.TransRight = "1";
                    else
                        model.NuclearRubTrans.TransRight = "0";

                    string evalNuclearRubTrans_TransTld = Request.Form["NuclearRubTrans_TransTld"];
                    if (evalNuclearRubTrans_TransTld == "1")
                        model.NuclearRubTrans.TransTld = "1";
                    else
                        model.NuclearRubTrans.TransTld = "0";

                    string evalNuclearRubTrans_TakePlace = Request.Form["NuclearRubTrans_TakePlace"];
                    if (evalNuclearRubTrans_TakePlace == "1")
                        model.NuclearRubTrans.TakePlace = "1";
                    else
                        model.NuclearRubTrans.TakePlace = "0";

                    string evalNuclearRubTrans_PoppulateLevel = Request.Form["NuclearRubTrans_PoppulateLevel"];
                    if (evalNuclearRubTrans_PoppulateLevel == "1")
                        model.NuclearRubTrans.PoppulateLevel = "1";
                    else
                        model.NuclearRubTrans.PoppulateLevel = "0";

                    string evalMeter = Request.Form["Meter"];
                    if (evalMeter == "1")
                        model.NuclearRubTrans.Meter = "1";
                    else
                        model.NuclearRubTrans.Meter = "0";

                    string evalSurfacePollution = Request.Form["SurfacePollution"];
                    if (evalSurfacePollution == "1")
                        model.NuclearRubTrans.SurfacePollution = "1";
                    else
                        model.NuclearRubTrans.SurfacePollution = "0";

                    this._NuclearRubTransRepository.Create(model.NuclearRubTrans);
                    if (!string.IsNullOrEmpty(model.RubTransDetails))
                    {
                        //新增金属验收单明细
                        string[] arrNuclearRubTransD = model.RubTransDetails.Split(';');
                        for (int i = 0; i < arrNuclearRubTransD.Length; i++)
                        {
                            NuclearRubTransDetail NuclearRubTransDetail = new NuclearRubTransDetail();
                            string[] arrNuclearRubTransDetail = arrNuclearRubTransD[i].Split(',');
                            if (arrNuclearRubTransDetail.Length == 9)
                            {
                                NuclearRubTransDetail.TransDetailId = Guid.NewGuid().ToString();
                                NuclearRubTransDetail.TransId = model.NuclearRubTrans.TransId;
                                NuclearRubTransDetail.PackageCondition = arrNuclearRubTransDetail[1];
                                NuclearRubTransDetail.MatterSource = arrNuclearRubTransDetail[2];
                                NuclearRubTransDetail.SullySurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[3]);
                                NuclearRubTransDetail.DoseSurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[4]);
                                NuclearRubTransDetail.SullySurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[5]);
                                NuclearRubTransDetail.DoseSurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[6]);
                                NuclearRubTransDetail.PackageId = arrNuclearRubTransDetail[7];

                                //判断废物货包id是否存在
                                string packageId = this._NuclearWastePackageRepository.IsExist(model.NuclearRubTransDetail.PackageId, AppContext.CurrentUser.ProjectCode);
                                if (string.IsNullOrEmpty(packageId))
                                {
                                    return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                                }
                                model.NuclearRubTransDetail.PackageId = packageId;

                                NuclearRubTransDetail.Remark = arrNuclearRubTransDetail[8];

                                NuclearRubTransDetail.CreateDate = DateTime.Now;
                                NuclearRubTransDetail.CreateUserName = AppContext.CurrentUser.UserName;
                                NuclearRubTransDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                                NuclearRubTransDetail.Status = "0";
                                NuclearRubTransDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                                this._NuclearRubTransDetailRepository.Create(NuclearRubTransDetail);
                            }
                        }

                    }

                    //提交
                    this._NuclearRubTransDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }
                //修改完新增
                else
                {
                    model.NuclearRubTrans = _NuclearRubTransRepository.Get(model.NuclearRubTrans.TransId);
                    UpdateModel(model);

                    model.NuclearRubTrans.Status = "0";
                    string evalNuclearRubTrans_RadioactionLabel = Request.Form["NuclearRubTrans_RadioactionLabel"];
                    if (evalNuclearRubTrans_RadioactionLabel == "1")
                        model.NuclearRubTrans.RadioactionLabel = "1";
                    else
                        model.NuclearRubTrans.RadioactionLabel = "0";

                    string evalNuclearRubTrans_RadiationFlag = Request.Form["NuclearRubTrans_RadiationFlag"];
                    if (evalNuclearRubTrans_RadiationFlag == "1")
                        model.NuclearRubTrans.RadiationFlag = "1";
                    else
                        model.NuclearRubTrans.RadiationFlag = "0";

                    string evalNuclearRubTrans_TransRight = Request.Form["NuclearRubTrans_TransRight"];
                    if (evalNuclearRubTrans_TransRight == "1")
                        model.NuclearRubTrans.TransRight = "1";
                    else
                        model.NuclearRubTrans.TransRight = "0";

                    string evalNuclearRubTrans_TransTld = Request.Form["NuclearRubTrans_TransTld"];
                    if (evalNuclearRubTrans_TransTld == "1")
                        model.NuclearRubTrans.TransTld = "1";
                    else
                        model.NuclearRubTrans.TransTld = "0";

                    string evalNuclearRubTrans_TakePlace = Request.Form["NuclearRubTrans_TakePlace"];
                    if (evalNuclearRubTrans_TakePlace == "1")
                        model.NuclearRubTrans.TakePlace = "1";
                    else
                        model.NuclearRubTrans.TakePlace = "0";

                    string evalNuclearRubTrans_PoppulateLevel = Request.Form["NuclearRubTrans_PoppulateLevel"];
                    if (evalNuclearRubTrans_PoppulateLevel == "1")
                        model.NuclearRubTrans.PoppulateLevel = "1";
                    else
                        model.NuclearRubTrans.PoppulateLevel = "0";

                    string evalMeter = Request.Form["Meter"];
                    if (evalMeter == "1")
                        model.NuclearRubTrans.Meter = "1";
                    else
                        model.NuclearRubTrans.Meter = "0";

                    string evalSurfacePollution = Request.Form["SurfacePollution"];
                    if (evalSurfacePollution == "1")
                        model.NuclearRubTrans.SurfacePollution = "1";
                    else
                        model.NuclearRubTrans.SurfacePollution = "0";
                    this._NuclearRubTransRepository.Update(model.NuclearRubTrans);
                    //根据废物运输ID查询废物运输详细
                    IQueryable<NuclearRubTransDetail> data = this._NuclearRubTransDetailRepository.QueryListByTransDetailId(model.NuclearRubTrans.TransId);
                    List<NuclearRubTransDetail> listData = data.ToList();
                    //删除废物运输详细的数据
                    foreach (var item in listData)
                    {
                        this._NuclearRubTransDetailRepository.DeleteById(item.TransDetailId);
                    }

                    if (!string.IsNullOrEmpty(model.RubTransDetails))
                    {
                        //新增金属验收单明细
                        string[] arrNuclearRubTransD = model.RubTransDetails.Split(';');
                        for (int i = 0; i < arrNuclearRubTransD.Length; i++)
                        {
                            NuclearRubTransDetail NuclearRubTransDetail = new NuclearRubTransDetail();
                            string[] arrNuclearRubTransDetail = arrNuclearRubTransD[i].Split(',');
                            if (arrNuclearRubTransDetail.Length == 9)
                            {
                                NuclearRubTransDetail.TransDetailId = Guid.NewGuid().ToString();
                                NuclearRubTransDetail.TransId = model.NuclearRubTrans.TransId;
                                NuclearRubTransDetail.PackageCondition = arrNuclearRubTransDetail[1];
                                NuclearRubTransDetail.MatterSource = arrNuclearRubTransDetail[2];
                                NuclearRubTransDetail.SullySurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[3]);
                                NuclearRubTransDetail.DoseSurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[4]);
                                NuclearRubTransDetail.SullySurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[5]);
                                NuclearRubTransDetail.DoseSurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[6]);
                                NuclearRubTransDetail.PackageId = arrNuclearRubTransDetail[7];

                                //判断废物货包id是否存在
                                string packageId = this._NuclearWastePackageRepository.IsExist(NuclearRubTransDetail.PackageId, AppContext.CurrentUser.ProjectCode);
                                if (string.IsNullOrEmpty(packageId))
                                {
                                    return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                                }
                                NuclearRubTransDetail.PackageId = packageId;
                                NuclearRubTransDetail.Remark = arrNuclearRubTransDetail[8];

                                NuclearRubTransDetail.CreateDate = DateTime.Now;
                                NuclearRubTransDetail.CreateUserName = AppContext.CurrentUser.UserName;
                                NuclearRubTransDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                                NuclearRubTransDetail.Status = "0";
                                NuclearRubTransDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                                this._NuclearRubTransDetailRepository.Create(NuclearRubTransDetail);
                            }
                        }

                    }
                    this._NuclearRubTransRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);


                }

            }
            catch
            {

                this._NuclearRubTransDetailRepository.UnitOfWork.Commit();
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Submit(RubTransferVM model, FormCollection formCollection)
        {

            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubTrans.TransId))
                {
                    //新增废物运输主单
                    model.NuclearRubTrans.TransId = Guid.NewGuid().ToString();
                    model.NuclearRubTrans.CreateDate = DateTime.Now;
                    model.NuclearRubTrans.CreateUserName = AppContext.CurrentUser.UserName;
                    model.NuclearRubTrans.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearRubTrans.Status = "1";
                    model.NuclearRubTrans.Stationcode = AppContext.CurrentUser.ProjectCode;
                    string evalNuclearRubTrans_RadioactionLabel = Request.Form["NuclearRubTrans_RadioactionLabel"];
                    if (evalNuclearRubTrans_RadioactionLabel == "1")
                        model.NuclearRubTrans.RadioactionLabel = "1";
                    else
                        model.NuclearRubTrans.RadioactionLabel = "0";

                    string evalNuclearRubTrans_RadiationFlag = Request.Form["NuclearRubTrans_RadiationFlag"];
                    if (evalNuclearRubTrans_RadiationFlag == "1")
                        model.NuclearRubTrans.RadiationFlag = "1";
                    else
                        model.NuclearRubTrans.RadiationFlag = "0";

                    string evalNuclearRubTrans_TransRight = Request.Form["NuclearRubTrans_TransRight"];
                    if (evalNuclearRubTrans_TransRight == "1")
                        model.NuclearRubTrans.TransRight = "1";
                    else
                        model.NuclearRubTrans.TransRight = "0";

                    string evalNuclearRubTrans_TransTld = Request.Form["NuclearRubTrans_TransTld"];
                    if (evalNuclearRubTrans_TransTld == "1")
                        model.NuclearRubTrans.TransTld = "1";
                    else
                        model.NuclearRubTrans.TransTld = "0";

                    string evalNuclearRubTrans_TakePlace = Request.Form["NuclearRubTrans_TakePlace"];
                    if (evalNuclearRubTrans_TakePlace == "1")
                        model.NuclearRubTrans.TakePlace = "1";
                    else
                        model.NuclearRubTrans.TakePlace = "0";

                    string evalNuclearRubTrans_PoppulateLevel = Request.Form["NuclearRubTrans_PoppulateLevel"];
                    if (evalNuclearRubTrans_PoppulateLevel == "1")
                        model.NuclearRubTrans.PoppulateLevel = "1";
                    else
                        model.NuclearRubTrans.PoppulateLevel = "0";

                    string evalMeter = Request.Form["Meter"];
                    if (evalMeter == "1")
                        model.NuclearRubTrans.Meter = "1";
                    else
                        model.NuclearRubTrans.Meter = "0";

                    string evalSurfacePollution = Request.Form["SurfacePollution"];
                    if (evalSurfacePollution == "1")
                        model.NuclearRubTrans.SurfacePollution = "1";
                    else
                        model.NuclearRubTrans.SurfacePollution = "0";

                    this._NuclearRubTransRepository.Create(model.NuclearRubTrans);
                    if (!string.IsNullOrEmpty(model.RubTransDetails))
                    {
                        //新增金属验收单明细
                        string[] arrNuclearRubTransD = model.RubTransDetails.Split(';');
                        for (int i = 0; i < arrNuclearRubTransD.Length; i++)
                        {
                            NuclearRubTransDetail NuclearRubTransDetail = new NuclearRubTransDetail();
                            string[] arrNuclearRubTransDetail = arrNuclearRubTransD[i].Split(',');
                            if (arrNuclearRubTransDetail.Length == 9)
                            {
                                NuclearRubTransDetail.TransDetailId = Guid.NewGuid().ToString();
                                NuclearRubTransDetail.TransId = model.NuclearRubTrans.TransId;
                                NuclearRubTransDetail.PackageCondition = arrNuclearRubTransDetail[1];
                                NuclearRubTransDetail.MatterSource = arrNuclearRubTransDetail[2];
                                NuclearRubTransDetail.SullySurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[3]);
                                NuclearRubTransDetail.DoseSurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[4]);
                                NuclearRubTransDetail.SullySurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[5]);
                                NuclearRubTransDetail.DoseSurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[6]);
                                NuclearRubTransDetail.PackageId = arrNuclearRubTransDetail[7];
                                //判断废物货包id是否存在
                                string packageId = this._NuclearWastePackageRepository.IsExist(NuclearRubTransDetail.PackageId, AppContext.CurrentUser.ProjectCode);
                                if (string.IsNullOrEmpty(packageId))
                                {
                                    return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                                }
                                NuclearRubTransDetail.PackageId = packageId;
                                NuclearRubTransDetail.Remark = arrNuclearRubTransDetail[8];
                                NuclearRubTransDetail.CreateDate = DateTime.Now;
                                NuclearRubTransDetail.CreateUserName = AppContext.CurrentUser.UserName;
                                NuclearRubTransDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                                NuclearRubTransDetail.Status = "1";
                                NuclearRubTransDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                                this._NuclearRubTransDetailRepository.Create(NuclearRubTransDetail);
                            }
                        }

                    }

                    //提交
                    this._NuclearRubTransDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
                //修改完新增
                else
                {
                    model.NuclearRubTrans = _NuclearRubTransRepository.Get(model.NuclearRubTrans.TransId);
                    UpdateModel(model);

                    model.NuclearRubTrans.Status = "1";
                    string evalNuclearRubTrans_RadioactionLabel = Request.Form["NuclearRubTrans_RadioactionLabel"];
                    if (evalNuclearRubTrans_RadioactionLabel == "1")
                        model.NuclearRubTrans.RadioactionLabel = "1";
                    else
                        model.NuclearRubTrans.RadioactionLabel = "0";

                    string evalNuclearRubTrans_RadiationFlag = Request.Form["NuclearRubTrans_RadiationFlag"];
                    if (evalNuclearRubTrans_RadiationFlag == "1")
                        model.NuclearRubTrans.RadiationFlag = "1";
                    else
                        model.NuclearRubTrans.RadiationFlag = "0";

                    string evalNuclearRubTrans_TransRight = Request.Form["NuclearRubTrans_TransRight"];
                    if (evalNuclearRubTrans_TransRight == "1")
                        model.NuclearRubTrans.TransRight = "1";
                    else
                        model.NuclearRubTrans.TransRight = "0";

                    string evalNuclearRubTrans_TransTld = Request.Form["NuclearRubTrans_TransTld"];
                    if (evalNuclearRubTrans_TransTld == "1")
                        model.NuclearRubTrans.TransTld = "1";
                    else
                        model.NuclearRubTrans.TransTld = "0";

                    string evalNuclearRubTrans_TakePlace = Request.Form["NuclearRubTrans_TakePlace"];
                    if (evalNuclearRubTrans_TakePlace == "1")
                        model.NuclearRubTrans.TakePlace = "1";
                    else
                        model.NuclearRubTrans.TakePlace = "0";

                    string evalNuclearRubTrans_PoppulateLevel = Request.Form["NuclearRubTrans_PoppulateLevel"];
                    if (evalNuclearRubTrans_PoppulateLevel == "1")
                        model.NuclearRubTrans.PoppulateLevel = "1";
                    else
                        model.NuclearRubTrans.PoppulateLevel = "0";

                    string evalMeter = Request.Form["Meter"];
                    if (evalMeter == "1")
                        model.NuclearRubTrans.Meter = "1";
                    else
                        model.NuclearRubTrans.Meter = "0";

                    string evalSurfacePollution = Request.Form["SurfacePollution"];
                    if (evalSurfacePollution == "1")
                        model.NuclearRubTrans.SurfacePollution = "1";
                    else
                        model.NuclearRubTrans.SurfacePollution = "0";
                    this._NuclearRubTransRepository.Update(model.NuclearRubTrans);
                    //根据废物运输ID查询废物运输详细
                    IQueryable<NuclearRubTransDetail> data = this._NuclearRubTransDetailRepository.QueryListByTransDetailId(model.NuclearRubTrans.TransId);
                    List<NuclearRubTransDetail> listData = data.ToList();
                    //删除废物运输详细的数据
                    foreach (var item in listData)
                    {
                        this._NuclearRubTransDetailRepository.DeleteById(item.TransDetailId);
                    }

                    if (!string.IsNullOrEmpty(model.RubTransDetails))
                    {
                        //新增金属验收单明细
                        string[] arrNuclearRubTransD = model.RubTransDetails.Split(';');
                        for (int i = 0; i < arrNuclearRubTransD.Length; i++)
                        {
                            NuclearRubTransDetail NuclearRubTransDetail = new NuclearRubTransDetail();
                            string[] arrNuclearRubTransDetail = arrNuclearRubTransD[i].Split(',');
                            if (arrNuclearRubTransDetail.Length == 9)
                            {
                                NuclearRubTransDetail.TransDetailId = Guid.NewGuid().ToString();
                                NuclearRubTransDetail.TransId = model.NuclearRubTrans.TransId;
                                NuclearRubTransDetail.PackageCondition = arrNuclearRubTransDetail[1];
                                NuclearRubTransDetail.MatterSource = arrNuclearRubTransDetail[2];
                                NuclearRubTransDetail.SullySurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[3]);
                                NuclearRubTransDetail.DoseSurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[4]);
                                NuclearRubTransDetail.SullySurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[5]);
                                NuclearRubTransDetail.DoseSurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[6]);
                                NuclearRubTransDetail.PackageId = arrNuclearRubTransDetail[7];
                                //判断废物货包id是否存在
                                string packageId = this._NuclearWastePackageRepository.IsExist(NuclearRubTransDetail.PackageId, AppContext.CurrentUser.ProjectCode);
                                if (string.IsNullOrEmpty(packageId))
                                {
                                    return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                                }
                                NuclearRubTransDetail.PackageId = packageId;
                                NuclearRubTransDetail.Remark = arrNuclearRubTransDetail[8];

                                NuclearRubTransDetail.CreateDate = DateTime.Now;
                                NuclearRubTransDetail.CreateUserName = AppContext.CurrentUser.UserName;
                                NuclearRubTransDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                                NuclearRubTransDetail.Status = "1";
                                NuclearRubTransDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                                this._NuclearRubTransDetailRepository.Create(NuclearRubTransDetail);
                            }
                        }

                    }
                    this._NuclearRubTransRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);


                }

            }
            catch
            {

                this._NuclearRubTransDetailRepository.UnitOfWork.Commit();
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物运输确认")]
        public JsonResult Confirm(RubTransferVM model, FormCollection formCollection)
        {

            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubTrans.TransId))
                {
                    //新增废物运输主单
                    model.NuclearRubTrans.TransId = Guid.NewGuid().ToString();
                    model.NuclearRubTrans.CreateDate = DateTime.Now;
                    model.NuclearRubTrans.CreateUserName = AppContext.CurrentUser.UserName;
                    model.NuclearRubTrans.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearRubTrans.ConfirmDate = DateTime.Now;
                    model.NuclearRubTrans.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.NuclearRubTrans.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearRubTrans.Status = "2";
                    model.NuclearRubTrans.Stationcode = AppContext.CurrentUser.ProjectCode;
                    string evalNuclearRubTrans_RadioactionLabel = Request.Form["NuclearRubTrans_RadioactionLabel"];
                    if (evalNuclearRubTrans_RadioactionLabel == "1")
                        model.NuclearRubTrans.RadioactionLabel = "1";
                    else
                        model.NuclearRubTrans.RadioactionLabel = "0";

                    string evalNuclearRubTrans_RadiationFlag = Request.Form["NuclearRubTrans_RadiationFlag"];
                    if (evalNuclearRubTrans_RadiationFlag == "1")
                        model.NuclearRubTrans.RadiationFlag = "1";
                    else
                        model.NuclearRubTrans.RadiationFlag = "0";

                    string evalNuclearRubTrans_TransRight = Request.Form["NuclearRubTrans_TransRight"];
                    if (evalNuclearRubTrans_TransRight == "1")
                        model.NuclearRubTrans.TransRight = "1";
                    else
                        model.NuclearRubTrans.TransRight = "0";

                    string evalNuclearRubTrans_TransTld = Request.Form["NuclearRubTrans_TransTld"];
                    if (evalNuclearRubTrans_TransTld == "1")
                        model.NuclearRubTrans.TransTld = "1";
                    else
                        model.NuclearRubTrans.TransTld = "0";

                    string evalNuclearRubTrans_TakePlace = Request.Form["NuclearRubTrans_TakePlace"];
                    if (evalNuclearRubTrans_TakePlace == "1")
                        model.NuclearRubTrans.TakePlace = "1";
                    else
                        model.NuclearRubTrans.TakePlace = "0";

                    string evalNuclearRubTrans_PoppulateLevel = Request.Form["NuclearRubTrans_PoppulateLevel"];
                    if (evalNuclearRubTrans_PoppulateLevel == "1")
                        model.NuclearRubTrans.PoppulateLevel = "1";
                    else
                        model.NuclearRubTrans.PoppulateLevel = "0";

                    string evalMeter = Request.Form["Meter"];
                    if (evalMeter == "1")
                        model.NuclearRubTrans.Meter = "1";
                    else
                        model.NuclearRubTrans.Meter = "0";

                    string evalSurfacePollution = Request.Form["SurfacePollution"];
                    if (evalSurfacePollution == "1")
                        model.NuclearRubTrans.SurfacePollution = "1";
                    else
                        model.NuclearRubTrans.SurfacePollution = "0";

                    this._NuclearRubTransRepository.Create(model.NuclearRubTrans);
                    if (!string.IsNullOrEmpty(model.RubTransDetails))
                    {
                        //新增金属验收单明细
                        string[] arrNuclearRubTransD = model.RubTransDetails.Split(';');
                        for (int i = 0; i < arrNuclearRubTransD.Length; i++)
                        {
                            NuclearRubTransDetail NuclearRubTransDetail = new NuclearRubTransDetail();
                            string[] arrNuclearRubTransDetail = arrNuclearRubTransD[i].Split(',');
                            if (arrNuclearRubTransDetail.Length == 9)
                            {
                                NuclearRubTransDetail.TransDetailId = Guid.NewGuid().ToString();
                                NuclearRubTransDetail.TransId = model.NuclearRubTrans.TransId;
                                NuclearRubTransDetail.PackageCondition = arrNuclearRubTransDetail[1];
                                NuclearRubTransDetail.MatterSource = arrNuclearRubTransDetail[2];
                                NuclearRubTransDetail.SullySurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[3]);
                                NuclearRubTransDetail.DoseSurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[4]);
                                NuclearRubTransDetail.SullySurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[5]);
                                NuclearRubTransDetail.DoseSurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[6]);
                                NuclearRubTransDetail.PackageId = arrNuclearRubTransDetail[7];
                                //判断废物货包id是否存在
                                string packageId = this._NuclearWastePackageRepository.IsExist(NuclearRubTransDetail.PackageId, AppContext.CurrentUser.ProjectCode);
                                if (string.IsNullOrEmpty(packageId))
                                {
                                    return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                                }
                                NuclearRubTransDetail.PackageId = packageId;
                                NuclearRubTransDetail.Remark = arrNuclearRubTransDetail[8];

                                NuclearRubTransDetail.ConfirmDate = DateTime.Now;
                                NuclearRubTransDetail.ConfirmUserName = AppContext.CurrentUser.UserName;
                                NuclearRubTransDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;
                                NuclearRubTransDetail.CreateDate = DateTime.Now;
                                NuclearRubTransDetail.CreateUserName = AppContext.CurrentUser.UserName;
                                NuclearRubTransDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                                NuclearRubTransDetail.Status = "2";
                                NuclearRubTransDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                                this._NuclearRubTransDetailRepository.Create(NuclearRubTransDetail);
                            }
                        }

                    }

                    //提交
                    this._NuclearRubTransDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);

                }
                //修改完新增
                else
                {
                    model.NuclearRubTrans = _NuclearRubTransRepository.Get(model.NuclearRubTrans.TransId);
                    UpdateModel(model);

                    model.NuclearRubTrans.Status = "2";
                    string evalNuclearRubTrans_RadioactionLabel = Request.Form["NuclearRubTrans_RadioactionLabel"];
                    if (evalNuclearRubTrans_RadioactionLabel == "1")
                        model.NuclearRubTrans.RadioactionLabel = "1";
                    else
                        model.NuclearRubTrans.RadioactionLabel = "0";

                    string evalNuclearRubTrans_RadiationFlag = Request.Form["NuclearRubTrans_RadiationFlag"];
                    if (evalNuclearRubTrans_RadiationFlag == "1")
                        model.NuclearRubTrans.RadiationFlag = "1";
                    else
                        model.NuclearRubTrans.RadiationFlag = "0";

                    string evalNuclearRubTrans_TransRight = Request.Form["NuclearRubTrans_TransRight"];
                    if (evalNuclearRubTrans_TransRight == "1")
                        model.NuclearRubTrans.TransRight = "1";
                    else
                        model.NuclearRubTrans.TransRight = "0";

                    string evalNuclearRubTrans_TransTld = Request.Form["NuclearRubTrans_TransTld"];
                    if (evalNuclearRubTrans_TransTld == "1")
                        model.NuclearRubTrans.TransTld = "1";
                    else
                        model.NuclearRubTrans.TransTld = "0";

                    string evalNuclearRubTrans_TakePlace = Request.Form["NuclearRubTrans_TakePlace"];
                    if (evalNuclearRubTrans_TakePlace == "1")
                        model.NuclearRubTrans.TakePlace = "1";
                    else
                        model.NuclearRubTrans.TakePlace = "0";

                    string evalNuclearRubTrans_PoppulateLevel = Request.Form["NuclearRubTrans_PoppulateLevel"];
                    if (evalNuclearRubTrans_PoppulateLevel == "1")
                        model.NuclearRubTrans.PoppulateLevel = "1";
                    else
                        model.NuclearRubTrans.PoppulateLevel = "0";

                    string evalMeter = Request.Form["Meter"];
                    if (evalMeter == "1")
                        model.NuclearRubTrans.Meter = "1";
                    else
                        model.NuclearRubTrans.Meter = "0";

                    string evalSurfacePollution = Request.Form["SurfacePollution"];
                    if (evalSurfacePollution == "1")
                        model.NuclearRubTrans.SurfacePollution = "1";
                    else
                        model.NuclearRubTrans.SurfacePollution = "0";
                    this._NuclearRubTransRepository.Update(model.NuclearRubTrans);
                    //根据废物运输ID查询废物运输详细
                    IQueryable<NuclearRubTransDetail> data = this._NuclearRubTransDetailRepository.QueryListByTransDetailId(model.NuclearRubTrans.TransId);
                    List<NuclearRubTransDetail> listData = data.ToList();
                    //删除废物运输详细的数据
                    foreach (var item in listData)
                    {
                        this._NuclearRubTransDetailRepository.DeleteById(item.TransDetailId);
                    }

                    if (!string.IsNullOrEmpty(model.RubTransDetails))
                    {
                        //新增金属验收单明细
                        string[] arrNuclearRubTransD = model.RubTransDetails.Split(';');
                        for (int i = 0; i < arrNuclearRubTransD.Length; i++)
                        {
                            NuclearRubTransDetail NuclearRubTransDetail = new NuclearRubTransDetail();
                            string[] arrNuclearRubTransDetail = arrNuclearRubTransD[i].Split(',');
                            if (arrNuclearRubTransDetail.Length == 9)
                            {
                                NuclearRubTransDetail.TransDetailId = Guid.NewGuid().ToString();
                                NuclearRubTransDetail.TransId = model.NuclearRubTrans.TransId;
                                NuclearRubTransDetail.PackageCondition = arrNuclearRubTransDetail[1];
                                NuclearRubTransDetail.MatterSource = arrNuclearRubTransDetail[2];
                                NuclearRubTransDetail.SullySurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[3]);
                                NuclearRubTransDetail.DoseSurfaceA = Convert.ToDecimal(arrNuclearRubTransDetail[4]);
                                NuclearRubTransDetail.SullySurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[5]);
                                NuclearRubTransDetail.DoseSurfaceB = Convert.ToDecimal(arrNuclearRubTransDetail[6]);
                                NuclearRubTransDetail.PackageId = arrNuclearRubTransDetail[7];
                                //判断废物货包id是否存在
                                string packageId = this._NuclearWastePackageRepository.IsExist(NuclearRubTransDetail.PackageId, AppContext.CurrentUser.ProjectCode);
                                if (string.IsNullOrEmpty(packageId))
                                {
                                    return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                                }
                                NuclearRubTransDetail.PackageId = packageId;
                                NuclearRubTransDetail.Remark = arrNuclearRubTransDetail[8];

                                NuclearRubTransDetail.ConfirmDate = DateTime.Now;
                                NuclearRubTransDetail.ConfirmUserName = AppContext.CurrentUser.UserName;
                                NuclearRubTransDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;
                                NuclearRubTransDetail.CreateDate = DateTime.Now;
                                NuclearRubTransDetail.CreateUserName = AppContext.CurrentUser.UserName;
                                NuclearRubTransDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                                NuclearRubTransDetail.Status = "2";
                                NuclearRubTransDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                                this._NuclearRubTransDetailRepository.Create(NuclearRubTransDetail);
                            }
                        }

                    }
                    this._NuclearRubTransRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);


                }

            }
            catch
            {

                this._NuclearRubTransDetailRepository.UnitOfWork.Commit();
                return Json("{\"result\":false,\"msg\":\"确定失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(RubTransferVM model, FormCollection formCollection)
        {
            //判断废物货包id是否存在
            string packageId = this._NuclearWastePackageRepository.IsExist(model.NuclearRubTransDetail.PackageId, AppContext.CurrentUser.ProjectCode);
            if (string.IsNullOrEmpty(packageId))
            {
                return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
            }
            model.NuclearRubTransDetail.PackageId = packageId;

            try
            {
                //model.DataManage.DataManageId = model.DataManage.DataManageId;
                model.NuclearRubTrans.Status = "0";//状态
                this._NuclearRubTransRepository.Update(model.NuclearRubTrans);//提交数据库
                this._NuclearRubTransRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 废物运输详细 初始化查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetRubTransDetailList(string TransId,string TransDetailId, string sord, int page, int rows, string sidx)
        {             
            if (string.IsNullOrEmpty(TransId))
            {
                return null;
            }
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<NuclearRubTransDetail> data = this._NuclearRubTransDetailRepository.GetAll().Where(d => d.TransId == TransId).AsQueryable();
            List<NuclearRubTransDetail> datalist = data.ToList();
            if (datalist.Count() > 0)
            {
                foreach (var item in datalist)
                {
                    NuclearWastePackage Pac = _NuclearWastePackageRepository.Get(item.PackageId);
                    item.PackageId = Pac.PackageCode;
                }
              
            }
            var pagedViewModel = new PagedViewModel<NuclearRubTransDetail>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.TransDetailId,
                    List = new List<object>() {   
                        d.TransDetailId,
                        d.PackageCondition,
                        d.MatterSource,
                        d.SullySurfaceA,
                        d.DoseSurfaceA,
                        d.SullySurfaceB,
                        d.DoseSurfaceB,
                        d.PackageId,
                        d.Remark,
                        d.Status                    
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询废物运输列表
        /// </summary>
        /// <param name="">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetRubTransferList(RubTransferCondition rubTransferCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<RubTransferView> data = this._NuclearRubTransRepository.QueryList(rubTransferCondition);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<RubTransferView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.TransId,
                    List = new List<object>() {
                    d.TransId,
                    d.MatterCompany,
                    d.TransDate.HasValue?d.TransDate.Value.ToString("yyyy-MM-dd"):string.Empty,                    
                    d.MatterFrom,
                    d.MatterTo,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        [HttpPost]
        public JsonResult Delete(string TransId)
        {
            try
            {

                IQueryable<NuclearRubTransDetail> DetailIdQuery = _NuclearRubTransDetailRepository.QueryListByTransDetailId(TransId);
                List<NuclearRubTransDetail> DetailIdQueryList = DetailIdQuery.ToList();
                foreach (var items in DetailIdQueryList)
                {
                    this._NuclearRubTransDetailRepository.DeleteById(items.TransDetailId);
                }
                this._NuclearRubTransRepository.DeleteById(TransId);
                this._NuclearRubTransDetailRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult IsExist(RubTransferVM model , FormCollection formCollection,string txtPacketCode)
        {            
            string packageId = this._NuclearWastePackageRepository.IsExist(txtPacketCode, AppContext.CurrentUser.ProjectCode);
            if (string.IsNullOrEmpty(packageId))
            {
                return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
            }
             return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);
        }

        ////自动填充控件-废物货包
        //public JsonResult GetDataList(string keyword)
        //{
        //    //数据源
        //    List<NuclearWastePackage> list = _NuclearWastePackageRepository.GetAll().Where(e => e.PackageCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
        //    List<AutoComplete> autoCompleteList = new List<AutoComplete>();
        //    for (int i = 0; i < list.Count; i++)
        //    {
        //        AutoComplete autoComplete = new AutoComplete();
        //        autoComplete.Name = list[i].PackageCode;
        //        autoComplete.Code = list[i].PackageId;
        //        autoCompleteList.Add(autoComplete);
        //    }
        //    var resultObj = new
        //    {
        //        autoCompleteList
        //    };
        //    return Json(resultObj, JsonRequestBehavior.AllowGet);
        //}

        #region 将文件输出到页面
        /// <summary>
        /// 导出运输单
        /// </summary>
        /// <param name="outputId">出库单ID</param>
        /// <returns></returns>
        [HttpGet]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "运输单导出")]
        public ActionResult PrintRubTransfer(string id)
        {

            Export(id);
            return null;
        }

        /// <summary>
        /// 将文件输出到页面
        /// </summary>
        /// <param name="page"></param>
        /// <param name="fileStream">文件流</param>
        /// <param name="saveFileName">用户默认保存名称</param>
        private void Export(string TransId)
        {
            #region 获取数据
            //得到当前废物运输id 和信息
            NuclearRubTrans nuclearRubTrans = _NuclearRubTransRepository.Get(TransId);
            List<NuclearRubTrans> nuclearRubTransList = new List<NuclearRubTrans>();
            nuclearRubTransList.Add(nuclearRubTrans);

            //得到当前废物运输详细id 和信息
            NuclearRubTransDetail NuclearRubTransDetail = _NuclearRubTransDetailRepository.Get(TransId);
            List<NuclearRubTransDetail> NuclearRubTransDetailList = new List<NuclearRubTransDetail>();
            nuclearRubTransList.Add(nuclearRubTrans);

           
            //得到下拉列表信息
            IQueryable<BasicObject> queryTo = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> matterToList = new List<BasicObject>();
            if (queryTo != null && queryTo.Count() > 0)
            {
                matterToList = queryTo.ToList();
            }
            IQueryable<BasicObject> queryFrom = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> matterFromList = new List<BasicObject>();
            if (queryFrom != null && queryFrom.Count() > 0)
            {
                matterFromList = queryFrom.ToList();
            }

            //得到废物运输信息
            List<RubTransferVM> rubTransferVMList = (from o in nuclearRubTransList                                                     
                                                     select new RubTransferVM
                                                     {
                                                         NuclearRubTrans = o,                                                          
                                                     }).ToList<RubTransferVM>();

            RubTransferVM RubTransferVM = new RubTransferVM();
            if (rubTransferVMList != null && rubTransferVMList.Count > 0)
            {
                RubTransferVM = rubTransferVMList[0];
            }

            RubTransferVM vm = new RubTransferVM();
            NuclearRubTrans model = _NuclearRubTransRepository.Get(TransId);
            vm.NuclearRubTrans = model;
            BasicObject BasicObject = new BasicObject();
            BasicObject basicObjectMatterFrom = _BasicObjectRepository.Get(model.MatterFrom);
            BasicObject basicObjectMatterTo = _BasicObjectRepository.Get(model.MatterTo);

            vm.MatterFromName = basicObjectMatterFrom.Name;
            vm.MatterToName = basicObjectMatterTo.Name;

            
            if (model.RadioactionLabel == "1")
                model.RadioactionLabel = "是";
            else
                model.RadioactionLabel = "否";

            if (model.RadiationFlag == "1")
                model.RadiationFlag = "是";
            else
                model.RadiationFlag = "否";

            if (model.TransRight == "1")
                model.TransRight = "是";
            else
                model.TransRight = "否";

            if (model.TransTld == "1")
                model.TransTld = "是";
            else
                model.TransTld = "否";

            if (model.TakePlace == "1")
                model.TakePlace = "是";
            else
                model.TakePlace = "否";

            if (model.PoppulateLevel == "1")
                model.PoppulateLevel = "否";
            else
                model.PoppulateLevel = "是";

            if (model.Meter == "1")
                model.Meter = "是";
            else
                model.Meter = "否";

            if (model.SurfacePollution == "1")
                model.SurfacePollution = "是";
            else
                model.SurfacePollution = "否";

            //得到出库单详细信息
            IQueryable<NuclearRubTransDetail> data = this._NuclearRubTransDetailRepository.GetAll().Where(d => d.TransId == TransId).AsQueryable();
            List<NuclearRubTransDetail> datalist = data.ToList();
           
            //创建文档对象
            HSSFWorkbook hssfworkbook = new HSSFWorkbook();
            //然后创建DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();
            dsi.Company = "NPOI Team";
           // 再创建SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Subject = "NPOI SDK Example";

            // 创建好的对象赋给Workbook 保证这些信息被写入文件。
            hssfworkbook.DocumentSummaryInformation = dsi;
            hssfworkbook.SummaryInformation = si;

            #endregion

            #region 编辑excel
            
            //创建工作表
            HSSFSheet sheet1 = (HSSFSheet)hssfworkbook.CreateSheet("Sheet1");
            //创建行
            HSSFRow row1 = (HSSFRow)sheet1.CreateRow(0);
            HSSFRow row2 = (HSSFRow)sheet1.CreateRow(1);
            HSSFRow row3 = (HSSFRow)sheet1.CreateRow(2);
            HSSFRow row4 = (HSSFRow)sheet1.CreateRow(3);
            HSSFRow row5 = (HSSFRow)sheet1.CreateRow(4);
            HSSFRow row6 = (HSSFRow)sheet1.CreateRow(5);
            HSSFRow row7 = (HSSFRow)sheet1.CreateRow(6);
            HSSFRow row8 = (HSSFRow)sheet1.CreateRow(7);
            HSSFRow row9 = (HSSFRow)sheet1.CreateRow(8);
            HSSFRow row10 = (HSSFRow)sheet1.CreateRow(9);
            HSSFRow row11 = (HSSFRow)sheet1.CreateRow(10);
            HSSFRow row12 = (HSSFRow)sheet1.CreateRow(11);
            HSSFRow row13 = (HSSFRow)sheet1.CreateRow(12);
            HSSFRow row14 = (HSSFRow)sheet1.CreateRow(13);
            HSSFRow row15 = (HSSFRow)sheet1.CreateRow(14);
            HSSFRow row16 = (HSSFRow)sheet1.CreateRow(15);
           

            //设置列宽 
            sheet1.SetColumnWidth(0, 40 * 100);
            sheet1.SetColumnWidth(1, 40 * 100);
            sheet1.SetColumnWidth(2, 40 * 100);
            sheet1.SetColumnWidth(3, 40 * 100);
            sheet1.SetColumnWidth(4, 40 * 100);
            sheet1.SetColumnWidth(5, 40 * 100);
            sheet1.SetColumnWidth(6, 40 * 100);
            sheet1.SetColumnWidth(7, 40 * 100);
            sheet1.SetColumnWidth(8, 40 * 100);
            sheet1.SetColumnWidth(9, 40 * 100);
            sheet1.SetColumnWidth(10, 40 * 100);
            sheet1.SetColumnWidth(11, 40 * 100);
            sheet1.SetColumnWidth(12, 40 * 100);
            sheet1.SetColumnWidth(13, 40 * 100);
            sheet1.SetColumnWidth(14, 40 * 100);
            //行高
            sheet1.CreateRow(0).Height = 40 * 20;
            sheet1.CreateRow(1).Height = 20 * 20;
            sheet1.CreateRow(2).Height = 20 * 20;
            sheet1.CreateRow(3).Height = 20 * 20;
            sheet1.CreateRow(4).Height = 20 * 20;
            sheet1.CreateRow(5).Height = 20 * 20;
            sheet1.CreateRow(6).Height = 20 * 20;
            sheet1.CreateRow(7).Height = 20 * 20;
            sheet1.CreateRow(8).Height = 20 * 20;
            sheet1.CreateRow(9).Height = 40 * 20;
            sheet1.CreateRow(10).Height = 40 * 20;
            sheet1.CreateRow(11).Height = 20 * 20;
            sheet1.CreateRow(12).Height = 40 * 20;
            sheet1.CreateRow(13).Height = 20 * 20;
            sheet1.CreateRow(14).Height = 40 * 20;
            sheet1.CreateRow(15).Height = 40 * 20;
            sheet1.CreateRow(16).Height = 40 * 20;




            //合并单元格（起始行号、列号、终止行号、列号）
            //合并单元格（起始行号、终止行号、起始列号、终止列号）

            sheet1.AddMergedRegion(new CellRangeAddress(0, 0, 1, 6));
            sheet1.AddMergedRegion(new CellRangeAddress(1, 1, 0, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(2, 2, 0, 1));
            sheet1.AddMergedRegion(new CellRangeAddress(2, 2, 2, 3));
            sheet1.AddMergedRegion(new CellRangeAddress(2, 2, 4, 5));
            sheet1.AddMergedRegion(new CellRangeAddress(2, 2, 6, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(3, 3, 0, 1));
            sheet1.AddMergedRegion(new CellRangeAddress(3, 3, 2, 3));
            sheet1.AddMergedRegion(new CellRangeAddress(3, 3, 4, 5));
            sheet1.AddMergedRegion(new CellRangeAddress(3, 3, 6, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(4, 5, 0, 1));
            sheet1.AddMergedRegion(new CellRangeAddress(4, 4, 2, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(5, 5, 2, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(6, 6, 0, 4));
            sheet1.AddMergedRegion(new CellRangeAddress(6, 6, 5, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(7, 7, 0, 4));
            sheet1.AddMergedRegion(new CellRangeAddress(7, 7, 5, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(8, 8, 0, 4));
            sheet1.AddMergedRegion(new CellRangeAddress(8, 8, 5, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(9, 9, 0, 4));
            sheet1.AddMergedRegion(new CellRangeAddress(9, 9, 5, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(10, 10, 0, 4));
            sheet1.AddMergedRegion(new CellRangeAddress(10, 10, 5, 7));
            
            sheet1.AddMergedRegion(new CellRangeAddress(11, 11, 0, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(12, 12, 0, 4));
            sheet1.AddMergedRegion(new CellRangeAddress(12, 12, 5, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(13, 13, 0, 7));
         
            sheet1.AddMergedRegion(new CellRangeAddress(14, 14, 0, 1));
            sheet1.AddMergedRegion(new CellRangeAddress(14, 14, 2, 4));
            sheet1.AddMergedRegion(new CellRangeAddress(14, 14, 5, 7));       


            //单元格样式——一级标题
            HSSFCellStyle style = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font = (HSSFFont)hssfworkbook.CreateFont();
            font.FontHeight = 30 * 20;//字体高度
            style.SetFont(font); 

            //单元格样式——正文
            HSSFCellStyle style3 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style3.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;//水平居中
            style3.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;//垂直居中
            HSSFFont font031 = (HSSFFont)hssfworkbook.CreateFont();
            font031.FontHeight = 11 * 20;//字体高度
            style3.WrapText = true;//自动换行
            style3.SetFont(font031);

            //单元格样式——二级标题
            HSSFCellStyle style2 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style2.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style2.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style2.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style2.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style2.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font021 = (HSSFFont)hssfworkbook.CreateFont();
            font021.FontHeight = 15 * 20;//字体高度
            style2.SetFont(font021);

            //单元格样式——正文左对齐
            HSSFCellStyle style4 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style4.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style4.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style4.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style4.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;

            style4.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;//水平居中
            style4.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;//垂直居中
            HSSFFont font041 = (HSSFFont)hssfworkbook.CreateFont();
            font041.FontHeight = 11 * 20;//字体高度
            style4.WrapText = true;//自动换行
            style4.SetFont(font041);

            //创建列
            HSSFCell cell011 = (HSSFCell)row1.CreateCell(0);
            cell011.SetCellValue("电站标号：" + model.Stationcode);//设置单元格内容
            HSSFCell cell012 = (HSSFCell)row1.CreateCell(1);
            cell012.SetCellValue("放射性物质场内运输登记表");
            HSSFCell cell013 = (HSSFCell)row1.CreateCell(7);
            cell013.SetCellValue("No:");
            HSSFCell cell014 = (HSSFCell)row1.CreateCell(2);
            HSSFCell cell015 = (HSSFCell)row1.CreateCell(3);
            HSSFCell cell016 = (HSSFCell)row1.CreateCell(4);
            HSSFCell cell017 = (HSSFCell)row1.CreateCell(5);
            HSSFCell cell018 = (HSSFCell)row1.CreateCell(6);
            //应用单元格样式
            cell012.CellStyle = style;
            cell011.CellStyle = style3;
            cell013.CellStyle = style4;
            cell014.CellStyle = style;
            cell015.CellStyle = style;
            cell016.CellStyle = style;
            cell017.CellStyle = style;
            cell018.CellStyle = style;

            //创建列
            HSSFCell cell021 = (HSSFCell)row2.CreateCell(0);
            HSSFCell cell022 = (HSSFCell)row2.CreateCell(7);
            HSSFCell cell023 = (HSSFCell)row2.CreateCell(1);
            HSSFCell cell024 = (HSSFCell)row2.CreateCell(2);
            HSSFCell cell025 = (HSSFCell)row2.CreateCell(3);
            HSSFCell cell026 = (HSSFCell)row2.CreateCell(4);
            HSSFCell cell027 = (HSSFCell)row2.CreateCell(5);
            HSSFCell cell028 = (HSSFCell)row2.CreateCell(6);
            cell021.SetCellValue("场内运输（UA门及快速通道内）填写本栏" );
           
            cell021.CellStyle = style2;
            cell022.CellStyle = style2;
            cell023.CellStyle = style2;
            cell024.CellStyle = style2;
            cell025.CellStyle = style2;
            cell026.CellStyle = style2;
            cell027.CellStyle = style2;
            cell028.CellStyle = style2;

            //创建列
            HSSFCell cell031 = (HSSFCell)row3.CreateCell(0);
            HSSFCell cell032 = (HSSFCell)row3.CreateCell(2);
            HSSFCell cell033 = (HSSFCell)row3.CreateCell(4);
            HSSFCell cell034 = (HSSFCell)row3.CreateCell(6);
            HSSFCell cell035 = (HSSFCell)row3.CreateCell(1);
            HSSFCell cell036 = (HSSFCell)row3.CreateCell(3);
            HSSFCell cell037 = (HSSFCell)row3.CreateCell(5);
            HSSFCell cell038 = (HSSFCell)row3.CreateCell(7);

            cell031.SetCellValue("物质运输时间:");
            cell032.SetCellValue(RubTransferVM.NuclearRubTrans.TransDate.Value.ToString("yyyy-MM-dd"));
            cell033.SetCellValue("物质来自：");
            cell034.SetCellValue(vm.MatterFromName);

            
            cell031.CellStyle = style3;
            cell032.CellStyle = style3;
            cell033.CellStyle = style3;
            cell034.CellStyle = style3;
            cell035.CellStyle = style3;
            cell036.CellStyle = style3;
            cell037.CellStyle = style3;
            cell038.CellStyle = style3;

            //创建列
            HSSFCell cell041 = (HSSFCell)row4.CreateCell(0);
            HSSFCell cell042 = (HSSFCell)row4.CreateCell(2);
            HSSFCell cell043 = (HSSFCell)row4.CreateCell(4);
            HSSFCell cell044 = (HSSFCell)row4.CreateCell(6);
            HSSFCell cell045 = (HSSFCell)row4.CreateCell(1);
            HSSFCell cell046 = (HSSFCell)row4.CreateCell(3);
            HSSFCell cell047 = (HSSFCell)row4.CreateCell(5);
            HSSFCell cell048 = (HSSFCell)row4.CreateCell(7);

            cell041.SetCellValue("物质运输单位:");
            cell042.SetCellValue(RubTransferVM.NuclearRubTrans.MatterCompany);
            cell043.SetCellValue("物质运往：");
            cell044.SetCellValue(vm.MatterToName);
            cell041.CellStyle = style3;
            cell042.CellStyle = style3;
            cell043.CellStyle = style3;
            cell044.CellStyle = style3;
            cell045.CellStyle = style3;
            cell046.CellStyle = style3;
            cell047.CellStyle = style3;
            cell048.CellStyle = style3;

           
            //创建列
            HSSFCell cell051 = (HSSFCell)row5.CreateCell(0);
            HSSFCell cell052 = (HSSFCell)row5.CreateCell(2);
            HSSFCell cell053 = (HSSFCell)row5.CreateCell(1);
            HSSFCell cell054 = (HSSFCell)row5.CreateCell(3);
            HSSFCell cell055 = (HSSFCell)row5.CreateCell(4);
            HSSFCell cell056 = (HSSFCell)row5.CreateCell(5);
            HSSFCell cell057 = (HSSFCell)row5.CreateCell(6);
            HSSFCell cell058 = (HSSFCell)row5.CreateCell(7);
            
            cell051.SetCellValue("测量仪表");
            cell052.SetCellValue("剂量率：6150AD5                    " + RubTransferVM.NuclearRubTrans.Meter + "          或其他型号仪表：" + RubTransferVM.NuclearRubTrans.OtherDoserate);            
            cell051.CellStyle = style3;
            cell052.CellStyle = style4;
            cell053.CellStyle = style4;
            cell054.CellStyle = style4;
            cell055.CellStyle = style4;
            cell056.CellStyle = style4;
            cell057.CellStyle = style4;
            cell058.CellStyle = style4;
           
            //创建列
            HSSFCell cell061 = (HSSFCell)row6.CreateCell(2);
            HSSFCell cell062 = (HSSFCell)row6.CreateCell(4);
            HSSFCell cell063 = (HSSFCell)row6.CreateCell(0);
            HSSFCell cell064 = (HSSFCell)row6.CreateCell(1);
            HSSFCell cell065 = (HSSFCell)row6.CreateCell(3);
            HSSFCell cell066 = (HSSFCell)row6.CreateCell(5);
            HSSFCell cell067 = (HSSFCell)row6.CreateCell(6);
            HSSFCell cell068 = (HSSFCell)row6.CreateCell(7);

            cell061.SetCellValue("表面污染：6150AD5+AD17     " + RubTransferVM.NuclearRubTrans.SurfacePollution + "          或其他型号仪表：" + RubTransferVM.NuclearRubTrans.OtherDoserate);            
            cell061.CellStyle = style4;
            cell062.CellStyle = style3;
            cell063.CellStyle = style3;
            cell064.CellStyle = style3;
            cell065.CellStyle = style3;
            cell066.CellStyle = style3;
            cell067.CellStyle = style3;
            cell068.CellStyle = style3;


            //创建列
            HSSFCell cell071 = (HSSFCell)row7.CreateCell(0);
            HSSFCell cell072 = (HSSFCell)row7.CreateCell(5);
            HSSFCell cell073 = (HSSFCell)row7.CreateCell(1);
            HSSFCell cell074 = (HSSFCell)row7.CreateCell(2);
            HSSFCell cell075 = (HSSFCell)row7.CreateCell(3);
            HSSFCell cell076 = (HSSFCell)row7.CreateCell(4);
            HSSFCell cell077 = (HSSFCell)row7.CreateCell(6);
            HSSFCell cell078 = (HSSFCell)row7.CreateCell(7);

            
            cell071.SetCellValue("运输工作负责人测量并填写");
            cell072.SetCellValue("辐射防护人员测量并填写");
            cell071.CellStyle = style2;
            cell072.CellStyle = style2;
            cell073.CellStyle = style2;
            cell074.CellStyle = style2;
            cell075.CellStyle = style2;
            cell076.CellStyle = style2;
            cell077.CellStyle = style2;
            cell078.CellStyle = style2;

            //创建列
            HSSFCell cell081 = (HSSFCell)row8.CreateCell(0);
            HSSFCell cell082 = (HSSFCell)row8.CreateCell(5);
            HSSFCell cell083 = (HSSFCell)row8.CreateCell(1);
            HSSFCell cell084 = (HSSFCell)row8.CreateCell(2);
            HSSFCell cell085 = (HSSFCell)row8.CreateCell(3);
            HSSFCell cell086 = (HSSFCell)row8.CreateCell(4);
            HSSFCell cell087 = (HSSFCell)row8.CreateCell(6);
            HSSFCell cell088 = (HSSFCell)row8.CreateCell(7);
            cell081.SetCellValue("货包粘贴场内运输放射性标签                  " + RubTransferVM.NuclearRubTrans.RadioactionLabel);
            cell082.SetCellValue("确认货包/车辆辐射水平满足要求           " + RubTransferVM.NuclearRubTrans.RadiationFlag);
            cell081.CellStyle = style4;
            cell082.CellStyle = style4;
            cell083.CellStyle = style4;
            cell084.CellStyle = style4;
            cell085.CellStyle = style4;
            cell086.CellStyle = style4;
            cell087.CellStyle = style4;
            cell088.CellStyle = style4;

            //创建列
            HSSFCell cell091 = (HSSFCell)row9.CreateCell(0);
            HSSFCell cell092 = (HSSFCell)row9.CreateCell(5);
            HSSFCell cell093 = (HSSFCell)row9.CreateCell(1);
            HSSFCell cell094 = (HSSFCell)row9.CreateCell(2);
            HSSFCell cell095 = (HSSFCell)row9.CreateCell(3);
            HSSFCell cell096 = (HSSFCell)row9.CreateCell(4);
            HSSFCell cell097 = (HSSFCell)row9.CreateCell(6);
            HSSFCell cell098 = (HSSFCell)row9.CreateCell(7);
            cell091.SetCellValue("正确的选择运输方式                                " + RubTransferVM.NuclearRubTrans.TransRight);
            cell092.SetCellValue("运输人员佩戴个人剂量计TLD                " + RubTransferVM.NuclearRubTrans.TransTld);
            cell091.CellStyle = style4;
            cell092.CellStyle = style4;
            cell093.CellStyle = style4;
            cell094.CellStyle = style4;
            cell095.CellStyle = style4;
            cell096.CellStyle = style4;
            cell097.CellStyle = style4;
            cell098.CellStyle = style4;

            //创建列
            HSSFCell cell0101 = (HSSFCell)row10.CreateCell(0);
            HSSFCell cell0102 = (HSSFCell)row10.CreateCell(5);
            HSSFCell cell0103 = (HSSFCell)row10.CreateCell(1);
            HSSFCell cell0104 = (HSSFCell)row10.CreateCell(2);
            HSSFCell cell0105 = (HSSFCell)row10.CreateCell(3);
            HSSFCell cell0106 = (HSSFCell)row10.CreateCell(4);
            HSSFCell cell0107 = (HSSFCell)row10.CreateCell(7);
            HSSFCell cell0108 = (HSSFCell)row10.CreateCell(6);
            cell0101.SetCellValue("确认控制区外接收、运输人员就位           " + RubTransferVM.NuclearRubTrans.TakePlace);
            cell0102.SetCellValue("过渡区的运输在运出前测量过渡区地面 和车轮污染水平<0.8Bq/cm2                                    " + RubTransferVM.NuclearRubTrans.PoppulateLevel);
            cell0101.CellStyle = style4;
            cell0102.CellStyle = style4;
            cell0103.CellStyle = style4;
            cell0104.CellStyle = style4;
            cell0105.CellStyle = style4;
            cell0106.CellStyle = style4;
            cell0107.CellStyle = style4;
            cell0108.CellStyle = style4;

            //创建列
            HSSFCell cell0111 = (HSSFCell)row11.CreateCell(0);
            HSSFCell cell0112 = (HSSFCell)row11.CreateCell(5);
            HSSFCell cell0113 = (HSSFCell)row11.CreateCell(1);
            HSSFCell cell0114 = (HSSFCell)row11.CreateCell(2);
            HSSFCell cell0115 = (HSSFCell)row11.CreateCell(3);
            HSSFCell cell0116 = (HSSFCell)row11.CreateCell(4);
            HSSFCell cell0117 = (HSSFCell)row11.CreateCell(6);
            HSSFCell cell0118 = (HSSFCell)row11.CreateCell(7);
            cell0111.SetCellValue("运输前运输工作负责人/日期：");//+RubTransferVM.NuclearRubTrans.TransFromName+RubTransferVM.NuclearRubTrans.TransFromDate.Value.ToString("yyyy-MM-dd")
            cell0112.SetCellValue("运输前辐射防护人员/日期：");// + RubTransferVM.NuclearRubTrans.RadiationFromName + RubTransferVM.NuclearRubTrans.RadiationFromDate.Value.ToString("yyyy-MM-dd")
            cell0111.CellStyle = style4;
            cell0112.CellStyle = style4;
            cell0113.CellStyle = style4;
            cell0114.CellStyle = style4;
            cell0115.CellStyle = style4;
            cell0116.CellStyle = style4;
            cell0117.CellStyle = style4;
            cell0118.CellStyle = style4;

            //创建列
            HSSFCell cell0121 = (HSSFCell)row12.CreateCell(0);
            HSSFCell cell0122 = (HSSFCell)row12.CreateCell(1);
            HSSFCell cell0123 = (HSSFCell)row12.CreateCell(2);
            HSSFCell cell0124 = (HSSFCell)row12.CreateCell(3);
            HSSFCell cell0125 = (HSSFCell)row12.CreateCell(4);
            HSSFCell cell0126 = (HSSFCell)row12.CreateCell(5);
            HSSFCell cell0127 = (HSSFCell)row12.CreateCell(6);
            HSSFCell cell0128 = (HSSFCell)row12.CreateCell(7);
            cell0121.SetCellValue("场内（UA门以外核电基地边界以内）或经过场内运往场外的运输同时填写本栏");
            cell0121.CellStyle = style2;
            cell0122.CellStyle = style2;
            cell0123.CellStyle = style2;
            cell0124.CellStyle = style2;
            cell0125.CellStyle = style2;
            cell0126.CellStyle = style2;
            cell0127.CellStyle = style2;
            cell0128.CellStyle = style2;

            //创建列
            HSSFCell cell0131 = (HSSFCell)row13.CreateCell(0);
            HSSFCell cell0132 = (HSSFCell)row13.CreateCell(5);
            HSSFCell cell0133 = (HSSFCell)row13.CreateCell(1);
            HSSFCell cell0134 = (HSSFCell)row13.CreateCell(2);
            HSSFCell cell0135 = (HSSFCell)row13.CreateCell(3);
            HSSFCell cell0136 = (HSSFCell)row13.CreateCell(4);
            HSSFCell cell0137 = (HSSFCell)row13.CreateCell(6);
            HSSFCell cell0138 = (HSSFCell)row13.CreateCell(7);
            cell0131.SetCellValue("所在单位或接口处长签字/日期：");//+ RubTransferVM.NuclearRubTrans.ReceptionName + RubTransferVM.NuclearRubTrans.ReceptionDate.Value.ToString("yyyy-MM-dd")
            cell0132.SetCellValue("运输前通知辐射防护人员押运本表作为通行UA门的凭证之一");
            cell0131.CellStyle = style4;
            cell0132.CellStyle = style4;
            cell0133.CellStyle = style4;
            cell0134.CellStyle = style4;
            cell0135.CellStyle = style4;
            cell0136.CellStyle = style4;
            cell0137.CellStyle = style4;
            cell0138.CellStyle = style4;

            //创建列
            HSSFCell cell0141 = (HSSFCell)row14.CreateCell(0);
            HSSFCell cell0142 = (HSSFCell)row14.CreateCell(1);
            HSSFCell cell0143 = (HSSFCell)row14.CreateCell(2);
            HSSFCell cell0144 = (HSSFCell)row14.CreateCell(3);
            HSSFCell cell0145 = (HSSFCell)row14.CreateCell(4);
            HSSFCell cell0146 = (HSSFCell)row14.CreateCell(5);
            HSSFCell cell0147 = (HSSFCell)row14.CreateCell(6);
            HSSFCell cell0148 = (HSSFCell)row14.CreateCell(7);
            cell0141.SetCellValue("到达目的地后");

            cell0141.CellStyle = style2;
            cell0142.CellStyle = style2;
            cell0143.CellStyle = style2;
            cell0144.CellStyle = style2;
            cell0145.CellStyle = style2;
            cell0146.CellStyle = style2;
            cell0147.CellStyle = style2;
            cell0148.CellStyle = style2;

            //创建列
            HSSFCell cell0151 = (HSSFCell)row15.CreateCell(0);
            HSSFCell cell0152 = (HSSFCell)row15.CreateCell(2);
            HSSFCell cell0153 = (HSSFCell)row15.CreateCell(5);
            HSSFCell cell0154 = (HSSFCell)row15.CreateCell(1);
            HSSFCell cell0155 = (HSSFCell)row15.CreateCell(3);
            HSSFCell cell0156 = (HSSFCell)row15.CreateCell(4);
            HSSFCell cell0157 = (HSSFCell)row15.CreateCell(6);
            HSSFCell cell0158 = (HSSFCell)row15.CreateCell(7);

            cell0151.SetCellValue("到达地点:" + RubTransferVM.NuclearRubTrans.TransPlace);
            cell0152.SetCellValue("到达后运输工作负责人/日期：");// + RubTransferVM.NuclearRubTrans.TransToName + RubTransferVM.NuclearRubTrans.TransToDate.Value.ToString("yyyy-MM-dd")
            cell0153.SetCellValue("目的地辐射防护人员/日期：");// + RubTransferVM.NuclearRubTrans.RadiationToName + RubTransferVM.NuclearRubTrans.RadiationToDate.Value.ToString("yyyy-MM-dd")

            cell0151.CellStyle = style4;
            cell0152.CellStyle = style4;
            cell0153.CellStyle = style4;
            cell0154.CellStyle = style4;
            cell0155.CellStyle = style4;
            cell0156.CellStyle = style4;
            cell0157.CellStyle = style4;
            cell0158.CellStyle = style4;

            //创建列
            HSSFCell cell0161 = (HSSFCell)row16.CreateCell(0);
            HSSFCell cell0162 = (HSSFCell)row16.CreateCell(1);
            HSSFCell cell0163 = (HSSFCell)row16.CreateCell(2);
            HSSFCell cell0164 = (HSSFCell)row16.CreateCell(3);
            HSSFCell cell0165 = (HSSFCell)row16.CreateCell(4);
            HSSFCell cell0166 = (HSSFCell)row16.CreateCell(5);
            HSSFCell cell0167 = (HSSFCell)row16.CreateCell(6);
            HSSFCell cell0168 = (HSSFCell)row16.CreateCell(7);


            cell0161.SetCellValue("序号");
            cell0162.SetCellValue("包装条件");
            cell0163.SetCellValue("物资名称和物资来源");
            cell0164.SetCellValue("外包装表面沾污(Bq/cm2)");
            cell0165.SetCellValue("货包接触剂量率(Sv/h)");
            cell0166.SetCellValue("外包装表面沾污(Bq/cm2)");
            cell0167.SetCellValue("货包接触剂量率(Sv/h)");
            cell0168.SetCellValue("备注");

            cell0161.CellStyle = style3;
            cell0162.CellStyle = style3;
            cell0163.CellStyle = style3;
            cell0164.CellStyle = style3;
            cell0165.CellStyle = style3;
            cell0166.CellStyle = style3;
            cell0167.CellStyle = style3;
            cell0168.CellStyle = style3;
  



            #endregion

            #region jqgrid

            if (datalist.Count == 0)
            {
                HSSFRow row17 = (HSSFRow)sheet1.CreateRow(16);
                sheet1.AddMergedRegion(new CellRangeAddress(16, 16, 0, 7));
                
                //创建列
                HSSFCell cell0171 = (HSSFCell)row17.CreateCell(0);
                HSSFCell cell0172 = (HSSFCell)row17.CreateCell(1);
                HSSFCell cell0173 = (HSSFCell)row17.CreateCell(2);
                HSSFCell cell0174 = (HSSFCell)row17.CreateCell(3);
                HSSFCell cell0175 = (HSSFCell)row17.CreateCell(4);
                HSSFCell cell0176 = (HSSFCell)row17.CreateCell(5);
                HSSFCell cell0177 = (HSSFCell)row17.CreateCell(6);
                HSSFCell cell0178 = (HSSFCell)row17.CreateCell(7);
                cell0171.SetCellValue("无"); 
                cell0171.CellStyle = style3;
                cell0172.CellStyle = style3;
                cell0173.CellStyle = style3;
                cell0174.CellStyle = style3;
                cell0175.CellStyle = style3;
                cell0176.CellStyle = style3;
                cell0177.CellStyle = style3;
                cell0178.CellStyle = style3;

                HSSFRow row18 = (HSSFRow)sheet1.CreateRow(17);
                sheet1.AddMergedRegion(new CellRangeAddress(17, 17, 0, 7));
                HSSFCell cell0181 = (HSSFCell)row18.CreateCell(0);
                cell0181.SetCellValue("      注：运输方式、货包/车辆相关要求、过渡区清单见登记表背面。");
                HSSFRow row19 = (HSSFRow)sheet1.CreateRow(18);
                sheet1.AddMergedRegion(new CellRangeAddress(18, 18, 0, 7));
                HSSFCell cell0191 = (HSSFCell)row19.CreateCell(0);
                cell0191.SetCellValue("           第一联（白色）：交辐射防护值班人员存档");
                HSSFRow row20 = (HSSFRow)sheet1.CreateRow(19);
                sheet1.AddMergedRegion(new CellRangeAddress(19, 19, 0, 7));
                HSSFCell cell0201 = (HSSFCell)row20.CreateCell(0);
                cell0201.SetCellValue("           第二联（粉红色）：随物质到达目的地后，由运输工作负责人交目的地辐射防护人员。");
            }

            if (datalist.Count == 1)
            {
                count1(datalist, sheet1, style3);
                HSSFRow row18 = (HSSFRow)sheet1.CreateRow(17);
                sheet1.AddMergedRegion(new CellRangeAddress(17, 17, 0, 7));
                HSSFCell cell0181 = (HSSFCell)row18.CreateCell(0);
                cell0181.SetCellValue("      注：运输方式、货包/车辆相关要求、过渡区清单见登记表背面。");
                HSSFRow row19 = (HSSFRow)sheet1.CreateRow(18);
                sheet1.AddMergedRegion(new CellRangeAddress(18, 18, 0, 7));
                HSSFCell cell0191 = (HSSFCell)row19.CreateCell(0);
                cell0191.SetCellValue("           第一联（白色）：交辐射防护值班人员存档");
                HSSFRow row20 = (HSSFRow)sheet1.CreateRow(19);
                sheet1.AddMergedRegion(new CellRangeAddress(19, 19, 0, 7));
                HSSFCell cell0201 = (HSSFCell)row20.CreateCell(0);
                cell0201.SetCellValue("           第二联（粉红色）：随物质到达目的地后，由运输工作负责人交目的地辐射防护人员。");
            }
            if (datalist.Count == 2)
            {
                Count2(datalist, sheet1, style3);

                HSSFRow row19 = (HSSFRow)sheet1.CreateRow(18);
                sheet1.AddMergedRegion(new CellRangeAddress(18, 18, 0, 7));
                HSSFCell cell0191 = (HSSFCell)row19.CreateCell(0);
                cell0191.SetCellValue("      注：运输方式、货包/车辆相关要求、过渡区清单见登记表背面。");
                HSSFRow row20 = (HSSFRow)sheet1.CreateRow(19);
                sheet1.AddMergedRegion(new CellRangeAddress(19, 19, 0, 7));
                HSSFCell cell0201 = (HSSFCell)row20.CreateCell(0);
                cell0201.SetCellValue("           第一联（白色）：交辐射防护值班人员存档");
                HSSFRow row21 = (HSSFRow)sheet1.CreateRow(20);
                sheet1.AddMergedRegion(new CellRangeAddress(20, 20, 0, 7));
                HSSFCell cell0211 = (HSSFCell)row21.CreateCell(0);
                cell0211.SetCellValue("           第二联（粉红色）：随物质到达目的地后，由运输工作负责人交目的地辐射防护人员。");
            }
            if (datalist.Count == 3)
            {
                Count3(datalist, sheet1, style3);

                HSSFRow row20 = (HSSFRow)sheet1.CreateRow(19);
                sheet1.AddMergedRegion(new CellRangeAddress(19, 19, 0, 7));
                HSSFCell cell0201 = (HSSFCell)row20.CreateCell(0);
                cell0201.SetCellValue("      注：运输方式、货包/车辆相关要求、过渡区清单见登记表背面。");
                HSSFRow row21 = (HSSFRow)sheet1.CreateRow(20);
                sheet1.AddMergedRegion(new CellRangeAddress(20, 20, 0, 7));
                HSSFCell cell0211 = (HSSFCell)row21.CreateCell(0);
                cell0211.SetCellValue("           第一联（白色）：交辐射防护值班人员存档");
                HSSFRow row22 = (HSSFRow)sheet1.CreateRow(21);
                sheet1.AddMergedRegion(new CellRangeAddress(21, 21, 0, 7));
                HSSFCell cell0221 = (HSSFCell)row22.CreateCell(0);
                cell0221.SetCellValue("           第二联（粉红色）：随物质到达目的地后，由运输工作负责人交目的地辐射防护人员。");
            }
            if (datalist.Count == 4)
            {
                Count4(datalist, sheet1, style3);

                HSSFRow row21 = (HSSFRow)sheet1.CreateRow(20);
                sheet1.AddMergedRegion(new CellRangeAddress(20, 20, 0, 7));
                HSSFCell cell0211 = (HSSFCell)row21.CreateCell(0);
                cell0211.SetCellValue("      注：运输方式、货包/车辆相关要求、过渡区清单见登记表背面。");
                HSSFRow row22 = (HSSFRow)sheet1.CreateRow(21);
                sheet1.AddMergedRegion(new CellRangeAddress(21, 21, 0, 7));
                HSSFCell cell0221 = (HSSFCell)row22.CreateCell(0);
                cell0221.SetCellValue("           第一联（白色）：交辐射防护值班人员存档");
                HSSFRow row23 = (HSSFRow)sheet1.CreateRow(22);
                sheet1.AddMergedRegion(new CellRangeAddress(22, 22, 0, 7));
                HSSFCell cell0231 = (HSSFCell)row23.CreateCell(0);
                cell0231.SetCellValue("           第二联（粉红色）：随物质到达目的地后，由运输工作负责人交目的地辐射防护人员。");
            }
            if (datalist.Count == 5)
            {
                Count5(datalist, sheet1, style3);

                HSSFRow row22 = (HSSFRow)sheet1.CreateRow(21);
                sheet1.AddMergedRegion(new CellRangeAddress(21, 21, 0, 7));
                HSSFCell cell0221 = (HSSFCell)row22.CreateCell(0);
                cell0221.SetCellValue("      注：运输方式、货包/车辆相关要求、过渡区清单见登记表背面。");
                HSSFRow row23 = (HSSFRow)sheet1.CreateRow(22);
                sheet1.AddMergedRegion(new CellRangeAddress(22, 22, 0, 7));
                HSSFCell cell0231 = (HSSFCell)row23.CreateCell(0);
                cell0231.SetCellValue("           第一联（白色）：交辐射防护值班人员存档");
                HSSFRow row24 = (HSSFRow)sheet1.CreateRow(23);
                sheet1.AddMergedRegion(new CellRangeAddress(23, 23, 0, 7));
                HSSFCell cell0241 = (HSSFCell)row24.CreateCell(0);
                cell0241.SetCellValue("           第二联（粉红色）：随物质到达目的地后，由运输工作负责人交目的地辐射防护人员。");
            }

            #endregion

            #region  工作流
            //工作流
            MemoryStream stream = new MemoryStream();
            hssfworkbook.Write(stream);

            string saveFileName = string.Format("{0}_{1}.xls", "NuclearRubTransfer", DateTime.Now.ToString("yyyy-MM-dd"));
            string fileName = Server.MapPath("~") + "\\ExcelTemplate\\" + saveFileName;
            SaveToFile(stream, fileName);
            FileInfo downLoadFile = new FileInfo(fileName);
            System.Web.HttpContext context = System.Web.HttpContext.Current;
            context.Response.Clear();
            context.Response.ClearHeaders();
            context.Response.Buffer = false;
            context.Response.ContentType = "application/octet-stream";
            context.Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlDecode(saveFileName, System.Text.Encoding.UTF8));
            context.Response.AddHeader("content-length", downLoadFile.Length.ToString());
            context.Response.WriteFile(downLoadFile.FullName);
            context.Response.Flush();
            context.Response.End();
            if (System.IO.File.Exists(fileName))
            {
                System.IO.File.Delete(fileName);
            }

        }
        /// <summary>
        /// jqgrid有5条数据时调取该方法
        /// </summary>
        /// <param name="datalist"></param>
        /// <param name="sheet1"></param>
        /// <param name="style3"></param>
        private static void Count5(List<NuclearRubTransDetail> datalist, HSSFSheet sheet1, HSSFCellStyle style3)
        {
            Count4(datalist, sheet1, style3);

            HSSFRow row21 = (HSSFRow)sheet1.CreateRow(20);
            NuclearRubTransDetail item4 = datalist[4];
            //创建列
            HSSFCell cell0211 = (HSSFCell)row21.CreateCell(0);
            HSSFCell cell0212 = (HSSFCell)row21.CreateCell(1);
            HSSFCell cell0213 = (HSSFCell)row21.CreateCell(2);
            HSSFCell cell0214 = (HSSFCell)row21.CreateCell(3);
            HSSFCell cell0215 = (HSSFCell)row21.CreateCell(4);
            HSSFCell cell0216 = (HSSFCell)row21.CreateCell(5);
            HSSFCell cell0217 = (HSSFCell)row21.CreateCell(6);
            HSSFCell cell0218 = (HSSFCell)row21.CreateCell(7);

            cell0211.SetCellValue("5");
            cell0212.SetCellValue(item4.PackageCondition);
            cell0213.SetCellValue(item4.MatterSource);
            cell0214.SetCellValue(item4.SullySurfaceA.ToString());
            cell0215.SetCellValue(item4.DoseSurfaceA.ToString());
            cell0216.SetCellValue(item4.SullySurfaceB.ToString());
            cell0217.SetCellValue(item4.DoseSurfaceB.ToString());
            cell0218.SetCellValue(item4.Remark);
            cell0211.CellStyle = style3;
            cell0212.CellStyle = style3;
            cell0213.CellStyle = style3;
            cell0214.CellStyle = style3;
            cell0215.CellStyle = style3;
            cell0216.CellStyle = style3;
            cell0217.CellStyle = style3;
            cell0218.CellStyle = style3;
        }
        /// <summary>
        /// jqgrid有4条数据时调取该方法
        /// </summary>
        /// <param name="datalist"></param>
        /// <param name="sheet1"></param>
        /// <param name="style3"></param>
        private static void Count4(List<NuclearRubTransDetail> datalist, HSSFSheet sheet1, HSSFCellStyle style3)
        {
            Count3(datalist, sheet1, style3);

            HSSFRow row20 = (HSSFRow)sheet1.CreateRow(19);
            NuclearRubTransDetail item3 = datalist[3];
            //创建列
            HSSFCell cell0201 = (HSSFCell)row20.CreateCell(0);
            HSSFCell cell0202 = (HSSFCell)row20.CreateCell(1);
            HSSFCell cell0203 = (HSSFCell)row20.CreateCell(2);
            HSSFCell cell0204 = (HSSFCell)row20.CreateCell(3);
            HSSFCell cell0205 = (HSSFCell)row20.CreateCell(4);
            HSSFCell cell0206 = (HSSFCell)row20.CreateCell(5);
            HSSFCell cell0207 = (HSSFCell)row20.CreateCell(6);
            HSSFCell cell0208 = (HSSFCell)row20.CreateCell(7);

            cell0201.SetCellValue("4");
            cell0202.SetCellValue(item3.PackageCondition);
            cell0203.SetCellValue(item3.MatterSource);
            cell0204.SetCellValue(item3.SullySurfaceA.ToString());
            cell0205.SetCellValue(item3.DoseSurfaceA.ToString());
            cell0206.SetCellValue(item3.SullySurfaceB.ToString());
            cell0207.SetCellValue(item3.DoseSurfaceB.ToString());
            cell0208.SetCellValue(item3.Remark);
            cell0201.CellStyle = style3;
            cell0202.CellStyle = style3;
            cell0203.CellStyle = style3;
            cell0204.CellStyle = style3;
            cell0205.CellStyle = style3;
            cell0206.CellStyle = style3;
            cell0207.CellStyle = style3;
            cell0208.CellStyle = style3;
        }
        /// <summary>
        /// jqgrid有3条数据时调取该方法
        /// </summary>
        /// <param name="datalist"></param>
        /// <param name="sheet1"></param>
        /// <param name="style3"></param>
        private static void Count3(List<NuclearRubTransDetail> datalist, HSSFSheet sheet1, HSSFCellStyle style3)
        {
            Count2(datalist, sheet1, style3);

            HSSFRow row19 = (HSSFRow)sheet1.CreateRow(18);
            NuclearRubTransDetail item2 = datalist[2];
            //创建列
            HSSFCell cell0191 = (HSSFCell)row19.CreateCell(0);
            HSSFCell cell0192 = (HSSFCell)row19.CreateCell(1);
            HSSFCell cell0193 = (HSSFCell)row19.CreateCell(2);
            HSSFCell cell0194 = (HSSFCell)row19.CreateCell(3);
            HSSFCell cell0195 = (HSSFCell)row19.CreateCell(4);
            HSSFCell cell0196 = (HSSFCell)row19.CreateCell(5);
            HSSFCell cell0197 = (HSSFCell)row19.CreateCell(6);
            HSSFCell cell0198 = (HSSFCell)row19.CreateCell(7);

            cell0191.SetCellValue("3");
            cell0192.SetCellValue(item2.PackageCondition);
            cell0193.SetCellValue(item2.MatterSource);
            cell0194.SetCellValue(item2.SullySurfaceA.ToString());
            cell0195.SetCellValue(item2.DoseSurfaceA.ToString());
            cell0196.SetCellValue(item2.SullySurfaceB.ToString());
            cell0197.SetCellValue(item2.DoseSurfaceB.ToString());
            cell0198.SetCellValue(item2.Remark);
            cell0191.CellStyle = style3;
            cell0192.CellStyle = style3;
            cell0193.CellStyle = style3;
            cell0194.CellStyle = style3;
            cell0195.CellStyle = style3;
            cell0196.CellStyle = style3;
            cell0197.CellStyle = style3;
            cell0198.CellStyle = style3;
        }
        /// <summary>
        /// jqgrid有2条数据时调取该方法
        /// </summary>
        /// <param name="datalist"></param>
        /// <param name="sheet1"></param>
        /// <param name="style3"></param>
        private static void Count2(List<NuclearRubTransDetail> datalist, HSSFSheet sheet1, HSSFCellStyle style3)
        {
            count1(datalist, sheet1, style3);

            HSSFRow row18 = (HSSFRow)sheet1.CreateRow(17);
            NuclearRubTransDetail item1 = datalist[1];
            //创建列
            HSSFCell cell0181 = (HSSFCell)row18.CreateCell(0);
            HSSFCell cell0182 = (HSSFCell)row18.CreateCell(1);
            HSSFCell cell0183 = (HSSFCell)row18.CreateCell(2);
            HSSFCell cell0184 = (HSSFCell)row18.CreateCell(3);
            HSSFCell cell0185 = (HSSFCell)row18.CreateCell(4);
            HSSFCell cell0186 = (HSSFCell)row18.CreateCell(5);
            HSSFCell cell0187 = (HSSFCell)row18.CreateCell(6);
            HSSFCell cell0188 = (HSSFCell)row18.CreateCell(7);

            cell0181.SetCellValue("2");
            cell0182.SetCellValue(item1.PackageCondition);
            cell0183.SetCellValue(item1.MatterSource);
            cell0184.SetCellValue(item1.SullySurfaceA.ToString());
            cell0185.SetCellValue(item1.DoseSurfaceA.ToString());
            cell0186.SetCellValue(item1.SullySurfaceB.ToString());
            cell0187.SetCellValue(item1.DoseSurfaceB.ToString());
            cell0188.SetCellValue(item1.Remark);
            cell0181.CellStyle = style3;
            cell0182.CellStyle = style3;
            cell0183.CellStyle = style3;
            cell0184.CellStyle = style3;
            cell0185.CellStyle = style3;
            cell0186.CellStyle = style3;
            cell0187.CellStyle = style3;
            cell0188.CellStyle = style3;
        }
        /// <summary>
        /// jqgrid有1条数据时调取该方法
        /// </summary>
        /// <param name="datalist"></param>
        /// <param name="sheet1"></param>
        /// <param name="style3"></param>
        private static void count1(List<NuclearRubTransDetail> datalist, HSSFSheet sheet1, HSSFCellStyle style3)
        {
            HSSFRow row17 = (HSSFRow)sheet1.CreateRow(16);
            NuclearRubTransDetail item0 = datalist[0];
            //创建列
            HSSFCell cell0171 = (HSSFCell)row17.CreateCell(0);
            HSSFCell cell0172 = (HSSFCell)row17.CreateCell(1);
            HSSFCell cell0173 = (HSSFCell)row17.CreateCell(2);
            HSSFCell cell0174 = (HSSFCell)row17.CreateCell(3);
            HSSFCell cell0175 = (HSSFCell)row17.CreateCell(4);
            HSSFCell cell0176 = (HSSFCell)row17.CreateCell(5);
            HSSFCell cell0177 = (HSSFCell)row17.CreateCell(6);
            HSSFCell cell0178 = (HSSFCell)row17.CreateCell(7);

            cell0171.SetCellValue("1");
            cell0172.SetCellValue(item0.PackageCondition);
            cell0173.SetCellValue(item0.MatterSource);
            cell0174.SetCellValue(item0.SullySurfaceA.ToString());
            cell0175.SetCellValue(item0.DoseSurfaceA.ToString());
            cell0176.SetCellValue(item0.SullySurfaceB.ToString());
            cell0177.SetCellValue(item0.DoseSurfaceB.ToString());
            cell0178.SetCellValue(item0.Remark);
            cell0171.CellStyle = style3;
            cell0172.CellStyle = style3;
            cell0173.CellStyle = style3;
            cell0174.CellStyle = style3;
            cell0175.CellStyle = style3;
            cell0176.CellStyle = style3;
            cell0177.CellStyle = style3;
            cell0178.CellStyle = style3;
        }

        private void SaveToFile(MemoryStream ms, string fileName)
        {
            using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write))
            {
                byte[] data = ms.ToArray();

                fs.Write(data, 0, data.Length);
                fs.Flush();
                data = null;
            }
        }
        #endregion

        #endregion


        #region 导出excel
        ///// <summary>
        ///// 导出WORD格式的出库单
        ///// </summary>
        ///// <param name="outputId">出库单ID</param>
        ///// <returns></returns>
        //[HttpGet]
        //[UbaFilter(OperateType = OperateType.Button, OperateDescription = "运输单导出")]
        //public ActionResult PrintRubTransfer(string id)
        //{

        //    Export(id);
        //    return null;
        //}

        ///// <summary>
        ///// 将文件输出到页面
        ///// </summary>
        ///// <param name="page"></param>
        ///// <param name="fileStream">文件流</param>
        ///// <param name="saveFileName">用户默认保存名称</param>
        //private void Export(string TransId)
        //{
        //    //得到当前登陆者的出库申请单信息
        //    NuclearRubTrans nuclearRubTrans = _NuclearRubTransRepository.Get(TransId);
        //    List<NuclearRubTrans> nuclearRubTransList = new List<NuclearRubTrans>();
        //    nuclearRubTransList.Add(nuclearRubTrans);

        //    NuclearRubTransDetail NuclearRubTransDetail = _NuclearRubTransDetailRepository.Get(TransId);
        //    List<NuclearRubTransDetail> NuclearRubTransDetailList = new List<NuclearRubTransDetail>();
        //    nuclearRubTransList.Add(nuclearRubTrans);

        //    //得到所有的入库申请单信息
        //    //List<ApplyInput> applyIntputList = iApplyInputRepository.QueryList().Where(c => c.InputId == NuclearRubTrans.InputId).ToList();

        //    //得到工厂基础信息
        //    //List<BasicObject> factoryList = iBasicObjectRepository.GetSubobjectsByName("工厂").ToList();
        //    List<BasicObject> MatterToList = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition").ToList();
        //    List<BasicObject> MatterFromList = _BasicObjectRepository.GetSubobjectsByCode("StorageLocation").ToList();

        //    //得到出库单信息
        //    List<RubTransferVM> rubTransferVMList = (from o in nuclearRubTransList
        //                                             //join a in applyIntputList on o.InputId equals a.InputId
        //                                             //join f in factoryList on a.FactoryId equals f.Uuid into factoryEmpt
        //                                             //from f in factoryEmpt
        //                                             //where a.InputId == o.InputId
        //                                             select new RubTransferVM
        //                                             {
        //                                                 NuclearRubTrans = o,
        //                                                 //BaseInfoName = f.Name,
        //                                                 //ApplyInput = a,
        //                                             }).ToList<RubTransferVM>();

        //    RubTransferVM RubTransferVM = new RubTransferVM();
        //    if (rubTransferVMList != null && rubTransferVMList.Count > 0)
        //    {
        //        RubTransferVM = rubTransferVMList[0];
        //        //NuclearRubTransDetail = NuclearRubTransDetailList[0];
        //    }

        //    RubTransferVM vm = new RubTransferVM();
        //    NuclearRubTrans model = _NuclearRubTransRepository.Get(TransId);
        //    vm.NuclearRubTrans = model;
        //    BasicObject BasicObject = new BasicObject();
        //    BasicObject basicObjectMatterFrom = _BasicObjectRepository.Get(model.MatterFrom);
        //    BasicObject basicObjectMatterTo = _BasicObjectRepository.Get(model.MatterFrom);

        //    vm.MatterFromName = basicObjectMatterFrom.Name;
        //    vm.MatterToName = basicObjectMatterTo.Name;
        //    //得到出库单详细信息
        //    IQueryable<NuclearRubTransDetail> data = this._NuclearRubTransDetailRepository.GetAll().Where(d => d.TransId == TransId).AsQueryable();
        //    List<NuclearRubTransDetail> datalist = data.ToList();

        //    //创建文档对象
        //    HSSFWorkbook hssfworkbook = new HSSFWorkbook();
        //    hssfworkbook.CreateSheet("new sheet");
        //    FileStream file = new FileStream(@"test.xls", FileMode.Create);
        //    hssfworkbook.Write(file);
        //    file.Close();

        //    //XWPFDocument m_Docx = new XWPFDocument();
        //    ////页面设置A4横向
        //    //CT_SectPr m_SectPr = new CT_SectPr();
        //    //m_SectPr.pgSz.w = (ulong)12906;
        //    //m_Docx.Document.body.sectPr = m_SectPr;

        //}

















        #endregion



       
    }
}
