﻿/********************************************************************************
 *
 *   项目名称   ：   核电废物信息系统
 *   文 件 名   ：   OtherTechnologyController.cs
 *   描    述   ：   OtherTechnologyController
 *   创 建 者   ：   郑浩宇 
 *   创建日期   ：   2016-09-13 12:01:45
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-13 12:01:45    1.0.0.0    郑浩宇       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Presentation.Web.Areas.OtherTechnology.Models;

using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.PublicInfo.Models;
using NET01.CoreFramework;
using RWIS.Domain.DomainObjects.View.OtherTechnology;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.Sorting;
using MvcContrib.UI.Grid;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;


namespace RWIS.Presentation.Web.Areas.OtherTechnology.Controllers
{
    public class OtherTechnologyController : Controller
    {

         INuclearWasteClearRepository _NuclearWasteClearRepository;
        INuclearWasteDegradeRepository _NuclearWasteDegradeRepository;
        INuclearWasteDismantleRepository _NuclearWasteDismantleRepository;
        INuclearWasteFireRepository _NuclearWasteFireRepository;
        INuclearWasteHDisposeRepository _NuclearWasteHDisposeRepository;
        INuclearWasteLDisposeRepository _NuclearWasteLDisposeRepository;
        INuclearWasteSmeltRepository _NuclearWasteSmeltRepository;
        INuclearSpecialPackageRepository _NuclearSpecialPackageRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearWasteOtherTechnologyRepository _NuclearWasteOtherTechnologyRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        ITrackLiquorRepository _TrackLiquorRepository;
        INuclearOtherTrackRepository _NuclearOtherTrackRepository;
        public OtherTechnologyController(INuclearSpecialPackageRepository _NuclearSpecialPackageRepository,
            INuclearWasteClearRepository _NuclearWasteClearRepository,
            INuclearWasteDegradeRepository _NuclearWasteDegradeRepository,
            INuclearWasteDismantleRepository _NuclearWasteDismantleRepository,
            INuclearWasteFireRepository _NuclearWasteFireRepository,
            INuclearWasteHDisposeRepository _NuclearWasteHDisposeRepository, 
            INuclearWasteLDisposeRepository _NuclearWasteLDisposeRepository,
            INuclearWasteSmeltRepository _NuclearWasteSmeltRepository, 
            IBasicObjectRepository _BasicObjectRepository,
            INuclearWastePackageRepository _NuclearWastePackageRepository,
            INuclearWasteOtherTechnologyRepository _NuclearWasteOtherTechnologyRepository,
            INuclearBucketRepository _NuclearBucketRepository,
            INuclearTempstockRepository _NuclearTempstockRepository,
            ITrackLiquorRepository _TrackLiquorRepository,
             INuclearOtherTrackRepository _NuclearOtherTrackRepository
            
            )
        {
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearWasteClearRepository = _NuclearWasteClearRepository;
            this._NuclearWasteDegradeRepository = _NuclearWasteDegradeRepository;
            this._NuclearWasteDismantleRepository = _NuclearWasteDismantleRepository;
            this._NuclearWasteFireRepository = _NuclearWasteFireRepository;
            this._NuclearWasteHDisposeRepository = _NuclearWasteHDisposeRepository;
            this._NuclearWasteLDisposeRepository = _NuclearWasteLDisposeRepository;
            this._NuclearWasteSmeltRepository = _NuclearWasteSmeltRepository;
            this._NuclearSpecialPackageRepository = _NuclearSpecialPackageRepository;
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
            this._NuclearWasteOtherTechnologyRepository = _NuclearWasteOtherTechnologyRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._NuclearTempstockRepository = _NuclearTempstockRepository;
            this._TrackLiquorRepository = _TrackLiquorRepository;
             this._NuclearOtherTrackRepository = _NuclearOtherTrackRepository;
             
        }

        #region 其他工艺 查询界面
        /// <summary>
        /// 其他工艺
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "其他工艺")]
        public ActionResult Index()
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            vm.OperationList = CommonHelper.GetOperationList("Other_Technology");//权限控制

            //加载废物类型下拉列表
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery!=null && wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
            }
            foreach (var item in wasteTypeIdList)
            {
                vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            return View(vm);
        }

        /// <summary>
        /// 初始查询所有验证单
        /// </summary>
        /// <param name="materialInputCondition"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetOtherTechnologyList(OtherTechnologyCondition condition, OtherTechnologyVM model,  string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
                      
            IQueryable<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode);
            IQueryable<OtherTechnologyView> data = this._NuclearWasteOtherTechnologyRepository.QueryList(condition).Where(d => d.StationCode == AppContext.CurrentUser.ProjectCode).OrderBy("CreateDate", SortDirection.Descending);
           IQueryable<OtherTechnologyQueryVM> query = from a in data
                                                      join t in iqueryTrackItem on a.TrackId equals t.TrackId into tEmpt
                                                      from t in tEmpt.DefaultIfEmpty()
                                                      select new OtherTechnologyQueryVM
                                                      {
                                                          OtherTechnologyView = a,
                                                          TrackCode = t.TrackCode
                                                      };
           if (!string.IsNullOrEmpty(condition.TrackId))
           {
               query = query.Where(d => d.TrackCode.Trim().ToUpper().Contains(condition.TrackId.Trim().ToUpper()));
           }
           query = query.OrderByDescending(c=>c.OtherTechnologyView.CreateDate);
           var pagedViewModel = new PagedViewModel<OtherTechnologyQueryVM>
            {
                Query = query,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            } 
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.OtherTechnologyView.OtherTechnologyId,
                    List = new List<object>() {    
                        d.OtherTechnologyView.OtherTechnologyId,
                        d.OtherTechnologyView.Code,
                        d.OtherTechnologyView.WorkTicket,
                        d.OtherTechnologyView.WasteType,
                        d.TrackCode,
                        d.OtherTechnologyView.Type,
                        string.IsNullOrEmpty(d.OtherTechnologyView.CheckUserNo)?string.Empty:"【"+d.OtherTechnologyView.CheckUserNo+"】"+d.OtherTechnologyView.CheckUserName,
                        d.OtherTechnologyView.Status
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 删除材料
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id, string type)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    if (type == "废物解控")
                    {
                        this._NuclearWasteClearRepository.DeleteById(id);
                    }
                    if (type == "废物降解")
                    {
                        this._NuclearWasteDegradeRepository.DeleteById(id);                     
                    }
                    if (type == "废物拆解")
                    {
                        this._NuclearWasteDismantleRepository.DeleteById(id);
                     }
                    if (type == "废物焚烧")
                    {
                        this._NuclearWasteFireRepository.DeleteById(id);
                    }
                    if (type == "极低放废物处理")
                    {
                        this._NuclearWasteLDisposeRepository.DeleteById(id);                       
                    }
                    if (type == "高整体容器处理废物")
                    {
                        this._NuclearWasteHDisposeRepository.DeleteById(id);
                     }
                    if (type == "废物熔炼")
                    {
                        this._NuclearWasteSmeltRepository.DeleteById(id);                  
                    }
                    if (type == "特殊包装")
                    {
                        this._NuclearSpecialPackageRepository.DeleteById(id);                      
                    }
                    this._NuclearWasteOtherTechnologyRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }


        public ActionResult Edit(string id, string type)
        {
            //存放地点下拉设置数据
            IQueryable<BasicObject> StorageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> StorageLocationList = new List<BasicObject>();
            if (StorageLocationQuery.Count() > 0)
            {
                StorageLocationList = StorageLocationQuery.ToList();
            }
            SelectList SelectList = new SelectList(StorageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;

            if (type == "NuclearWasteClear")
            {
                NuclearWasteClear nuclearWasteClear = _NuclearWasteClearRepository.Get(id);
                OtherTechnologyVM vm = new OtherTechnologyVM();
                vm.OperationList = CommonHelper.GetOperationList("Index_Fire");//权限控制

                NuclearWasteClear model = _NuclearWasteClearRepository.Get(id);
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.Code);
                if (Pac!=null)
                {
                    string bucketCode = Pac.BucketCode;
                    model.Code = bucketCode;
                }
              

                //桶状态
                vm.BucketStatusList = new List<SelectListItem>();
                vm.NuclearWasteClear = new NuclearWasteClear();
                vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
                //加载废物类型下拉列表
                vm.WasteTypeIdList = new List<SelectListItem>();
                IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
                List<BasicObject> wasteTypeIdList = new List<BasicObject>();
                if (wasteTypeIdQuery != null && wasteTypeIdQuery.Count() > 0)
                {
                    wasteTypeIdList = wasteTypeIdQuery.ToList();
                }
                foreach (var item in wasteTypeIdList)
                {
                    vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
                //加载解控后存储位置下拉列表
                vm.WastePositionList = new List<SelectListItem>();
                IQueryable<BasicObject> WastePositionQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
                List<BasicObject> wastePositionList = new List<BasicObject>();
                if (WastePositionQuery.Count() > 0)
                {
                    wastePositionList = WastePositionQuery.ToList();
                }
                foreach (var item in wastePositionList)
                {
                    vm.WastePositionList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }

                //加载结论
                vm.ClearFlagRodiodList = new List<SelectListItem>();
                vm.ClearFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ClearFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

                //RP测量结果
                vm.RpResultRodiodList = new List<SelectListItem>();
                vm.RpResultRodiodList.Add(new SelectListItem { Text = "满足解控需求", Value = "1", Selected = true });
                vm.RpResultRodiodList.Add(new SelectListItem { Text = "不满足解控需求", Value = "0" });

                //是否需要再处理
                vm.ReprocessFlagRodiodList = new List<SelectListItem>();
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == nuclearWasteClear.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    nuclearWasteClear.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    nuclearWasteClear.TrackId = null;
                }
                vm.NuclearWasteClear = nuclearWasteClear;


                //废物跟踪单列表
                List<NuclearOtherTrack> giftDetailList = _NuclearOtherTrackRepository.GetAll().Where(c => c.BusinessId == id).ToList();
                if (giftDetailList != null && giftDetailList.Count > 0)
                {
                    vm.GiftDetailList = new List<GiftDetailList>();
                    for (int i = 0; i < giftDetailList.Count; i++)
                    {
                        string tId = giftDetailList[i].TrackId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        GiftDetailList detail = new GiftDetailList();
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.GiftDetailList.Add(detail);
                    }
                }

                return View("IndexClear", vm);
            }

            if (type == "NuclearWasteDegrade")
            {
                NuclearWasteDegrade NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(id);
                OtherTechnologyVM vm = new OtherTechnologyVM();
                vm.OperationList = CommonHelper.GetOperationList("Index_Degrades");//权限控制

                NuclearWasteDegrade model = _NuclearWasteDegradeRepository.Get(id);
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.WasteCode);
                if (Pac!=null)
                {
                    string bucketCode = Pac.BucketCode;
                    model.WasteCode = bucketCode;
                }
              

                //桶状态
                vm.BucketStatusList = new List<SelectListItem>();

                vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
                //加载废物类型下拉列表
                vm.WasteTypeIdList = new List<SelectListItem>();
                IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType",AppContext.CurrentUser.ProjectCode);
                List<BasicObject> wasteTypeIdList = new List<BasicObject>();
                if (wasteTypeIdQuery!=null && wasteTypeIdQuery.Count() > 0)
                {
                    wasteTypeIdList = wasteTypeIdQuery.ToList();
                }
                foreach (var item in wasteTypeIdList)
                {
                    vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }

                //加载降解后存储位置下拉列表
                vm.WastePositionList = new List<SelectListItem>();
                IQueryable<BasicObject> WastePositionQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
                List<BasicObject> wastePositionList = new List<BasicObject>();
                if (WastePositionQuery.Count() > 0)
                {
                    wastePositionList = WastePositionQuery.ToList();
                }
                foreach (var item in wastePositionList)
                {
                    vm.WastePositionList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }

                //是否需要再处理
                vm.ReprocessFlagRodiodList = new List<SelectListItem>();
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });
                vm.NuclearWasteDegrade = NuclearWasteDegrade;

                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == NuclearWasteDegrade.TrackId).ToList();
                if (iqueryTrackItem.Count>0)
                {
                    NuclearWasteDegrade.TrackId = iqueryTrackItem[0].TrackCode;                 
                }
                else
                {
                    NuclearWasteDegrade.TrackId = null;
                }
                //修改数字显示格式
                if (vm.NuclearWasteDegrade.WasteDose != null)
                {
                    if (vm.NuclearWasteDegrade.WasteDose.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteDegrade.WasteDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteDegrade.WasteDose));
                    }
                }
                if (vm.NuclearWasteDegrade.ReprocessDose != null)
                {
                    if (vm.NuclearWasteDegrade.ReprocessDose.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteDegrade.ReprocessDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteDegrade.ReprocessDose));
                    }
                }

                //废物跟踪单列表
                List<NuclearOtherTrack> giftDetailList = _NuclearOtherTrackRepository.GetAll().Where(c => c.BusinessId == id).ToList();
                if (giftDetailList != null && giftDetailList.Count > 0)
                {
                    vm.GiftDetailList = new List<GiftDetailList>();
                    for (int i = 0; i < giftDetailList.Count; i++)
                    {
                        string tId = giftDetailList[i].TrackId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        GiftDetailList detail = new GiftDetailList();
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.GiftDetailList.Add(detail);
                    }
                }

                return View("IndexDegrades", vm);

            }
            if (type == "NuclearWasteDismantle")
            {
                NuclearWasteDismantle nuclearWasteDismantle = _NuclearWasteDismantleRepository.Get(id);
                OtherTechnologyVM vm = new OtherTechnologyVM();
                vm.OperationList = CommonHelper.GetOperationList("Index_Dismantle");//权限控制

                NuclearWasteDismantle model = _NuclearWasteDismantleRepository.Get(id);
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.Code);
                if (Pac != null)
                {
                    string bucketCode = Pac.BucketCode;
                    model.Code = bucketCode;
                }

               

                //桶状态
                vm.BucketStatusList = new List<SelectListItem>();
                vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
                //加载废物类型下拉列表
                vm.WasteTypeIdList = new List<SelectListItem>();
                IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
                List<BasicObject> wasteTypeIdList = new List<BasicObject>();
                if (wasteTypeIdQuery != null && wasteTypeIdQuery.Count() > 0)
                {
                    wasteTypeIdList = wasteTypeIdQuery.ToList();
                }
                foreach (var item in wasteTypeIdList)
                {
                    vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }

                //加载拆解方式下拉列表
                vm.DismantleWayList = new List<SelectListItem>();
                IQueryable<BasicObject> dismantleWayQuery = _BasicObjectRepository.GetSubobjectsByCode("DismantleWay",AppContext.CurrentUser.ProjectCode);
                List<BasicObject> dismantleWayList = new List<BasicObject>();
                if (dismantleWayQuery!=null && dismantleWayQuery.Count() > 0)
                {
                    dismantleWayList = dismantleWayQuery.ToList();
                }
                foreach (var item in dismantleWayList)
                {
                    vm.DismantleWayList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }

                //加载拆解后存储位置下拉列表
                vm.SaveFactoryList = new List<SelectListItem>();
                IQueryable<BasicObject> saveFactoryQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory",AppContext.CurrentUser.ProjectCode);
                List<BasicObject> saveFactoryList = new List<BasicObject>();
                if (saveFactoryQuery.Count() > 0)
                {
                    saveFactoryList = saveFactoryQuery.ToList();
                }
                foreach (var item in saveFactoryList)
                {
                    vm.SaveFactoryList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }

                //存储方式-暂存包装容器
                vm.SaveFlagCodeList = new List<SelectListItem>();
                vm.SaveFlagCodeList.Add(new SelectListItem { Text = "暂存包装容器", Value = "1", Selected = true });

                //存储方式-暂存厂房
                vm.SaveFlagFactoryList = new List<SelectListItem>();
                vm.SaveFlagFactoryList.Add(new SelectListItem { Text = "暂存厂房", Value = "0" });

                //是否需要再处理
                vm.ReprocessFlagRodiodList = new List<SelectListItem>();
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });
                vm.NuclearWasteDismantle = nuclearWasteDismantle;
                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == nuclearWasteDismantle.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    nuclearWasteDismantle.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    nuclearWasteDismantle.TrackId = null;
                }
               

                //修改数字显示格式
                if (vm.NuclearWasteDismantle.DoseEva != null)
                {
                    if (vm.NuclearWasteDismantle.DoseEva.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteDismantle.DoseEva = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteDismantle.DoseEva));
                    }
                }
                if (vm.NuclearWasteDismantle.DoseMax != null)
                {
                    if (vm.NuclearWasteDismantle.DoseMax.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteDismantle.DoseMax = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteDismantle.DoseMax));
                    }
                }


                //废物跟踪单列表
                List<NuclearOtherTrack> giftDetailList = _NuclearOtherTrackRepository.GetAll().Where(c => c.BusinessId == id).ToList();
                if (giftDetailList != null && giftDetailList.Count > 0)
                {
                    vm.GiftDetailList = new List<GiftDetailList>();
                    for (int i = 0; i < giftDetailList.Count; i++)
                    {
                        string tId = giftDetailList[i].TrackId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        GiftDetailList detail = new GiftDetailList();
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.GiftDetailList.Add(detail);
                    }
                }

                return View("IndexDismantle", vm);
            }

            if (type == "NuclearWasteFire")
            {
                NuclearWasteFire nuclearWasteFire = _NuclearWasteFireRepository.Get(id);
                OtherTechnologyVM vm = new OtherTechnologyVM();
                vm.OperationList = CommonHelper.GetOperationList("Index_Fire");//权限控制

                NuclearWasteFire model = _NuclearWasteFireRepository.Get(id);
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.WasteCode);
                if (Pac != null)
                {
                    string bucketCode = Pac.BucketCode;
                    model.WasteCode = bucketCode;
                }
                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == nuclearWasteFire.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    nuclearWasteFire.TrackId = iqueryTrackItem[0].TrackCode;

                }
                else
                {
                    nuclearWasteFire.TrackId = null;
                }

                //桶状态
                vm.BucketStatusList = new List<SelectListItem>();
                vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
                //加载废物类型下拉列表
                vm.WasteTypeIdList = new List<SelectListItem>();
                IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType",AppContext.CurrentUser.ProjectCode);
                List<BasicObject> wasteTypeIdList = new List<BasicObject>();
                if (wasteTypeIdQuery!=null && wasteTypeIdQuery.Count() > 0)
                {
                    wasteTypeIdList = wasteTypeIdQuery.ToList();
                }
                foreach (var item in wasteTypeIdList)
                {
                    vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }

                //加载是否可以焚烧
                vm.FireFlagRodiodList = new List<SelectListItem>();
                vm.FireFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.FireFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

                //是否需要再处理
                vm.ReprocessFlagRodiodList = new List<SelectListItem>();
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });
                vm.NuclearWasteFire = nuclearWasteFire;

                //修改数字显示格式
                if (vm.NuclearWasteFire.ReprocessDose != null)
                {
                    if (vm.NuclearWasteFire.ReprocessDose.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteFire.ReprocessDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteFire.ReprocessDose));
                    }
                }
                if (vm.NuclearWasteFire.RubbishDoseEva != null)
                {
                    if (vm.NuclearWasteFire.RubbishDoseEva.Value.ToString().IndexOf('.') > 0)
                    {
                    vm.NuclearWasteFire.RubbishDoseEva = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteFire.RubbishDoseEva));
                    }
                }
                if (vm.NuclearWasteFire.RubbishDoseMax != null)
                {
                    if (vm.NuclearWasteFire.RubbishDoseMax.Value.ToString().IndexOf('.') > 0)
                    {
                    vm.NuclearWasteFire.RubbishDoseMax = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteFire.RubbishDoseMax));
                    }
                }

                //废物跟踪单列表
                List<NuclearOtherTrack> giftDetailList = _NuclearOtherTrackRepository.GetAll().Where(c => c.BusinessId == id).ToList();
                if (giftDetailList != null && giftDetailList.Count > 0)
                {
                    vm.GiftDetailList = new List<GiftDetailList>();
                    for (int i = 0; i < giftDetailList.Count; i++)
                    {
                        string tId = giftDetailList[i].TrackId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        GiftDetailList detail = new GiftDetailList();
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.GiftDetailList.Add(detail);
                    }
                }

                return View("IndexFire", vm);

            }

            if (type == "NuclearWasteLDispose")
            {
                NuclearWasteLDispose nuclearWasteLDispose = _NuclearWasteLDisposeRepository.Get(id);
                OtherTechnologyVM vm = new OtherTechnologyVM();
                vm.OperationList = CommonHelper.GetOperationList("Index_L_Dispose");//权限控制

                NuclearWasteLDispose model = _NuclearWasteLDisposeRepository.Get(id);
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.Code);
                if (Pac != null)
                {
                    string bucketCode = Pac.BucketCode;
                    model.Code = bucketCode;
                }
                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == nuclearWasteLDispose.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    nuclearWasteLDispose.TrackId = iqueryTrackItem[0].TrackCode;

                }
                else
                {
                    nuclearWasteLDispose.TrackId = null;
                }
                //桶状态
                vm.BucketStatusList = new List<SelectListItem>();

                vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
                //加载废物类型下拉列表
                vm.WasteTypeIdList = new List<SelectListItem>();
                IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
                List<BasicObject> wasteTypeIdList = new List<BasicObject>();
                if (wasteTypeIdQuery != null && wasteTypeIdQuery.Count() > 0)
                {
                    wasteTypeIdList = wasteTypeIdQuery.ToList();
                }
                foreach (var item in wasteTypeIdList)
                {
                    vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }

                //加载降解后存储位置下拉列表
                vm.WastePositionList = new List<SelectListItem>();
                IQueryable<BasicObject> WastePositionQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
                List<BasicObject> wastePositionList = new List<BasicObject>();
                if (WastePositionQuery.Count() > 0)
                {
                    wastePositionList = WastePositionQuery.ToList();
                }
                foreach (var item in wastePositionList)
                {
                    vm.WastePositionList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }

                //是否需要再处理
                vm.ReprocessFlagRodiodList = new List<SelectListItem>();
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });
                vm.NuclearWasteLDispose = nuclearWasteLDispose;
                //修改数字显示格式
                if (vm.NuclearWasteLDispose.WasteDose!=null)
                {
                    if (vm.NuclearWasteLDispose.WasteDose.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteLDispose.WasteDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteLDispose.WasteDose));
                    }
                }

                //废物跟踪单列表
                List<NuclearOtherTrack> giftDetailList = _NuclearOtherTrackRepository.GetAll().Where(c => c.BusinessId == id).ToList();
                if (giftDetailList != null && giftDetailList.Count > 0)
                {
                    vm.GiftDetailList = new List<GiftDetailList>();
                    for (int i = 0; i < giftDetailList.Count; i++)
                    {
                        string tId = giftDetailList[i].TrackId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        GiftDetailList detail = new GiftDetailList();
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.GiftDetailList.Add(detail);
                    }
                }

                return View("IndexLDispose", vm);
            }

            if (type == "NuclearWasteHDispose")
            {
                OtherTechnologyVM vm = new OtherTechnologyVM();
                vm.OperationList = CommonHelper.GetOperationList("Index_H_Dispose");//权限控制

                NuclearWasteHDispose model = _NuclearWasteHDisposeRepository.Get(id);
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.ContainerCode);
                if (Pac != null)
                {
                    string bucketCode = Pac.BucketCode;
                    model.ContainerCode = bucketCode;
                }
                 List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    model.TrackId = null;
                }
               
                NuclearWasteHDispose nuclearWasteHDispose = _NuclearWasteHDisposeRepository.Get(id);                
                   
                //桶状态
                vm.BucketStatusList = new List<SelectListItem>();
                vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
                //加载废物类型下拉列表
                vm.WasteTypeIdList = new List<SelectListItem>();
                IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
                List<BasicObject> wasteTypeIdList = new List<BasicObject>();
                if (wasteTypeIdQuery != null && wasteTypeIdQuery.Count() > 0)
                {
                    wasteTypeIdList = wasteTypeIdQuery.ToList();
                }
                foreach (var item in wasteTypeIdList)
                {
                    vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
                vm.NuclearWasteHDispose = nuclearWasteHDispose;

                //修改数字显示格式
                if (vm.NuclearWasteHDispose.WasteDose != null)
                {
                    if (vm.NuclearWasteHDispose.WasteDose.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.WasteDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.WasteDose));
                    }
                }
                if (vm.NuclearWasteHDispose.WasteDose != null)
                {
                    if (vm.NuclearWasteHDispose.ContainerWeight.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.ContainerWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.ContainerWeight));
                    }
                 }
                if (vm.NuclearWasteHDispose.ContainerPosition != null)
                {
                    if (vm.NuclearWasteHDispose.ContainerPosition.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.ContainerPosition = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.ContainerPosition));
                    }
                }
                if (vm.NuclearWasteHDispose.DoseEva != null)
                {
                    if (vm.NuclearWasteHDispose.DoseEva.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.DoseEva = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.DoseEva));
                    }
                }
                if (vm.NuclearWasteHDispose.DoseMax != null)
                {
                    if (vm.NuclearWasteHDispose.DoseMax.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.DoseMax = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.DoseMax));
                    }
                 }
                if (vm.NuclearWasteHDispose.DoseMeter != null)
                {
                    if (vm.NuclearWasteHDispose.DoseMeter.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.DoseMeter = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.DoseMeter));
                    }
                 }


                //废物跟踪单列表
                List<NuclearOtherTrack> giftDetailList = _NuclearOtherTrackRepository.GetAll().Where(c => c.BusinessId == id).ToList();
                if (giftDetailList != null && giftDetailList.Count > 0)
                {
                    vm.GiftDetailList = new List<GiftDetailList>();
                    for (int i = 0; i < giftDetailList.Count; i++)
                    {
                        string tId = giftDetailList[i].TrackId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        GiftDetailList detail = new GiftDetailList();
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.GiftDetailList.Add(detail);
                    }
                }

                return View("IndexHDispose", vm);
            }

            if (type == "NuclearWasteSmelt")
            {
                NuclearWasteSmelt nuclearWasteSmelt = _NuclearWasteSmeltRepository.Get(id);
                OtherTechnologyVM vm = new OtherTechnologyVM();
                vm.OperationList = CommonHelper.GetOperationList("Index_Smelt");//权限控制

                NuclearBucket Pac = _NuclearBucketRepository.Get(nuclearWasteSmelt.Code);
                if (Pac != null)
                {
                    string bucketCode = Pac.BucketCode;
                    nuclearWasteSmelt.Code = bucketCode;
                }
                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == nuclearWasteSmelt.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    nuclearWasteSmelt.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    nuclearWasteSmelt.TrackId = null;
                }

                //桶状态
                vm.BucketStatusList = new List<SelectListItem>();
                vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
                //加载废物类型下拉列表
                vm.WasteTypeIdList = new List<SelectListItem>();
                IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
                List<BasicObject> wasteTypeIdList = new List<BasicObject>();
                if (wasteTypeIdQuery != null && wasteTypeIdQuery.Count() > 0)
                {
                    wasteTypeIdList = wasteTypeIdQuery.ToList();
                }
                foreach (var item in wasteTypeIdList)
                {
                    vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
                vm.NuclearWasteSmelt = nuclearWasteSmelt;

                //修改数字显示格式
                if (vm.NuclearWasteSmelt.DoseEva != null)
                {
                    if (vm.NuclearWasteSmelt.DoseEva.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteSmelt.DoseEva = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteSmelt.DoseEva));
                    }
                }
                if (vm.NuclearWasteSmelt.DoseMax != null)
                {
                    if (vm.NuclearWasteSmelt.DoseMax.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteSmelt.DoseMax = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteSmelt.DoseMax));
                    }
                }

                //废物跟踪单列表
                List<NuclearOtherTrack> giftDetailList = _NuclearOtherTrackRepository.GetAll().Where(c => c.BusinessId == id).ToList();
                if (giftDetailList != null && giftDetailList.Count > 0)
                {
                    vm.GiftDetailList = new List<GiftDetailList>();
                    for (int i = 0; i < giftDetailList.Count; i++)
                    {
                        string tId = giftDetailList[i].TrackId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        GiftDetailList detail = new GiftDetailList();
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.GiftDetailList.Add(detail);
                    }
                }

                return View("IndexSmelt", vm);
            }
            
            if (type == "NuclearSpecialPackage")
            {
               
                OtherTechnologyVM vm = new OtherTechnologyVM();
                vm.OperationList = CommonHelper.GetOperationList("Index_Package");//权限控制

                NuclearSpecialPackage model = _NuclearSpecialPackageRepository.Get(id);
                NuclearBucket bucket = _NuclearBucketRepository.Get(model.Code);
                if (bucket != null)
                {
                    string bucketCode = bucket.BucketCode;
                    model.Code = bucketCode;
                }
                NuclearWastePackage Pac = _NuclearWastePackageRepository.Get(model.PackagedId);
                if (model.TrackId != null)
                {
                    List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }
                string evalNuclearSpecialPackage_PackagedFlag = Request.Form["NuclearSpecialPackage_PackagedFlag"];
                if (!string.IsNullOrEmpty(model.PackagedId))
                {
                    string packageCode = Pac.PackageCode;
                    model.PackagedId = packageCode;
                }
                //桶状态
                vm.BucketStatusList = new List<SelectListItem>();
                vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
                vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
                vm.NuclearSpecialPackage = model;


                //废物跟踪单列表
                List<NuclearOtherTrack> giftDetailList = _NuclearOtherTrackRepository.GetAll().Where(c => c.BusinessId == id).ToList();
                if (giftDetailList != null && giftDetailList.Count > 0)
                {
                    vm.GiftDetailList = new List<GiftDetailList>();
                    for (int i = 0; i < giftDetailList.Count; i++)
                    {
                        string tId = giftDetailList[i].TrackId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        GiftDetailList detail = new GiftDetailList();
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.GiftDetailList.Add(detail);
                    }
                }

                return View("IndexPackage", vm);
            }
            return View();
        }
        
        [HttpGet]
       new public ActionResult View(string id, string type)
        {
            if (type == "NuclearWasteClear")
            {
                OtherTechnologyVM vm = new OtherTechnologyVM();
                NuclearWasteClear model = _NuclearWasteClearRepository.Get(id);
                vm.NuclearWasteClear = model;
                BasicObject BasicObject = new BasicObject();
                BasicObject basicObjectWasteType = _BasicObjectRepository.Get(model.WasteTypeId);
                BasicObject basicObjectWastePosition = _BasicObjectRepository.Get(model.WastePosition);
                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();

                //通过废物跟踪id(TrackCode)获取获取废物跟踪单号
               
                if (iqueryTrackItem.Count > 0)
                {
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    model.TrackId = null;
                }

                vm.WasteTypeIdName = basicObjectWasteType.Name;
                vm.WastePositionName = basicObjectWastePosition.Name;

                //通过桶id(code)获取桶号
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.Code);
                string bucketCode = Pac.BucketCode;
                model.Code = bucketCode;

                //加载结论
                vm.ClearFlagRodiodList = new List<SelectListItem>();
                vm.ClearFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ClearFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

                //RP测量结果
                vm.RpResultRodiodList = new List<SelectListItem>();
                vm.RpResultRodiodList.Add(new SelectListItem { Text = "满足解控需求", Value = "1", Selected = true });
                vm.RpResultRodiodList.Add(new SelectListItem { Text = "不满足解控需求", Value = "0" });

                //是否需要再处理
                vm.ReprocessFlagRodiodList = new List<SelectListItem>();
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });
                return View("ViewClear", vm);
            }
            if (type == "NuclearWasteDegrade")
            {                
                OtherTechnologyVM vm = new OtherTechnologyVM();
                NuclearWasteDegrade model = _NuclearWasteDegradeRepository.Get(id);
                vm.NuclearWasteDegrade = model;
                BasicObject BasicObject = new BasicObject();
                BasicObject basicObjectWasteType = _BasicObjectRepository.Get(model.WasteTypeId);
                BasicObject basicObjectWastePosition = _BasicObjectRepository.Get(model.DegradePosition);

                //通过桶id(code)获取桶号
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.WasteCode);
                string bucketCode = Pac.BucketCode;
                model.WasteCode = bucketCode;

                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    model.TrackId = null;
                }
                
                vm.WasteTypeIdName = basicObjectWasteType.Name;
                vm.WastePositionName = basicObjectWastePosition.Name;
                //是否需要再处理
                vm.ReprocessFlagRodiodList = new List<SelectListItem>();
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1" });
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

                //修改数字显示格式
                if (vm.NuclearWasteDegrade.WasteDose != null)
                {
                    if (vm.NuclearWasteDegrade.WasteDose.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteDegrade.WasteDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteDegrade.WasteDose));
                    }
                }
                if (vm.NuclearWasteDegrade.ReprocessDose != null)
                {
                    if (vm.NuclearWasteDegrade.ReprocessDose.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteDegrade.ReprocessDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteDegrade.ReprocessDose));
                    }
                }
                return View("ViewDegrade", vm);
            }
            if (type == "NuclearWasteDismantle")
            {
                OtherTechnologyVM vm = new OtherTechnologyVM();
                NuclearWasteDismantle model = _NuclearWasteDismantleRepository.Get(id);
                vm.NuclearWasteDismantle = model;
                BasicObject BasicObject = new BasicObject();
                BasicObject basicObjectWasteType = _BasicObjectRepository.Get(model.WasteTypeId);
                BasicObject basicObjectSaveFactory = _BasicObjectRepository.Get(model.SaveFactory);
                BasicObject basicObjectDismantleWay = _BasicObjectRepository.Get(model.DismantleWay);

                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    model.TrackId = null;
                }

                //通过桶id(code)获取桶号
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.Code);
                string bucketCode = Pac.BucketCode;
                model.Code = bucketCode;
               
                vm.WasteTypeIdName = basicObjectWasteType.Name;
                vm.WastePositionName = basicObjectSaveFactory.Name;
                vm.DismantleWayName = basicObjectDismantleWay.Name;
                //存储方式-暂存包装容器
                vm.SaveFlagCodeList = new List<SelectListItem>();
                vm.SaveFlagCodeList.Add(new SelectListItem { Text = "暂存包装容器", Value = "1", Selected = true });

                //存储方式-暂存厂房
                vm.SaveFlagFactoryList = new List<SelectListItem>();
                vm.SaveFlagFactoryList.Add(new SelectListItem { Text = "暂存厂房", Value = "0" });

                //是否需要再处理
                vm.ReprocessFlagRodiodList = new List<SelectListItem>();
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

                //修改数字显示格式
                if (vm.NuclearWasteDismantle.DoseEva != null)
                {
                    if (vm.NuclearWasteDismantle.DoseEva.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteDismantle.DoseEva = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteDismantle.DoseEva));
                    }
                }
                if (vm.NuclearWasteDismantle.DoseMax != null)
                {
                    if (vm.NuclearWasteDismantle.DoseMax.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteDismantle.DoseMax = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteDismantle.DoseMax));
                    }
                }
                return View("ViewDismantle", vm);
            }

            if (type == "NuclearWasteFire")
            {
                OtherTechnologyVM vm = new OtherTechnologyVM();
                NuclearWasteFire model = _NuclearWasteFireRepository.Get(id);
                vm.NuclearWasteFire = model;
                BasicObject BasicObject = new BasicObject();
                BasicObject basicObjectWasteType = _BasicObjectRepository.Get(model.WasteTypeId);

                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    model.TrackId = null;
                }

                //通过桶id(code)获取桶号
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.WasteCode);
                string bucketCode = Pac.BucketCode;
                model.WasteCode = bucketCode;

                vm.WasteTypeIdName = basicObjectWasteType.Name;

                //加载是否可以焚烧
                vm.FireFlagRodiodList = new List<SelectListItem>();
                vm.FireFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.FireFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

                //是否需要再处理
                vm.ReprocessFlagRodiodList = new List<SelectListItem>();
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

                //修改数字显示格式
                if (vm.NuclearWasteFire.ReprocessDose != null)
                {
                    if (vm.NuclearWasteFire.ReprocessDose.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteFire.ReprocessDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteFire.ReprocessDose));
                    }
                }
                if (vm.NuclearWasteFire.RubbishDoseEva != null)
                {
                    if (vm.NuclearWasteFire.RubbishDoseEva.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteFire.RubbishDoseEva = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteFire.RubbishDoseEva));
                    }
                }
                if (vm.NuclearWasteFire.RubbishDoseMax != null)
                {
                    if (vm.NuclearWasteFire.RubbishDoseMax.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteFire.RubbishDoseMax = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteFire.RubbishDoseMax));
                    }
                }
                return View("ViewFire", vm);
            }

            if (type == "NuclearWasteLDispose")
            {
                OtherTechnologyVM vm = new OtherTechnologyVM();
                NuclearWasteLDispose model = _NuclearWasteLDisposeRepository.Get(id);
                vm.NuclearWasteLDispose = model;
                BasicObject BasicObject = new BasicObject();
                BasicObject basicObjectWasteType = _BasicObjectRepository.Get(model.WasteTypeId);
                BasicObject basicObjectWastePosition = _BasicObjectRepository.Get(model.WastePosition);

                //通过桶id(code)获取桶号
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.Code);
                string bucketCode = Pac.BucketCode;
                model.Code = bucketCode;

                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    model.TrackId = null;
                }
                               
                vm.WasteTypeIdName = basicObjectWasteType.Name;
                vm.WastePositionName = basicObjectWastePosition.Name;
                //是否需要再处理
                vm.ReprocessFlagRodiodList = new List<SelectListItem>();
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
                vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

                //修改数字显示格式
                if (vm.NuclearWasteLDispose.WasteDose != null)
                {
                    if (vm.NuclearWasteLDispose.WasteDose.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteLDispose.WasteDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteLDispose.WasteDose));
                    }
                }
                return View("ViewLDispose", vm);
            }

            if (type == "NuclearWasteHDispose")
            {
                OtherTechnologyVM vm = new OtherTechnologyVM();
                NuclearWasteHDispose model = _NuclearWasteHDisposeRepository.Get(id);

                //通过桶id(code)获取桶号
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.ContainerCode);
                string bucketCode = Pac.BucketCode;
                model.ContainerCode = bucketCode;
                NuclearWasteHDispose nuclearWasteHDispose = _NuclearWasteHDisposeRepository.Get(id);

                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    model.TrackId = null;
                }

                vm.NuclearWasteHDispose = model;
                BasicObject BasicObject = new BasicObject();
                BasicObject basicObjectWasteType = _BasicObjectRepository.Get(model.WasteTypeId);    
                vm.WasteTypeIdName = basicObjectWasteType.Name;                
                vm.NuclearWasteHDispose = nuclearWasteHDispose;

                //修改数字显示格式
                if (vm.NuclearWasteHDispose.WasteDose != null)
                {
                    if (vm.NuclearWasteHDispose.WasteDose.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.WasteDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.WasteDose));
                    }
                }
                if (vm.NuclearWasteHDispose.WasteDose != null)
                {
                    if (vm.NuclearWasteHDispose.ContainerWeight.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.ContainerWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.ContainerWeight));
                    }
                }
                if (vm.NuclearWasteHDispose.ContainerPosition != null)
                {
                    if (vm.NuclearWasteHDispose.ContainerPosition.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.ContainerPosition = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.ContainerPosition));
                    }
                }
                if (vm.NuclearWasteHDispose.DoseEva != null)
                {
                    if (vm.NuclearWasteHDispose.DoseEva.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.DoseEva = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.DoseEva));
                    }
                }
                if (vm.NuclearWasteHDispose.DoseMax != null)
                {
                    if (vm.NuclearWasteHDispose.DoseMax.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.DoseMax = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.DoseMax));
                    }
                }
                if (vm.NuclearWasteHDispose.DoseMeter != null)
                {
                    if (vm.NuclearWasteHDispose.DoseMeter.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteHDispose.DoseMeter = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteHDispose.DoseMeter));
                    }
                }
                return View("ViewHDispose", vm);
            }

            if (type == "NuclearWasteSmelt")
            {
                OtherTechnologyVM vm = new OtherTechnologyVM();
                NuclearWasteSmelt model = _NuclearWasteSmeltRepository.Get(id);

                List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                if (iqueryTrackItem.Count > 0)
                {
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }
                else
                {
                    model.TrackId = null;
                }

                //通过桶id(code)获取桶号
                NuclearBucket Pac = _NuclearBucketRepository.Get(model.Code);
                string bucketCode = Pac.BucketCode;
                model.Code = bucketCode;

                vm.NuclearWasteSmelt = model;
                BasicObject BasicObject = new BasicObject();
                BasicObject basicObjectWasteType = _BasicObjectRepository.Get(model.WasteTypeId);
                vm.WasteTypeIdName = basicObjectWasteType.Name;

                //修改数字显示格式
                if (vm.NuclearWasteSmelt.DoseEva != null)
                {
                    if (vm.NuclearWasteSmelt.DoseEva.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteSmelt.DoseEva = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteSmelt.DoseEva));
                    }
                }
                if (vm.NuclearWasteSmelt.DoseMax != null)
                {
                    if (vm.NuclearWasteSmelt.DoseMax.Value.ToString().IndexOf('.') > 0)
                    {
                        vm.NuclearWasteSmelt.DoseMax = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearWasteSmelt.DoseMax));
                    }
                }
                return View("ViewSmelt", vm);
            }
            
            if (type == "NuclearSpecialPackage")
            {
                OtherTechnologyVM vm = new OtherTechnologyVM();
                NuclearSpecialPackage model = _NuclearSpecialPackageRepository.Get(id);
                NuclearWastePackage Pac = _NuclearWastePackageRepository.Get(model.PackagedId);

                //通过桶id(code)获取桶号
                NuclearBucket bucket = _NuclearBucketRepository.Get(model.Code);
                string bucketCode = bucket.BucketCode;
                model.Code = bucketCode;

                if (model.TrackId != null)
                {
                    List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }

                string evalNuclearSpecialPackage_PackagedFlag = Request.Form["NuclearSpecialPackage_PackagedFlag"];
                if (!string.IsNullOrEmpty(model.PackagedId))
                {
                    string packageCode = Pac.PackageCode;
                    model.PackagedId = packageCode;
                }
                if (evalNuclearSpecialPackage_PackagedFlag == "1")
                {
                    List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }

                string evalNuclearSpecialPackage_SourceFlag = Request.Form["NuclearSpecialPackage_SourceFlag"];
                if (evalNuclearSpecialPackage_SourceFlag == "1")
                {
                    List<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("", AppContext.CurrentUser.ProjectCode).Where(d => d.TrackId == model.TrackId).ToList();
                    model.TrackId = iqueryTrackItem[0].TrackCode;
                }
                vm.NuclearSpecialPackage = model;
                return View("ViewPackage", vm);
            }
            return View();
        }
        #endregion

        #region 废物焚烧
      
        /// <summary>
        /// 废物焚烧
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物焚烧")]
        public ActionResult IndexFire()
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            vm.OperationList = CommonHelper.GetOperationList("Index_Fire");//权限控制
            
            //桶状态
            vm.BucketStatusList = new List<SelectListItem>();
            vm.NuclearWasteFire = new NuclearWasteFire();
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            //加载废物类型下拉列表
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery!=null && wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
            }
            foreach (var item in wasteTypeIdList)
            {
                vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }           

            //加载是否可以焚烧
            vm.FireFlagRodiodList = new List<SelectListItem>();
            vm.FireFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
            vm.FireFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });           

            //是否需要再处理
            vm.ReprocessFlagRodiodList = new List<SelectListItem>();
            vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
            vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });
            return View(vm);
        }
        
        [HttpGet]
        public ActionResult CommitFire(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteFire model = _NuclearWasteFireRepository.Get(id);
            vm.NuclearWasteFire = model;
            return View("CommittFire", vm);
        }

        [HttpGet]
        public ActionResult ConfirmFire(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteFire model = _NuclearWasteFireRepository.Get(id);
            vm.NuclearWasteFire = model;
            return View("ConfirmFire", vm);
        }

        /// <summary>
        /// 保存废物焚烧
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddFire(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }           
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteFire.WasteCode, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                model.NuclearWasteFire.WasteCode = model.NuclearWasteFire.WasteCode;


                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });

                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteFire.FireId))
                {
                    model.NuclearWasteFire.FireId = Guid.NewGuid().ToString();
                    model.NuclearWasteFire.Status = "0";//状态
                    model.NuclearWasteFire.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteFire.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteFire.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteFire.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteFireRepository.Create(model.NuclearWasteFire);//提交数据库

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteFire.FireId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "FIRE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }
                    
                    }
                    
                    this._NuclearWasteFireRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteFire = _NuclearWasteFireRepository.Get(model.NuclearWasteFire.FireId);
                    UpdateModel(model);
                    model.NuclearWasteFire.Status = "0";//状态
                    model.NuclearWasteFire.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteFire.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteFire.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteFire.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteFireRepository.Update(model.NuclearWasteFire);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteFire.FireId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }
                    
                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteFire.FireId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "FIRE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteFireRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                
                }

            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }


        /// <summary>
        /// 提交废物焚烧
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitFire(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }           
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteFire.WasteCode, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                model.NuclearWasteFire.WasteCode = model.NuclearWasteFire.WasteCode;


                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });

                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteFire.FireId))
                {
                    model.NuclearWasteFire.FireId = Guid.NewGuid().ToString();
                    model.NuclearWasteFire.Status = "1";//状态
                    model.NuclearWasteFire.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteFire.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteFire.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteFire.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteFireRepository.Create(model.NuclearWasteFire);//提交数据库

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteFire.FireId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "FIRE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteFireRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    model.NuclearWasteFire = _NuclearWasteFireRepository.Get(model.NuclearWasteFire.FireId);
                    UpdateModel(model);
                    model.NuclearWasteFire.Status = "1";//状态
                    model.NuclearWasteFire.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteFire.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteFire.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteFire.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteFireRepository.Update(model.NuclearWasteFire);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteFire.FireId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteFire.FireId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "FIRE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteFireRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确定废物焚烧
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物焚烧确认")]
        public JsonResult ConfirmFire(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteFire.WasteCode, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                model.NuclearWasteFire.WasteCode = model.NuclearWasteFire.WasteCode;


                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });

                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteFire.FireId))
                {
                    model.NuclearWasteFire.FireId = Guid.NewGuid().ToString();
                    model.NuclearWasteFire.Status = "2";//状态
                    model.NuclearWasteFire.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteFire.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteFire.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteFire.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteFire.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteFire.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteFire.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteFireRepository.Create(model.NuclearWasteFire);//提交数据库
               

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteFire.FireId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "FIRE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteFireRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteFire = _NuclearWasteFireRepository.Get(model.NuclearWasteFire.FireId);
                    UpdateModel(model);

                    model.NuclearWasteFire.Status = "2";//状态
                    model.NuclearWasteFire.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteFire.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteFire.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteFire.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteFireRepository.Update(model.NuclearWasteFire);//提交数据库
                    
                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteFire.FireId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteFire.FireId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "FIRE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteFireRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region 废物降解

        /// <summary>
        /// 废物降解
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物降解")]
        public ActionResult IndexDegrades()
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            vm.OperationList = CommonHelper.GetOperationList("Index_Degrades");//权限控制

            vm.NuclearWasteDegrade = new NuclearWasteDegrade();
            //桶状态
            vm.BucketStatusList = new List<SelectListItem>();
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            //加载废物类型下拉列表
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery!=null && wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
            }
            foreach (var item in wasteTypeIdList)
            {
                vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载降解后存储位置下拉列表
            vm.WastePositionList = new List<SelectListItem>();
            IQueryable<BasicObject> WastePositionQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wastePositionList = new List<BasicObject>();
            if (WastePositionQuery.Count() > 0)
            {
                wastePositionList = WastePositionQuery.ToList();
            }
            foreach (var item in wastePositionList)
            {
                vm.WastePositionList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            
            //是否需要再处理
            vm.ReprocessFlagRodiodList = new List<SelectListItem>();
            vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
            vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });
            return View(vm);
        }       

        [HttpGet]
        public ActionResult CommitDegrade(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteDegrade model = _NuclearWasteDegradeRepository.Get(id);
            vm.NuclearWasteDegrade = model;
            return View("CommittDegrade", vm);
        }

        [HttpGet]
        public ActionResult ConfirmDegrade(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteDegrade model = _NuclearWasteDegradeRepository.Get(id);
            vm.NuclearWasteDegrade = model;
            return View("ConfirmDegrade", vm);
        }

        /// <summary>
        /// 保存废物降解
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddDegrade(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
           
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteDegrade.WasteCode, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteDegrade.WasteCode = bucketId;

                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });

                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteDegrade.DegradeId))
                {
                    model.NuclearWasteDegrade.DegradeId = Guid.NewGuid().ToString();
                    model.NuclearWasteDegrade.Status = "0";//状态
                    model.NuclearWasteDegrade.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteDegrade.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteDegrade.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteDegrade.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDegradeRepository.Create(model.NuclearWasteDegrade);//提交数据库
                   

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDegrade.DegradeId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DEGRADE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteDegradeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteDegrade.DegradeId);
                    UpdateModel(model);
                    model.NuclearWasteDegrade.Status = "0";//状态
                    model.NuclearWasteDegrade.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteDegrade.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteDegrade.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteDegrade.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDegradeRepository.Update(model.NuclearWasteDegrade);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteDegrade.DegradeId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDegrade.DegradeId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DEGRADE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteDegradeRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// 提交废物降解
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitDegrade(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }            
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteDegrade.WasteCode, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteDegrade.WasteCode = bucketId;


                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });

                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteDegrade.DegradeId))
                {
                    model.NuclearWasteDegrade.DegradeId = Guid.NewGuid().ToString();
                    model.NuclearWasteDegrade.Status = "1";//状态
                    model.NuclearWasteDegrade.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteDegrade.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteDegrade.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteDegrade.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDegradeRepository.Create(model.NuclearWasteDegrade);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDegrade.DegradeId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DEGRADE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteDegradeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteDegrade.DegradeId);
                    UpdateModel(model);
                    model.NuclearWasteDegrade.Status = "1";//状态
                    model.NuclearWasteDegrade.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteDegrade.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteDegrade.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteDegrade.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDegradeRepository.Update(model.NuclearWasteDegrade);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteDegrade.DegradeId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDegrade.DegradeId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DEGRADE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteDegradeRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// 确定废物降解
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物降解确认")]
        public JsonResult ConfirmDegrade(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
           
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteDegrade.WasteCode, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteDegrade.WasteCode = bucketId;


                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });

                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteDegrade.DegradeId))
                {
                    model.NuclearWasteDegrade.DegradeId = Guid.NewGuid().ToString();
                    model.NuclearWasteDegrade.Status = "2";//状态
                    model.NuclearWasteDegrade.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteDegrade.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteDegrade.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteDegrade.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteDegrade.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteDegrade.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteDegrade.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDegradeRepository.Create(model.NuclearWasteDegrade);//提交数据库

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDegrade.DegradeId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DEGRADE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteDegradeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteDegrade.DegradeId);
                    UpdateModel(model);
                    model.NuclearWasteDegrade.Status = "2";//状态
                    model.NuclearWasteDegrade.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteDegrade.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteDegrade.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteDegrade.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDegradeRepository.Update(model.NuclearWasteDegrade);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteDegrade.DegradeId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDegrade.DegradeId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DEGRADE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteDegradeRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确定失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        #endregion

        #region 高整体容器处理废物
        
        /// <summary>
        /// 高整体容器处理废物
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "高整体容器处理废物")]
        public ActionResult IndexHDispose()
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            vm.OperationList = CommonHelper.GetOperationList("Index_H_Dispose");//权限控制

            vm.NuclearWasteHDispose = new NuclearWasteHDispose();
            //桶状态
            vm.BucketStatusList = new List<SelectListItem>();
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            //加载废物类型下拉列表
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery!=null && wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
            }
            foreach (var item in wasteTypeIdList)
            {
                vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            return View(vm);
        }

        [HttpGet]
        public ActionResult CommitHDispose(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteHDispose model = _NuclearWasteHDisposeRepository.Get(id);
            vm.NuclearWasteHDispose = model;
            return View("CommittHDispose", vm);
        }

        [HttpGet]
        public ActionResult ConfirmHDispose(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteHDispose model = _NuclearWasteHDisposeRepository.Get(id);
            vm.NuclearWasteHDispose = model;
            return View("ConfirmHDispose", vm);
        }

        /// <summary>
        /// 保存高整体容器处理废物
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddHDispose(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }            
            try
            {
               

                //判断桶号是否存在 
                string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteHDispose.ContainerCode, AppContext.CurrentUser.ProjectCode);
                if (string.IsNullOrEmpty(bucketId))
                {
                    return Json("{\"result\":false,\"msg\":\"容器号不存在!\"}", JsonRequestBehavior.AllowGet);
                }
                model.NuclearWasteHDispose.ContainerCode = bucketId;


                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });

                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteHDispose.DisposeHId))
                {
                    model.NuclearWasteHDispose.DisposeHId = Guid.NewGuid().ToString();
                    model.NuclearWasteHDispose.Status = "0";//状态
                    model.NuclearWasteHDispose.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteHDispose.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteHDispose.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteHDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteHDisposeRepository.Create(model.NuclearWasteHDispose);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteHDispose.DisposeHId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "HDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteHDisposeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteHDispose.DisposeHId);
                    UpdateModel(model);
                    model.NuclearWasteHDispose.Status = "0";//状态                    
                    model.NuclearWasteHDispose.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteHDispose.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteHDispose.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteHDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteHDisposeRepository.Update(model.NuclearWasteHDispose);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteHDispose.DisposeHId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteHDispose.DisposeHId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "HDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteHDisposeRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }



            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交高整体容器处理废物
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitHDispose(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }           
            try
            {
              
                //判断桶号是否存在 
                string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteHDispose.ContainerCode, AppContext.CurrentUser.ProjectCode);
                if (string.IsNullOrEmpty(bucketId))
                {
                    return Json("{\"result\":false,\"msg\":\"容器号不存在!\"}", JsonRequestBehavior.AllowGet);
                }
                model.NuclearWasteHDispose.ContainerCode = bucketId;


                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteHDispose.DisposeHId))
                {
                    model.NuclearWasteHDispose.DisposeHId = Guid.NewGuid().ToString();
                    model.NuclearWasteHDispose.Status = "1";//状态
                    model.NuclearWasteHDispose.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteHDispose.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteHDispose.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteHDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteHDisposeRepository.Create(model.NuclearWasteHDispose);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteHDispose.DisposeHId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "HDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteHDisposeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteHDispose.DisposeHId);
                    UpdateModel(model);
                    model.NuclearWasteHDispose.Status = "1";//状态                    
                    model.NuclearWasteHDispose.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteHDispose.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteHDispose.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteHDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteHDisposeRepository.Update(model.NuclearWasteHDispose);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteHDispose.DisposeHId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteHDispose.DisposeHId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "HDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteHDisposeRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }

            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        
        /// <summary>
        /// 确定高整体容器处理废物
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "高整体容器处理废物确认")]
        public JsonResult ConfirmHDispose(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }            
            try
            {
                
                //判断桶包是否存在 
                string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteHDispose.ContainerCode, AppContext.CurrentUser.ProjectCode);
                if (string.IsNullOrEmpty(bucketId))
                {
                    return Json("{\"result\":false,\"msg\":\"容器号不存在!\"}", JsonRequestBehavior.AllowGet);
                }
                model.NuclearWasteHDispose.ContainerCode = bucketId;




                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteHDispose.DisposeHId))
                {
                    model.NuclearWasteHDispose.DisposeHId = Guid.NewGuid().ToString();
                    model.NuclearWasteHDispose.Status = "2";//状态
                    model.NuclearWasteHDispose.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteHDispose.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteHDispose.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteHDispose.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteHDispose.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteHDispose.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteHDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteHDisposeRepository.Create(model.NuclearWasteHDispose);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteHDispose.DisposeHId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "HDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteHDisposeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteHDispose.DisposeHId);
                    UpdateModel(model);             
                    model.NuclearWasteHDispose.Status = "2";//状态
                    model.NuclearWasteHDispose.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteHDispose.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteHDispose.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteHDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteHDisposeRepository.Update(model.NuclearWasteHDispose);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteHDispose.DisposeHId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteHDispose.DisposeHId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "HDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteHDisposeRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }

               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #endregion

        #region 极低放废物处理
        
        /// <summary>
        /// 极低放废物处理
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "极低放废物处理")]
        public ActionResult IndexLDispose()
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            vm.OperationList = CommonHelper.GetOperationList("Index_L_Dispose");//权限控制

            vm.NuclearWasteLDispose = new NuclearWasteLDispose();
            //桶状态
            vm.BucketStatusList = new List<SelectListItem>();
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            //加载废物类型下拉列表
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery!=null && wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
            }
            foreach (var item in wasteTypeIdList)
            {
                vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载降解后存储位置下拉列表
            vm.WastePositionList = new List<SelectListItem>();
            IQueryable<BasicObject> WastePositionQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wastePositionList = new List<BasicObject>();
            if (WastePositionQuery.Count() > 0)
            {
                wastePositionList = WastePositionQuery.ToList();
            }
            foreach (var item in wastePositionList)
            {
                vm.WastePositionList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //是否需要再处理
            vm.ReprocessFlagRodiodList = new List<SelectListItem>();
            vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
            vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });
            return View(vm);
        }

        [HttpGet]
        public ActionResult CommitLDispose(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteLDispose model = _NuclearWasteLDisposeRepository.Get(id);
            vm.NuclearWasteLDispose = model;
            return View("CommittLDispose", vm);
        }

        [HttpGet]
        public ActionResult ConfirmLDispose(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteLDispose model = _NuclearWasteLDisposeRepository.Get(id);
            vm.NuclearWasteLDispose = model;
            return View("ConfirmLDispose", vm);
        }

        /// <summary>
        /// 保存极低放废物处理
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddLDispose(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }            
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteLDispose.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteLDispose.Code = bucketId;

                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteLDispose.DisposeLId))
                {
                    model.NuclearWasteLDispose.DisposeLId = Guid.NewGuid().ToString();
                    model.NuclearWasteLDispose.Status = "0";//状态
                    model.NuclearWasteLDispose.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteLDispose.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteLDispose.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteLDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteLDisposeRepository.Create(model.NuclearWasteLDispose);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteLDispose.DisposeLId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "LDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteLDisposeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteLDispose.DisposeLId);
                    UpdateModel(model);
                    model.NuclearWasteLDispose.Status = "0";//状态
                    model.NuclearWasteLDispose.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteLDispose.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteLDispose.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteLDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteLDisposeRepository.Update(model.NuclearWasteLDispose);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteLDispose.DisposeLId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteLDispose.DisposeLId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "LDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteHDisposeRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交极低放废物处理
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitLDispose(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }           
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteLDispose.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteLDispose.Code = bucketId;

                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteLDispose.DisposeLId))
                {
                    model.NuclearWasteLDispose.DisposeLId = Guid.NewGuid().ToString();
                    model.NuclearWasteLDispose.Status = "1";//状态
                    model.NuclearWasteLDispose.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteLDispose.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteLDispose.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteLDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteLDisposeRepository.Create(model.NuclearWasteLDispose);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteLDispose.DisposeLId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "LDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteLDisposeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteLDispose.DisposeLId);
                    UpdateModel(model);
                    model.NuclearWasteLDispose.Status = "1";//状态
                    model.NuclearWasteLDispose.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteLDispose.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteLDispose.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteLDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteLDisposeRepository.Update(model.NuclearWasteLDispose);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteLDispose.DisposeLId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteLDispose.DisposeLId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "LDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteHDisposeRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// 确定极低放废物处理
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "极低放废物处理确认")]
        public JsonResult ConfirmLDispose(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
            
           try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteLDispose.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteLDispose.Code = bucketId;

                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteLDispose.DisposeLId))
                {
                   model.NuclearWasteLDispose.DisposeLId = Guid.NewGuid().ToString();
                    model.NuclearWasteLDispose.Status = "2";//状态
                    model.NuclearWasteLDispose.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteLDispose.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteLDispose.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteLDispose.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteLDispose.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteLDispose.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteLDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteLDisposeRepository.Create(model.NuclearWasteLDispose);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteLDispose.DisposeLId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "LDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteLDisposeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteLDispose.DisposeLId);
                    UpdateModel(model);
                     model.NuclearWasteLDispose.Status = "2";//状态
                    
                    model.NuclearWasteLDispose.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteLDispose.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteLDispose.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteLDispose.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteLDisposeRepository.Update(model.NuclearWasteLDispose);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteLDispose.DisposeLId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteLDispose.DisposeLId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "LDISPOSE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteHDisposeRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        #endregion

        #region 废物解控
        /// <summary>
        /// 废物解控
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物解控")]
        public ActionResult IndexClear()
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            vm.OperationList = CommonHelper.GetOperationList("Index_Clear");//权限控制

            vm.NuclearWasteClear  = new NuclearWasteClear();
            //桶状态
            vm.BucketStatusList = new List<SelectListItem>();
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            //加载废物类型下拉列表
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery!=null && wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
            }
            foreach (var item in wasteTypeIdList)
            {
                vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载解控后存储位置下拉列表
            vm.WastePositionList = new List<SelectListItem>();
            IQueryable<BasicObject> WastePositionQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wastePositionList = new List<BasicObject>();
            if (WastePositionQuery.Count() > 0)
            {
                wastePositionList = WastePositionQuery.ToList();
            }
            foreach (var item in wastePositionList)
            {
                vm.WastePositionList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载结论
            vm.ClearFlagRodiodList = new List<SelectListItem>();
            vm.ClearFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
            vm.ClearFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

            //RP测量结果
            vm.RpResultRodiodList = new List<SelectListItem>();
            vm.RpResultRodiodList.Add(new SelectListItem { Text = "满足解控需求", Value = "1", Selected = true });
            vm.RpResultRodiodList.Add(new SelectListItem { Text = "不满足解控需求", Value = "0" });

            //是否需要再处理
            vm.ReprocessFlagRodiodList = new List<SelectListItem>();
            vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
            vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

            return View(vm);
        }

        [HttpGet]
        public ActionResult CommitClear(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteClear model = _NuclearWasteClearRepository.Get(id);
            vm.NuclearWasteClear = model;            
            return View("CommittClear", vm);
        }

        [HttpGet]
        public ActionResult ConfirmClear(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteClear model = _NuclearWasteClearRepository.Get(id);
            vm.NuclearWasteClear = model;          
            return View("ConfirmClear", vm);
        }

        /// <summary>
        /// 保存废物解控
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddClear(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }            
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteClear.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteClear.Code = bucketId;

                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteClear.ClearId))
                {
                    model.NuclearWasteClear.ClearId = Guid.NewGuid().ToString();
                    model.NuclearWasteClear.Status = "0";//状态
                    model.NuclearWasteClear.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteClear.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteClear.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteClear.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteClearRepository.Create(model.NuclearWasteClear);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteClear.ClearId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "CLEAR";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteClearRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteClear.ClearId);
                    UpdateModel(model);
                    model.NuclearWasteClear.Status = "0";//状态
                    model.NuclearWasteClear.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteClear.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteClear.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteClear.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteClearRepository.Update(model.NuclearWasteClear);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteClear.ClearId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteClear.ClearId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "CLEAR";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteClearRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// 提交废物解控
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitClear(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            } 
            try
            {
                ////判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteClear.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteClear.Code = bucketId;

                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteClear.ClearId))
                {
                    model.NuclearWasteClear.ClearId = Guid.NewGuid().ToString();
                    model.NuclearWasteClear.Status = "1";//状态
                    model.NuclearWasteClear.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteClear.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteClear.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteClear.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteClearRepository.Create(model.NuclearWasteClear);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteClear.ClearId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "CLEAR";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteClearRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteClear.ClearId);
                    UpdateModel(model);
                    model.NuclearWasteClear.Status = "1";//状态
                    model.NuclearWasteClear.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteClear.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteClear.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteClear.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteClearRepository.Update(model.NuclearWasteClear);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteClear.ClearId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteClear.ClearId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "CLEAR";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteClearRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确定废物解控
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物解控确认")]
        public JsonResult ConfirmClear(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }            
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteClear.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteClear.Code = bucketId;
                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteClear.ClearId))
                {
                    model.NuclearWasteClear.ClearId = Guid.NewGuid().ToString();
                    model.NuclearWasteClear.Status = "2";//状态
                    model.NuclearWasteClear.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteClear.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteClear.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteClear.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteClear.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteClear.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteClear.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteClearRepository.Create(model.NuclearWasteClear);//提交数据库

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteClear.ClearId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "CLEAR";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteClearRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteClear.ClearId);
                    UpdateModel(model);
                    model.NuclearWasteClear.Status = "2";//状态
                    model.NuclearWasteClear.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteClear.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteClear.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteClear.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteClearRepository.Update(model.NuclearWasteClear);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteClear.ClearId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteClear.ClearId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "CLEAR";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteClearRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #endregion

        #region 废物熔炼
 
        /// <summary>
        /// 废物熔炼
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物熔炼")]
        public ActionResult IndexSmelt()
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            vm.OperationList = CommonHelper.GetOperationList("Index_Smelt");//权限控制

            vm.NuclearWasteSmelt = new NuclearWasteSmelt();
            //桶状态
            vm.BucketStatusList = new List<SelectListItem>();
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            //加载废物类型下拉列表
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery != null && wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
            }
            foreach (var item in wasteTypeIdList)
            {
                vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            return View(vm);
        }

        [HttpGet]
        public ActionResult CommitSmelt(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteSmelt model = _NuclearWasteSmeltRepository.Get(id);
            vm.NuclearWasteSmelt = model;
            return View("CommittSmelt", vm);
        }

        [HttpGet]
        public ActionResult ConfirmSmelt(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteSmelt model = _NuclearWasteSmeltRepository.Get(id);
            vm.NuclearWasteSmelt = model;
            return View("ConfirmSmelt", vm);
        }

        /// <summary>
        /// 保存废物熔炼
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddSmelt(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            } 
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteSmelt.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteSmelt.Code = bucketId;

                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteSmelt.SmeltId))
                {
                    model.NuclearWasteSmelt.SmeltId = Guid.NewGuid().ToString();
                    model.NuclearWasteSmelt.Status = "0";//状态
                    model.NuclearWasteSmelt.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteSmelt.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteSmelt.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteSmelt.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteSmeltRepository.Create(model.NuclearWasteSmelt);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteSmelt.SmeltId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "SMELT";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteSmeltRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteSmelt.SmeltId);
                    UpdateModel(model);
                    model.NuclearWasteSmelt.Status = "0";//状态                    
                    model.NuclearWasteSmelt.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteSmelt.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteSmelt.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteSmelt.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteSmeltRepository.Update(model.NuclearWasteSmelt);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteSmelt.SmeltId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteSmelt.SmeltId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "SMELT";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteSmeltRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }


        /// <summary>
        /// 提交废物熔炼
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitSmelt(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
            
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteSmelt.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteSmelt.Code = bucketId;

                
                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteSmelt.SmeltId))
                {
                    model.NuclearWasteSmelt.SmeltId = Guid.NewGuid().ToString();
                    model.NuclearWasteSmelt.Status = "1";//状态
                    model.NuclearWasteSmelt.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteSmelt.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteSmelt.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteSmelt.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteSmeltRepository.Create(model.NuclearWasteSmelt);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteSmelt.SmeltId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "SMELT";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteSmeltRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteSmelt.SmeltId);
                    UpdateModel(model);
                    model.NuclearWasteSmelt.Status = "1";//状态                    
                    model.NuclearWasteSmelt.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteSmelt.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteSmelt.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteSmelt.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteSmeltRepository.Update(model.NuclearWasteSmelt);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteSmelt.SmeltId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteSmelt.SmeltId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "SMELT";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteSmeltRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }


        /// <summary>
        /// 确定废物熔炼
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物熔炼确认")]
        public JsonResult ConfirmSmelt(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }            
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteSmelt.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteSmelt.Code = bucketId;


                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteSmelt.SmeltId))
                {
                    model.NuclearWasteSmelt.SmeltId = Guid.NewGuid().ToString();
                    model.NuclearWasteSmelt.Status = "2";//状态
                    model.NuclearWasteSmelt.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteSmelt.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteSmelt.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteSmelt.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteSmelt.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteSmelt.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteSmelt.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteSmeltRepository.Create(model.NuclearWasteSmelt);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteSmelt.SmeltId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "SMELT";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteSmeltRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteSmelt.SmeltId);
                    UpdateModel(model);
                    model.NuclearWasteSmelt.Status = "2";//状态

                    model.NuclearWasteSmelt.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteSmelt.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteSmelt.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteSmelt.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteSmeltRepository.Update(model.NuclearWasteSmelt);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteSmelt.SmeltId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteSmelt.SmeltId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "SMELT";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteSmeltRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        #endregion

        #region 废物拆解

        /// <summary>
        /// 废物拆解
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物拆解")]
        public ActionResult IndexDismantle()
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            vm.OperationList = CommonHelper.GetOperationList("Index_Dismantle");//权限控制

            vm.BucketStatusList = new List<SelectListItem>();
            vm.NuclearWasteDismantle = new NuclearWasteDismantle();
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            
            //加载废物类型下拉列表
            vm.WasteTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> wasteTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> wasteTypeIdList = new List<BasicObject>();
            if (wasteTypeIdQuery != null && wasteTypeIdQuery.Count() > 0)
            {
                wasteTypeIdList = wasteTypeIdQuery.ToList();
            }
            foreach (var item in wasteTypeIdList)
            {
                vm.WasteTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }             

            //加载拆解方式下拉列表
            vm.DismantleWayList = new List<SelectListItem>();
            IQueryable<BasicObject> dismantleWayQuery = _BasicObjectRepository.GetSubobjectsByCode("DismantleWay",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> dismantleWayList = new List<BasicObject>();
            if (dismantleWayQuery!=null && dismantleWayQuery.Count() > 0)
            {
                dismantleWayList = dismantleWayQuery.ToList();
            }
            foreach (var item in dismantleWayList)
            {
                vm.DismantleWayList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载拆解后存储位置下拉列表
            vm.SaveFactoryList = new List<SelectListItem>();
            IQueryable<BasicObject> saveFactoryQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> saveFactoryList = new List<BasicObject>();
            if (saveFactoryQuery.Count() > 0)
            {
                saveFactoryList = saveFactoryQuery.ToList();
            }
            foreach (var item in saveFactoryList)
            {
                vm.SaveFactoryList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //存储方式-暂存包装容器
            vm.SaveFlagCodeList = new List<SelectListItem>();
            vm.SaveFlagCodeList.Add(new SelectListItem { Text = "暂存包装容器", Value = "1", Selected = true });

            //存储方式-暂存厂房
            vm.SaveFlagFactoryList = new List<SelectListItem>();
            vm.SaveFlagFactoryList.Add(new SelectListItem { Text = "暂存厂房", Value = "0" });

            //是否需要再处理
            vm.ReprocessFlagRodiodList = new List<SelectListItem>();
            vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
            vm.ReprocessFlagRodiodList.Add(new SelectListItem { Text = "否", Value = "0" });
            return View(vm);
        }

        [HttpGet]
        public ActionResult CommitDismantle(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteDismantle model = _NuclearWasteDismantleRepository.Get(id);
            vm.NuclearWasteDismantle = model;
            return View("CommittDismantle", vm);
        }

        [HttpGet]
        public ActionResult ConfirmDismantle(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearWasteDismantle model = _NuclearWasteDismantleRepository.Get(id);
            vm.NuclearWasteDismantle = model;
            return View("ConfirmDismantle", vm);
        }

        /// <summary>
        /// 保存废物拆解
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddDismantle(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
            
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteDismantle.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteDismantle.Code = bucketId;

                
                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteDismantle.DismantleId))
                {
                    model.NuclearWasteDismantle.DismantleId = Guid.NewGuid().ToString();
                    model.NuclearWasteDismantle.Status = "0";//状态
                    model.NuclearWasteDismantle.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteDismantle.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteDismantle.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteDismantle.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDismantleRepository.Create(model.NuclearWasteDismantle);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDismantle.DismantleId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DISMANTLE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteDismantleRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteDismantle.DismantleId);
                    UpdateModel(model);
                    model.NuclearWasteDismantle.Status = "0";//状态
                    model.NuclearWasteDismantle.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteDismantle.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteDismantle.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteDismantle.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDismantleRepository.Update(model.NuclearWasteDismantle);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteDismantle.DismantleId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDismantle.DismantleId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DISMANTLE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteDismantleRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交废物拆解
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitDismantle(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }           
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteDismantle.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteDismantle.Code = bucketId;

                
                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteDismantle.DismantleId))
                {
                    model.NuclearWasteDismantle.DismantleId = Guid.NewGuid().ToString();
                    model.NuclearWasteDismantle.Status = "1";//状态
                    model.NuclearWasteDismantle.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteDismantle.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteDismantle.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteDismantle.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDismantleRepository.Create(model.NuclearWasteDismantle);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDismantle.DismantleId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DISMANTLE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteDismantleRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteDismantle.DismantleId);
                    UpdateModel(model);
                    model.NuclearWasteDismantle.Status = "1";//状态
                    model.NuclearWasteDismantle.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteDismantle.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteDismantle.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteDismantle.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDismantleRepository.Update(model.NuclearWasteDismantle);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteDismantle.DismantleId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDismantle.DismantleId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DISMANTLE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteDismantleRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
                
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确定废物拆解
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物拆解确认")]
        public JsonResult ConfirmDismantle(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }            
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearWasteDismantle.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearWasteDismantle.Code = bucketId;

                
                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearWasteDismantle.DismantleId))
                {
                    model.NuclearWasteDismantle.DismantleId = Guid.NewGuid().ToString();
                    model.NuclearWasteDismantle.Status = "2";//状态
                    model.NuclearWasteDismantle.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearWasteDismantle.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearWasteDismantle.CreateDate = DateTime.Now;//创建时间
                    model.NuclearWasteDismantle.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteDismantle.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteDismantle.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteDismantle.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDismantleRepository.Create(model.NuclearWasteDismantle);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDismantle.DismantleId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DISMANTLE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearWasteDismantleRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearWasteDismantle.DismantleId);
                    UpdateModel(model);
                    model.NuclearWasteDismantle.Status = "2";//状态

                    model.NuclearWasteDismantle.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearWasteDismantle.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearWasteDismantle.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearWasteDismantle.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearWasteDismantleRepository.Update(model.NuclearWasteDismantle);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearWasteDismantle.DismantleId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearWasteDismantle.DismantleId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "DISMANTLE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearWasteDismantleRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #endregion

        #region 特殊包装

        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "特殊包装")]
        public ActionResult IndexPackage()
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            vm.OperationList = CommonHelper.GetOperationList("Index_Package");//权限控制

            vm.NuclearSpecialPackage = new NuclearSpecialPackage();
            vm.BucketStatusList = new List<SelectListItem>();

            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            return View(vm);
        }

        [HttpGet]
        public ActionResult CommitPackage(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearSpecialPackage model = _NuclearSpecialPackageRepository.Get(id);
            vm.NuclearSpecialPackage = model;
            return View("CommittPackage", vm);
        }

        [HttpGet]
        public ActionResult ConfirmPackage(string id)
        {
            OtherTechnologyVM vm = new OtherTechnologyVM();
            NuclearSpecialPackage model = _NuclearSpecialPackageRepository.Get(id);
            vm.NuclearSpecialPackage = model;
            return View("ConfirmPackage", vm);
        }

        /// <summary>
        /// 保存特殊包装
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddPackage(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearSpecialPackage.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearSpecialPackage.Code = bucketId;

                //获取页面源项废物
                string evalNuclearSpecialPackage_SourceFlag = Request.Form["NuclearSpecialPackage_SourceFlag"];
                if (evalNuclearSpecialPackage_SourceFlag == "1")
                {
                    model.NuclearSpecialPackage.SourceFlag = "1"; 
                     
                         IQueryable<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList(model.NuclearSpecialPackage.TrackId, AppContext.CurrentUser.ProjectCode);
                        if (iqueryTrackItem.Count() == 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"源项废物单中不存在该跟踪单号。\"}", JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            TrackItemVM vm = iqueryTrackItem.ToList()[0];
                            model.NuclearSpecialPackage.TrackId = vm.TrackId;
                            model.NuclearSpecialPackage.TrackType = vm.TrackType;                             
                        }
                }
                else
                    model.NuclearSpecialPackage.SourceFlag = "0";

                //获取页面已打包废物
                string evalNuclearSpecialPackage_PackagedFlag = Request.Form["NuclearSpecialPackage_PackagedFlag"];
                if (evalNuclearSpecialPackage_PackagedFlag == "1")
                {
                    model.NuclearSpecialPackage.PackagedFlag = "1";
                    //判断废物货包是否存在 
                    string packageId = this._NuclearWastePackageRepository.IsExist(model.NuclearSpecialPackage.PackagedId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(packageId))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.NuclearSpecialPackage.PackagedId = packageId;
                }
                else
                    model.NuclearSpecialPackage.PackagedFlag = "0";

                //获取页面其他类型
                string evalNuclearSpecialPackage_OthersFlag = Request.Form["NuclearSpecialPackage_OthersFlag"];
                if (evalNuclearSpecialPackage_OthersFlag == "1")                
                    model.NuclearSpecialPackage.OthersFlag = "1"; 
                else
                    model.NuclearSpecialPackage.OthersFlag = "0";


                
                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearSpecialPackage.PackageId))
                {
                    model.NuclearSpecialPackage.PackageId = Guid.NewGuid().ToString();
                    model.NuclearSpecialPackage.Status = "0";//状态
                    model.NuclearSpecialPackage.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearSpecialPackage.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearSpecialPackage.CreateDate = DateTime.Now;//创建时间
                    model.NuclearSpecialPackage.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearSpecialPackageRepository.Create(model.NuclearSpecialPackage);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearSpecialPackage.PackageId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "PACKAGE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearSpecialPackageRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearSpecialPackage.PackageId);
                    UpdateModel(model);
                    model.NuclearSpecialPackage.Status = "0";//状态                    
                    model.NuclearSpecialPackage.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearSpecialPackage.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearSpecialPackage.CreateDate = DateTime.Now;//创建时间
                    model.NuclearSpecialPackage.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearSpecialPackageRepository.Update(model.NuclearSpecialPackage);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearSpecialPackage.PackageId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearSpecialPackage.PackageId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "PACKAGE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearSpecialPackageRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交特殊包装
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitPackage(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearSpecialPackage.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearSpecialPackage.Code = bucketId;

                //获取页面源项废物
                string evalNuclearSpecialPackage_SourceFlag = Request.Form["NuclearSpecialPackage_SourceFlag"];
                if (evalNuclearSpecialPackage_SourceFlag == "1")
                {
                    model.NuclearSpecialPackage.SourceFlag = "1";
                   // 判断源项跟踪单号是否存在
                    IQueryable<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList(model.NuclearSpecialPackage.TrackId, AppContext.CurrentUser.ProjectCode);
                    if (iqueryTrackItem.Count() == 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"源项废物单中不存在该跟踪单号。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        TrackItemVM vm = iqueryTrackItem.ToList()[0];
                        model.NuclearSpecialPackage.TrackId = vm.TrackId;
                        model.NuclearSpecialPackage.TrackType = vm.TrackType;                        
                    }                
                }
                else
                    model.NuclearSpecialPackage.SourceFlag = "0";
                //获取页面已打包废物
                string evalNuclearSpecialPackage_PackagedFlag = Request.Form["NuclearSpecialPackage_PackagedFlag"];
                if (evalNuclearSpecialPackage_PackagedFlag == "1")
                {
                    model.NuclearSpecialPackage.PackagedFlag = "1";
                    //判断废物货包是否存在 
                    string packageId = this._NuclearWastePackageRepository.IsExist(model.NuclearSpecialPackage.PackagedId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(packageId))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.NuclearSpecialPackage.PackagedId = packageId;
                }
                else
                    model.NuclearSpecialPackage.PackagedFlag = "0";

                //获取页面其他类型
                string evalNuclearSpecialPackage_OthersFlag = Request.Form["NuclearSpecialPackage_OthersFlag"];
                if (evalNuclearSpecialPackage_OthersFlag == "1")
                    model.NuclearSpecialPackage.OthersFlag = "1";
                else
                    model.NuclearSpecialPackage.OthersFlag = "0";
              


                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearSpecialPackage.PackageId))
                {
                    model.NuclearSpecialPackage.PackageId = Guid.NewGuid().ToString();
                    model.NuclearSpecialPackage.Status = "1";//状态
                    model.NuclearSpecialPackage.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearSpecialPackage.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearSpecialPackage.CreateDate = DateTime.Now;//创建时间
                    model.NuclearSpecialPackage.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearSpecialPackageRepository.Create(model.NuclearSpecialPackage);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearSpecialPackage.PackageId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "PACKAGE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearSpecialPackageRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearSpecialPackage.PackageId);
                    UpdateModel(model);
                    model.NuclearSpecialPackage.Status = "1";//状态                    
                    model.NuclearSpecialPackage.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearSpecialPackage.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearSpecialPackage.CreateDate = DateTime.Now;//创建时间
                    model.NuclearSpecialPackage.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearSpecialPackageRepository.Update(model.NuclearSpecialPackage);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearSpecialPackage.PackageId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearSpecialPackage.PackageId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "PACKAGE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearSpecialPackageRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// 确定特殊包装
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "特殊包装确认")]
        public JsonResult ConfirmPackage(OtherTechnologyVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //判断桶号是否存在 
                //string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearSpecialPackage.Code, AppContext.CurrentUser.ProjectCode);
                //if (string.IsNullOrEmpty(bucketId))
                //{
                //    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                //}
                //model.NuclearSpecialPackage.Code = bucketId;


                //获取页面源项废物
                string evalNuclearSpecialPackage_SourceFlag = Request.Form["NuclearSpecialPackage_SourceFlag"];
                if (evalNuclearSpecialPackage_SourceFlag == "1")
                {
                    model.NuclearSpecialPackage.SourceFlag = "1";
                    
                    IQueryable<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList(model.NuclearSpecialPackage.TrackId, AppContext.CurrentUser.ProjectCode);
                    if (iqueryTrackItem.Count() == 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"源项废物单中不存在该跟踪单号。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        TrackItemVM vm = iqueryTrackItem.ToList()[0];
                        model.NuclearSpecialPackage.TrackId = vm.TrackId;
                        model.NuclearSpecialPackage.TrackType = vm.TrackType;
                        if (model.NuclearSpecialPackage.Status != "2")
                        {
                            //修改暂存库存
                            this._NuclearTempstockRepository.MergeWasteTmpStock(vm.TrackType, vm.LocationId, AppContext.CurrentUser.ProjectCode, -1);
                        }
                    }                
                }
                else
                    model.NuclearSpecialPackage.SourceFlag = "0";

                //获取页面已打包废物
                string evalNuclearSpecialPackage_PackagedFlag = Request.Form["NuclearSpecialPackage_PackagedFlag"];
                if (evalNuclearSpecialPackage_PackagedFlag == "1")
                {
                    model.NuclearSpecialPackage.PackagedFlag = "1";
                    //判断废物货包是否存在 
                    string packageId = this._NuclearWastePackageRepository.IsExist(model.NuclearSpecialPackage.PackagedId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(packageId))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.NuclearSpecialPackage.PackagedId = packageId;
                }
                else
                    model.NuclearSpecialPackage.PackagedFlag = "0";

                //获取页面其他类型
                string evalNuclearSpecialPackage_OthersFlag = Request.Form["NuclearSpecialPackage_OthersFlag"];
                if (evalNuclearSpecialPackage_OthersFlag == "1")
                    model.NuclearSpecialPackage.OthersFlag = "1";
                else
                    model.NuclearSpecialPackage.OthersFlag = "0";



                
                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //新增
                if (string.IsNullOrEmpty(model.NuclearSpecialPackage.PackageId))
                {
                    model.NuclearSpecialPackage.PackageId = Guid.NewGuid().ToString();
                    model.NuclearSpecialPackage.Status = "2";//状态
                    model.NuclearSpecialPackage.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearSpecialPackage.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearSpecialPackage.CreateDate = DateTime.Now;//创建时间
                    model.NuclearSpecialPackage.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearSpecialPackage.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearSpecialPackage.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearSpecialPackage.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearSpecialPackageRepository.Create(model.NuclearSpecialPackage);//提交数据库


                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearSpecialPackage.PackageId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "PACKAGE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }

                    this._NuclearSpecialPackageRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改
                else
                {
                    model.NuclearWasteDegrade = _NuclearWasteDegradeRepository.Get(model.NuclearSpecialPackage.PackageId);
                    UpdateModel(model);
                    model.NuclearSpecialPackage.Status = "2";//状态

                    model.NuclearSpecialPackage.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NuclearSpecialPackage.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NuclearSpecialPackage.ConfirmDate = DateTime.Now;//确认时间
                    model.NuclearSpecialPackage.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._NuclearSpecialPackageRepository.Update(model.NuclearSpecialPackage);//提交数据库

                    List<NuclearOtherTrack> nuclearOtherTrackList = this._NuclearOtherTrackRepository.GetAll().Where(d => d.BusinessId == model.NuclearSpecialPackage.PackageId).ToList();
                    if (nuclearOtherTrackList.Count() > 0)
                    {
                        foreach (var item in nuclearOtherTrackList)
                        {
                            _NuclearOtherTrackRepository.DeleteById(item.OtherTrackId);
                        }

                    }

                    if (trackArray.Length > 0 && trackArray[0] != "")
                    {
                        foreach (var item in trackArray)
                        {
                            NuclearOtherTrack nuclearOtherTrack = new NuclearOtherTrack();
                            nuclearOtherTrack.OtherTrackId = Guid.NewGuid().ToString();
                            nuclearOtherTrack.BusinessId = model.NuclearSpecialPackage.PackageId;
                            nuclearOtherTrack.TrackId = item;
                            nuclearOtherTrack.BusinessType = "PACKAGE";
                            this._NuclearOtherTrackRepository.Create(nuclearOtherTrack);//提交数据库
                        }

                    }
                    this._NuclearSpecialPackageRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);

                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #endregion

        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetDataList(string keyword)
        {
            //数据源
            List<NuclearBucket> list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable().Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count>0)
            {
                for (int i = 0; i <list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].BucketCode;
                    autoComplete.Code = list[i].BucketId;
                    autoCompleteList.Add(autoComplete);
                }
            }           
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 自动填充——废物跟踪单
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetTrackCodeList(string keyword)
        {
            //数据源
           List<TrackItemVM> list = TrackItemBuilder.GetAllTrackList(keyword, AppContext.CurrentUser.ProjectCode).AsQueryable().Take(10).ToList();//.Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count>0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].TrackCode;
                    autoComplete.Code = list[i].TrackId;
                    autoCompleteList.Add(autoComplete);
                }                
            }           
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 自动填充控件-废物货包
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetPackageList(string keyword)
        {
            //数据源
            List<NuclearWastePackage> list = _NuclearWastePackageRepository.GetAll().Where(e => e.PackageCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable().Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count > 0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].PackageCode;
                    autoComplete.Code = list[i].PackageId;
                    autoCompleteList.Add(autoComplete);
                }
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 检查废物跟踪单号
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckTrack()
        {
            string trackCode = Request["code"];
            var trackList = TrackItemBuilder.GetTrackList(AppContext.CurrentUser.ProjectCode).Where(d => d.TrackCode == trackCode.Trim()).Where(c => c.DealStatus == "0").ToList();
            if (trackList.Count == 0)
            {
                return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在或者已经处理。\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"" + trackList[0].TrackId + "\"}", JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 自动填充——废树脂废物跟踪单
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetResinTrackDataList(string keyword)
        {
            List<TrackItemVM> list = TrackItemBuilder.GetTrackList(AppContext.CurrentUser.ProjectCode).Where(d => d.TrackCode.ToUpper().Contains(keyword.Trim().ToUpper())).Where(c => c.DealStatus == "0" || c.DealStatus == ""  || c.DealStatus == null ).AsQueryable().ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count > 0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].TrackCode;
                    autoComplete.Code = list[i].TrackId;
                    autoCompleteList.Add(autoComplete);
                }

            }

            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
