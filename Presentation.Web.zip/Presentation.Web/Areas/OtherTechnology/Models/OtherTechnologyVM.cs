﻿/********************************************************************************
 *
 *   项目名称   ：   核电废物信息系统
 *   文 件 名   ：   OtherTechnologyVM.cs
 *   描    述   ：   其他工艺vm
 *   创 建 者   ：   郑浩宇 
 *   创建日期   ：   2016-09-13 12:01:45
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-13 12:01:45    1.0.0.0    郑浩宇       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.OtherTechnology.Models
{
    /// <summary>
    /// 其他工艺vm
    /// </summary>
    public class OtherTechnologyVM
    {
        /// <summary>
        /// 废物解控 实体
        /// </summary>
        public NuclearWasteClear NuclearWasteClear { get; set; }

        /// <summary>
        /// 废物降解 实体
        /// </summary>
        public NuclearWasteDegrade NuclearWasteDegrade { get; set; }

        /// <summary>
        /// 废物拆解 实体
        /// </summary>
        public NuclearWasteDismantle NuclearWasteDismantle { get; set; }

        /// <summary>
        /// 废物焚烧 实体
        /// </summary>
        public NuclearWasteFire NuclearWasteFire { get; set; }

        /// <summary>
        /// 高整体容器处理废物 实体
        /// </summary>
        public NuclearWasteHDispose NuclearWasteHDispose { get; set; }

        /// <summary>
        /// 极低放废物处理 实体
        /// </summary>
        public NuclearWasteLDispose NuclearWasteLDispose { get; set; }

        /// <summary>
        /// 废物熔炼 实体
        /// </summary>
        public NuclearWasteSmelt NuclearWasteSmelt { get; set; }

        /// <summary>
        /// 特殊包装
        /// </summary>
        public NuclearSpecialPackage NuclearSpecialPackage { get; set; }

        /// <summary>
        /// 废物类型
        /// </summary>
        public List<SelectListItem> WasteTypeIdList { get; set; }

        /// <summary>
        /// 废物类型
        /// </summary>
        public string WasteTypeIdName { get; set; }

        /// <summary>
        /// 解控后存储位置
        /// </summary>
        public List<SelectListItem> WastePositionList { get; set; }

        /// <summary>
        /// 解控后存储位置
        /// </summary>
        public string WastePositionName { get; set; }

        /// <summary>
        /// 废物是否满足解控要求
        /// </summary>
        public List<SelectListItem> ClearFlagRodiodList { get; set; }

        /// <summary>
        /// RP测量结果
        /// </summary>
        public List<SelectListItem> RpResultRodiodList { get; set; }

        /// <summary>
        /// 是否需要再处理
        /// </summary>
        public List<SelectListItem> ReprocessFlagRodiodList { get; set; }

        /// <summary>
        /// 是否可以焚烧
        /// </summary>
        public List<SelectListItem> FireFlagRodiodList { get; set; }

        /// <summary>
        /// 拆解方式
        /// </summary>
        public List<SelectListItem> DismantleWayList { get; set; }

        /// <summary>
        /// 拆解方式
        /// </summary>
        public string DismantleWayName { get; set; }

        /// <summary>
        /// 存储方式-暂存包装容器
        /// </summary>
        public List<SelectListItem> SaveFlagCodeList { get; set; }

        /// <summary>
        /// 存储方式-暂存厂房
        /// </summary>
        public List<SelectListItem> SaveFlagFactoryList { get; set; }

        /// <summary>
        /// 拆解后存储位置
        /// </summary>
        public List<SelectListItem> SaveFactoryList { get; set; }

        /// <summary>
        /// 桶状态
        /// </summary>
        public List<SelectListItem> BucketStatusList { get; set; }

        /// <summary>
        /// 权限验证
        /// </summary>
        public string OperationList { get; set; }

        /// <summary>
        /// 废物焚烧
        /// </summary>
        public List<GiftDetailList> GiftDetailList { get; set; }
        
    }
}
