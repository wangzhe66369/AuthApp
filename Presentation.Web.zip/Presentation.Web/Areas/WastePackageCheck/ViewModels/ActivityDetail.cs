﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels
{
    public class ActivityDetail
    {
        /// <summary>
        /// 核素名称
        /// </summary>
        public string ElementName { set; get; }

        /// <summary>
        /// 核素ID
        /// </summary>
        public string ElementId { set; get; }

        /// <summary>
        /// 核素分类
        /// </summary>
        public string ElementClass { set; get; }

        /// <summary>
        /// 半衰期
        /// </summary>
        public Nullable<decimal> HalfLife { set; get; }

        /// <summary>
        /// 能谱活度
        /// </summary>
        public Nullable<decimal> OriginalActivity { set; get; }

        /// <summary>
        /// 能谱活度百分比
        /// </summary>
        public Nullable<decimal> OriginalActivityPercent { set; get; }

        /// <summary>
        /// 原废物活度
        /// </summary>
        public Nullable<decimal> OriginalWasteActivity { set; get; }

        /// <summary>
        /// 比例值
        /// </summary>
        public Nullable<double> PercentValue { get; set; }
        /// <summary>
        /// 活度
        /// </summary>
        public Nullable<double> Activity { get; set; }
    }
}