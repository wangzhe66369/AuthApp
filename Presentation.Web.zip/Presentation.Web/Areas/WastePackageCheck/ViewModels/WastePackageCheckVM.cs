﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Presentation.Web.ViewModels.Common;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels
{
    public class WastePackageCheckVM
    {
        /// <summary>
        /// 废物货包信息
        /// </summary>
        public WastePackageBucketVM WastePackageBucketVM { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DispsiteEval DispsiteEval { get; set; }

        /// <summary>
        /// 放射性特性评估验算
        /// </summary>
        public ActivityOrder ActivityOrder { get; set; }

        /// <summary>
        /// 废物货包审批
        /// </summary>
        public DispsiteApprove DispsiteApprove { get; set; }
        /// <summary>
        /// 放射性特性评估验算明细
        /// </summary>
        public List<DispiteEvalDetail> DispiteEvalDetailList { get; set; }

        /// <summary>
        /// 桶信息
        /// </summary>
        public NuclearBucket NuclearBucket { get; set; }

        /// <summary>
        /// 距离桶1米处剂量率
        /// </summary>
        public Nullable<decimal> DoseMeter { get; set; }

        //废物类型
        public string WasteType { get; set; }
        //处理方式
        public string DealMethod { get; set; }
        //材料名称
        public string MaterialName { get; set; }
        /// <summary>
        /// 桶的材料信息
        /// </summary>
        public MaterialInputVM MaterialInputVM { get; set; }

        /// <summary>
        /// 桶检查信息
        /// </summary>
        public NuclearBucketCheck NuclearBucketCheck { get; set; }
        
         /// <summary>
        /// 材料入库信息
        /// </summary>
        public MaterialInput MaterialInput { get; set; }
        /// <summary>
        /// 是否存在转运或者存储
        /// </summary>
        public bool IsExistTransferAndStorage { get; set; }

        /// <summary>
        /// 处理申请实体
        /// </summary>
        public NuclearProcessApply NuclearProcessApply { get; set; }

        /// <summary>
        /// 处理申请明细实体
        /// </summary>
        public NuclearApplyDetail NuclearApplyDetail { get; set; }
        
         /// <summary>
        /// 废物报审核实体
        /// </summary>
        public DispsiteCheck DispsiteCheck { get; set; }

        /// <summary>
        /// 申请明细
        /// </summary>
        public string ApplyDetailId { get; set; }

        /// <summary>
        /// 废物报审核明细实体
        /// </summary>
        public DispsiteCheckDetail DispsiteCheckDetail { get; set; }

        /// <summary>
        /// 暂存位置
        /// </summary>
        public List<SelectListItem> StoragePositionIdList { get; set; }

        public string ProcessFactoryId { get; set; }

        /// <summary>
        /// 厂房位置ID
        /// </summary>
        public string StoragePositionId { get; set; }

        /// <summary>
        /// 状态列表
        /// </summary>
        public List<SelectListItem> StatusList { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> AttachFiles { get; set; }
        public UploadFileListVM UploadFileListVM { get; set; }
        /// <summary>
        /// 审查结果附件列表
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> CheckReportFileList;


        /// <summary>
        /// 处置申报附件列表
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> ApplyDealFileList;

        /// <summary>
        /// 桶信息审核结果列表
        /// </summary>
        public List<SelectListItem> CheckMaterialList { get; set; }

        /// <summary>
        /// 桶检查信息审核结果列表
        /// </summary>
        public List<SelectListItem> CheckBucketAduitList { get; set; }

        /// <summary>
        /// 审核结果列表
        /// </summary>
        public List<SelectListItem> CheckBucketMesList { get; set; }

        /// <summary>
        /// 审核结果列表
        /// </summary>
        public List<SelectListItem> EvaluateList { get; set; }

        /// <summary>
        /// 装桶信息审核结果列表
        /// </summary>
        public List<SelectListItem> CheckBucketDealList { get; set; }

        /// <summary>
        /// 桶封盖信息审核结果列表
        /// </summary>
        public List<SelectListItem> CheckBucketCoverList { get; set; }

        /// <summary>
        /// 桶转运与存储信息审核结果列表
        /// </summary>
        public List<SelectListItem> CheckBucketTransferList { get; set; }
        
        /// <summary>
        /// 金属衬里
        /// </summary>
        public string HasLining { get; set; }
        /// <summary>
        /// 金属外观质量
        /// </summary>
        public string TechStandard { get; set; }
        /// <summary>
        /// 审核结果列表
        /// </summary>
        public List<SelectListItem> CheckResultList { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }
        
        //认定单号
        public string IdentityCode { get; set; }

        //文件是否完整
        public List<SelectListItem> FileIsCompletedList { get; set; }

        /// <summary>
        /// 浓缩液装桶固化400l金属桶主键ID
        /// </summary>
        public string SolutionId { get; set; }
        /// <summary>
        /// 废树脂装桶固化400l金属桶主键ID
        /// </summary>
        public string ResinId { get; set; }
        /// <summary>
        /// 干湿料制备及废树脂装桶固化主键ID
        /// </summary>
        public string RSolidifyId { get; set; }
        /// <summary>
        /// 干湿料制备及浓缩液装桶固化主键ID
        /// </summary>
        public string SSolidifyId { get; set; }
        /// <summary>
        /// 湿混料制备及400L金属桶装桶封盖
        /// </summary>
        public string MetalId { get; set; }
        /// <summary>
        /// 湿混料制备及封盖
        /// </summary>
        public string MixId { get; set; }
        /// <summary>
        /// 废物货包转运及QT贮存移动单
        /// </summary>
        public string QtTransId { get; set; }
        /// <summary>
        /// 厂房间废物桶转运
        /// </summary>
        public string FcTransId { get; set; }
        /// <summary>
        /// QT厂房废物货包入库记录
        /// </summary>
        public string GoodsInId { get; set; }
        /// <summary>
        /// QT厂房废物货包出库记录
        /// </summary>
        public string GoodsOutId { get; set; }

        public List<TrackItem> trackIdIdJoinList { get; set; }

        public List<CIT.UPC.Domain.DomainObjects.AttachFile> MaterialInputAttachFiles { get; set; }
    }

    /// <summary>
    /// 处理类型
    /// </summary>
    public class DealMethod
    {
        public string DealMethodStatus { set; get; }
    }
    /// <summary>
    /// 
    /// </summary>
    public class TrackItem
    {
        /// <summary>
        /// 跟踪单ID 
        /// </summary>
        public string TrackId { set; get; }

        /// <summary>
        /// 废物跟踪单号
        /// </summary>
        public string TrackCode { set; get; }
        /// <summary>
        /// 废物跟踪单号类型
        /// </summary>
        public string TrackType { set; get; }
    }
}