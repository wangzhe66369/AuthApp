﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;


namespace RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels
{
    public class WastePackageBucketVM
    {
        /// <summary>
        /// 废物桶
        /// </summary>
        public NuclearBucket NuclearBucket { set;get;}

        /// <summary>
        /// 废物货包
        /// </summary>
        public NuclearWastePackage NuclearWastePackage { set; get; }
    }
}