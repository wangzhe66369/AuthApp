﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels
{
    /// <summary>
    /// 活度计算单 
    /// </summary>
    public class ActivityOrder
    {
        /// <summary>
        /// 封盖信息
        /// </summary>
        public CoverInfo CoverInfo { get; set; }

        /// <summary>
        /// 活度计算ID
        /// </summary>
        public string AcitivityId { get; set; }

        /// <summary>
        /// 能谱序号ID
        /// </summary>
        public string ElemAnalysisId { get; set; }

        /// <summary>
        /// 比例因子类型
        /// </summary>
        public string FactorType { get; set; }

        /// <summary>
        /// 总活度
        /// </summary>
        public Nullable<decimal> AddCalcuActivity { get; set; }

        /// <summary>
        /// 压缩桶数量
        /// </summary>
        public Nullable<double> CompressBucketCount { set; get; }

        /// <summary>
        /// 关联因素比值
        /// </summary>
        public Nullable<double> RelationFactorValue { set; get; }

        /// <summary>
        /// 活度计算单类项
        /// </summary>
        public string ActivityOrderType { set; get; }

        public List<DispiteEvalDetailVM> DispiteEvalDetailVMList { set; get; }
        public List<DispiteEvalDetail> DispiteEvalDetailList { set; get; }
        public string BucketCode { set; get; }
        public string WastePacakgeCode { set; get; }
         
        /// <summary>
        /// 桶饼数量
        /// </summary>
        public int BucketHandleCount { set; get; }

        /// <summary>
        /// 能谱序号
        /// </summary>
        public string EdsCode { set; get; }

        /// <summary>
        /// 废物货包重量
        /// </summary>
        public string PackageWeight { set; get; }

        /// <summary>
        /// 空桶重量
        /// </summary>
        public string EmptyBucketWeight { set; get; }

        /// <summary>
        /// 桶预留封盖空间(cm)
        /// </summary>
        public string OverSpace { set; get; }

        /// <summary>
        /// 封盖重量
        /// </summary>
        public string CoverWeight { set; get; }

        /// <summary>
        /// 固化体质量
        /// </summary>
        public string GiftWeight { set; get; }

        /// <summary>
        /// 屏蔽重量
        /// </summary>
        public Nullable<decimal> ShiledWeight { set; get; }

        /// <summary>
        ///转换函数
        /// </summary>
        public string TransferPara { set; get; }

        /// <summary>
        /// 废物类型ID
        /// </summary>
        public string WasteTypeId { set; get; }

        /// <summary>
        /// 废物类型
        /// </summary>
        public string WasteType { set; get; }

        /// <summary>
        /// 平均剂量率
        /// </summary>
        public string AvgDoseRate { set; get; }

       /// <summary>
        /// 破损情况
       /// </summary>
        public string Damage { set; get; }

        /// <summary>
        /// 初始γ核素计算日期
        /// </summary>
        public string InitialCalcuDate { get; set; }

        /// <summary>
        ///废物固化日期
        /// </summary>
        public string WasteGiftDate { get; set; }

        /// <summary>
        ///废物产生日期
        /// </summary>
        public string WasteProduceDate { get; set; }

        /// <summary>
        /// 与废物产生日间隔(d)
        /// </summary>
        public string MinusProduceDate { get; set; }

        /// <summary>
        /// 与初始活度计算时间差(d)
        /// </summary>
        public string MinusOriginalActivity { get; set; }

        /// <summary>
        /// 放射性检查评估日期
        /// </summary>
        public string ActivityEvalDate { get; set; }

        /// <summary>
        /// 能谱测量日期
        /// </summary>
        public string EdsCalcuDate { get; set; }


        /// <summary>
        /// 活度测量日期
        /// </summary>
        public string ActivityCalcuDate { get; set; }

        /// <summary>
        /// 原废物装桶日期
        /// </summary>
        public string WasteInputBucketDate { get; set; }

       /// <summary>
        /// 废物体积
       /// </summary>
        public Nullable<decimal> WasteVolumn { get; set; }

        //桶体积
        public Nullable<decimal> BucketVolumn { get; set; }

        /// <summary>
        /// 废物总活度
        /// </summary>
        public string TotalWasteActivity { get; set; }

        /// <summary>
        /// 审查日废物总α
        /// </summary>
        public string TotalCheckActivity { get; set; }

        /// <summary>
        /// 原废物活度总和 
        /// </summary>
        public string TotalOriginalActivity { get; set; }


        public string TotalCheckActivityPercent { get; set; }

        public string _totalCheckActivityUnit;
        public string TotalCheckActivityUnit
        {
            set
            {
                _totalCheckActivityUnit = value;
            }
            get
            {
                if (string.IsNullOrEmpty(_totalCheckActivityUnit))
                {
                    return "0";
                }
                else
                {
                    return _totalCheckActivityUnit;
                }
            }
        }
        public string TotalActivity { get; set; }
        public string TotalZActivity { get; set; }
        public string DecayThreeHundred { get; set; }
        public string DecayThreeHundredValue { get; set; }
        public string Classify { get; set; }
        public string ClassifyValue { get; set; }
        public string SurfaceClass { get; set; }
        public string SurfaceClassValue1 { get; set; }
        public string SurfaceClassValue2 { get; set; }
        public string DecayHeat { get; set; }
        public string CalcuThreeHundred { get; set; }
        public string CalcuNo { get; set; }
        public string CalcuName { get; set; }
        public Nullable<System.DateTime> CalcuDate { get; set; }
        public string CheckNo { get; set; }
        public string CheckName { get; set; }
        public Nullable<System.DateTime> CheckDate { get; set; }

        /// <summary>
        /// 核素活度与A1限值的比较
        /// </summary>
        public string ActivityCompare { get; set; }

        /// <summary>
        /// 关键核素比活度与处置场环评限值的比较
        /// </summary>
        public string KeyActivityUnitCompare { get; set; }

         //处置场ID
        public string DispitePositionId { get; set; }
    }

    /// <summary>
    /// 废物桶信息 
    /// </summary>
    public class WasteBucket
    {
        /// <summary>
        ///桶ID
        /// </summary>
        public string BucketId { get; set; }

        /// <summary>
        ///废物跟踪单ID
        /// </summary>
        public string TrackId { get; set; }

    }

    /// <summary>
    /// 废物跟踪单信息 
    /// </summary>
    public class TrackOrder
    {
        /// <summary>
        ///桶ID
        /// </summary>
        public string BucketId { get; set; }

        /// <summary>
        ///废物跟踪单ID
        /// </summary>
        public string TrackId { get; set; }

        /// <summary>
        ///废物跟踪单类型
        /// </summary>
        public string TrackType { get; set; }

        /// <summary>
        /// 废物跟踪单确认时间
        /// </summary>
        public Nullable<DateTime> ConfirmDate { get; set; }

        /// <summary>
        /// 废物跟踪单产生时间
        /// </summary>
        public Nullable<DateTime> ControlDate { get; set; }
    }

    /// <summary>
    /// 封盖信息
    /// </summary>
    public class CoverInfo
    {
        /// <summary>
        /// 预留封盖空间
        /// </summary>
        public string OverSpace { get; set; }

        /// <summary>
        ///废物固化日期
        /// </summary>
        public Nullable<System.DateTime> WasteGiftDate { get; set; }

        public Nullable<decimal> CurdleWeight { get; set; }
    }
}