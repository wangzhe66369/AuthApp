﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels
{
    public class DispiteEvalDetailVM
    {
        /// <summary>
        /// 是否是特殊的比活度单位
        /// </summary>
        public bool IsSpecialActivityUnit { get; set; }
        public string DetailId { get; set; }
        public string ElementId { get; set; }

        /// <summary>
        /// 核素名称
        /// </summary>
        public string ElementName { get; set; }

        /// <summary>
        /// 核素分类 1：可测  0：不可测
        /// </summary>
        public string ElementClass { get; set; }

        /// <summary>
        /// 半衰期
        /// </summary>
        public string _halfLife;
        public string HalfLife
        {
            set
            {
                _halfLife = value;
            }
            get
            {
                if (string.IsNullOrEmpty(_halfLife))
                {
                    return "0";
                }
                else
                {
                    return _halfLife;
                }
            }
        }


        /// <summary>
        /// 原γ活度谱
        /// </summary>
        public Nullable<decimal> OriginalActivity { get; set; }

        /// <summary>
        /// 原γ活度谱百分比
        /// </summary>
        public Nullable<decimal> OriginalActivityPercent { get; set; }

        /// <summary>
        /// 计算谱
        /// </summary>
        public string CalcuSpectraActivity { get; set; }

        /// <summary>
        /// 计算谱百分比
        /// </summary>
        public Nullable<decimal> CalcuSpectraPercent { get; set; }

        /// <summary>
        /// 初始γ活度
        /// </summary>
        public string _initialActivity;
        public string InitialActivity
        {

            set
            {
                _initialActivity = value;
            }
            get
            {
                if (string.IsNullOrEmpty(_initialActivity))
                {
                    return "0";
                }
                else
                {
                    return _initialActivity;
                }
            }
        }

        /// <summary>
        /// 原废物活度
        /// </summary>
        public string _originalWasteActivity;
        public string OriginalWasteActivity
        {

            set
            {

                _originalWasteActivity = value;

            }
            get
            {
                if (string.IsNullOrEmpty(_originalWasteActivity))
                {
                    return "0";
                }
                else
                {
                    return _originalWasteActivity;
                }
            }
        }
        /// <summary>
        /// 审查日废物活度
        /// </summary>
        public string _checkdateActivity;
        public string CheckdateActivity
        {
            set
            {
                _checkdateActivity = value;
            }
            get
            {
                if (string.IsNullOrEmpty(_checkdateActivity) || _checkdateActivity=="非数字")
                {
                    return "0";
                }
                else
                {
                    return _checkdateActivity;
                }
            }
        }

        /// <summary>
        /// 审查日废物活度百分比
        /// </summary>
        public Nullable<decimal> CheckdateActivityPercent { get; set; }

        /// <summary>
        /// 审查日废物比活度(Bq/M3)
        /// </summary>
        public string _checkdateActivityUnit;
        public string CheckdateActivityUnit
        {
            set
            {
                _checkdateActivityUnit = value;
            }
            get
            {
                if (string.IsNullOrEmpty(_checkdateActivityUnit))
                {
                    return "0";
                }
                else
                {
                    return _checkdateActivityUnit;
                }
            }
        }

        public string _zActivity;
        public string ZActivity
        {
            set
            {
                    _zActivity = value;
            }
            get
            {
                if (string.IsNullOrEmpty(_zActivity))
                {
                    return "0";
                }
                else
                {
                    return _zActivity;
                }
            }
        }

    }
}