﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels
{
    public class DeclareConfirmVM
    {
        /// <summary>
        /// 废物货包审批
        /// </summary>
        public DispsiteApprove DispsiteApprove { get; set; }
        /// <summary>
        /// 废物货包审批明细
        /// </summary>
        public NuclearApproveDetail NuclearApproveDetail { get; set; }
        /// <summary>
        /// 处理申请实体
        /// </summary>
        public NuclearProcessApply NuclearProcessApply { get; set; }

        /// <summary>
        /// 处理申请明细实体
        /// </summary>
        public NuclearApplyDetail NuclearApplyDetail { get; set; }

        /// <summary>
        /// 废物报审核实体
        /// </summary>
        public DispsiteCheck DispsiteCheck { get; set; }

        /// <summary>
        /// 废物货包
        /// </summary>
        public NuclearWastePackage NuclearWastePackage { get; set; }

        /// <summary>
        /// 暂存位置
        /// </summary>
        public List<SelectListItem> StoragePositionIdList { get; set; }
        public string ProcessFactoryId { get; set; }

        /// <summary>
        /// 厂房位置ID
        /// </summary>
        public string StoragePositionId { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> AttachFiles { get; set; }
        /// <summary>
        /// 处置申报附件列表
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> ApplyDealFileList { get; set; }
        /// <summary>
        /// 审查结果附件列表
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> CheckReportFileList { get; set; }
        /// <summary>
        /// 审批结果附件列表
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> ApproveReportFileList { get; set; }

        /// <summary>
        /// ApplyDetailId
        /// </summary>
        public string ApplyDetailId { get; set; }

        /// <summary>
        /// 电站
        /// </summary>
        public string StationCode { get; set; }
        //页面寄存器
        public string PackageCodes { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }
        //审批时间
        public Nullable<System.DateTime> DeclareDate { get; set; }
        //认定单号
        public string IdentityCode { get; set; } 
        //审查经过
        public string CheckDescription { get; set; }
        //评价意见
        public string PriceOpinion { get; set; }
    } 
}