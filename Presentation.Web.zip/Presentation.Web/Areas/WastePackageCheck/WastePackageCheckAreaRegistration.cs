﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck
{
    public class WastePackageCheckAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "WastePackageCheck";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "WastePackageCheck_default",
                "WastePackageCheck/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
