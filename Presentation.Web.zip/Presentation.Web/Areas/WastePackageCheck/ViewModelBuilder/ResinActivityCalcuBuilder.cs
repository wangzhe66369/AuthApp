﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   WasteCheckBuilder.cs
 *   描    述   ：   废物货包审核查询类
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-28 18:45:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-28 18:45:00    1.0.0.0     PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Domain.DomainObjects.View.Support;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModelBuilder
{
    public class ResinActivityCalcuBuilder
    {
        /// <summary>
        /// 得到废树脂废物类型的放射性特性评估验算内容
        /// </summary>
        /// <param name="activityOrder">活度计算单</param>
        /// <returns></returns>
        public static ActivityOrder GetResinCalcuElement(ActivityOrder activityOrder)
        {
            //比例因子信息
            IScalefactorRepository iScalefactorRepository = ServiceLocator.Current.GetInstance<IScalefactorRepository>();
            string fatorType = activityOrder.FactorType;
            if (string.IsNullOrEmpty(fatorType))
            {
                fatorType = "CGN";
            }
            IQueryable<Scalefactor> iqueryScalefactor = iScalefactorRepository.GetAll().AsQueryable().Where(c => c.WasteTypeId == activityOrder.WasteTypeId && c.FactorType.ToUpper().Trim() == fatorType.ToUpper().Trim());

            //核素信息
            INuclearElementRepository iNuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = iNuclearElementRepository.GetAll().AsQueryable();

            List<Scalefactor> scalefactorList = new List<Scalefactor>();
            var query = from s in iqueryScalefactor
                        join e in iqueryNuclearElement
                        on s.DtmElementId equals e.ElementId
                        select s;
            if (query.Count() > 0)
            { 
                scalefactorList = query.ToList();
            }

            //实例化近地表处置参数设置
            SurfaceDealCondition surfaceDealCondition = new SurfaceDealCondition();
            ISupportSurfaceDealRepository iSupportSurfaceDealRepository = ServiceLocator.Current.GetInstance<ISupportSurfaceDealRepository>();
            List<SurfaceDealView> supportSurfaceDealList = iSupportSurfaceDealRepository.QueryList(surfaceDealCondition).ToList();

            //得到α废物的限制1
            string wasteLimit1 = "0";
            NuclearElementCondition nuclearElementCondition = new NuclearElementCondition();
            nuclearElementCondition.ElementName = "α废物";
            IQueryable<NuclearElementView> iqueryLimit1 = iNuclearElementRepository.QueryList(nuclearElementCondition);
            if (iqueryLimit1 != null && iqueryLimit1.Count() > 0)
            {
                Nullable<decimal> limit1Value = iqueryLimit1.ToList()[0].LimitValue1;
                wasteLimit1 = limit1Value.ToString();
            }

            //得到高放固体废物限制1
            string highWasteLimit1 = "0";
            nuclearElementCondition.ElementName = "高放固体废物";
            iqueryLimit1 = iNuclearElementRepository.QueryList(nuclearElementCondition);
            if (iqueryLimit1 != null && iqueryLimit1.Count() > 0)
            {
                Nullable<decimal> limit1Value = iqueryLimit1.ToList()[0].LimitValue1;
                highWasteLimit1 = limit1Value.ToString();
            }

            //得到中放固体废物限制1
            string middleWasteLimit1 = "0";
            nuclearElementCondition.ElementName = "中放固体废物";
            iqueryLimit1 = iNuclearElementRepository.QueryList(nuclearElementCondition);
            if (iqueryLimit1 != null && iqueryLimit1.Count() > 0)
            {
                Nullable<decimal> limit1Value = iqueryLimit1.ToList()[0].LimitValue1;
                middleWasteLimit1 = limit1Value.ToString();
            }

            //得到低放固体废物限制1
            string lowerWasteLimit1 = "0";
            nuclearElementCondition.ElementName = "低放固体废物";
            iqueryLimit1 = iNuclearElementRepository.QueryList(nuclearElementCondition);
            if (iqueryLimit1 != null && iqueryLimit1.Count() > 0)
            {
                Nullable<decimal> limit1Value = iqueryLimit1.ToList()[0].LimitValue1;
                lowerWasteLimit1 = limit1Value.ToString();
            }

            ActivityOrder model = new ActivityOrder();

            //与废物装桶固化日间隔(d)=得到初始活度计算日期-废物产生日期
            DateTime initialCalcuDate = Convert.ToDateTime(activityOrder.InitialCalcuDate);
            DateTime edsCalcuDate = Convert.ToDateTime(activityOrder.EdsCalcuDate);
            double days = (initialCalcuDate - edsCalcuDate).TotalDays;

            //与初始活度计算时间差(d)=得到放射性评估日期-初始核素计算日期
            DateTime activityEvalDate = Convert.ToDateTime(activityOrder.ActivityEvalDate);
            float minusDays = float.Parse((activityEvalDate - initialCalcuDate).TotalDays.ToString());

            //逐行计算核素活度信息
            List<DispiteEvalDetailVM> list = new List<DispiteEvalDetailVM>();
            string pu_239Original = "0";
            string co_60Original = "0";

            //审查日废物活度总和 
            string sumCheckdateActivity = "0";
            string sumZActivity = "0";
            string pu_239ZActivity = "0";

            //IAEA以及极低放数值
            string iaea_Cr51_Value = "1";
            string iaea_Mn54_Value = "1";
            string iaea_Co57_Value = "1";
            string iaea_Co58_Value = "1";
            string iaea_Co60_Value = "1";
            string iaea_Zn65_Value = "1";
            string iaea_Nb95_Value = "1";
            string iaea_Zr95_Value = "1";
            string iaea_Ru106_Value = "1";
            string iaea_Ag110m_Value = "1";
            string iaea_Sn113_Value = "1";
            string iaea_Sb124_Value = "1";
            string iaea_Cm242_Value = "1";
            string iaea_Fe59_Value = "1";
            string iaea_Cs137_Value = "1";
            string iaea_H3_Value = "1";
            string iaea_Pu241_Value = "1";
            string iaea_Pu239_Value = "1";
            string iaea_Sr90_Value = "1";
            string iaea_I129_Value = "1";
            string iaea_Ni63_Value = "1";
            string iaea_Ni59_Value = "1";
            string iaea_C14_Value = "1";
            string iaea_Tc99_Value = "1";
            string iaea_Nb94_Value = "1";

            string lower_Cr51_Value = "1";
            string lower_Mn54_Value = "1";
            string lower_Co57_Value = "1";
            string lower_Co58_Value = "1";
            string lower_Co60_Value = "1";
            string lower_Zn65_Value = "1";
            string lower_Nb95_Value = "1";
            string lower_Zr95_Value = "1";
            string lower_Ru106_Value = "1";
            string lower_Ag110m_Value = "1";
            string lower_Sn113_Value = "1";
            string lower_Sb124_Value = "1";
            string lower_Cm242_Value = "1";
            string lower_Fe59_Value = "1";
            string lower_Cs134_Value = "1";
            string lower_Cs137_Value = "1";
            string lower_H3_Value = "1";
            string lower_Pu241_Value = "1";
            string lower_Pu239_Value = "1";
            string lower_Sr90_Value = "1";
            string lower_I129_Value = "1";
            string lower_Ni63_Value = "1";
            string lower_Ni59_Value = "1";
            string lower_C14_Value = "1";
            string lower_Tc99_Value = "1";
            string lower_Nb94_Value = "1";

            //审查日废物活度
            string checkDate_Cr51_Value = "0";
            string checkDate_Mn54_Value = "0";
            string checkDate_Co57_Value = "0";
            string checkDate_Co58_Value = "0";
            string checkDate_Co60_Value = "0";
            string checkDate_Zn65_Value = "0";
            string checkDate_Nb95_Value = "0";
            string checkDate_Zr95_Value = "0";
            string checkDate_Ru106_Value = "0";
            string checkDate_Ag110m_Value = "0";
            string checkDate_Sn113_Value = "0";
            string checkDate_Sb124_Value = "0";
            string checkDate_Cm242_Value = "0";
            string checkDate_Fe59_Value = "0";
            string checkDate_Cs134_Value = "0";
            string checkDate_Cs137_Value = "0";
            string checkDate_H3_Value = "0";
            string checkDate_Pu241_Value = "0";
            string checkDate_Pu239_Value = "0";
            string checkDate_Sr90_Value = "0";
            string checkDate_I129_Value = "0";
            string checkDate_Ni63_Value = "0";
            string checkDate_Ni59_Value = "0";
            string checkDate_C14_Value = "0";
            string checkDate_Tc99_Value = "0";
            string checkDate_Nb94_Value = "0";

            //审查日废物活度R列的数值
            string checkDate_r_Cr51_Value = "0";
            string checkDate_r_Mn54_Value = "0";
            string checkDate_r_Co57_Value = "0";
            string checkDate_r_Co58_Value = "0";
            string checkDate_r_Co60_Value = "0";
            string checkDate_r_Fe59_Value = "0";
            string checkDate_r_Nb95_Value = "0";
            string checkDate_r_Zr95_Value = "0";
            string checkDate_r_Zn65_Value = "0";
            string checkDate_r_Ru106_Value = "0";
            string checkDate_r_Ag110m_Value = "0";
            string checkDate_r_Sn113_Value = "0";
            string checkDate_r_Sn117m_Value = "0";
            string checkDate_r_Sb124_Value = "0";
            string checkDate_r_Cs134_Value = "0";
            string checkDate_r_Cr137_Value = "0";
            string checkDate_r_H3_Value = "0";
            string checkDate_r_Sr90_Value = "0";
            string checkDate_r_Ni63_Value = "0";
            string checkDate_r_Pu241_Value = "0";
            string checkDate_r_I129_Value = "0";
            string checkDate_r_C14_Value = "0";
            string checkDate_r_TC99_Value = "0";
            string checkDate_r_Cm242_Value = "0";
            string checkDate_r_Total_Value = "0";

            //T45、T46的总活度
            string t45TotalActivity = "0";
            string t46TotalActivity = "0";
            string checkDateDecayTotalActivity = "0";  //近地表审查日废物活度
            string checkDateWasteTotalActivity = "0";  //∑D300a

            //固化体质量
            string giftWasteQuatity = (float.Parse(activityOrder.PackageWeight) * 1000 / 9.8 - float.Parse(activityOrder.EmptyBucketWeight) * 1000 / 9.8 - float.Parse(activityOrder.CoverWeight) * 1000 / 9.8).ToString();


            //原γ活度谱活度总和、计算谱活度总和
            string sumOriginalActivity = (activityOrder.DispiteEvalDetailVMList.Where(c => c.ElementClass == "1").Sum(c => c.OriginalActivity)).ToString();
            string sumCalcuSpectraActivity = (activityOrder.DispiteEvalDetailVMList.Where(c => c.ElementClass == "1").Sum(c => double.Parse(c.OriginalActivity.ToString()) * Math.Exp(-0.693 * days / double.Parse(c.HalfLife)))).ToString();
            if (sumCalcuSpectraActivity == "0") sumCalcuSpectraActivity = "1";

            //原废物活度 
            double originalTotalActivity = 0;
            List<DispiteEvalDetailVM> originalActivityList = new List<DispiteEvalDetailVM>();
            foreach (var item in activityOrder.DispiteEvalDetailVMList)
            {
                double originalActivity = double.Parse(item.OriginalWasteActivity) * Math.Exp(-0.693 * days / float.Parse(item.HalfLife));
                originalTotalActivity += originalActivity;

                //审查日废物活度
                if (days > 31)
                {
                    item.CheckdateActivity = (float.Parse(item.OriginalWasteActivity) * Math.Exp((-0.693 * (minusDays + days) / float.Parse(item.HalfLife)))).ToString();
                }
                else
                {
                    item.CheckdateActivity = (float.Parse(item.OriginalWasteActivity) * Math.Exp((-0.693 * (minusDays ) / float.Parse(item.HalfLife)))).ToString();
                }
                if (item.ElementName.ToUpper() == "PU239" || item.ElementName.ToUpper() == "PU-239")
                {
                    checkDate_Pu239_Value = item.CheckdateActivity;
                }
                sumCheckdateActivity = (float.Parse(sumCheckdateActivity) + float.Parse(item.CheckdateActivity)).ToString();

                if (item.ElementClass == "1")
                {
                    DispiteEvalDetailVM detail = new DispiteEvalDetailVM();
                    //计算谱、计算谱百分比
                    item.CalcuSpectraActivity = (float.Parse(item.OriginalActivity.ToString()) * Math.Exp(-0.693 * days / float.Parse(item.HalfLife))).ToString();
                    item.CalcuSpectraPercent = 100 * Convert.ToDecimal(item.CalcuSpectraActivity) / Convert.ToDecimal(sumCalcuSpectraActivity);

                    //初始活度
                    if (days > 31)
                    {
                        detail.InitialActivity = (10 * item.CalcuSpectraPercent * decimal.Parse(activityOrder.TransferPara) * decimal.Parse(activityOrder.AvgDoseRate)).ToString();
                    }
                    else
                    {
                        detail.InitialActivity = (10 * item.OriginalActivityPercent * decimal.Parse(activityOrder.TransferPara) * decimal.Parse(activityOrder.AvgDoseRate)).ToString();
                    }

                    if (days > 31)
                    {
                        detail.OriginalWasteActivity = (float.Parse(detail.InitialActivity) / Math.Exp(-0.693 * days / float.Parse(item.HalfLife))).ToString();
                    }
                    else
                    {
                        detail.OriginalWasteActivity = detail.InitialActivity;
                    }
                    originalActivityList.Add(detail);
                }
            }

            //废物初始活度总α、审查日废物活度总α、Z列总α
            string pu239CheckActivityUnit = "0";
            DispiteEvalDetailVM dispiteEvalDetail = list.Where(c => c.ElementName.ToUpper().Trim() == "PU239" || c.ElementName.ToUpper().Trim() == "PU-239").AsQueryable().ToList()[0];
            if (dispiteEvalDetail != null)
            {
                pu239CheckActivityUnit = dispiteEvalDetail.CheckdateActivity;
            }
            string pu241Scale = iScalefactorRepository.GetScaleFactorByElement("pu241");
            string pu238Scale = iScalefactorRepository.GetScaleFactorByElement("pu238");
            string pu240Scale = iScalefactorRepository.GetScaleFactorByElement("pu240");
            string pu244Scale = iScalefactorRepository.GetScaleFactorByElement("pu244");

            //逐行计算核素
            foreach (var item in activityOrder.DispiteEvalDetailVMList)
            {
                DispiteEvalDetailVM detail = new DispiteEvalDetailVM();
                detail.DetailId = Guid.NewGuid().ToString();
                detail.ElementId = item.ElementId;
                detail.HalfLife = item.HalfLife;
                detail.OriginalActivity = item.OriginalActivity;
                detail.OriginalActivityPercent = item.OriginalActivityPercent;

                //计算谱
                detail.CalcuSpectraPercent = decimal.Parse((100 * (double.Parse(item.OriginalActivity.ToString()) * Math.Exp(-0.693 * days / double.Parse(item.HalfLife))) / originalTotalActivity).ToString());

                //初始活度
                if (days > 31)
                {
                    detail.InitialActivity = (10 * item.CalcuSpectraPercent * decimal.Parse(activityOrder.TransferPara) * decimal.Parse(activityOrder.AvgDoseRate)).ToString();
                }
                else
                {
                    detail.InitialActivity = (10 * item.OriginalActivityPercent * decimal.Parse(activityOrder.TransferPara) * decimal.Parse(activityOrder.AvgDoseRate)).ToString();
                }

                //原废物活度 
                if (detail.ElementClass == "1")
                {
                    if (days > 31)
                    {
                        detail.OriginalWasteActivity = (float.Parse(detail.InitialActivity) / Math.Exp(-0.693 * (days) / float.Parse(item.HalfLife))).ToString();
                    }
                    else
                    {
                        detail.OriginalWasteActivity = (float.Parse(detail.InitialActivity) / Math.Exp(-0.693 / float.Parse(item.HalfLife))).ToString();
                    }
                }
                else if (detail.ElementClass == "0")
                {
                    //有疑问
                    if (item.ElementName.ToUpper() == "H-3" || item.ElementName.ToUpper() == "H3")
                    {
                        detail.OriginalWasteActivity = "0";
                    }
                    else
                    {
                        Scalefactor factor = WasteCheckBuilder.GetScaleValue(item.ElementId, scalefactorList);
                        if (factor != null)
                        {
                            string qtElementOriginalActovity = WasteCheckBuilder.GetOriginalActivity(factor.QuotaElementId, originalActivityList);
                            detail.OriginalWasteActivity = (decimal.Parse(qtElementOriginalActovity) * factor.Scalevalue).ToString();
                        }
                        else
                        {
                            detail.OriginalWasteActivity = "0";
                        }
                        if (item.ElementName.ToUpper() == "PU-239" || item.ElementName.ToUpper() == "PU239")
                        {
                            if (activityOrder.Damage == "0")
                            {
                                detail.OriginalWasteActivity = "0";
                            }
                            else
                            {
                                if (activityOrder.Damage != "1")
                                {
                                    detail.OriginalWasteActivity = "采样分析";
                                }
                            }
                        }
                    }
                }


                //审查日废物活度
                if (days > 31)
                {
                    detail.CheckdateActivity = (float.Parse(detail.OriginalWasteActivity) * Math.Exp((-0.693 * (minusDays + days ) / float.Parse(item.HalfLife)))).ToString();
                }
                else
                {
                    detail.CheckdateActivity = (float.Parse(detail.OriginalWasteActivity) * Math.Exp((-0.693 * (minusDays) / float.Parse(item.HalfLife)))).ToString();
                }
                //审查日废物活度百分比
                detail.CheckdateActivityPercent = decimal.Parse(detail.CheckdateActivity) / (decimal.Parse(sumCheckdateActivity) - decimal.Parse(checkDate_Pu239_Value) + decimal.Parse(activityOrder.TotalCheckActivityUnit));


                //审查日废物活度R列的数值
                if (item.ElementName.ToUpper() == "H3" || item.ElementName.ToUpper() == "H-3")
                {
                    checkDate_r_H3_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "CO60" || item.ElementName.ToUpper() == "CO-60")
                {
                    checkDate_r_Co60_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "FE59" || item.ElementName.ToUpper() == "FE-59")
                {
                    checkDate_r_Fe59_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "CS134" || item.ElementName.ToUpper() == "CS-134")
                {
                    checkDate_r_Cs134_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "SB124" || item.ElementName.ToUpper() == "SB-124")
                {
                    checkDate_r_Sb124_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "SN117M" || item.ElementName.ToUpper() == "SN-117M")
                {
                    checkDate_r_Sn117m_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "SN113" || item.ElementName.ToUpper() == "SN-113")
                {
                    checkDate_r_Sn113_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "AG110M" || item.ElementName.ToUpper() == "AG-110M")
                {
                    checkDate_r_Ag110m_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "RU106" || item.ElementName.ToUpper() == "RU-106")
                {
                    checkDate_r_Ru106_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "ZN65" || item.ElementName.ToUpper() == "ZN-65")
                {
                    checkDate_r_Zn65_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "ZR95" || item.ElementName.ToUpper() == "ZR-95")
                {
                    checkDate_r_Zr95_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "CR51" || item.ElementName.ToUpper() == "CR-51")
                {
                    checkDate_r_Cr51_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "MN54" || item.ElementName.ToUpper() == "MN-54")
                {
                    checkDate_r_Mn54_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "CO57" || item.ElementName.ToUpper() == "CO-57")
                {
                    checkDate_r_Co57_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "CO58" || item.ElementName.ToUpper() == "CO-58")
                {
                    checkDate_r_Co58_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "NB95" || item.ElementName.ToUpper() == "NB-95")
                {
                    checkDate_r_Nb95_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "CS137" || item.ElementName.ToUpper() == "CS-137")
                {
                    checkDate_r_Cr137_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "SR90" || item.ElementName.ToUpper() == "SR-90")
                {
                    checkDate_r_Sr90_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "NI63" || item.ElementName.ToUpper() == "NI-63")
                {
                    checkDate_r_Ni63_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "PU241" || item.ElementName.ToUpper() == "PU-241")
                {
                    checkDate_r_Pu241_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "I-129" || item.ElementName.ToUpper() == "I129")
                {
                    checkDate_r_I129_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "C14" || item.ElementName.ToUpper() == "C-14")
                {
                    checkDate_r_C14_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "TC99" || item.ElementName.ToUpper() == "TC-99")
                {
                    checkDate_r_TC99_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "CM242" || item.ElementName.ToUpper() == "CM-242")
                {
                    checkDate_r_Cm242_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                //审查日废物比活度
                detail.OriginalActivityPercent = decimal.Parse(detail.CheckdateActivity) / decimal.Parse(activityOrder.WasteVolumn.ToString());

                //Z列的活度
                detail.ZActivity = (float.Parse(detail.CheckdateActivity) * Math.Exp(-0.693 * (300 * 365) / float.Parse(item.HalfLife))).ToString();
                if (item.ElementName.ToUpper() == "PU-239" || item.ElementName.ToUpper() == "PU239")
                {
                    pu_239ZActivity = detail.ZActivity;
                }
                sumZActivity = (float.Parse(sumZActivity) + float.Parse(detail.ZActivity)).ToString();


                //添加T45、T46的活度、近地表审查日废物活度、审查日废物活度以及IAEA数值
                nuclearElementCondition.ElementName = item.ElementName.ToUpper().Trim();
                IQueryable<NuclearElementView> iqueryItem = iNuclearElementRepository.QueryList(nuclearElementCondition);
                if (iqueryItem != null && iqueryItem.Count() > 0)
                {
                    NuclearElementView elementItem = iqueryItem.ToList()[0];

                    //T45
                    t45TotalActivity = (float.Parse(t45TotalActivity) + float.Parse(detail.CheckdateActivity) / float.Parse(elementItem.LimitValue2.ToString())).ToString();

                    //T46
                    t46TotalActivity = (float.Parse(t46TotalActivity) + float.Parse(detail.CheckdateActivity) / float.Parse(elementItem.LimitValue3.ToString())).ToString();

                    //近地表审查日废物活度
                    string checkDateDecayActivity = "0";
                    if (elementItem.ElementName.ToUpper().Trim() == "NB94" || elementItem.ElementName.ToUpper().Trim() == "NB-94" || elementItem.ElementName.ToUpper().Trim() == "CM242" || elementItem.ElementName.ToUpper().Trim() == "CM-242")
                    {
                        checkDateDecayActivity = (float.Parse(detail.CheckdateActivity) * float.Parse(elementItem.DecayHeat.ToString()) / 37000).ToString();
                        checkDateDecayTotalActivity = (float.Parse(checkDateDecayTotalActivity) + float.Parse(detail.CheckdateActivity) * float.Parse(elementItem.DecayHeat.ToString()) / 37000).ToString();
                    }

                    //∑D300a
                    float halfLife = float.Parse(elementItem.HalfLife.ToString()) / 365;
                    checkDateWasteTotalActivity = (float.Parse(checkDateWasteTotalActivity) + float.Parse(checkDateDecayActivity) / float.Parse(giftWasteQuatity) * 45500000 * halfLife * (1 - Math.Exp(-0.693 * 300 / halfLife))).ToString();

                    if (elementItem.ElementName.ToUpper().Trim() == "NB94" || elementItem.ElementName.ToUpper().Trim() == "NB-94")
                    {
                        lower_Nb94_Value = elementItem.LowerValue.ToString();
                        iaea_Nb94_Value = elementItem.IaeaValue.ToString();
                        checkDate_Nb94_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "TC99" || elementItem.ElementName.ToUpper().Trim() == "TC-99")
                    {
                        lower_Tc99_Value = elementItem.LowerValue.ToString();
                        iaea_Tc99_Value = elementItem.IaeaValue.ToString();
                        checkDate_Tc99_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "C14" || elementItem.ElementName.ToUpper().Trim() == "C-14")
                    {
                        lower_C14_Value = elementItem.LowerValue.ToString();
                        iaea_C14_Value = elementItem.IaeaValue.ToString();
                        checkDate_C14_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "NI59" || elementItem.ElementName.ToUpper().Trim() == "NI-59")
                    {
                        lower_Ni59_Value = elementItem.LowerValue.ToString();
                        iaea_Ni59_Value = elementItem.IaeaValue.ToString();
                        checkDate_Ni59_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "NI63" || elementItem.ElementName.ToUpper().Trim() == "NI-63")
                    {
                        lower_Ni63_Value = elementItem.LowerValue.ToString();
                        iaea_Ni63_Value = elementItem.IaeaValue.ToString();
                        checkDate_Ni63_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "I129" || elementItem.ElementName.ToUpper().Trim() == "I-129")
                    {
                        lower_I129_Value = elementItem.LowerValue.ToString();
                        iaea_I129_Value = elementItem.IaeaValue.ToString();
                        checkDate_I129_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "SR90" || elementItem.ElementName.ToUpper().Trim() == "SR-90")
                    {
                        lower_Sr90_Value = elementItem.LowerValue.ToString();
                        iaea_Sr90_Value = elementItem.IaeaValue.ToString();
                        checkDate_Sr90_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "PU239" || elementItem.ElementName.ToUpper().Trim() == "PU-239")
                    {
                        lower_Pu239_Value = elementItem.LowerValue.ToString();
                        iaea_Pu239_Value = elementItem.IaeaValue.ToString();
                        checkDate_Pu239_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "PU241" || elementItem.ElementName.ToUpper().Trim() == "PU-241")
                    {
                        lower_Pu241_Value = elementItem.LowerValue.ToString();
                        iaea_Pu241_Value = elementItem.IaeaValue.ToString();
                        checkDate_Pu241_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "H3" || elementItem.ElementName.ToUpper().Trim() == "H-3")
                    {
                        lower_H3_Value = elementItem.LowerValue.ToString();
                        iaea_H3_Value = elementItem.IaeaValue.ToString();
                        checkDate_H3_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CS137" || elementItem.ElementName.ToUpper().Trim() == "CS-137")
                    {
                        lower_Cs137_Value = elementItem.LowerValue.ToString();
                        iaea_Cs137_Value = elementItem.IaeaValue.ToString();
                        checkDate_Cs137_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CR51" || elementItem.ElementName.ToUpper().Trim() == "CR-51")
                    {
                        lower_Cr51_Value = elementItem.LowerValue.ToString();
                        iaea_Cr51_Value = elementItem.IaeaValue.ToString();
                        checkDate_Cr51_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "MN54" || elementItem.ElementName.ToUpper().Trim() == "MN-54")
                    {
                        lower_Mn54_Value = elementItem.LowerValue.ToString();
                        iaea_Mn54_Value = elementItem.IaeaValue.ToString();
                        checkDate_Mn54_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CO57" || elementItem.ElementName.ToUpper().Trim() == "CO-57")
                    {
                        lower_Co57_Value = elementItem.LowerValue.ToString();
                        iaea_Co57_Value = elementItem.IaeaValue.ToString();
                        checkDate_Co57_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CO58" || elementItem.ElementName.ToUpper().Trim() == "CO-58")
                    {
                        lower_Co58_Value = elementItem.LowerValue.ToString();
                        iaea_Co58_Value = elementItem.IaeaValue.ToString();
                        checkDate_Co58_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CO60" || elementItem.ElementName.ToUpper().Trim() == "CO-60")
                    {
                        lower_Co60_Value = elementItem.LowerValue.ToString();
                        iaea_Co60_Value = elementItem.IaeaValue.ToString();
                        checkDate_Co60_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "ZN65" || elementItem.ElementName.ToUpper().Trim() == "ZN-65")
                    {
                        lower_Zn65_Value = elementItem.LowerValue.ToString();
                        iaea_Zn65_Value = elementItem.IaeaValue.ToString();
                        checkDate_Zn65_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "NB95" || elementItem.ElementName.ToUpper().Trim() == "NB-95")
                    {
                        lower_Nb95_Value = elementItem.LowerValue.ToString();
                        iaea_Nb95_Value = elementItem.IaeaValue.ToString();
                        checkDate_Nb95_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "ZR95" || elementItem.ElementName.ToUpper().Trim() == "ZR-95")
                    {
                        lower_Zr95_Value = elementItem.LowerValue.ToString();
                        iaea_Zr95_Value = elementItem.IaeaValue.ToString();
                        checkDate_Zr95_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "RU106" || elementItem.ElementName.ToUpper().Trim() == "RU-106")
                    {
                        lower_Ru106_Value = elementItem.LowerValue.ToString();
                        iaea_Ru106_Value = elementItem.IaeaValue.ToString();
                        checkDate_Ru106_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "AG110M" || elementItem.ElementName.ToUpper().Trim() == "AG-110M")
                    {
                        lower_Ag110m_Value = elementItem.LowerValue.ToString();
                        iaea_Ag110m_Value = elementItem.IaeaValue.ToString();
                        checkDate_Ag110m_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "SN113" || elementItem.ElementName.ToUpper().Trim() == "SN-113")
                    {
                        lower_Sn113_Value = elementItem.LowerValue.ToString();
                        iaea_Sn113_Value = elementItem.IaeaValue.ToString();
                        checkDate_Sn113_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "SB124" || elementItem.ElementName.ToUpper().Trim() == "SB-124")
                    {
                        lower_Sb124_Value = elementItem.LowerValue.ToString();
                        iaea_Sb124_Value = elementItem.IaeaValue.ToString();
                        checkDate_Sb124_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CM242" || elementItem.ElementName.ToUpper().Trim() == "CM-242")
                    {
                        lower_Cm242_Value = elementItem.LowerValue.ToString();
                        iaea_Cm242_Value = elementItem.IaeaValue.ToString();
                        checkDate_Cm242_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "FE59" || elementItem.ElementName.ToUpper().Trim() == "FE-59")
                    {
                        lower_Fe59_Value = elementItem.LowerValue.ToString();
                        iaea_Fe59_Value = elementItem.IaeaValue.ToString();
                        checkDate_Fe59_Value = detail.CheckdateActivity.ToString();
                    }
                }

                //添加一行数据
                list.Add(detail);
            }

            if (activityOrder.Damage == "0")
            {
                //废物初始活度总α
                activityOrder.TotalOriginalActivity = "0";

                //审查日废物活度总α
                activityOrder.TotalCheckActivityUnit = "0";

                //Z列总α
                activityOrder.TotalZActivity = "0";
            }
            else if (activityOrder.Damage == "1")
            {
                //废物初始活度总α
                pu244Scale = iScalefactorRepository.GetScaleFactorByElement("pu244");
                activityOrder.TotalOriginalActivity = (float.Parse(pu_239Original) + float.Parse(co_60Original) * (float.Parse(pu241Scale) + float.Parse(pu238Scale) + float.Parse(pu240Scale) + float.Parse(pu244Scale))).ToString();

                //审查日废物活度总α
                activityOrder.TotalCheckActivityUnit = (float.Parse(pu239CheckActivityUnit) + float.Parse(co_60Original) * float.Parse(pu241Scale) * Math.Exp(-0.693 * (minusDays) / 365 / 432) + float.Parse(co_60Original) * float.Parse(pu238Scale) * Math.Exp(-0.693 * (minusDays) / 365 / 87.7)
                    + float.Parse(co_60Original) * float.Parse(pu240Scale) * Math.Exp(-0.693 * (minusDays) / 365 / 6550) + float.Parse(co_60Original) * float.Parse(pu244Scale) * Math.Exp(-0.693 * (minusDays) / 365 / 18.1)).ToString();
                checkDate_r_Total_Value = (float.Parse(activityOrder.TotalCheckActivityUnit) * 1000000 / float.Parse(giftWasteQuatity) / 1000).ToString();

                //Z列总α
                activityOrder.TotalZActivity = (float.Parse(pu_239ZActivity) + float.Parse(co_60Original) * float.Parse(pu241Scale) * Math.Exp(-0.693 * (minusDays + 300 * 365) / 365 / 432) + float.Parse(co_60Original) * float.Parse(pu238Scale) * Math.Exp(-0.693 * (minusDays + 300 * 365) / 365 / 87.7)
                    + float.Parse(co_60Original) * float.Parse(pu240Scale) * Math.Exp(-0.693 * (minusDays + 300 * 365) / 365 / 6550) + float.Parse(co_60Original) * float.Parse(pu244Scale) * Math.Exp(-0.693 * (minusDays + 300 * 365) / 365 / 18.1)).ToString();
            }
            else
            {
                //审查日废物活度总α
                activityOrder.TotalOriginalActivity = "采样分析";

                //审查日废物活度总α
                activityOrder.TotalCheckActivityUnit = "采样分析";

                //Z列总α
                activityOrder.TotalZActivity = "采样分析";
            }
            //总活度
            activityOrder.TotalActivity = ((float.Parse(sumCheckdateActivity) - float.Parse(pu239CheckActivityUnit) + float.Parse(activityOrder.TotalCheckActivityUnit)) / 1000).ToString();

            //衰变300年
            activityOrder.DecayThreeHundred = ((float.Parse(sumZActivity) - float.Parse(pu_239ZActivity) + float.Parse(activityOrder.TotalZActivity)) / 1000).ToString();
            activityOrder.DecayThreeHundredValue = (float.Parse(t45TotalActivity) / 1000000 / float.Parse(giftWasteQuatity)).ToString();

            //归类
            string z46Activity = ((float.Parse(checkDate_Cr51_Value) / float.Parse(iaea_Cr51_Value) + float.Parse(checkDate_Mn54_Value) / float.Parse(iaea_Mn54_Value) + float.Parse(checkDate_Co57_Value) / float.Parse(iaea_Co57_Value)
                + float.Parse(checkDate_Co58_Value) / float.Parse(iaea_Co58_Value) + float.Parse(checkDate_Fe59_Value) / float.Parse(iaea_Fe59_Value) + float.Parse(checkDate_Co60_Value) / float.Parse(iaea_Co60_Value) + float.Parse(checkDate_Nb95_Value) / float.Parse(iaea_Nb95_Value) + float.Parse(checkDate_Zn65_Value) / float.Parse(iaea_Zn65_Value)
                + float.Parse(checkDate_Zr95_Value) / float.Parse(iaea_Zr95_Value) + float.Parse(checkDate_Ru106_Value) / float.Parse(iaea_Ru106_Value) + float.Parse(checkDate_Ag110m_Value) / float.Parse(iaea_Ag110m_Value)
                + float.Parse(checkDate_Sn113_Value) / float.Parse(iaea_Sn113_Value) + float.Parse(checkDate_Sb124_Value) / float.Parse(iaea_Sb124_Value) + float.Parse(checkDate_Cm242_Value) / float.Parse(iaea_Cm242_Value)) * 1000 / float.Parse(giftWasteQuatity)).ToString();
            string r42 = (float.Parse(activityOrder.TotalCheckActivityUnit) * 1000000 / float.Parse(giftWasteQuatity) / 1000).ToString();
            string mathExp = (Math.Exp(-0.693 * (minusDays) / 365 / 18.1)).ToString();
            float value1 = float.Parse(wasteLimit1) - (float.Parse(r42) - float.Parse(co_60Original) * float.Parse(pu244Scale) * float.Parse(mathExp)) * 1000000 / float.Parse(giftWasteQuatity) / 1000;
            float value2 = float.Parse(activityOrder.TotalActivity) * 1000000000 / float.Parse(giftWasteQuatity) - float.Parse(highWasteLimit1);
            float value3 = float.Parse(activityOrder.TotalActivity) * 1000000000 / float.Parse(giftWasteQuatity) - float.Parse(middleWasteLimit1);
            if (value1 > 0)
            {
                if (value2 > 0)
                {
                    activityOrder.Classify = "高放固体废物";
                }
                else
                {
                    if (value3 > 0)
                    {
                        activityOrder.Classify = "中放固体废物";
                    }
                    else
                    {
                        if (float.Parse(z46Activity) - 1 < 0)
                        {
                            activityOrder.Classify = "豁免废物";
                        }
                        else
                        {
                            activityOrder.Classify = "低放固体废物";
                        }
                    }
                }
            }
            else
            {
                activityOrder.Classify = "α废物";
            }

            //归类等级
            if (float.Parse(t45TotalActivity) - 2 > 0)
            {
                activityOrder.ClassifyValue = "非低比活度物质";
            }
            else
            {
                if (float.Parse(t45TotalActivity) - 0.1 > 0)
                {
                    activityOrder.ClassifyValue = "LSA-III";
                }
                else
                {
                    if (float.Parse(t46TotalActivity) - 1 > 0)
                    {
                        activityOrder.ClassifyValue = "LSA-II";
                    }
                    else
                    {
                        if (float.Parse(t46TotalActivity) * 30 - 1 > 0)
                        {
                            activityOrder.ClassifyValue = "LSA-I";
                        }
                        else
                        {
                            activityOrder.ClassifyValue = "豁免运输物质";
                        }
                    }
                }
            }

            //近地表处置
            activityOrder.SurfaceClassValue2 = t46TotalActivity;

            float surfaceClassValue1 = float.Parse(checkDate_r_Cr137_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn3(supportSurfaceDealList, "CS137"))
                + float.Parse(checkDate_r_Sr90_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn3(supportSurfaceDealList, "SR90"))
                + float.Parse(checkDate_r_Ni63_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn3(supportSurfaceDealList, "NI63"));

            float surfaceClassValue2 = float.Parse(checkDate_r_Pu241_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn3(supportSurfaceDealList, "PU241"))
             + float.Parse(checkDate_r_Cm242_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "CM242"))
             + float.Parse(checkDate_r_Pu241_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "PU241"))
             + float.Parse(checkDate_r_Total_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "α>5 A"))
             + float.Parse(checkDate_r_I129_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "I129"))
             + float.Parse(checkDate_r_C14_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "C14"))
             + float.Parse(checkDate_r_TC99_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "TC99"));

            float surfaceClassValue3 = float.Parse(checkDate_r_Cm242_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn3(supportSurfaceDealList, "CM242"))
                + float.Parse(checkDate_r_Pu241_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "PU241"))
                + float.Parse(checkDate_r_Total_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "α>5 A"))
                + float.Parse(checkDate_r_I129_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "I129"))
                + float.Parse(checkDate_r_C14_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "C14"))
             + float.Parse(checkDate_r_TC99_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "TC99"));

            float surfaceClassValue4 = float.Parse(checkDate_r_Cr137_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "CS137"))
                + float.Parse(checkDate_r_Sr90_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "SR90"))
                + float.Parse(checkDate_r_Ni63_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "NI63"));

            float surfaceClassValue5 = (float.Parse(checkDate_r_Cr51_Value) + float.Parse(checkDate_r_Mn54_Value) + float.Parse(checkDate_r_Co57_Value)
                + float.Parse(checkDate_r_Co58_Value) + float.Parse(checkDate_r_Fe59_Value) + float.Parse(checkDate_r_Nb95_Value) + float.Parse(checkDate_r_Zr95_Value)
                + float.Parse(checkDate_r_Zn65_Value) + float.Parse(checkDate_r_Ru106_Value) + float.Parse(checkDate_r_Ag110m_Value) + float.Parse(checkDate_r_Sn113_Value)
                + float.Parse(checkDate_r_Sn117m_Value) + float.Parse(checkDate_r_Sb124_Value) + float.Parse(checkDate_r_Cs134_Value)) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "<5E"))
                + float.Parse(checkDate_r_Co60_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "CO60")) + float.Parse(checkDate_r_Cr137_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "CS137"))
                + float.Parse(checkDate_r_H3_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "H3")) + float.Parse(checkDate_r_Sr90_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "SR90"))
                + float.Parse(checkDate_r_Ni63_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "NI63"));

            float z47Activity = (float.Parse(checkDate_Cr51_Value) / float.Parse(lower_Cr51_Value) + float.Parse(checkDate_Mn54_Value) / float.Parse(lower_Mn54_Value) + float.Parse(checkDate_Co57_Value) / float.Parse(lower_Co57_Value)
                + float.Parse(checkDate_Co58_Value) / float.Parse(lower_Co58_Value) + float.Parse(checkDate_Fe59_Value) / float.Parse(lower_Fe59_Value) + float.Parse(checkDate_Co60_Value) / float.Parse(lower_Co60_Value)
                + float.Parse(checkDate_Nb95_Value) / float.Parse(lower_Nb95_Value) + float.Parse(checkDate_Zr95_Value) / float.Parse(lower_Zr95_Value) + float.Parse(checkDate_Zn65_Value) / float.Parse(lower_Zn65_Value)
                + float.Parse(checkDate_Ru106_Value) / float.Parse(lower_Ru106_Value) + float.Parse(checkDate_Ag110m_Value) / float.Parse(lower_Ag110m_Value) + float.Parse(checkDate_Sn113_Value) / float.Parse(lower_Sn113_Value)
                + float.Parse(checkDate_Sb124_Value) / float.Parse(lower_Sb124_Value) + float.Parse(checkDate_Cs134_Value) / float.Parse(lower_Cs134_Value) + float.Parse(checkDate_H3_Value) / float.Parse(lower_H3_Value)
            + float.Parse(checkDate_Pu241_Value) / float.Parse(lower_Pu241_Value) + float.Parse(checkDate_Pu239_Value) / float.Parse(lower_Pu239_Value) + float.Parse(checkDate_Sr90_Value) / float.Parse(lower_Sr90_Value)
            + float.Parse(checkDate_I129_Value) / float.Parse(lower_I129_Value) + float.Parse(checkDate_Ni63_Value) / float.Parse(lower_Ni63_Value) + float.Parse(checkDate_Ni59_Value) / float.Parse(lower_Ni59_Value)
            + float.Parse(checkDate_C14_Value) / float.Parse(lower_C14_Value) + float.Parse(checkDate_Tc99_Value) / float.Parse(lower_Tc99_Value) + float.Parse(checkDate_Nb94_Value) / float.Parse(lower_Nb94_Value)
            + float.Parse(activityOrder.TotalCheckActivityUnit) / float.Parse(lower_Cm242_Value)) * 1000 / float.Parse(giftWasteQuatity);

            if (surfaceClassValue1 < 1 && surfaceClassValue2 < 1)
            {
                if (surfaceClassValue3 < 0.1)
                {
                    if (surfaceClassValue4 < 1)
                    {
                        if (surfaceClassValue5 < 1)
                        {
                            if (z47Activity - 1 < 0)
                            {
                                if (float.Parse(z46Activity) - 1 < 0)
                                {
                                    activityOrder.SurfaceClass = "可解控类";
                                }
                                else
                                {
                                    activityOrder.SurfaceClass = "极低放类";
                                }
                            }
                            else
                            {
                                activityOrder.SurfaceClass = "A类";
                            }
                        }
                        else
                        {
                            activityOrder.SurfaceClass = "B类";
                        }
                    }
                    else
                    {
                        activityOrder.SurfaceClass = "C类";
                    }
                }
                else
                {
                    activityOrder.SurfaceClass = "C类";
                }
            }
            else
            {
                activityOrder.SurfaceClass = "超C类标准";
            }

            //衰变热
            activityOrder.DecayHeat = (float.Parse(checkDateDecayTotalActivity) / float.Parse(activityOrder.WasteVolumn.ToString()) / 1000).ToString();

            //∑D300a
            activityOrder.CalcuThreeHundred = checkDateWasteTotalActivity;
            return model;
        }
    }
}