﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   WasteCheckBuilder.cs
 *   描    述   ：   废物货包审核查询类
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-28 18:45:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-28 18:45:00    1.0.0.0     PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Domain.DomainObjects.View.Support;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModelBuilder
{
    public class MetelActivityCalcuBuilder
    {
        CommonHelper commonHelper = new CommonHelper();
        /// <summary>
        /// 得到400L金属桶的放射性特性评估验算内容
        /// </summary>
        /// <param name="activityOrder">活度计算单</param>
        /// <returns></returns>
        public static ActivityOrder GetMetelBucketCalcuElement(ActivityOrder activityOrder)
        {
            //比例因子信息
            IScalefactorRepository iScalefactorRepository = ServiceLocator.Current.GetInstance<IScalefactorRepository>();
            string fatorType = activityOrder.FactorType;
            if (string.IsNullOrEmpty(fatorType))
            {
                fatorType = "CGN";
            }
            IQueryable<Scalefactor> iqueryScalefactor = iScalefactorRepository.GetAll().AsQueryable().Where(c => c.WasteTypeId == activityOrder.WasteTypeId && c.FactorType.ToUpper().Trim() == fatorType.ToUpper().Trim());

            //核素信息
            INuclearElementRepository iNuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = iNuclearElementRepository.GetAll().AsQueryable();

            List<Scalefactor> scalefactorList = new List<Scalefactor>();
            var query = from s in iqueryScalefactor
                        join e in iqueryNuclearElement
                        on s.DtmElementId equals e.ElementId
                        select s;
            if (query.Count() > 0)
            {
                scalefactorList = query.ToList();
            }

            //实例化近地表处置参数设置
            SurfaceDealCondition surfaceDealCondition = new SurfaceDealCondition();
            ISupportSurfaceDealRepository iSupportSurfaceDealRepository = ServiceLocator.Current.GetInstance<ISupportSurfaceDealRepository>();
            List<SurfaceDealView> supportSurfaceDealList = iSupportSurfaceDealRepository.QueryList(surfaceDealCondition).ToList();
            if (supportSurfaceDealList == null)
            {
                supportSurfaceDealList = new List<SurfaceDealView>();
            }

            //得到α废物的限制1
            string wasteLimit1 = "0";
            NuclearElementCondition nuclearElementCondition = new NuclearElementCondition();
            nuclearElementCondition.ElementName = "α废物";
            IQueryable<NuclearElementView> iqueryLimit1 = iNuclearElementRepository.QueryList(nuclearElementCondition);
            if (iqueryLimit1 != null && iqueryLimit1.Count() > 0)
            {
                Nullable<decimal> limit1Value = iqueryLimit1.ToList()[0].LimitValue1;
                wasteLimit1 = limit1Value.ToString();
            }

            //得到高放固体废物限制1
            string highWasteLimit1 = "0";
            nuclearElementCondition.ElementName = "高放固体废物";
            iqueryLimit1 = iNuclearElementRepository.QueryList(nuclearElementCondition);
            if (iqueryLimit1 != null && iqueryLimit1.Count() > 0)
            {
                Nullable<decimal> limit1Value = iqueryLimit1.ToList()[0].LimitValue1;
                highWasteLimit1 = limit1Value.ToString();
            }

            //得到中放固体废物限制1
            string middleWasteLimit1 = "0";
            nuclearElementCondition.ElementName = "中放固体废物";
            iqueryLimit1 = iNuclearElementRepository.QueryList(nuclearElementCondition);
            if (iqueryLimit1 != null && iqueryLimit1.Count() > 0)
            {
                Nullable<decimal> limit1Value = iqueryLimit1.ToList()[0].LimitValue1;
                middleWasteLimit1 = limit1Value.ToString();
            }

            //得到低放固体废物限制1
            string lowerWasteLimit1 = "0";
            nuclearElementCondition.ElementName = "低放固体废物";
            iqueryLimit1 = iNuclearElementRepository.QueryList(nuclearElementCondition);
            if (iqueryLimit1 != null && iqueryLimit1.Count() > 0)
            {
                Nullable<decimal> limit1Value = iqueryLimit1.ToList()[0].LimitValue1;
                lowerWasteLimit1 = limit1Value.ToString();
            }

            //得到处置场限值信息
            List<SupportDispiteLimit> supportDispiteLimitList = new List<SupportDispiteLimit>();
            ISupportDispiteLimitRepository supportDispiteLimitRepository = ServiceLocator.Current.GetInstance<ISupportDispiteLimitRepository>();
            IQueryable<SupportDispiteLimit> iquerySupportDispiteLimit = supportDispiteLimitRepository.GetAll().AsQueryable().Where(c=>c.Status=="1");
            if (iquerySupportDispiteLimit != null && iquerySupportDispiteLimit.Count() > 0)
            {
                supportDispiteLimitList = iquerySupportDispiteLimit.ToList();
            }

            //实例化处置场废物验算实体
            ActivityOrder model = new ActivityOrder();

            //与废物产生日间隔(d)=废物固化日期-废物产生日期
            DateTime wasteGiftDate = Convert.ToDateTime(activityOrder.WasteGiftDate);
            DateTime wasteProduceDate = (activityOrder.WasteProduceDate == null || activityOrder.WasteProduceDate=="" ? wasteGiftDate : Convert.ToDateTime(activityOrder.WasteProduceDate));
            double days = (wasteGiftDate - wasteProduceDate).TotalDays;

            //与初始活度计算时间差(d)=放射性检查评估日期：-废物固化日期
            DateTime activityEvalDate = Convert.ToDateTime(activityOrder.ActivityEvalDate);
            float minusDays = float.Parse((activityEvalDate - wasteGiftDate).TotalDays.ToString());

            //逐行计算核素活度信息
            List<DispiteEvalDetailVM> allActivitylist = new List<DispiteEvalDetailVM>();
            string pu_239Original = "0";
            string co_60Original = "0";

            //审查日废物活度总和 
            string sumCheckdateActivity = "0";
            string sumZActivity = "0";
            string pu_239ZActivity = "0";

            //IAEA以及极低放数值
            string iaea_Cr51_Value = "1";
            string iaea_Mn54_Value = "1";
            string iaea_Co57_Value = "1";
            string iaea_Co58_Value = "1";
            string iaea_Co60_Value = "1";
            string iaea_Zn65_Value = "1";
            string iaea_Nb95_Value = "1";
            string iaea_Zr95_Value = "1";
            string iaea_Ru106_Value = "1";
            string iaea_Ag110m_Value = "1";
            string iaea_Sn113_Value = "1";
            string iaea_Sb124_Value = "1";
            string iaea_Cm242_Value = "1";
            string iaea_Fe59_Value = "1";
            string iaea_Cs137_Value = "1";
            string iaea_H3_Value = "1";
            string iaea_Pu241_Value = "1";
            string iaea_Pu239_Value = "1";
            string iaea_Sr90_Value = "1";
            string iaea_I129_Value = "1";
            string iaea_Ni63_Value = "1";
            string iaea_Ni59_Value = "1";
            string iaea_C14_Value = "1";
            string iaea_Tc99_Value = "1";
            string iaea_Nb94_Value = "1";

            string lower_Cr51_Value = "1";
            string lower_Mn54_Value = "1";
            string lower_Co57_Value = "1";
            string lower_Co58_Value = "1";
            string lower_Co60_Value = "1";
            string lower_Zn65_Value = "1";
            string lower_Nb95_Value = "1";
            string lower_Zr95_Value = "1";
            string lower_Ru106_Value = "1";
            string lower_Ag110m_Value = "1";
            string lower_Sn113_Value = "1";
            string lower_Sb124_Value = "1";
            string lower_Cm242_Value = "1";
            string lower_Fe59_Value = "1";
            string lower_Cs134_Value = "1";
            string lower_Cs137_Value = "1";
            string lower_H3_Value = "1";
            string lower_Pu241_Value = "1";
            string lower_Pu239_Value = "1";
            string lower_Sr90_Value = "1";
            string lower_I129_Value = "1";
            string lower_Ni63_Value = "1";
            string lower_Ni59_Value = "1";
            string lower_C14_Value = "1";
            string lower_Tc99_Value = "1";
            string lower_Nb94_Value = "1";

            //审查日废物活度
            string checkDate_Cr51_Value = "0";
            string checkDate_Mn54_Value = "0";
            string checkDate_Co57_Value = "0";
            string checkDate_Co58_Value = "0";
            string checkDate_Co60_Value = "0";
            string checkDate_Zn65_Value = "0";
            string checkDate_Nb95_Value = "0";
            string checkDate_Zr95_Value = "0";
            string checkDate_Ru106_Value = "0";
            string checkDate_Ag110m_Value = "0";
            string checkDate_Sn113_Value = "0";
            string checkDate_Sb124_Value = "0";
            string checkDate_Cm242_Value = "0";
            string checkDate_Fe59_Value = "0";
            string checkDate_Cs134_Value = "0";
            string checkDate_Cs137_Value = "0";
            string checkDate_H3_Value = "0";
            string checkDate_Pu241_Value = "0";
            string checkDate_Pu239_Value = "0";
            string checkDate_Sr90_Value = "0";
            string checkDate_I129_Value = "0";
            string checkDate_Ni63_Value = "0";
            string checkDate_Ni59_Value = "0";
            string checkDate_C14_Value = "0";
            string checkDate_Tc99_Value = "0";
            string checkDate_Nb94_Value = "0";

            //审查日废物活度R列的数值
            string checkDate_r_Cr51_Value = "0";
            string checkDate_r_Mn54_Value = "0";
            string checkDate_r_Co57_Value = "0";
            string checkDate_r_Co58_Value = "0";
            string checkDate_r_Co60_Value = "0";
            string checkDate_r_Fe59_Value = "0";
            string checkDate_r_Nb95_Value = "0";
            string checkDate_r_Zr95_Value = "0";
            string checkDate_r_Zn65_Value = "0";
            string checkDate_r_Ru106_Value = "0";
            string checkDate_r_Ag110m_Value = "0";
            string checkDate_r_Sn113_Value = "0";
            string checkDate_r_Sn117m_Value = "0";
            string checkDate_r_Sb125_Value = "0";
            string checkDate_r_Cs134_Value = "0";
            string checkDate_r_Cr137_Value = "0";
            string checkDate_r_H3_Value = "0";
            string checkDate_r_Sr90_Value = "0";
            string checkDate_r_Ni63_Value = "0";
            string checkDate_r_Pu241_Value = "0";
            string checkDate_r_I129_Value = "0";
            string checkDate_r_C14_Value = "0";
            string checkDate_r_TC99_Value = "0";
            string checkDate_r_Cm242_Value = "0";
            string checkDate_r_Total_Value = "0";

            //核素活度与A1限值比值组成元素
            string A1_Cr51_Value = "0";
            string A1_Mn54_Value = "0";
            string A1_Co57_Value = "0";
            string A1_Co58_Value = "0";
            string A1_Co60_Value = "0";
            string A1_Fe59_Value = "0";
            string A1_Nb95_Value = "0";
            string A1_Nb94_Value = "0";
            string A1_Cd109_Value = "0";
            string A1_Zr95_Value = "0";
            string A1_Zn65_Value = "0";
            string A1_Ag110m_Value = "0";
            string A1_Sn113_Value = "0";
            string A1_Sn117m_Value = "0";
            string A1_Sb125_Value = "0";
            string A1_Cs134_Value = "0";
            string A1_Cs137_Value = "0";
            string A1_Sr90_Value = "0";
            string A1_Ni63_Value = "0";
            string A1_Pu241_Value = "0";
            string A1_Pu239_Value = "0";
            string A1_C14_Value = "0";
            string A1_TC99_Value = "0";
            string A1_Cm242_Value = "0";
            string A1_Total_Value = "0";

            //处置场限值
            string limit_CS137_Value = "0";
            string limit_SR90_Value = "0";
            string limit_NI63_Value = "0";
            string limit_C14_Value = "0";
            string limit_CO60_Value = "0";
            string total_Limit_Value = "0";

            //T45、T46的总活度
            string t45TotalActivity = "0";
            string t46TotalActivity = "0";
            string checkDateDecayTotalActivity = "0";  //近地表审查日废物活度
            string checkDateWasteTotalActivity = "0";  //∑D300a

            //固化体质量
            string giftWasteQuatity = (float.Parse(string.IsNullOrEmpty(activityOrder.PackageWeight) ? "0" : activityOrder.PackageWeight) * 1000 / 9.8 - float.Parse(string.IsNullOrEmpty(activityOrder.EmptyBucketWeight) ? "0" : activityOrder.EmptyBucketWeight) * 1000 / 9.8 - float.Parse(string.IsNullOrEmpty(activityOrder.CoverWeight) ? "0" : activityOrder.CoverWeight) * 1000 / 9.8).ToString();
            if (giftWasteQuatity == "0") giftWasteQuatity = "1";

            //获取所有的可测核素的原废物活度
            string sumOriginalActivity = (activityOrder.DispiteEvalDetailVMList.Where(c => c.ElementClass == "1").Sum(c => c.OriginalActivity)).ToString();
            string sumCalcuSpectraActivity = (activityOrder.DispiteEvalDetailVMList.Where(c => c.ElementClass == "1").Sum(c => double.Parse(c.OriginalActivity.ToString()) * Math.Exp(-0.693 * days / double.Parse(c.HalfLife)))).ToString();

            //逐行计算核素
            if (sumCalcuSpectraActivity == "0") sumCalcuSpectraActivity = "1";

            //得到CO60、CS137的核素ID
            string co60ElementId = "0";
            string cs137ElementId = "0";
            List<DispiteEvalDetailVM> co60List=activityOrder.DispiteEvalDetailVMList.Where(c => c.ElementName.ToUpper() == "CO60" || c.ElementName.ToUpper() =="CO-60").ToList();
            List<DispiteEvalDetailVM> cs137List = activityOrder.DispiteEvalDetailVMList.Where(c => c.ElementName.ToUpper() == "CS137" || c.ElementName.ToUpper() == "CS-137").ToList();
            if (co60List != null && co60List.Count > 0)
            {
                co60ElementId = co60List[0].ElementId;
            }
            if (cs137List != null && cs137List.Count > 0)
            {
                cs137ElementId = cs137List[0].ElementId;
            }

            foreach (var item in activityOrder.DispiteEvalDetailVMList)
            {
                DispiteEvalDetailVM detail = new DispiteEvalDetailVM();
                detail.DetailId = Guid.NewGuid().ToString();
                detail.ElementName = item.ElementName;
                detail.ElementClass = item.ElementClass;
                detail.ElementId = item.ElementId;
                detail.HalfLife = item.HalfLife;
                detail.OriginalActivity = Convert.ToDecimal(String.Format("{0:0.000000}",item.OriginalActivity));
                detail.OriginalActivityPercent = item.OriginalActivityPercent;
                detail.OriginalWasteActivity = item.OriginalWasteActivity;

                //得到核素实体
                NuclearElement nuclearElement=iNuclearElementRepository.Get(item.ElementId);
                if (nuclearElement == null) nuclearElement = new NuclearElement();

                //审查日废物活度
                if (days > 31)
                {
                    try
                    {
                        detail.CheckdateActivity = String.Format("{0:0.000000}",(float.Parse(detail.OriginalWasteActivity) * Math.Exp((-0.693 * (minusDays + days) / float.Parse(item.HalfLife)))).ToString());
                    }
                    catch
                    {
                        detail.CheckdateActivity = "0";
                    }
                }
                else
                {
                    detail.CheckdateActivity = String.Format("{0:0.000000}",(float.Parse(detail.OriginalWasteActivity) * Math.Exp((-0.693 * (minusDays ) / float.Parse(item.HalfLife)))).ToString());
                }
                sumCheckdateActivity = String.Format("{0:0.000000}",(float.Parse(sumCheckdateActivity) + float.Parse(detail.CheckdateActivity)).ToString());

                //审查日废物活度百分比
                try
                {
                    detail.CheckdateActivityPercent = decimal.Parse(detail.CheckdateActivity) / (decimal.Parse(sumCheckdateActivity) - decimal.Parse(checkDate_Pu239_Value) + decimal.Parse(activityOrder.TotalCheckActivityUnit));
                }
                catch
                {
                    detail.CheckdateActivityPercent = 0;
                }

                //审查日废物比活度 
                try
                {
                    if (item.ElementName.ToUpper() == "PU241" || item.ElementName.ToUpper() == "PU-241" || item.ElementName.ToUpper() == "PU239" || item.ElementName.ToUpper() == "PU-239"
                        || item.ElementName.ToUpper() == "NB94" || item.ElementName.ToUpper() == "NB-94" || item.ElementName.ToUpper() == "CM242" || item.ElementName.ToUpper() == "CM-242"
                        )
                    {
                        detail.IsSpecialActivityUnit = true;
                        detail.CheckdateActivityUnit = (float.Parse(detail.CheckdateActivity) * 1000000 / float.Parse(giftWasteQuatity) / 1000).ToString();
                    }
                    else
                    {
                        detail.IsSpecialActivityUnit = false;
                        detail.CheckdateActivityUnit = String.Format("{0:0.000000}",(float.Parse(detail.CheckdateActivity)/float.Parse(activityOrder.WasteVolumn.ToString())).ToString());
                    }
                }
                catch
                {
                    detail.CheckdateActivityUnit = "0";
                }


                SupportDispiteLimit co60DispiteLimit = GetSupportDispiteLimit(supportDispiteLimitList, co60ElementId, activityOrder.DispitePositionId);
                SupportDispiteLimit cs137DispiteLimit = GetSupportDispiteLimit(supportDispiteLimitList, cs137ElementId, activityOrder.DispitePositionId);
                //审查日废物活度R列的数值
                if (item.ElementName.ToUpper() == "H3" || item.ElementName.ToUpper() == "H-3")
                {
                    checkDate_r_H3_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "CO60" || item.ElementName.ToUpper() == "CO-60")
                {
                    if (cs137DispiteLimit.SpecificActivity != 0)
                    {
                        limit_CO60_Value = (double.Parse(detail.CheckdateActivityUnit) / (cs137DispiteLimit.SpecificActivity * 80000 / Math.Exp(-0.693 * 150 * 365 / double.Parse(detail.HalfLife)) / 1000000)).ToString();
                    
                    }
                    checkDate_r_Co60_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Co60_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "FE59" || item.ElementName.ToUpper() == "FE-59")
                {
                    checkDate_r_Fe59_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Fe59_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "CS134" || item.ElementName.ToUpper() == "CS-134")
                {
                    checkDate_r_Cs134_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Cs134_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "SB125" || item.ElementName.ToUpper() == "SB-125")
                {
                    checkDate_r_Sb125_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Sb125_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "SN117M" || item.ElementName.ToUpper() == "SN-117M")
                {
                    checkDate_r_Sn117m_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Sn117m_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "SN113" || item.ElementName.ToUpper() == "SN-113")
                {
                    checkDate_r_Sn113_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Sn113_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "AG110M" || item.ElementName.ToUpper() == "AG-110M")
                {
                    checkDate_r_Ag110m_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Ag110m_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "RU106" || item.ElementName.ToUpper() == "RU-106")
                {
                    checkDate_r_Ru106_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "ZN65" || item.ElementName.ToUpper() == "ZN-65")
                {
                    checkDate_r_Zn65_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Zn65_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "ZR95" || item.ElementName.ToUpper() == "ZR-95")
                {
                    checkDate_r_Zr95_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Zr95_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "CR51" || item.ElementName.ToUpper() == "CR-51")
                {
                    checkDate_r_Cr51_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Cr51_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "MN54" || item.ElementName.ToUpper() == "MN-54")
                {
                    checkDate_r_Mn54_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Mn54_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "CO57" || item.ElementName.ToUpper() == "CO-57")
                {
                    checkDate_r_Co57_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Co57_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "CO58" || item.ElementName.ToUpper() == "CO-58")
                {
                    checkDate_r_Co58_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Co58_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "NB95" || item.ElementName.ToUpper() == "NB-95")
                {
                    checkDate_r_Nb95_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Nb95_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "NB94" || item.ElementName.ToUpper() == "NB-94")
                {
                    try
                    {
                        A1_Nb94_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "CD109" || item.ElementName.ToUpper() == "CD-109")
                {
                    try
                    {
                        A1_Cd109_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "CS137" || item.ElementName.ToUpper() == "CS-137")
                {
                    limit_CS137_Value = (double.Parse(detail.CheckdateActivityUnit) / (cs137DispiteLimit.SpecificActivity * 1400000000 / Math.Exp(-0.693 * 150 * 365 / double.Parse(detail.HalfLife)) / 1000000)).ToString();
                    checkDate_r_Cr137_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Cs137_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "SR90" || item.ElementName.ToUpper() == "SR-90")
                {
                    limit_SR90_Value = (double.Parse(detail.CheckdateActivityUnit) / (co60DispiteLimit.SpecificActivity * 430000 / Math.Exp(-0.693 * 150 * 365 / double.Parse(detail.HalfLife)) / 1000000)).ToString();
                    checkDate_r_Sr90_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Sr90_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "NI63" || item.ElementName.ToUpper() == "NI-63")
                {
                    limit_NI63_Value = (double.Parse(detail.CheckdateActivityUnit) / (co60DispiteLimit.SpecificActivity * 5800000000 / Math.Exp(-0.693 * 150 * 365 / double.Parse(detail.HalfLife)) / 1000000)).ToString();
                    checkDate_r_Ni63_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Ni63_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "PU241" || item.ElementName.ToUpper() == "PU-241")
                {
                    checkDate_r_Pu241_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Pu241_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "PU239" || item.ElementName.ToUpper() == "PU-239")
                {
                    try
                    {
                        A1_Pu239_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "I-129" || item.ElementName.ToUpper() == "I129")
                {
                    checkDate_r_I129_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                }
                if (item.ElementName.ToUpper() == "C14" || item.ElementName.ToUpper() == "C-14")
                {
                    limit_C14_Value = (double.Parse(detail.CheckdateActivityUnit) / (co60DispiteLimit.SpecificActivity * 410000000 / Math.Exp(-0.693 * 150 * 365 / double.Parse(detail.HalfLife)) / 1000000)).ToString();
                    checkDate_r_C14_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_C14_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "TC99" || item.ElementName.ToUpper() == "TC-99")
                {
                    checkDate_r_TC99_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_TC99_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                if (item.ElementName.ToUpper() == "CM242" || item.ElementName.ToUpper() == "CM-242")
                {
                    checkDate_r_Cm242_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(giftWasteQuatity)).ToString();
                    try
                    {
                        A1_Cm242_Value = (float.Parse(detail.CheckdateActivity) / float.Parse(nuclearElement.LimitValue1.ToString())).ToString();
                    }
                    catch
                    { }
                }
                //审查日废物比活度
                try
                {
                    detail.CheckdateActivityPercent = decimal.Parse(detail.CheckdateActivity) / decimal.Parse(activityOrder.WasteVolumn.ToString());
                }
                catch
                {
                    detail.CheckdateActivityPercent = 0;
                }

                //Z列的活度
                detail.ZActivity = (float.Parse(detail.CheckdateActivity) * Math.Exp(-0.693 * (500 * 365) / float.Parse(item.HalfLife))).ToString();
                if (item.ElementName.ToUpper() == "PU-239" || item.ElementName.ToUpper() == "PU239")
                {
                    pu_239ZActivity = detail.ZActivity;
                }
                sumZActivity = (float.Parse(sumZActivity) + float.Parse(detail.ZActivity)).ToString();


                //添加T45、T46的活度、近地表审查日废物活度、审查日废物活度以及IAEA数值
                nuclearElementCondition.ElementName = item.ElementName.ToUpper().Trim();
                IQueryable<NuclearElementView> iqueryItem = iNuclearElementRepository.QueryList(nuclearElementCondition);
                if (iqueryItem != null && iqueryItem.Count() > 0)
                {
                    NuclearElementView elementItem = iqueryItem.ToList()[0];

                    //T45
                    try
                    {
                        t45TotalActivity = (float.Parse(t45TotalActivity) + float.Parse(detail.CheckdateActivity) / float.Parse(elementItem.LimitValue2.ToString())).ToString();
                    }
                    catch
                    {
                        t45TotalActivity = "0";
                    }

                    //T46
                    try
                    {
                        t46TotalActivity = (float.Parse(t46TotalActivity) + float.Parse(detail.CheckdateActivity) / float.Parse(elementItem.LimitValue3.ToString())).ToString();
                    }
                    catch
                    {
                        t46TotalActivity = "0";
                    }

                    //近地表审查日废物活度
                    string checkDateDecayActivity = "0";
                   


                    checkDateDecayActivity = (float.Parse(detail.CheckdateActivity) * float.Parse(elementItem.DecayHeat.ToString()) / 37000).ToString();
                    checkDateDecayTotalActivity = (float.Parse(checkDateDecayTotalActivity) + float.Parse(detail.CheckdateActivity) * float.Parse(elementItem.DecayHeat.ToString()) / 37000).ToString();
                   
                    //∑D300a
                    float halfLife = float.Parse(elementItem.HalfLife.ToString()) / 365;
                    checkDateWasteTotalActivity = (float.Parse(checkDateWasteTotalActivity) + float.Parse(checkDateDecayActivity) / float.Parse(giftWasteQuatity) * 45500000 * halfLife * (1 - Math.Exp(-0.693 * 300 / halfLife))).ToString();

                    string lowerValue = elementItem.LowerValue == null ? "1" : elementItem.LowerValue.ToString();
                    string iaeaValue = elementItem.IaeaValue == null ? "1" : elementItem.IaeaValue.ToString();
                    if (elementItem.ElementName.ToUpper().Trim() == "NB94" || elementItem.ElementName.ToUpper().Trim() == "NB-94")
                    {
                        lower_Nb94_Value = lowerValue;
                        iaea_Nb94_Value = iaeaValue;
                        checkDate_Nb94_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "TC99" || elementItem.ElementName.ToUpper().Trim() == "TC-99")
                    {
                        lower_Tc99_Value = lowerValue;
                        iaea_Tc99_Value = iaeaValue;
                        checkDate_Tc99_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "C14" || elementItem.ElementName.ToUpper().Trim() == "C-14")
                    {
                        lower_C14_Value = lowerValue;
                        iaea_C14_Value = iaeaValue;
                        checkDate_C14_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "NI59" || elementItem.ElementName.ToUpper().Trim() == "NI-59")
                    {
                        lower_Ni59_Value = lowerValue;
                        iaea_Ni59_Value = iaeaValue;
                        checkDate_Ni59_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "NI63" || elementItem.ElementName.ToUpper().Trim() == "NI-63")
                    {
                        lower_Ni63_Value = lowerValue;
                        iaea_Ni63_Value = iaeaValue;
                        checkDate_Ni63_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "I129" || elementItem.ElementName.ToUpper().Trim() == "I-129")
                    {
                        lower_I129_Value = lowerValue;
                        iaea_I129_Value = iaeaValue;
                        checkDate_I129_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "SR90" || elementItem.ElementName.ToUpper().Trim() == "SR-90")
                    {
                        lower_Sr90_Value = lowerValue;
                        iaea_Sr90_Value = iaeaValue;
                        checkDate_Sr90_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "PU239" || elementItem.ElementName.ToUpper().Trim() == "PU-239")
                    {
                        lower_Pu239_Value = lowerValue;
                        iaea_Pu239_Value = iaeaValue;
                        checkDate_Pu239_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "PU241" || elementItem.ElementName.ToUpper().Trim() == "PU-241")
                    {
                        lower_Pu241_Value = lowerValue;
                        iaea_Pu241_Value = iaeaValue;
                        checkDate_Pu241_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "H3" || elementItem.ElementName.ToUpper().Trim() == "H-3")
                    {
                        lower_H3_Value = lowerValue;
                        iaea_H3_Value = iaeaValue;
                        checkDate_H3_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CS137" || elementItem.ElementName.ToUpper().Trim() == "CS-137")
                    {
                        lower_Cs137_Value = elementItem.LowerValue==null?"1":elementItem.LowerValue.ToString();
                        iaea_Cs137_Value = elementItem.IaeaValue==null?"1":elementItem.IaeaValue.ToString();
                        checkDate_Cs137_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CR51" || elementItem.ElementName.ToUpper().Trim() == "CR-51")
                    {
                        lower_Cr51_Value = lowerValue;
                        iaea_Cr51_Value = iaeaValue;
                        checkDate_Cr51_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "MN54" || elementItem.ElementName.ToUpper().Trim() == "MN-54")
                    {
                        lower_Mn54_Value = lowerValue;
                        iaea_Mn54_Value = iaeaValue;
                        checkDate_Mn54_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CO57" || elementItem.ElementName.ToUpper().Trim() == "CO-57")
                    {
                        lower_Co57_Value = lowerValue;
                        iaea_Co57_Value = iaeaValue;
                        checkDate_Co57_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CO58" || elementItem.ElementName.ToUpper().Trim() == "CO-58")
                    {
                        lower_Co58_Value = lowerValue;
                        iaea_Co58_Value = iaeaValue;
                        checkDate_Co58_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CO60" || elementItem.ElementName.ToUpper().Trim() == "CO-60")
                    {
                        lower_Co60_Value = lowerValue;
                        iaea_Co60_Value = iaeaValue;
                        checkDate_Co60_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "ZN65" || elementItem.ElementName.ToUpper().Trim() == "ZN-65")
                    {
                        lower_Zn65_Value = lowerValue;
                        iaea_Zn65_Value = iaeaValue;
                        checkDate_Zn65_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "NB95" || elementItem.ElementName.ToUpper().Trim() == "NB-95")
                    {
                        lower_Nb95_Value = lowerValue;
                        iaea_Nb95_Value = iaeaValue;
                        checkDate_Nb95_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "ZR95" || elementItem.ElementName.ToUpper().Trim() == "ZR-95")
                    {
                        lower_Zr95_Value = lowerValue;
                        iaea_Zr95_Value = iaeaValue;
                        checkDate_Zr95_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "RU106" || elementItem.ElementName.ToUpper().Trim() == "RU-106")
                    {
                        lower_Ru106_Value = lowerValue;
                        iaea_Ru106_Value = iaeaValue;
                        checkDate_Ru106_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "AG110M" || elementItem.ElementName.ToUpper().Trim() == "AG-110M")
                    {
                        lower_Ag110m_Value = lowerValue;
                        iaea_Ag110m_Value = iaeaValue;
                        checkDate_Ag110m_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "SN113" || elementItem.ElementName.ToUpper().Trim() == "SN-113")
                    {
                        lower_Sn113_Value = lowerValue;
                        iaea_Sn113_Value = iaeaValue;
                        checkDate_Sn113_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "SB124" || elementItem.ElementName.ToUpper().Trim() == "SB-124")
                    {
                        lower_Sb124_Value = lowerValue;
                        iaea_Sb124_Value = iaeaValue;
                        checkDate_Sb124_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "CM242" || elementItem.ElementName.ToUpper().Trim() == "CM-242")
                    {
                        lower_Cm242_Value = lowerValue;
                        iaea_Cm242_Value = iaeaValue;
                        checkDate_Cm242_Value = detail.CheckdateActivity.ToString();
                    }
                    if (elementItem.ElementName.ToUpper().Trim() == "FE59" || elementItem.ElementName.ToUpper().Trim() == "FE-59")
                    {
                        lower_Fe59_Value = lowerValue;
                        iaea_Fe59_Value = iaeaValue;
                        checkDate_Fe59_Value = detail.CheckdateActivity.ToString();
                    }
                }

                //添加一行数据
                allActivitylist.Add(detail);
            }

            activityOrder.DispiteEvalDetailVMList = allActivitylist;
            //废物初始活度总α、审查日废物活度总α、Z列总α
            string pu241Scale = iScalefactorRepository.GetScaleFactorByElement("pu241");
            string pu238Scale = iScalefactorRepository.GetScaleFactorByElement("pu238");
            string pu240Scale = iScalefactorRepository.GetScaleFactorByElement("pu240");
            string pu244Scale = iScalefactorRepository.GetScaleFactorByElement("pu244");

            //如果无破损
            if (activityOrder.Damage == "0")
            {
                //废物初始活度总α
                activityOrder.TotalOriginalActivity = "0";

                //审查日废物活度总α
                activityOrder.TotalCheckActivityUnit = "0";

                //Z列总α
                activityOrder.TotalZActivity = "0";
            }
            else if (activityOrder.Damage == "1") //如果轻度破损
            {
                //废物初始活度总α
                pu244Scale = iScalefactorRepository.GetScaleFactorByElement("pu244");
                activityOrder.TotalOriginalActivity = String.Format("{0:0.000000}",(float.Parse(pu_239Original) + float.Parse(co_60Original) * (float.Parse(pu241Scale) + float.Parse(pu238Scale) + float.Parse(pu240Scale) + float.Parse(pu244Scale))).ToString());

                //审查日废物活度总α
                activityOrder.TotalCheckActivityUnit = String.Format("{0:0.000000}",(float.Parse(checkDate_Pu239_Value) + float.Parse(co_60Original) * float.Parse(pu241Scale) * Math.Exp(-0.693 * (minusDays ) / 365 / 432) + float.Parse(co_60Original) * float.Parse(pu238Scale) * Math.Exp(-0.693 * (minusDays ) / 365 / 87.7)
                    + float.Parse(co_60Original) * float.Parse(pu240Scale) * Math.Exp(-0.693 * (minusDays ) / 365 / 6550) + float.Parse(co_60Original) * float.Parse(pu244Scale) * Math.Exp(-0.693 * (minusDays ) / 365 / 18.1)).ToString());
                checkDate_r_Total_Value = (float.Parse(activityOrder.TotalCheckActivityUnit) * 1000000 / float.Parse(giftWasteQuatity) / 1000).ToString();

                //Z列总α
                activityOrder.TotalZActivity = String.Format("{0:0.000000}",(float.Parse(pu_239ZActivity) + float.Parse(co_60Original) * float.Parse(pu241Scale) * Math.Exp(-0.693 * (minusDays  + 300 * 365) / 365 / 432) + float.Parse(co_60Original) * float.Parse(pu238Scale) * Math.Exp(-0.693 * (minusDays  + 300 * 365) / 365 / 87.7)
                    + float.Parse(co_60Original) * float.Parse(pu240Scale) * Math.Exp(-0.693 * (minusDays  + 300 * 365) / 365 / 6550) + float.Parse(co_60Original) * float.Parse(pu244Scale) * Math.Exp(-0.693 * (minusDays  + 300 * 365) / 365 / 18.1)).ToString());
            }
            else //重度破损
            {
                //审查日废物活度总α
                activityOrder.TotalOriginalActivity = "采样分析";

                //审查日废物活度总α
                activityOrder.TotalCheckActivityUnit = "采样分析";

                //Z列总α
                activityOrder.TotalZActivity = "采样分析";
            }

            //核素活度与A1限值的比较
            A1_Total_Value = ((double.Parse(A1_Cr51_Value) + double.Parse(A1_Mn54_Value) + double.Parse(A1_Co57_Value) + double.Parse(A1_Co58_Value) + double.Parse(A1_Co60_Value) + double.Parse(A1_Fe59_Value) +
                double.Parse(A1_Nb95_Value) + double.Parse(A1_Nb94_Value) + double.Parse(A1_Cd109_Value) + double.Parse(A1_Zr95_Value) + double.Parse(A1_Zn65_Value) + double.Parse(A1_Ag110m_Value) + double.Parse(A1_Sn113_Value) +
                double.Parse(A1_Sn117m_Value) + double.Parse(A1_Sb125_Value) + double.Parse(A1_Cs134_Value) + double.Parse(A1_Cs137_Value) + double.Parse(A1_Sr90_Value) + double.Parse(A1_Ni63_Value) + double.Parse(A1_Pu241_Value) +
                double.Parse(A1_Pu239_Value) + double.Parse(A1_C14_Value) + double.Parse(A1_TC99_Value) + double.Parse(A1_Cm242_Value)) / 1000000).ToString();
            if (double.Parse(A1_Total_Value) - 1 > 0)
            {
                activityOrder.ActivityCompare = ">";
            }
            else
            {
                activityOrder.ActivityCompare = "<";
            }

            //关键核素比活度与处置场环评限值的比值
            total_Limit_Value = (double.Parse(limit_CS137_Value) + double.Parse(limit_SR90_Value) + double.Parse(limit_NI63_Value) + double.Parse(limit_C14_Value) + double.Parse(limit_CO60_Value)).ToString();
            if (double.Parse(total_Limit_Value) - 1 < 0)
            {
                activityOrder.KeyActivityUnitCompare = "<";
            }
            else
            {
                activityOrder.KeyActivityUnitCompare = ">";
            }

            //总活度
            activityOrder.TotalActivity = String.Format("{0:0.000000}",((float.Parse(sumCheckdateActivity) - float.Parse(checkDate_Pu239_Value) + float.Parse(activityOrder.TotalCheckActivityUnit)) / 1000).ToString());

            //衰变500年
            activityOrder.DecayThreeHundred = String.Format("{0:0.000000}",((float.Parse(sumZActivity) - float.Parse(pu_239ZActivity) + float.Parse(activityOrder.TotalZActivity)) / 1000).ToString());
            activityOrder.DecayThreeHundredValue = String.Format("{0:0.000000}",(float.Parse(t45TotalActivity) / 1000000 / float.Parse(giftWasteQuatity)).ToString());

            //归类
            string z46Activity = ((float.Parse(checkDate_Cr51_Value) / float.Parse(iaea_Cr51_Value) + float.Parse(checkDate_Mn54_Value) / float.Parse(iaea_Mn54_Value) + float.Parse(checkDate_Co57_Value) / float.Parse(iaea_Co57_Value)
                + float.Parse(checkDate_Co58_Value) / float.Parse(iaea_Co58_Value) + float.Parse(checkDate_Fe59_Value) / float.Parse(iaea_Fe59_Value) + float.Parse(checkDate_Co60_Value) / float.Parse(iaea_Co60_Value) + float.Parse(checkDate_Nb95_Value) / float.Parse(iaea_Nb95_Value) + float.Parse(checkDate_Zn65_Value) / float.Parse(iaea_Zn65_Value)
                + float.Parse(checkDate_Zr95_Value) / float.Parse(iaea_Zr95_Value) + float.Parse(checkDate_Ru106_Value) / float.Parse(iaea_Ru106_Value) + float.Parse(checkDate_Ag110m_Value) / float.Parse(iaea_Ag110m_Value)
                + float.Parse(checkDate_Sn113_Value) / float.Parse(iaea_Sn113_Value) + float.Parse(checkDate_Sb124_Value) / float.Parse(iaea_Sb124_Value) + float.Parse(checkDate_Cm242_Value) / float.Parse(iaea_Cm242_Value)) * 1000 / float.Parse(giftWasteQuatity)).ToString();
            string r42 = (float.Parse(activityOrder.TotalCheckActivityUnit) * 1000000 / float.Parse(giftWasteQuatity) / 1000).ToString();
            string mathExp = (Math.Exp(-0.693 * (minusDays ) / 365 / 18.1)).ToString();
            float value1 = float.Parse(wasteLimit1) - (float.Parse(r42) - float.Parse(co_60Original) * float.Parse(pu244Scale) * float.Parse(mathExp)) * 1000000 / float.Parse(giftWasteQuatity) / 1000;
            float value2 = float.Parse(activityOrder.TotalActivity) * 1000000000 / float.Parse(giftWasteQuatity) - float.Parse(highWasteLimit1);
            float value3 = float.Parse(activityOrder.TotalActivity) * 1000000000 / float.Parse(giftWasteQuatity) - float.Parse(middleWasteLimit1);
            if (value1 > 0)
            {
                if (value2 > 0)
                {
                    activityOrder.Classify = "高放固体废物";
                }
                else
                {
                    if (value3 > 0)
                    {
                        activityOrder.Classify = "中放固体废物";
                    }
                    else
                    {
                        if (float.Parse(z46Activity) - 1 < 0)
                        {
                            activityOrder.Classify = "豁免废物";
                        }
                        else
                        {
                            activityOrder.Classify = "低放固体废物";
                        }
                    }
                }
            }
            else
            {
                activityOrder.Classify = "α废物";
            }

            //归类等级
            if (float.Parse(t45TotalActivity) - 2 > 0)
            {
                activityOrder.ClassifyValue = "非低比活度物质";
            }
            else
            {
                if (float.Parse(t45TotalActivity) - 0.1 > 0)
                {
                    activityOrder.ClassifyValue = "LSA-III";
                }
                else
                {
                    if (float.Parse(t46TotalActivity) - 1 > 0)
                    {
                        activityOrder.ClassifyValue = "LSA-II";
                    }
                    else
                    {
                        if (float.Parse(t46TotalActivity) * 30 - 1 > 0)
                        {
                            activityOrder.ClassifyValue = "LSA-I";
                        }
                        else
                        {
                            activityOrder.ClassifyValue = "豁免运输物质";
                        }
                    }
                }
            }

            //近地表处置
            activityOrder.SurfaceClassValue2 = t46TotalActivity;

            float surfaceClassValue1 = float.Parse(checkDate_r_Cr137_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn3(supportSurfaceDealList, "CS137"))
                + float.Parse(checkDate_r_Sr90_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn3(supportSurfaceDealList, "SR90"))
                + float.Parse(checkDate_r_Ni63_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn3(supportSurfaceDealList, "NI63"));

            float surfaceClassValue2 = float.Parse(checkDate_r_Pu241_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn3(supportSurfaceDealList, "PU241"))
             + float.Parse(checkDate_r_Cm242_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "CM242"))
             + float.Parse(checkDate_r_Pu241_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "PU241"))
             + float.Parse(checkDate_r_Total_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "α>5 A"))
             + float.Parse(checkDate_r_I129_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "I129"))
             + float.Parse(checkDate_r_C14_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "C14"))
             + float.Parse(checkDate_r_TC99_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "TC99"));

            float surfaceClassValue3 = float.Parse(checkDate_r_Cm242_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn3(supportSurfaceDealList, "CM242"))
                + float.Parse(checkDate_r_Pu241_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "PU241"))
                + float.Parse(checkDate_r_Total_Value) / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "α>5 A"))
                + float.Parse(checkDate_r_I129_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "I129"))
                + float.Parse(checkDate_r_C14_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "C14"))
             + float.Parse(checkDate_r_TC99_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "TC99"));

            float surfaceClassValue4 = float.Parse(checkDate_r_Cr137_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "CS137"))
                + float.Parse(checkDate_r_Sr90_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "SR90"))
                + float.Parse(checkDate_r_Ni63_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn2(supportSurfaceDealList, "NI63"));

            float surfaceClassValue5 = (float.Parse(checkDate_r_Cr51_Value) + float.Parse(checkDate_r_Mn54_Value) + float.Parse(checkDate_r_Co57_Value)
                + float.Parse(checkDate_r_Co58_Value) + float.Parse(checkDate_r_Fe59_Value) + float.Parse(checkDate_r_Nb95_Value) + float.Parse(checkDate_r_Zr95_Value)
                + float.Parse(checkDate_r_Zn65_Value) + float.Parse(checkDate_r_Ru106_Value) + float.Parse(checkDate_r_Ag110m_Value) + float.Parse(checkDate_r_Sn113_Value)
                + float.Parse(checkDate_r_Sn117m_Value) + float.Parse(checkDate_r_Sb125_Value) + float.Parse(checkDate_r_Cs134_Value)) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "<5E"))
                + float.Parse(checkDate_r_Co60_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "CO60")) + float.Parse(checkDate_r_Cr137_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "CS137"))
                + float.Parse(checkDate_r_H3_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "H3")) + float.Parse(checkDate_r_Sr90_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "SR90"))
                + float.Parse(checkDate_r_Ni63_Value) * 1000000 / float.Parse(WasteCheckBuilder.GetSupportSurfaceDealColumn1(supportSurfaceDealList, "NI63"));

            float z47Activity = (float.Parse(checkDate_Cr51_Value) / float.Parse(lower_Cr51_Value) + float.Parse(checkDate_Mn54_Value) / float.Parse(lower_Mn54_Value) + float.Parse(checkDate_Co57_Value) / float.Parse(lower_Co57_Value)
                + float.Parse(checkDate_Co58_Value) / float.Parse(lower_Co58_Value) + float.Parse(checkDate_Fe59_Value) / float.Parse(lower_Fe59_Value) + float.Parse(checkDate_Co60_Value) / float.Parse(lower_Co60_Value)
                + float.Parse(checkDate_Nb95_Value) / float.Parse(lower_Nb95_Value) + float.Parse(checkDate_Zr95_Value) / float.Parse(lower_Zr95_Value) + float.Parse(checkDate_Zn65_Value) / float.Parse(lower_Zn65_Value)
                + float.Parse(checkDate_Ru106_Value) / float.Parse(lower_Ru106_Value) + float.Parse(checkDate_Ag110m_Value) / float.Parse(lower_Ag110m_Value) + float.Parse(checkDate_Sn113_Value) / float.Parse(lower_Sn113_Value)
                + float.Parse(checkDate_Sb124_Value) / float.Parse(lower_Sb124_Value) + float.Parse(checkDate_Cs134_Value) / float.Parse(lower_Cs134_Value) + float.Parse(checkDate_H3_Value) / float.Parse(lower_H3_Value)
            + float.Parse(checkDate_Pu241_Value) / float.Parse(lower_Pu241_Value) + float.Parse(checkDate_Pu239_Value) / float.Parse(lower_Pu239_Value) + float.Parse(checkDate_Sr90_Value) / float.Parse(lower_Sr90_Value)
            + float.Parse(checkDate_I129_Value) / float.Parse(lower_I129_Value) + float.Parse(checkDate_Ni63_Value) / float.Parse(lower_Ni63_Value) + float.Parse(checkDate_Ni59_Value) / float.Parse(lower_Ni59_Value)
            + float.Parse(checkDate_C14_Value) / float.Parse(lower_C14_Value) + float.Parse(checkDate_Tc99_Value) / float.Parse(lower_Tc99_Value) + float.Parse(checkDate_Nb94_Value) / float.Parse(lower_Nb94_Value)
            + float.Parse(activityOrder.TotalCheckActivityUnit) / float.Parse(lower_Cm242_Value)) * 1000 / float.Parse(giftWasteQuatity);

            if (surfaceClassValue1 < 1 && surfaceClassValue2 < 1)
            {
                //if (surfaceClassValue3 < 0.1)
                //{
                //    if (surfaceClassValue4 < 1)
                //    {
                //        if (surfaceClassValue5 < 1)
                //        {
                //            if (z47Activity - 1 < 0)
                //            {
                //                if (float.Parse(z46Activity) - 1 < 0)
                //                {
                //                    activityOrder.SurfaceClass = "可解控类";
                //                }
                //                else
                //                {
                //                    activityOrder.SurfaceClass = "极低放类";
                //                }
                //            }
                //            else
                //            {
                //                activityOrder.SurfaceClass = "A类";
                //            }
                //        }
                //        else
                //        {
                //            activityOrder.SurfaceClass = "B类";
                //        }
                //    }
                //    else
                //    {
                //        activityOrder.SurfaceClass = "C类";
                //    }
                //}
                //else
                //{
                //    activityOrder.SurfaceClass = "C类";
                //}

                activityOrder.SurfaceClass = "满足近地表处置要求";
            }
            else
            {
                activityOrder.SurfaceClass = "超C类标准";
            }

            //衰变热
            try
            {
                activityOrder.DecayHeat = (float.Parse(checkDateDecayTotalActivity) / float.Parse(activityOrder.WasteVolumn.ToString()) / 1000).ToString();
            }
            catch
            {
                activityOrder.DecayHeat = string.Empty;
            }

            //∑D300a
            activityOrder.CalcuThreeHundred = checkDateWasteTotalActivity;
            model = activityOrder;
            return model;
        }

       /// <summary>
        /// 根据核素ID和处置场ID得到限值信息
       /// </summary>
       /// <param name="supportDispiteLimitList">处置场限值列表</param>
       /// <param name="nuclearElementId">核素ID</param>
       /// <param name="dispitePositonId">处置场ID</param>
       /// <returns></returns>
        public static SupportDispiteLimit GetSupportDispiteLimit(List<SupportDispiteLimit> supportDispiteLimitList, string nuclearElementId, string dispitePositonId)
        {
            SupportDispiteLimit supportDispiteLimit = new SupportDispiteLimit(); ;
            var list = from s in supportDispiteLimitList
                       where s.ElementId == nuclearElementId && s.DispitePositionId == dispitePositonId
                       select s;
            if (list != null && list.Count() > 0)
            {
                supportDispiteLimit = list.ToList()[0];
            }
            return supportDispiteLimit;
        }
    }
}