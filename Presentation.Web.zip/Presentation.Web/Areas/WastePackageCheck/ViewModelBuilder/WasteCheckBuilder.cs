﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   WasteCheckBuilder.cs
 *   描    述   ：   废物货包审核查询类
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-28 18:45:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-28 18:45:00    1.0.0.0     PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Domain.DomainObjects.View.Support;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModelBuilder
{
    public class WasteCheckBuilder
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="bucketId">桶ID</param>
        /// <returns></returns>
        public static IQueryable<DealMethod> GetWasteDealMethod(string bucketId)
        {
            INuclearBucketSolutionRepository nuclearBucketSolutionRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolutionRepository>();
            INuclearBucketResinRepository nuclearBucketResinRepository = ServiceLocator.Current.GetInstance<INuclearBucketResinRepository>();
            INuclearBucketRSolidifyRepository nuclearBucketRSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketRSolidifyRepository>();
            INuclearBucketSSolidifyRepository nuclearBucketSSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketSSolidifyRepository>();

            var iqueryBucketSolution = nuclearBucketSolutionRepository.GetQueryList().Where(c => c.Stationcode == AppContext.CurrentUser.ProjectCode);
            var iqueryBucketResin = nuclearBucketResinRepository.GetQueryList().Where(c => c.Stationcode == AppContext.CurrentUser.ProjectCode);
            var iqueryBucketRSolidify = nuclearBucketResinRepository.GetQueryList().Where(c => c.Stationcode == AppContext.CurrentUser.ProjectCode);
            var iqueryNuclearBucketSSolidify = nuclearBucketSSolidifyRepository.GetQueryList().Where(c => c.Stationcode == AppContext.CurrentUser.ProjectCode);
            return null;

        }


        /// <summary>
        /// 根据桶ID得到材料信息
        /// </summary>
        /// <param name="bucketId">桶ID</param>
        /// <returns></returns>
        public static IQueryable<MaterialInputVM> GetMaterialInput(string bucketId)
        {
            IMaterialInputRepository materialInputRepository = ServiceLocator.Current.GetInstance<IMaterialInputRepository>();
            INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IMaterialTypeRepository materialRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
            IBasicObjectRepository basicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            IQueryable<BasicObject> iqueryLocation = basicObjectRepository.GetAll().AsQueryable();
            IQueryable<BasicObject> iqueryUnit = iqueryLocation;
            IQueryable<BasicObject> iquerySpec = iqueryLocation;
            IQueryable<MaterialType> iqueryMaterial = materialRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == AppContext.CurrentUser.ProjectCode.ToUpper().Trim());
            IQueryable<MaterialInput> iqueryMaterialInput = materialInputRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == AppContext.CurrentUser.ProjectCode.ToUpper().Trim());
            IQueryable<NuclearBucket> iqueryBucket = nuclearBucketRepository.GetAll().AsQueryable().Where(c => c.BucketId == bucketId);
            var query = from b in iqueryBucket
                        join m in iqueryMaterial on b.MaterialId equals m.MaterialId into mEmpt
                        from m in mEmpt.DefaultIfEmpty()
                        join p in iqueryMaterialInput on m.MaterialId equals p.MaterialId into pEmpt
                        from p in pEmpt.DefaultIfEmpty()
                        join l in iqueryLocation on p.StorageLocationId equals l.Uuid into lEmpt
                        from l in lEmpt.DefaultIfEmpty()
                        join u in iqueryUnit on p.UnitId equals u.Uuid into uEmpt
                        from u in uEmpt.DefaultIfEmpty()
                        join s in iquerySpec on m.SpecId equals s.Uuid into sEmpt
                        from s in sEmpt.DefaultIfEmpty()
                        select new MaterialInputVM
                        {
                            BucketCode = b.BucketCode,
                            MaterialSpec = s.Name,
                            MaterialName = m.MaterialName,
                            LocationName = l.Name,
                            UuidName = u.Name,
                            MaterialInput = p
                        };

            return query;
        }

        /// <summary>
        /// 是否存在转运或者存储
        /// </summary>
        /// <param name="bucketId">桶ID</param>
        /// <returns></returns>
        public static bool IsExistTransferAndStorage(string bucketId)
        {

            INuclearQtTransRepository nuclearQtTransRepository = ServiceLocator.Current.GetInstance<INuclearQtTransRepository>();
            INuclearFcTransRepository nuclearFcTransRepository = ServiceLocator.Current.GetInstance<INuclearFcTransRepository>();
            IQueryable<NuclearQtTrans> iqueryNuclearQtTrans = nuclearQtTransRepository.GetAll().AsQueryable().Where(c => c.BucketId == bucketId);
            IQueryable<NuclearFcTransDetail> iqueryNuclearFcTrans = nuclearFcTransRepository.GetDetailQueryList().Where(c => c.BucketId == bucketId);
            if (iqueryNuclearQtTrans.Count() + iqueryNuclearFcTrans.Count() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 根据桶ID得到废物货包和桶信息
        /// </summary>
        /// <param name="bucketId">桶ID</param>
        /// <returns></returns>
        public static WastePackageBucketVM GetWastePackageInfo(string bucketId)
        {
            WastePackageBucketVM vm = new WastePackageBucketVM();
            INuclearBucketRepository nuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            INuclearWastePackageRepository nuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
            IQueryable<NuclearBucket> iqueryNuclearBucket = nuclearBucketRepository.GetAll().AsQueryable().Where(c=>c.BucketId==bucketId);
            IQueryable<NuclearWastePackage> iqueryNuclearWastePackage = nuclearWastePackageRepository.GetAll().AsQueryable();
            var query = from b in iqueryNuclearBucket
                        join p in iqueryNuclearWastePackage on b.BucketId equals p.BucketId
                        select new WastePackageBucketVM
                        {
                            NuclearBucket=b,
                            NuclearWastePackage=p
                        };
            
            if (query.Count() > 0)
            {
                vm = query.ToList()[0];
            }
            return vm;
        }

        public static ActivityOrder GetElementList(string activityId, string activityType, ActivityOrder activityOrder)
        {
            List<DispiteEvalDetail> detailList = new List<DispiteEvalDetail>();
            switch (activityType)
            {
                case "ActivityBucket":

                    break;
                case "ActivityCementliquid":
                    IActivityCliquidDetailRepository activityCementliquidRepository = ServiceLocator.Current.GetInstance<IActivityCliquidDetailRepository>();
                    IQueryable<ActivityCliquidDetail> iqueryList = activityCementliquidRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == activityId);
                    if (iqueryList.Count() > 0)
                    {
                        List<ActivityCliquidDetail> activityBucketDetailList = iqueryList.ToList();
                        foreach (var item in activityBucketDetailList)
                        {
                            DispiteEvalDetail detail = new DispiteEvalDetail();
                            detail.ElementId = item.ElementId;
                            detail.HalfLife = item.HalfLife.ToString();
                            detail.OriginalActivity = item.InitialActivity.ToString();
                            detail.OriginalActivityPercent = item.InitialActivityRate;
                            detailList.Add(detail);
                        }
                    }
                    activityOrder.DispiteEvalDetailList = detailList;
                    break;
                case "ActivityCfilter":
                    break;
                case "ActivityCore":
                    break;
                case "ActivityCresin":
                    break;
                case "ActivityDmeasure":
                    break;
                case "ActivityHlevel":
                    break;
                case "ActivityMfilter":
                    break;
                case "ActivityMliquid":
                    break;
                case "ActivityMresin":
                    break;
                case "ActivityOpBucket":
                    break;
                default:
                    break;
            }
            return LinquidActivityCalcuBuilder.GetLinquidCalcuElement(activityOrder);
        }

        /// <summary>
        /// 根据Dtm核素ID得到比例因子
        /// </summary>
        /// <param name="elementId">Dtm核素ID</param>
        /// <param name="scalefactorList">比例因子列表</param>
        /// <returns></returns>
        public static Scalefactor GetScaleValue(string elementId, List<Scalefactor> scalefactorList)
        {
            Scalefactor item = null;
            var query = from s in scalefactorList
                        where s.DtmElementId == elementId
                        select s;
            if (query.Count() > 0)
            {
                item = query.ToList()[0];
            }
            return item;
         
        }

        /// <summary>
        /// 根据核素ID得原始活度
        /// </summary>
        /// <param name="elementId">核素ID</param>
        /// <param name="originalActivityList">原始活度列表</param>
        /// <returns></returns>
        public static string GetOriginalActivity(string elementId, List<DispiteEvalDetailVM> originalActivityList)
        {
            string originalActivity = "0";
            var query = from s in originalActivityList
                        where s.ElementId==elementId
                        select s;
            if (query.Count() > 0)
            {
                originalActivity = query.ToList()[0].OriginalWasteActivity;
            }
            return originalActivity;

        }

        /// <summary>
        /// 得到近地表处置参数栏一的数值
        /// </summary>
        /// <param name="supportSurfaceDealList">近地表处置参数列表</param>
        /// <param name="elementName">核素名称</param>
        /// <returns></returns>
        public static string GetSupportSurfaceDealColumn1(List<SurfaceDealView> supportSurfaceDealList, string elementName)
        {
            string columnValue = "1";
            var query = from s in supportSurfaceDealList
                        where s.ElementName.ToUpper().Trim() == elementName.ToUpper().Trim()
                        select s;
            if (query.Count() > 0)
            {
                columnValue = query.ToList()[0].Column1.ToString();
            }
            return columnValue;
        }

        /// <summary>
        /// 得到近地表处置参数栏二的数值
        /// </summary>
        /// <param name="supportSurfaceDealList">近地表处置参数列表</param>
        /// <param name="elementName">核素名称</param>
        /// <returns></returns>
       public static string GetSupportSurfaceDealColumn2(List<SurfaceDealView> supportSurfaceDealList, string elementName)
        {
            string columnValue = "1";
            var query = from s in supportSurfaceDealList
                        where s.ElementName.ToUpper().Trim() == elementName.ToUpper().Trim()
                        select s;
            if (query.Count() > 0)
            {
                columnValue = query.ToList()[0].Column2.ToString();
            }
            return columnValue;
        }

        /// <summary>
        /// 得到近地表处置参数栏三的数值
        /// </summary>
        /// <param name="supportSurfaceDealList">近地表处置参数列表</param>
        /// <param name="elementName">核素名称</param>
        /// <returns></returns>
       public static string GetSupportSurfaceDealColumn3(List<SurfaceDealView> supportSurfaceDealList, string elementName)
        {
            string columnValue = "1";
            var query = from s in supportSurfaceDealList
                        where s.ElementName.ToUpper().Trim() == elementName.ToUpper().Trim()
                        select s;
            if (query.Count() > 0)
            {
                columnValue = query.ToList()[0].Column3.ToString();
            }
            return columnValue;
        }

    }
}