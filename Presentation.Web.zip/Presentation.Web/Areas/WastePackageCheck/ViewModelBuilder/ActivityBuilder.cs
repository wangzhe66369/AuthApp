﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   WasteCheckBuilder.cs
 *   描    述   ：   废物货包审核查询类
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-28 18:45:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-28 18:45:00    1.0.0.0     PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Domain.DomainObjects.View.Support;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
namespace RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModelBuilder
{
    public class ActivityBuilder
    {
        /// <summary>
        /// 通过废物处理单检索到桶的源项信息
        /// </summary>
        /// <param name="bucketId">桶ID</param>
        /// <returns></returns>
        public static TrackOrder GetTrackOrder(string bucketId, string stationCode)
        {
            TrackOrder order = new TrackOrder();

            //浓缩液装桶固化400l金属桶
            INuclearBucketSolutionRepository _NuclearBucketSolutionRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolutionRepository>();
            var iqueryBucketSolution = _NuclearBucketSolutionRepository.GetAll().AsQueryable().Where(c => c.BucketId == bucketId && c.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());

            //废树脂装桶固化400l金属桶 
            INuclearBucketResinRepository _NuclearBucketResinRepository = ServiceLocator.Current.GetInstance<INuclearBucketResinRepository>();
            var iqueryBucketResin = _NuclearBucketResinRepository.GetAll().AsQueryable().Where(c => c.BucketId == bucketId && c.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            INuclearGiftDetailRepository _NuclearGiftDetailRepository = ServiceLocator.Current.GetInstance<INuclearGiftDetailRepository>();
            var iqueryGiftDetail = _NuclearGiftDetailRepository.GetAll().AsQueryable();
            var iqueryBucketResinTrack = (from s in iqueryBucketResin
                                          join d in iqueryGiftDetail on s.ResinId equals d.GiftId
                                          select new WasteBucket
                                          {
                                              BucketId = s.BucketId,
                                              TrackId = d.TrackId
                                          }).AsQueryable();


            //干湿料制备及废树脂装桶固化
            INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketRSolidifyRepository>();
            var iqueryBucketRSolidify = _NuclearBucketRSolidifyRepository.GetAll().AsQueryable().Where(c => c.BucketId == bucketId && c.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            var iqueryBucketRTrack = (from s in iqueryBucketRSolidify
                                      join d in iqueryGiftDetail on s.SolidifyRId equals d.GiftId
                                      select new WasteBucket
                                      {
                                          BucketId = s.BucketId,
                                          TrackId = d.TrackId
                                      }).AsQueryable();

            //干湿料制备及浓缩液装桶固化 
            INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketSSolidifyRepository>();
            var iqueryBucketSSolidify = _NuclearBucketSSolidifyRepository.GetAll().AsQueryable().Where(c => c.BucketId == bucketId && c.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());

            //固定
            INuclearFixationRepository _NuclearFixationRepository = ServiceLocator.Current.GetInstance<INuclearFixationRepository>();
            var iqueryFixation = _NuclearFixationRepository.GetAll().AsQueryable().Where(c => c.BucketId == bucketId && c.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            INuclearFixationDetailRepository _NuclearFixationDetailRepository = ServiceLocator.Current.GetInstance<INuclearFixationDetailRepository>();
            var iqueryFixationDetail = _NuclearFixationDetailRepository.GetAll().AsQueryable();
            var iqueryFixTrack = (from s in iqueryFixation
                                  join d in iqueryFixationDetail on s.FixationId equals d.FixationId
                                  select new WasteBucket
                                  {
                                      BucketId = s.BucketId,
                                      TrackId = d.TrackId
                                  }).AsQueryable();

            //联合查询 
            var iqueryWasteTrack = (from s in iqueryBucketSolution
                                    select new WasteBucket
                             {
                                 BucketId = s.BucketId,
                                 TrackId = s.TrackId
                             }
                         ).AsQueryable().Union
                        (
                            from ss in iqueryBucketSSolidify
                            select new WasteBucket
                            {
                                BucketId = ss.BucketId,
                                TrackId = ss.TrackId
                            }
                        ).AsQueryable().
                      Union(iqueryBucketResinTrack).Union(iqueryBucketRTrack).Union(iqueryFixTrack);

            //所有的源项跟踪单 
            IQueryable<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetTrackList(stationCode).OrderBy(c => c.ConfirmDate);
            var query = (from w in iqueryWasteTrack
                        join t in iqueryTrackItem on w.TrackId equals t.TrackId
                        select new TrackOrder
                        {
                            BucketId = w.BucketId,
                            TrackId = t.TrackId,
                            TrackType = t.TrackType,
                            ConfirmDate=t.ConfirmDate,
                            ControlDate=t.ControlDate
                        }).AsQueryable();

            if (query.Count() > 0)
            {
                order = query.ToList()[0];
            }
            //返回废物跟踪单信息
            return order;
        }

        /// <summary>
        ///得到核电厂活度计算单内容
        /// </summary>
        /// <param name="activityCount">核电厂活度计算单</param>
        /// <returns></returns>
        public static ActivityOrder GetActivityOrder(ActivityCount activityCount, NuclearBucket bucket, string packageCode)
        {
            ISupportEdsRepository iSupportEdsRepository = ServiceLocator.Current.GetInstance<ISupportEdsRepository>();

            //200L废物桶
            IActivityBucketRepository iActivityBucketRepository = ServiceLocator.Current.GetInstance<IActivityBucketRepository>();
    
            //RWIS_ACTIVITY_CEMENTLIQUID(C1浓缩液活度计算表G)
            IActivityCementliquidRepository iActivityCementliquidRepository = ServiceLocator.Current.GetInstance<IActivityCementliquidRepository>();

            //RWIS_ACTIVITY_CFILTER(C4过滤活度计算G)
            IActivityCfilterRepository iActivityCfilterRepository = ServiceLocator.Current.GetInstance<IActivityCfilterRepository>();

            //RWIS_ACTIVITY_CORE(多芯桶活度计算G)
            IActivityCoreRepository iActivityCoreRepository = ServiceLocator.Current.GetInstance<IActivityCoreRepository>();

            //RWIS_ACTIVITY_CRESIN(C1树脂活度计算表G)
            IActivityCresinRepository iActivityCresinRepository = ServiceLocator.Current.GetInstance<IActivityCresinRepository>();

            //RWIS_ACTIVITY_DMEASURE(活度直接测量)
            IActivityDmeasureRepository iActivityDmeasureRepository = ServiceLocator.Current.GetInstance<IActivityDmeasureRepository>();

            //RWIS_ACTIVITY_HANDLE_VALUE(桶饼核素活度信息)
            IActivityHandleValueRepository iActivityHandleValueRepository = ServiceLocator.Current.GetInstance<IActivityHandleValueRepository>();

            //RWIS_ACTIVITY_HLEVEL(高放废物G)
            IActivityHlevelRepository iActivityHlevelRepository = ServiceLocator.Current.GetInstance<IActivityHlevelRepository>();

            //RWIS_ACTIVITY_MFILTER(400L过滤器活度计算表K)
            IActivityMfilterRepository iActivityMfilterRepository = ServiceLocator.Current.GetInstance<IActivityMfilterRepository>();

            //RWIS_ACTIVITY_MLIQUID(400L浓缩液活度计算表K)
            IActivityMliquidRepository iActivityMliquidRepository = ServiceLocator.Current.GetInstance<IActivityMliquidRepository>();

            //RWIS_ACTIVITY_MRESIN(400L废树脂活度计算表K)
            IActivityMresinRepository iActivityMresinRepository = ServiceLocator.Current.GetInstance<IActivityMresinRepository>();

            //RWIS_ACTIVITY_OP_BUCKETHANDLE(400L超压废物桶的桶饼信息)
            IActivityOpBuckethandleRepository iActivityOpBuckethandleRepository = ServiceLocator.Current.GetInstance<IActivityOpBuckethandleRepository>();

            //RWIS_ACTIVITY_OP_BUCKET(400L超压废物桶活度计算G)
            IActivityOpBucketRepository iActivityOpBucketRepository = ServiceLocator.Current.GetInstance<IActivityOpBucketRepository>();

            ActivityOrder activityOrder = new ActivityOrder();
            string viewModel = activityCount.ViewModel;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            switch (viewModel)
            {
                case "ActivityBucket":
                    ActivityBucketVM activityBucketVM = new ActivityBucketVM();
                    ActivityBucket activityBucket = iActivityBucketRepository.Get(activityCount.CalcuId);
                    if (activityBucket != null)
                    {
                        activityBucketVM.Activity = activityBucket;
                    }
                    activityOrder = TransferActivityBucket(activityBucketVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityBucket != null ? activityBucket.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityBucket != null ? activityBucket.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityBucket != null ? activityBucket.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityBucket != null ? activityBucket.CalcuId : "";
                    break;
                case "ActivityCementliquid":
                    CementLiquidVM cementLiquidVM = new CementLiquidVM();
                    ActivityCementLiquid activityCementLiquid = iActivityCementliquidRepository.Get(activityCount.CalcuId);
                    if (activityCementLiquid != null)
                    {
                        cementLiquidVM.Activity = activityCementLiquid;
                    }
                    activityOrder=TransferLinquid(cementLiquidVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityCementLiquid != null ? activityCementLiquid.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityCementLiquid != null ? activityCementLiquid.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityCementLiquid != null ? activityCementLiquid.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityCementLiquid != null ? activityCementLiquid.CalcuId : "";
                    activityOrder.WasteVolumn = activityCementLiquid != null ? activityCementLiquid.LiquidVolime :0;

                    break;
                case "ActivityCfilter":
                    CfilterVM cfilterVM = new CfilterVM();
                    ActivityCfilter activityCfilter = iActivityCfilterRepository.Get(activityCount.CalcuId);
                    if (activityCfilter != null)
                    {
                        cfilterVM.Activity = activityCfilter;
                    }
                    activityOrder = TransferCFilter(cfilterVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityCfilter != null ? activityCfilter.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityCfilter != null ? activityCfilter.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityCfilter != null ? activityCfilter.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityCfilter != null ? activityCfilter.CalcuId : "";
                    break;
                case "ActivityCore":
                    CoreVM coreVM = new CoreVM();
                    ActivityCore activityCore = iActivityCoreRepository.Get(activityCount.CalcuId);
                    if (activityCore != null)
                    {
                        coreVM.Activity = activityCore;
                    }
                    activityOrder = TransferCore(coreVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityCore != null ? activityCore.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityCore != null ? activityCore.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityCore != null ? activityCore.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityCore != null ? activityCore.CalcuId : "";
                    break;
                case "ActivityCresin":
                    CresinVM cresinVM = new CresinVM();
                    ActivityCresin activityCresin = iActivityCresinRepository.Get(activityCount.CalcuId);
                    if (activityCresin != null)
                    {
                        cresinVM.Activity = activityCresin;
                    }
                    activityOrder = TransferCresin(cresinVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityCresin != null ? activityCresin.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityCresin != null ? activityCresin.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityCresin != null ? activityCresin.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityCresin != null ? activityCresin.CalcuId : "";
                    break;
                case "ActivityDmeasure":
                    DmeasureVM dmeasureVM = new DmeasureVM();
                    ActivityDmeasure activityDmeasure = iActivityDmeasureRepository.Get(activityCount.CalcuId);
                    if (activityDmeasure != null)
                    {
                        dmeasureVM.Activity = activityDmeasure;
                    }
                    activityOrder = TransferDMeasure(dmeasureVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityDmeasure != null ? activityDmeasure.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityDmeasure != null ? activityDmeasure.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityDmeasure != null ? activityDmeasure.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityDmeasure != null ? activityDmeasure.CalcuId : "";
                    break;
                case "ActivityHlevel":
                    HlevelVM hlevelVM = new HlevelVM();
                    ActivityHlevel activityHlevel = iActivityHlevelRepository.Get(activityCount.CalcuId);
                    if (activityHlevel != null)
                    {
                        hlevelVM.Activity = activityHlevel;
                    }
                    activityOrder = TransferHlevel(hlevelVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityHlevel != null ? activityHlevel.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityHlevel != null ? activityHlevel.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityHlevel != null ? activityHlevel.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityHlevel != null ? activityHlevel.CalcuId : "";
                    break;
                case "ActivityMfilter":
                    MfilterVM mfilterVM = new MfilterVM();
                    ActivityMfilter activityMfilter = iActivityMfilterRepository.Get(activityCount.CalcuId);
                    if (activityMfilter != null)
                    {
                        mfilterVM.Activity = activityMfilter;
                    }
                    activityOrder = TransferMFilter(mfilterVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityMfilter != null ? activityMfilter.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityMfilter != null ? activityMfilter.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityMfilter != null ? activityMfilter.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityMfilter != null ? activityMfilter.CalcuId : "";
                    break;
                case "ActivityMliquid":
                    MliquidVM mliquidVM = new MliquidVM();
                    ActivityMliquid activityMliquid = iActivityMliquidRepository.Get(activityCount.CalcuId);
                    if (activityMliquid != null)
                    {
                        mliquidVM.Activity = activityMliquid;
                    }
                    activityOrder = TransferMLiquid(mliquidVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityMliquid != null ? activityMliquid.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityMliquid != null ? activityMliquid.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityMliquid != null ? activityMliquid.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityMliquid != null ? activityMliquid.CalcuId : "";
                    activityOrder.WasteVolumn = activityMliquid != null ? activityMliquid.LiquidVolime : 0;
                    break;
                case "ActivityMresin":
                    MresinVM mresinVM = new MresinVM();
                    ActivityMresin activityMresin = iActivityMresinRepository.Get(activityCount.CalcuId);
                    if (activityMresin != null)
                    {
                        mresinVM.Activity = activityMresin;
                    }
                    activityOrder = TransferMresin(mresinVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityMresin != null ? activityMresin.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityMresin != null ? activityMresin.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityMresin != null ? activityMresin.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityMresin != null ? activityMresin.CalcuId : "";
                    break;
                case "ActivityOpBucket":
                    OpBucketVM opBucketVM = new OpBucketVM();
                    ActivityOpBucket activityOpBucket = iActivityOpBucketRepository.Get(activityCount.CalcuId);
                    if (activityOpBucket != null)
                    {
                        //activityOpBucket.ElemAnalysisId = iSupportEdsRepository.GetCodeById(activityOpBucket.ElemAnalysisId, AppContext.CurrentUser.ProjectCode);
                        opBucketVM.Activity = activityOpBucket;
                    }
                    activityOrder = TransferOpBucket(opBucketVM, bucket, packageCode);
                    activityOrder.AddCalcuActivity = activityOpBucket != null ? activityOpBucket.AddCalcuActivity : 0;
                    activityOrder.FactorType = activityOpBucket != null ? activityOpBucket.FactorType : "CGN";
                    activityOrder.ElemAnalysisId = activityOpBucket != null ? activityOpBucket.ElemAnalysisId : "";
                    activityOrder.AcitivityId = activityOpBucket != null ? activityOpBucket.CalcuId : "";
                    break;
                default:
                    break;
            }
            activityOrder.ActivityOrderType = viewModel;
            SupportEds eds = iSupportEdsRepository.Get(activityOrder.ElemAnalysisId);
            if (eds != null)
            {
                activityOrder.EdsCode = eds.EdsSerialCode;
                activityOrder.WasteTypeId = eds.WasteTypeId;
            }

            //废物体积
            IMaterialTypeRepository materialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
            MaterialType material = materialTypeRepository.GetMaterialModel(bucket.MaterialId);
            if (material != null && (activityOrder.WasteVolumn == null || activityOrder.WasteVolumn==0))
            {
                activityOrder.WasteVolumn = decimal.Parse((3.14 * material.Diamerter / 200 * material.Diamerter / 200 * (material.Height / 100 - double.Parse(activityOrder.OverSpace) / 100)).ToString());
            }
            return activityOrder;
        }

        /// <summary>
        /// 得到封盖/超压/固定时间，即废物固化时间
        /// </summary>
        /// <param name="activityOrder"></param>
        public static void GetWasteGift(ActivityOrder activityOrder, NuclearBucket bucket, out string overSpace)
        {
            //封盖/超压/固定信息
            INuclearCoverMixRepository nuclearCoverMixRepository = ServiceLocator.Current.GetInstance<INuclearCoverMixRepository>();
            IQueryable<NuclearCoverMix> iqueryNuclearCoverMix = nuclearCoverMixRepository.GetAll().AsQueryable().Where(c => c.BucketId == bucket.BucketId);
            INuclearCoverMetalRepository nuclearCoverMetalRepository = ServiceLocator.Current.GetInstance<INuclearCoverMetalRepository>();
            IQueryable<NuclearCoverMetal> iqueryNuclearCoverMetal = nuclearCoverMetalRepository.GetAll().AsQueryable().Where(c => c.BucketId == bucket.BucketId);
            INuclearFixationRepository nuclearFixationRepository = ServiceLocator.Current.GetInstance<INuclearFixationRepository>();
            IQueryable<NuclearFixation> iqueryNuclearFixation = nuclearFixationRepository.GetAll().AsQueryable().Where(c => c.BucketId == bucket.BucketId);
            var query = (from m in iqueryNuclearCoverMix
                         select new CoverInfo
                         {
                             OverSpace = m.OverSpace,
                             WasteGiftDate = m.ControlDate
                         }).AsQueryable().Union
                       (from m in iqueryNuclearCoverMetal
                        select new CoverInfo
                        {
                            OverSpace = "0",
                            WasteGiftDate = m.ControlDate
                        }).AsQueryable().Union
                       (from m in iqueryNuclearFixation
                        select new CoverInfo
                        {
                            OverSpace = "0",
                            WasteGiftDate = m.ControlDate
                        }).AsQueryable();
            CoverInfo coverInfo = new CoverInfo();
            overSpace = "0";
            if (query.Count() > 0)
            {
                coverInfo = query.ToList()[0];
                overSpace = coverInfo.OverSpace == null ? overSpace : coverInfo.OverSpace;
                activityOrder.CoverInfo = coverInfo;
                activityOrder.WasteGiftDate = coverInfo.WasteGiftDate.HasValue ? coverInfo.WasteGiftDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            }
        }
        /// <summary>
        /// 返回200L废物桶活度计算明细
        /// </summary>
        /// <param name="activityBucketVM"></param>
        /// <param name="bucket"></param>
        /// <param name="packageCode"></param>
        /// <returns></returns>
        public static ActivityOrder TransferActivityBucket(ActivityBucketVM model, NuclearBucket bucket, string packageCode)
        {
            ActivityOrder activityOrder = new ActivityOrder();

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //高放废物明细信息
            IActivityBucketDetailRepository iActivityBucketDetailRepository = ServiceLocator.Current.GetInstance<IActivityBucketDetailRepository>();
            IQueryable<ActivityBucketDetail> iqueryActivityBucket = iActivityBucketDetailRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == model.Activity.CalcuId);

            //废物固化时间
            string overSpace = "0";
            GetWasteGift(activityOrder, bucket, out overSpace);

            //废物产生时间
            TrackOrder order = GetTrackOrder(bucket.BucketId, AppContext.CurrentUser.ProjectCode);
            activityOrder.WasteProduceDate = order.ControlDate.HasValue ? order.ControlDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.OverSpace = overSpace;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.AvgDoseRate = model.Activity.AvgDoseRate.ToString();
            activityOrder.TransferPara = model.Activity.TransferFun.ToString();
            activityOrder.ShiledWeight = model.Activity.ShieldWeight;
            activityOrder.CoverWeight ="0";
            activityOrder.GiftWeight = ((double)model.Activity.BucketWeight / 9.8 - (double)model.Activity.ShieldWeight / 9.8).ToString();
            activityOrder.BucketHandleCount = 0;
            //得到核素明细信息
            var query = from d in iqueryActivityBucket
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            OriginalActivity = d.CalcuLevel,
                            OriginalActivityPercent = d.CalcuLevelRate,
                            OriginalWasteActivity=d.ElementLevel
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = item.OriginalActivity;
                vm.OriginalActivityPercent = item.OriginalActivityPercent;
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }

        /// <summary>
        /// 返回活度直接测量计算单明细
        /// </summary>
        /// <param name="model">浓缩液实体</param>
        /// <param name="bucket">桶信息</param>
        /// <param name="packageCode">废物货包号</param>
        /// <returns></returns>
        public static ActivityOrder TransferDMeasure(DmeasureVM model, NuclearBucket bucket, string packageCode)
        {
            ActivityOrder activityOrder = new ActivityOrder();

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //活度直接测量明细信息
            IActivityDmeasureDetailRepository activityDmeasureDetailRepository = ServiceLocator.Current.GetInstance<IActivityDmeasureDetailRepository>();
            IQueryable<ActivityDmeasureDetail> iqueryDmeasureDetail = activityDmeasureDetailRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == model.Activity.CalcuId);

            //废物固化时间
            string overSpace = "0";
            GetWasteGift(activityOrder, bucket, out overSpace);

            //废物产生时间
            activityOrder.OverSpace = overSpace;
            TrackOrder order = GetTrackOrder(bucket.BucketId, AppContext.CurrentUser.ProjectCode);
            activityOrder.WasteProduceDate = order.ControlDate.HasValue ? order.ControlDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteInputBucketDate = bucket.DealDate.HasValue ? bucket.DealDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            activityOrder.WasteVolumn = (decimal)0.305;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.AvgDoseRate = model.Activity.AvgDoseRate.ToString();

            //得到核素明细信息
            var query = from d in iqueryDmeasureDetail
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            OriginalActivity = d.CalcuLevel,
                            OriginalActivityPercent = d.CalcuLevelRate,
                            OriginalWasteActivity = d.ElementLevel
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = item.OriginalActivity;
                vm.OriginalActivityPercent = item.OriginalActivityPercent;
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }

        /// <summary>
        /// 返回高放废物G活度计算单明细
        /// </summary>
        /// <param name="model">高放废物实体</param>
        /// <param name="bucket">桶信息</param>
        /// <param name="packageCode">废物货包号</param>
        /// <returns></returns>
        public static ActivityOrder TransferHlevel(HlevelVM model, NuclearBucket bucket, string packageCode)
        {
            ActivityOrder activityOrder = new ActivityOrder();

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //高放废物明细信息
            IActivityHlevelDetailRepository activityHlevelDetailRepository = ServiceLocator.Current.GetInstance<IActivityHlevelDetailRepository>();
            IQueryable<ActivityHlevelDetail> iqueryHlevelDetail = activityHlevelDetailRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == model.Activity.CalcuId);

            //废物固化时间
            string overSpace = "0";
            GetWasteGift(activityOrder, bucket, out overSpace);

            //废物产生时间
            activityOrder.OverSpace = overSpace;
            TrackOrder order = GetTrackOrder(bucket.BucketId, AppContext.CurrentUser.ProjectCode);
            activityOrder.WasteProduceDate = order.ControlDate.HasValue ? order.ControlDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteInputBucketDate = bucket.DealDate.HasValue ? bucket.DealDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            activityOrder.ActivityCalcuDate = model.Activity.EffcetDate.HasValue ? model.Activity.EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.AvgDoseRate = model.Activity.AvgDoseRate.ToString();
            activityOrder.TransferPara = model.Activity.TransferFun.ToString();
            activityOrder.CoverWeight = model.Activity.CoverWeight.ToString();
            activityOrder.GiftWeight = ((double)model.Activity.BucketWeight / 9.8 - (double)model.Activity.CoverWeight / 9.8 - (double)model.Activity.EmptyWeight / 9.8 - (double)model.Activity.ShieldWeight / 9.8).ToString();
            activityOrder.BucketHandleCount = 0;

            //得到核素明细信息
            var query = from d in iqueryHlevelDetail
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            OriginalActivity = d.InitialActivity,
                            OriginalActivityPercent = d.InitialActivityRate,
                            OriginalWasteActivity=d.ElementLevel
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = item.OriginalActivity;
                vm.OriginalActivityPercent = item.OriginalActivityPercent;
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }

        /// <summary>
        /// 返回多芯桶活度计算单明细
        /// </summary>
        /// <param name="model">多芯桶实体</param>
        /// <param name="bucket">桶信息</param>
        /// <param name="packageCode">废物货包号</param>
        /// <returns></returns>
        public static ActivityOrder TransferCore(CoreVM model, NuclearBucket bucket, string packageCode)
        {
            ActivityOrder activityOrder = new ActivityOrder();

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //多芯桶明细信息
            IActivityCoreDetailRepository activityCoreDetailRepository = ServiceLocator.Current.GetInstance<IActivityCoreDetailRepository>();
            IQueryable<ActivityCoreDetail> iqueryCfilterDetail = activityCoreDetailRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == model.Activity.CalcuId);

            string overSpace = "0";
            activityOrder.OverSpace = overSpace;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            //多芯桶过滤器的参考日期即废物产生日期
            activityOrder.WasteProduceDate = model.Activity.ReferDate.HasValue ? model.Activity.ReferDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            //多芯桶过滤器的有效期对应废物固化日期
            activityOrder.WasteGiftDate = model.Activity.EffcetDate.HasValue ? model.Activity.EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.AvgDoseRate = model.Activity.AvgDoseRate.ToString();
            activityOrder.TransferPara = model.Activity.TransferFun.ToString();
            activityOrder.CoverWeight = model.Activity.CoverWeight.ToString();
            activityOrder.GiftWeight = ((double)model.Activity.BucketWeight / 9.8 - (double)model.Activity.CoverWeight / 9.8 - (double)model.Activity.EmptyBucketWeight / 9.8 - (activityOrder.CoverInfo!=null?(double)activityOrder.CoverInfo.CurdleWeight:0) / 9.8).ToString();
            activityOrder.BucketHandleCount = 0;
            
            //得到核素明细信息
            var query = from d in iqueryCfilterDetail
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            OriginalActivity = d.CalcuLevel,
                            OriginalActivityPercent = d.CalcuLevelRate,
                            OriginalWasteActivity=d.ElementLevel
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = item.OriginalActivity;
                vm.OriginalActivityPercent = item.OriginalActivityPercent;
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }

        /// <summary>
        /// 返回C4过滤活度计算单明细
        /// </summary>
        /// <param name="model">C4过滤器实体</param>
        /// <param name="bucket">桶信息</param>
        /// <param name="packageCode">废物货包号</param>
        /// <returns></returns>
        public static ActivityOrder TransferCFilter(CfilterVM model, NuclearBucket bucket, string packageCode)
        {
            ActivityOrder activityOrder = new ActivityOrder();

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //C4过滤明细信息
            IActivityCfilterDetailRepository activityCfilterDetailRepository = ServiceLocator.Current.GetInstance<IActivityCfilterDetailRepository>();
            IQueryable<ActivityCfilterDetail> iqueryCfilterDetail = activityCfilterDetailRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == model.Activity.CalcuId);
           
            //废物固化时间
            string overSpace = "0";
            GetWasteGift(activityOrder, bucket, out overSpace);

            //废物产生时间
            activityOrder.OverSpace = overSpace;
            TrackOrder order = GetTrackOrder(bucket.BucketId, AppContext.CurrentUser.ProjectCode);
            activityOrder.WasteProduceDate = order.ControlDate.HasValue ? order.ControlDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.AvgDoseRate = model.Activity.AvgDoseRate.ToString();
            activityOrder.TransferPara = model.Activity.TransferFun.ToString();
            activityOrder.CoverWeight = model.Activity.CoverWeight.ToString();
            activityOrder.PackageWeight = model.Activity.BucketWeight.ToString();
            activityOrder.EmptyBucketWeight = model.Activity.EmptyBucketWeight.ToString();
            activityOrder.ShiledWeight = model.Activity.ShieldWeight;
            activityOrder.GiftWeight = ((double)model.Activity.BucketWeight / 9.8 - (double)model.Activity.CoverWeight / 9.8 - (double)model.Activity.EmptyBucketWeight / 9.8 - (double)model.Activity.ShieldWeight / 9.8).ToString();
            activityOrder.BucketHandleCount = 0;

            //得到核素明细信息
            var query = from d in iqueryCfilterDetail
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            OriginalActivity = d.InitialActivity,
                            OriginalActivityPercent = d.InitialActivityRate,
                            OriginalWasteActivity=d.ElementLevel
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = item.OriginalActivity;
                vm.OriginalActivityPercent = item.OriginalActivityPercent;
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }

        /// <summary>
        /// 返回C1树脂活度计算单明细
        /// </summary>
        /// <param name="model">浓缩液实体</param>
        /// <param name="bucket">桶信息</param>
        /// <param name="packageCode">废物货包号</param>
        /// <returns></returns>
        public static ActivityOrder TransferCresin(CresinVM model, NuclearBucket bucket, string packageCode)
        {
            ActivityOrder activityOrder = new ActivityOrder();

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //C1树脂明细信息
            IActivityCresinDetailRepository activityCresinDetailRepository = ServiceLocator.Current.GetInstance<IActivityCresinDetailRepository>();
            IQueryable<ActivityCresinDetail> iqueryCresinDetail = activityCresinDetailRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == model.Activity.CalcuId);

            //废物固化时间
            string overSpace = "0";
            GetWasteGift(activityOrder, bucket, out overSpace);

            activityOrder.OverSpace = overSpace;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            activityOrder.WasteProduceDate = model.Activity.RepostDate.HasValue ? model.Activity.RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.AvgDoseRate = model.Activity.AvgDoseRate.ToString();
            activityOrder.TransferPara = model.Activity.TransferFun.ToString();
            activityOrder.CoverWeight = model.Activity.CoverWeight.ToString();
            activityOrder.GiftWeight = ((double)model.Activity.BucketWeight / 9.8 - (double)model.Activity.CoverWeight / 9.8 - (double)model.Activity.EmptyBucketWeight / 9.8 - (double)activityOrder.CoverInfo.CurdleWeight / 9.8).ToString();
            activityOrder.BucketHandleCount = 0;

            //得到核素明细信息
            var query = from d in iqueryCresinDetail
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            OriginalActivity = d.CalcuLevel,
                            OriginalActivityPercent = d.CalcuLevelRate,
                            OriginalWasteActivity=d.ElementActivity
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = item.OriginalActivity;
                vm.OriginalActivityPercent = item.OriginalActivityPercent;
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }

        /// <summary>
        /// 返回C1浓缩液活度计算单明细
        /// </summary>
        /// <param name="model">浓缩液实体</param>
        /// <param name="bucket">桶信息</param>
        /// <param name="packageCode">废物货包号</param>
        /// <returns></returns>
        public static ActivityOrder TransferLinquid(CementLiquidVM model, NuclearBucket bucket, string packageCode)
        {
            ActivityOrder activityOrder = new ActivityOrder();

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //浓缩液明细信息
            IActivityCliquidDetailRepository activityCliquidDetailRepository = ServiceLocator.Current.GetInstance<IActivityCliquidDetailRepository>();
            IQueryable<ActivityCliquidDetail> iqueryCliquidDetail = activityCliquidDetailRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == model.Activity.CalcuId);

            //废物固化时间
            string overSpace = "0";
            GetWasteGift(activityOrder, bucket, out overSpace);

            activityOrder.OverSpace = overSpace;
            activityOrder.WasteProduceDate = model.Activity.RepostDate.HasValue ? model.Activity.RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            activityOrder.WasteVolumn = model.Activity.LiquidVolime;
            activityOrder.OverSpace = overSpace;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.CoverWeight = model.Activity.CoverWeight.ToString();
            activityOrder.GiftWeight = ((double)model.Activity.BucketWeight / 9.8 - (double)model.Activity.CoverWeight / 9.8 - (double)model.Activity.EmptyBucketWeight / 9.8 - (double)activityOrder.CoverInfo.CurdleWeight / 9.8).ToString();
            activityOrder.PackageWeight = model.Activity.BucketWeight.ToString();
            activityOrder.EdsCalcuDate = model.Activity.MeasureDate.HasValue ? model.Activity.MeasureDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.BucketHandleCount = 0;
           
            //得到核素明细信息
            var query = from d in iqueryCliquidDetail
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            OriginalActivity = d.InitialActivity,
                            OriginalActivityPercent = d.InitialActivityRate,
                            OriginalWasteActivity=d.ElementLevel
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = item.OriginalActivity;
                vm.OriginalActivityPercent = item.OriginalActivityPercent;
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }

        /// <summary>
        /// 返回400L浓缩液活度计算单明细
        /// </summary>
        /// <param name="model">400L浓缩液</param>
        /// <param name="bucket">桶信息</param>
        /// <param name="packageCode">废物货包号</param>
        /// <returns></returns>
        public static ActivityOrder TransferMLiquid(MliquidVM model, NuclearBucket bucket, string packageCode)
        {
            ActivityOrder activityOrder = new ActivityOrder();

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //400L浓缩液明细信息
            IActivityMliquidDetailRepository activityMliquidDetailRepository = ServiceLocator.Current.GetInstance<IActivityMliquidDetailRepository>();
            IQueryable<ActivityMliquidDetail> iqueryMliquidDetail = activityMliquidDetailRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == model.Activity.CalcuId);

            //废物固化时间
            string overSpace = "0";
            GetWasteGift(activityOrder, bucket, out overSpace);

            //封盖信息
            activityOrder.OverSpace = overSpace;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteProduceDate = model.Activity.RepostDate.HasValue ? model.Activity.RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            activityOrder.WasteVolumn = model.Activity.LiquidVolime;
            activityOrder.InitialCalcuDate = model.Activity.MeasureDate.HasValue ? model.Activity.MeasureDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.OverSpace = overSpace;
            activityOrder.BucketHandleCount = 0;
            activityOrder.GiftWeight = model.Activity.LiquidWeight.ToString();
            activityOrder.EdsCalcuDate = model.Activity.MeasureDate.HasValue ? model.Activity.MeasureDate.Value.ToString("yyyy-MM-dd") : string.Empty;

            //得到核素明细信息
            var query = from d in iqueryMliquidDetail
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            OriginalActivity = d.InitialActivity,
                            OriginalActivityPercent = d.InitialActivityRate,
                            OriginalWasteActivity=d.ElementLevel
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = item.OriginalActivity;
                vm.OriginalActivityPercent = item.OriginalActivityPercent;
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }


        /// <summary>
        /// 返回400L超压桶活度计算单明细
        /// </summary>
        /// <param name="model">400L超压桶</param>
        /// <param name="bucket">桶信息</param>
        /// <param name="packageCode">废物货包号</param>
        /// <returns></returns>
        public static ActivityOrder TransferOpBucket(OpBucketVM model, NuclearBucket bucket, string packageCode)
        {
            ActivityOrder activityOrder = new ActivityOrder();

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //400L超压桶明细信息
            IActivityOpBucketDetailRepository activityOpBucketRepository = ServiceLocator.Current.GetInstance<IActivityOpBucketDetailRepository>();
            IActivityOpBuckethandleRepository activityOpBuckethandleRepository = ServiceLocator.Current.GetInstance<IActivityOpBuckethandleRepository>();
            IQueryable<ActivityOpBucketDetail> iqueryOpBucketDetail = activityOpBucketRepository.GetAll().AsQueryable().Where(c => c.CalcuId == model.Activity.CalcuId);
            IQueryable<ActivityOpBuckethandle> iqueryOpBuckethandle = activityOpBuckethandleRepository.GetAll().AsQueryable().Where(c => c.CalcuId == model.Activity.CalcuId);

            //废物固化时间
            string overSpace = "0";
            GetWasteGift(activityOrder, bucket, out overSpace);

            //固化体质量 
            Nullable<decimal> giftWeight = 0;
            var weightList = (from i in iqueryOpBuckethandle
                             select i.BucketWeight).ToList();
            try
            {
                foreach (var weight in weightList)
                {
                    if (weight!=null && weight!=0)
                    {
                        giftWeight = giftWeight + weight;
                    }
                }
            }
            catch
            { }

            //废物产生时间
            TrackOrder order = GetTrackOrder(bucket.BucketId, AppContext.CurrentUser.ProjectCode);
            activityOrder.WasteProduceDate = order.ControlDate.HasValue ? order.ControlDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.OverSpace = overSpace;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.TotalWasteActivity = model.Activity.AddCalcuActivity.ToString();
            activityOrder.AvgDoseRate = model.Activity.AvgDoseRate.ToString();
            activityOrder.BucketHandleCount = iqueryOpBuckethandle.Count();
            activityOrder.CoverWeight = "0";
            activityOrder.GiftWeight = giftWeight.ToString();

            //得到能谱号所对应的原V活度
            //能谱信息
            string edsId = model.Activity.ElemAnalysisId;
            ISupportEdsRepository iSupportEdsRepository = ServiceLocator.Current.GetInstance<ISupportEdsRepository>();
            IQueryable<SupportEds> iquerySupportEds = iSupportEdsRepository.GetAll().AsQueryable().Where(c => c.EdsId == edsId);

            ISupportEdsDetailRepository isupportEdsDetailRepository = ServiceLocator.Current.GetInstance<ISupportEdsDetailRepository>();
            IQueryable<SupportEdsDetail> iquerySupportEdsDetail = isupportEdsDetailRepository.GetAll().AsQueryable();

            //得到核素明细信息
            var query = from d in iqueryOpBucketDetail
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        join sd in iquerySupportEdsDetail on d.ElementId equals sd.ElementId into sEmpt
                        from sd in sEmpt.DefaultIfEmpty()
                        join s in iquerySupportEds on sd.EdsId equals s.EdsId
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            Activity = sd.Activity,
                            PercentValue = sd.PercentValue,
                            OriginalWasteActivity=d.TotalActivity
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = Convert.ToDecimal(item.Activity.ToString());
                vm.OriginalActivityPercent = Convert.ToDecimal(item.PercentValue.ToString());
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }

        /// <summary>
        /// 返回400L金属桶废树脂活度计算单明细
        /// </summary>
        /// <param name="model">400废树脂实体</param>
        /// <param name="bucket">桶信息</param>
        /// <param name="packageCode">废物货包号</param>
        /// <returns></returns>
        public static ActivityOrder TransferMresin(MresinVM model, NuclearBucket bucket, string packageCode)
        {

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //400L金属桶废树脂明细信息
            IActivityMresinDetailRepository activityMresinDetailRepository = ServiceLocator.Current.GetInstance<IActivityMresinDetailRepository>();
            IQueryable<ActivityMresinDetail> iqueryMresinDetail = activityMresinDetailRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == model.Activity.CalcuId);

            ActivityOrder activityOrder = new ActivityOrder();

            //废物固化时间
            string overSpace = "0";
            GetWasteGift(activityOrder, bucket, out overSpace);

            //废物产生时间
            activityOrder.OverSpace = overSpace;
            activityOrder.WasteProduceDate = model.Activity.RepostDate.HasValue ? model.Activity.RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteInputBucketDate = bucket.DealDate.HasValue ? bucket.DealDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.TotalWasteActivity = model.Activity.AddCalcuActivity.ToString();
            activityOrder.AvgDoseRate = model.Activity.AvgDoseRate.ToString();
            activityOrder.CoverWeight = "0";
            activityOrder.GiftWeight = (model.Activity.BucketWeight - 0 - 0 - 0).ToString();
            activityOrder.InitialCalcuDate = model.Activity.EffcetDate.HasValue ? model.Activity.EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.EdsCalcuDate = model.Activity.EffcetDate.HasValue ? model.Activity.EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.TransferPara = model.Activity.TransferFun.ToString();
            activityOrder.BucketHandleCount = 0;
            //得到核素明细信息
            var query = from d in iqueryMresinDetail
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            OriginalActivity = d.CalcuLevel,
                            OriginalActivityPercent = d.CalcuLevelRate,
                            OriginalWasteActivity=d.ElementLevel
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = item.OriginalActivity;
                vm.OriginalActivityPercent = item.OriginalActivityPercent;
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }

        /// <summary>
        /// 返回400L过滤器活度计算单明细
        /// </summary>
        /// <param name="model">400L过滤器</param>
        /// <param name="bucket">桶信息</param>
        /// <param name="packageCode">废物货包号</param>
        /// <returns></returns>
        public static ActivityOrder TransferMFilter(MfilterVM model, NuclearBucket bucket, string packageCode)
        {
            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable();

            //400L金属桶废树脂明细信息
            IActivityMfilterDetailRepository activityMfilterDetailRepository = ServiceLocator.Current.GetInstance<IActivityMfilterDetailRepository>();
            IQueryable<ActivityMfilterDetail> iqueryMfilterDetail = activityMfilterDetailRepository.GetAll().AsQueryable().Where(c => c.CalcuLd == model.Activity.CalcuId);

            ActivityOrder activityOrder = new ActivityOrder();
            //废物固化时间
            string overSpace = "0";
            GetWasteGift(activityOrder, bucket, out overSpace);

            activityOrder.OverSpace = overSpace;
            TrackOrder order = GetTrackOrder(bucket.BucketId, AppContext.CurrentUser.ProjectCode);
            activityOrder.WasteProduceDate = order.ControlDate.HasValue ? order.ControlDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.BucketCode = bucket.BucketCode;
            activityOrder.WastePacakgeCode = packageCode;
            activityOrder.WasteInputBucketDate = bucket.DealDate.HasValue ? bucket.DealDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.WasteTypeId = bucket.BucketTypeId;
            activityOrder.WasteType = bucket.WasteType;
            activityOrder.EdsCode = model.Activity.ElemAnalysisId;
            activityOrder.Damage = model.Activity.IsDamage;
            activityOrder.TotalWasteActivity = model.Activity.AddCalcuActivity.ToString();
            activityOrder.AvgDoseRate = model.Activity.AvgDoseRate.ToString();

            activityOrder.CoverWeight = "0";
            activityOrder.GiftWeight = (model.Activity.BucketWeight - model.Activity.EmptyBucketWeight).ToString();
            activityOrder.EdsCalcuDate = model.Activity.EffcetDate.HasValue ? model.Activity.EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty;
            activityOrder.TransferPara = model.Activity.TransferFun.ToString();
            activityOrder.BucketHandleCount = 0;


            //得到核素明细信息
            var query = from d in iqueryMfilterDetail
                        join e in iqueryNuclearElement on d.ElementId equals e.ElementId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        select new ActivityDetail
                        {
                            ElementName = e.ElementName,
                            ElementId = e.ElementId,
                            HalfLife = e.HalfLife,
                            ElementClass = e.ElementClass,
                            OriginalActivity = d.CalcuLevel,
                            OriginalActivityPercent = d.CalcuLevelRate,
                            OriginalWasteActivity=d.ElementLevel
                        };

            List<DispiteEvalDetailVM> dispiteEvalDetailVMList = new List<DispiteEvalDetailVM>();
            foreach (var item in query)
            {
                DispiteEvalDetailVM vm = new DispiteEvalDetailVM();
                vm.ElementId = item.ElementId;
                vm.ElementName = item.ElementName;
                vm.ElementClass = item.ElementClass;
                vm.HalfLife = item.HalfLife.ToString();
                vm.OriginalActivity = item.OriginalActivity;
                vm.OriginalActivityPercent = item.OriginalActivityPercent;
                vm.OriginalWasteActivity = item.OriginalWasteActivity.ToString();
                dispiteEvalDetailVMList.Add(vm);
            }
            activityOrder.DispiteEvalDetailVMList = dispiteEvalDetailVMList;

            //返回核素分析单
            return activityOrder;
        }

        /// <summary>
        /// 根据Dtm核素ID得到比例因子
        /// </summary>
        /// <param name="elementId">Dtm核素ID</param>
        /// <param name="scalefactorList">比例因子列表</param>
        /// <returns></returns>
        public static Scalefactor GetScaleValue(string elementId, List<Scalefactor> scalefactorList)
        {
            Scalefactor item = null;
            var query = from s in scalefactorList
                        where s.DtmElementId == elementId
                        select s;
            if (query.Count() > 0)
            {
                item = query.ToList()[0];
            }
            return item;

        }

        /// <summary>
        /// 根据核素ID得原始活度
        /// </summary>
        /// <param name="elementId">核素ID</param>
        /// <param name="originalActivityList">原始活度列表</param>
        /// <returns></returns>
        public static string GetOriginalActivity(string elementId, List<DispiteEvalDetailVM> originalActivityList)
        {
            string originalActivity = "0";
            var query = from s in originalActivityList
                        where s.ElementId == elementId
                        select s;
            if (query.Count() > 0)
            {
                originalActivity = query.ToList()[0].OriginalWasteActivity;
            }
            return originalActivity;

        }

        /// <summary>
        /// 得到近地表处置参数栏一的数值
        /// </summary>
        /// <param name="supportSurfaceDealList">近地表处置参数列表</param>
        /// <param name="elementName">核素名称</param>
        /// <returns></returns>
        static string GetSupportSurfaceDealColumn1(List<SurfaceDealView> supportSurfaceDealList, string elementName)
        {
            string columnValue = "1";
            var query = from s in supportSurfaceDealList
                        where s.ElementName.ToUpper().Trim() == elementName.ToUpper().Trim()
                        select s;
            if (query.Count() > 0)
            {
                columnValue = query.ToList()[0].Column1.ToString();
            }
            return columnValue;
        }

        /// <summary>
        /// 得到近地表处置参数栏二的数值
        /// </summary>
        /// <param name="supportSurfaceDealList">近地表处置参数列表</param>
        /// <param name="elementName">核素名称</param>
        /// <returns></returns>
        static string GetSupportSurfaceDealColumn2(List<SurfaceDealView> supportSurfaceDealList, string elementName)
        {
            string columnValue = "1";
            var query = from s in supportSurfaceDealList
                        where s.ElementName.ToUpper().Trim() == elementName.ToUpper().Trim()
                        select s;
            if (query.Count() > 0)
            {
                columnValue = query.ToList()[0].Column2.ToString();
            }
            return columnValue;
        }

        /// <summary>
        /// 得到近地表处置参数栏三的数值
        /// </summary>
        /// <param name="supportSurfaceDealList">近地表处置参数列表</param>
        /// <param name="elementName">核素名称</param>
        /// <returns></returns>
        static string GetSupportSurfaceDealColumn3(List<SurfaceDealView> supportSurfaceDealList, string elementName)
        {
            string columnValue = "1";
            var query = from s in supportSurfaceDealList
                        where s.ElementName.ToUpper().Trim() == elementName.ToUpper().Trim()
                        select s;
            if (query.Count() > 0)
            {
                columnValue = query.ToList()[0].Column3.ToString();
            }
            return columnValue;
        }
    }
}