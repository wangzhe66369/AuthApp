﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   WastePacageCheckController.cs
 *   描    述   ：   废物包申报认定控制器
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-18 18:45:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-18 18:45:00    1.0.0.0     PXMWSWG       初版　 
 *    
 *
 *   
 *    
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View.EquipManage;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.DomainObjects.View.WastePackageCheck;
using MvcContrib.UI.Grid;
using RWIS.Presentation.Web.Core;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels;
using RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Presentation.Web.Core.Ftp;
using NET01.CoreFramework;
using NPOI.HSSF.UserModel;
using NPOI.SS.Util;
using NPOI.HPSF;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using System.IO;
using CIT.UPC.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using CIT.UPC.Domain.DomainObjects;
using System.Configuration;
using NET01.CoreFramework.Mail;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck.Controllers
{
    public class DeclareConfirmController : Controller
    {
        IDispiteConfirmRepository _DispiteConfirmRepository;
        INuclearApproveDetailRepository _NuclearApproveDetailRepository;
        IMaterialInputRepository _MaterialInputRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearProcessApplyRepository _NuclearProcessApplyRepository;
        IDispsiteCheckRepository _DispsiteCheckRepository;
        IDispsiteCheckDetailRepository _DispsiteCheckDetailRepository;
        IDispsiteApproveRepository _DispsiteApproveRepository;
        INuclearApplyDetailRepository _NuclearApplyDetailRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        INuclearBucketCheckRepository _NuclearBucketCheckRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        INuclearBucketChangeRepository _NuclearBucketChangeRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        INuclearCoverMetalRepository _NuclearCoverMetalRepository;
        INuclearBucketSolutionRepository _NuclearBucketSolutionRepository;
        INuclearBucketResinRepository _NuclearBucketResinRepository;
        INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository;
        INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository;
        INuclearCoverMixRepository _NuclearCoverMixRepository;
        INuclearQtTransRepository _NuclearQtTransRepository;
        INuclearFcTransRepository _NuclearFcTransRepository;
        INuclearTsGoodsInRepository _NuclearTsGoodsInRepository;
        INuclearTsGoodsOutRepository _NuclearTsGoodsOutRepository;
        public DeclareConfirmController(INuclearProcessApplyRepository NuclearProcessApplyRepository
            , INuclearBucketRepository _NuclearBucketRepository
            , IBasicObjectRepository _BasicObjectRepository
            , IDispsiteCheckRepository _DispsiteCheckRepository
            , IDispsiteCheckDetailRepository _DispsiteCheckDetailRepository,
            IDispsiteApproveRepository _DispsiteApproveRepository,
            INuclearApplyDetailRepository _NuclearApplyDetailRepository,
            INuclearWastePackageRepository _NuclearWastePackageRepository,
            IMaterialInputRepository _MaterialInputRepository,
            INuclearBucketCheckRepository _NuclearBucketCheckRepository,
            INuclearApproveDetailRepository _NuclearApproveDetailRepository,
            IDispiteConfirmRepository _DispiteConfirmRepository,
            IBasicWasteUnitRepository _BasicWasteUnitRepository,
            INuclearBucketChangeRepository _NuclearBucketChangeRepository,
            IMaterialTypeRepository _MaterialTypeRepository,
            INuclearCoverMetalRepository _NuclearCoverMetalRepository, 
            INuclearBucketSolutionRepository NuclearBucketSolutionRepository
            , INuclearBucketResinRepository NuclearBucketResinRepository
            , INuclearBucketRSolidifyRepository NuclearBucketRSolidifyRepository
            , INuclearBucketSSolidifyRepository NuclearBucketSSolidifyRepository
            , INuclearCoverMetalRepository NuclearCoverMetalRepository
            , INuclearCoverMixRepository NuclearCoverMixRepository
            , INuclearQtTransRepository NuclearQtTransRepository
            , INuclearFcTransRepository NuclearFcTransRepository
            ,INuclearTsGoodsInRepository NuclearTsGoodsInRepository
             ,INuclearTsGoodsOutRepository NuclearTsGoodsOutRepository
            )
        {
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearProcessApplyRepository = NuclearProcessApplyRepository;
            this._DispsiteCheckRepository = _DispsiteCheckRepository;
            this._DispsiteCheckDetailRepository = _DispsiteCheckDetailRepository;
            this._DispsiteApproveRepository = _DispsiteApproveRepository;
            this._NuclearApplyDetailRepository = _NuclearApplyDetailRepository;
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
            this._MaterialInputRepository = _MaterialInputRepository;
            this._NuclearBucketCheckRepository = _NuclearBucketCheckRepository;
            this._NuclearApproveDetailRepository = _NuclearApproveDetailRepository;
            this._DispiteConfirmRepository = _DispiteConfirmRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
            this._NuclearBucketChangeRepository = _NuclearBucketChangeRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._NuclearCoverMetalRepository = _NuclearCoverMetalRepository;
            this._NuclearBucketSolutionRepository = NuclearBucketSolutionRepository;
            this._NuclearBucketResinRepository = NuclearBucketResinRepository;
            this._NuclearBucketRSolidifyRepository = NuclearBucketRSolidifyRepository;
            this._NuclearBucketSSolidifyRepository = NuclearBucketSSolidifyRepository;
            this._NuclearCoverMetalRepository = NuclearCoverMetalRepository;
            this._NuclearCoverMixRepository = NuclearCoverMixRepository;
            this._NuclearQtTransRepository = NuclearQtTransRepository;
            this._NuclearFcTransRepository = NuclearFcTransRepository;
            this._NuclearTsGoodsInRepository = NuclearTsGoodsInRepository;
            this._NuclearTsGoodsOutRepository = NuclearTsGoodsOutRepository;
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物包申报认定")]
        public ActionResult Index()
        {
            return View();
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物包申报认定详细信息页面")]
        public ActionResult DeclareConfirm(string processApplyId)
        {
            ViewBag.ProcessApplyId = processApplyId;
            DeclareConfirmVM vm = new DeclareConfirmVM();
            //DispsiteCheck dispsiteCheck = _DispsiteCheckRepository.Get(processApplyId);
            NuclearProcessApply model = _NuclearProcessApplyRepository.Get(processApplyId);
            IQueryable<DispsiteCheck> dispsiteCheckQuery = _DispsiteApproveRepository.QueryListById(processApplyId);
            foreach (var item in dispsiteCheckQuery)
            {
                DispsiteCheck dispsiteCheck = new DispsiteCheck();
                dispsiteCheck.CheckId = item.CheckId;
                vm.DispsiteCheck = dispsiteCheck;
                IQueryable<DispsiteApprove> dispsiteApproveQuery = _DispsiteApproveRepository.QueryListByCheckId(item.CheckId);
                foreach (var items in dispsiteApproveQuery)
                {
                    DispsiteApprove dispsiteApprove = _DispsiteApproveRepository.Get(items.ApproveId);
                    vm.DispsiteApprove = dispsiteApprove;
                    vm.DeclareDate = dispsiteApprove.DeclareDate;
                    vm.IdentityCode = dispsiteApprove.IdentityCode;
                    vm.CheckDescription = dispsiteApprove.CheckDescription;
                    vm.PriceOpinion = dispsiteApprove.PriceOpinion;
                }
            }
            BasicObject basicObjectProcessFactoryId = _BasicObjectRepository.Get(model.ProcessFactoryId);
            BasicObject basicObjectStoragePositionId = _BasicObjectRepository.Get(model.StoragePositionId);
            vm.ProcessFactoryId = basicObjectProcessFactoryId.Name;
            vm.StoragePositionId = basicObjectStoragePositionId.Name;
            model.ProcessApplyId = processApplyId;
            vm.NuclearProcessApply = model;
            ViewBag.ApplyDate = model.ApplyDate.HasValue?model.ApplyDate.Value.ToString("yyyy-MM-dd"):string.Empty;
            //加载电站
            IQueryable<BasicWasteUnit> basicWasteUnit = _DispsiteApproveRepository.QueryListByStationCode(AppContext.CurrentUser.ProjectCode);
            foreach (var item in basicWasteUnit)
            {
                vm.StationCode = item.UnitName;
            }
            //IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            //IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(processApplyId, "QuestionReport");
            
            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(processApplyId, "DispsiteApprove");
            vm.ApproveReportFileList = (List<AttachFile>)listAttachFile;
            ViewBag.BusinessType = "DispsiteApprove";

            IList<AttachFile> listAttachFiles = _attachFileRepository.GetAttachFileBy(processApplyId, "DispsiteCheck");
            vm.CheckReportFileList = (List<AttachFile>)listAttachFiles;
            ViewBag.BusinessType = "DispsiteCheck";

            IList<AttachFile> listAttachFilees = _attachFileRepository.GetAttachFileBy(processApplyId, "DisposeApply");
            vm.AttachFiles = (List<AttachFile>)listAttachFilees;
            ViewBag.BusinessType = "DisposeApply";
            return View(vm);
        }
        public ActionResult DetailView(string processApplyId)
        {
            ViewBag.ProcessApplyId = processApplyId;
            DeclareConfirmVM vm = new DeclareConfirmVM();
            //DispsiteCheck dispsiteCheck = _DispsiteCheckRepository.Get(processApplyId);
            NuclearProcessApply model = _NuclearProcessApplyRepository.Get(processApplyId);
            IQueryable<DispsiteCheck> dispsiteCheckQuery = _DispsiteApproveRepository.QueryListById(processApplyId);
            foreach (var item in dispsiteCheckQuery)
            {
                DispsiteCheck dispsiteCheck = new DispsiteCheck();
                dispsiteCheck.CheckId = item.CheckId;
                vm.DispsiteCheck = dispsiteCheck;
                IQueryable<DispsiteApprove> dispsiteApproveQuery = _DispsiteApproveRepository.QueryListByCheckId(item.CheckId);
                foreach (var items in dispsiteApproveQuery)
                {
                    DispsiteApprove dispsiteApprove = _DispsiteApproveRepository.Get(items.ApproveId);
                    vm.DispsiteApprove = dispsiteApprove;
                    vm.DeclareDate = dispsiteApprove.DeclareDate;
                    vm.CheckDescription = dispsiteApprove.CheckDescription;
                    vm.PriceOpinion = dispsiteApprove.PriceOpinion;
                    vm.IdentityCode = dispsiteApprove.IdentityCode;

                }
            }
            if (model != null)
            {
                BasicObject basicObjectProcessFactoryId = _BasicObjectRepository.Get(model.ProcessFactoryId);
                BasicObject basicObjectStoragePositionId = _BasicObjectRepository.Get(model.StoragePositionId);
                if (basicObjectProcessFactoryId != null)
                {
                    vm.ProcessFactoryId = basicObjectProcessFactoryId.Name;
                }
                else
                {
                    vm.ProcessFactoryId = "";
                }
                if (basicObjectStoragePositionId != null)
                {
                    vm.StoragePositionId = basicObjectStoragePositionId.Name;
                }
                else
                {
                    vm.StoragePositionId = "";
                }
            }
            model.ProcessApplyId = processApplyId;
            vm.NuclearProcessApply = model;

            //加载电站
            IQueryable<BasicWasteUnit> basicWasteUnit = _DispsiteApproveRepository.QueryListByStationCode(AppContext.CurrentUser.ProjectCode);
            foreach (var item in basicWasteUnit)
            {
                vm.StationCode = item.UnitName;
            }
            //IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            //IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(processApplyId, "QuestionReport");

            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(processApplyId, "DispsiteCheck");
            vm.ApproveReportFileList = (List<AttachFile>)listAttachFile;
            ViewBag.BusinessType = "DispsiteCheck";

            IList<AttachFile> listAttachFiles = _attachFileRepository.GetAttachFileBy(processApplyId, "QuestionReport");
            vm.CheckReportFileList = (List<AttachFile>)listAttachFiles;
            ViewBag.BusinessType = "QuestionReport";

            IList<AttachFile> listAttachFilees = _attachFileRepository.GetAttachFileBy(processApplyId, "DisposeApply");
            vm.AttachFiles = (List<AttachFile>)listAttachFilees;
            ViewBag.BusinessType = "DisposeApply";
            return View("DetailView", vm);
        }
        /// <summary>
        /// 废物包列表页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物包列表页面")]
        public ActionResult WastePackageList(string processApplyId, string wasteType, string dealMethod, string materialName)
        {
            WastePackageCheckVM vm = new WastePackageCheckVM();
            NuclearProcessApply nuclearProcessApply = new NuclearProcessApply();
            IQueryable<NuclearApplyDetail> nuclearApplyDetail = _NuclearApplyDetailRepository.GetAll().Where(d => d.ProcessApplyId == processApplyId).AsQueryable();
            foreach (var item in nuclearApplyDetail)
            {
                vm.ApplyDetailId = item.ApplyDetailId;
                nuclearProcessApply.ProcessApplyId = item.ProcessApplyId;
            }
            vm.WasteType = wasteType;
            vm.DealMethod = dealMethod;
            vm.MaterialName = materialName;
            //nuclearProcessApply.ProcessApplyId = nuclearApplyDetail.ProcessApplyId;
            vm.NuclearProcessApply = nuclearProcessApply;
            //vm.ApplyDetailId = applyDetailId;
            return View("WastePackageList",vm);
        }

        /// <summary>
        /// 废物包审核页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物包审核页面")]
        public ActionResult WastePackageCheck(string bucketId, string applyDetailId)
        {
            WastePackageCheckVM vm = new WastePackageCheckVM();
            NuclearApplyDetail nuclearApplyDetail = new NuclearApplyDetail();
            nuclearApplyDetail.ApplyDetailId = applyDetailId;
            vm.NuclearApplyDetail = nuclearApplyDetail;
            NuclearApplyDetail applyDetail = _NuclearApplyDetailRepository.Get(applyDetailId);
            NuclearProcessApply nuclearProcessApply = new NuclearProcessApply();
            nuclearProcessApply.ProcessApplyId = applyDetail.ProcessApplyId;
            vm.NuclearProcessApply = nuclearProcessApply;
            NuclearBucket nuclearBucket = this._NuclearBucketRepository.Get(bucketId);
            if (nuclearBucket != null)
            {
                vm.WasteType = nuclearBucket.WasteType;
                vm.DealMethod = nuclearBucket.DealMethod;
            
            }

            MaterialType materialType = this._MaterialTypeRepository.Get(nuclearBucket.MaterialId);
            vm.MaterialName = materialType.MaterialName;
            List<SelectListItem> checkList = new List<SelectListItem>();
            checkList.Add(new SelectListItem { Text = "否", Value = "1", Selected = true });
            checkList.Add(new SelectListItem { Text = "是", Value = "2" });
            checkList.Add(new SelectListItem { Text = "请选择", Value = "" });
            vm.CheckMaterialList = checkList;
            vm.CheckBucketAduitList = checkList;
            vm.EvaluateList = checkList;
            vm.CheckBucketMesList = checkList;
            vm.CheckBucketDealList = checkList;
            vm.CheckBucketCoverList = checkList;
            vm.CheckBucketTransferList = checkList;
            vm.ApplyDetailId = applyDetailId;
            ViewBag.ApplyDetailId = applyDetailId;
            //桶入库材料信息
            vm.MaterialInputVM = GetMaterialInput(bucketId);

            //桶检查信息
            vm.NuclearBucketCheck = GetNuclearBucketCheck(bucketId);
            if (vm.NuclearBucketCheck == null)
            {
                vm.NuclearBucketCheck = new NuclearBucketCheck();
            }
            IQueryable<NuclearApplyDetail> nuclearApplyDetails = this._NuclearApplyDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == applyDetailId);
            foreach (var item in nuclearApplyDetails)
            {
                IQueryable<NuclearBucketCheck> nuclearBucketChecks = this._NuclearBucketCheckRepository.GetAll().AsQueryable().Where(c => c.BucketId == item.BucketId);
                foreach (var items in nuclearBucketChecks)
                {
                    vm.TechStandard = items.TechStandard;
                }
                IQueryable<NuclearBucketChange> nuclearBucketChanges = this._NuclearBucketChangeRepository.GetAll().AsQueryable().Where(c => c.BucketId == item.BucketId);
                foreach (var itemes in nuclearBucketChanges)
                {
                    IQueryable<MaterialInput> materialInput = this._MaterialInputRepository.GetAll().AsQueryable().Where(c => c.InputId == itemes.BusinessId);
                    foreach (var itemd in materialInput)
                    {
                        vm.HasLining = itemd.HasLining;
                    }
                    
                }
            }
            //桶信息
            vm.NuclearBucket = this._NuclearBucketRepository.Get(bucketId);
            if (vm.NuclearBucket == null)
            {
                vm.NuclearBucket = new NuclearBucket();
            }

            //存储和转运信息
            vm.IsExistTransferAndStorage = WasteCheckBuilder.IsExistTransferAndStorage(bucketId);

            //审核明细信息
            IQueryable<DispsiteCheckDetail> dispsiteCheckDetail = this._DispsiteCheckDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == applyDetailId);
            if (dispsiteCheckDetail.Count() > 0)
            {
                vm.DispsiteCheckDetail = dispsiteCheckDetail.ToList()[0];
            }
            else
            {
                vm.DispsiteCheckDetail = new DispsiteCheckDetail();
            }

            //废物包信息
            //固化、封盖、转运信息 
            var SolutionModel = _NuclearBucketSolutionRepository.GetModelByBucketId(bucketId);
            var ResinModel = _NuclearBucketResinRepository.GetModelByBucketId(bucketId);
            var RSolidifyModel = _NuclearBucketRSolidifyRepository.GetModelByBucketId(bucketId);
            var SSolidifyModel = _NuclearBucketSSolidifyRepository.GetModelByBucketId(bucketId);
            var MetaModel = _NuclearCoverMetalRepository.GetModelByBucketId(bucketId);
            var MixModel = _NuclearCoverMixRepository.GetModelByBucketId(bucketId);
            var QtTransModel = _NuclearQtTransRepository.GetModelByBucketId(bucketId);
            var FcTransModel = _NuclearFcTransRepository.GetModelByBucketId(bucketId);
            var GoodsInModel = _NuclearTsGoodsInRepository.GetModelByBucketId(bucketId);
            var GoodsOutModel = _NuclearTsGoodsOutRepository.GetModelByBucketId(bucketId);
            if (SolutionModel != null)
                vm.SolutionId = SolutionModel.SolutionId;
            if (ResinModel != null)
                vm.ResinId = ResinModel.ResinId;
            if (RSolidifyModel != null)
                vm.RSolidifyId = RSolidifyModel.SolidifyRId;
            if (SSolidifyModel != null)
                vm.SSolidifyId = SSolidifyModel.SolidifySIdd;
            if (MetaModel != null)
                vm.MetalId = MetaModel.MetalId;
            if (MixModel != null)
                vm.MixId = MixModel.MixId;
            if (QtTransModel != null)
                vm.QtTransId = QtTransModel.QtTransId;
            if (FcTransModel != null)
                vm.FcTransId = FcTransModel.FcDetailId;
            if (GoodsInModel != null)
                vm.GoodsInId = GoodsInModel.GoodsInDetailId;
            if (GoodsOutModel != null)
                vm.GoodsOutId = GoodsOutModel.GoodsOutDetailId;
            return View(vm);
        }
        /// <summary>
        /// 得到桶入库信息
        /// </summary>
        /// <param name="bucketId"></param>
        /// <returns></returns>
        public MaterialInputVM GetMaterialInput(string bucketId)
        {
            MaterialInputVM vm = new MaterialInputVM();
            IQueryable<MaterialInputVM> iqueryMaterialInput = WasteCheckBuilder.GetMaterialInput(bucketId);
            if (iqueryMaterialInput.Count() > 0)
            {
                vm = iqueryMaterialInput.ToList()[0];
            }
            return vm;

        }
        /// <summary>
        /// 得到桶检查信息
        /// </summary>
        /// <param name="bucketId">桶ID</param>
        /// <returns></returns>
        public NuclearBucketCheck GetNuclearBucketCheck(string bucketId)
        {
            NuclearBucketCheck bucketCheck = new NuclearBucketCheck();
            IQueryable<NuclearBucketCheck> iqueryBucketCheck = _NuclearBucketCheckRepository.GetBucketCheckByBucketId(bucketId);
            if (iqueryBucketCheck.Count() > 0)
            {
                bucketCheck = iqueryBucketCheck.ToList()[0];

            }
            return bucketCheck;
        }

        #region 页面
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetDataList(DispsiteCheckCondition dispsiteCheckCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<DispsiteApproveView> data = this._DispsiteApproveRepository.QueryList(dispsiteCheckCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode); 
            //绑定前台JqGrid参数.Where(d => d.Status == "2")
            var pagedViewModel = new PagedViewModel<DispsiteApproveView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ProcessApplyId,
                    List = new List<object>() {
                    d.ProcessApplyId,
                    //d.ApplyDetailId,
                    d.ApplyCode,
                    d.PackageSum,
                    d.IdentityCode,
                    d.StoragePositionId,
                    d.TransFlag,
                    d.ApplyDate.HasValue? d.ApplyDate.Value.ToString("yyyy-MM-dd"):string.Empty,   
                    d.ApplyName,
                    d.Attachment,
                    d.Status,
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetWastePackageInfoList(string processApplyId, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearApplyDetailView> data = this._DispsiteCheckRepository.QueryListById(processApplyId).Where(d => d.ProcessApplyId == processApplyId).AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearApplyDetailView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.WasteType,
                    List = new List<object>() {
                    //d.ApplyDetailId,
                    d.WasteType,
                    d.DealMethod,
                    d.MaterialName,
                    d.UnCheckedCount, 
                    d.CheckedCount, 
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetWastePackageList(DispsiteCheckCondition dispsiteCheckCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet }; 
            //获取数据
            IQueryable<DispsiteApproveDetailView> data = this._DispsiteApproveRepository.QueryWastePackageList(dispsiteCheckCondition);//.Where(d => d.WasteType == dispsiteCheckCondition.WasteType && d.DealMethod == dispsiteCheckCondition.DealMethod && d.MaterialName == dispsiteCheckCondition.MaterialName);
            if (!string.IsNullOrEmpty(dispsiteCheckCondition.WasteType) && dispsiteCheckCondition.WasteType != "null")
            {
                data = data.Where(d => d.WasteType == dispsiteCheckCondition.WasteType);
            }
            if (!string.IsNullOrEmpty(dispsiteCheckCondition.DealMethod) && dispsiteCheckCondition.DealMethod != "null")
            {
                data = data.Where(d => d.DealMethod == dispsiteCheckCondition.DealMethod);
            }
            if (!string.IsNullOrEmpty(dispsiteCheckCondition.MaterialName))
            {
                data = data.Where(d => d.MaterialName == dispsiteCheckCondition.MaterialName);
            }
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<DispsiteApproveDetailView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ApplyDetailId,
                    List = new List<object>() {
                    d.ApplyDetailId,
                    d.BucketId,
                    d.WasteType,
                    d.DealMethod,
                    d.MaterialName,
                    d.PackageCode,
                    d.BucketCode,
                    d.TechStandard,
                    d.HasLining, 
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetWastePackageCode(string processApplyId, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<DispsiteApproveDetailView> data = this._DispsiteApproveRepository.QueryListWastePackageCode(processApplyId);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<DispsiteApproveDetailView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.PackageId,
                    List = new List<object>() {
                    d.PackageId,
                    d.PackageCode
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetUnApproveWastePackageCode(string processApplyId, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<DispsiteApproveDetailView> data = this._DispsiteApproveRepository.QueryUnApproveWastePackageCode(processApplyId);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<DispsiteApproveDetailView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.PackageId,
                    List = new List<object>() {
                    d.PackageId,
                    d.PackageCode
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        #endregion

        /// <summary>
        /// 是否存在废物包号
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public JsonResult IsExisPackageCode(string packageCode)
        {

            try
            {
                IQueryable<NuclearWastePackage> packageIdQuery = this._DispsiteApproveRepository.QueryListByCode(packageCode);
                foreach (var item in packageIdQuery)
                {
                    NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(item.PackageId);
                    if (nuclearWastePackage.Status == "CHECKED")
                    {
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                //return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                return Json("{\"result\":false,\"msg\":\"该废物包号没有经过审核。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认废物包审核信息
        /// </summary>
        /// <param name="vm">废物包审核信息</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物包申报认定确认")]
        public JsonResult Save(DeclareConfirmVM vm, FormCollection formCollection)
        {
            try
            {
                //新增或修改审批信息
                if (vm.DispsiteApprove.ApproveId == null)
                {
                    vm.DispsiteApprove.ApproveId = Guid.NewGuid().ToString();
                    IQueryable<DispsiteCheck> checkIdQuery = _DispsiteApproveRepository.QueryListByApplyId(vm.NuclearProcessApply.ProcessApplyId);
                    foreach (var item in checkIdQuery)
                    {
                        vm.DispsiteApprove.ChekcId = item.CheckId;
                    }
                    vm.DispsiteApprove.IdentityCode = DateTime.Now.ToString("yyyyMMdd");
                    vm.DispsiteApprove.ApproveDate = DateTime.Now;
                    vm.DispsiteApprove.ApproveUserName = AppContext.CurrentUser.UserName;
                    vm.DispsiteApprove.ApproveUserNo = AppContext.CurrentUser.UserId;
                    vm.DispsiteApprove.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._DispsiteApproveRepository.Create(vm.DispsiteApprove);
                    this._DispsiteCheckRepository.UnitOfWork.Commit();
                }
                else {
                    DispsiteApprove dispsiteApprove = this._DispsiteApproveRepository.Get(vm.DispsiteApprove.ApproveId);
                    dispsiteApprove.DeclareDate = vm.DispsiteApprove.DeclareDate;
                    dispsiteApprove.CheckDescription = vm.DispsiteApprove.CheckDescription;
                    dispsiteApprove.PriceOpinion = vm.DispsiteApprove.PriceOpinion;
                    this._DispsiteApproveRepository.Update(dispsiteApprove);
                }                
                //新增废物包审批单明细与更新废物包状态
                if (!string.IsNullOrEmpty(vm.PackageCodes))
                {
                    string[] arrPackageCodesList = vm.PackageCodes.Split(',');
                    foreach (var item in arrPackageCodesList)
	                {
                        //NuclearWastePackage nuclearWastePackage = new NuclearWastePackage();
                        IQueryable<NuclearWastePackage> packageIdQuery = this._NuclearWastePackageRepository.GetAll().Where(d=>d.PackageCode==item&&d.Stationcode==AppContext.CurrentUser.ProjectCode).AsQueryable();
                        foreach (var itemQuery in packageIdQuery)
                        {
                            if (itemQuery.Status != "APPLIED" && itemQuery.Status != "RECEPTED" && itemQuery.Status != "DEALED") 
                            { 
                                NuclearApproveDetail nuclearApproveDetail = new NuclearApproveDetail();
                                nuclearApproveDetail.ApproveDetailId = Guid.NewGuid().ToString();
                                nuclearApproveDetail.ApproveId = vm.DispsiteApprove.ApproveId;
                                nuclearApproveDetail.PackageId = itemQuery.PackageId;
                                this._NuclearApproveDetailRepository.Create(nuclearApproveDetail);
                                itemQuery.Status = "APPLIED";
                                //更新处置申请单明细状态
                                IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == itemQuery.BucketId).AsQueryable();
                                foreach (var itemDetail in nuclearApplyDetailQuery)
                                {
                                    //NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.Get(itemDetail.ApplyDetailId);
                                    itemDetail.Status = "2";
                                    this._NuclearApplyDetailRepository.Update(itemDetail);
                                }
                                this._NuclearWastePackageRepository.Update(itemQuery);
                            }
                        }
                        IQueryable<NuclearApplyDetail> nuclearApplyDetail = _NuclearApplyDetailRepository.GetAll().Where(d => d.ProcessApplyId == vm.NuclearProcessApply.ProcessApplyId).AsQueryable();
                        bool isCompleted = true;
                        foreach (var items in nuclearApplyDetail)
                        {
                            IQueryable<NuclearWastePackage> nuclearWastePackage = this._NuclearWastePackageRepository.GetAll().Where(d => d.BucketId == items.BucketId ).AsQueryable();
                            
                            foreach (var itemd in nuclearWastePackage)
                            {
                                //更新废物审批信息
                                if (itemd.Status == "CHECKED")
                                {
                                    DispsiteApprove dispsiteApprove = _DispsiteApproveRepository.Get(vm.DispsiteApprove.ApproveId);
                                    if (dispsiteApprove != null)
                                    {
                                        dispsiteApprove.Status = "0";
                                        _DispsiteApproveRepository.Update(dispsiteApprove);
                                    }
                                    isCompleted = false;
                                    break;
                                }
                            }
                        }
                        if (isCompleted)
                        {
                            DispsiteApprove dispsiteApprove = _DispsiteApproveRepository.Get(vm.DispsiteApprove.ApproveId);
                            if (dispsiteApprove != null)
                            {
                                dispsiteApprove.Status = "1";
                                _DispsiteApproveRepository.Update(dispsiteApprove);
                            }
                        }
	                }
                    List<NuclearWastePackage> nuclearWastePackages = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == arrPackageCodesList[0] && d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable().ToList();
                    List<NuclearApplyDetail> nuclearApplyDetails = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == nuclearWastePackages[0].BucketId).AsQueryable().ToList();
                    NuclearProcessApply nuclearProcessApply = _NuclearProcessApplyRepository.Get(vm.NuclearProcessApply.ProcessApplyId);
                    List<DispsiteCheck> dispsiteCheck = _DispsiteApproveRepository.QueryListByApplyId(vm.NuclearProcessApply.ProcessApplyId).ToList();
                    //发送邮件提醒
                    NuclearProcessApply nuclearProcessApplyQuery = _NuclearProcessApplyRepository.Get(nuclearApplyDetails[0].ProcessApplyId);
                    string copyUsers = string.Empty;
                    NET01.CoreFramework.Mail.ISmtpClient smtpClent = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<NET01.CoreFramework.Mail.ISmtpClient>();
                    var mailService = new RWIS.Application.Implementation.MailService(smtpClent);
                    string sendTitle = string.Format("废物包申报认定通知");
                    string systemAddress = ConfigurationManager.AppSettings["SystemAddress"];
                    string sendContent = "您好！" + "<br/>" + "&nbsp;" + vm.DispsiteApprove.ApproveUserName + "[" + vm.DispsiteApprove.ApproveUserNo + "]在" + DateTime.Now + "进行了申报认定，申报单号是：" + nuclearProcessApply.ApplyCode + "，请点击" + "<a href=" + systemAddress + ">处置申请列表</a>" + "进入系统进行确认，谢谢！"
                       + "<br/>" + "&nbsp;" + "<table cellpadding='0' cellspacing='0' border='1'>" + "<tr>" + "<th>流程名称</th>" + "<td>" + "<font color='#0000FF'>废物包申报认定</font>" + "</td>" + "</tr>" +
                       "<tr>" + "<th>工作主题</th>" + "<td>" + "<font color='#0000FF'>对申报单号为</font>" + "<font color='#0000FF'>" + nuclearProcessApply.ApplyCode + "</font>" + "<font color='#0000FF'>进行申报认定</font>" + "</td>" + "</tr>" +
                       "<tr>" + "<th>审批意见</th>" + "<td>" + "<font color='#0000FF'>" + vm.DispsiteApprove.PriceOpinion + "</font>" + "</td>" + "</tr>" +
                       "<tr>" + "<th>认定的废物货包清单</th>" + "<td>" + "<font color='#0000FF'>" + vm.PackageCodes + "</font>" + "</td>" + "</tr>" +
                       "</table>";
                    mailService.SendMailService(nuclearProcessApplyQuery.ApplyNo, copyUsers, sendTitle, sendContent);
                }
                //提交
                this._DispsiteCheckRepository.UnitOfWork.Commit();
                this.SaveAttachFile(vm.NuclearProcessApply.ProcessApplyId, "UploadDispsiteCheck", formCollection);
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":true,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #region 上传附件
        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], "DispsiteApprove");
            }
            return null;
        }
        /// <summary>
        /// 下载文件
        /// 
        /// </summary>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }
        #endregion

        #region 将文件输出到页面
        /// <summary>
        /// 导出运输单
        /// </summary>
        /// <param name="outputId">出库单ID</param>
        /// <returns></returns>
        [HttpGet]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "运输单导出")]
        public ActionResult PrintRubTransfer(DeclareConfirmVM vm, FormCollection formCollection)
        {
            string[] arrPackageCodesList = vm.PackageCodes.Split(',');
            //创建文档对象
            HSSFWorkbook hssfworkbook = new HSSFWorkbook();
            //然后创建DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();
            dsi.Company = "NPOI Team";
            // 再创建SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Subject = "NPOI SDK Example";

            // 创建好的对象赋给Workbook 保证这些信息被写入文件。
            hssfworkbook.DocumentSummaryInformation = dsi;
            hssfworkbook.SummaryInformation = si;
             #region 编辑excel1
            //创建工作表
            HSSFSheet sheet1 = (HSSFSheet)hssfworkbook.CreateSheet("Sheet1");
            //创建行
            HSSFRow row1 = (HSSFRow)sheet1.CreateRow(0);
            HSSFRow row2 = (HSSFRow)sheet1.CreateRow(1);
            HSSFRow row3 = (HSSFRow)sheet1.CreateRow(2);
            HSSFRow row4 = (HSSFRow)sheet1.CreateRow(3);
            HSSFRow row5 = (HSSFRow)sheet1.CreateRow(4);
            HSSFRow row6 = (HSSFRow)sheet1.CreateRow(5);
            HSSFRow row7 = (HSSFRow)sheet1.CreateRow(6);
            HSSFRow row8 = (HSSFRow)sheet1.CreateRow(7);
            HSSFRow row9 = (HSSFRow)sheet1.CreateRow(8);
            HSSFRow row10 = (HSSFRow)sheet1.CreateRow(9);
            HSSFRow row11 = (HSSFRow)sheet1.CreateRow(10);
            HSSFRow row12 = (HSSFRow)sheet1.CreateRow(11);
            HSSFRow row13 = (HSSFRow)sheet1.CreateRow(12);
            HSSFRow row14 = (HSSFRow)sheet1.CreateRow(13);
            HSSFRow row15 = (HSSFRow)sheet1.CreateRow(14);
            HSSFRow row16 = (HSSFRow)sheet1.CreateRow(15);
            HSSFRow row17 = (HSSFRow)sheet1.CreateRow(16);
            HSSFRow row18 = (HSSFRow)sheet1.CreateRow(17);
            HSSFRow row19 = (HSSFRow)sheet1.CreateRow(18);
            HSSFRow row20 = (HSSFRow)sheet1.CreateRow(19);
            HSSFRow row21 = (HSSFRow)sheet1.CreateRow(20);
            HSSFRow row22 = (HSSFRow)sheet1.CreateRow(21);
            HSSFRow row23 = (HSSFRow)sheet1.CreateRow(22);
            HSSFRow row24 = (HSSFRow)sheet1.CreateRow(23);
            HSSFRow row25 = (HSSFRow)sheet1.CreateRow(24);
            HSSFRow row26 = (HSSFRow)sheet1.CreateRow(25);
            HSSFRow row27 = (HSSFRow)sheet1.CreateRow(26);
            HSSFRow row28 = (HSSFRow)sheet1.CreateRow(27);
            HSSFRow row29 = (HSSFRow)sheet1.CreateRow(28);
            HSSFRow row30 = (HSSFRow)sheet1.CreateRow(29);

            int counts = 0;
            int j = 1;
            if (arrPackageCodesList.Count() % 3 == 0)
            {
                counts = arrPackageCodesList.Count()/3;
            }
            if (arrPackageCodesList.Count() % 3 > 0)
            {
                counts = arrPackageCodesList.Count()/3 + 1;
            }
            for (int i = 1; i <= counts; i++)
            {
                HSSFRow row = (HSSFRow)sheet1.CreateRow(i + 29);
                sheet1.CreateRow(i + 29).Height = 40 * 20;
                HSSFCell cell0000 = (HSSFCell)row.CreateCell(0);
                HSSFCell cell0001 = (HSSFCell)row.CreateCell(1);
                HSSFCell cell0002 = (HSSFCell)row.CreateCell(2);
                HSSFCell cell0003 = (HSSFCell)row.CreateCell(3);
                HSSFCell cell0004 = (HSSFCell)row.CreateCell(4);
                HSSFCell cell0005 = (HSSFCell)row.CreateCell(5);
                HSSFCell cell0006 = (HSSFCell)row.CreateCell(6);
                HSSFCell cell0007 = (HSSFCell)row.CreateCell(7);
                HSSFCell cell0008 = (HSSFCell)row.CreateCell(8);
                HSSFCell cell0009 = (HSSFCell)row.CreateCell(9);
                HSSFCell cell0010 = (HSSFCell)row.CreateCell(10);
                HSSFCell cell0011 = (HSSFCell)row.CreateCell(11);
                sheet1.AddMergedRegion(new CellRangeAddress(i + 29, i + 29, 3, 4));
                sheet1.AddMergedRegion(new CellRangeAddress(i + 29, i + 29, 6, 7));
                sheet1.AddMergedRegion(new CellRangeAddress(i + 29, i + 29, 9, 10));
                //单元格样式——文本
                HSSFCellStyle style2s = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style2s.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
                style2s.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                style2s.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                style2s.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
                style2s.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                style2s.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
                HSSFFont font2s = (HSSFFont)hssfworkbook.CreateFont();
                font2s.FontHeight = 15 * 20;//字体高度
                style2s.SetFont(font2s);

                //单元格样式——二级标题 无边框
                HSSFCellStyle style311s = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style311s.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
                style311s.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                HSSFFont font311s = (HSSFFont)hssfworkbook.CreateFont();
                font311s.FontHeight = 22 * 20;//字体高度
                style311s.SetFont(font311s);

                //单元格样式——一级标题 右
                HSSFCellStyle stylers = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                stylers.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;

                cell0000.CellStyle = style2s;
                cell0001.CellStyle = style311s;
                cell0002.CellStyle = style2s;
                cell0003.CellStyle = style2s;
                cell0004.CellStyle = style2s;
                cell0005.CellStyle = style2s;
                cell0006.CellStyle = style2s;
                cell0007.CellStyle = style2s;
                cell0008.CellStyle = style2s;
                cell0009.CellStyle = style2s;
                cell0010.CellStyle = style2s;
                cell0011.CellStyle = stylers;

                if (j <= arrPackageCodesList.Count())
                {
                    j = j + 1;
                    if (j <= arrPackageCodesList.Count())
                    {
                        j = j + 1;
                        if (j <= arrPackageCodesList.Count())
                        {
                            cell0002.SetCellValue(j - 2);//设置单元格内容
                            cell0003.SetCellValue(arrPackageCodesList[j - 3]);//设置单元格内容
                            cell0004.SetCellValue(j - 1);//设置单元格内容
                            cell0005.SetCellValue(arrPackageCodesList[j - 2]);//设置单元格内容 
                            cell0006.SetCellValue(j);//设置单元格内容
                            cell0007.SetCellValue(arrPackageCodesList[j - 1]);//设置单元格内容 
                            j = j + 1;
                        }
                        else
                        {
                            cell0002.SetCellValue(j - 2);//设置单元格内容
                            cell0003.SetCellValue(arrPackageCodesList[j - 3]);//设置单元格内容
                            cell0004.SetCellValue(j - 1);//设置单元格内容
                            cell0005.SetCellValue(arrPackageCodesList[j - 2]);//设置单元格内容 
                            cell0006.SetCellValue("");//设置单元格内容
                            cell0007.SetCellValue("");//设置单元格内容 
                        }
                    }
                    else
                    {
                        cell0002.SetCellValue(j - 1);//设置单元格内容
                        cell0003.SetCellValue(arrPackageCodesList[j - 2]);//设置单元格内容
                        cell0004.SetCellValue("");//设置单元格内容
                        cell0005.SetCellValue("");//设置单元格内容 
                        cell0006.SetCellValue("");//设置单元格内容
                        cell0007.SetCellValue("");//设置单元格内容 
                    }
                }
                else
                {
                    cell0002.SetCellValue("");//设置单元格内容
                    cell0003.SetCellValue("");//设置单元格内容
                    cell0004.SetCellValue("");//设置单元格内容
                    cell0005.SetCellValue("");//设置单元格内容 
                    cell0006.SetCellValue("");//设置单元格内容
                    cell0007.SetCellValue("");//设置单元格内容 
                }

            }
            HSSFRow row43 = (HSSFRow)sheet1.CreateRow(counts + 30);
            HSSFRow row44 = (HSSFRow)sheet1.CreateRow(counts + 31);
            HSSFRow row45 = (HSSFRow)sheet1.CreateRow(counts + 32);
            HSSFRow row46 = (HSSFRow)sheet1.CreateRow(counts + 33);
            HSSFRow row47 = (HSSFRow)sheet1.CreateRow(counts + 34);
            HSSFRow row48 = (HSSFRow)sheet1.CreateRow(counts + 35);
            sheet1.CreateRow(counts + 30).Height = 60 * 20;
            sheet1.CreateRow(counts + 31).Height = 60 * 20;
            sheet1.CreateRow(counts + 32).Height = 60 * 20;
            sheet1.CreateRow(counts + 33).Height = 60 * 20;
            sheet1.CreateRow(counts + 34).Height = 60 * 20;
            sheet1.CreateRow(counts + 35).Height = 60 * 20;


            //设置列宽 
            sheet1.SetColumnWidth(0, 30 * 100);
            sheet1.SetColumnWidth(1, 10 * 100);
            sheet1.SetColumnWidth(2, 30 * 100);
            sheet1.SetColumnWidth(3, 30 * 100);
            sheet1.SetColumnWidth(4, 30 * 100);
            sheet1.SetColumnWidth(5, 30 * 100);
            sheet1.SetColumnWidth(6, 30 * 100);
            sheet1.SetColumnWidth(7, 30 * 100);
            sheet1.SetColumnWidth(8, 30 * 100);
            sheet1.SetColumnWidth(9, 30 * 100);
            sheet1.SetColumnWidth(10, 30 * 100);
            sheet1.SetColumnWidth(11, 30 * 100);
            sheet1.SetColumnWidth(12, 30 * 100);
            sheet1.SetColumnWidth(13, 30 * 100);


            //行高
            sheet1.CreateRow(0).Height = 20 * 20;
            sheet1.CreateRow(1).Height = 20 * 20;
            sheet1.CreateRow(2).Height = 30 * 20;
            sheet1.CreateRow(3).Height = 30 * 20;
            sheet1.CreateRow(4).Height = 30 * 20;
            sheet1.CreateRow(5).Height = 20 * 20;
            sheet1.CreateRow(6).Height = 20 * 20;
            sheet1.CreateRow(7).Height = 20 * 20;
            sheet1.CreateRow(8).Height = 20 * 20;
            sheet1.CreateRow(9).Height = 40 * 20;
            sheet1.CreateRow(10).Height = 40 * 20;
            sheet1.CreateRow(11).Height = 20 * 20;
            sheet1.CreateRow(12).Height = 40 * 20;
            sheet1.CreateRow(13).Height = 20 * 20;
            sheet1.CreateRow(14).Height = 40 * 20;
            sheet1.CreateRow(15).Height = 40 * 20;
            sheet1.CreateRow(16).Height = 40 * 20;
            sheet1.CreateRow(17).Height = 40 * 20;
            sheet1.CreateRow(18).Height = 40 * 20;
            sheet1.CreateRow(19).Height = 40 * 20;
            sheet1.CreateRow(20).Height = 60 * 20;
            sheet1.CreateRow(21).Height = 40 * 20;
            sheet1.CreateRow(22).Height = 40 * 20;
            sheet1.CreateRow(23).Height = 40 * 20;
            sheet1.CreateRow(24).Height = 20 * 20;
            sheet1.CreateRow(25).Height = 20 * 20;
            sheet1.CreateRow(26).Height = 10 * 20;
            sheet1.CreateRow(27).Height = 40 * 20;
            sheet1.CreateRow(28).Height = 40 * 20;
            sheet1.CreateRow(29).Height = 40 * 20;
            
            //合并单元格（起始行号、终止行号、起始列号、终止列号）
            sheet1.AddMergedRegion(new CellRangeAddress(0, 1, 0, 2));
            sheet1.AddMergedRegion(new CellRangeAddress(0, 1, 3, 8));
            sheet1.AddMergedRegion(new CellRangeAddress(0, 0, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(1, 1, 9, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(2, 2, 0, 2));
            sheet1.AddMergedRegion(new CellRangeAddress(2, 4, 3, 8));
            sheet1.AddMergedRegion(new CellRangeAddress(4, 4, 9, 11));

            sheet1.AddMergedRegion(new CellRangeAddress(5, 5, 0, 2));
            sheet1.AddMergedRegion(new CellRangeAddress(5, 5, 3, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(5, 5, 8, 9));
            sheet1.AddMergedRegion(new CellRangeAddress(5, 5, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(6, 21, 0, 0));
            sheet1.AddMergedRegion(new CellRangeAddress(6, 6, 1, 11));

            sheet1.AddMergedRegion(new CellRangeAddress(7, 12, 1, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(13, 13, 1, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(14, 19, 1, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(20, 20, 7, 10));
            sheet1.AddMergedRegion(new CellRangeAddress(21, 21, 7, 10));

            sheet1.AddMergedRegion(new CellRangeAddress(24, 25, 0, 2));
            sheet1.AddMergedRegion(new CellRangeAddress(24, 25, 3, 8));
            sheet1.AddMergedRegion(new CellRangeAddress(24, 24, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(25, 25, 9, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(27, 41, 0, 0));

            //单元格样式——一级标题
            HSSFCellStyle style = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font = (HSSFFont)hssfworkbook.CreateFont();
            font.FontHeight = 28 * 20;//字体高度
            style.SetFont(font);

            //单元格样式——文本
            HSSFCellStyle style2 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style2.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style2.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style2.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style2.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style2.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            style2.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            HSSFFont font2 = (HSSFFont)hssfworkbook.CreateFont();
            font2.FontHeight = 15 * 20;//字体高度
            style2.SetFont(font2);

            //单元格样式——二级标题
            HSSFCellStyle style3 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style3.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font3 = (HSSFFont)hssfworkbook.CreateFont();
            font3.FontHeight = 22 * 20;//字体高度
            style3.SetFont(font3);

            //创建列
            HSSFCell cell011 = (HSSFCell)row1.CreateCell(0);
            cell011.SetCellValue("GNPEP");//设置单元格内容
            HSSFCell cell012 = (HSSFCell)row1.CreateCell(3);
            cell012.SetCellValue("低中放固体废物处置申报认定程序");
            HSSFCell cell013 = (HSSFCell)row1.CreateCell(9);
            cell013.SetCellValue("版次:2");
            HSSFCell cell014 = (HSSFCell)row1.CreateCell(10);
            cell014.SetCellValue("页码:6/10");
            HSSFCell cell015 = (HSSFCell)row1.CreateCell(1);
            HSSFCell cell016 = (HSSFCell)row1.CreateCell(2);
            HSSFCell cell017 = (HSSFCell)row1.CreateCell(4);
            HSSFCell cell018 = (HSSFCell)row1.CreateCell(5);
            HSSFCell cell019 = (HSSFCell)row1.CreateCell(6);
            HSSFCell cell0110 = (HSSFCell)row1.CreateCell(7);
            HSSFCell cell0111 = (HSSFCell)row1.CreateCell(8);
            HSSFCell cell0112 = (HSSFCell)row1.CreateCell(11);
            //应用单元格样式
            cell011.CellStyle = style;
            cell012.CellStyle = style3;
            cell013.CellStyle = style2;
            cell014.CellStyle = style2;
            cell015.CellStyle = style;
            cell016.CellStyle = style;
            cell017.CellStyle = style;
            cell018.CellStyle = style;
            cell019.CellStyle = style;
            cell0110.CellStyle = style;
            cell0111.CellStyle = style;
            cell0112.CellStyle = style;

            //创建列
            HSSFCell cell021 = (HSSFCell)row2.CreateCell(9);
            cell021.SetCellValue("C/IP/OPN/020");//设置单元格内容
            HSSFCell cell022 = (HSSFCell)row2.CreateCell(0);
            HSSFCell cell025 = (HSSFCell)row2.CreateCell(1);
            HSSFCell cell026 = (HSSFCell)row2.CreateCell(2);
            HSSFCell cell023 = (HSSFCell)row2.CreateCell(3);
            HSSFCell cell027 = (HSSFCell)row2.CreateCell(4);
            HSSFCell cell028 = (HSSFCell)row2.CreateCell(5);
            HSSFCell cell029 = (HSSFCell)row2.CreateCell(6);
            HSSFCell cell0210 = (HSSFCell)row2.CreateCell(7);
            HSSFCell cell0211 = (HSSFCell)row2.CreateCell(8);
            HSSFCell cell0214 = (HSSFCell)row2.CreateCell(10);
            HSSFCell cell0212 = (HSSFCell)row2.CreateCell(11);
            //应用单元格样式
            cell022.CellStyle = style;
            cell021.CellStyle = style2;
            cell023.CellStyle = style;
            cell025.CellStyle = style;
            cell026.CellStyle = style;
            cell027.CellStyle = style;
            cell028.CellStyle = style;
            cell029.CellStyle = style;
            cell0210.CellStyle = style;
            cell0211.CellStyle = style;
            cell0212.CellStyle = style;
            cell0214.CellStyle = style;

            //单元格样式——一级标题-垂直居上
            HSSFCellStyle style4 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style4.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style4.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style4.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style4.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style4.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            style4.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font4 = (HSSFFont)hssfworkbook.CreateFont();
            font4.FontHeight = 22 * 20;//字体高度
            style4.SetFont(font4);

            //单元格样式——一级标题-垂直居中
            HSSFCellStyle style5 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style5.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style5.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style5.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style5.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style5.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            style5.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font5 = (HSSFFont)hssfworkbook.CreateFont();
            font5.FontHeight = 22 * 20;//字体高度
            style5.SetFont(font5);

            //单元格样式——文本-水平居左
            HSSFCellStyle style6 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style6.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style6.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style6.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style6.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style6.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font6 = (HSSFFont)hssfworkbook.CreateFont();
            font6.FontHeight = 15 * 20;//字体高度
            style6.SetFont(font6);

            //单元格样式——文本-水平居左
            HSSFCellStyle style611 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style611.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style611.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font611 = (HSSFFont)hssfworkbook.CreateFont();
            font611.FontHeight = 15 * 20;//字体高度
            style611.SetFont(font611);

            //单元格样式——文本-左边框
            HSSFCellStyle style615 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style615.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style615.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font615 = (HSSFFont)hssfworkbook.CreateFont();
            font615.FontHeight = 15 * 20;//字体高度
            style615.SetFont(font615);

            //单元格样式——二级标题 无边框
            HSSFCellStyle style311 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style311.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            style311.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font311 = (HSSFFont)hssfworkbook.CreateFont();
            font311.FontHeight = 22 * 20;//字体高度
            style311.SetFont(font311);

            //单元格样式——文本-只要右边框
            HSSFCellStyle style620 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style620.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;

            style620.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font620 = (HSSFFont)hssfworkbook.CreateFont();
            font620.FontHeight = 15 * 20;//字体高度
            style620.SetFont(font620);

            //创建列
            HSSFCell cell031 = (HSSFCell)row3.CreateCell(0);
            HSSFCell cell041 = (HSSFCell)row4.CreateCell(0);

            cell031.SetCellValue("附件3");//设置单元格内容
            HSSFCell cell032 = (HSSFCell)row3.CreateCell(3);
            cell032.SetCellValue("废物处置申报认定通知书");//设置单元格内容

            HSSFCell cell034 = (HSSFCell)row3.CreateCell(9);
            HSSFCell cell035 = (HSSFCell)row3.CreateCell(1);

            HSSFCell cell037 = (HSSFCell)row3.CreateCell(4);
            HSSFCell cell038 = (HSSFCell)row3.CreateCell(5);
            HSSFCell cell039 = (HSSFCell)row3.CreateCell(6);
            HSSFCell cell0310 = (HSSFCell)row3.CreateCell(7);
            HSSFCell cell0311 = (HSSFCell)row3.CreateCell(8);
            HSSFCell cell0313 = (HSSFCell)row3.CreateCell(10);

            HSSFCell cell0312 = (HSSFCell)row3.CreateCell(11);
            HSSFCell cell0412 = (HSSFCell)row4.CreateCell(11);
            //应用单元格样式
            cell031.CellStyle = style611;
            cell041.CellStyle = style611;
            cell032.CellStyle = style311;
            cell034.CellStyle = style311;
            cell035.CellStyle = style615;
            cell0313.CellStyle = style311;
            cell037.CellStyle = style615;
            cell038.CellStyle = style615;
            cell0312.CellStyle = style620;
            cell0412.CellStyle = style620;

            //单元格样式——文本-水平居左
            HSSFCellStyle style612 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style612.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style612.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style612.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font612 = (HSSFFont)hssfworkbook.CreateFont();
            font612.FontHeight = 15 * 20;//字体高度
            style612.SetFont(font612);

            //单元格样式——文本-水平居左
            HSSFCellStyle style613 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();

            style613.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font613 = (HSSFFont)hssfworkbook.CreateFont();
            font613.FontHeight = 15 * 20;//字体高度
            style613.SetFont(font613);

            //创建列
            HSSFCell cell051 = (HSSFCell)row5.CreateCell(0);

            HSSFCell cell052 = (HSSFCell)row5.CreateCell(3);
            HSSFCell cell053 = (HSSFCell)row5.CreateCell(9);
            cell053.SetCellValue("编号：");//设置单元格内容

            HSSFCell cell057 = (HSSFCell)row5.CreateCell(4);
            HSSFCell cell058 = (HSSFCell)row5.CreateCell(5);
            HSSFCell cell059 = (HSSFCell)row5.CreateCell(6);
            HSSFCell cell0510 = (HSSFCell)row5.CreateCell(7);
            HSSFCell cell0511 = (HSSFCell)row5.CreateCell(8);
            HSSFCell cell0512 = (HSSFCell)row5.CreateCell(11);
            //应用单元格样式
            cell051.CellStyle = style611;

            cell052.CellStyle = style613;
            cell053.CellStyle = style613;
            cell057.CellStyle = style613;
            cell058.CellStyle = style613;
            cell059.CellStyle = style613;
            cell0510.CellStyle = style613;
            cell0511.CellStyle = style613;
            cell0512.CellStyle = style620;

            //创建列
            IQueryable<BasicWasteUnit> basicWasteUnit = _DispsiteApproveRepository.QueryListByStationCode(AppContext.CurrentUser.ProjectCode);
            foreach (var item in basicWasteUnit)
            {
                vm.StationCode = item.UnitName;
            }
            HSSFCell cell061 = (HSSFCell)row6.CreateCell(0);
            cell061.SetCellValue("废物处置申报单位");//设置单元格内容
            HSSFCell cell062 = (HSSFCell)row6.CreateCell(3);
            cell062.SetCellValue(vm.StationCode);
            HSSFCell cell063 = (HSSFCell)row6.CreateCell(9);
            HSSFCell cell064 = (HSSFCell)row6.CreateCell(10);
            if (vm.DispsiteApprove.DeclareDate == null)
            {
                cell064.SetCellValue("");
            }
            else
            {
                cell064.SetCellValue(vm.DispsiteApprove.DeclareDate.Value.ToString("yyyy-MM-dd"));
            }
            HSSFCell cell065 = (HSSFCell)row6.CreateCell(1);
            HSSFCell cell066 = (HSSFCell)row6.CreateCell(2);
            HSSFCell cell067 = (HSSFCell)row6.CreateCell(4);
            HSSFCell cell068 = (HSSFCell)row6.CreateCell(5);
            HSSFCell cell069 = (HSSFCell)row6.CreateCell(6);
            HSSFCell cell0610 = (HSSFCell)row6.CreateCell(7);
            HSSFCell cell0611 = (HSSFCell)row6.CreateCell(8);
            cell0611.SetCellValue("申报日期");
            HSSFCell cell0612 = (HSSFCell)row6.CreateCell(11);

            //应用单元格样式
            cell061.CellStyle = style2;
            cell062.CellStyle = style2;
            cell063.CellStyle = style2;
            cell064.CellStyle = style2;
            cell065.CellStyle = style2;
            cell066.CellStyle = style2;
            cell067.CellStyle = style2;
            cell068.CellStyle = style2;
            cell069.CellStyle = style2;
            cell0610.CellStyle = style2;
            cell0611.CellStyle = style2;
            cell0612.CellStyle = style2;

            //单元格样式——一级标题 meiy
            HSSFCellStyle style701 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style701.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style701.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style701.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style701.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style701.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font701 = (HSSFFont)hssfworkbook.CreateFont();
            font701.FontHeight = 28 * 20;//字体高度
            style701.SetFont(font701);

            //单元格样式——一级标题
            HSSFCellStyle style702 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style702.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style702.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style702.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style702.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style702.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font702 = (HSSFFont)hssfworkbook.CreateFont();
            font702.FontHeight = 28 * 20;//字体高度
            style702.SetFont(font702);

            //单元格样式——文本
            HSSFCellStyle style222 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style222.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style222.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            style222.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font222 = (HSSFFont)hssfworkbook.CreateFont();
            font222.FontHeight = 15 * 20;//字体高度
            style222.SetFont(font222);

            //单元格样式——文本
            HSSFCellStyle style7 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style7.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style7.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;

            style7.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            style7.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            style7.WrapText = true;
            HSSFFont font7 = (HSSFFont)hssfworkbook.CreateFont();
            font7.FontHeight = 15 * 20;//字体高度
            style7.SetFont(font7);

            //创建列
            HSSFCell cell071 = (HSSFCell)row7.CreateCell(0);
            cell071.SetCellValue("申报    文件    检查    情况");
            HSSFCell cell072 = (HSSFCell)row7.CreateCell(1);
            cell072.SetCellValue("检查经过：");
            HSSFCell cell0712 = (HSSFCell)row7.CreateCell(11);

            //应用单元格样式
            cell071.CellStyle = style7;
            cell072.CellStyle = style222;
            cell0712.CellStyle = style620;

            HSSFCell cell0811 = (HSSFCell)row8.CreateCell(0);
            cell0811.CellStyle = style7;
            HSSFCell cell091 = (HSSFCell)row9.CreateCell(0);
            cell091.CellStyle = style7;
            HSSFCell cell0101 = (HSSFCell)row10.CreateCell(0);
            cell0101.CellStyle = style7;
            HSSFCell cell01111 = (HSSFCell)row11.CreateCell(0);
            cell01111.CellStyle = style7;
            HSSFCell cell0121 = (HSSFCell)row12.CreateCell(0);
            cell0121.CellStyle = style7;
            HSSFCell cell0131 = (HSSFCell)row13.CreateCell(0);
            cell0131.CellStyle = style7;
            HSSFCell cell0141 = (HSSFCell)row14.CreateCell(0);
            cell0141.CellStyle = style7;
            HSSFCell cell0151 = (HSSFCell)row15.CreateCell(0);
            cell0151.CellStyle = style7;
            HSSFCell cell0161 = (HSSFCell)row16.CreateCell(0);
            cell0161.CellStyle = style7;
            HSSFCell cell0171 = (HSSFCell)row17.CreateCell(0);
            cell0171.CellStyle = style7;
            HSSFCell cell0181 = (HSSFCell)row18.CreateCell(0);
            cell0181.CellStyle = style7;
            HSSFCell cell0191 = (HSSFCell)row19.CreateCell(0);
            cell0191.CellStyle = style7;
            HSSFCell cell0201 = (HSSFCell)row20.CreateCell(0);
            cell0201.CellStyle = style7;
            HSSFCell cell02111 = (HSSFCell)row21.CreateCell(0);
            cell02111.CellStyle = style7;
            HSSFCell cell0221 = (HSSFCell)row22.CreateCell(0);
            cell0221.CellStyle = style7;

            //单元格样式——文本
            HSSFCellStyle style71 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style71.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;

            HSSFCell cell08111 = (HSSFCell)row8.CreateCell(12);
            cell08111.CellStyle = style71;
            HSSFCell cell0911 = (HSSFCell)row9.CreateCell(12);
            cell0911.CellStyle = style71;
            HSSFCell cell01011 = (HSSFCell)row10.CreateCell(12);
            cell01011.CellStyle = style71;
            HSSFCell cell010111 = (HSSFCell)row11.CreateCell(12);
            cell010111.CellStyle = style71;
            HSSFCell cell01211 = (HSSFCell)row12.CreateCell(12);
            cell01211.CellStyle = style71;
            HSSFCell cell01311 = (HSSFCell)row13.CreateCell(12);
            cell01311.CellStyle = style71;
            HSSFCell cell01411 = (HSSFCell)row14.CreateCell(12);
            cell01411.CellStyle = style71;
            HSSFCell cell01511 = (HSSFCell)row15.CreateCell(12);
            cell01511.CellStyle = style71;
            HSSFCell cell01611 = (HSSFCell)row16.CreateCell(12);
            cell01611.CellStyle = style71;
            HSSFCell cell01711 = (HSSFCell)row17.CreateCell(12);
            cell01711.CellStyle = style71;
            HSSFCell cell01811 = (HSSFCell)row18.CreateCell(12);
            cell01811.CellStyle = style71;
            HSSFCell cell01911 = (HSSFCell)row19.CreateCell(12);
            cell01911.CellStyle = style71;
            HSSFCell cell02011 = (HSSFCell)row20.CreateCell(12);
            cell02011.CellStyle = style71;
            HSSFCell cell021111 = (HSSFCell)row21.CreateCell(12);
            cell021111.CellStyle = style71;
            HSSFCell cell02211 = (HSSFCell)row22.CreateCell(12);
            cell02211.CellStyle = style71;

            //单元格样式——文本 只有上边框
            HSSFCellStyle style23 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style23.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style23.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            style23.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            style23.WrapText = true;

            HSSFCell cell231 = (HSSFCell)row23.CreateCell(0);
            cell231.CellStyle = style23;
            HSSFCell cell232 = (HSSFCell)row23.CreateCell(1);
            cell232.CellStyle = style23;
            HSSFCell cell233 = (HSSFCell)row23.CreateCell(2);
            cell233.CellStyle = style23;
            HSSFCell cell234 = (HSSFCell)row23.CreateCell(3);
            cell234.CellStyle = style23;

            HSSFCell cell235 = (HSSFCell)row23.CreateCell(4);
            cell235.CellStyle = style23;
            HSSFCell cell236 = (HSSFCell)row23.CreateCell(5);
            cell236.CellStyle = style23;
            HSSFCell cell238 = (HSSFCell)row23.CreateCell(6);
            cell238.CellStyle = style23;
            HSSFCell cell239 = (HSSFCell)row23.CreateCell(7);
            cell239.CellStyle = style23;
            HSSFCell cell230 = (HSSFCell)row23.CreateCell(8);
            cell230.CellStyle = style23;
            HSSFCell cell237 = (HSSFCell)row23.CreateCell(9);
            cell237.CellStyle = style23;
            HSSFCell cell2310 = (HSSFCell)row23.CreateCell(10);
            cell2310.CellStyle = style23;
            HSSFCell cell2311 = (HSSFCell)row23.CreateCell(11);
            cell2311.CellStyle = style23;


            //单元格样式——文本
            HSSFCellStyle style223 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();

            style223.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            style223.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font223 = (HSSFFont)hssfworkbook.CreateFont();
            font223.FontHeight = 15 * 20;//字体高度
            style223.SetFont(font223);

            //创建列
            HSSFCell cell081 = (HSSFCell)row8.CreateCell(1);
            if (vm.DispsiteApprove.CheckDescription == null)
            {
                cell081.SetCellValue("");
            }
            else
            {
                cell081.SetCellValue(vm.DispsiteApprove.CheckDescription);
            }


            HSSFCell cell082 = (HSSFCell)row8.CreateCell(11);
            cell081.CellStyle = style223;

            //单元格样式——文本
            HSSFCellStyle stylelt = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            stylelt.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            stylelt.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            stylelt.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            stylelt.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            stylelt.SetFont(font222);

            //单元格样式——文本
            HSSFCellStyle stylet = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            stylet.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            stylet.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;

            HSSFCell cell142 = (HSSFCell)row14.CreateCell(1);
            cell142.SetCellValue("评价意见：");
            HSSFCell cell1412 = (HSSFCell)row14.CreateCell(11);

            HSSFCell cell1422 = (HSSFCell)row14.CreateCell(2);
            HSSFCell cell143 = (HSSFCell)row14.CreateCell(3);
            HSSFCell cell144 = (HSSFCell)row14.CreateCell(4);
            HSSFCell cell145 = (HSSFCell)row14.CreateCell(5);
            HSSFCell cell146 = (HSSFCell)row14.CreateCell(6);
            HSSFCell cell147 = (HSSFCell)row14.CreateCell(7);
            HSSFCell cell148 = (HSSFCell)row14.CreateCell(8);
            HSSFCell cell149 = (HSSFCell)row14.CreateCell(9);
            HSSFCell cell1410 = (HSSFCell)row14.CreateCell(10);

            //应用单元格样式
            cell142.CellStyle = stylelt;
            cell1412.CellStyle = stylet;
            cell1422.CellStyle = stylet;
            cell143.CellStyle = stylet;
            cell144.CellStyle = stylet;
            cell145.CellStyle = stylet;
            cell146.CellStyle = stylet;
            cell147.CellStyle = stylet;
            cell148.CellStyle = stylet;
            cell149.CellStyle = stylet;
            cell1410.CellStyle = stylet;



            //创建列
            HSSFCell cell151 = (HSSFCell)row15.CreateCell(1);
            if (vm.DispsiteApprove.PriceOpinion == null)
            {
                cell151.SetCellValue("");
            }
            else
            {
                cell151.SetCellValue(vm.DispsiteApprove.PriceOpinion);
            }
            HSSFCell cell152 = (HSSFCell)row15.CreateCell(11);
            cell151.CellStyle = style223;


            //单元格样式——文本
            HSSFCellStyle style21 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();

            style21.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            style21.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font21 = (HSSFFont)hssfworkbook.CreateFont();
            font21.FontHeight = 15 * 20;//字体高度
            style21.SetFont(font21);

            //创建列
            HSSFCell cell211 = (HSSFCell)row21.CreateCell(7);
            cell211.SetCellValue("处置认定负责人（签字）：");

            HSSFCell cell212 = (HSSFCell)row21.CreateCell(11);
            cell211.CellStyle = style21;



            //创建列
            HSSFCell cell221 = (HSSFCell)row22.CreateCell(7);
            cell221.SetCellValue("日期：");

            HSSFCell cell222 = (HSSFCell)row22.CreateCell(11);
            cell221.CellStyle = style21;


            #endregion

            #region 编辑excel2

            //创建列
            HSSFCell cell251 = (HSSFCell)row25.CreateCell(0);
            cell251.SetCellValue("GNPEP");//设置单元格内容
            HSSFCell cell252 = (HSSFCell)row25.CreateCell(3);
            cell252.SetCellValue("低中放固体废物处置申报认定程序");
            HSSFCell cell253 = (HSSFCell)row25.CreateCell(9);
            cell253.SetCellValue("版次:2");
            HSSFCell cell254 = (HSSFCell)row25.CreateCell(10);
            cell254.SetCellValue("页码:7/10");
            HSSFCell cell255 = (HSSFCell)row25.CreateCell(1);
            HSSFCell cell256 = (HSSFCell)row25.CreateCell(2);
            HSSFCell cell257 = (HSSFCell)row25.CreateCell(4);
            HSSFCell cell258 = (HSSFCell)row25.CreateCell(5);
            HSSFCell cell259 = (HSSFCell)row25.CreateCell(6);
            HSSFCell cell2510 = (HSSFCell)row25.CreateCell(7);
            HSSFCell cell2511 = (HSSFCell)row25.CreateCell(8);
            HSSFCell cell2512 = (HSSFCell)row25.CreateCell(11);
            //应用单元格样式
            cell251.CellStyle = style;
            cell252.CellStyle = style3;
            cell253.CellStyle = style2;
            cell254.CellStyle = style2;
            cell255.CellStyle = style;
            cell256.CellStyle = style;
            cell257.CellStyle = style;
            cell258.CellStyle = style;
            cell259.CellStyle = style;
            cell2510.CellStyle = style;
            cell2511.CellStyle = style;
            cell2512.CellStyle = style;


            //创建列
            HSSFCell cell261 = (HSSFCell)row26.CreateCell(9);
            cell261.SetCellValue("C/IP/OPN/020");//设置单元格内容
            HSSFCell cell262 = (HSSFCell)row26.CreateCell(0);
            HSSFCell cell265 = (HSSFCell)row26.CreateCell(1);
            HSSFCell cell266 = (HSSFCell)row26.CreateCell(2);
            HSSFCell cell263 = (HSSFCell)row26.CreateCell(3);
            HSSFCell cell267 = (HSSFCell)row26.CreateCell(4);
            HSSFCell cell268 = (HSSFCell)row26.CreateCell(5);
            HSSFCell cell269 = (HSSFCell)row26.CreateCell(6);
            HSSFCell cell2610 = (HSSFCell)row26.CreateCell(7);
            HSSFCell cell2611 = (HSSFCell)row26.CreateCell(8);
            HSSFCell cell2614 = (HSSFCell)row26.CreateCell(10);
            HSSFCell cell2612 = (HSSFCell)row26.CreateCell(11);
            //应用单元格样式
            cell262.CellStyle = style;
            cell261.CellStyle = style2;
            cell263.CellStyle = style;
            cell265.CellStyle = style;
            cell266.CellStyle = style;
            cell267.CellStyle = style;
            cell268.CellStyle = style;
            cell269.CellStyle = style;
            cell2610.CellStyle = style;
            cell2611.CellStyle = style;
            cell2612.CellStyle = style;
            cell2614.CellStyle = style;

            //单元格样式——一级标题 上下左
            HSSFCellStyle styletbl = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styletbl.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            styletbl.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            styletbl.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 上下右
            HSSFCellStyle styletbr = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styletbr.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            styletbr.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            styletbr.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 上下
            HSSFCellStyle styletb = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styletb.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            styletb.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 上左
            HSSFCellStyle styletl = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styletl.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            styletl.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 上右
            HSSFCellStyle styletr = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styletr.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            styletr.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 下左
            HSSFCellStyle stylebl = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            stylebl.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            stylebl.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 下右
            HSSFCellStyle stylebr = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            stylebr.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            stylebr.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 左
            HSSFCellStyle stylel = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            stylel.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 右
            HSSFCellStyle styler = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styler.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 下
            HSSFCellStyle styleb = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styleb.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

            HSSFCell cell270 = (HSSFCell)row27.CreateCell(0);
            HSSFCell cell271 = (HSSFCell)row27.CreateCell(1);
            HSSFCell cell272 = (HSSFCell)row27.CreateCell(2);
            HSSFCell cell273 = (HSSFCell)row27.CreateCell(3);
            HSSFCell cell274 = (HSSFCell)row27.CreateCell(4);
            HSSFCell cell275 = (HSSFCell)row27.CreateCell(5);
            HSSFCell cell276 = (HSSFCell)row27.CreateCell(6);
            HSSFCell cell277 = (HSSFCell)row27.CreateCell(7);
            HSSFCell cell278 = (HSSFCell)row27.CreateCell(8);
            HSSFCell cell279 = (HSSFCell)row27.CreateCell(9);
            HSSFCell cell2710 = (HSSFCell)row27.CreateCell(10);
            HSSFCell cell2711 = (HSSFCell)row27.CreateCell(11);
            cell270.CellStyle = styletbl;
            cell271.CellStyle = styletb;
            cell272.CellStyle = styletb;
            cell273.CellStyle = styletb;
            cell274.CellStyle = styletb;
            cell275.CellStyle = styletb;
            cell276.CellStyle = styletb;
            cell277.CellStyle = styletb;
            cell278.CellStyle = styletb;
            cell279.CellStyle = styletb;
            cell2710.CellStyle = styletb;
            cell2711.CellStyle = styletbr;

            //单元格样式——文本
            HSSFCellStyle style28 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();

            style28.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            style28.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font28 = (HSSFFont)hssfworkbook.CreateFont();
            font28.FontHeight = 15 * 20;//字体高度
            style28.SetFont(font28);

            HSSFCell cell280 = (HSSFCell)row28.CreateCell(0);
            cell280.SetCellValue("认        定        范        围");//设置单元格内容
            HSSFCell cell281 = (HSSFCell)row28.CreateCell(1);
            HSSFCell cell282 = (HSSFCell)row28.CreateCell(2);
            cell282.SetCellValue("通过处置申报认定的废物货包数共计" + arrPackageCodesList.Count() + "个，其废物桶号码分别为：");//设置单元格内容
            HSSFCell cell283 = (HSSFCell)row28.CreateCell(3);
            HSSFCell cell284 = (HSSFCell)row28.CreateCell(4);
            HSSFCell cell285 = (HSSFCell)row28.CreateCell(5);
            HSSFCell cell286 = (HSSFCell)row28.CreateCell(6);
            HSSFCell cell287 = (HSSFCell)row28.CreateCell(7);
            HSSFCell cell288 = (HSSFCell)row28.CreateCell(8);
            HSSFCell cell289 = (HSSFCell)row28.CreateCell(9);
            HSSFCell cell2810 = (HSSFCell)row28.CreateCell(10);
            HSSFCell cell2811 = (HSSFCell)row28.CreateCell(11);
            cell280.CellStyle = style7;
            cell281.CellStyle = styletl;
            cell282.CellStyle = style28;
            cell283.CellStyle = style23;
            cell284.CellStyle = style23;
            cell285.CellStyle = style23;
            cell286.CellStyle = style23;
            cell287.CellStyle = style23;
            cell288.CellStyle = style23;
            cell289.CellStyle = style23;
            cell2810.CellStyle = style23;
            cell2811.CellStyle = styletr;

            HSSFCell cell290 = (HSSFCell)row29.CreateCell(0);
            HSSFCell cell291 = (HSSFCell)row29.CreateCell(1);
            HSSFCell cell2911 = (HSSFCell)row29.CreateCell(11);
            cell290.CellStyle = stylel;
            cell291.CellStyle = stylel;
            cell2911.CellStyle = styler;

            #region grid
            sheet1.AddMergedRegion(new CellRangeAddress(29, 29, 3, 4));
            sheet1.AddMergedRegion(new CellRangeAddress(29, 29, 6, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(29, 29, 9, 10));
            sheet1.AddMergedRegion(new CellRangeAddress(30, 30, 3, 4));
            sheet1.AddMergedRegion(new CellRangeAddress(30, 30, 6, 7));
            sheet1.AddMergedRegion(new CellRangeAddress(30, 30, 9, 10));

            HSSFCell cell300 = (HSSFCell)row30.CreateCell(0);
            HSSFCell cell301 = (HSSFCell)row30.CreateCell(1);
            HSSFCell cell302 = (HSSFCell)row30.CreateCell(2);
            cell302.SetCellValue("序号");//设置单元格内容
            HSSFCell cell303 = (HSSFCell)row30.CreateCell(3);
            cell303.SetCellValue("废物桶号码");//设置单元格内容
            HSSFCell cell304 = (HSSFCell)row30.CreateCell(4);
            HSSFCell cell305 = (HSSFCell)row30.CreateCell(5);
            cell305.SetCellValue("序号");//设置单元格内容
            HSSFCell cell306 = (HSSFCell)row30.CreateCell(6);
            cell306.SetCellValue("废物桶号码");//设置单元格内容
            HSSFCell cell307 = (HSSFCell)row30.CreateCell(7);
            HSSFCell cell308 = (HSSFCell)row30.CreateCell(8);
            cell308.SetCellValue("序号");//设置单元格内容
            HSSFCell cell309 = (HSSFCell)row30.CreateCell(9);
            cell309.SetCellValue("废物桶号码");//设置单元格内容
            HSSFCell cell3010 = (HSSFCell)row30.CreateCell(10);
            HSSFCell cell3011 = (HSSFCell)row30.CreateCell(11);
            cell300.CellStyle = style2;
            cell301.CellStyle = style311;
            cell302.CellStyle = style2;
            cell303.CellStyle = style2;
            cell304.CellStyle = style2;
            cell305.CellStyle = style2;
            cell306.CellStyle = style2;
            cell307.CellStyle = style2;
            cell308.CellStyle = style2;
            cell309.CellStyle = style2;
            cell3010.CellStyle = style2;
            cell3011.CellStyle = styler;
            
            #endregion
            sheet1.AddMergedRegion(new CellRangeAddress(42, 47, 0, 0));
            sheet1.AddMergedRegion(new CellRangeAddress(42, 42, 7, 10));
            sheet1.AddMergedRegion(new CellRangeAddress(43, 43, 7, 10));
            sheet1.AddMergedRegion(new CellRangeAddress(44, 44, 7, 10));
            sheet1.AddMergedRegion(new CellRangeAddress(45, 45, 7, 10));
            sheet1.AddMergedRegion(new CellRangeAddress(46, 46, 7, 10));
            sheet1.AddMergedRegion(new CellRangeAddress(47, 47, 7, 10));

            HSSFCell cell430 = (HSSFCell)row43.CreateCell(0);
            HSSFCell cell431 = (HSSFCell)row43.CreateCell(1);
            HSSFCell cell432 = (HSSFCell)row43.CreateCell(2);
            HSSFCell cell433 = (HSSFCell)row43.CreateCell(3);
            HSSFCell cell434 = (HSSFCell)row43.CreateCell(4);
            HSSFCell cell435 = (HSSFCell)row43.CreateCell(5);
            HSSFCell cell436 = (HSSFCell)row43.CreateCell(6);
            HSSFCell cell437 = (HSSFCell)row43.CreateCell(7);
            HSSFCell cell438 = (HSSFCell)row43.CreateCell(8);
            HSSFCell cell439 = (HSSFCell)row43.CreateCell(9);
            HSSFCell cell4310 = (HSSFCell)row43.CreateCell(10);
            HSSFCell cell4311 = (HSSFCell)row43.CreateCell(11);
            cell430.CellStyle = style2;
            cell431.CellStyle = stylel;

            cell4311.CellStyle = styler;

            HSSFCell cell440 = (HSSFCell)row44.CreateCell(0);
            HSSFCell cell441 = (HSSFCell)row44.CreateCell(1);
            HSSFCell cell442 = (HSSFCell)row44.CreateCell(2);
            HSSFCell cell443 = (HSSFCell)row44.CreateCell(3);
            HSSFCell cell444 = (HSSFCell)row44.CreateCell(4);
            HSSFCell cell445 = (HSSFCell)row44.CreateCell(5);
            HSSFCell cell446 = (HSSFCell)row44.CreateCell(6);
            HSSFCell cell447 = (HSSFCell)row44.CreateCell(7);
            cell447.SetCellValue("处置单位授权人签发:");//设置单元格内容
            HSSFCell cell448 = (HSSFCell)row44.CreateCell(8);
            HSSFCell cell449 = (HSSFCell)row44.CreateCell(9);
            HSSFCell cell4410 = (HSSFCell)row44.CreateCell(10);
            HSSFCell cell4411 = (HSSFCell)row44.CreateCell(11);
            cell440.CellStyle = style2;
            cell441.CellStyle = stylel;
            cell447.CellStyle = style21;
            cell4411.CellStyle = styler;

            HSSFCell cell450 = (HSSFCell)row45.CreateCell(0);
            HSSFCell cell451 = (HSSFCell)row45.CreateCell(1);
            HSSFCell cell452 = (HSSFCell)row45.CreateCell(2);
            HSSFCell cell453 = (HSSFCell)row45.CreateCell(3);
            HSSFCell cell454 = (HSSFCell)row45.CreateCell(4);
            HSSFCell cell455 = (HSSFCell)row45.CreateCell(5);
            HSSFCell cell456 = (HSSFCell)row45.CreateCell(6);
            HSSFCell cell457 = (HSSFCell)row45.CreateCell(7);
            cell457.SetCellValue("单位盖章：");//设置单元格内容
            HSSFCell cell458 = (HSSFCell)row45.CreateCell(8);
            HSSFCell cell459 = (HSSFCell)row45.CreateCell(9);
            HSSFCell cell4510 = (HSSFCell)row45.CreateCell(10);
            HSSFCell cell4511 = (HSSFCell)row45.CreateCell(11);
            cell450.CellStyle = style2;
            cell451.CellStyle = stylel;
            cell457.CellStyle = style21;
            cell4511.CellStyle = styler;

            HSSFCell cell460 = (HSSFCell)row46.CreateCell(0);
            HSSFCell cell461 = (HSSFCell)row46.CreateCell(1);
            HSSFCell cell462 = (HSSFCell)row46.CreateCell(2);
            HSSFCell cell463 = (HSSFCell)row46.CreateCell(3);
            HSSFCell cell464 = (HSSFCell)row46.CreateCell(4);
            HSSFCell cell465 = (HSSFCell)row46.CreateCell(5);
            HSSFCell cell466 = (HSSFCell)row46.CreateCell(6);
            HSSFCell cell467 = (HSSFCell)row46.CreateCell(7);
            cell467.SetCellValue("日期：");//设置单元格内容
            HSSFCell cell468 = (HSSFCell)row46.CreateCell(8);
            HSSFCell cell469 = (HSSFCell)row46.CreateCell(9);
            HSSFCell cell4610 = (HSSFCell)row46.CreateCell(10);
            HSSFCell cell4611 = (HSSFCell)row46.CreateCell(11);
            cell460.CellStyle = style2;
            cell461.CellStyle = stylel;
            cell467.CellStyle = style21;
            cell4611.CellStyle = styler;

            HSSFCell cell470 = (HSSFCell)row47.CreateCell(0);
            HSSFCell cell471 = (HSSFCell)row47.CreateCell(1);
            HSSFCell cell472 = (HSSFCell)row47.CreateCell(2);
            HSSFCell cell473 = (HSSFCell)row47.CreateCell(3);
            HSSFCell cell474 = (HSSFCell)row47.CreateCell(4);
            HSSFCell cell475 = (HSSFCell)row47.CreateCell(5);
            HSSFCell cell476 = (HSSFCell)row47.CreateCell(6);
            HSSFCell cell477 = (HSSFCell)row47.CreateCell(7);
            HSSFCell cell478 = (HSSFCell)row47.CreateCell(8);
            HSSFCell cell479 = (HSSFCell)row47.CreateCell(9);
            HSSFCell cell4710 = (HSSFCell)row47.CreateCell(10);
            HSSFCell cell4711 = (HSSFCell)row47.CreateCell(11);
            cell470.CellStyle = style2;
            cell471.CellStyle = stylel;

            cell4711.CellStyle = styler;

            HSSFCell cell480 = (HSSFCell)row48.CreateCell(0);
            HSSFCell cell481 = (HSSFCell)row48.CreateCell(1);
            HSSFCell cell482 = (HSSFCell)row48.CreateCell(2);
            HSSFCell cell483 = (HSSFCell)row48.CreateCell(3);
            HSSFCell cell484 = (HSSFCell)row48.CreateCell(4);
            HSSFCell cell485 = (HSSFCell)row48.CreateCell(5);
            HSSFCell cell486 = (HSSFCell)row48.CreateCell(6);
            HSSFCell cell487 = (HSSFCell)row48.CreateCell(7);
            HSSFCell cell488 = (HSSFCell)row48.CreateCell(8);
            HSSFCell cell489 = (HSSFCell)row48.CreateCell(9);
            HSSFCell cell4810 = (HSSFCell)row48.CreateCell(10);
            HSSFCell cell4811 = (HSSFCell)row48.CreateCell(11);
            cell480.CellStyle = style2;
            cell481.CellStyle = stylebl;
            cell482.CellStyle = styleb;
            cell483.CellStyle = styleb;
            cell484.CellStyle = styleb;
            cell485.CellStyle = styleb;
            cell486.CellStyle = styleb;
            cell487.CellStyle = styleb;
            cell488.CellStyle = styleb;
            cell489.CellStyle = styleb;
            cell4810.CellStyle = styleb;
            cell4811.CellStyle = stylebr;
            #endregion

            #region  工作流
            //工作流
            MemoryStream stream = new MemoryStream();
            hssfworkbook.Write(stream);

            string saveFileName = string.Format("{0}_{1}.xls", "DispsiteApprove", DateTime.Now.ToString("yyyy-MM-dd"));
            string fileName = Server.MapPath("~") + "\\ExcelTemplate\\" + saveFileName;
            SaveToFile(stream, fileName);
            FileInfo downLoadFile = new FileInfo(fileName);
            System.Web.HttpContext context = System.Web.HttpContext.Current;
            context.Response.Clear();
            context.Response.ClearHeaders();
            context.Response.Buffer = false;
            context.Response.ContentType = "application/octet-stream";
            context.Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlDecode(saveFileName, System.Text.Encoding.UTF8));
            context.Response.AddHeader("content-length", downLoadFile.Length.ToString());
            context.Response.WriteFile(downLoadFile.FullName);
            context.Response.Flush();
            context.Response.End();
            if (System.IO.File.Exists(fileName))
            {
                System.IO.File.Delete(fileName);
            }
            return null;
        }

        private void SaveToFile(MemoryStream ms, string fileName)
        {
            using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write))
            {
                byte[] data = ms.ToArray();

                fs.Write(data, 0, data.Length);
                fs.Flush();
                data = null;
            }
        }
            #endregion



        //[HttpGet]
        //[UbaFilter(OperateType = OperateType.Button, OperateDescription = "出库单导出")]
        //public ActionResult Prints(string bucketCode)
        //{
        //    bucketCode = "K1212310";
        //    Export(bucketCode);
        //    return null;
        //}
        //private void Export(string bucketCode)
        //{
        //    //设置数据
        //    List<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).AsQueryable().ToList();
        //    List<NuclearBucketCheck> nuclearBucketCheck = _NuclearBucketCheckRepository.GetAll().Where(d => d.BucketId == nuclearBucket[0].BucketId).ToList();
        //   "□R";
            //#endregion
            //#region 工作流
            ////工作流
            //MemoryStream stream = new MemoryStream();
            //hssfworkbook.Write(stream);

            //string saveFileName = string.Format("{0}_{1}.xls", "DispsiteApprove", DateTime.Now.ToString("yyyy-MM-dd"));
            //string fileName = Server.MapPath("~") + "\\ExcelTemplate\\" + saveFileName;
            //SaveToFile(stream, fileName);
            //FileInfo downLoadFile = new FileInfo(fileName);
            //System.Web.HttpContext context = System.Web.HttpContext.Current;
            //context.Response.Clear();
            //context.Response.ClearHeaders();
            //context.Response.Buffer = false;
            //context.Response.ContentType = "application/octet-stream";
            //context.Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlDecode(saveFileName, System.Text.Encoding.UTF8));
            //context.Response.AddHeader("content-length", downLoadFile.Length.ToString());
            //context.Response.WriteFile(downLoadFile.FullName);
            //context.Response.Flush();
            //context.Response.End();
            //if (System.IO.File.Exists(fileName))
            //{
            //    System.IO.File.Delete(fileName);
            //}
            //#endregion
        //}

        }
        #endregion

    }

