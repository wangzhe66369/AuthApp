﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   WastePacageCheckController.cs
 *   描    述   ：   废物包审核控制器
 *   创 建 者   ：   PXMWSWG
 *   创建日期   ：   2016-10-18 18:45:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-18 18:45:00    1.0.0.0     PXMWSWG       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using MvcContrib.UI.Grid;

using NET01.Presentation.Web.Mvc.JqGrid;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core.Ftp;
using RWIS.Presentation.Web.Core;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View.EquipManage;
using RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View.WastePackageCheck;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModelBuilder;
using CIT.UPC.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using CIT.UPC.Domain.DomainObjects;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using System.IO;
using System.Web;
using NPOI.SS.Util;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using System.Configuration;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using NPOI.XSSF.UserModel;
using RWIS.Presentation.Web.Areas.WasteDisposal.Controllers;

namespace RWIS.Presentation.Web.Areas.WastePackageCheck.Controllers
{
    public class WastePacageCheckController : Controller
    {
        static ActivityOrder activityOrder = new ActivityOrder();
        CommonHelper commonHelper = new CommonHelper();
        IMaterialInputRepository _MaterialInputRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearProcessApplyRepository _NuclearProcessApplyRepository;
        IDispsiteCheckRepository _DispsiteCheckRepository;
        IDispsiteCheckDetailRepository _DispsiteCheckDetailRepository;
        IDispsiteApproveRepository _DispsiteApproveRepository;
        INuclearApplyDetailRepository _NuclearApplyDetailRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        INuclearBucketCheckRepository _NuclearBucketCheckRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        INuclearCoverMetalRepository _NuclearCoverMetalRepository;
        INuclearBucketSolutionRepository _NuclearBucketSolutionRepository;
        INuclearBucketResinRepository _NuclearBucketResinRepository;
        INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository;
        INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository;
        INuclearCoverMixRepository _NuclearCoverMixRepository;
        INuclearQtTransRepository _NuclearQtTransRepository;
        INuclearFcTransRepository _NuclearFcTransRepository;
        INuclearTsGoodsInRepository _NuclearTsGoodsInRepository;
        INuclearTsGoodsOutRepository _NuclearTsGoodsOutRepository;
        IDispsiteEvalRepository _DispsiteEvalRepository;
        IDispsiteEvalDetailRepository _DispsiteEvalDetailRepository;
        INuclearGiftDetailRepository _NuclearGiftDetailRepository;
        INuclearFixationRepository _NuclearFixationRepository;
        INuclearBucketChangeRepository _NuclearBucketChangeRepository;
        public WastePacageCheckController(INuclearProcessApplyRepository NuclearProcessApplyRepository
            , INuclearBucketRepository _NuclearBucketRepository
            , IBasicObjectRepository _BasicObjectRepository
            , IDispsiteCheckRepository _DispsiteCheckRepository
            , IDispsiteCheckDetailRepository _DispsiteCheckDetailRepository,
            IDispsiteApproveRepository _DispsiteApproveRepository,
            INuclearApplyDetailRepository _NuclearApplyDetailRepository,
            IMaterialTypeRepository _MaterialTypeRepository,
            IMaterialInputRepository _MaterialInputRepository,
            INuclearBucketCheckRepository _NuclearBucketCheckRepository,
            INuclearWastePackageRepository _NuclearWastePackageRepository,
            INuclearCoverMetalRepository _NuclearCoverMetalRepository,
            INuclearBucketSolutionRepository NuclearBucketSolutionRepository
            , INuclearBucketResinRepository NuclearBucketResinRepository
            , INuclearBucketRSolidifyRepository NuclearBucketRSolidifyRepository
            , INuclearBucketSSolidifyRepository NuclearBucketSSolidifyRepository
            , INuclearCoverMetalRepository NuclearCoverMetalRepository
            , INuclearCoverMixRepository NuclearCoverMixRepository
            , INuclearQtTransRepository NuclearQtTransRepository
            , INuclearFcTransRepository NuclearFcTransRepository
            , INuclearTsGoodsInRepository NuclearTsGoodsInRepository
             , INuclearTsGoodsOutRepository NuclearTsGoodsOutRepository
            , IDispsiteEvalRepository DispsiteEvalRepository
            , INuclearGiftDetailRepository _NuclearGiftDetailRepository
            , INuclearFixationRepository _NuclearFixationRepository
           ,INuclearBucketChangeRepository _NuclearBucketChangeRepository
        , IDispsiteEvalDetailRepository DispsiteEvalDetailRepository)
        {
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearProcessApplyRepository = NuclearProcessApplyRepository;
            this._DispsiteCheckRepository = _DispsiteCheckRepository;
            this._DispsiteCheckDetailRepository = _DispsiteCheckDetailRepository;
            this._DispsiteApproveRepository = _DispsiteApproveRepository;
            this._NuclearApplyDetailRepository = _NuclearApplyDetailRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._MaterialInputRepository = _MaterialInputRepository;
            this._NuclearBucketCheckRepository = _NuclearBucketCheckRepository;
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
            this._NuclearCoverMetalRepository = _NuclearCoverMetalRepository;
            this._NuclearBucketSolutionRepository = NuclearBucketSolutionRepository;
            this._NuclearBucketResinRepository = NuclearBucketResinRepository;
            this._NuclearBucketRSolidifyRepository = NuclearBucketRSolidifyRepository;
            this._NuclearBucketSSolidifyRepository = NuclearBucketSSolidifyRepository;
            this._NuclearCoverMetalRepository = NuclearCoverMetalRepository;
            this._NuclearCoverMixRepository = NuclearCoverMixRepository;
            this._NuclearQtTransRepository = NuclearQtTransRepository;
            this._NuclearFcTransRepository = NuclearFcTransRepository;
            this._NuclearTsGoodsInRepository = NuclearTsGoodsInRepository;
            this._NuclearTsGoodsOutRepository = NuclearTsGoodsOutRepository;
            this._DispsiteEvalRepository = DispsiteEvalRepository;
            this._DispsiteEvalDetailRepository = DispsiteEvalDetailRepository;
            this._NuclearGiftDetailRepository = _NuclearGiftDetailRepository;
            this._NuclearFixationRepository = _NuclearFixationRepository;
            this._NuclearBucketChangeRepository = _NuclearBucketChangeRepository;
        }

        #region 页面

        /// <summary>
        /// 废物审核管理页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物审核管理页面")]
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 废物包详细信息页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物包详细信息页面")]
        public ActionResult WastePackageInfo(string processApplyId)
        {
            ViewBag.ProcessApplyId = processApplyId;
            WastePackageCheckVM vm = new WastePackageCheckVM();
            NuclearProcessApply model = _NuclearProcessApplyRepository.Get(processApplyId);
            NuclearApplyDetail nuclearApplyDetail = new NuclearApplyDetail();
            IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().Where(d => d.ProcessApplyId == processApplyId).AsQueryable();
            foreach (var items in nuclearApplyDetailQuery)
            {
                nuclearApplyDetail.ApplyDetailId = items.ApplyDetailId;
            }
            vm.NuclearApplyDetail = nuclearApplyDetail;
            BasicObject basicObjectProcessFactoryId = _BasicObjectRepository.Get(model.ProcessFactoryId);
            BasicObject basicObjectStoragePositionId = _BasicObjectRepository.Get(model.StoragePositionId);
            vm.ProcessFactoryId = basicObjectProcessFactoryId.Name;
            vm.StoragePositionId = basicObjectStoragePositionId.Name;
            NuclearProcessApply nuclearProcessApply = new NuclearProcessApply();
            nuclearProcessApply.ProcessApplyId = processApplyId;
            vm.NuclearProcessApply = nuclearProcessApply;
            vm.NuclearProcessApply = model;
            IQueryable<DispsiteCheck> dispsiteCheckQuery = _DispsiteApproveRepository.QueryListById(processApplyId);
            foreach (var item in dispsiteCheckQuery)
            {
                DispsiteCheck dispsiteCheck = new DispsiteCheck();
                dispsiteCheck.CheckId = item.CheckId;
                vm.DispsiteCheck = dispsiteCheck;
                IQueryable<DispsiteApprove> dispsiteApproveQuery = _DispsiteApproveRepository.QueryListByCheckId(item.CheckId);
                foreach (var items in dispsiteApproveQuery)
                {
                    DispsiteApprove dispsiteApprove = _DispsiteApproveRepository.Get(items.ApproveId);
                    vm.IdentityCode = dispsiteApprove.IdentityCode;

                }
            }
            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(processApplyId, "DispsiteCheck");
            vm.CheckReportFileList = (List<AttachFile>)listAttachFile;
            ViewBag.BusinessType = "DispsiteCheck";

            IList<AttachFile> listAttachFilees = _attachFileRepository.GetAttachFileBy(processApplyId, "DisposeApply");
            vm.AttachFiles = (List<AttachFile>)listAttachFilees;
            ViewBag.BusinessType = "DisposeApply";
            return View(vm);
        }

        public ActionResult DetailView(string processApplyId)
        {
            ViewBag.ProcessApplyId = processApplyId;
            NuclearProcessApply model = _NuclearProcessApplyRepository.Get(processApplyId);
            WastePackageCheckVM vm = new WastePackageCheckVM();
            if (model != null)
            {
                BasicObject basicObjectProcessFactoryId = _BasicObjectRepository.Get(model.ProcessFactoryId);
                BasicObject basicObjectStoragePositionId = _BasicObjectRepository.Get(model.StoragePositionId);
                if (basicObjectProcessFactoryId != null)
                {
                    vm.ProcessFactoryId = basicObjectProcessFactoryId.Name;
                }
                else
                {
                    vm.ProcessFactoryId = "";
                }
                if (basicObjectStoragePositionId != null)
                {
                    vm.StoragePositionId = basicObjectStoragePositionId.Name;
                }
                else
                {
                    vm.StoragePositionId = "";
                }
            }
            NuclearProcessApply nuclearProcessApply = new NuclearProcessApply();
            nuclearProcessApply.ProcessApplyId = processApplyId;
            vm.NuclearProcessApply = nuclearProcessApply;
            vm.NuclearProcessApply = model;
            IQueryable<DispsiteCheck> dispsiteCheckQuery = _DispsiteApproveRepository.QueryListById(processApplyId);
            foreach (var item in dispsiteCheckQuery)
            {
                DispsiteCheck dispsiteCheck = new DispsiteCheck();
                dispsiteCheck.CheckId = item.CheckId;
                vm.DispsiteCheck = dispsiteCheck;
                IQueryable<DispsiteApprove> dispsiteApproveQuery = _DispsiteApproveRepository.QueryListByCheckId(item.CheckId);
                foreach (var items in dispsiteApproveQuery)
                {
                    DispsiteApprove dispsiteApprove = _DispsiteApproveRepository.Get(items.ApproveId);
                    vm.IdentityCode = dispsiteApprove.IdentityCode;

                }
            }
            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(processApplyId, "QuestionReport");
            vm.CheckReportFileList = (List<AttachFile>)listAttachFile;
            ViewBag.BusinessType = "QuestionReport";

            IList<AttachFile> listAttachFilees = _attachFileRepository.GetAttachFileBy(processApplyId, "DisposeApply");
            vm.AttachFiles = (List<AttachFile>)listAttachFilees;
            ViewBag.BusinessType = "DisposeApply";
            return View("DetailView", vm);
        }

        /// <summary>
        /// 废物包列表页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物包列表页面")]
        public ActionResult WastePackageList(string processApplyId, string wasteType, string dealMethod, string materialName)
        {
            WastePackageCheckVM vm = new WastePackageCheckVM();
            NuclearProcessApply nuclearProcessApply = new NuclearProcessApply();
            IQueryable<NuclearApplyDetail> nuclearApplyDetail = _NuclearApplyDetailRepository.GetAll().Where(d => d.ProcessApplyId == processApplyId).AsQueryable();
            foreach (var item in nuclearApplyDetail)
            {
                vm.ApplyDetailId = item.ApplyDetailId;
                nuclearProcessApply.ProcessApplyId = item.ProcessApplyId;
            }
            vm.NuclearProcessApply = nuclearProcessApply;
            //加载状态
            vm.StatusList = new List<SelectListItem>();
            vm.StatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.StatusList.Add(new SelectListItem { Text = "未确认", Value = "1" });
            vm.StatusList.Add(new SelectListItem { Text = "已确认", Value = "2" });
            //vm.ApplyDetailId = applyDetailId;
            vm.WasteType = wasteType;
            vm.DealMethod = dealMethod;
            vm.MaterialName = materialName;
            return View("WastePackageList", vm);
        }

        /// <summary>
        /// 废物包审核页面
        /// </summary>
        /// <returns></returns>
        public ActionResult WastePackageCheck(string bucketId, string applyDetailId)
        {
            string wasteProduceDate = null;
            string wasteGiftDate = null;
            string activityEvalDate = null;
            WastePackageCheckVM vm = new WastePackageCheckVM();
            vm.ActivityOrder = new ActivityOrder();
            vm.OperationList = CommonHelper.GetOperationList("Waste_Pacage_Check");

            NuclearApplyDetail nuclearApplyDetail = new NuclearApplyDetail();
            IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == bucketId).AsQueryable();
            foreach (var item in nuclearApplyDetailQuery)
            {
                nuclearApplyDetail.ApplyDetailId = item.ApplyDetailId;
            }
            vm.NuclearApplyDetail = nuclearApplyDetail;
            NuclearApplyDetail applyDetail = _NuclearApplyDetailRepository.Get(nuclearApplyDetail.ApplyDetailId);
            NuclearProcessApply nuclearProcessApply = new NuclearProcessApply();
            if (applyDetail != null)
            {
                nuclearProcessApply.ProcessApplyId = applyDetail.ProcessApplyId;
                nuclearProcessApply = _NuclearProcessApplyRepository.Get(applyDetail.ProcessApplyId);
                vm.NuclearProcessApply = nuclearProcessApply;
            }
           
            List<SelectListItem> checkList = new List<SelectListItem>();
            checkList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
            checkList.Add(new SelectListItem { Text = "否", Value = "0" });

            NuclearBucket nuclearBucket = this._NuclearBucketRepository.Get(bucketId);
            if (nuclearBucket != null)
            {
                vm.WasteType = nuclearBucket.WasteType;
                vm.DealMethod = nuclearBucket.DealMethod;
            
            }


            MaterialType materialType = this._MaterialTypeRepository.Get(nuclearBucket.MaterialId);
            vm.MaterialName = materialType.MaterialName;
            vm.CheckMaterialList = checkList;
            vm.CheckBucketAduitList = checkList;
            vm.CheckBucketMesList = checkList;
            vm.EvaluateList = checkList;
            vm.CheckBucketDealList = checkList;
            vm.CheckBucketCoverList = checkList;
            vm.CheckBucketTransferList = checkList;
            vm.FileIsCompletedList = checkList;

            List<SelectListItem> checkResultList = new List<SelectListItem>();
            checkResultList.Add(new SelectListItem { Text = "同意", Value = "1", Selected = true });
            checkResultList.Add(new SelectListItem { Text = "不同意", Value = "0" });
            vm.CheckResultList = checkResultList;
            vm.ApplyDetailId = nuclearApplyDetail.ApplyDetailId;
            ViewBag.ApplyDetailId = nuclearApplyDetail.ApplyDetailId;
            //桶入库材料信息
            vm.MaterialInputVM = GetMaterialInput(bucketId);

            //桶检查信息
            vm.NuclearBucketCheck = GetNuclearBucketCheck(bucketId);
            if (vm.NuclearBucketCheck == null)
            {
                vm.NuclearBucketCheck = new NuclearBucketCheck();
            }

            //桶信息
            vm.NuclearBucket = this._NuclearBucketRepository.Get(bucketId);
            if (vm.NuclearBucket == null)
            {
                vm.NuclearBucket = new NuclearBucket();
            }
            //存储和转运信息
            vm.IsExistTransferAndStorage = WasteCheckBuilder.IsExistTransferAndStorage(bucketId);

            //审核明细信息
            activityOrder.MinusProduceDate = string.Empty;
            activityOrder.MinusOriginalActivity = string.Empty;
            IQueryable<DispsiteCheckDetail> dispsiteCheckDetail = this._DispsiteCheckDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == nuclearApplyDetail.ApplyDetailId);
            if (dispsiteCheckDetail.Count() > 0)
            {
                vm.DispsiteCheckDetail = dispsiteCheckDetail.ToList()[0];
                string detailId = vm.DispsiteCheckDetail.DetailId;
                IQueryable<DispsiteEval> dispiteEval = _DispsiteEvalRepository.GetAll().AsQueryable().Where(c => c.CheckDetailId == detailId);
                if (dispiteEval.Count() > 0)
                {
                    DispsiteEval dispsiteEval = dispiteEval.ToList()[0];
                    wasteProduceDate = dispsiteEval.ActivityProduceDate.Value.ToString("yyyy-MM-dd");
                    wasteGiftDate = dispsiteEval.ActivityGiftDate.Value.ToString("yyyy-MM-dd");
                    activityEvalDate = dispsiteEval.ActivityEvalDate.Value.ToString("yyyy-MM-dd");
                    if (string.IsNullOrEmpty(dispsiteEval.CheckName))
                    {
                        dispsiteEval.CheckName = AppContext.CurrentUser.UserName;
                        dispsiteEval.CheckNo = AppContext.CurrentUser.UserId;
                        dispsiteEval.CheckDate = DateTime.Now;
                    }
                    vm.DispsiteEval = dispsiteEval;

                }
                else
                {
                    vm.DispsiteEval = new DispsiteEval();
                }
            }
            else
            {
                vm.DispsiteEval = new DispsiteEval();
                vm.DispsiteCheckDetail = new DispsiteCheckDetail();
            }

            //废物包信息
            NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.GetPackageByBucketId(bucketId);
            vm.WastePackageBucketVM = new WastePackageBucketVM();
            vm.WastePackageBucketVM.NuclearWastePackage = nuclearWastePackage;
          
            //废物包活度计算信息
            ActivityCountCondition activityCountCondition = new ActivityCountCondition();
            activityCountCondition.BucketId = bucketId;
            IQueryable<ActivityCount> iqueryActivityCount = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition);
            ActivityCount activityCount = new ActivityCount();
            if (iqueryActivityCount.Count() > 0)
            {
                activityCount = iqueryActivityCount.ToList()[0];
                if (nuclearWastePackage != null)
                {
                    activityOrder = ActivityBuilder.GetActivityOrder(activityCount, vm.NuclearBucket, nuclearWastePackage.PackageCode);
                }
               
            }
            //处置场ID
            if (vm.NuclearProcessApply != null)
            {
                activityOrder.DispitePositionId = vm.NuclearProcessApply.ProcessFactoryId;
            }
            activityOrder.WasteProduceDate = activityOrder.WasteGiftDate;
            activityOrder.ActivityEvalDate = nuclearProcessApply.ApplyDate.ToShortDate();
            activityOrder.PackageWeight = nuclearWastePackage == null ? null : nuclearWastePackage.Weight.ToString();
            if (!string.IsNullOrEmpty(activityOrder.AcitivityId))
            {
                activityOrder = MetelActivityCalcuBuilder.GetMetelBucketCalcuElement(activityOrder);
            }

            //时间间隔
            try
            {
                if (!string.IsNullOrEmpty(wasteProduceDate) && !string.IsNullOrEmpty(wasteGiftDate))
                {
                    activityOrder.MinusProduceDate = (Convert.ToDateTime(wasteGiftDate) - Convert.ToDateTime(wasteProduceDate)).TotalDays.ToString();
                }
                if (!string.IsNullOrEmpty(activityEvalDate) && !string.IsNullOrEmpty(wasteProduceDate))
                {
                    activityOrder.MinusOriginalActivity = (Convert.ToDateTime(activityEvalDate) - Convert.ToDateTime(wasteGiftDate)).TotalDays.ToString();
                }
            }
            catch { }

            
            vm.ActivityOrder = activityOrder;

            //固化、封盖、转运信息 
            var SolutionModel = _NuclearBucketSolutionRepository.GetModelByBucketId(bucketId);
            var ResinModel = _NuclearBucketResinRepository.GetModelByBucketId(bucketId);
            var RSolidifyModel = _NuclearBucketRSolidifyRepository.GetModelByBucketId(bucketId);
            var SSolidifyModel = _NuclearBucketSSolidifyRepository.GetModelByBucketId(bucketId);
            var MetaModel = _NuclearCoverMetalRepository.GetModelByBucketId(bucketId);
            var MixModel = _NuclearCoverMixRepository.GetModelByBucketId(bucketId);
            var QtTransModel = _NuclearQtTransRepository.GetModelByBucketId(bucketId);
            var FcTransModel = _NuclearFcTransRepository.GetModelByBucketId(bucketId);
            var GoodsInModel = _NuclearTsGoodsInRepository.GetModelByBucketId(bucketId);
            var GoodsOutModel = _NuclearTsGoodsOutRepository.GetModelByBucketId(bucketId);
            if (SolutionModel != null)
                vm.SolutionId = SolutionModel.SolutionId;
            if (ResinModel != null)
                vm.ResinId = ResinModel.ResinId;
            if (RSolidifyModel != null)
                vm.RSolidifyId = RSolidifyModel.SolidifyRId;
            if (SSolidifyModel != null)
                vm.SSolidifyId = SSolidifyModel.SolidifySIdd;
            if (MetaModel != null)
            {
                vm.MetalId = MetaModel.MetalId;
                vm.DoseMeter = MetaModel.DoseMeter;
            }
            if (MixModel != null)
            {
                vm.DoseMeter = MixModel.DoseMeter;
                vm.MixId = MixModel.MixId;
            }
            if (QtTransModel != null)
                vm.QtTransId = QtTransModel.QtTransId;
            if (FcTransModel != null)
                vm.FcTransId = FcTransModel.FcDetailId;
            if (GoodsInModel != null)
                vm.GoodsInId = GoodsInModel.GoodsInDetailId;
            if (GoodsOutModel != null)
                vm.GoodsOutId = GoodsOutModel.GoodsOutDetailId;


            #region 废物跟踪单信息
            ////超压
            //var queryMetal = _NuclearCoverMetalRepository.GetAll().Where(d => d.BucketId == bucketId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            ////封盖
            //var queryMix = _NuclearCoverMixRepository.GetAll().Where(d => d.BucketId == bucketId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            List<string> bucketIdJoin = new List<string>();
            List<string> trackIdIdJoin = new List<string>();
            //if (queryMetal.Count() > 0)
            //{
            //    var queryDetail = _NuclearCoverMetalRepository.GetDetailByCoverId(queryMetal[0].MetalId);
            //    foreach (var item in queryDetail)
            //    {
            //        bucketIdJoin.Add(item.BucketId);
            //    }
            //}
            //if (queryMix.Count() > 0)
            //{
            //    bucketIdJoin.Add(queryMix[0].BucketId);
            //}
            //if (SolutionModel != null)
            //{ 
            
            //}
            //if (ResinModel != null)
            //{

            //}
            //if (RSolidifyModel != null)
            //{

            //}
            //if (SSolidifyModel != null)
            //{

            //}
            
            //foreach (var itemBucket in bucketIdJoin)
            //{
                //浓缩液装桶固化
            var querySolution = _NuclearBucketSolutionRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.BucketId == bucketId).ToList();
                //废树脂装桶固化
                var queryResin = _NuclearBucketResinRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.BucketId == bucketId).ToList();
                //废树脂固化
                var queryRSolidify = _NuclearBucketRSolidifyRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.BucketId == bucketId).ToList();
                //浓缩液固化
                var querySSolidify = _NuclearBucketSSolidifyRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.BucketId == bucketId).ToList();
                //固定
                NuclearFixation nuclearFixation = _NuclearFixationRepository.GetAll().Where(d => d.BucketId == bucketId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                if (querySolution.Count() > 0)
                {
                    trackIdIdJoin.Add(querySolution[0].TrackId);
                }
                if (queryResin.Count() > 0)
                {
                    List<NuclearGiftDetail> giftDetailList = _NuclearGiftDetailRepository.GetAll().Where(c => c.GiftId == queryResin[0].ResinId).ToList();
                    if (giftDetailList.Count() > 0)
                    {
                        foreach (var item in giftDetailList)
                        {
                            trackIdIdJoin.Add(item.TrackId);
                        }
                    }


                }

                if (queryRSolidify.Count() > 0)
                {
                    List<NuclearGiftDetail> giftDetailList = _NuclearGiftDetailRepository.GetAll().Where(c => c.GiftId == queryRSolidify[0].SolidifyRId).ToList();
                    if (giftDetailList.Count() > 0)
                    {
                        foreach (var item in giftDetailList)
                        {
                            trackIdIdJoin.Add(item.TrackId);
                        }
                    }

                }

                if (querySSolidify.Count() > 0)
                {
                    trackIdIdJoin.Add(querySSolidify[0].TrackId);
                }


                if (nuclearFixation != null)
                {

                    List<NuclearFixationDetail> detailList = _NuclearFixationRepository.GetFixAtionDetailById(nuclearFixation.FixationId).ToList();
                    foreach (var item in detailList)
                    {
                        trackIdIdJoin.Add(item.TrackId);
                    }
                }

            //}

            List<TrackItemVM> trackItemVM = new List<TrackItemVM>();
            List<TrackItem> trackIdIdJoinList = new List<TrackItem>();
            foreach (var item in trackIdIdJoin)
            {
                IQueryable<TrackItemVM> trackList = TrackItemBuilder.GetAllTrackList(item);
                TrackItem trackItem = new TrackItem();
                if (trackList.Count() > 0)
                {
                    trackItemVM = trackList.ToList();
                    trackItem.TrackId = trackItemVM[0].TrackId;
                    trackItem.TrackCode = trackItemVM[0].TrackCode;
                    trackItem.TrackType = trackItemVM[0].TrackType;
                    trackIdIdJoinList.Add(trackItem);
                }

            }


            vm.trackIdIdJoinList = trackIdIdJoinList;
            #endregion



            IQueryable<NuclearBucket> nuclearBucketIQ = _NuclearBucketRepository.GetAll().AsQueryable().Where(d => d.BucketId == bucketId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);

            IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().AsQueryable().Where(d => d.ChangeType == "INPUT");
            nuclearBucketChange = (from i in nuclearBucketChange
                                   join s in nuclearBucketIQ
                                   on i.BucketId equals s.BucketId
                                   select i).Distinct();

            if (nuclearBucketChange.Count() > 0)
                {
                    IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                    IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(nuclearBucketChange.ToList()[0].BusinessId, "QuestionReport");
                    vm.MaterialInputAttachFiles = (List<AttachFile>)listAttachFile;
                    ViewBag.BusinessType = "QuestionReport";
                }
            
           
           
            return View(vm);

        }


        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// 
        /// 
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetActivityList(string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = 1000000, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            //计算记录数
            List<DispiteEvalDetailVM> list = new List<DispiteEvalDetailVM>();
            if (activityOrder.DispiteEvalDetailVMList != null)
            {
                list = activityOrder.DispiteEvalDetailVMList;
            }
            jqGridResponse.TotalRecordsCount = list.Count;
            //生成前台json字符串
            list.ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ElementId,
                    List = new List<object>() {
                    d.ElementId,
                    d.ElementName,
                    d.ElementClass,
                     commonHelper.StringFormatGetE(Convert.ToDecimal(d.HalfLife)),
                    commonHelper.StringFormatGetE(Convert.ToDecimal(d.OriginalActivity.ToString())),
                    d.OriginalActivityPercent,   
                    "",
                    "",
                    "",
                    "",
                    ""
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 得到桶入库信息
        /// </summary>
        /// <param name="bucketId"></param>
        /// <returns></returns>
        public MaterialInputVM GetMaterialInput(string bucketId)
        {
            MaterialInputVM vm = new MaterialInputVM();
            IQueryable<MaterialInputVM> iqueryMaterialInput = WasteCheckBuilder.GetMaterialInput(bucketId);
            if (iqueryMaterialInput.Count() > 0)
            {
                vm = iqueryMaterialInput.ToList()[0];
            }
            return vm;

        }


        /// <summary>
        /// 得到桶检查信息
        /// </summary>
        /// <param name="bucketId">桶ID</param>
        /// <returns></returns>
        public NuclearBucketCheck GetNuclearBucketCheck(string bucketId)
        {
            NuclearBucketCheck bucketCheck = new NuclearBucketCheck();
            IQueryable<NuclearBucketCheck> iqueryBucketCheck = _NuclearBucketCheckRepository.GetBucketCheckByBucketId(bucketId);
            if (iqueryBucketCheck.Count() > 0)
            {
                bucketCheck = iqueryBucketCheck.ToList()[0];

            }
            return bucketCheck;
        }

        #endregion 页面

        #region 方法

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(DispsiteCheckCondition dispsiteCheckCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<DispsiteCheckView> data = this._DispsiteCheckRepository.QueryList(dispsiteCheckCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //绑定前台JqGrid参数.Where(d => d.Status == "2")
            var pagedViewModel = new PagedViewModel<DispsiteCheckView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ProcessApplyId,
                    List = new List<object>() {
                    d.ProcessApplyId,
                    d.ApplyCode,
                    d.PackageSum,
                    d.StoragePositionId,
                    d.TransFlag,
                    d.ApplyDate.HasValue? d.ApplyDate.Value.ToString("yyyy-MM-dd"):string.Empty,   
                    d.ApplyName,
                    d.Attachment,
                    d.Status,
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }


        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetWastePackageInfoList(string processApplyId, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            //获取数据
            IQueryable<NuclearApplyDetailView> data = this._DispsiteCheckRepository.QueryListById(processApplyId).Where(d => d.ProcessApplyId == processApplyId).AsQueryable();

            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearApplyDetailView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.WasteType,
                    List = new List<object>() {
                    //d.ApplyDetailId,
                    d.WasteType,
                    d.DealMethod,
                    d.MaterialName,
                    d.UnCheckedCount, 
                    d.CheckedCount, 
                    }
                });
            });

            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetWastePackageList(DispsiteCheckCondition dispsiteCheckCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<DispsiteCheckDetailView> dataWastePackageList = this._DispsiteCheckRepository.QueryWastePackageList(dispsiteCheckCondition);//;.Where(d => d.WasteType == dispsiteCheckCondition.WasteType && d.DealMethod == dispsiteCheckCondition.DealMethod && d.MaterialName == dispsiteCheckCondition.MaterialName);

            ActivityCountCondition activityCountCondition = new ActivityCountCondition();
            IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition).Where(d => d.Status == "2");

            var data = from d in dataWastePackageList
                       join a in activityCountList on d.BucketId equals a.BucketId into DispsiteCheckDetailEmpt
                       from e in DispsiteCheckDetailEmpt.DefaultIfEmpty()
                       select new DispsiteCheckDetailView
                       {
                           DetailId = d.DetailId,
                           ApplyDetailId = d.ApplyDetailId,
                           ProcessApplyId = d.ProcessApplyId,
                           BucketCode = d.BucketCode,
                           BucketId = d.BucketId,
                           PacakgeCode = d.PacakgeCode,
                           WasteType = d.WasteType,
                           DealMethod = d.DealMethod,
                           MaterialName = d.MaterialName,
                           GiftTime = d.GiftTime,
                           SurfacePercent = d.SurfacePercent,
                           IsPackage = "",
                           WastePackageStatus = d.WastePackageStatus,
                           TransferFun = e.TransferFun,
                           FileCompleted = d.FileCompleted,
                           Status = d.Status
                       };


            if (!string.IsNullOrEmpty(dispsiteCheckCondition.WasteType) && dispsiteCheckCondition.WasteType != "null")
            {
                data = data.Where(d => d.WasteType == dispsiteCheckCondition.WasteType);
            }
            if (!string.IsNullOrEmpty(dispsiteCheckCondition.DealMethod) && dispsiteCheckCondition.DealMethod != "null")
            {
                data = data.Where(d => d.DealMethod == dispsiteCheckCondition.DealMethod);
            }
            if (!string.IsNullOrEmpty(dispsiteCheckCondition.MaterialName))
            {
                data = data.Where(d => d.MaterialName == dispsiteCheckCondition.MaterialName);
            }
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<DispsiteCheckDetailView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DetailId,
                    List = new List<object>() {
                    d.DetailId,
                    d.BucketId,
                    d.ProcessApplyId,
                    d.BucketCode,
                    d.PacakgeCode,
                    d.WasteType,
                    d.DealMethod,
                    d.MaterialName,
                    d.GiftTime.HasValue?d.GiftTime.Value.ToString("yyyy-MM-dd"):string.Empty, 
                    d.SurfacePercent,
                    d.IsPackage,
                    d.WastePackageStatus,
                    d.TransferFun,
                    d.FileCompleted=="0"?"不完整":"完整",
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        DispsiteCheck GetDispsiteCheck(string processApplyId)
        {
            DispsiteCheck dispsiteCheck = null;
            IQueryable<DispsiteCheck> iqueryDispsiteCheck = _DispsiteCheckRepository.GetAll().AsQueryable().Where(c => c.ProcessApplyId == processApplyId);
            if (iqueryDispsiteCheck.Count() > 0)
            {
                dispsiteCheck = iqueryDispsiteCheck.ToList()[0];
            }
            return dispsiteCheck;
        }

        /// <summary>
        /// 保存废物包审核信息
        /// </summary>
        /// <param name="vm">废物包审核信息</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Create(WastePackageCheckVM vm, string applyDetailId)
        {
            string checkDetailId = "";
            try
            {
                vm.ApplyDetailId = applyDetailId;
                string message = string.Empty;
                IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == vm.ApplyDetailId);
                foreach (var item in nuclearApplyDetailQuery)
                {
                    ViewBag.ProcessApplyId = item.ProcessApplyId;
                }
                DispsiteCheck dispsiteCheck = GetDispsiteCheck(ViewBag.ProcessApplyId);
                if (dispsiteCheck == null)
                {
                    //废物包审核信息
                    dispsiteCheck = new DispsiteCheck();
                    dispsiteCheck.CheckId = Guid.NewGuid().ToString();
                    NuclearApplyDetail nuclearApplyDetails = _NuclearApplyDetailRepository.Get(vm.ApplyDetailId);
                    dispsiteCheck.ProcessApplyId = nuclearApplyDetails.ProcessApplyId;
                    dispsiteCheck.Stationcode = AppContext.CurrentUser.ProjectCode;
                    dispsiteCheck.Status = "0";
                    dispsiteCheck.CreateDate = DateTime.Now;
                    dispsiteCheck.CreateUserName = AppContext.CurrentUser.UserName;
                    dispsiteCheck.CreateUserNo = AppContext.CurrentUser.UserId;
                    this._DispsiteCheckRepository.Create(dispsiteCheck);

                    //废物包审核明细信息
                    vm.DispsiteCheckDetail.DetailId = Guid.NewGuid().ToString();
                    vm.DispsiteCheckDetail.CheckId = dispsiteCheck.CheckId;
                    if (vm.DispsiteCheckDetail.Checkresult == "1")
                    { vm.DispsiteCheckDetail.Status = "0"; }
                    else { vm.DispsiteCheckDetail.Status = "0"; }
                    vm.DispsiteCheckDetail.CreateDate = DateTime.Now;
                    vm.DispsiteCheckDetail.CreateUserName = AppContext.CurrentUser.UserName;
                    vm.DispsiteCheckDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                    vm.DispsiteCheckDetail.ConfirmDate = DateTime.Now;
                    vm.DispsiteCheckDetail.ConfirmUserName = AppContext.CurrentUser.UserName;
                    vm.DispsiteCheckDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    vm.DispsiteCheckDetail.ApplyDetailId = vm.ApplyDetailId;
                    this._DispsiteCheckDetailRepository.Create(vm.DispsiteCheckDetail);


                }
                else
                {
                    dispsiteCheck.Status = "0";
                    this._DispsiteCheckRepository.Update(dispsiteCheck);
                    IQueryable<DispsiteCheckDetail> query = _DispsiteCheckDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == applyDetailId);
                    if (query.Count() > 0)
                    {
                        vm.DispsiteCheckDetail = query.ToList()[0];
                    }
                    UpdateModel(vm);
                    if (vm.DispsiteCheckDetail.Checkresult == "1")
                    { vm.DispsiteCheckDetail.Status = "0"; }
                    else { vm.DispsiteCheckDetail.Status = "0"; }
                    if (query.Count() > 0)
                    {
                        this._DispsiteCheckDetailRepository.Update(vm.DispsiteCheckDetail);
                    }
                    if (vm.DispsiteCheckDetail.DetailId == null)
                    {
                        //废物包审核明细信息
                        vm.DispsiteCheckDetail.DetailId = Guid.NewGuid().ToString();
                        vm.DispsiteCheckDetail.CheckId = dispsiteCheck.CheckId;
                        if (vm.DispsiteCheckDetail.Checkresult == "1")
                        { vm.DispsiteCheckDetail.Status = "0"; }
                        else { vm.DispsiteCheckDetail.Status = "0"; }
                        vm.DispsiteCheckDetail.CreateDate = DateTime.Now;
                        vm.DispsiteCheckDetail.CreateUserName = AppContext.CurrentUser.UserName;
                        vm.DispsiteCheckDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                        vm.DispsiteCheckDetail.ConfirmDate = DateTime.Now;
                        vm.DispsiteCheckDetail.ConfirmUserName = AppContext.CurrentUser.UserName;
                        vm.DispsiteCheckDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        vm.DispsiteCheckDetail.ApplyDetailId = vm.ApplyDetailId;
                        this._DispsiteCheckDetailRepository.Create(vm.DispsiteCheckDetail);
                    }

                }

                //新增或修改废物验算评估信息
                checkDetailId = vm.DispsiteCheckDetail.DetailId;
                if (vm.ActivityOrder != null)
                {
                    activityOrder.WasteProduceDate = vm.ActivityOrder.WasteProduceDate;
                    activityOrder.WasteGiftDate = vm.ActivityOrder.WasteGiftDate;
                    activityOrder.ActivityEvalDate = vm.ActivityOrder.ActivityEvalDate;
                }
                SaveActivityData(vm, checkDetailId);

                NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.Get(applyDetailId);
                IQueryable<NuclearWastePackage> packageIdQuery = _DispsiteApproveRepository.QueryListByBucketId(nuclearApplyDetail.BucketId);
                foreach (var items in packageIdQuery)
                {
                    NuclearWastePackage nuclearWastePackage = this._NuclearWastePackageRepository.Get(items.PackageId);
                    if (nuclearWastePackage.Status != "APPLIED" && nuclearWastePackage.Status != "RECEPTED" && nuclearWastePackage.Status != "DEALED")
                    {
                        nuclearWastePackage.Status = "UNCHECKED";
                    }
                    this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                }//废物包状态(UNAPPLY:未申请处置  UNCHECKED:未审核 CHECKED:已审核 APPLIED：已申报  RECEPTED：已接收 DEALED:已处置 RETURN:已退回)
                this._DispsiteCheckRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":true,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(WastePackageCheckVM vm, FormCollection formCollection)
        {
            try
            {
                this.SaveAttachFile(vm.NuclearProcessApply.ProcessApplyId, "UploadOther", formCollection);
                this._DispsiteCheckRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":true,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交废物包审核信息
        /// </summary>
        /// <param name="vm">废物包审核信息</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(WastePackageCheckVM vm, string applyDetailId)
        {
            string checkDetailId = string.Empty;
            try
            {
                vm.ApplyDetailId = applyDetailId;
                string message = string.Empty;
                IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == vm.ApplyDetailId);
                foreach (var item in nuclearApplyDetailQuery)
                {
                    ViewBag.ProcessApplyId = item.ProcessApplyId;
                }
                DispsiteCheck dispsiteCheck = GetDispsiteCheck(ViewBag.ProcessApplyId);
                if (dispsiteCheck == null)
                {
                    //废物包审核信息
                    dispsiteCheck = new DispsiteCheck();
                    dispsiteCheck.CheckId = Guid.NewGuid().ToString();
                    NuclearApplyDetail nuclearApplyDetails = _NuclearApplyDetailRepository.Get(vm.ApplyDetailId);
                    dispsiteCheck.ProcessApplyId = nuclearApplyDetails.ProcessApplyId;
                    dispsiteCheck.Stationcode = AppContext.CurrentUser.ProjectCode;
                    dispsiteCheck.Status = "0";
                    dispsiteCheck.CreateDate = DateTime.Now;
                    dispsiteCheck.CreateUserName = AppContext.CurrentUser.UserName;
                    dispsiteCheck.CreateUserNo = AppContext.CurrentUser.UserId;
                    this._DispsiteCheckRepository.Create(dispsiteCheck);

                    //废物包审核明细信息
                    vm.DispsiteCheckDetail.DetailId = Guid.NewGuid().ToString();
                    vm.DispsiteCheckDetail.CheckId = dispsiteCheck.CheckId;
                    if (vm.DispsiteCheckDetail.Checkresult == "1")
                    { vm.DispsiteCheckDetail.Status = "1"; }
                    else { vm.DispsiteCheckDetail.Status = "1"; }
                    vm.DispsiteCheckDetail.CreateDate = DateTime.Now;
                    vm.DispsiteCheckDetail.CreateUserName = AppContext.CurrentUser.UserName;
                    vm.DispsiteCheckDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                    vm.DispsiteCheckDetail.ConfirmDate = DateTime.Now;
                    vm.DispsiteCheckDetail.ConfirmUserName = AppContext.CurrentUser.UserName;
                    vm.DispsiteCheckDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    vm.DispsiteCheckDetail.ApplyDetailId = vm.ApplyDetailId;
                    this._DispsiteCheckDetailRepository.Create(vm.DispsiteCheckDetail);
                }
                else
                {
                    dispsiteCheck.Status = "0";
                    this._DispsiteCheckRepository.Update(dispsiteCheck);
                    IQueryable<DispsiteCheckDetail> query = _DispsiteCheckDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == applyDetailId);
                    if (query.Count() > 0)
                    {
                        vm.DispsiteCheckDetail = query.ToList()[0];
                    }
                    UpdateModel(vm);
                    if (vm.DispsiteCheckDetail.Checkresult == "1")
                    { vm.DispsiteCheckDetail.Status = "1"; }
                    else { vm.DispsiteCheckDetail.Status = "1"; }
                    if (query.Count() > 0)
                    {
                        this._DispsiteCheckDetailRepository.Update(vm.DispsiteCheckDetail);
                    }
                    if (vm.DispsiteCheckDetail.DetailId == null)
                    {
                        //废物包审核明细信息
                        vm.DispsiteCheckDetail.DetailId = Guid.NewGuid().ToString();
                        vm.DispsiteCheckDetail.CheckId = dispsiteCheck.CheckId;
                        if (vm.DispsiteCheckDetail.Checkresult == "1")
                        { vm.DispsiteCheckDetail.Status = "1"; }
                        else { vm.DispsiteCheckDetail.Status = "1"; }
                        vm.DispsiteCheckDetail.CreateDate = DateTime.Now;
                        vm.DispsiteCheckDetail.CreateUserName = AppContext.CurrentUser.UserName;
                        vm.DispsiteCheckDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                        vm.DispsiteCheckDetail.ConfirmDate = DateTime.Now;
                        vm.DispsiteCheckDetail.ConfirmUserName = AppContext.CurrentUser.UserName;
                        vm.DispsiteCheckDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        vm.DispsiteCheckDetail.ApplyDetailId = vm.ApplyDetailId;
                        this._DispsiteCheckDetailRepository.Create(vm.DispsiteCheckDetail);
                    }
                }

                //新增或修改废物验算评估信息
                checkDetailId = vm.DispsiteCheckDetail.DetailId;
                if (vm.ActivityOrder != null)
                {
                    activityOrder.WasteProduceDate = vm.ActivityOrder.WasteProduceDate;
                    activityOrder.WasteGiftDate = vm.ActivityOrder.WasteGiftDate;
                    activityOrder.ActivityEvalDate = vm.ActivityOrder.ActivityEvalDate;
                }

                SaveActivityData(vm, checkDetailId);

                NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.Get(applyDetailId);
                IQueryable<NuclearWastePackage> packageIdQuery = _DispsiteApproveRepository.QueryListByBucketId(nuclearApplyDetail.BucketId);
                foreach (var items in packageIdQuery)
                {
                    NuclearWastePackage nuclearWastePackage = this._NuclearWastePackageRepository.Get(items.PackageId);
                    if (nuclearWastePackage.Status != "APPLIED" && nuclearWastePackage.Status != "RECEPTED" && nuclearWastePackage.Status != "DEALED")
                    {
                        nuclearWastePackage.Status = "UNCHECKED";
                    }
                    this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                }//废物包状态(UNAPPLY:未申请处置  UNCHECKED:未审核 CHECKED:已审核 APPLIED：已申报  RECEPTED：已接收 DEALED:已处置 RETURN:已退回)
                this._DispsiteCheckRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认废物包审核信息
        /// </summary>
        /// <param name="vm">废物包审核信息</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物包审核确认")]
        public JsonResult Confirm(WastePackageCheckVM vm, string applyDetailId)
        {
            string checkDetailId = string.Empty;
            try
            {
                #region
                vm.ApplyDetailId = applyDetailId;
                string message = string.Empty;
                NuclearProcessApply nuclearProcessApply = new NuclearProcessApply();
                IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == vm.ApplyDetailId);
                foreach (var item in nuclearApplyDetailQuery)
                {
                    nuclearProcessApply.ProcessApplyId = item.ProcessApplyId;
                    ViewBag.ProcessApplyId = item.ProcessApplyId;
                }
                DispsiteCheck dispsiteCheck = GetDispsiteCheck(ViewBag.ProcessApplyId);
                if (dispsiteCheck == null)
                {
                    //废物包审核信息
                    dispsiteCheck = new DispsiteCheck();
                    dispsiteCheck.CheckId = Guid.NewGuid().ToString();

                    NuclearApplyDetail nuclearApplyDetails = _NuclearApplyDetailRepository.Get(vm.ApplyDetailId);
                    dispsiteCheck.ProcessApplyId = nuclearApplyDetails.ProcessApplyId;
                    dispsiteCheck.Stationcode = AppContext.CurrentUser.ProjectCode;
                    dispsiteCheck.Status = "1";
                    dispsiteCheck.CreateDate = DateTime.Now;
                    dispsiteCheck.CreateUserName = AppContext.CurrentUser.UserName;
                    dispsiteCheck.CreateUserNo = AppContext.CurrentUser.UserId;
                    this._DispsiteCheckRepository.Create(dispsiteCheck);
                    //废物包审核明细信息
                    vm.DispsiteCheckDetail.DetailId = Guid.NewGuid().ToString();
                    vm.DispsiteCheckDetail.CheckId = dispsiteCheck.CheckId;
                    vm.DispsiteCheckDetail.Status = "2";
                    vm.DispsiteCheckDetail.CreateDate = DateTime.Now;
                    vm.DispsiteCheckDetail.CreateUserName = AppContext.CurrentUser.UserName;
                    vm.DispsiteCheckDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                    vm.DispsiteCheckDetail.ConfirmDate = DateTime.Now;
                    vm.DispsiteCheckDetail.ConfirmUserName = AppContext.CurrentUser.UserName;
                    vm.DispsiteCheckDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    vm.DispsiteCheckDetail.ApplyDetailId = vm.ApplyDetailId;
                    this._DispsiteCheckDetailRepository.Create(vm.DispsiteCheckDetail);
                }
                else
                {
                    IQueryable<DispsiteCheckDetail> query = _DispsiteCheckDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == applyDetailId);
                    if (query.Count() > 0)
                    {
                        vm.DispsiteCheckDetail = query.ToList()[0];

                        UpdateModel(vm);
                        vm.DispsiteCheckDetail.Status = "2";
                        vm.DispsiteCheckDetail.ConfirmDate = DateTime.Now;
                        vm.DispsiteCheckDetail.ConfirmUserName = AppContext.CurrentUser.UserName;
                        vm.DispsiteCheckDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        this._DispsiteCheckDetailRepository.Update(vm.DispsiteCheckDetail);
                        NuclearApplyDetail detail = _NuclearApplyDetailRepository.Get(applyDetailId);
                        if (detail != null)
                        {
                            detail.Status = "1";
                        }
                        _NuclearApplyDetailRepository.Update(detail);

                    }
                    if (vm.DispsiteCheckDetail.DetailId == null)
                    {
                        //废物包审核明细信息
                        vm.DispsiteCheckDetail.DetailId = Guid.NewGuid().ToString();
                        vm.DispsiteCheckDetail.CheckId = dispsiteCheck.CheckId;
                        vm.DispsiteCheckDetail.Status = "2";
                        vm.DispsiteCheckDetail.CreateDate = DateTime.Now;
                        vm.DispsiteCheckDetail.CreateUserName = AppContext.CurrentUser.UserName;
                        vm.DispsiteCheckDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                        vm.DispsiteCheckDetail.ConfirmDate = DateTime.Now;
                        vm.DispsiteCheckDetail.ConfirmUserName = AppContext.CurrentUser.UserName;
                        vm.DispsiteCheckDetail.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        vm.DispsiteCheckDetail.ApplyDetailId = vm.ApplyDetailId;
                        this._DispsiteCheckDetailRepository.Create(vm.DispsiteCheckDetail);
                        NuclearApplyDetail detail = _NuclearApplyDetailRepository.Get(applyDetailId);
                        if (detail != null)
                        {
                            detail.Status = "1";

                        }
                        _NuclearApplyDetailRepository.Update(detail);
                    }
                    //更新废物审核信息
                    bool isCompleted = true;
                    IQueryable<DispsiteCheckDetail> iqueryList = _DispsiteCheckDetailRepository.GetAll().AsQueryable().Where(c => c.CheckId == vm.DispsiteCheckDetail.CheckId);
                    if (iqueryList.Count() > 0)
                    {
                        foreach (var item in iqueryList)
                        {
                            if (item.Status != "2")
                            {
                                isCompleted = false;
                                break;
                            }
                        }
                    }
                    if (isCompleted)
                    {
                        DispsiteCheck dispsiteChecks = _DispsiteCheckRepository.Get(vm.DispsiteCheckDetail.CheckId);
                        if (dispsiteChecks != null)
                        {
                            dispsiteChecks.Status = "1";
                            _DispsiteCheckRepository.Update(dispsiteChecks);
                        }
                    }
                }
                #endregion

                //新增或修改废物验算评估信息
                checkDetailId = vm.DispsiteCheckDetail.DetailId;
                if (vm.ActivityOrder != null)
                {
                    activityOrder.WasteProduceDate = vm.ActivityOrder.WasteProduceDate;
                    activityOrder.WasteGiftDate = vm.ActivityOrder.WasteGiftDate;
                    activityOrder.ActivityEvalDate = vm.ActivityOrder.ActivityEvalDate;

                }
                SaveActivityData(vm, checkDetailId);

                //更新废物审核以及废物包状态 
                NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.Get(applyDetailId);
                nuclearApplyDetail.Status = "1";
                this._NuclearApplyDetailRepository.Update(nuclearApplyDetail);
                IQueryable<NuclearWastePackage> packageIdQuery = _DispsiteApproveRepository.QueryListByBucketId(nuclearApplyDetail.BucketId);
                foreach (var items in packageIdQuery)
                {
                    //判断审核结果是否同意
                    if (vm.DispsiteCheckDetail.Checkresult == "1")
                    {
                        NuclearWastePackage nuclearWastePackage = this._NuclearWastePackageRepository.Get(items.PackageId);
                        if (nuclearWastePackage.Status != "APPLIED" && nuclearWastePackage.Status != "RECEPTED" && nuclearWastePackage.Status != "DEALED")
                        {
                            nuclearWastePackage.Status = "CHECKED";
                        }
                        this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                    }
                    else
                    {
                        NuclearWastePackage nuclearWastePackage = this._NuclearWastePackageRepository.Get(items.PackageId);
                        if (nuclearWastePackage.Status != "APPLIED" && nuclearWastePackage.Status != "RECEPTED" && nuclearWastePackage.Status != "DEALED")
                        {
                            nuclearWastePackage.Status = "RETURN";
                        }
                        this._NuclearWastePackageRepository.Update(nuclearWastePackage);

                        //发送邮件提醒
                        List<NuclearProcessApply> nuclearProcessApplyQuery = _NuclearProcessApplyRepository.GetAll().AsQueryable().Where(c => c.ProcessApplyId == nuclearProcessApply.ProcessApplyId).ToList();
                        NET01.CoreFramework.Mail.ISmtpClient smtpClent = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<NET01.CoreFramework.Mail.ISmtpClient>();
                        string copyUsers = string.Empty;
                        string systemAddress = ConfigurationManager.AppSettings["SystemAddress"];
                        var mailService = new RWIS.Application.Implementation.MailService(smtpClent);
                        string sendTitle = string.Format("废物包审核被退回通知");
                        string sendContent = "您好！" + "<br/>" + "&nbsp;" + "废物包" + nuclearWastePackage.PackageCode + "审核不通过，已被退回。" + "<br/>" + "&nbsp;" + "请点击" + "<a href=" + systemAddress + ">废物货包审核</a>" + "进入系统进行确认，谢谢！";
                        mailService.SendMailService(nuclearProcessApplyQuery[0].ApplyNo, copyUsers, sendTitle, sendContent);  //nuclearProcessApplyQuery[0].ApplyNo
                    }
                }//废物包状态(UNAPPLY:未申请处置  UNCHECKED:未审核 CHECKED:已审核 APPLIED：已申报  RECEPTED：已接收 DEALED:已处置 RETURN:已退回)

                this._DispsiteCheckRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":true,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 保存放射性验算评估数据
        /// </summary>
        /// <param name="vm">页面实体</param>
        /// <param name="checkDetailId">废物审核明细ID</param>
        void SaveActivityData(WastePackageCheckVM vm, string checkDetailId)
        {
            IQueryable<DispsiteEval> iqueryDispsiteEval = _DispsiteEvalRepository.GetAll().AsQueryable().Where(c => c.CheckDetailId == checkDetailId);
            DispsiteEval eval = null;
            bool isNewAdd = false;
            if (iqueryDispsiteEval.Count() == 0)
            {
                isNewAdd = true;
                eval = new DispsiteEval();
                eval.EvalId = Guid.NewGuid().ToString();
            }
            else
            {
                List<DispsiteEval> list = iqueryDispsiteEval.ToList<DispsiteEval>();
                eval = iqueryDispsiteEval.ToList()[0];
            }

            eval.CheckDetailId = checkDetailId;
            eval.ActivityId = activityOrder.AcitivityId;
            eval.ActivityProduceDate = Convert.ToDateTime(activityOrder.WasteProduceDate);
            eval.ActivityEvalDate = Convert.ToDateTime(activityOrder.ActivityEvalDate);
            eval.ActivityGiftDate = Convert.ToDateTime(activityOrder.WasteGiftDate);
            eval.TotalCheckActivity = activityOrder.TotalCheckActivity;
            eval.TotalActivity = activityOrder.TotalActivity;
            eval.DecayThreeHundred = activityOrder.DecayThreeHundred;
            eval.DecayThreeHundredValue = activityOrder.DecayThreeHundredValue;
            eval.Classify = activityOrder.Classify;
            eval.ClassifyValue = activityOrder.ClassifyValue;
            eval.SurfaceClass = activityOrder.SurfaceClass;
            eval.DecayHeat = activityOrder.DecayHeat;
            eval.CalcuThreeHundred = activityOrder.CalcuThreeHundred;
            eval.ActivityCompare = activityOrder.ActivityCompare;
            eval.keyActivityUnitCompare = activityOrder.KeyActivityUnitCompare;
            eval.StationCode = AppContext.CurrentUser.ProjectCode;

            eval.CheckDate=vm.DispsiteEval.CheckDate;
            eval.CheckName=vm.DispsiteEval.CheckName;
            eval.CheckNo = vm.DispsiteEval.CheckNo;

            eval.CalcuName = vm.DispsiteEval.CalcuName;
            eval.CalcuNo = vm.DispsiteEval.CalcuNo;
            eval.CalcuDate = vm.DispsiteEval.CalcuDate;

            //如果是新增 
            if (isNewAdd)
            {
                _DispsiteEvalRepository.Create(eval);
            }
            else //如果是修改 
            {
                _DispsiteEvalRepository.Update(eval);
                IQueryable<DispiteEvalDetail> iqueryEvalDetail = _DispsiteEvalDetailRepository.GetAll().AsQueryable().Where(c => c.EvalId == eval.EvalId);

                //删除明细信息 
                foreach (var item in iqueryEvalDetail)
                {
                    _DispsiteEvalDetailRepository.Delete(item);
                }
            }
            if (activityOrder.DispiteEvalDetailVMList != null)
            {

                //新增明细信息 
                foreach (var item in activityOrder.DispiteEvalDetailVMList)
                {
                    DispiteEvalDetail detail = new DispiteEvalDetail();
                    detail.DetailId = Guid.NewGuid().ToString();
                    detail.EvalId = eval.EvalId;
                    detail.ElementId = item.ElementId;
                    detail.HalfLife = item.HalfLife;
                    detail.OriginalActivity = item.OriginalActivity.ToString();
                    detail.OriginalActivityPercent = item.OriginalActivityPercent;
                    detail.CalcuSpectraPercent = item.CalcuSpectraPercent;
                    detail.InitialActivity = item.InitialActivity;
                    detail.OriginalWasteActivity = item.OriginalWasteActivity;
                    detail.CheckdateActivity = item.CheckdateActivity;
                    detail.CheckdateActivityPercent = item.CheckdateActivityPercent;
                    detail.CheckdateActivityUnit = item.CheckdateActivityUnit;
                    detail.StationCode = AppContext.CurrentUser.ProjectCode;
                    _DispsiteEvalDetailRepository.Create(detail);
                }
            }

        }

        /// <summary>
        /// 修改或编辑废物审核数据
        /// </summary>
        /// <param name="vm">废物审核数据</param>
        /// <param name="status">状态值</param>
        void SaveOrUpdate(WastePackageCheckVM vm, string status)
        {
            string message = string.Empty;
            IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == vm.ApplyDetailId);
            foreach (var item in nuclearApplyDetailQuery)
            {
                ViewBag.ProcessApplyId = item.ProcessApplyId;
            }
            DispsiteCheck dispsiteCheck = GetDispsiteCheck(ViewBag.ProcessApplyId);
            //新增
            if (dispsiteCheck == null)
            {
                dispsiteCheck = new DispsiteCheck();
                dispsiteCheck.CheckId = Guid.NewGuid().ToString();
                NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.Get(vm.ApplyDetailId);
                dispsiteCheck.ProcessApplyId = nuclearApplyDetail.ProcessApplyId;
                dispsiteCheck.Stationcode = AppContext.CurrentUser.ProjectCode;
                dispsiteCheck.Status = "0";
                dispsiteCheck.CreateDate = DateTime.Now;
                dispsiteCheck.CreateUserName = AppContext.CurrentUser.UserName;
                dispsiteCheck.CreateUserNo = AppContext.CurrentUser.UserId;
                this._DispsiteCheckRepository.Create(dispsiteCheck);

                //废物包审核信息
                vm.DispsiteCheckDetail.DetailId = Guid.NewGuid().ToString();
                vm.DispsiteCheckDetail.CheckId = dispsiteCheck.CheckId;
                vm.DispsiteCheckDetail.Status = status;
                vm.DispsiteCheckDetail.CreateDate = DateTime.Now;
                vm.DispsiteCheckDetail.CreateUserName = AppContext.CurrentUser.UserName;
                vm.DispsiteCheckDetail.CreateUserNo = AppContext.CurrentUser.UserId;
                vm.DispsiteCheckDetail.ApplyDetailId = vm.ApplyDetailId;
                this._DispsiteCheckDetailRepository.Create(vm.DispsiteCheckDetail);
            }
            else
            {
                string applyDetailId = vm.ApplyDetailId;
                IQueryable<DispsiteCheckDetail> query = _DispsiteCheckDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == applyDetailId);
                if (query.Count() > 0)
                {
                    vm.DispsiteCheckDetail = query.ToList()[0];
                }
                UpdateModel(vm);
                vm.DispsiteCheckDetail.Status = status;
                if (query.Count() > 0)
                {
                    this._DispsiteCheckDetailRepository.Update(vm.DispsiteCheckDetail);
                }
            }
        }


        #region 附件
        /// <summary>
        /// 附件
        /// </summary>
        /// <param name="formCollection"></param>
        /// <returns></returns>

        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], "DispsiteCheck");
            }
            return null;
        }
        /// <summary>
        /// 下载文件
        /// 
        /// </summary>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }
        #endregion

        #region 打印
        /// <summary>
        /// 导出
        /// </summary>
        /// <param name="applyDetailId">申请单明细ID</param>
        /// <returns></returns>
        [HttpGet]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "审核单导出")]
        public ActionResult Print(DispsiteCheckCondition dispsiteCheckCondition)
        {
            List<DispsiteCheckDetailView> data = this._DispsiteCheckRepository.QueryWastePackageList(dispsiteCheckCondition).Where(d => d.WasteType == dispsiteCheckCondition.WasteType && d.DealMethod == dispsiteCheckCondition.DealMethod && d.MaterialName == dispsiteCheckCondition.MaterialName).ToList();
            for (int i = 0; i < data.Count(); i++)
            {
                if (data[i].WastePackageStatus == "UNCHECKED")
                {
                    data[i].WastePackageStatus = "未审核";
                }
                if (data[i].WastePackageStatus == "CHECKED")
                {
                    data[i].WastePackageStatus = "已审核";
                }
                if (data[i].WastePackageStatus == "UNRECEPTED")
                {
                    data[i].WastePackageStatus = "已退回";
                }
                if (data[i].WastePackageStatus == "DEALED")
                {
                    data[i].WastePackageStatus = "已处置";
                }
                if (data[i].WastePackageStatus == "RECEPTED")
                {
                    data[i].WastePackageStatus = "已接收";
                }
                if (data[i].WastePackageStatus == "APPLIED")
                {
                    data[i].WastePackageStatus = "已申报";
                }
                if (data[i].WastePackageStatus == "RETURN")
                {
                    data[i].WastePackageStatus = "已退回";
                }
            }
            //创建文档对象
            HSSFWorkbook hssfworkbook = new HSSFWorkbook();
            //然后创建DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();
            dsi.Company = "NPOI Team";
            // 再创建SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Subject = "NPOI SDK Example";

            // 创建好的对象赋给Workbook 保证这些信息被写入文件。
            hssfworkbook.DocumentSummaryInformation = dsi;
            hssfworkbook.SummaryInformation = si;
            #region 编辑excel1


            //创建工作表
            HSSFSheet sheet1 = (HSSFSheet)hssfworkbook.CreateSheet("Sheet1");
            //创建行
            HSSFRow row1 = (HSSFRow)sheet1.CreateRow(0);
            HSSFRow row2 = (HSSFRow)sheet1.CreateRow(1);
            HSSFRow row3 = (HSSFRow)sheet1.CreateRow(2);
            HSSFRow row4 = (HSSFRow)sheet1.CreateRow(3);
            HSSFRow row5 = (HSSFRow)sheet1.CreateRow(4);
            List<DispsiteCheckDetailView> item = data.ToList();
            string stutas = string.Empty;
            if (data.Count() > 0)
            {
                stutas = data[0].WastePackageStatus;
            }
            for (int i = 1; i <= data.Count(); i++)
            {


                HSSFRow row = (HSSFRow)sheet1.CreateRow(i + 4);
                sheet1.CreateRow(i + 4).Height = 30 * 20;
                sheet1.AddMergedRegion(new CellRangeAddress(i + 4, i + 4, 10, 11));
                HSSFCell cell0000 = (HSSFCell)row.CreateCell(0);
                HSSFCell cell0001 = (HSSFCell)row.CreateCell(1);
                cell0001.SetCellValue(i);
                HSSFCell cell0002 = (HSSFCell)row.CreateCell(2);
                cell0002.SetCellValue(data[i - 1].BucketCode);
                HSSFCell cell0003 = (HSSFCell)row.CreateCell(3);
                cell0003.SetCellValue(data[i - 1].PacakgeCode);
                HSSFCell cell0004 = (HSSFCell)row.CreateCell(4);
                cell0004.SetCellValue(data[i - 1].WasteType);
                HSSFCell cell0005 = (HSSFCell)row.CreateCell(5);
                cell0005.SetCellValue(data[i - 1].GiftTime.HasValue ? data[i - 1].GiftTime.Value.ToString("yyyy-MM-dd") : string.Empty);
                HSSFCell cell0006 = (HSSFCell)row.CreateCell(6);
                cell0006.SetCellValue(data[i - 1].SurfacePercent.ToString());
                HSSFCell cell0007 = (HSSFCell)row.CreateCell(7);
                cell0007.SetCellValue(data[i - 1].IsPackage);
                HSSFCell cell0008 = (HSSFCell)row.CreateCell(8);
                cell0008.SetCellValue(data[i - 1].WastePackageStatus);
                HSSFCell cell0009 = (HSSFCell)row.CreateCell(9);
                cell0009.SetCellValue(data[i - 1].TransferFun.ToString());
                HSSFCell cell0010 = (HSSFCell)row.CreateCell(10);
                cell0010.SetCellValue(data[i - 1].FileCompleted == "1" ? "是" : "否");
                HSSFCell cell0011 = (HSSFCell)row.CreateCell(11);
                HSSFCell cell0012 = (HSSFCell)row.CreateCell(12);


                //单元格样式——一级标题 左
                HSSFCellStyle stylels = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                stylels.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                //单元格样式——一级标题 右
                HSSFCellStyle stylers = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                stylers.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                //单元格样式——一级标题-垂直居中
                HSSFCellStyle style6 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style6.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
                style6.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                style6.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                style6.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
                style6.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
                style6.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                HSSFFont font6 = (HSSFFont)hssfworkbook.CreateFont();
                font6.FontHeight = 15 * 20;//字体高度
                style6.SetFont(font6);

                cell0000.CellStyle = stylels;
                cell0001.CellStyle = style6;
                cell0002.CellStyle = style6;
                cell0003.CellStyle = style6;
                cell0004.CellStyle = style6;
                cell0005.CellStyle = style6;
                cell0006.CellStyle = style6;
                cell0007.CellStyle = style6;
                cell0008.CellStyle = style6;
                cell0009.CellStyle = style6;
                cell0010.CellStyle = style6;
                cell0011.CellStyle = style6;
                cell0012.CellStyle = stylers;
            }

            //int rowNo = 14;
            HSSFRow row15 = (HSSFRow)sheet1.CreateRow(data.Count() + 5);
            sheet1.CreateRow(data.Count() + 5).Height = 30 * 20;
            HSSFRow row16 = (HSSFRow)sheet1.CreateRow(data.Count() + 6);
            sheet1.CreateRow(data.Count() + 6).Height = 30 * 20;
            HSSFRow row17 = (HSSFRow)sheet1.CreateRow(data.Count() + 7);
            sheet1.CreateRow(data.Count() + 7).Height = 30 * 20;
            HSSFRow row18 = (HSSFRow)sheet1.CreateRow(data.Count() + 8);
            sheet1.CreateRow(data.Count() + 8).Height = 30 * 20;
            HSSFRow row19 = (HSSFRow)sheet1.CreateRow(data.Count() + 9);
            sheet1.CreateRow(data.Count() + 9).Height = 30 * 20;
            HSSFRow row20 = (HSSFRow)sheet1.CreateRow(data.Count() + 10);
            sheet1.CreateRow(data.Count() + 10).Height = 30 * 20;
            HSSFRow row21 = (HSSFRow)sheet1.CreateRow(data.Count() + 11);
            sheet1.CreateRow(data.Count() + 11).Height = 30 * 20;
            HSSFRow row22 = (HSSFRow)sheet1.CreateRow(data.Count() + 12);
            sheet1.CreateRow(data.Count() + 12).Height = 30 * 20;
            HSSFRow row23 = (HSSFRow)sheet1.CreateRow(data.Count() + 13);
            sheet1.CreateRow(data.Count() + 13).Height = 30 * 20;
            HSSFRow row24 = (HSSFRow)sheet1.CreateRow(data.Count() + 14);
            sheet1.CreateRow(data.Count() + 14).Height = 30 * 20;
            HSSFRow row25 = (HSSFRow)sheet1.CreateRow(data.Count() + 15);
            sheet1.CreateRow(data.Count() + 15).Height = 30 * 20;


            //设置列宽 
            sheet1.SetColumnWidth(0, 10 * 100);
            sheet1.SetColumnWidth(1, 30 * 100);
            sheet1.SetColumnWidth(2, 35 * 100);
            sheet1.SetColumnWidth(3, 60 * 100);
            sheet1.SetColumnWidth(4, 45 * 100);
            sheet1.SetColumnWidth(5, 45 * 100);
            sheet1.SetColumnWidth(6, 45 * 100);
            sheet1.SetColumnWidth(7, 45 * 100);
            sheet1.SetColumnWidth(8, 70 * 100);
            sheet1.SetColumnWidth(9, 45 * 100);
            sheet1.SetColumnWidth(10, 40 * 100);
            sheet1.SetColumnWidth(11, 40 * 100);
            sheet1.SetColumnWidth(12, 10 * 100);

            //行高
            sheet1.CreateRow(0).Height = 50 * 20;
            sheet1.CreateRow(1).Height = 20 * 20;
            sheet1.CreateRow(2).Height = 30 * 20;
            sheet1.CreateRow(3).Height = 20 * 20;
            sheet1.CreateRow(4).Height = 30 * 20;

            //合并单元格（起始行号、终止行号、起始列号、终止列号）
            sheet1.AddMergedRegion(new CellRangeAddress(0, 0, 2, 9));
            sheet1.AddMergedRegion(new CellRangeAddress(2, 2, 7, 10));
            sheet1.AddMergedRegion(new CellRangeAddress(4, 4, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(5, 5, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(6, 6, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(7, 7, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(8, 8, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(9, 9, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(10, 10, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(11, 11, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(12, 12, 10, 11));
            sheet1.AddMergedRegion(new CellRangeAddress(14, 14, 1, 6));
            sheet1.AddMergedRegion(new CellRangeAddress(20, 20, 1, 5));
            sheet1.AddMergedRegion(new CellRangeAddress(22, 22, 1, 5));

            //单元格样式——一级标题 上
            HSSFCellStyle stylet = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            stylet.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 左
            HSSFCellStyle stylel = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            stylel.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 右
            HSSFCellStyle styler = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styler.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 上左
            HSSFCellStyle styletl = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styletl.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            styletl.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 上右
            HSSFCellStyle styletr = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styletr.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            styletr.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题
            HSSFCellStyle style = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font = (HSSFFont)hssfworkbook.CreateFont();
            font.FontHeight = 28 * 20;//字体高度
            style.SetFont(font);

            //单元格样式——文本
            HSSFCellStyle style2 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style2.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            style2.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            HSSFFont font2 = (HSSFFont)hssfworkbook.CreateFont();
            font2.FontHeight = 15 * 20;//字体高度
            style2.SetFont(font2);

            //单元格样式——二级标题
            HSSFCellStyle style3 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style3.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style3.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font3 = (HSSFFont)hssfworkbook.CreateFont();
            font3.FontHeight = 22 * 20;//字体高度
            style3.SetFont(font3);

            //创建列
            HSSFCell cell011 = (HSSFCell)row1.CreateCell(0);
            HSSFCell cell012 = (HSSFCell)row1.CreateCell(1);
            HSSFCell cell013 = (HSSFCell)row1.CreateCell(2);
            cell013.SetCellValue("审 查 报 告 单");
            HSSFCell cell014 = (HSSFCell)row1.CreateCell(3);
            HSSFCell cell015 = (HSSFCell)row1.CreateCell(4);
            HSSFCell cell016 = (HSSFCell)row1.CreateCell(5);
            HSSFCell cell017 = (HSSFCell)row1.CreateCell(6);
            HSSFCell cell018 = (HSSFCell)row1.CreateCell(7);
            HSSFCell cell019 = (HSSFCell)row1.CreateCell(8);
            HSSFCell cell0110 = (HSSFCell)row1.CreateCell(9);
            HSSFCell cell0111 = (HSSFCell)row1.CreateCell(10);
            HSSFCell cell0112 = (HSSFCell)row1.CreateCell(11);
            HSSFCell cell0113 = (HSSFCell)row1.CreateCell(12);
            //应用单元格样式
            cell011.CellStyle = styletl;
            cell012.CellStyle = stylet;
            cell013.CellStyle = style;
            cell014.CellStyle = style;
            cell015.CellStyle = style;
            cell016.CellStyle = style;
            cell017.CellStyle = style;
            cell018.CellStyle = style;
            cell019.CellStyle = style;
            cell0110.CellStyle = style;
            cell0111.CellStyle = style;
            cell0112.CellStyle = stylet;
            cell0113.CellStyle = styletr;

            //创建列
            HSSFCell cell021 = (HSSFCell)row2.CreateCell(0);
            HSSFCell cell022 = (HSSFCell)row2.CreateCell(1);
            HSSFCell cell023 = (HSSFCell)row2.CreateCell(2);
            HSSFCell cell024 = (HSSFCell)row2.CreateCell(3);
            HSSFCell cell025 = (HSSFCell)row2.CreateCell(4);
            HSSFCell cell026 = (HSSFCell)row2.CreateCell(5);
            HSSFCell cell027 = (HSSFCell)row2.CreateCell(6);
            HSSFCell cell028 = (HSSFCell)row2.CreateCell(7);
            HSSFCell cell029 = (HSSFCell)row2.CreateCell(8);
            HSSFCell cell0210 = (HSSFCell)row2.CreateCell(9);
            HSSFCell cell0211 = (HSSFCell)row2.CreateCell(10);
            HSSFCell cell0212 = (HSSFCell)row2.CreateCell(11);
            HSSFCell cell0213 = (HSSFCell)row2.CreateCell(12);
            //应用单元格样式
            cell021.CellStyle = stylel;
            cell0213.CellStyle = styler;

            //创建列
            HSSFCell cell031 = (HSSFCell)row3.CreateCell(0);
            HSSFCell cell032 = (HSSFCell)row3.CreateCell(1);
            HSSFCell cell033 = (HSSFCell)row3.CreateCell(2);
            HSSFCell cell034 = (HSSFCell)row3.CreateCell(3);
            HSSFCell cell035 = (HSSFCell)row3.CreateCell(4);
            HSSFCell cell036 = (HSSFCell)row3.CreateCell(5);
            HSSFCell cell037 = (HSSFCell)row3.CreateCell(6);
            HSSFCell cell038 = (HSSFCell)row3.CreateCell(7);
            cell038.SetCellValue("核对报告单编号:");//设置单元格内容
            HSSFCell cell039 = (HSSFCell)row3.CreateCell(8);
            HSSFCell cell0310 = (HSSFCell)row3.CreateCell(9);
            HSSFCell cell0311 = (HSSFCell)row3.CreateCell(10);
            HSSFCell cell0312 = (HSSFCell)row3.CreateCell(11);
            HSSFCell cell0313 = (HSSFCell)row3.CreateCell(12);
            //应用单元格样式
            cell031.CellStyle = stylel;
            cell038.CellStyle = style2;
            cell0313.CellStyle = styler;

            //创建列
            HSSFCell cell041 = (HSSFCell)row4.CreateCell(0);
            HSSFCell cell042 = (HSSFCell)row4.CreateCell(1);
            HSSFCell cell043 = (HSSFCell)row4.CreateCell(2);
            HSSFCell cell044 = (HSSFCell)row4.CreateCell(3);
            HSSFCell cell045 = (HSSFCell)row4.CreateCell(4);
            HSSFCell cell046 = (HSSFCell)row4.CreateCell(5);
            HSSFCell cell047 = (HSSFCell)row4.CreateCell(6);
            HSSFCell cell048 = (HSSFCell)row4.CreateCell(7);
            HSSFCell cell049 = (HSSFCell)row4.CreateCell(8);
            HSSFCell cell0410 = (HSSFCell)row4.CreateCell(9);
            HSSFCell cell0411 = (HSSFCell)row4.CreateCell(10);
            HSSFCell cell0412 = (HSSFCell)row4.CreateCell(11);
            HSSFCell cell0413 = (HSSFCell)row4.CreateCell(12);
            //应用单元格样式
            cell041.CellStyle = stylel;
            cell0413.CellStyle = styler;

            //单元格样式——一级标题-垂直居中
            HSSFCellStyle style5 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style5.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
            style5.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            style5.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            style5.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
            style5.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;
            style5.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            HSSFFont font5 = (HSSFFont)hssfworkbook.CreateFont();
            font5.FontHeight = 15 * 20;//字体高度
            style5.SetFont(font5);
            //创建列
            HSSFCell cell051 = (HSSFCell)row5.CreateCell(0);
            HSSFCell cell052 = (HSSFCell)row5.CreateCell(1);
            cell052.SetCellValue("序号");
            HSSFCell cell053 = (HSSFCell)row5.CreateCell(2);
            cell053.SetCellValue("桶号");
            HSSFCell cell054 = (HSSFCell)row5.CreateCell(3);
            cell054.SetCellValue("编码");
            HSSFCell cell055 = (HSSFCell)row5.CreateCell(4);
            cell055.SetCellValue("废物类型");
            HSSFCell cell056 = (HSSFCell)row5.CreateCell(5);
            cell056.SetCellValue("固化时间");
            HSSFCell cell057 = (HSSFCell)row5.CreateCell(6);
            cell057.SetCellValue("表面剂量率");
            HSSFCell cell058 = (HSSFCell)row5.CreateCell(7);
            cell058.SetCellValue("废物货包标识");
            HSSFCell cell059 = (HSSFCell)row5.CreateCell(8);
            cell059.SetCellValue("废物货包处理状态");
            HSSFCell cell0510 = (HSSFCell)row5.CreateCell(9);
            cell0510.SetCellValue("转换函数");
            HSSFCell cell0511 = (HSSFCell)row5.CreateCell(10);
            cell0511.SetCellValue("文件记录完整性");
            HSSFCell cell0512 = (HSSFCell)row5.CreateCell(11);
            HSSFCell cell0513 = (HSSFCell)row5.CreateCell(12);
            //应用单元格样式
            cell051.CellStyle = stylel;
            cell052.CellStyle = style5;
            cell053.CellStyle = style5;
            cell054.CellStyle = style5;
            cell055.CellStyle = style5;
            cell056.CellStyle = style5;
            cell057.CellStyle = style5;
            cell058.CellStyle = style5;
            cell059.CellStyle = style5;
            cell0510.CellStyle = style5;
            cell0511.CellStyle = style5;
            cell0512.CellStyle = style5;
            cell0513.CellStyle = styler;

            //单元格样式——一级标题-垂直居中
            HSSFCellStyle style15 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            style15.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
            HSSFFont font15 = (HSSFFont)hssfworkbook.CreateFont();
            font15.FontHeight = 15 * 20;//字体高度
            style15.SetFont(font15);
            //创建列
            HSSFCell cell151 = (HSSFCell)row15.CreateCell(0);
            HSSFCell cell152 = (HSSFCell)row15.CreateCell(1);
            cell152.SetCellValue("核实废物包能否满足北龙处置场“废物包质量要求”规定的各项要求:");
            HSSFCell cell153 = (HSSFCell)row15.CreateCell(2);
            HSSFCell cell154 = (HSSFCell)row15.CreateCell(3);
            HSSFCell cell155 = (HSSFCell)row15.CreateCell(4);
            HSSFCell cell156 = (HSSFCell)row15.CreateCell(5);
            HSSFCell cell157 = (HSSFCell)row15.CreateCell(6);
            HSSFCell cell158 = (HSSFCell)row15.CreateCell(7);
            HSSFCell cell159 = (HSSFCell)row15.CreateCell(8);
            HSSFCell cell1510 = (HSSFCell)row15.CreateCell(9);
            HSSFCell cell1511 = (HSSFCell)row15.CreateCell(10);
            HSSFCell cell1512 = (HSSFCell)row15.CreateCell(11);
            HSSFCell cell1513 = (HSSFCell)row15.CreateCell(12);
            //应用单元格样式
            //应用单元格样式
            cell151.CellStyle = stylel;
            cell152.CellStyle = style15;
            cell1513.CellStyle = styler;

            //创建列
            HSSFCell cell161 = (HSSFCell)row16.CreateCell(0);
            HSSFCell cell162 = (HSSFCell)row16.CreateCell(1);
            HSSFCell cell163 = (HSSFCell)row16.CreateCell(2);
            HSSFCell cell164 = (HSSFCell)row16.CreateCell(3);
            HSSFCell cell165 = (HSSFCell)row16.CreateCell(4);
            HSSFCell cell166 = (HSSFCell)row16.CreateCell(5);
            HSSFCell cell167 = (HSSFCell)row16.CreateCell(6);
            HSSFCell cell168 = (HSSFCell)row16.CreateCell(7);
            HSSFCell cell169 = (HSSFCell)row16.CreateCell(8);
            HSSFCell cell1610 = (HSSFCell)row16.CreateCell(9);
            HSSFCell cell1611 = (HSSFCell)row16.CreateCell(10);
            HSSFCell cell1612 = (HSSFCell)row16.CreateCell(11);
            HSSFCell cell1613 = (HSSFCell)row16.CreateCell(12);
            //应用单元格样式
            //应用单元格样式
            cell161.CellStyle = stylel;
            cell1613.CellStyle = styler;

            //创建列
            HSSFCell cell171 = (HSSFCell)row17.CreateCell(0);
            HSSFCell cell172 = (HSSFCell)row17.CreateCell(1);
            HSSFCell cell173 = (HSSFCell)row17.CreateCell(2);
            HSSFCell cell174 = (HSSFCell)row17.CreateCell(3);
            HSSFCell cell175 = (HSSFCell)row17.CreateCell(4);
            HSSFCell cell176 = (HSSFCell)row17.CreateCell(5);
            HSSFCell cell177 = (HSSFCell)row17.CreateCell(6);
            HSSFCell cell178 = (HSSFCell)row17.CreateCell(7);
            HSSFCell cell179 = (HSSFCell)row17.CreateCell(8);
            HSSFCell cell1710 = (HSSFCell)row17.CreateCell(9);
            HSSFCell cell1711 = (HSSFCell)row17.CreateCell(10);
            HSSFCell cell1712 = (HSSFCell)row17.CreateCell(11);
            HSSFCell cell1713 = (HSSFCell)row17.CreateCell(12);
            //应用单元格样式
            //应用单元格样式
            cell171.CellStyle = stylel;
            cell1713.CellStyle = styler;

            //创建列
            HSSFCell cell181 = (HSSFCell)row18.CreateCell(0);
            HSSFCell cell182 = (HSSFCell)row18.CreateCell(1);
            HSSFCell cell183 = (HSSFCell)row18.CreateCell(2);
            HSSFCell cell184 = (HSSFCell)row18.CreateCell(3);
            HSSFCell cell185 = (HSSFCell)row18.CreateCell(4);
            HSSFCell cell186 = (HSSFCell)row18.CreateCell(5);
            HSSFCell cell187 = (HSSFCell)row18.CreateCell(6);
            HSSFCell cell188 = (HSSFCell)row18.CreateCell(7);
            HSSFCell cell189 = (HSSFCell)row18.CreateCell(8);
            HSSFCell cell1810 = (HSSFCell)row18.CreateCell(9);
            HSSFCell cell1811 = (HSSFCell)row18.CreateCell(10);
            HSSFCell cell1812 = (HSSFCell)row18.CreateCell(11);
            HSSFCell cell1813 = (HSSFCell)row18.CreateCell(12);
            //应用单元格样式
            //应用单元格样式
            cell181.CellStyle = stylel;
            cell1813.CellStyle = styler;

            //创建列
            HSSFCell cell191 = (HSSFCell)row19.CreateCell(0);
            HSSFCell cell192 = (HSSFCell)row19.CreateCell(1);
            HSSFCell cell193 = (HSSFCell)row19.CreateCell(2);
            HSSFCell cell194 = (HSSFCell)row19.CreateCell(3);
            HSSFCell cell195 = (HSSFCell)row19.CreateCell(4);
            HSSFCell cell196 = (HSSFCell)row19.CreateCell(5);
            HSSFCell cell197 = (HSSFCell)row19.CreateCell(6);
            HSSFCell cell198 = (HSSFCell)row19.CreateCell(7);
            HSSFCell cell199 = (HSSFCell)row19.CreateCell(8);
            HSSFCell cell1910 = (HSSFCell)row19.CreateCell(9);
            HSSFCell cell1911 = (HSSFCell)row19.CreateCell(10);
            HSSFCell cell1912 = (HSSFCell)row19.CreateCell(11);
            HSSFCell cell1913 = (HSSFCell)row19.CreateCell(12);
            //应用单元格样式
            //应用单元格样式
            cell191.CellStyle = stylel;
            cell1913.CellStyle = styler;

            //创建列
            HSSFCell cell201 = (HSSFCell)row20.CreateCell(0);
            HSSFCell cell202 = (HSSFCell)row20.CreateCell(1);
            HSSFCell cell203 = (HSSFCell)row20.CreateCell(2);
            HSSFCell cell204 = (HSSFCell)row20.CreateCell(3);
            HSSFCell cell205 = (HSSFCell)row20.CreateCell(4);
            HSSFCell cell206 = (HSSFCell)row20.CreateCell(5);
            HSSFCell cell207 = (HSSFCell)row20.CreateCell(6);
            HSSFCell cell208 = (HSSFCell)row20.CreateCell(7);
            HSSFCell cell209 = (HSSFCell)row20.CreateCell(8);
            HSSFCell cell2010 = (HSSFCell)row20.CreateCell(9);
            HSSFCell cell2011 = (HSSFCell)row20.CreateCell(10);
            HSSFCell cell2012 = (HSSFCell)row20.CreateCell(11);
            HSSFCell cell2013 = (HSSFCell)row20.CreateCell(12);
            //应用单元格样式
            //应用单元格样式
            cell201.CellStyle = stylel;
            cell2013.CellStyle = styler;

            //创建列
            HSSFCell cell211 = (HSSFCell)row21.CreateCell(0);
            HSSFCell cell212 = (HSSFCell)row21.CreateCell(1);
            cell212.SetCellValue("审查人签字:");
            HSSFCell cell213 = (HSSFCell)row21.CreateCell(2);
            HSSFCell cell214 = (HSSFCell)row21.CreateCell(3);
            HSSFCell cell215 = (HSSFCell)row21.CreateCell(4);
            HSSFCell cell216 = (HSSFCell)row21.CreateCell(5);
            HSSFCell cell217 = (HSSFCell)row21.CreateCell(6);
            HSSFCell cell218 = (HSSFCell)row21.CreateCell(7);
            HSSFCell cell219 = (HSSFCell)row21.CreateCell(8);
            HSSFCell cell2110 = (HSSFCell)row21.CreateCell(9);
            cell2110.SetCellValue("年");
            HSSFCell cell2111 = (HSSFCell)row21.CreateCell(10);
            cell2111.SetCellValue("月");
            HSSFCell cell2112 = (HSSFCell)row21.CreateCell(11);
            cell2112.SetCellValue("日");
            HSSFCell cell2113 = (HSSFCell)row21.CreateCell(12);
            //应用单元格样式
            cell211.CellStyle = stylel;
            cell212.CellStyle = style15;
            cell213.CellStyle = style15;
            cell214.CellStyle = style15;
            cell215.CellStyle = style15;
            cell216.CellStyle = style15;
            cell217.CellStyle = style15;
            cell218.CellStyle = style15;
            cell219.CellStyle = style15;
            cell2110.CellStyle = style15;
            cell2111.CellStyle = style15;
            cell2112.CellStyle = style15;
            cell2113.CellStyle = styler;

            //创建列
            HSSFCell cell221 = (HSSFCell)row22.CreateCell(0);
            HSSFCell cell222 = (HSSFCell)row22.CreateCell(1);
            HSSFCell cell223 = (HSSFCell)row22.CreateCell(2);
            HSSFCell cell224 = (HSSFCell)row22.CreateCell(3);
            HSSFCell cell225 = (HSSFCell)row22.CreateCell(4);
            HSSFCell cell226 = (HSSFCell)row22.CreateCell(5);
            HSSFCell cell227 = (HSSFCell)row22.CreateCell(6);
            HSSFCell cell228 = (HSSFCell)row22.CreateCell(7);
            HSSFCell cell229 = (HSSFCell)row22.CreateCell(8);
            HSSFCell cell2210 = (HSSFCell)row22.CreateCell(9);
            HSSFCell cell2211 = (HSSFCell)row22.CreateCell(10);
            HSSFCell cell2212 = (HSSFCell)row22.CreateCell(11);
            HSSFCell cell2213 = (HSSFCell)row22.CreateCell(12);
            //应用单元格样式
            //应用单元格样式
            cell221.CellStyle = stylel;
            cell2213.CellStyle = styler;

            //创建列
            HSSFCell cell231 = (HSSFCell)row23.CreateCell(0);
            HSSFCell cell232 = (HSSFCell)row23.CreateCell(1);
            cell232.SetCellValue("处置场负责人签字:");
            HSSFCell cell233 = (HSSFCell)row23.CreateCell(2);
            HSSFCell cell234 = (HSSFCell)row23.CreateCell(3);
            HSSFCell cell235 = (HSSFCell)row23.CreateCell(4);
            HSSFCell cell236 = (HSSFCell)row23.CreateCell(5);
            HSSFCell cell237 = (HSSFCell)row23.CreateCell(6);
            HSSFCell cell238 = (HSSFCell)row23.CreateCell(7);
            HSSFCell cell239 = (HSSFCell)row23.CreateCell(8);
            HSSFCell cell2310 = (HSSFCell)row23.CreateCell(9);
            cell2310.SetCellValue("年");
            HSSFCell cell2311 = (HSSFCell)row23.CreateCell(10);
            cell2311.SetCellValue("月");
            HSSFCell cell2312 = (HSSFCell)row23.CreateCell(11);
            cell2312.SetCellValue("日");
            HSSFCell cell2313 = (HSSFCell)row23.CreateCell(12);
            //应用单元格样式
            cell231.CellStyle = stylel;
            cell232.CellStyle = style15;
            cell233.CellStyle = style15;
            cell234.CellStyle = style15;
            cell235.CellStyle = style15;
            cell236.CellStyle = style15;
            cell237.CellStyle = style15;
            cell238.CellStyle = style15;
            cell239.CellStyle = style15;
            cell2310.CellStyle = style15;
            cell2311.CellStyle = style15;
            cell2312.CellStyle = style15;
            cell2313.CellStyle = styler;

            //创建列
            HSSFCell cell241 = (HSSFCell)row24.CreateCell(0);
            HSSFCell cell242 = (HSSFCell)row24.CreateCell(1);
            HSSFCell cell243 = (HSSFCell)row24.CreateCell(2);
            HSSFCell cell244 = (HSSFCell)row24.CreateCell(3);
            HSSFCell cell245 = (HSSFCell)row24.CreateCell(4);
            HSSFCell cell246 = (HSSFCell)row24.CreateCell(5);
            HSSFCell cell247 = (HSSFCell)row24.CreateCell(6);
            HSSFCell cell248 = (HSSFCell)row24.CreateCell(7);
            HSSFCell cell249 = (HSSFCell)row24.CreateCell(8);
            HSSFCell cell2410 = (HSSFCell)row24.CreateCell(9);
            HSSFCell cell2411 = (HSSFCell)row24.CreateCell(10);
            HSSFCell cell2412 = (HSSFCell)row24.CreateCell(11);
            HSSFCell cell2413 = (HSSFCell)row24.CreateCell(12);
            //应用单元格样式
            //应用单元格样式
            cell241.CellStyle = stylel;
            cell2413.CellStyle = styler;

            //单元格样式——一级标题 下
            HSSFCellStyle styleb = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            styleb.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 下左
            HSSFCellStyle stylebl = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            stylebl.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
            stylebl.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

            //单元格样式——一级标题 下右
            HSSFCellStyle stylebr = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
            stylebr.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
            stylebr.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;

            //创建列
            HSSFCell cell251 = (HSSFCell)row25.CreateCell(0);
            HSSFCell cell252 = (HSSFCell)row25.CreateCell(1);
            HSSFCell cell253 = (HSSFCell)row25.CreateCell(2);
            HSSFCell cell254 = (HSSFCell)row25.CreateCell(3);
            HSSFCell cell255 = (HSSFCell)row25.CreateCell(4);
            HSSFCell cell256 = (HSSFCell)row25.CreateCell(5);
            HSSFCell cell257 = (HSSFCell)row25.CreateCell(6);
            HSSFCell cell258 = (HSSFCell)row25.CreateCell(7);
            HSSFCell cell259 = (HSSFCell)row25.CreateCell(8);
            HSSFCell cell2510 = (HSSFCell)row25.CreateCell(9);
            HSSFCell cell2511 = (HSSFCell)row25.CreateCell(10);
            HSSFCell cell2512 = (HSSFCell)row25.CreateCell(11);
            HSSFCell cell2513 = (HSSFCell)row25.CreateCell(12);
            //应用单元格样式
            cell251.CellStyle = stylebl;
            cell252.CellStyle = styleb;
            cell253.CellStyle = styleb;
            cell254.CellStyle = styleb;
            cell255.CellStyle = styleb;
            cell256.CellStyle = styleb;
            cell257.CellStyle = styleb;
            cell258.CellStyle = styleb;
            cell259.CellStyle = styleb;
            cell2510.CellStyle = styleb;
            cell2511.CellStyle = styleb;
            cell2512.CellStyle = styleb;
            cell2513.CellStyle = stylebr;

            #endregion

            #region  工作流
            //工作流
            MemoryStream stream = new MemoryStream();
            hssfworkbook.Write(stream);

            string saveFileName = string.Format("{0}_{1}.xls", stutas, DateTime.Now.ToString("yyyy-MM-dd"));
            string fileName = Server.MapPath("~") + "\\ExcelTemplate\\" + saveFileName;
            SaveToFile(stream, fileName);
            FileInfo downLoadFile = new FileInfo(fileName);
            System.Web.HttpContext context = System.Web.HttpContext.Current;
            context.Response.Clear();
            context.Response.ClearHeaders();
            context.Response.Buffer = false;
            context.Response.ContentType = "application/octet-stream";
            context.Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlDecode(saveFileName, System.Text.Encoding.UTF8));
            context.Response.AddHeader("content-length", downLoadFile.Length.ToString());
            context.Response.WriteFile(downLoadFile.FullName);
            context.Response.Flush();
            context.Response.End();
            if (System.IO.File.Exists(fileName))
            {
                System.IO.File.Delete(fileName);
            }
            return null;
        }

        private void SaveToFile(MemoryStream ms, string fileName)
        {
            using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write))
            {
                byte[] data = ms.ToArray();

                fs.Write(data, 0, data.Length);
                fs.Flush();
                data = null;
            }
        }
            #endregion

        #endregion

        /// <summary>
        /// 根据核电场模块的活度计算单ID得到处置场模块活度计算的核素活度信息
        /// </summary>
        /// <param name="activityId">活度计算单ID</param>
        /// <returns></returns>

        public JsonResult GetElementList(string activityId, string activityType, ActivityOrder activityOrder)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 100000000, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            try
            {
                activityOrder = WasteCheckBuilder.GetElementList(activityId, activityType, activityOrder);
                //获取数据
                List<DispiteEvalDetail> list = activityOrder.DispiteEvalDetailList;
                //计算记录数
                jqGridResponse.TotalRecordsCount = list.Count;
                //生成前台json字符串
                list.ForEach(d =>
                {
                    jqGridResponse.Records.Add(new JqGridRecord()
                    {
                        Id = d.DetailId,
                        List = new List<object>() {
                    d.DetailId,
                    d.ElementId,
                    d.ElementName,
                    d.HalfLife+"天",
                    d.OriginalActivity, 
                    d.OriginalActivityPercent, 
                    d.CalcuSpectraPercent,
                    d.InitialActivity,
                    d.OriginalWasteActivity,
                    d.CheckdateActivity,
                    d.CheckdateActivityPercent,

                    }
                    });
                });


            }
            catch
            { }
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 根据活度计算ID以及活度计算类型得到计算单信息
        /// </summary>
        /// <param name="activityId">活度计算ID</param>
        /// <param name="activityType">活度计算类型</param>
        /// <returns></returns>
        public JsonResult GetActivityOrder(string date1, string date2, string date3)
        {
            CommonHelper commonHelper = new CommonHelper();
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 100000000, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            try
            {
                //获取数据
                List<DispiteEvalDetailVM> list = new List<DispiteEvalDetailVM>();
                if (activityOrder.DispiteEvalDetailVMList != null)
                {
                    list = activityOrder.DispiteEvalDetailVMList;

                    //计算记录数
                    jqGridResponse.TotalRecordsCount = list.Count;
                    //生成前台json字符串
                    list.ForEach(d =>
                    {
                        jqGridResponse.Records.Add(new JqGridRecord()
                        {

                            Id = d.DetailId,
                            List = new List<object>() {
                    d.ElementId,
                    d.ElementName,
                    d.ElementClass,
                    d.HalfLife,
                    commonHelper.StringFormatGetE(Convert.ToDecimal(d.OriginalActivity==null?"0":d.OriginalActivity.ToString())), 
                    commonHelper.StringFormatGetE(Convert.ToDecimal((d.OriginalWasteActivity==null || d.OriginalWasteActivity=="采样分析")?"0":d.OriginalWasteActivity.ToString())), 
                    commonHelper.StringFormatGetE(Convert.ToDecimal(d.CheckdateActivity)),
                    d.IsSpecialActivityUnit==true?commonHelper.StringFormatGetE( Convert.ToDecimal(d.CheckdateActivityUnit))+" (Bq/g)":commonHelper.StringFormatGetE(Convert.ToDecimal(d.CheckdateActivityUnit)),
                        }
                        });
                    });
                }
            }
            catch
            { }
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 统计方法 
        /// </summary>
        /// <param name="date1"></param>
        /// <param name="date2"></param>
        /// <param name="date3"></param>
        /// <returns></returns>
        public JsonResult GetStatisticActivityOrder(string date1, string date2, string date3)
        {
            CommonHelper commonHelper = new CommonHelper();
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = 1, PageSize = 100000000, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            try
            {
                activityOrder.WasteProduceDate = date1;
                activityOrder.WasteGiftDate = date2;
                activityOrder.ActivityEvalDate = date3;
                ActivityOrder order = MetelActivityCalcuBuilder.GetMetelBucketCalcuElement(activityOrder);
                activityOrder = order;
                //获取数据
                List<DispiteEvalDetailVM> list = order.DispiteEvalDetailVMList;
                //计算记录数
                jqGridResponse.TotalRecordsCount = list.Count;
                //生成前台json字符串
                list.ForEach(d =>
                {
                    jqGridResponse.Records.Add(new JqGridRecord()
                    {
                        Id = d.DetailId,
                        List = new List<object>() {
                    d.ElementId,
                    d.ElementName,
                    d.ElementClass,
                    d.HalfLife,
                    commonHelper.StringFormatGetE(Convert.ToDecimal(d.OriginalActivity==null?"0":d.OriginalActivity.ToString())), 
                    commonHelper.StringFormatGetE(Convert.ToDecimal((d.OriginalWasteActivity==null || d.OriginalWasteActivity=="采样分析")?"0":d.OriginalWasteActivity.ToString())), 
                    commonHelper.StringFormatGetE(Convert.ToDecimal(d.CheckdateActivity)),
                    d.IsSpecialActivityUnit==true?commonHelper.StringFormatGetE(Convert.ToDecimal(d.CheckdateActivityUnit))+" (Bq/g)":commonHelper.StringFormatGetE(Convert.ToDecimal(d.CheckdateActivityUnit)),
                        }
                    });
                });


            }
            catch
            { }
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        #endregion 方法
        #region 废物货包审核导出
        /// <summary>
        /// 废物货包质量确认导出
        /// </summary>
        /// <param name="confirmId"></param>
        /// <returns></returns>
        public ActionResult Confirm(string bucketCode, string packageCode)
        {

            ToExcel(bucketCode, packageCode);
            return null;
        }

        private void ToExcel(string bucketCode, string packageCode)
        {

            //创建工作簿对象
            XSSFWorkbook xssfworkbook;
            //打开模板文件到文件流中
            using (FileStream file = new FileStream(System.Web.HttpContext.Current.Request.PhysicalApplicationPath + @"ExcelTemplate/废物包审核.xlsx", FileMode.Open, FileAccess.Read))
            {
                //将文件流中模板加载到工作簿对象中
                xssfworkbook = new XSSFWorkbook(file);
            }
            //建立一个名为Sheet1的工作表
            XSSFSheet sheet1 = (XSSFSheet)xssfworkbook.GetSheet("Sheet1");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;

            string bucketId = _NuclearBucketRepository.GetIdByCode(bucketCode, AppContext.CurrentUser.ProjectCode);

            string wasteProduceDate = null;
            string wasteGiftDate = null;
            string activityEvalDate = null;
            WastePackageCheckVM vm = new WastePackageCheckVM();
            vm.ActivityOrder = new ActivityOrder();
            vm.OperationList = CommonHelper.GetOperationList("Waste_Pacage_Check");

            NuclearApplyDetail nuclearApplyDetail = new NuclearApplyDetail();
            IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == bucketId).AsQueryable();
            foreach (var item in nuclearApplyDetailQuery)
            {
                nuclearApplyDetail.ApplyDetailId = item.ApplyDetailId;
            }
            vm.NuclearApplyDetail = nuclearApplyDetail;
            NuclearApplyDetail applyDetail = _NuclearApplyDetailRepository.Get(nuclearApplyDetail.ApplyDetailId);
            NuclearProcessApply nuclearProcessApply = new NuclearProcessApply();
            nuclearProcessApply.ProcessApplyId = applyDetail.ProcessApplyId;
            vm.NuclearProcessApply = nuclearProcessApply;

            List<SelectListItem> checkList = new List<SelectListItem>();
            checkList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
            checkList.Add(new SelectListItem { Text = "否", Value = "0" });

            NuclearBucket nuclearBucket = this._NuclearBucketRepository.Get(bucketId);
            vm.WasteType = nuclearBucket.WasteType;
            vm.DealMethod = nuclearBucket.DealMethod;

            MaterialType materialType = this._MaterialTypeRepository.Get(nuclearBucket.MaterialId);
            vm.MaterialName = materialType.MaterialName;
            vm.CheckMaterialList = checkList;
            vm.CheckBucketAduitList = checkList;
            vm.CheckBucketMesList = checkList;
            vm.EvaluateList = checkList;
            vm.CheckBucketDealList = checkList;
            vm.CheckBucketCoverList = checkList;
            vm.CheckBucketTransferList = checkList;
            vm.FileIsCompletedList = checkList;

            List<SelectListItem> checkResultList = new List<SelectListItem>();
            checkResultList.Add(new SelectListItem { Text = "同意", Value = "1", Selected = true });
            checkResultList.Add(new SelectListItem { Text = "不同意", Value = "0" });
            vm.CheckResultList = checkResultList;
            vm.ApplyDetailId = nuclearApplyDetail.ApplyDetailId;
            ViewBag.ApplyDetailId = nuclearApplyDetail.ApplyDetailId;
            //桶入库材料信息
            vm.MaterialInputVM = GetMaterialInput(bucketId);

            //桶检查信息
            vm.NuclearBucketCheck = GetNuclearBucketCheck(bucketId);
            if (vm.NuclearBucketCheck == null)
            {
                vm.NuclearBucketCheck = new NuclearBucketCheck();
            }

            //桶信息
            vm.NuclearBucket = this._NuclearBucketRepository.Get(bucketId);
            if (vm.NuclearBucket == null)
            {
                vm.NuclearBucket = new NuclearBucket();
            }
            //存储和转运信息
            vm.IsExistTransferAndStorage = WasteCheckBuilder.IsExistTransferAndStorage(bucketId);

            //审核明细信息
            activityOrder.MinusProduceDate = string.Empty;
            activityOrder.MinusOriginalActivity = string.Empty;
            IQueryable<DispsiteCheckDetail> dispsiteCheckDetail = this._DispsiteCheckDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == nuclearApplyDetail.ApplyDetailId);
            if (dispsiteCheckDetail.Count() > 0)
            {
                vm.DispsiteCheckDetail = dispsiteCheckDetail.ToList()[0];
                string detailId = vm.DispsiteCheckDetail.DetailId;
                IQueryable<DispsiteEval> dispiteEval = _DispsiteEvalRepository.GetAll().AsQueryable().Where(c => c.CheckDetailId == detailId);
                if (dispiteEval.Count() > 0)
                {
                    DispsiteEval dispsiteEval = dispiteEval.ToList()[0];
                    wasteProduceDate = dispsiteEval.ActivityProduceDate.Value.ToString("yyyy-MM-dd");
                    wasteGiftDate = dispsiteEval.ActivityGiftDate.Value.ToString("yyyy-MM-dd");
                    activityEvalDate = dispsiteEval.ActivityEvalDate.Value.ToString("yyyy-MM-dd");

                }
            }
            else
            {
                vm.DispsiteCheckDetail = new DispsiteCheckDetail();
            }

            //废物包信息
            NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.GetPackageByBucketId(bucketId);
            vm.WastePackageBucketVM = new WastePackageBucketVM();
            vm.WastePackageBucketVM.NuclearWastePackage = nuclearWastePackage;

            //废物包活度计算信息
            ActivityCountCondition activityCountCondition = new ActivityCountCondition();
            activityCountCondition.BucketId = bucketId;
            IQueryable<ActivityCount> iqueryActivityCount = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition);
            ActivityCount activityCount = new ActivityCount();
            if (iqueryActivityCount.Count() > 0)
            {
                activityCount = iqueryActivityCount.ToList()[0];
                activityOrder = ActivityBuilder.GetActivityOrder(activityCount, vm.NuclearBucket, nuclearWastePackage.PackageCode);
            }
            activityOrder.WasteProduceDate = wasteProduceDate;
            activityOrder.WasteGiftDate = wasteGiftDate;
            activityOrder.ActivityEvalDate = activityEvalDate;
            activityOrder.PackageWeight = nuclearWastePackage == null ? null : nuclearWastePackage.Weight.ToString();
            if (!string.IsNullOrEmpty(activityOrder.AcitivityId))
            {
                activityOrder = MetelActivityCalcuBuilder.GetMetelBucketCalcuElement(activityOrder);
            }

            //时间间隔
            try
            {
                if (!string.IsNullOrEmpty(wasteProduceDate) && !string.IsNullOrEmpty(wasteGiftDate))
                {
                    activityOrder.MinusProduceDate = (Convert.ToDateTime(wasteGiftDate) - Convert.ToDateTime(wasteProduceDate)).TotalDays.ToString();
                }
                if (!string.IsNullOrEmpty(activityEvalDate) && !string.IsNullOrEmpty(wasteProduceDate))
                {
                    activityOrder.MinusOriginalActivity = (Convert.ToDateTime(activityEvalDate) - Convert.ToDateTime(wasteGiftDate)).TotalDays.ToString();
                }
            }
            catch { }

            vm.ActivityOrder = activityOrder;

            //固化、封盖、转运信息 
            var SolutionModel = _NuclearBucketSolutionRepository.GetModelByBucketId(bucketId);
            var ResinModel = _NuclearBucketResinRepository.GetModelByBucketId(bucketId);
            var RSolidifyModel = _NuclearBucketRSolidifyRepository.GetModelByBucketId(bucketId);
            var SSolidifyModel = _NuclearBucketSSolidifyRepository.GetModelByBucketId(bucketId);
            var MetaModel = _NuclearCoverMetalRepository.GetModelByBucketId(bucketId);
            var MixModel = _NuclearCoverMixRepository.GetModelByBucketId(bucketId);
            var QtTransModel = _NuclearQtTransRepository.GetModelByBucketId(bucketId);
            var FcTransModel = _NuclearFcTransRepository.GetModelByBucketId(bucketId);
            var GoodsInModel = _NuclearTsGoodsInRepository.GetModelByBucketId(bucketId);
            var GoodsOutModel = _NuclearTsGoodsOutRepository.GetModelByBucketId(bucketId);
            if (SolutionModel != null)
                vm.SolutionId = SolutionModel.SolutionId;
            if (ResinModel != null)
                vm.ResinId = ResinModel.ResinId;
            if (RSolidifyModel != null)
                vm.RSolidifyId = RSolidifyModel.SolidifyRId;
            if (SSolidifyModel != null)
                vm.SSolidifyId = SSolidifyModel.SolidifySIdd;
            if (MetaModel != null)
            {
                vm.MetalId = MetaModel.MetalId;
                vm.DoseMeter = MetaModel.DoseMeter;
            }
            if (MixModel != null)
            {
                vm.DoseMeter = MixModel.DoseMeter;
                vm.MixId = MixModel.MixId;
            }
            if (QtTransModel != null)
                vm.QtTransId = QtTransModel.QtTransId;
            if (FcTransModel != null)
                vm.FcTransId = FcTransModel.FcDetailId;
            if (GoodsInModel != null)
                vm.GoodsInId = GoodsInModel.GoodsInDetailId;
            if (GoodsOutModel != null)
                vm.GoodsOutId = GoodsOutModel.GoodsOutDetailId;







            sheet1.GetRow(6).GetCell(2).SetCellValue(vm.MaterialInputVM.BucketCode);
            sheet1.GetRow(6).GetCell(6).SetCellValue(vm.WastePackageBucketVM.NuclearWastePackage.PackageCode);
            sheet1.GetRow(6).GetCell(13).SetCellValue(vm.ActivityOrder.WasteProduceDate);
            sheet1.GetRow(7).GetCell(2).SetCellValue(vm.NuclearBucket.WasteType);
            sheet1.GetRow(7).GetCell(6).SetCellValue(vm.ActivityOrder.BucketHandleCount);
            sheet1.GetRow(7).GetCell(13).SetCellValue(vm.ActivityOrder.WasteGiftDate);
            if (vm.ActivityOrder.Damage == "1")
            {
                sheet1.GetRow(8).GetCell(2).SetCellValue("有");
            }
            else
            {
                sheet1.GetRow(8).GetCell(2).SetCellValue("无");
            }

            sheet1.GetRow(8).GetCell(6).SetCellValue(vm.ActivityOrder.EdsCode);
            sheet1.GetRow(8).GetCell(14).SetCellValue(vm.ActivityOrder.MinusProduceDate);
            sheet1.GetRow(9).GetCell(3).SetCellValue(Convert.ToString(vm.DoseMeter));
            sheet1.GetRow(9).GetCell(7).SetCellValue(Convert.ToString(vm.ActivityOrder.AddCalcuActivity));
            sheet1.GetRow(9).GetCell(14).SetCellValue(vm.ActivityOrder.ActivityEvalDate);
            sheet1.GetRow(10).GetCell(3).SetCellValue(vm.WastePackageBucketVM.NuclearWastePackage.Weight.ToString());
            sheet1.GetRow(10).GetCell(6).SetCellValue(vm.WastePackageBucketVM.NuclearWastePackage.Volumn.ToString());
            sheet1.GetRow(10).GetCell(14).SetCellValue(vm.ActivityOrder.MinusOriginalActivity);

          

            CommonHelper commonHelper = new CommonHelper();
            //获取数据
            List<DispiteEvalDetailVM> list = new List<DispiteEvalDetailVM>();
            if (activityOrder.DispiteEvalDetailVMList != null)
            {
                list = activityOrder.DispiteEvalDetailVMList;

                if (list.Count() <= 26 && list.Count()>0)
                {
                    for (int i = 0; i < list.Count(); i++)
                    {
                        sheet1.GetRow(14 + i).GetCell(1).SetCellValue(list[i].ElementName);
                        sheet1.GetRow(14 + i).GetCell(2).SetCellValue(list[i].ElementClass);
                        sheet1.GetRow(14 + i).GetCell(5).SetCellValue(list[i].HalfLife);
                        sheet1.GetRow(14 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(list[i].OriginalActivity == null ? "0" : list[i].OriginalActivity.ToString())));
                        sheet1.GetRow(14 + i).GetCell(13).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal((list[i].OriginalWasteActivity == null || list[i].OriginalWasteActivity == "采样分析") ? "0" : list[i].OriginalWasteActivity.ToString())));
                        sheet1.GetRow(14 + i).GetCell(15).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(list[i].CheckdateActivity)));
                    }
                   
                
                }
                if (list.Count() > 26)
                {
                    int addRow = list.Count()-26;
                    NPOIHelper.CopyRow(sheet1, 40, 39, addRow);

                    for (int i = 0; i < list.Count(); i++)
                    {
                        sheet1.GetRow(14 + i).GetCell(1).SetCellValue(list[i].ElementName);
                        sheet1.GetRow(14 + i).GetCell(2).SetCellValue(list[i].ElementClass);
                        sheet1.GetRow(14 + i).GetCell(5).SetCellValue(list[i].HalfLife);
                        sheet1.GetRow(14 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(list[i].OriginalActivity == null ? "0" : list[i].OriginalActivity.ToString())));
                        sheet1.GetRow(14 + i).GetCell(13).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal((list[i].OriginalWasteActivity == null || list[i].OriginalWasteActivity == "采样分析") ? "0" : list[i].OriginalWasteActivity.ToString())));
                        sheet1.GetRow(14 + i).GetCell(15).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(list[i].CheckdateActivity)));
                    }

                }
               
            }

            if (list.Count() <= 26)
            {
                sheet1.GetRow(42).GetCell(4).SetCellValue(vm.ActivityOrder.ActivityCompare);
                sheet1.GetRow(42).GetCell(13).SetCellValue(vm.ActivityOrder.KeyActivityUnitCompare);
                sheet1.GetRow(43).GetCell(4).SetCellValue(vm.ActivityOrder.TotalActivity);
                sheet1.GetRow(43).GetCell(13).SetCellValue(vm.ActivityOrder.DecayThreeHundred);
                sheet1.GetRow(44).GetCell(4).SetCellValue(vm.ActivityOrder.Classify + "   " + vm.ActivityOrder.ClassifyValue);
                sheet1.GetRow(44).GetCell(13).SetCellValue(vm.ActivityOrder.SurfaceClass);
                sheet1.GetRow(45).GetCell(4).SetCellValue(vm.ActivityOrder.DecayHeat);
                sheet1.GetRow(45).GetCell(13).SetCellValue(vm.ActivityOrder.CalcuThreeHundred);
            }
            else
            {
                int addRow = list.Count() - 26;
                sheet1.GetRow(42 + addRow).GetCell(4).SetCellValue(vm.ActivityOrder.ActivityCompare);
                sheet1.GetRow(42 + addRow).GetCell(13).SetCellValue(vm.ActivityOrder.KeyActivityUnitCompare);
                sheet1.GetRow(43 + addRow).GetCell(4).SetCellValue(vm.ActivityOrder.TotalActivity);
                sheet1.GetRow(43 + addRow).GetCell(13).SetCellValue(vm.ActivityOrder.DecayThreeHundred);
                sheet1.GetRow(44 + addRow).GetCell(4).SetCellValue(vm.ActivityOrder.Classify + "   " + vm.ActivityOrder.ClassifyValue);
                sheet1.GetRow(44 + addRow).GetCell(13).SetCellValue(vm.ActivityOrder.SurfaceClass);
                sheet1.GetRow(45 + addRow).GetCell(4).SetCellValue(vm.ActivityOrder.DecayHeat);
                sheet1.GetRow(45 + addRow).GetCell(13).SetCellValue(vm.ActivityOrder.CalcuThreeHundred);
            }
          




            //设置响应的类型为Excel
            Response.ContentType = "application/vnd.ms-excel";
            //设置下载的Excel文件名
            Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", "WastePackageCheck.xlsx"));
            //Clear方法删除所有缓存中的HTML输出。但此方法只删除Response显示输入信息，不删除Response头信息。以免影响导出数据的完整性。
            Response.Clear();

            using (MemoryStream ms = new MemoryStream())
            {
                //将工作簿的内容放到内存流中   
                xssfworkbook.Write(ms);
                //将内存流转换成字节数组发送到客户端
                Response.BinaryWrite(ms.GetBuffer());
                Response.End();
            }


        }

        #endregion

    }
}
