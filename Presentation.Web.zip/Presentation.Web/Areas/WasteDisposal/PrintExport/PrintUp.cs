﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NPOI.XSSF.UserModel;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels;
using RWIS.Domain.DomainObjects.View.NuclearRubFile;
using NET01.CoreFramework;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Domain.DomainObjects.View;
using MvcContrib.Sorting;
using RWIS.Domain.DomainObjects.View.DispiteConfirm;
using RWIS.Domain.DomainObjects.View.NuclearRubLocation;
using RWIS.Domain.DomainObjects.View.WastePackageCheck;
using RWIS.Domain.DomainObjects.View.EquipManage;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.WastePackageCheck.ViewModels;
using System.Web.Mvc;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.Controllers
{
    public class PrintUp
    {
        static ActivityOrder activityOrder = new ActivityOrder();
        INuclearRubFileRepository _NuclearRubFileRepository = ServiceLocator.Current.GetInstance<INuclearRubFileRepository>();
        INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
        INuclearMStockRepository _NuclearMStockRepository = ServiceLocator.Current.GetInstance<INuclearMStockRepository>();
        INuclearWastePackageRepository _NuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
        INuclearRubLocationRepository _NuclearRubLocationRepository = ServiceLocator.Current.GetInstance<INuclearRubLocationRepository>();
        IBasicObjectRepository _BasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
        IMaterialTypeRepository _MaterialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
        INuclearBucketCheckRepository _NuclearBucketCheckRepository = ServiceLocator.Current.GetInstance<INuclearBucketCheckRepository>();
        INuclearRubReceptionDRepository _NuclearRubReceptionDRepository = ServiceLocator.Current.GetInstance<INuclearRubReceptionDRepository>();
        INuclearRubReceptionRepository _NuclearRubReceptionRepository =ServiceLocator.Current.GetInstance<INuclearRubReceptionRepository>();
        INuclearElementRepository _NuclearElementRepository =ServiceLocator.Current.GetInstance<INuclearElementRepository>();
        ISupportEdsDetailRepository _SupportEdsDetailRepository =ServiceLocator.Current.GetInstance<ISupportEdsDetailRepository>();
        INuclearApplyDetailRepository _NuclearApplyDetailRepository = ServiceLocator.Current.GetInstance<INuclearApplyDetailRepository>();
        IDispsiteCheckDetailRepository _DispsiteCheckDetailRepository = ServiceLocator.Current.GetInstance<IDispsiteCheckDetailRepository>();
        IDispsiteEvalRepository _DispsiteEvalRepository = ServiceLocator.Current.GetInstance<IDispsiteEvalRepository>();
        IDispsiteEvalDetailRepository _DispsiteEvalDetailRepository = ServiceLocator.Current.GetInstance<IDispsiteEvalDetailRepository>();
        INuclearRubTransDetailRepository _NuclearRubTransDetailRepository = ServiceLocator.Current.GetInstance<INuclearRubTransDetailRepository>();
        INuclearRubTransRepository _NuclearRubTransRepository = ServiceLocator.Current.GetInstance<INuclearRubTransRepository>();
        IBasicWasteUnitRepository _BasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
        INuclearTsGoodsOutRepository _NuclearTsGoodsOutRepository = ServiceLocator.Current.GetInstance<INuclearTsGoodsOutRepository>();
        IDispiteConfirmRepository _DispiteConfirmRepository = ServiceLocator.Current.GetInstance<IDispiteConfirmRepository>();
        IDispiteConfirmDetailRepository _DispiteConfirmDetailRepository = ServiceLocator.Current.GetInstance<IDispiteConfirmDetailRepository>();
        IActivityBucketRepository _ActivityBucketRepository = ServiceLocator.Current.GetInstance<IActivityBucketRepository>();
        ISupportEdsRepository _SupportEdsRepository = ServiceLocator.Current.GetInstance<ISupportEdsRepository>();
        INuclearCoverMixRepository _NuclearCoverMixRepository= ServiceLocator.Current.GetInstance<INuclearCoverMixRepository>();
        IDispsiteApproveRepository _DispsiteApproveRepository = ServiceLocator.Current.GetInstance<IDispsiteApproveRepository>();
        IMaterialTypeRepository materialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
        //IDispiteEvalDetailRepository _DispiteEvalDetailRepository = ServiceLocator.Current.GetInstance<IDispiteEvalDetailRepository>();
        //IDispsiteEvalRepository _DispsiteEvalRepository = ServiceLocator.Current.GetInstance<IDispsiteEvalRepository>();
        /// <summary>
        /// <summary>
        /// 封面页
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="xssfworkbook"></param>
        /// <param name="packageCode"></param>
        /// <param name="wastePackage"></param>
        /// <returns></returns>
        public void CoverOfPrint(string fileId, XSSFWorkbook xssfworkbook, string packageCode, NuclearWastePackage wastePackage, string bucketId)
        {
            //建立一个名为Sheet1的工作表
            XSSFSheet sheet1 = (XSSFSheet)xssfworkbook.GetSheet("CNPEP");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;

            //求封面页数据
            NuclearRubFile nuclearRubFile = this._NuclearRubFileRepository.Get(fileId);
            NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(wastePackage.BucketId);
            string bucketCode = string.Empty;
            if (nuclearBucket != null)
            {
                bucketCode = nuclearBucket.BucketCode;
            }

            if (nuclearRubFile != null)
            {
                //if (nuclearRubFile.SecrecyLevel == "Secrecy")
                //{
                //    nuclearRubFile.SecrecyLevel = "机密";
                //}
                //if (nuclearRubFile.SecrecyLevel == "Restriction")
                //{
                //    nuclearRubFile.SecrecyLevel = "限制使用";
                //}
                //sheet1.GetRow(9).GetCell(5).SetCellValue(nuclearRubFile.SecrecyLevel);
                sheet1.GetRow(9).GetCell(17).SetCellValue(nuclearRubFile.CommitDate.HasValue ? nuclearRubFile.CommitDate.Value.ToString("yyyy-MM-dd"):"");
                //sheet1.GetRow(11).GetCell(7).SetCellValue(nuclearRubFile.RecordDate.HasValue ? nuclearRubFile.RecordDate.Value.ToString("yyyy-MM-dd") : "");
                sheet1.GetRow(13).GetCell(6).SetCellValue(nuclearRubFile.RecordFile);
                sheet1.GetRow(13).GetCell(17).SetCellValue(nuclearRubFile.FilePage);
                sheet1.GetRow(26).GetCell(12).SetCellValue(nuclearRubFile.PackageSource);
            }

            sheet1.GetRow(22).GetCell(12).SetCellValue(packageCode);
            sheet1.GetRow(24).GetCell(12).SetCellValue(bucketCode);
            sheet1.GetRow(28).GetCell(12).SetCellValue(wastePackage.ConfirmDate.HasValue?wastePackage.ConfirmDate.Value.ToString("yyyy"):"");
            
            NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == bucketId).FirstOrDefault();
            if (nuclearApplyDetail != null)
            {
                DispsiteCheckDetail dispsiteCheckDetail = _DispsiteCheckDetailRepository.GetAll().Where(d => d.ApplyDetailId == nuclearApplyDetail.ApplyDetailId).FirstOrDefault();
                if (dispsiteCheckDetail != null)
                {
                    DispsiteEval dispsiteEval = _DispsiteEvalRepository.GetAll().Where(d => d.CheckDetailId == dispsiteCheckDetail.DetailId).FirstOrDefault();

                    if (dispsiteEval != null)
                    {
                        
                        sheet1.GetRow(30).GetCell(12).SetCellValue(dispsiteEval.SurfaceClass);

                    }
                }
            }
        
        }
        /// <summary>
        /// 废物包质量检查页
        /// </summary>
        /// <param name="fileId"></param>
        /// <param name="xssfworkbook"></param>
        public void QualityControl(string fileId, XSSFWorkbook xssfworkbook, string bucketId)
        {
            XSSFSheet sheet2 = (XSSFSheet)xssfworkbook.GetSheet("关键信息汇总");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
            //设置数据
            NuclearRubFileVM vm = new NuclearRubFileVM();
            NuclearRubFile nuclearRubFile = this._NuclearRubFileRepository.Get(fileId);
            if (nuclearRubFile != null)
            {
                vm.PackageSource = nuclearRubFile.PackageSource;
            }

            NuclearRubFileCondition condition = new NuclearRubFileCondition();
            List<DispiteEvalDetail> dispiteEvalDetailList = null;
            if (nuclearRubFile != null)
            {
                NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(nuclearRubFile.PackageId);

                if (nuclearWastePackage != null)
                {
                    vm.PackageCode = nuclearWastePackage.PackageCode;
                    vm.Weight = nuclearWastePackage.Weight.ToString();
                    vm.Volumn = nuclearWastePackage.Volumn;
                    List<NuclearRubLocation> nuclearRubLocationList = _NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == nuclearWastePackage.PackageId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                    if (nuclearRubLocationList.Count() > 0)
                    {
                        BasicObject basicObjectUnitCode = _BasicObjectRepository.Get(nuclearRubLocationList[0].UnitCode);
                        if (basicObjectUnitCode != null)
                        {
                            vm.UnitCode = basicObjectUnitCode.Name;
                        }
                        vm.LocationX = nuclearRubLocationList[0].LocationX;
                        vm.LocationY = nuclearRubLocationList[0].LocationY;
                        vm.LocationZ = nuclearRubLocationList[0].LocationZ;

                    }
                    NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(nuclearWastePackage.BucketId);
                    if (nuclearBucket != null)
                    {
                        vm.WasteType = nuclearBucket.WasteType;
                        vm.BucketCode = nuclearBucket.BucketCode;
                        //BasicObject basicObjectBucketType = _BasicObjectRepository.Get(nuclearBucket.BucketTypeId);
                        //if (basicObjectBucketType != null)
                        //{
                        //    vm.BucketType = basicObjectBucketType.Name;
                        //}
                        MaterialType materialType = _MaterialTypeRepository.Get(nuclearBucket.MaterialId);
                        if (materialType != null)
                        {
                            BasicObject basicObjectSpec = _BasicObjectRepository.Get(materialType.SpecId);
                            vm.Spec = basicObjectSpec.Name;
                        }
                        List<NuclearBucketCheck> nuclearBucketCheck = _NuclearBucketCheckRepository.GetAll().Where(d => d.BucketId == nuclearBucket.BucketId).ToList();
                        if (nuclearBucketCheck.Count() > 0)
                        {
                            vm.ShieldMaterail = nuclearBucketCheck[0].ShieldMaterail;
                          //  vm.ShieldWeight = nuclearBucketCheck[0].Weight;
                        }
                    }
                    List<NuclearRubReceptionD> dataD = _NuclearRubReceptionDRepository.GetAll().Where(d => d.PackageId == nuclearWastePackage.PackageId).ToList();
                    if (dataD.Count() > 0)
                    {
                        vm.DoseSurface = dataD[0].DoseSurface;
                        vm.DoseMeter = dataD[0].DoseMeter;
                        vm.PackagePolluteB = dataD[0].PackagePolluteB;
                        vm.PackagePolluteA = dataD[0].PackagePolluteA;

                        MaterialType materialType = _MaterialTypeRepository.Get(dataD[0].BucketType);
                        if (materialType != null)
                        {
                            vm.BucketType = materialType.MaterialName;
                        }
                        List<NuclearRubReception> data = _NuclearRubReceptionRepository.GetAll().Where(d => d.ReceptId == dataD[0].ReceptId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                        if (data.Count() > 0)
                        {
                            vm.ReceptionDate = data[0].ReceptionDate.Value.ToString("yyyy-MM-dd");
                        }
                    }


                    //废物产生时间
                    sheet2.GetRow(20).GetCell(5).SetCellValue(nuclearWastePackage.ConfirmDate.Value.ToString("yyyy-MM-dd"));
                    NuclearRubLocationCondition conditionRub = new NuclearRubLocationCondition();
                    conditionRub.PackageCode = nuclearWastePackage.PackageCode;
                    IQueryable<NuclearRubLocationView> dataView = _NuclearRubLocationRepository.QueryList(conditionRub).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                    if (dataView.Count() > 0)
                    {
                        DispsiteCheckCondition dispsiteCheckCondition = new DispsiteCheckCondition();
                        dispsiteCheckCondition.IdentityCode = dataView.ToList()[0].IdentityCode;
                        IQueryable<DispsiteApproveView> data = this._DispsiteApproveRepository.QueryList(dispsiteCheckCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode );
                        if (data.Count() > 0)
                        {
                            if (data.ToList()[0].TransFlag == "Self")
                            {
                                vm.TransFlag = "自行";
                            }
                            if (data.ToList()[0].TransFlag == "Delegate")
                            {
                                vm.TransFlag = "委托";
                            }

                        }

                    }

                    //废物包活度计算信息
                    ActivityOrder activityOrder = new ActivityOrder();
                    ActivityCountCondition activityCountCondition = new ActivityCountCondition();
                    activityCountCondition.BucketId = bucketId;
                    IQueryable<ActivityCount> iqueryActivityCount = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition);
                    ActivityCount activityCount = new ActivityCount();
                    if (iqueryActivityCount.Count() > 0)
                    {
                        activityCount = iqueryActivityCount.ToList()[0];
                        activityOrder = ActivityBuilder.GetActivityOrder(activityCount, nuclearBucket, nuclearWastePackage.PackageCode);

                        vm.GiftWeight = activityOrder.GiftWeight;


                        //废物体积
                        MaterialType material = materialTypeRepository.GetMaterialModel(nuclearBucket.MaterialId);
                        if (material != null)
                        {
                            activityOrder.WasteVolumn = decimal.Parse((3.14 * material.Diamerter / 200 * material.Diamerter / 200 * (material.Height / 100 - double.Parse(activityOrder.OverSpace) / 100)).ToString());
                        }
                        else {

                            activityOrder.WasteVolumn = decimal.Parse((3.14 * material.Diamerter / 200 * material.Diamerter / 200 * (material.Height / 100 )).ToString());
                        }


                        vm.GiftWeight = activityOrder.GiftWeight;
                        vm.WasteVolumn = activityOrder.WasteVolumn;
                       
                    }

                }
             //总活度
                NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == bucketId).FirstOrDefault();
                if (nuclearApplyDetail != null)
                {
                    DispsiteCheckDetail dispsiteCheckDetail = _DispsiteCheckDetailRepository.GetAll().Where(d => d.ApplyDetailId == nuclearApplyDetail.ApplyDetailId).FirstOrDefault();
                    if (dispsiteCheckDetail != null)
                    {
                        DispsiteEval dispsiteEval = _DispsiteEvalRepository.GetAll().Where(d => d.CheckDetailId == dispsiteCheckDetail.DetailId).FirstOrDefault();
                       
                        if (dispsiteEval != null)
                        {
                            vm.TotalActivity = Convert.ToDecimal(dispsiteEval.TotalActivity);
                            vm.SurfaceClass = dispsiteEval.SurfaceClass;
                            IQueryable<DispiteEvalDetail> dispiteEvalDetail = _DispsiteEvalDetailRepository.GetAll().Where(d => d.EvalId == dispsiteEval.EvalId).AsQueryable();
                            if (dispiteEvalDetail.Count() > 0)
                            {
                                dispiteEvalDetailList = dispiteEvalDetail.ToList();

                            }
                            
                        }
                    }
                }
              
            }
            
            //IQueryable<NuclearElement> nuclearElement = _NuclearElementRepository.GetAll().AsQueryable();
            //IQueryable<SupportEdsDetail> supportEdsDetail = _SupportEdsDetailRepository.GetAll().AsQueryable();
            //var query = from n in nuclearElement
            //            join s in supportEdsDetail on n.ElementId equals s.ElementId into nEmpt
            //            from s in nEmpt.DefaultIfEmpty()
            //            select new NuclearRubFileVM
            //            {
            //                ElementName = n.ElementName,
            //                PercentValue = s.PercentValue,
            //            };

            //List<NuclearRubFileVM> nuclearRubFileVM = query.ToList();

            sheet2.GetRow(17).GetCell(6).SetCellValue(vm.PackageSource);
            sheet2.GetRow(18).GetCell(5).SetCellValue(vm.PackageCode);

            sheet2.GetRow(18).GetCell(10).SetCellValue(vm.BucketCode);
            sheet2.GetRow(18).GetCell(16).SetCellValue(vm.ReceptionDate);
            sheet2.GetRow(19).GetCell(5).SetCellValue(vm.Weight);
            sheet2.GetRow(19).GetCell(14).SetCellValue(Convert.ToString(vm.Volumn));
           

            sheet2.GetRow(21).GetCell(5).SetCellValue(vm.BucketType);
            sheet2.GetRow(21).GetCell(14).SetCellValue(vm.Spec);
            sheet2.GetRow(22).GetCell(5).SetCellValue(vm.SurfaceClass);
            sheet2.GetRow(22).GetCell(15).SetCellValue(vm.TransFlag);
            sheet2.GetRow(23).GetCell(6).SetCellValue(vm.WasteType);
            sheet2.GetRow(23).GetCell(14).SetCellValue(vm.WasteVolumn.ToString());
            sheet2.GetRow(24).GetCell(5).SetCellValue("水泥");
            sheet2.GetRow(24).GetCell(14).SetCellValue(vm.GiftWeight);
            sheet2.GetRow(25).GetCell(5).SetCellValue(vm.ShieldMaterail);
            sheet2.GetRow(25).GetCell(14).SetCellValue(Convert.ToString(vm.ShieldWeight));
            sheet2.GetRow(26).GetCell(5).SetCellValue(vm.TotalActivity.ToString());
            sheet2.GetRow(27).GetCell(5).SetCellValue(Convert.ToString(vm.DoseSurface));
            sheet2.GetRow(27).GetCell(15).SetCellValue(Convert.ToString(vm.DoseMeter));
            sheet2.GetRow(28).GetCell(5).SetCellValue(Convert.ToString(vm.PackagePolluteB));
            sheet2.GetRow(28).GetCell(15).SetCellValue(Convert.ToString(vm.PackagePolluteA));
            sheet2.GetRow(30).GetCell(5).SetCellValue(vm.UnitCode);
            
            sheet2.GetRow(30).GetCell(14).SetCellValue(vm.LocationX);
            sheet2.GetRow(30).GetCell(16).SetCellValue(vm.LocationY);
            sheet2.GetRow(30).GetCell(19).SetCellValue(vm.LocationZ);
           
            if (dispiteEvalDetailList != null)
            {
                if (dispiteEvalDetailList.Count() < 7)
                {
                    for (int i = 0; i < dispiteEvalDetailList.Count(); i++)
                    {

                        sheet2.GetRow(37 + i).GetCell(2).SetCellValue(i + 1);
                        BasicObject basicObject = _BasicObjectRepository.GetAll().Where(d => d.Uuid == dispiteEvalDetailList[i].ElementId).FirstOrDefault();
                        if (basicObject != null)
                        {
                            sheet2.GetRow(37 + i).GetCell(3).SetCellValue(basicObject.Name);
                        }
                        sheet2.GetRow(37 + i).GetCell(5).SetCellValue(dispiteEvalDetailList[i].CheckdateActivityPercent.ToString());
                        sheet2.GetRow(37 + i).GetCell(8).SetCellValue(dispiteEvalDetailList[i].CheckdateActivity.ToString());

                    }
                }
                if (6 < dispiteEvalDetailList.Count() && dispiteEvalDetailList.Count() <= 12)
                {
                    for (int i = 0; i < 6; i++)
                    {

                        sheet2.GetRow(37 + i).GetCell(2).SetCellValue(i + 1);
                        BasicObject basicObject = _BasicObjectRepository.GetAll().Where(d => d.Uuid == dispiteEvalDetailList[i].ElementId).FirstOrDefault();
                        if (basicObject != null)
                        {
                            sheet2.GetRow(37 + i).GetCell(3).SetCellValue(basicObject.Name);
                        }
                        sheet2.GetRow(37 + i).GetCell(5).SetCellValue(dispiteEvalDetailList[i].CheckdateActivityPercent.ToString());
                        sheet2.GetRow(37 + i).GetCell(8).SetCellValue(dispiteEvalDetailList[i].CheckdateActivity.ToString());

                    }


                    for (int i = 6; i < dispiteEvalDetailList.Count(); i++)
                    {
                        sheet2.GetRow(37 + i-6).GetCell(11).SetCellValue(i + 1);
                        BasicObject basicObject = _BasicObjectRepository.GetAll().Where(d => d.Uuid == dispiteEvalDetailList[i].ElementId).FirstOrDefault();
                        if (basicObject != null)
                        {
                            sheet2.GetRow(37 + i-6).GetCell(12).SetCellValue(basicObject.Name);
                        }
                        sheet2.GetRow(37 + i-6).GetCell(14).SetCellValue(dispiteEvalDetailList[i].CheckdateActivityPercent.ToString());
                        sheet2.GetRow(37 + i-6).GetCell(17).SetCellValue(dispiteEvalDetailList[i].CheckdateActivity.ToString());
                    }
                }

                if (dispiteEvalDetailList.Count() > 12)
                {
                    int addRow = Convert.ToInt32(Math.Ceiling(Convert.ToDouble((dispiteEvalDetailList.Count() - 12) / 2)));
                    NPOIHelper.CopyRow(sheet2, 42, 41, addRow);
                    //左边写入数据
                    int sum = Convert.ToInt32(Math.Ceiling(Convert.ToDouble(dispiteEvalDetailList.Count() / 2)));
                    for (int i = 0; i < sum; i++)
                    {
                        sheet2.GetRow(37 + i).GetCell(11).SetCellValue(i + 1);
                        BasicObject basicObject = _BasicObjectRepository.GetAll().Where(d => d.Uuid == dispiteEvalDetailList[i].ElementId).FirstOrDefault();
                        if (basicObject != null)
                        {
                            sheet2.GetRow(37 + i).GetCell(12).SetCellValue(basicObject.Name);
                        }
                        sheet2.GetRow(37 + i).GetCell(14).SetCellValue(dispiteEvalDetailList[i].CheckdateActivityPercent.ToString());
                        sheet2.GetRow(37 + i).GetCell(17).SetCellValue(dispiteEvalDetailList[i].CheckdateActivity.ToString());
                    }
                    //右边写入数据
                    for (int i = sum; i < dispiteEvalDetailList.Count(); i++)
                    {
                        sheet2.GetRow(37 + i - sum).GetCell(11).SetCellValue(i + 1);
                        BasicObject basicObject = _BasicObjectRepository.GetAll().Where(d => d.Uuid == dispiteEvalDetailList[i].ElementId).FirstOrDefault();
                        if (basicObject != null)
                        {
                            sheet2.GetRow(37 + i - sum).GetCell(12).SetCellValue(basicObject.Name);
                        }
                        sheet2.GetRow(37 + i - sum).GetCell(14).SetCellValue(dispiteEvalDetailList[i].CheckdateActivityPercent.ToString());
                        sheet2.GetRow(37 + i - sum).GetCell(17).SetCellValue(dispiteEvalDetailList[i].CheckdateActivity.ToString());
                    }
                }
            
            }
            

        }
        /// <summary>
        /// 废物接收
        /// </summary>
        /// <param name="xssfworkbook"></param>
        /// <param name="packageCode"></param>
        public void RubReceptionMethod(XSSFWorkbook xssfworkbook, string packageCode)
        {
            XSSFSheet sheet = (XSSFSheet)xssfworkbook.GetSheet("废物接收");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
            //NuclearRubReceptionDView nuclearRubReceptionDView = new NuclearRubReceptionDView();
            List<NuclearRubReceptionDView> dataList = null;
            NuclearRubReception nuclearRubReception = null;
            NuclearRubReceptionDView nuclearView = this._NuclearRubReceptionDRepository.QueryListByReceptId("").Where(d => d.PackageCode == packageCode).FirstOrDefault();
            if (nuclearView != null)
            {
                IQueryable<NuclearRubReceptionDView> data = this._NuclearRubReceptionDRepository.QueryListByReceptId("").Where(d => d.ReceptId == nuclearView.ReceptId);
                if (data.Count() > 0)
                {
                    dataList = data.ToList();
                }
                nuclearRubReception = this._NuclearRubReceptionRepository.Get(nuclearView.ReceptId);
            }
            if (dataList != null && dataList.Count() < 9)
            {
                for (int i = 0; i < dataList.Count(); i++)
                {
                    sheet.GetRow(6 + i).GetCell(1).SetCellValue(i + 1);
                    sheet.GetRow(6 + i).GetCell(2).SetCellValue(dataList[i].PackageCode);
                    sheet.GetRow(6 + i).GetCell(3).SetCellValue(dataList[i].BucketType);
                    if (dataList[i].IsMetelquelified == null||dataList[i].IsMetelquelified =="")
                    {
                        if (dataList[i].IsCementquelified == "1")
                        {
                            sheet.GetRow(6 + i).GetCell(4).SetCellValue("是");
                        }
                        else {
                            sheet.GetRow(6 + i).GetCell(4).SetCellValue("否");
                        }
                        
                    }
                    else
                    {
                        if (dataList[i].IsMetelquelified == "1")
                        {
                            sheet.GetRow(6 + i).GetCell(4).SetCellValue("是");
                        }
                        else
                        {
                            sheet.GetRow(6 + i).GetCell(4).SetCellValue("否");
                        }
                        
                    }
                   
                    sheet.GetRow(6 + i).GetCell(5).SetCellValue(dataList[i].SandySurface);
                    sheet.GetRow(6 + i).GetCell(6).SetCellValue(dataList[i].Crack);
                    sheet.GetRow(6 + i).GetCell(7).SetCellValue(dataList[i].Breach);
                    sheet.GetRow(6 + i).GetCell(8).SetCellValue(dataList[i].Cavatity);

                    sheet.GetRow(6 + i).GetCell(9).SetCellValue(dataList[i].Concavity);
                    sheet.GetRow(6 + i).GetCell(10).SetCellValue(dataList[i].GirthWelding);
                    sheet.GetRow(6 + i).GetCell(11).SetCellValue(dataList[i].WeldingWidth);
                    sheet.GetRow(6 + i).GetCell(12).SetCellValue(dataList[i].RingWelding);


                    sheet.GetRow(6 + i).GetCell(13).SetCellValue(dataList[i].DoseSurface.ToString());
                    sheet.GetRow(6 + i).GetCell(14).SetCellValue(dataList[i].DoseMeter.ToString());
                    sheet.GetRow(6 + i).GetCell(15).SetCellValue(dataList[i].PackagePolluteA.ToString());
                    sheet.GetRow(6 + i).GetCell(16).SetCellValue(dataList[i].PackagePolluteB.ToString());
                    if (dataList[i].CheckResult == "1")
                    {
                        sheet.GetRow(6 + i).GetCell(17).SetCellValue("接收");
                    }
                    else
                    {
                        sheet.GetRow(6 + i).GetCell(17).SetCellValue("退回");
                    }
                    
                    sheet.GetRow(6 + i).GetCell(18).SetCellValue(dataList[i].Remark);


                }
                sheet.GetRow(14).GetCell(3).SetCellValue(nuclearRubReception.TransPlate);

            }
            if (dataList != null && dataList.Count() > 8)
            {
                int addRow = dataList.Count() - 8;
                NPOIHelper.CopyRow(sheet, 13, 12, addRow);
                for (int i = 0; i < dataList.Count(); i++)
                {
                    sheet.GetRow(6 + i).GetCell(1).SetCellValue(i + 1);
                    sheet.GetRow(6 + i).GetCell(2).SetCellValue(dataList[i].PackageCode);
                    sheet.GetRow(6 + i).GetCell(3).SetCellValue(dataList[i].BucketType);
                    if (dataList[i].Isquelified == "1")
                    {
                        sheet.GetRow(6 + i).GetCell(4).SetCellValue("是");
                    }
                    else
                    {
                        sheet.GetRow(6 + i).GetCell(4).SetCellValue("否");
                    }

                    sheet.GetRow(6 + i).GetCell(5).SetCellValue(dataList[i].SandySurface);
                    sheet.GetRow(6 + i).GetCell(6).SetCellValue(dataList[i].Crack);
                    sheet.GetRow(6 + i).GetCell(7).SetCellValue(dataList[i].Breach);
                    sheet.GetRow(6 + i).GetCell(8).SetCellValue(dataList[i].Cavatity);

                    sheet.GetRow(6 + i).GetCell(9).SetCellValue(dataList[i].Concavity);
                    sheet.GetRow(6 + i).GetCell(10).SetCellValue(dataList[i].GirthWelding);
                    sheet.GetRow(6 + i).GetCell(11).SetCellValue(dataList[i].WeldingWidth);
                    sheet.GetRow(6 + i).GetCell(12).SetCellValue(dataList[i].RingWelding);


                    sheet.GetRow(6 + i).GetCell(13).SetCellValue(dataList[i].DoseSurface.ToString());
                    sheet.GetRow(6 + i).GetCell(14).SetCellValue(dataList[i].DoseMeter.ToString());
                    sheet.GetRow(6 + i).GetCell(15).SetCellValue(dataList[i].PackagePolluteA.ToString());
                    sheet.GetRow(6 + i).GetCell(16).SetCellValue(dataList[i].PackagePolluteB.ToString());
                    if (dataList[i].CheckResult == "1")
                    {
                        sheet.GetRow(6 + i).GetCell(17).SetCellValue("接收");
                    }
                    else
                    {
                        sheet.GetRow(6 + i).GetCell(17).SetCellValue("退回");
                    }

                    sheet.GetRow(6 + i).GetCell(18).SetCellValue(dataList[i].Remark);

                }
                sheet.GetRow(14 + addRow).GetCell(3).SetCellValue(nuclearRubReception.TransPlate);

            }

        }
        /// <summary>
        /// 北龙处置场废物包吊装定位单
        /// </summary>
        /// <param name="xssfworkbook"></param>
        /// <param name="packageCode"></param>
        /// <param name="bucketCode"></param>
        /// <param name="packageId"></param>
        public void RubConsMethod(XSSFWorkbook xssfworkbook, string packageCode, string bucketCode, string packageId)
        {
            XSSFSheet sheet = (XSSFSheet)xssfworkbook.GetSheet("吊装定位单");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
            NuclearRubFileVM vm = new NuclearRubFileVM();
            List<NuclearRubLocation> nuclearRubLocationList = _NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == packageId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (nuclearRubLocationList.Count() > 0)
            {
                BasicObject basicObjectUnitCode = _BasicObjectRepository.Get(nuclearRubLocationList[0].UnitCode);
                if (basicObjectUnitCode != null)
                {
                    vm.UnitCode = basicObjectUnitCode.Name;
                }
                vm.LocationX = nuclearRubLocationList[0].LocationX;
                vm.LocationY = nuclearRubLocationList[0].LocationY;
                vm.LocationZ = nuclearRubLocationList[0].LocationZ;
                vm.SlingLocation = nuclearRubLocationList[0].SlingLocation;
            }

            sheet.GetRow(5).GetCell(4).SetCellValue(bucketCode);
            sheet.GetRow(6).GetCell(4).SetCellValue(packageCode);
            sheet.GetRow(8).GetCell(2).SetCellValue(vm.SlingLocation);
            sheet.GetRow(9).GetCell(3).SetCellValue(vm.UnitCode);

            sheet.GetRow(11).GetCell(3).SetCellValue(vm.LocationX);
            sheet.GetRow(12).GetCell(3).SetCellValue(vm.LocationY);
            sheet.GetRow(13).GetCell(3).SetCellValue(vm.LocationZ);

        }

        /// <summary>
        /// 放射性物质场内运输登记表
        /// </summary>
        /// <param name="xssfworkbook"></param>
        /// <param name="packageCode"></param>
        /// <param name="bucketCode"></param>
        /// <param name="packageId"></param>
        public void TransportMethod(XSSFWorkbook xssfworkbook, string packageCode, string bucketCode, string packageId)
        {
            XSSFSheet sheet = (XSSFSheet)xssfworkbook.GetSheet("场内运输登记表");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
            NuclearRubTransDetail nuclearByPackageId = _NuclearRubTransDetailRepository.GetAll().Where(d => d.PackageId == packageId && d.Stationcode == AppContext.CurrentUser.ProjectCode).FirstOrDefault();
            if (nuclearByPackageId != null)
            {
                BasicWasteUnit basicWasteUnit = _BasicWasteUnitRepository.GetAll().Where(d => d.SimpleCode == AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                IQueryable<NuclearRubTransDetail> nuclearRubTransDetail = _NuclearRubTransDetailRepository.GetAll().Where(d => d.TransId == nuclearByPackageId.TransId && d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
              
                BasicObject BasicObject = new BasicObject();
                NuclearRubTrans nuclearRubTrans = _NuclearRubTransRepository.Get(nuclearByPackageId.TransId);
                if (nuclearRubTrans == null)
                {
                    nuclearRubTrans = new NuclearRubTrans();
                }
                BasicObject basicObjectMatterTo = _BasicObjectRepository.Get(nuclearRubTrans.MatterTo);
                sheet.GetRow(1).GetCell(1).SetCellValue(basicWasteUnit.UnitName);

              
                BasicObject basicObjectMatterFrom = _BasicObjectRepository.Get(nuclearRubTrans.MatterFrom);
                if (basicObjectMatterFrom != null)
                {
                    sheet.GetRow(3).GetCell(8).SetCellValue(basicObjectMatterFrom.Name);
                }
                sheet.GetRow(4).GetCell(4).SetCellValue(nuclearRubTrans.MatterCompany);
                sheet.GetRow(4).GetCell(8).SetCellValue(basicObjectMatterTo.Name);
                if (nuclearRubTrans.Meter == "1")
                {
                    sheet.GetRow(5).GetCell(6).SetCellValue("√");
                }
                else 
                {
                    sheet.GetRow(5).GetCell(6).SetCellValue("□");
                }
                sheet.GetRow(5).GetCell(9).SetCellValue(nuclearRubTrans.OtherDoserate);
                if (nuclearRubTrans.SurfacePollution == "1")
                {
                    sheet.GetRow(6).GetCell(6).SetCellValue("√");
                }
                else
                {
                    sheet.GetRow(6).GetCell(6).SetCellValue("□");
                }
                sheet.GetRow(6).GetCell(9).SetCellValue(nuclearRubTrans.OtherSurfacePollution);
                if (nuclearRubTransDetail.Count() > 0)
                {
                    List<NuclearRubTransDetail> nuclearRubTransDetailList = nuclearRubTransDetail.ToList();
                    if (nuclearRubTransDetailList.Count() < 6)
                    {
                        for (int i = 0; i < nuclearRubTransDetailList.Count(); i++)
                        {
                            sheet.GetRow(10 + i).GetCell(1).SetCellValue(i + 1);
                            sheet.GetRow(10 + i).GetCell(2).SetCellValue(nuclearRubTransDetailList[i].PackageCondition);
                            sheet.GetRow(10 + i).GetCell(3).SetCellValue(nuclearRubTransDetailList[i].MatterSource);
                            sheet.GetRow(10 + i).GetCell(5).SetCellValue(nuclearRubTransDetailList[i].SullySurfaceA.ToString());
                            sheet.GetRow(10 + i).GetCell(6).SetCellValue(nuclearRubTransDetailList[i].DoseSurfaceA.ToString());
                            sheet.GetRow(10 + i).GetCell(8).SetCellValue(nuclearRubTransDetailList[i].SullySurfaceB.ToString());
                            sheet.GetRow(10 + i).GetCell(9).SetCellValue(nuclearRubTransDetailList[i].DoseSurfaceB.ToString());
                            sheet.GetRow(10 + i).GetCell(10).SetCellValue(nuclearRubTransDetailList[i].Remark);
                        }

                        if (nuclearRubTrans.RadioactionLabel == "1")
                        {
                            sheet.GetRow(16).GetCell(7).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(16).GetCell(7).SetCellValue("□");
                        }
                        if (nuclearRubTrans.RadiationFlag == "1")
                        {
                            sheet.GetRow(16).GetCell(11).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(16).GetCell(11).SetCellValue("□");
                        }


                        if (nuclearRubTrans.TransRight == "1")
                        {
                            sheet.GetRow(17).GetCell(7).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(17).GetCell(7).SetCellValue("□");
                        }
                        if (nuclearRubTrans.TransTld == "1")
                        {
                            sheet.GetRow(17).GetCell(11).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(17).GetCell(11).SetCellValue("□");
                        }

                        if (nuclearRubTrans.TakePlace == "1")
                        {
                            sheet.GetRow(18).GetCell(7).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(18).GetCell(7).SetCellValue("□");
                        }
                        if (nuclearRubTrans.PoppulateLevel == "1")
                        {
                            sheet.GetRow(18).GetCell(11).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(18).GetCell(11).SetCellValue("□");
                        }
                        sheet.GetRow(27).GetCell(1).SetCellValue(nuclearRubTrans.TransPlace);

                    }
                    else
                    {
                        int addRow = nuclearRubTransDetailList.Count() - 5;
                        NPOIHelper.CopyRow(sheet, 14, 13, addRow);

                        for (int i = 0; i < nuclearRubTransDetailList.Count(); i++)
                        {
                            sheet.GetRow(10 + i).GetCell(1).SetCellValue(i + 1);
                            sheet.GetRow(10 + i).GetCell(2).SetCellValue(nuclearRubTransDetailList[i].PackageCondition);
                            sheet.GetRow(10 + i).GetCell(3).SetCellValue(nuclearRubTransDetailList[i].MatterSource);
                            sheet.GetRow(10 + i).GetCell(5).SetCellValue(nuclearRubTransDetailList[i].SullySurfaceA.ToString());
                            sheet.GetRow(10 + i).GetCell(6).SetCellValue(nuclearRubTransDetailList[i].DoseSurfaceA.ToString());
                            sheet.GetRow(10 + i).GetCell(8).SetCellValue(nuclearRubTransDetailList[i].SullySurfaceB.ToString());
                            sheet.GetRow(10 + i).GetCell(9).SetCellValue(nuclearRubTransDetailList[i].DoseSurfaceB.ToString());
                            sheet.GetRow(10 + i).GetCell(10).SetCellValue(nuclearRubTransDetailList[i].Remark);
                        }

                        if (nuclearRubTrans.RadioactionLabel == "1")
                        {
                            sheet.GetRow(16 + addRow).GetCell(7).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(16 + addRow).GetCell(7).SetCellValue("□");
                        }
                        if (nuclearRubTrans.RadiationFlag == "1")
                        {
                            sheet.GetRow(16 + addRow).GetCell(11).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(16 + addRow).GetCell(11).SetCellValue("□");
                        }


                        if (nuclearRubTrans.TransRight == "1")
                        {
                            sheet.GetRow(17 + addRow).GetCell(7).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(17 + addRow).GetCell(7).SetCellValue("□");
                        }
                        if (nuclearRubTrans.TransTld == "1")
                        {
                            sheet.GetRow(17 + addRow).GetCell(11).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(17 + addRow).GetCell(11).SetCellValue("□");
                        }

                        if (nuclearRubTrans.TakePlace == "1")
                        {
                            sheet.GetRow(18 + addRow).GetCell(7).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(18 + addRow).GetCell(7).SetCellValue("□");
                        }
                        if (nuclearRubTrans.PoppulateLevel == "1")
                        {
                            sheet.GetRow(18 + addRow).GetCell(11).SetCellValue("√");
                        }
                        else
                        {
                            sheet.GetRow(18 + addRow).GetCell(11).SetCellValue("□");
                        }
                        sheet.GetRow(27 + addRow).GetCell(1).SetCellValue(nuclearRubTrans.TransPlace);
                    
                    }
                }

            }

            //NuclearRubFileVM vm = new NuclearRubFileVM();
            //List<NuclearRubLocation> nuclearRubLocationList = _NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == packageId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            //if (nuclearRubLocationList.Count() > 0)
            //{
            //    BasicObject basicObjectUnitCode = _BasicObjectRepository.Get(nuclearRubLocationList[0].UnitCode);
            //    vm.UnitCode = basicObjectUnitCode.Name;
            //    vm.LocationX = nuclearRubLocationList[0].LocationX;
            //    vm.LocationY = nuclearRubLocationList[0].LocationY;
            //    vm.LocationZ = nuclearRubLocationList[0].LocationZ;
            //}

            //sheet.GetRow(5).GetCell(4).SetCellValue(bucketCode);
            //sheet.GetRow(6).GetCell(4).SetCellValue(packageCode);
            //sheet.GetRow(9).GetCell(3).SetCellValue(vm.UnitCode);

            //sheet.GetRow(11).GetCell(3).SetCellValue(vm.LocationX);
            //sheet.GetRow(12).GetCell(3).SetCellValue(vm.LocationY);
            //sheet.GetRow(13).GetCell(3).SetCellValue(vm.LocationZ);

        }
        /// <summary>
        /// QT厂房废物货包出库记录
        /// </summary>
        /// <param name="xssfworkbook"></param>
        /// <param name="packageCode"></param>
        /// <param name="bucketCode"></param>
        /// <param name="packageId"></param>
        public void RubConsMethod(XSSFWorkbook xssfworkbook, string packageCode, string bucketId, string bucketCode, string packageId)
        {
            XSSFSheet sheet = (XSSFSheet)xssfworkbook.GetSheet("QT厂房出库记录");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
            NuclearGoodsOutDetail nuclearGoodsOutDetailBy = _NuclearTsGoodsOutRepository.QueryDetailListAll().Where(d => d.BucketId == bucketId).OrderBy("ConfirmDate", SortDirection.Descending).FirstOrDefault();
            if (nuclearGoodsOutDetailBy != null)
            {
                NuclearTsGoodsOut nuclearTsGoodsOut = _NuclearTsGoodsOutRepository.Get(nuclearGoodsOutDetailBy.GoodsOutId);
                IQueryable<NuclearGoodsOutDetail> nuclearGoodsOutDetail = _NuclearTsGoodsOutRepository.QueryDetailList(nuclearGoodsOutDetailBy.GoodsOutId);
                if (nuclearTsGoodsOut != null)
                {
                    sheet.GetRow(3).GetCell(4).SetCellValue(nuclearTsGoodsOut.Reason);
                    sheet.GetRow(3).GetCell(8).SetCellValue(nuclearTsGoodsOut.TicketCode);
                    sheet.GetRow(3).GetCell(11).SetCellValue(nuclearTsGoodsOut.Batch);
                }

                if (nuclearGoodsOutDetail.Count() > 0)
                {
                    List<NuclearGoodsOutDetail> nuclearGoodsOutDetailList = nuclearGoodsOutDetail.ToList();
                    if (nuclearGoodsOutDetailList.Count() < 9)
                    {
                        for (int i = 0; i < nuclearGoodsOutDetailList.Count(); i++)
                        {

                            sheet.GetRow(8 + i).GetCell(1).SetCellValue(i + 1);
                            sheet.GetRow(8 + i).GetCell(2).SetCellValue(bucketCode);
                            sheet.GetRow(8 + i).GetCell(3).SetCellValue(packageCode);
                            sheet.GetRow(8 + i).GetCell(4).SetCellValue(nuclearGoodsOutDetailList[0].ContentGoods);
                            sheet.GetRow(8 + i).GetCell(5).SetCellValue(nuclearGoodsOutDetailList[0].DoseSurface.ToString());
                            sheet.GetRow(8 + i).GetCell(6).SetCellValue(nuclearGoodsOutDetailList[0].DoseMeter.ToString());
                            sheet.GetRow(8 + i).GetCell(7).SetCellValue(nuclearGoodsOutDetailList[0].PolluteA.ToString());
                            sheet.GetRow(8 + i).GetCell(8).SetCellValue(nuclearGoodsOutDetailList[0].PolluteB.ToString());

                            sheet.GetRow(8 + i).GetCell(9).SetCellValue(nuclearGoodsOutDetailList[0].GoodsFacade);
                            sheet.GetRow(8 + i).GetCell(10).SetCellValue(nuclearGoodsOutDetailList[0].ProcessName);
                            sheet.GetRow(8 + i).GetCell(11).SetCellValue(nuclearGoodsOutDetailList[0].ProcessDate.HasValue ? nuclearGoodsOutDetailList[0].ProcessDate.Value.ToString("yyyy-MM-dd") : "");
                            sheet.GetRow(8 + i).GetCell(12).SetCellValue(nuclearGoodsOutDetailList[0].Remark);

                        }
                    }
                    else
                    {
                        int addRow = nuclearGoodsOutDetailList.Count() - 8;
                        NPOIHelper.CopyRow(sheet, 15, 14, addRow);
                        for (int i = 0; i < nuclearGoodsOutDetailList.Count(); i++)
                        {
                            sheet.GetRow(8 + i).GetCell(1).SetCellValue(i + 1);
                            sheet.GetRow(8 + i).GetCell(2).SetCellValue(bucketCode);
                            sheet.GetRow(8 + i).GetCell(3).SetCellValue(packageCode);
                            sheet.GetRow(8 + i).GetCell(4).SetCellValue(nuclearGoodsOutDetailList[0].ContentGoods);
                            sheet.GetRow(8 + i).GetCell(5).SetCellValue(nuclearGoodsOutDetailList[0].DoseSurface.ToString());
                            sheet.GetRow(8 + i).GetCell(6).SetCellValue(nuclearGoodsOutDetailList[0].DoseMeter.ToString());
                            sheet.GetRow(8 + i).GetCell(7).SetCellValue(nuclearGoodsOutDetailList[0].PolluteA.ToString());
                            sheet.GetRow(8 + i).GetCell(8).SetCellValue(nuclearGoodsOutDetailList[0].PolluteB.ToString());
                            sheet.GetRow(8 + i).GetCell(9).SetCellValue(nuclearGoodsOutDetailList[0].GoodsFacade);
                            sheet.GetRow(8 + i).GetCell(10).SetCellValue(nuclearGoodsOutDetailList[0].ProcessName);
                            sheet.GetRow(8 + i).GetCell(11).SetCellValue(nuclearGoodsOutDetailList[0].ProcessDate.HasValue ? nuclearGoodsOutDetailList[0].ProcessDate.Value.ToString("yyyy-MM-dd") : "");
                            sheet.GetRow(8 + i).GetCell(12).SetCellValue(nuclearGoodsOutDetailList[0].Remark);

                        }
                    }


                }

            }
        }

          /// <summary>
        /// 废物包质量检查
          /// </summary>
          /// <param name="xssfworkbook"></param>
          /// <param name="packageCode"></param>
        public void DispiteConfirmMethod(XSSFWorkbook xssfworkbook, string packageCode,string bucketCode,string bucketId)
        {


            //建立一个名为Sheet1的工作表
            XSSFSheet sheet1 = (XSSFSheet)xssfworkbook.GetSheet("质保审查单");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;


            //获得数据
            DispiteConfirmVM vm = new DispiteConfirmVM();
            List<NuclearWastePackage> nuclearWastePackageList = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode.Trim() && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (nuclearWastePackageList.Count() > 0)
            {
                //获得质量确认主表
                List<DispiteConfirm> dispiteConfirmList = _DispiteConfirmRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId).ToList();
                if (dispiteConfirmList.Count() > 0)
                {

                    DispiteConfirm dispiteConfirm = _DispiteConfirmRepository.Get(dispiteConfirmList[0].ConfirmId);
                    List<DispiteConfirmDetail> dispiteConfirmDetail = _DispiteConfirmDetailRepository.GetAll().Where(d => d.ConfirmId == dispiteConfirm.ConfirmId).ToList();
                    foreach (var item in dispiteConfirmDetail)
                    {
                        if (item.CheckType == "PREPARE")
                        {
                            vm.Prepare = item.ExplainContent;
                        }
                        if (item.CheckType == "SOLID")
                        {
                            vm.Solid = item.ExplainContent;
                        }
                        if (item.CheckType == "COVER")
                        {
                            vm.Cover = item.ExplainContent;
                        }
                        if (item.CheckType == "TRANSFER")
                        {
                            vm.Transfer = item.ExplainContent;
                        }
                        if (item.CheckType == "RECEIVE")
                        {
                            vm.Receive = item.ExplainContent;
                        }
                        if (item.CheckType == "SUPPLY")
                        {
                            vm.Supply = item.ExplainContent;
                        }

                    }

                }

                //获得桶的信息
                List<NuclearBucket> nuclearBucketList = this._NuclearBucketRepository.GetAll().Where(d => d.BucketId == nuclearWastePackageList[0].BucketId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                if (nuclearBucketList.Count() > 0)
                {
                    vm.BucketCode = nuclearBucketList[0].BucketCode;
                    vm.WasteType = nuclearBucketList[0].WasteType;
                    vm.DealDate = nuclearBucketList[0].DealDate.HasValue ? nuclearBucketList[0].DealDate.Value.ToString("yyyy-MM-dd") : "";
                }
                //废物货包编号赋值
                vm.PackageCode = packageCode.Trim();
                //废物重量赋值
                List<NuclearRubLocation> nuclearRubLocationList = this._NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                if (nuclearRubLocationList.Count() > 0)
                {
                    vm.Weight = nuclearRubLocationList[0].Weight;
                }
                
              

                NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == nuclearWastePackageList[0].BucketId).FirstOrDefault();
                if (nuclearApplyDetail != null)
                {
                    DispsiteCheckDetail dispsiteCheckDetail = _DispsiteCheckDetailRepository.GetAll().Where(d => d.ApplyDetailId == nuclearApplyDetail.ApplyDetailId).FirstOrDefault();
                    //废物跟踪
                    vm.BucketIsrequired = dispsiteCheckDetail.BucketIsrequired;
                    vm.BucketCheckresult = dispsiteCheckDetail.BucketCheckresult;

                    //容器入库检查表
                    vm.BucketMesIsrequired = dispsiteCheckDetail.BucketMesIsrequired;
                    vm.BucketMesCheckresult = dispsiteCheckDetail.BucketMesCheckresult;

                    //容器质量检验单
                    vm.InspectIsrequired = dispsiteCheckDetail.InspectIsrequired;
                    vm.InspectCheckresult = dispsiteCheckDetail.InspectCheckresult;



                    //vm.BarrelIsrequired = dispsiteCheckDetail.BarrelIsrequired;
                    //vm.BarrelCheckresult = dispsiteCheckDetail.BarrelCheckresult;


                    //干混料制备及装桶封盖
                    vm.DoseIsrequired = dispsiteCheckDetail.DoseIsrequired;
                    vm.DoseCheckresult = dispsiteCheckDetail.DoseCheckresult;
                    //废物包转运及QT移动
                    vm.TransferIsrequired = dispsiteCheckDetail.TransferIsrequired;
                    vm.TransferCheckresult = dispsiteCheckDetail.TransferCheckresult;

                    //废物包放射性特征评价
                    vm.EvaluateIsrequired = dispsiteCheckDetail.EvaluateIsrequired;
                    vm.EvaluateCheckresult = dispsiteCheckDetail.EvaluateCheckresult;
                   

                }

                //废物货包接收、检查
                List<NuclearRubReceptionD> nuclearRubReceptionDList = this._NuclearRubReceptionDRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId).ToList();
                if (nuclearRubReceptionDList.Count() > 0)
                {
                    vm.Isquelified = nuclearRubReceptionDList[0].CheckResult;
                    vm.Remark = nuclearRubReceptionDList[0].Remark;
                }
                NuclearRubLocation nuclearRubLocation = _NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId).FirstOrDefault();
                if (nuclearRubLocation != null)
                {
                    vm.Status = nuclearRubLocation.Status;
                    vm.RubRemark = nuclearRubLocation.Remark;
                }
            }
            //获得审核结果数据
            //List<DispiteConfirmView> dispiteConfirmViewList = this._DispiteConfirmRepository.QueryList().Where(d => d.PackageCode == packageCode.Trim()).ToList();
            //if (dispiteConfirmViewList.Count() > 0)
            //{
            //    vm.InspectIsrequired = dispiteConfirmViewList[0].InspectIsrequired;
            //    vm.BarrelIsrequired = dispiteConfirmViewList[0].BarrelIsrequired;
            //    vm.DoseIsrequired = dispiteConfirmViewList[0].DoseIsrequired;
            //    vm.TransferIsrequired = dispiteConfirmViewList[0].TransferIsrequired;
            //}

            sheet1.GetRow(7).GetCell(0).SetCellValue(vm.BucketCode);
            sheet1.GetRow(7).GetCell(4).SetCellValue(vm.PackageCode);
            sheet1.GetRow(7).GetCell(9).SetCellValue(Convert.ToString(vm.Weight));
            sheet1.GetRow(7).GetCell(13).SetCellValue(vm.DealDate);
            sheet1.GetRow(7).GetCell(18).SetCellValue(vm.WasteType);

            if (vm.BucketIsrequired == "0")
            {
                sheet1.GetRow(12).GetCell(9).SetCellValue("不符合要求");
            }
            if (vm.BucketIsrequired == "1")
            {
                sheet1.GetRow(12).GetCell(9).SetCellValue("符合要求");
            }


            if (vm.BucketMesIsrequired == "0")
            {
                sheet1.GetRow(14).GetCell(9).SetCellValue("不符合要求");
            }
            if (vm.BucketMesIsrequired == "1")
            {
                sheet1.GetRow(14).GetCell(9).SetCellValue("符合要求");
            }


            if (vm.InspectIsrequired == "0")
            {
                sheet1.GetRow(16).GetCell(9).SetCellValue("不符合要求");
            }
            if (vm.InspectIsrequired == "1")
            {
                sheet1.GetRow(16).GetCell(9).SetCellValue("符合要求");
            }
            
            //if (vm.BarrelIsrequired == "0")
            //{
            //    sheet1.GetRow(16).GetCell(9).SetCellValue("不符合要求");
            //}
            //if (vm.BarrelIsrequired == "1")
            //{
            //    sheet1.GetRow(16).GetCell(9).SetCellValue("符合要求");
            //}
           

            if (vm.DoseIsrequired == "0")
            {
                sheet1.GetRow(18).GetCell(9).SetCellValue("不符合要求");
            }
            if (vm.DoseIsrequired == "1")
            {
                sheet1.GetRow(18).GetCell(9).SetCellValue("符合要求");
            }
           
            if (vm.TransferIsrequired == "0")
            {
                sheet1.GetRow(20).GetCell(9).SetCellValue("不符合要求");
            }
            if (vm.TransferIsrequired == "1")
            {
                sheet1.GetRow(20).GetCell(9).SetCellValue("符合要求");
            }


            //废物活度计算单
            ActivityCountCondition activityCountCondition = new ActivityCountCondition();
            IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition).Where(d => d.BucketCode == bucketCode);
            if (activityCountList.Count() > 0)
            {
                sheet1.GetRow(22).GetCell(9).SetCellValue("符合要求");
            }
            else
            {
                sheet1.GetRow(22).GetCell(9).SetCellValue("不符合要求");
            }
            //废物包放射性特征评价
            if (vm.EvaluateIsrequired == "0")
            {
                sheet1.GetRow(24).GetCell(9).SetCellValue("不符合要求");
            }
            if (vm.EvaluateIsrequired == "1")
            {
                sheet1.GetRow(24).GetCell(9).SetCellValue("符合要求");
            }
            //废物包运输
            List<NuclearGoodsOutDetail> dataList = _NuclearTsGoodsOutRepository.QueryDetailListAll().Where(d => d.BucketId == bucketId).ToList();
            if (dataList.Count() > 0)
            {
                sheet1.GetRow(26).GetCell(9).SetCellValue("不符合要求");
            }
            else
            {
                sheet1.GetRow(26).GetCell(9).SetCellValue("符合要求");
            }

            if (vm.Isquelified == "0")
            {
                sheet1.GetRow(28).GetCell(9).SetCellValue("不符合要求");
            }
            if (vm.Isquelified == "1")
            {
                sheet1.GetRow(28).GetCell(9).SetCellValue("符合要求");
            }

            if (vm.Status == "2")
            {
                sheet1.GetRow(30).GetCell(9).SetCellValue("符合要求");
            }
            else
            {
                sheet1.GetRow(30).GetCell(9).SetCellValue("不符合要求");
            }


            sheet1.GetRow(12).GetCell(10).SetCellValue(vm.BucketCheckresult);
            sheet1.GetRow(14).GetCell(10).SetCellValue(vm.BucketMesCheckresult);
            sheet1.GetRow(16).GetCell(10).SetCellValue(vm.InspectCheckresult);
            sheet1.GetRow(18).GetCell(10).SetCellValue(vm.DoseCheckresult);
            sheet1.GetRow(20).GetCell(10).SetCellValue(vm.TransferCheckresult);
            sheet1.GetRow(24).GetCell(10).SetCellValue(vm.EvaluateCheckresult);
            sheet1.GetRow(28).GetCell(10).SetCellValue(vm.Remark);
            sheet1.GetRow(30).GetCell(10).SetCellValue(vm.RubRemark);
            sheet1.GetRow(32).GetCell(10).SetCellValue(vm.Supply);


        }
        /// <summary>
        /// 评估验算报表
        /// </summary>
        /// <param name="xssfworkbook"></param>
        /// <param name="packageCode"></param>
        /// <param name="bucketCode"></param>
        /// <param name="packageId"></param>
        public void EvaluateMethod(XSSFWorkbook xssfworkbook, NuclearWastePackage nuclearWastePackage, NuclearBucket nuclearBucket)
        {
            XSSFSheet sheet1 = (XSSFSheet)xssfworkbook.GetSheet("评估验算报表");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;

            string wasteProduceDate = null;
            string wasteGiftDate = null;
            string activityEvalDate = null;
            WastePackageCheckVM vm = new WastePackageCheckVM();
            vm.ActivityOrder = new ActivityOrder();
            vm.OperationList = CommonHelper.GetOperationList("Waste_Pacage_Check");

            NuclearApplyDetail nuclearApplyDetail = new NuclearApplyDetail();
            IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == nuclearBucket.BucketId).AsQueryable();
            foreach (var item in nuclearApplyDetailQuery)
            {
                nuclearApplyDetail.ApplyDetailId = item.ApplyDetailId;
            }
            vm.NuclearApplyDetail = nuclearApplyDetail;
            NuclearApplyDetail applyDetail = _NuclearApplyDetailRepository.Get(nuclearApplyDetail.ApplyDetailId);
            NuclearProcessApply nuclearProcessApply = new NuclearProcessApply();
            nuclearProcessApply.ProcessApplyId = applyDetail.ProcessApplyId;
            vm.NuclearProcessApply = nuclearProcessApply;

            List<SelectListItem> checkList = new List<SelectListItem>();
            checkList.Add(new SelectListItem { Text = "是", Value = "1", Selected = true });
            checkList.Add(new SelectListItem { Text = "否", Value = "0" });

            vm.WasteType = nuclearBucket.WasteType;
            vm.DealMethod = nuclearBucket.DealMethod;

            MaterialType materialType = this._MaterialTypeRepository.Get(nuclearBucket.MaterialId);
            vm.MaterialName = materialType.MaterialName;
            vm.CheckMaterialList = checkList;
            vm.CheckBucketAduitList = checkList;
            vm.EvaluateList = checkList;
            vm.CheckBucketMesList = checkList;
            vm.CheckBucketDealList = checkList;
            vm.CheckBucketCoverList = checkList;
            vm.CheckBucketTransferList = checkList;
            vm.FileIsCompletedList = checkList;

            List<SelectListItem> checkResultList = new List<SelectListItem>();
            checkResultList.Add(new SelectListItem { Text = "同意", Value = "1", Selected = true });
            checkResultList.Add(new SelectListItem { Text = "不同意", Value = "0" });
            vm.CheckResultList = checkResultList;
            vm.ApplyDetailId = nuclearApplyDetail.ApplyDetailId;

            //桶信息
            vm.NuclearBucket = this._NuclearBucketRepository.Get(nuclearBucket.BucketId);
            if (vm.NuclearBucket == null)
            {
                vm.NuclearBucket = new NuclearBucket();
            }
            //存储和转运信息
            vm.IsExistTransferAndStorage = WasteCheckBuilder.IsExistTransferAndStorage(nuclearBucket.BucketId);

            //审核明细信息
            activityOrder.MinusProduceDate = string.Empty;
            activityOrder.MinusOriginalActivity = string.Empty;
            IQueryable<DispsiteCheckDetail> dispsiteCheckDetail = this._DispsiteCheckDetailRepository.GetAll().AsQueryable().Where(c => c.ApplyDetailId == nuclearApplyDetail.ApplyDetailId);
            if (dispsiteCheckDetail.Count() > 0)
            {
                vm.DispsiteCheckDetail = dispsiteCheckDetail.ToList()[0];
                string detailId = vm.DispsiteCheckDetail.DetailId;
                IQueryable<DispsiteEval> dispiteEval = _DispsiteEvalRepository.GetAll().AsQueryable().Where(c => c.CheckDetailId == detailId);
                if (dispiteEval.Count() > 0)
                {
                    DispsiteEval dispsiteEval = dispiteEval.ToList()[0];
                    wasteProduceDate = dispsiteEval.ActivityProduceDate.Value.ToString("yyyy-MM-dd");
                    wasteGiftDate = dispsiteEval.ActivityGiftDate.Value.ToString("yyyy-MM-dd");
                    activityEvalDate = dispsiteEval.ActivityEvalDate.Value.ToString("yyyy-MM-dd");

                }
            }
            else
            {
                vm.DispsiteCheckDetail = new DispsiteCheckDetail();
            }

            //废物包信息
            vm.WastePackageBucketVM = new WastePackageBucketVM();
            vm.WastePackageBucketVM.NuclearWastePackage = nuclearWastePackage;

            //废物包活度计算信息
            ActivityCountCondition activityCountCondition = new ActivityCountCondition();
            activityCountCondition.BucketId = nuclearBucket.BucketId;
            IQueryable<ActivityCount> iqueryActivityCount = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition);
            ActivityCount activityCount = new ActivityCount();
            if (iqueryActivityCount.Count() > 0)
            {
                activityCount = iqueryActivityCount.ToList()[0];
                activityOrder = ActivityBuilder.GetActivityOrder(activityCount, vm.NuclearBucket, nuclearWastePackage.PackageCode);
            }
            activityOrder.WasteProduceDate = wasteProduceDate;
            activityOrder.WasteGiftDate = wasteGiftDate;
            activityOrder.ActivityEvalDate = activityEvalDate;
            activityOrder.PackageWeight = nuclearWastePackage == null ? null : nuclearWastePackage.Weight.ToString();
            if (!string.IsNullOrEmpty(activityOrder.AcitivityId))
            {
                activityOrder = MetelActivityCalcuBuilder.GetMetelBucketCalcuElement(activityOrder);
            }

            //时间间隔
            try
            {
                if (!string.IsNullOrEmpty(wasteProduceDate) && !string.IsNullOrEmpty(wasteGiftDate))
                {
                    activityOrder.MinusProduceDate = (Convert.ToDateTime(wasteGiftDate) - Convert.ToDateTime(wasteProduceDate)).TotalDays.ToString();
                }
                if (!string.IsNullOrEmpty(activityEvalDate) && !string.IsNullOrEmpty(wasteProduceDate))
                {
                    activityOrder.MinusOriginalActivity = (Convert.ToDateTime(activityEvalDate) - Convert.ToDateTime(wasteGiftDate)).TotalDays.ToString();
                }
            }
            catch { }

            vm.ActivityOrder = activityOrder;

            ////固化、封盖、转运信息 
            //var SolutionModel = _NuclearBucketSolutionRepository.GetModelByBucketId(nuclearBucket.BucketId);
            //var ResinModel = _NuclearBucketResinRepository.GetModelByBucketId(nuclearBucket.BucketId);
            //var RSolidifyModel = _NuclearBucketRSolidifyRepository.GetModelByBucketId(nuclearBucket.BucketId);
            //var SSolidifyModel = _NuclearBucketSSolidifyRepository.GetModelByBucketId(nuclearBucket.BucketId);
            //var MetaModel = _NuclearCoverMetalRepository.GetModelByBucketId(nuclearBucket.BucketId);
            //var MixModel = _NuclearCoverMixRepository.GetModelByBucketId(nuclearBucket.BucketId);
            //var QtTransModel = _NuclearQtTransRepository.GetModelByBucketId(bucketId);
            //var FcTransModel = _NuclearFcTransRepository.GetModelByBucketId(bucketId);
            //var GoodsInModel = _NuclearTsGoodsInRepository.GetModelByBucketId(bucketId);
            //var GoodsOutModel = _NuclearTsGoodsOutRepository.GetModelByBucketId(bucketId);
            //if (SolutionModel != null)
            //    vm.SolutionId = SolutionModel.SolutionId;
            //if (ResinModel != null)
            //    vm.ResinId = ResinModel.ResinId;
            //if (RSolidifyModel != null)
            //    vm.RSolidifyId = RSolidifyModel.SolidifyRId;
            //if (SSolidifyModel != null)
            //    vm.SSolidifyId = SSolidifyModel.SolidifySIdd;
            //if (MetaModel != null)
            //{
            //    vm.MetalId = MetaModel.MetalId;
            //    vm.DoseMeter = MetaModel.DoseMeter;
            //}
            //if (MixModel != null)
            //{
            //    vm.DoseMeter = MixModel.DoseMeter;
            //    vm.MixId = MixModel.MixId;
            //}
            //if (QtTransModel != null)
            //    vm.QtTransId = QtTransModel.QtTransId;
            //if (FcTransModel != null)
            //    vm.FcTransId = FcTransModel.FcDetailId;
            //if (GoodsInModel != null)
            //    vm.GoodsInId = GoodsInModel.GoodsInDetailId;
            //if (GoodsOutModel != null)
            //    vm.GoodsOutId = GoodsOutModel.GoodsOutDetailId;

            sheet1.GetRow(6).GetCell(2).SetCellValue(vm.MaterialInputVM.BucketCode);
            sheet1.GetRow(6).GetCell(6).SetCellValue(vm.WastePackageBucketVM.NuclearWastePackage.PackageCode);
            sheet1.GetRow(6).GetCell(13).SetCellValue(vm.ActivityOrder.WasteProduceDate);
            sheet1.GetRow(7).GetCell(2).SetCellValue(vm.NuclearBucket.WasteType);
            sheet1.GetRow(7).GetCell(6).SetCellValue(vm.ActivityOrder.BucketHandleCount);
            sheet1.GetRow(7).GetCell(13).SetCellValue(vm.ActivityOrder.WasteGiftDate);
            if (vm.ActivityOrder.Damage == "1")
            {
                sheet1.GetRow(8).GetCell(2).SetCellValue("有");
            }
            else
            {
                sheet1.GetRow(8).GetCell(2).SetCellValue("无");
            }

            sheet1.GetRow(8).GetCell(6).SetCellValue(vm.ActivityOrder.EdsCode);
            sheet1.GetRow(8).GetCell(14).SetCellValue(vm.ActivityOrder.MinusProduceDate);
            sheet1.GetRow(9).GetCell(3).SetCellValue(Convert.ToString(vm.DoseMeter));
            sheet1.GetRow(9).GetCell(7).SetCellValue(Convert.ToString(vm.ActivityOrder.AddCalcuActivity));
            sheet1.GetRow(9).GetCell(14).SetCellValue(vm.ActivityOrder.ActivityEvalDate);
            sheet1.GetRow(10).GetCell(3).SetCellValue(vm.WastePackageBucketVM.NuclearWastePackage.Weight.ToString());
            sheet1.GetRow(10).GetCell(6).SetCellValue(vm.WastePackageBucketVM.NuclearWastePackage.Volumn.ToString());
            sheet1.GetRow(10).GetCell(14).SetCellValue(vm.ActivityOrder.MinusOriginalActivity);

            CommonHelper commonHelper = new CommonHelper();
            //获取数据
            List<DispiteEvalDetailVM> list = new List<DispiteEvalDetailVM>();
            if (activityOrder.DispiteEvalDetailVMList != null)
            {
                list = activityOrder.DispiteEvalDetailVMList;

                if (list.Count() <= 26 && list.Count() > 0)
                {
                    for (int i = 0; i < list.Count(); i++)
                    {
                        sheet1.GetRow(14 + i).GetCell(1).SetCellValue(list[i].ElementName);
                        sheet1.GetRow(14 + i).GetCell(2).SetCellValue(list[i].ElementClass);
                        sheet1.GetRow(14 + i).GetCell(5).SetCellValue(list[i].HalfLife);
                        sheet1.GetRow(14 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(list[i].OriginalActivity == null ? "0" : list[i].OriginalActivity.ToString())));
                        sheet1.GetRow(14 + i).GetCell(13).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal((list[i].OriginalWasteActivity == null || list[i].OriginalWasteActivity == "采样分析") ? "0" : list[i].OriginalWasteActivity.ToString())));
                        sheet1.GetRow(14 + i).GetCell(15).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(list[i].CheckdateActivity)));
                    }


                }
                if (list.Count() > 26)
                {
                    int addRow = list.Count() - 26;
                    NPOIHelper.CopyRow(sheet1, 40, 39, addRow);

                    for (int i = 0; i < list.Count(); i++)
                    {
                        sheet1.GetRow(14 + i).GetCell(1).SetCellValue(list[i].ElementName);
                        sheet1.GetRow(14 + i).GetCell(2).SetCellValue(list[i].ElementClass);
                        sheet1.GetRow(14 + i).GetCell(5).SetCellValue(list[i].HalfLife);
                        sheet1.GetRow(14 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(list[i].OriginalActivity == null ? "0" : list[i].OriginalActivity.ToString())));
                        sheet1.GetRow(14 + i).GetCell(13).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal((list[i].OriginalWasteActivity == null || list[i].OriginalWasteActivity == "采样分析") ? "0" : list[i].OriginalWasteActivity.ToString())));
                        sheet1.GetRow(14 + i).GetCell(15).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(list[i].CheckdateActivity)));
                    }

                }

            }

            if (list.Count() <= 26)
            {
                sheet1.GetRow(42).GetCell(4).SetCellValue(vm.ActivityOrder.ActivityCompare);
                sheet1.GetRow(42).GetCell(13).SetCellValue(vm.ActivityOrder.KeyActivityUnitCompare);
                sheet1.GetRow(43).GetCell(4).SetCellValue(vm.ActivityOrder.TotalActivity);
                sheet1.GetRow(43).GetCell(13).SetCellValue(vm.ActivityOrder.DecayThreeHundred);
                sheet1.GetRow(44).GetCell(4).SetCellValue(vm.ActivityOrder.Classify + "   " + vm.ActivityOrder.ClassifyValue);
                sheet1.GetRow(44).GetCell(13).SetCellValue(vm.ActivityOrder.SurfaceClass);
                sheet1.GetRow(45).GetCell(4).SetCellValue(vm.ActivityOrder.DecayHeat);
                sheet1.GetRow(45).GetCell(13).SetCellValue(vm.ActivityOrder.CalcuThreeHundred);
            }
            else
            {
                int addRow = list.Count() - 26;
                sheet1.GetRow(42 + addRow).GetCell(4).SetCellValue(vm.ActivityOrder.ActivityCompare);
                sheet1.GetRow(42 + addRow).GetCell(13).SetCellValue(vm.ActivityOrder.KeyActivityUnitCompare);
                sheet1.GetRow(43 + addRow).GetCell(4).SetCellValue(vm.ActivityOrder.TotalActivity);
                sheet1.GetRow(43 + addRow).GetCell(13).SetCellValue(vm.ActivityOrder.DecayThreeHundred);
                sheet1.GetRow(44 + addRow).GetCell(4).SetCellValue(vm.ActivityOrder.Classify + "   " + vm.ActivityOrder.ClassifyValue);
                sheet1.GetRow(44 + addRow).GetCell(13).SetCellValue(vm.ActivityOrder.SurfaceClass);
                sheet1.GetRow(45 + addRow).GetCell(4).SetCellValue(vm.ActivityOrder.DecayHeat);
                sheet1.GetRow(45 + addRow).GetCell(13).SetCellValue(vm.ActivityOrder.CalcuThreeHundred);
            }
          


        }
        /// <summary>
        /// DNMC封面页
        /// </summary>
        /// <param name="xssfworkbook"></param>
        /// <param name="packageCode"></param>
        /// <param name="bucketCode"></param>
        /// <param name="packageId"></param>
        public void RecordMethod(XSSFWorkbook xssfworkbook, string packageCode, string fileId)
        {
            XSSFSheet sheet = (XSSFSheet)xssfworkbook.GetSheet("DNMC");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;

            BasicWasteUnit basicWasteUnit = _BasicWasteUnitRepository.GetAll().Where(d => d.SimpleCode == AppContext.CurrentUser.ProjectCode).FirstOrDefault();
            NuclearRubFile nuclearRubFile = this._NuclearRubFileRepository.Get(fileId);
            string bucketCode = string.Empty;

            if (basicWasteUnit != null)
            {
                sheet.GetRow(9).GetCell(5).SetCellValue(basicWasteUnit.UnitName);
            }
            if (nuclearRubFile.SecrecyLevel == "Secrecy")
            {
                sheet.GetRow(11).GetCell(5).SetCellValue("机密");
            }
            if (nuclearRubFile.SecrecyLevel == "Restriction")
            {
                sheet.GetRow(11).GetCell(5).SetCellValue("限制使用");
            }
            sheet.GetRow(13).GetCell(5).SetCellValue(packageCode);
        }
    }
}