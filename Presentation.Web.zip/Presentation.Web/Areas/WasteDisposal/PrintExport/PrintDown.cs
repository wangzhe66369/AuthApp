﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NPOI.XSSF.UserModel;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels;
using RWIS.Domain.DomainObjects.View.NuclearRubFile;
using NET01.CoreFramework;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.Activity.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.Controllers
{
    public class PrintDown
    {
        #region 构造函数
        INuclearRubFileRepository _NuclearRubFileRepository = ServiceLocator.Current.GetInstance<INuclearRubFileRepository>();
        INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
        INuclearMStockRepository _NuclearMStockRepository = ServiceLocator.Current.GetInstance<INuclearMStockRepository>();
        INuclearWastePackageRepository _NuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
        INuclearRubLocationRepository _NuclearRubLocationRepository = ServiceLocator.Current.GetInstance<INuclearRubLocationRepository>();
        IBasicObjectRepository _BasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
        IMaterialTypeRepository _MaterialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
        INuclearBucketCheckRepository _NuclearBucketCheckRepository = ServiceLocator.Current.GetInstance<INuclearBucketCheckRepository>();
        INuclearRubReceptionDRepository _NuclearRubReceptionDRepository = ServiceLocator.Current.GetInstance<INuclearRubReceptionDRepository>();
        INuclearRubReceptionRepository _NuclearRubReceptionRepository = ServiceLocator.Current.GetInstance<INuclearRubReceptionRepository>();
        INuclearElementRepository _NuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
        ISupportEdsDetailRepository _SupportEdsDetailRepository = ServiceLocator.Current.GetInstance<ISupportEdsDetailRepository>();
        INuclearFixationRepository _NuclearFixationRepository = ServiceLocator.Current.GetInstance<INuclearFixationRepository>();
        INuclearFixationDetailRepository _NuclearFixationDetailRepository = ServiceLocator.Current.GetInstance<INuclearFixationDetailRepository>();
        INuclearCoverMixRepository _NuclearCoverMixRepository = ServiceLocator.Current.GetInstance<INuclearCoverMixRepository>();
        INuclearQtTransRepository _NuclearQtTransRepository = ServiceLocator.Current.GetInstance<INuclearQtTransRepository>();
        INuclearTrackElementRepository _NuclearTrackElementRepository = ServiceLocator.Current.GetInstance<INuclearTrackElementRepository>();
        IActivityBucketRepository _ActivityBucketRepository = ServiceLocator.Current.GetInstance<IActivityBucketRepository>();
        IActivityBucketDetailRepository _ActivityBucketDetailRepository = ServiceLocator.Current.GetInstance<IActivityBucketDetailRepository>();
        ISupportEdsRepository _SupportEdsRepository = ServiceLocator.Current.GetInstance<ISupportEdsRepository>();
        IActivityCementliquidRepository _ActivityCementliquidRepository = ServiceLocator.Current.GetInstance<IActivityCementliquidRepository>();
        IActivityCliquidDetailRepository _ActivityCliquidDetailRepository = ServiceLocator.Current.GetInstance<IActivityCliquidDetailRepository>();
        IActivityCfilterRepository _ActivityCfilterRepository = ServiceLocator.Current.GetInstance<IActivityCfilterRepository>();
        IActivityCfilterDetailRepository _ActivityCfilterDetailRepository = ServiceLocator.Current.GetInstance<IActivityCfilterDetailRepository>();
        IActivityCoreRepository _ActivityCoreRepository = ServiceLocator.Current.GetInstance<IActivityCoreRepository>();
        IActivityCoreDetailRepository _ActivityCoreDetailRepository = ServiceLocator.Current.GetInstance<IActivityCoreDetailRepository>();
        IActivityCresinRepository _ActivityCresinRepository = ServiceLocator.Current.GetInstance<IActivityCresinRepository>();
        IActivityCresinDetailRepository _ActivityCresinDetailRepository = ServiceLocator.Current.GetInstance<IActivityCresinDetailRepository>();
        IActivityHlevelRepository _ActivityHlevelRepository = ServiceLocator.Current.GetInstance<IActivityHlevelRepository>();
        IActivityHlevelDetailRepository _ActivityHlevelDetailRepository = ServiceLocator.Current.GetInstance<IActivityHlevelDetailRepository>();
        IActivityMfilterRepository _ActivityMfilterRepository = ServiceLocator.Current.GetInstance<IActivityMfilterRepository>();
        IActivityMfilterDetailRepository _ActivityMfilterDetailRepository = ServiceLocator.Current.GetInstance<IActivityMfilterDetailRepository>();
        IActivityMliquidRepository _ActivityMliquidRepository = ServiceLocator.Current.GetInstance<IActivityMliquidRepository>();
        IActivityMliquidDetailRepository _ActivityMliquidDetailRepository = ServiceLocator.Current.GetInstance<IActivityMliquidDetailRepository>();
        IActivityMresinRepository _ActivityMresinRepository = ServiceLocator.Current.GetInstance<IActivityMresinRepository>();
        IActivityMresinDetailRepository _ActivityMresinDetailRepository = ServiceLocator.Current.GetInstance<IActivityMresinDetailRepository>();
        IActivityOpBucketRepository _ActivityOpBucketRepository = ServiceLocator.Current.GetInstance<IActivityOpBucketRepository>();
        IActivityOpBucketDetailRepository _ActivityOpBucketDetailRepository = ServiceLocator.Current.GetInstance<IActivityOpBucketDetailRepository>();
        INuclearBucketSolutionRepository _NuclearBucketSolutionRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolutionRepository>();
        INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketSSolidifyRepository>();
        INuclearBucketResinRepository _NuclearBucketResinRepository = ServiceLocator.Current.GetInstance<INuclearBucketResinRepository>();
        INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketRSolidifyRepository>();
        INuclearNuclideSampleRepository _NuclearNuclideSampleRepository = ServiceLocator.Current.GetInstance<INuclearNuclideSampleRepository>();
        INuclearNuclideRepository _NuclearNuclideRepository = ServiceLocator.Current.GetInstance<INuclearNuclideRepository>();
        IMaterialInputRepository _MaterialInputRepository = ServiceLocator.Current.GetInstance<IMaterialInputRepository>();
        #endregion
        ///// <summary>
        ///// 固体放射性废物跟踪单封面页
        ///// </summary>
        ///// <param name="fileId"></param>
        ///// <param name="xssfworkbook"></param>
        //public void WasteCoverPrint(string fileId, XSSFWorkbook xssfworkbook)
        //{
        //    //建立一个名为Sheet0的工作表
        //    XSSFSheet sheet0 = (XSSFSheet)xssfworkbook.GetSheet("固体放射性废物跟踪单");
        //    XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
        //    cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
        //    cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
        //    //求封面页数据
        //    NuclearRubFile nuclearRubFile = this._NuclearRubFileRepository.Get(fileId);
        //    if (nuclearRubFile != null)
        //    {
        //        sheet0.GetRow(3).GetCell(3).SetCellValue("£");
        //        sheet0.GetRow(3).GetCell(5).SetCellValue("£");
        //        if (nuclearRubFile.SecrecyLevel == "Restriction")
        //        {
        //            sheet0.GetRow(5).GetCell(0).SetCellValue("£");
        //            sheet0.GetRow(6).GetCell(0).SetCellValue("R");
        //            sheet0.GetRow(7).GetCell(0).SetCellValue("£");
        //        }
        //        else if (nuclearRubFile.SecrecyLevel == "Secrecy")
        //        {
        //            sheet0.GetRow(5).GetCell(0).SetCellValue("£");
        //            sheet0.GetRow(6).GetCell(0).SetCellValue("£");
        //            sheet0.GetRow(7).GetCell(0).SetCellValue("R");
        //        }
        //        else {
        //            sheet0.GetRow(5).GetCell(0).SetCellValue("£");
        //            sheet0.GetRow(6).GetCell(0).SetCellValue("£");
        //            sheet0.GetRow(7).GetCell(0).SetCellValue("£");
        //        }
        //        sheet0.GetRow(7).GetCell(7).SetCellValue(nuclearRubFile.FilePage);//页数
        //        sheet0.GetRow(17).GetCell(6).SetCellValue(DateTime.Now.ToString("yyyy")+"年");
        //    }
        //}
        /// <summary>
        /// 水泥桶准备
        /// </summary>
        /// <param name="xssfworkbook"></param>
        /// <param name="packageCode"></param>
        /// <returns></returns>
        public void CementPreparePrint(string packageCode, XSSFWorkbook xssfworkbook)
        {
            //建立一个名为Sheet1的工作表
            XSSFSheet sheet1 = (XSSFSheet)xssfworkbook.GetSheet("水泥桶准备");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;

            //求数据
            IQueryable<NuclearWastePackage> nuclearWastePackageQuery = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode).AsQueryable();
            List<NuclearWastePackage> nuclearWastePackage = new List<NuclearWastePackage>();
            List<NuclearBucketCheck> nuclearBucketCheck = new List<NuclearBucketCheck>();
            NuclearBucket nuclearBucket = null;
            if (nuclearWastePackageQuery != null && nuclearWastePackageQuery.Count() > 0)
            {
                nuclearWastePackage = nuclearWastePackageQuery.ToList();
                nuclearBucket = _NuclearBucketRepository.Get(nuclearWastePackage[0].BucketId);
                IQueryable<NuclearBucketCheck> nuclearBucketCheckQuery = _NuclearBucketCheckRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                if (nuclearBucketCheckQuery != null && nuclearBucketCheckQuery.Count() > 0)
                {
                    nuclearBucketCheck = nuclearBucketCheckQuery.ToList();
                }
            }
            if (nuclearBucket == null) nuclearBucket = new NuclearBucket();
            sheet1.GetRow(5).GetCell(1).SetCellValue(nuclearBucket.BucketCode);
            sheet1.GetRow(5).GetCell(7).SetCellValue(nuclearBucketCheck[0].WorkTicket);
            if (nuclearBucketCheck[0].TechStandard == "0")
            {
                sheet1.GetRow(6).GetCell(5).SetCellValue("£");
                sheet1.GetRow(6).GetCell(9).SetCellValue("R");
            }
            else if (nuclearBucketCheck[0].TechStandard == "1")
            {
                sheet1.GetRow(6).GetCell(5).SetCellValue("R");
                sheet1.GetRow(6).GetCell(9).SetCellValue("£");
            }
            else
            {
                sheet1.GetRow(6).GetCell(5).SetCellValue("£");
                sheet1.GetRow(6).GetCell(9).SetCellValue("£");
            }
            sheet1.GetRow(7).GetCell(3).SetCellValue(nuclearBucketCheck[0].HeightNorm.ToString());
            if (nuclearBucketCheck[0].CladLining == "0")
            {
                sheet1.GetRow(8).GetCell(5).SetCellValue("R");
                sheet1.GetRow(8).GetCell(9).SetCellValue("£");
            }
            else
            {
                sheet1.GetRow(8).GetCell(5).SetCellValue("£");
                sheet1.GetRow(8).GetCell(9).SetCellValue("R");
            }
            if (nuclearBucketCheck[0].CenterBasket == "0" && nuclearBucketCheck[0].CenterHolder == "0")
            {
                sheet1.GetRow(9).GetCell(5).SetCellValue("R");
                sheet1.GetRow(9).GetCell(9).SetCellValue("£");
            }
            else
            {
                sheet1.GetRow(9).GetCell(5).SetCellValue("£");
                sheet1.GetRow(9).GetCell(9).SetCellValue("R");
            }
            sheet1.GetRow(10).GetCell(5).SetCellValue("");//类型
            if (nuclearBucketCheck[0].GeneralEval == "1")
            {
                sheet1.GetRow(11).GetCell(5).SetCellValue("R");
                sheet1.GetRow(11).GetCell(9).SetCellValue("£");
            }
            else
            {
                sheet1.GetRow(11).GetCell(5).SetCellValue("£");
                sheet1.GetRow(11).GetCell(9).SetCellValue("R");
            }
            if (nuclearBucketCheck[0].Shield == "0")
            {
                sheet1.GetRow(12).GetCell(1).SetCellValue("(" + nuclearBucketCheck[0].ShieldMaterail + ")");
            }
            else
            {
                sheet1.GetRow(12).GetCell(1).SetCellValue("");
            }
            sheet1.GetRow(12).GetCell(6).SetCellValue(nuclearBucketCheck[0].ShieldPlyBottom.ToString());
            sheet1.GetRow(12).GetCell(9).SetCellValue(nuclearBucketCheck[0].Weight.ToString());
            sheet1.GetRow(13).GetCell(6).SetCellValue(nuclearBucketCheck[0].ShieldPlyRound.ToString());
            sheet1.GetRow(13).GetCell(9).SetCellValue(nuclearBucketCheck[0].Weight.ToString());
            sheet1.GetRow(15).GetCell(0).SetCellValue("    " + nuclearBucketCheck[0].Remark);
            sheet1.GetRow(21).GetCell(0).SetCellValue(nuclearBucketCheck[0].CreateUserName);//操作员
            sheet1.GetRow(21).GetCell(2).SetCellValue(nuclearBucketCheck[0].CreateDate.HasValue ? nuclearBucketCheck[0].CreateDate.Value.ToString("yyyy-MM-dd") : string.Empty);//日期
            sheet1.GetRow(21).GetCell(5).SetCellValue(nuclearBucketCheck[0].CheckPersonName);
            sheet1.GetRow(21).GetCell(8).SetCellValue(nuclearBucketCheck[0].CheckDate.HasValue ? nuclearBucketCheck[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
        }
        /// <summary>
        /// 湿混料制备及装通固定
        /// </summary>
        /// <param name="packageCode"></param>
        /// <param name="xssfworkbook"></param>
        public void FixationPrint(string packageCode, XSSFWorkbook xssfworkbook)
        {
            //var bucketCode = "S100002";
            //List<NuclearBucket> NuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).AsQueryable().ToList();
            XSSFSheet sheet2 = (XSSFSheet)xssfworkbook.GetSheet("湿混料制备及装通固定");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
            //求数据
            IQueryable<NuclearWastePackage> nuclearWastePackageQuery = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode).AsQueryable();
            List<NuclearWastePackage> nuclearWastePackage = new List<NuclearWastePackage>();
            List<NuclearFixation> nuclearFixation = new List<NuclearFixation>();
            List<NuclearFixationDetail> nuclearFixationDetail = new List<NuclearFixationDetail>();
            List<BasicObject> basicObject = new List<BasicObject>();
            NuclearBucket nuclearBucket = new NuclearBucket();
            List<MaterialType> materialType = new List<MaterialType>();
            List<MaterialInput> materialInput = new List<MaterialInput>();
            IQueryable<MaterialType> materialTypeQuery = this._MaterialTypeRepository.GetAll().Where(d => d.MaterialName == "水泥").AsQueryable();
            if (materialTypeQuery != null && materialTypeQuery.Count() > 0)
            {
                materialType = materialTypeQuery.ToList();
                IQueryable<MaterialInput> materialInputQuery = this._MaterialInputRepository.GetAll().Where(d => d.MaterialId == materialType[0].MaterialId).AsQueryable().OrderByDescending(d => d.ConfirmDate);
                if (materialInputQuery != null && materialInputQuery.Count() > 0)
                { 
                    materialInput=materialInputQuery.ToList();
                }
            }
            //var listTrack = null;
            if (nuclearWastePackageQuery != null && nuclearWastePackageQuery.Count() > 0)
            {
                nuclearWastePackage = nuclearWastePackageQuery.ToList();
                nuclearBucket = _NuclearBucketRepository.Get(nuclearWastePackage[0].BucketId);//nuclearWastePackage[0].BucketId
                IQueryable<NuclearFixation> nuclearFixationQuery = _NuclearFixationRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();//nuclearWastePackage[0].BucketId
                if (nuclearFixationQuery != null && nuclearFixationQuery.Count() > 0)
                {
                    nuclearFixation = nuclearFixationQuery.ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == nuclearFixation[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<NuclearFixationDetail> nuclearFixationDetailQuery = _NuclearFixationDetailRepository.GetAll().Where(d => d.FixationId == nuclearFixation[0].FixationId).AsQueryable();
                    if (nuclearFixationDetailQuery != null && nuclearFixationDetailQuery.Count() > 0)
                    {
                        nuclearFixationDetail = nuclearFixationDetailQuery.ToList();
                    }
                }
            }
            var trackId = "";
            if (nuclearFixationDetail != null && nuclearFixationDetail.Count() > 0)
            {
                trackId = nuclearFixationDetail[0].TrackId;
            }
            var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == trackId).ToList();
            if (nuclearFixation != null && nuclearFixation.Count() > 0)
            {
                sheet2.GetRow(5).GetCell(1).SetCellValue(nuclearBucket.BucketCode);
                sheet2.GetRow(5).GetCell(8).SetCellValue(nuclearFixation[0].OrderCode);
                sheet2.GetRow(7).GetCell(9).SetCellValue(nuclearFixation[0].Cement.ToString());
                sheet2.GetRow(8).GetCell(9).SetCellValue(nuclearFixation[0].Sand.ToString());
                sheet2.GetRow(9).GetCell(9).SetCellValue(nuclearFixation[0].Meterial.ToString());
                sheet2.GetRow(10).GetCell(9).SetCellValue(nuclearFixation[0].Water.ToString());
                sheet2.GetRow(11).GetCell(9).SetCellValue(nuclearFixation[0].Additive.ToString());
                sheet2.GetRow(12).GetCell(9).SetCellValue(nuclearFixation[0].ShakeTime.ToString());
                if (materialInput != null && materialInput.Count() > 0)
                {
                    sheet2.GetRow(13).GetCell(9).SetCellValue(materialInput[0].EffectDate.HasValue ? materialInput[0].EffectDate.Value.ToString("yyyy") : string.Empty);
                    sheet2.GetRow(13).GetCell(11).SetCellValue(materialInput[0].EffectDate.HasValue ? materialInput[0].EffectDate.Value.ToString("MM") : string.Empty);
                    sheet2.GetRow(13).GetCell(13).SetCellValue(materialInput[0].EffectDate.HasValue ? materialInput[0].EffectDate.Value.ToString("dd") : string.Empty);
                }
                sheet2.GetRow(16).GetCell(0).SetCellValue(nuclearFixation[0].MaterialControlName);
                sheet2.GetRow(16).GetCell(3).SetCellValue(nuclearFixation[0].MaterialControlDate.HasValue ? nuclearFixation[0].MaterialControlDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet2.GetRow(16).GetCell(6).SetCellValue(nuclearFixation[0].MaterialCheckName);
                sheet2.GetRow(16).GetCell(9).SetCellValue(nuclearFixation[0].MaterialCheckDate.HasValue ? nuclearFixation[0].MaterialCheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet2.GetRow(17).GetCell(2).SetCellValue(nuclearFixation[0].WasteSourse);
                sheet2.GetRow(17).GetCell(8).SetCellValue(basicObject[0].Name);
                sheet2.GetRow(18).GetCell(2).SetCellValue(nuclearFixation[0].WastePosition);
                if (listTrack.Count() > 0)
                {
                    sheet2.GetRow(18).GetCell(8).SetCellValue(listTrack[0].TrackCode);
                }
                sheet2.GetRow(20).GetCell(4).SetCellValue(nuclearFixation[0].WaterShakeTime.ToString());
                sheet2.GetRow(21).GetCell(4).SetCellValue(nuclearFixation[0].ReduceTime.ToString());
                sheet2.GetRow(22).GetCell(4).SetCellValue(nuclearFixation[0].MeteringAve.ToString());
                sheet2.GetRow(23).GetCell(4).SetCellValue(nuclearFixation[0].MeteringTop.ToString());
                sheet2.GetRow(24).GetCell(4).SetCellValue(nuclearFixation[0].MeteringMax.ToString());
                sheet2.GetRow(26).GetCell(0).SetCellValue(nuclearFixation[0].ControlPersonName);
                sheet2.GetRow(26).GetCell(3).SetCellValue(nuclearFixation[0].ControlDate.HasValue ? nuclearFixation[0].ControlDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet2.GetRow(26).GetCell(6).SetCellValue(nuclearFixation[0].CheckPersonName);
                sheet2.GetRow(26).GetCell(9).SetCellValue(nuclearFixation[0].CheckDate.HasValue ? nuclearFixation[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
        }
        /// <summary>
        /// 湿混料制备及封盖
        /// </summary>
        /// <param name="packageCode"></param>
        /// <param name="xssfworkbook"></param>
        public void CoverMixPrint(string packageCode, XSSFWorkbook xssfworkbook)
        {
            XSSFSheet sheet3 = (XSSFSheet)xssfworkbook.GetSheet("湿混料制备及封盖");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
            //求数据
            IQueryable<NuclearWastePackage> nuclearWastePackageQuery = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode).AsQueryable();
            List<NuclearWastePackage> nuclearWastePackage = new List<NuclearWastePackage>();
            List<NuclearCoverMix> nuclearCoverMix = new List<NuclearCoverMix>();
            NuclearBucket nuclearBucket = new NuclearBucket();
            List<MaterialType> materialType = new List<MaterialType>();
            List<MaterialInput> materialInput = new List<MaterialInput>();
            IQueryable<MaterialType> materialTypeQuery = this._MaterialTypeRepository.GetAll().Where(d => d.MaterialName == "水泥").AsQueryable();
            if (materialTypeQuery != null && materialTypeQuery.Count() > 0)
            {
                materialType = materialTypeQuery.ToList();
                IQueryable<MaterialInput> materialInputQuery = this._MaterialInputRepository.GetAll().Where(d => d.MaterialId == materialType[0].MaterialId).AsQueryable().OrderByDescending(d => d.ConfirmDate);
                if (materialInputQuery != null && materialInputQuery.Count() > 0)
                {
                    materialInput = materialInputQuery.ToList();
                }
            }
            //var listTrack = null;
            if (nuclearWastePackageQuery != null && nuclearWastePackageQuery.Count() > 0)
            {
                nuclearWastePackage = nuclearWastePackageQuery.ToList();
                nuclearBucket = _NuclearBucketRepository.Get(nuclearWastePackage[0].BucketId);//nuclearWastePackage[0].BucketId
                IQueryable<NuclearCoverMix> nuclearCoverMixQuery = _NuclearCoverMixRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();//nuclearWastePackage[0].BucketId
                if (nuclearCoverMixQuery != null && nuclearCoverMixQuery.Count() > 0)
                {
                    nuclearCoverMix = nuclearCoverMixQuery.ToList();
                }
            }
            if (nuclearCoverMix != null && nuclearCoverMix.Count() > 0)
            {
                sheet3.GetRow(5).GetCell(1).SetCellValue(nuclearBucket.BucketCode);
                sheet3.GetRow(5).GetCell(8).SetCellValue(nuclearCoverMix[0].WorkTicket);
                if (nuclearCoverMix[0].PondingFlag == "1")
                {
                    sheet3.GetRow(7).GetCell(3).SetCellValue("R");
                    sheet3.GetRow(7).GetCell(5).SetCellValue("£");
                }
                else if (nuclearCoverMix[0].PondingFlag == "0")
                {
                    sheet3.GetRow(7).GetCell(3).SetCellValue("£");
                    sheet3.GetRow(7).GetCell(5).SetCellValue("R");
                }
                else {
                    sheet3.GetRow(7).GetCell(3).SetCellValue("£");
                    sheet3.GetRow(7).GetCell(5).SetCellValue("£");
                }
                if (nuclearCoverMix[0].CurdleFlag == "1")
                {
                    sheet3.GetRow(8).GetCell(3).SetCellValue("R");
                    sheet3.GetRow(8).GetCell(5).SetCellValue("£");
                }
                else if (nuclearCoverMix[0].CurdleFlag == "0")
                {
                    sheet3.GetRow(8).GetCell(3).SetCellValue("£");
                    sheet3.GetRow(8).GetCell(5).SetCellValue("R");
                }
                else
                {
                    sheet3.GetRow(8).GetCell(3).SetCellValue("£");
                    sheet3.GetRow(8).GetCell(5).SetCellValue("£");
                }
                if (nuclearCoverMix[0].MaterialFlag == "1")
                {
                    sheet3.GetRow(9).GetCell(3).SetCellValue("£");
                    sheet3.GetRow(9).GetCell(5).SetCellValue("R");
                }
                else if (nuclearCoverMix[0].MaterialFlag == "0")
                {
                    sheet3.GetRow(9).GetCell(3).SetCellValue("R");
                    sheet3.GetRow(9).GetCell(5).SetCellValue("£");
                }
                else
                {
                    sheet3.GetRow(9).GetCell(3).SetCellValue("£");
                    sheet3.GetRow(9).GetCell(5).SetCellValue("£");
                }
                sheet3.GetRow(9).GetCell(8).SetCellValue(nuclearCoverMix[0].Texture);
                sheet3.GetRow(10).GetCell(2).SetCellValue(nuclearCoverMix[0].CurdlePly.ToString());
                sheet3.GetRow(10).GetCell(8).SetCellValue(nuclearCoverMix[0].CurdleWeight.ToString());
                sheet3.GetRow(11).GetCell(2).SetCellValue(nuclearCoverMix[0].OverSpace);
                sheet3.GetRow(17).GetCell(0).SetCellValue(nuclearCoverMix[0].Cement.ToString());
                sheet3.GetRow(17).GetCell(2).SetCellValue(nuclearCoverMix[0].Sand.ToString());
                sheet3.GetRow(17).GetCell(4).SetCellValue(nuclearCoverMix[0].Stone.ToString());
                sheet3.GetRow(17).GetCell(6).SetCellValue(nuclearCoverMix[0].Water.ToString());
                sheet3.GetRow(17).GetCell(8).SetCellValue(nuclearCoverMix[0].Additive.ToString());
                sheet3.GetRow(17).GetCell(10).SetCellValue(nuclearCoverMix[0].ShakeTime.ToString());
               
                sheet3.GetRow(18).GetCell(3).SetCellValue(nuclearCoverMix[0].DoseEva.ToString());
                sheet3.GetRow(19).GetCell(2).SetCellValue(nuclearCoverMix[0].OverHeight.ToString());
                sheet3.GetRow(19).GetCell(9).SetCellValue("X="+nuclearCoverMix[0].PositionX);
                sheet3.GetRow(19).GetCell(10).SetCellValue("Y="+nuclearCoverMix[0].PositionY);
                sheet3.GetRow(19).GetCell(11).SetCellValue("Z="+nuclearCoverMix[0].PositionZ);
                if (materialInput != null && materialInput.Count() > 0)
                {
                    sheet3.GetRow(20).GetCell(2).SetCellValue(materialInput[0].EffectDate.HasValue ? materialInput[0].EffectDate.Value.ToString("yyyy") : string.Empty);
                    sheet3.GetRow(20).GetCell(4).SetCellValue(materialInput[0].EffectDate.HasValue ? materialInput[0].EffectDate.Value.ToString("MM") : string.Empty);
                    sheet3.GetRow(20).GetCell(6).SetCellValue(materialInput[0].EffectDate.HasValue ? materialInput[0].EffectDate.Value.ToString("dd") : string.Empty);
                }
                sheet3.GetRow(22).GetCell(0).SetCellValue("    "+nuclearCoverMix[0].Remark);
                sheet3.GetRow(25).GetCell(0).SetCellValue(nuclearCoverMix[0].ControlName);
                sheet3.GetRow(25).GetCell(3).SetCellValue(nuclearCoverMix[0].ControlDate.HasValue ? nuclearCoverMix[0].ControlDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet3.GetRow(25).GetCell(6).SetCellValue(nuclearCoverMix[0].CheckName);
                sheet3.GetRow(25).GetCell(9).SetCellValue(nuclearCoverMix[0].CheckDate.HasValue ? nuclearCoverMix[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
        }
        /// <summary>
        /// 废物货包转运及QT贮存
        /// </summary>
        /// <param name="packageCode"></param>
        /// <param name="xssfworkbook"></param>
        public void QTTransPrint(string packageCode, XSSFWorkbook xssfworkbook)
        {
            //var bucketCode = "swq012";
            //List<NuclearBucket> NuclearBucket = this._NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).ToList();
            XSSFSheet sheet4 = (XSSFSheet)xssfworkbook.GetSheet("废物货包转运及QT贮存");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
            //求数据
            IQueryable<NuclearWastePackage> nuclearWastePackageQuery = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode).AsQueryable();
            List<NuclearWastePackage> nuclearWastePackage = new List<NuclearWastePackage>();
            List<NuclearQtTrans> nuclearQtTrans = new List<NuclearQtTrans>();
            List<NuclearQtTransDetail> nuclearQtTransDetail = new List<NuclearQtTransDetail>();
            List<NuclearQtTransDetailB> nuclearQtTransDetailB = new List<NuclearQtTransDetailB>();
            NuclearBucket nuclearBucket = new NuclearBucket();
            List<ActivityCount> activityList = new List<ActivityCount>();
            List<NuclearCoverMix> nuclearCoverMix = new List<NuclearCoverMix>();
            if (nuclearWastePackageQuery != null && nuclearWastePackageQuery.Count() > 0)
            {
                nuclearWastePackage = nuclearWastePackageQuery.ToList();
                nuclearBucket = _NuclearBucketRepository.Get(nuclearWastePackage[0].BucketId);//nuclearWastePackage[0].BucketId
                IQueryable<NuclearCoverMix> nuclearCoverMixQuery = _NuclearCoverMixRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();//nuclearWastePackage[0].BucketId
                if (nuclearCoverMixQuery != null && nuclearCoverMixQuery.Count() > 0)
                {
                    nuclearCoverMix = nuclearCoverMixQuery.ToList();
                }
                ActivityCountCondition activityCountCondition = new ActivityCountCondition();
                activityCountCondition.BucketCode = nuclearBucket.BucketCode;
                IQueryable<ActivityCount> activityCountList = ActivityCountBuilder.BuilderActivityCountInfo(activityCountCondition);
                if (activityCountList != null && activityCountList.Count() > 0)
                {
                    activityList = activityCountList.ToList();
                }
                IQueryable<NuclearQtTrans> nuclearQtTransQuery = _NuclearQtTransRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();//nuclearWastePackage[0].BucketId
                if (nuclearQtTransQuery != null && nuclearQtTransQuery.Count() > 0)
                {
                    nuclearQtTrans = nuclearQtTransQuery.ToList();
                    IQueryable<NuclearQtTransDetail> nuclearQtTransDetailQuery = _NuclearQtTransRepository.GetDetailById(nuclearQtTrans[0].QtTransId);
                    if (nuclearQtTransDetailQuery != null && nuclearQtTransDetailQuery.Count() > 0)
                    {
                        nuclearQtTransDetail = nuclearQtTransDetailQuery.ToList();
                    }
                    IQueryable<NuclearQtTransDetailB> nuclearQtTransDetailBQuery = _NuclearQtTransRepository.GetDetailBById(nuclearQtTrans[0].QtTransId);
                    if (nuclearQtTransDetailBQuery != null && nuclearQtTransDetailBQuery.Count() > 0)
                    {
                        nuclearQtTransDetailB = nuclearQtTransDetailBQuery.ToList();
                    }
                }
            }
            if (nuclearQtTrans != null && nuclearQtTrans.Count() > 0)
            {
                sheet4.GetRow(5).GetCell(1).SetCellValue(nuclearBucket.BucketCode);
                sheet4.GetRow(5).GetCell(7).SetCellValue(nuclearQtTrans[0].TicketCode);
                if (nuclearQtTransDetail != null && nuclearQtTransDetail.Count() > 0)
                {
                    sheet4.GetRow(8).GetCell(2).SetCellValue(nuclearQtTransDetail[0].FixationDate.HasValue ? nuclearQtTransDetail[0].FixationDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                    sheet4.GetRow(8).GetCell(8).SetCellValue(nuclearQtTransDetail[0].TransDate.HasValue ? nuclearQtTransDetail[0].TransDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                    sheet4.GetRow(10).GetCell(3).SetCellValue(nuclearQtTransDetail[0].ProcessName);
                }
                sheet4.GetRow(10).GetCell(9).SetCellValue(nuclearQtTrans[0].ConfirmDate.HasValue ? nuclearQtTrans[0].ConfirmDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                if (nuclearCoverMix != null && nuclearCoverMix.Count() > 0)
                {
                    sheet4.GetRow(13).GetCell(1).SetCellValue("X=" + nuclearCoverMix[0].PositionX);//QS位置
                    sheet4.GetRow(13).GetCell(2).SetCellValue("Y=" + nuclearCoverMix[0].PositionY);
                    sheet4.GetRow(13).GetCell(3).SetCellValue("Z=" + nuclearCoverMix[0].PositionZ);
                }
                if (nuclearQtTransDetailB != null && nuclearQtTransDetailB.Count() > 0)
                {
                    sheet4.GetRow(13).GetCell(8).SetCellValue(nuclearQtTransDetailB[0].TransDate.HasValue ? nuclearQtTransDetailB[0].TransDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                }
                if (nuclearQtTrans[0].CurdleFlag == "0")
                {
                    sheet4.GetRow(15).GetCell(3).SetCellValue("R");
                    sheet4.GetRow(15).GetCell(5).SetCellValue("£");
                }
                else if (nuclearQtTrans[0].CurdleFlag == "1")
                {
                    sheet4.GetRow(15).GetCell(3).SetCellValue("£");
                    sheet4.GetRow(15).GetCell(5).SetCellValue("R");
                }
                else
                {
                    sheet4.GetRow(15).GetCell(3).SetCellValue("£");
                    sheet4.GetRow(15).GetCell(5).SetCellValue("£");
                }
                if (nuclearQtTrans[0].WaterLeaveFlag == "1")
                {
                    sheet4.GetRow(16).GetCell(3).SetCellValue("R");
                    sheet4.GetRow(16).GetCell(5).SetCellValue("£");
                }
                else if (nuclearQtTrans[0].WaterLeaveFlag == "0")
                {
                    sheet4.GetRow(16).GetCell(3).SetCellValue("£");
                    sheet4.GetRow(16).GetCell(5).SetCellValue("R");
                }
                else
                {
                    sheet4.GetRow(16).GetCell(3).SetCellValue("£");
                    sheet4.GetRow(16).GetCell(5).SetCellValue("£");
                }
                if (nuclearQtTrans[0].FlawFlag == "1")
                {
                    sheet4.GetRow(17).GetCell(3).SetCellValue("R");
                    sheet4.GetRow(17).GetCell(5).SetCellValue("£");
                }
                else if (nuclearQtTrans[0].FlawFlag == "0")
                {
                    sheet4.GetRow(17).GetCell(3).SetCellValue("£");
                    sheet4.GetRow(17).GetCell(5).SetCellValue("R");
                }
                else
                {
                    sheet4.GetRow(17).GetCell(3).SetCellValue("£");
                    sheet4.GetRow(17).GetCell(5).SetCellValue("£");
                }
                if (nuclearQtTrans[0].SullyFlag == "1")
                {
                    sheet4.GetRow(18).GetCell(3).SetCellValue("R");
                    sheet4.GetRow(18).GetCell(5).SetCellValue("£");
                }
                else if (nuclearQtTrans[0].SullyFlag == "0")
                {
                    sheet4.GetRow(18).GetCell(3).SetCellValue("£");
                    sheet4.GetRow(18).GetCell(5).SetCellValue("R");
                }
                else
                {
                    sheet4.GetRow(18).GetCell(3).SetCellValue("£");
                    sheet4.GetRow(18).GetCell(5).SetCellValue("£");
                }
                sheet4.GetRow(18).GetCell(7).SetCellValue(nuclearQtTrans[0].SullyCaseA);
                sheet4.GetRow(19).GetCell(7).SetCellValue(nuclearQtTrans[0].SullyCaseB);
                sheet4.GetRow(20).GetCell(3).SetCellValue(Convert.ToString(nuclearQtTrans[0].DoseMeter));
                if (nuclearQtTrans[0].RubbishFlag == "0")
                {
                    sheet4.GetRow(21).GetCell(3).SetCellValue("R");
                    sheet4.GetRow(21).GetCell(5).SetCellValue("£");
                }
                else if (nuclearQtTrans[0].RubbishFlag == "1")
                {
                    sheet4.GetRow(21).GetCell(3).SetCellValue("£");
                    sheet4.GetRow(21).GetCell(5).SetCellValue("R");
                }
                else
                {
                    sheet4.GetRow(21).GetCell(3).SetCellValue("£");
                    sheet4.GetRow(21).GetCell(5).SetCellValue("£");
                }
                sheet4.GetRow(21).GetCell(8).SetCellValue(nuclearQtTrans[0].BucketWeight.ToString());
                sheet4.GetRow(22).GetCell(1).SetCellValue("X="+nuclearQtTrans[0].QtPositionX);
                sheet4.GetRow(22).GetCell(2).SetCellValue("Y="+nuclearQtTrans[0].QtPositionY);
                sheet4.GetRow(22).GetCell(3).SetCellValue("Z="+nuclearQtTrans[0].QtPositionZ);
                if (activityList != null && activityList.Count() > 0)
                {
                    sheet4.GetRow(22).GetCell(5).SetCellValue(activityList[0].ElemAnalysisId);
                }
                sheet4.GetRow(22).GetCell(8).SetCellValue(nuclearQtTrans[0].Activity.ToString());
                sheet4.GetRow(24).GetCell(0).SetCellValue("    "+nuclearQtTrans[0].Remark);
                sheet4.GetRow(30).GetCell(3).SetCellValue(nuclearQtTrans[0].ProcessName);
                sheet4.GetRow(30).GetCell(9).SetCellValue(nuclearQtTrans[0].ProcessDate.HasValue ? nuclearQtTrans[0].ProcessDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
        }
        ///// <summary>
        ///// 废物货包在QT贮存后的移动
        ///// </summary>
        ///// <param name="packageCode"></param>
        ///// <param name="xssfworkbook"></param>
        //public void QTSaveMovePrint(string packageCode, XSSFWorkbook xssfworkbook)
        //{
           
        //    XSSFSheet sheet5 = (XSSFSheet)xssfworkbook.GetSheet("废物货包在QT贮存后的移动");
        //    XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
        //    cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
        //    cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
        //    //求数据
            
        //    sheet5.GetRow(5).GetCell(1).SetCellValue("");
        //    sheet5.GetRow(5).GetCell(7).SetCellValue("");

        //    sheet5.GetRow(7).GetCell(0).SetCellValue("");

        //    sheet5.GetRow(14).GetCell(7).SetCellValue("");
        //    sheet5.GetRow(15).GetCell(7).SetCellValue("");

        //    sheet5.GetRow(16).GetCell(7).SetCellValue("");
        //    sheet5.GetRow(16).GetCell(9).SetCellValue("");

        //    sheet5.GetRow(16).GetCell(11).SetCellValue("");

        //    sheet5.GetRow(26).GetCell(0).SetCellValue("");
        //    sheet5.GetRow(26).GetCell(3).SetCellValue("");
        //    sheet5.GetRow(26).GetCell(6).SetCellValue("");
        //    sheet5.GetRow(26).GetCell(9).SetCellValue("");
        //}
        /// <summary>
        /// 循环水过滤器废物跟踪单
        /// </summary>
        /// <param name="packageCode"></param>
        /// <param name="xssfworkbook"></param>
        public void CirculWaterFilterPrint(string packageCode, XSSFWorkbook xssfworkbook)
        {
            XSSFSheet sheet6 = (XSSFSheet)xssfworkbook.GetSheet("循环水过滤器废物跟踪单");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
            //求数据
            IQueryable<NuclearWastePackage> nuclearWastePackageQuery = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode).AsQueryable();
            List<NuclearWastePackage> nuclearWastePackage = new List<NuclearWastePackage>();
            if (nuclearWastePackageQuery != null && nuclearWastePackageQuery.Count() > 0)
            {
                nuclearWastePackage = nuclearWastePackageQuery.ToList();
            }
            List<NuclearTrackElement> list = new List<NuclearTrackElement>();
            List<BasicObject> basicObject = new List<BasicObject>();
            List<NuclearBucket> nuclearBucket = new List<NuclearBucket>();
            List<NuclearBucket> nuclearBuckets = new List<NuclearBucket>();
            //var trackCode = "20161209";//此处需要根据nuclearWastePackage[0].BucketId联合固定和固化表单查询出废物跟踪单号
            List<NuclearFixation> nuclearFixation = new List<NuclearFixation>();
            List<NuclearBucketSolution> nuclearBucketSolution = new List<NuclearBucketSolution>();
            List<NuclearBucketSSolidify> nuclearBucketSSolidify = new List<NuclearBucketSSolidify>();
            List<NuclearBucketResin> nuclearBucketResin = new List<NuclearBucketResin>();
            List<NuclearBucketRSolidify> nuclearBucketRSolidify = new List<NuclearBucketRSolidify>();
            List<NuclearFixationDetail> nuclearFixationDetail = new List<NuclearFixationDetail>();
            IQueryable<NuclearFixation> nuclearFixationQuery = _NuclearFixationRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();//nuclearWastePackage[0].BucketId
            IQueryable<NuclearBucketSolution> nuclearBucketSolutionQuery = _NuclearBucketSolutionRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();//nuclearWastePackage[0].BucketId
            IQueryable<NuclearBucketSSolidify> nuclearBucketSSolidifyQuery = _NuclearBucketSSolidifyRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();//nuclearWastePackage[0].BucketId
            IQueryable<NuclearBucketResin> nuclearBucketResinQuery = _NuclearBucketResinRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();//nuclearWastePackage[0].BucketId
            IQueryable<NuclearBucketRSolidify> nuclearBucketRSolidifyQuery = _NuclearBucketRSolidifyRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();//nuclearWastePackage[0].BucketId           
            if (nuclearBucketSolutionQuery != null && nuclearBucketSolutionQuery.Count() > 0)
            {
                nuclearBucketSolution = nuclearBucketSolutionQuery.ToList();
            }
            if (nuclearBucketSSolidifyQuery != null && nuclearBucketSSolidifyQuery.Count() > 0)
            {
                nuclearBucketSSolidify = nuclearBucketSSolidifyQuery.ToList();
            }
            if (nuclearBucketResinQuery != null && nuclearBucketResinQuery.Count() > 0)
            {
                nuclearBucketResin = nuclearBucketResinQuery.ToList();
            }
            if (nuclearBucketRSolidifyQuery != null && nuclearBucketRSolidifyQuery.Count() > 0)
            {
                nuclearBucketRSolidify = nuclearBucketRSolidifyQuery.ToList();
            }
            if (nuclearFixationQuery != null && nuclearFixationQuery.Count() > 0)
            {
                nuclearFixation = nuclearFixationQuery.ToList();
                IQueryable<NuclearFixationDetail> nuclearFixationDetailQuery = _NuclearFixationDetailRepository.GetAll().Where(d => d.FixationId == nuclearFixation[0].FixationId).AsQueryable();
                if (nuclearFixationDetailQuery != null && nuclearFixationDetailQuery.Count() > 0)
                {
                    nuclearFixationDetail = nuclearFixationDetailQuery.ToList();
                }
            }
            var trackId = "";
            if (nuclearBucketSolution != null && nuclearBucketSolution.Count() > 0)
            {
                trackId = nuclearBucketSolution[0].TrackId;
            }
            else if (nuclearBucketSSolidify != null && nuclearBucketSSolidify.Count() > 0)
            {
                trackId = nuclearBucketSSolidify[0].TrackId;
            }
            else if (nuclearBucketResin != null && nuclearBucketResin.Count() > 0)
            {
                trackId = nuclearBucketResin[0].TrackId;
            }
            else if (nuclearBucketRSolidify != null && nuclearBucketRSolidify.Count() > 0)
            {
                trackId = nuclearBucketRSolidify[0].TrackId;
            }
            else if (nuclearFixationDetail != null && nuclearFixationDetail.Count() > 0)
            {
                trackId = nuclearFixationDetail[0].TrackId;              
            }
            var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == trackId).ToList();
            if (listTrack != null && listTrack.Count() > 0)
            {
                IQueryable<NuclearTrackElement> nuclearTrackElement = this._NuclearTrackElementRepository.GetAll().Where(d => d.ElementCode == listTrack[0].TrackCode).AsQueryable();
                if (nuclearTrackElement != null && nuclearTrackElement.Count() > 0)
                {
                    list = nuclearTrackElement.ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == list[0].FactoryPositionId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<NuclearBucket> nuclearBucketQuery = _NuclearBucketRepository.GetAll().Where(d => d.BucketId == list[0].ContainerId).AsQueryable();
                    if (nuclearBucketQuery != null && nuclearBucketQuery.Count() > 0)
                    {
                        nuclearBucket = nuclearBucketQuery.ToList();
                    }
                    IQueryable<NuclearBucket> nuclearBucketsQuery = _NuclearBucketRepository.GetAll().Where(d => d.BucketId == list[0].InputContainerId).AsQueryable();
                    if (nuclearBucketsQuery != null && nuclearBucketsQuery.Count() > 0)
                    {
                        nuclearBuckets = nuclearBucketsQuery.ToList();
                    }
                }
            }
            //var bucketCode = "S100002";
            //List<NuclearBucket> NuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).AsQueryable().ToList();
            NuclearNuclide nuclearNuclide = new NuclearNuclide();
            List<NuclearNuclideSample> nuclearNuclideSample = new List<NuclearNuclideSample>();
            IQueryable<NuclearNuclideSample> nuclearNuclideSampleQuery = _NuclearNuclideSampleRepository.GetAll().Where(d => d.SampleNum == nuclearWastePackage[0].BucketId).AsQueryable();//nuclearWastePackage[0].BucketId           
            if (nuclearNuclideSampleQuery != null && nuclearNuclideSampleQuery.Count() > 0)
            {
                nuclearNuclideSample = nuclearNuclideSampleQuery.ToList();
                nuclearNuclide = _NuclearNuclideRepository.Get(nuclearNuclideSample[0].NuclideId);
                if (nuclearNuclide != null)
                {
                    nuclearNuclide.EdsId = _SupportEdsRepository.GetCodeById(nuclearNuclide.EdsId, AppContext.CurrentUser.ProjectCode);
                }
            }
            if (list.Count() > 0)
            {
                sheet6.GetRow(3).GetCell(8).SetCellValue(list[0].ElementCode);
                sheet6.GetRow(4).GetCell(2).SetCellValue(list[0].SystemCode);
                sheet6.GetRow(4).GetCell(8).SetCellValue(list[0].WorkTicket);

                sheet6.GetRow(5).GetCell(3).SetCellValue(list[0].FilterStopDate.HasValue ? list[0].FilterStopDate.Value.ToString("yyyy-MM-dd") : string.Empty);

                sheet6.GetRow(6).GetCell(2).SetCellValue(list[0].ProcessName);
                sheet6.GetRow(6).GetCell(6).SetCellValue(list[0].ProcessDate.HasValue ? list[0].ProcessDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet6.GetRow(6).GetCell(9).SetCellValue(list[0].ProcessName);
                if (list[0].FilterFlag == "0")
                {
                    sheet6.GetRow(7).GetCell(3).SetCellValue("R");
                    sheet6.GetRow(7).GetCell(7).SetCellValue("£");
                }
                else {
                    sheet6.GetRow(7).GetCell(3).SetCellValue("£");
                    sheet6.GetRow(7).GetCell(7).SetCellValue("R");
                }
                sheet6.GetRow(7).GetCell(10).SetCellValue(list[0].SurfaceTouch.ToString());

                sheet6.GetRow(8).GetCell(2).SetCellValue(list[0].MeasureName);
                sheet6.GetRow(8).GetCell(6).SetCellValue(list[0].MeasureDate.HasValue ? list[0].MeasureDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet6.GetRow(8).GetCell(9).SetCellValue(list[0].MeasureName);

                sheet6.GetRow(9).GetCell(3).SetCellValue(list[0].ElementVersionOld);
                if (nuclearNuclide != null)
                {
                    sheet6.GetRow(9).GetCell(8).SetCellValue(nuclearNuclide.EdsId);//能谱号
                }
                if (basicObject.Count() > 0)
                {
                    sheet6.GetRow(10).GetCell(5).SetCellValue(basicObject[0].Name);
                }
                sheet6.GetRow(10).GetCell(8).SetCellValue(list[0].ControlName);
                sheet6.GetRow(10).GetCell(10).SetCellValue(list[0].ControlDate.HasValue ? list[0].ControlDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                if (nuclearBucket.Count() > 0)
                {
                    sheet6.GetRow(11).GetCell(5).SetCellValue(nuclearBucket[0].BucketCode);
                }
                sheet6.GetRow(11).GetCell(8).SetCellValue(list[0].ContainerControlName);
                sheet6.GetRow(11).GetCell(10).SetCellValue(list[0].ContainerControlDate.HasValue ? list[0].ContainerControlDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                if (nuclearBuckets.Count() > 0)
                {
                    sheet6.GetRow(12).GetCell(5).SetCellValue(nuclearBuckets[0].BucketCode);
                }
                sheet6.GetRow(12).GetCell(8).SetCellValue(list[0].InputContainerControlName);
                sheet6.GetRow(12).GetCell(10).SetCellValue(list[0].InputContainerControlDate.HasValue ? list[0].InputContainerControlDate.Value.ToString("yyyy-MM-dd") : string.Empty);

                sheet6.GetRow(13).GetCell(5).SetCellValue(list[0].LeadSurface.ToString());

                sheet6.GetRow(14).GetCell(1).SetCellValue("    "+list[0].Remark);

                sheet6.GetRow(22).GetCell(2).SetCellValue("");//检查人
                sheet6.GetRow(22).GetCell(6).SetCellValue("");//日期
                sheet6.GetRow(22).GetCell(9).SetCellValue("");//签字

                sheet6.GetRow(23).GetCell(3).SetCellValue(list[0].StatisticsName);
                sheet6.GetRow(23).GetCell(6).SetCellValue(list[0].StatisticsDate.HasValue ? list[0].StatisticsDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet6.GetRow(23).GetCell(9).SetCellValue(list[0].StatisticsName);
            }
        }
        /// <summary>
        /// 活度计算单
        /// </summary>
        /// <param name="packageCode"></param>
        /// <param name="xssfworkbook"></param>
        public void ActivityPrint(string packageCode, XSSFWorkbook xssfworkbook)
        {
            //var bucketCode = "K121238";
            //List<NuclearBucket> NuclearBucket = this._NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).ToList();
            XSSFSheet sheet7 = (XSSFSheet)xssfworkbook.GetSheet("活度计算单");
            XSSFCellStyle cellstyle = (XSSFCellStyle)xssfworkbook.CreateCellStyle();
            cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;
            CommonHelper commonHelper = new CommonHelper();
            #region 求数据
            IQueryable<NuclearWastePackage> nuclearWastePackageQuery = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode).AsQueryable();
            List<NuclearWastePackage> nuclearWastePackage = new List<NuclearWastePackage>();
            NuclearBucket nuclearBucket = new NuclearBucket();
            List<BasicObject> basicObject = new List<BasicObject>();
            List<SupportEds> supportEds = new List<SupportEds>();
            List<ActivityBucket> activityBucket = new List<ActivityBucket>();
            ActivityBucketDetail activityBucketDetail = new ActivityBucketDetail();
            List<ActivityBucketDetail> activityBucketDetailList = new List<ActivityBucketDetail>();
            List<ActivityCementLiquid> activityCementLiquid = new List<ActivityCementLiquid>();
            List<ActivityCliquidDetail> activityCliquidDetailList = new List<ActivityCliquidDetail>();
            List<ActivityCfilter> activityCfilter = new List<ActivityCfilter>();
            List<ActivityCfilterDetail> activityCfilterDetailList = new List<ActivityCfilterDetail>();
            List<ActivityCore> activityCore = new List<ActivityCore>();
            List<ActivityCoreDetail> activityCoreDetailList = new List<ActivityCoreDetail>();
            List<ActivityCresin> activityCresin = new List<ActivityCresin>();
            List<ActivityCresinDetail> activityCresinDetailList = new List<ActivityCresinDetail>();
            List<ActivityHlevel> activityHlevel = new List<ActivityHlevel>();
            List<ActivityHlevelDetail> activityHlevelDetailList = new List<ActivityHlevelDetail>();
            List<ActivityMfilter> activityMfilter = new List<ActivityMfilter>();
            List<ActivityMfilterDetail> activityMfilterDetailList = new List<ActivityMfilterDetail>();
            List<ActivityMliquid> activityMliquid = new List<ActivityMliquid>();
            List<ActivityMliquidDetail> activityMliquidDetailList = new List<ActivityMliquidDetail>();
            List<ActivityMresin> activityMresin = new List<ActivityMresin>();
            List<ActivityMresinDetail> activityMresinDetailList = new List<ActivityMresinDetail>();
            List<ActivityOpBucket> activityOpBucket = new List<ActivityOpBucket>();
            List<ActivityOpBucketDetail> activityOpBucketDetailList = new List<ActivityOpBucketDetail>();
            if (nuclearWastePackageQuery != null && nuclearWastePackageQuery.Count() > 0)
            {
                nuclearWastePackage = nuclearWastePackageQuery.ToList();
                nuclearBucket = _NuclearBucketRepository.Get(nuclearWastePackage[0].BucketId);//nuclearWastePackage[0].BucketId
                //200L废物桶
                IQueryable<ActivityBucket> activityBuckets = _ActivityBucketRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                //C1浓缩液
                IQueryable<ActivityCementLiquid> activityCementLiquids = _ActivityCementliquidRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                //C4过滤
                IQueryable<ActivityCfilter> activityCfilters = _ActivityCfilterRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                //多芯桶
                IQueryable<ActivityCore> activityCores = _ActivityCoreRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                //C1树脂
                IQueryable<ActivityCresin> activityCresins = _ActivityCresinRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                //高放废物
                IQueryable<ActivityHlevel> activityHlevels = _ActivityHlevelRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                //400L过滤器
                IQueryable<ActivityMfilter> activityMfilters = _ActivityMfilterRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                //400L浓缩液
                IQueryable<ActivityMliquid> activityMliquids = _ActivityMliquidRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                //400L废树脂
                IQueryable<ActivityMresin> activityMresins = _ActivityMresinRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                //400L超压桶
                IQueryable<ActivityOpBucket> activityOpBuckets = _ActivityOpBucketRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage[0].BucketId).AsQueryable();
                if (activityBuckets != null && activityBuckets.Count()>0)
                {
                    activityBucket = activityBuckets.ToList();
                    activityBucketDetailList = _ActivityBucketDetailRepository.GetAll().Where(d => d.CalcuLd == activityBucket[0].CalcuId).AsQueryable().ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == activityBucket[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<SupportEds> supportEdsQuery = _SupportEdsRepository.GetAll().Where(d => d.EdsId == activityBucket[0].ElemAnalysisId).AsQueryable();
                    if (supportEdsQuery != null && supportEdsQuery.Count() > 0)
                    {
                        supportEds = supportEdsQuery.ToList();
                    }
                }
                else if (activityCementLiquids != null && activityCementLiquids.Count()>0)
                {
                    activityCementLiquid = activityCementLiquids.ToList();
                    activityCliquidDetailList = _ActivityCliquidDetailRepository.GetAll().Where(d => d.CalcuLd == activityCementLiquid[0].CalcuId).AsQueryable().ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == activityCementLiquid[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<SupportEds> supportEdsQuery = _SupportEdsRepository.GetAll().Where(d => d.EdsId == activityCementLiquid[0].ElemAnalysisId).AsQueryable();
                    if (supportEdsQuery != null && supportEdsQuery.Count() > 0)
                    {
                        supportEds = supportEdsQuery.ToList();
                    }
                }
                else if (activityCfilters != null && activityCfilters.Count() > 0)
                {
                    activityCfilter = activityCfilters.ToList();
                    activityCfilterDetailList = _ActivityCfilterDetailRepository.GetAll().Where(d => d.CalcuLd == activityCfilter[0].CalcuId).AsQueryable().ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == activityCfilter[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<SupportEds> supportEdsQuery = _SupportEdsRepository.GetAll().Where(d => d.EdsId == activityCfilter[0].ElemAnalysisId).AsQueryable();
                    if (supportEdsQuery != null && supportEdsQuery.Count() > 0)
                    {
                        supportEds = supportEdsQuery.ToList();
                    }
                }
                else if (activityCores != null && activityCores.Count() > 0)
                {
                    activityCore = activityCores.ToList();
                    activityCoreDetailList = _ActivityCoreDetailRepository.GetAll().Where(d => d.CalcuLd == activityCore[0].CalcuId).AsQueryable().ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == activityCore[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<SupportEds> supportEdsQuery = _SupportEdsRepository.GetAll().Where(d => d.EdsId == activityCore[0].ElemAnalysisId).AsQueryable();
                    if (supportEdsQuery != null && supportEdsQuery.Count() > 0)
                    {
                        supportEds = supportEdsQuery.ToList();
                    }
                }
                else if (activityCresins != null && activityCresins.Count() > 0)
                {
                    activityCresin = activityCresins.ToList();
                    activityCresinDetailList = _ActivityCresinDetailRepository.GetAll().Where(d => d.CalcuLd == activityCresin[0].CalcuId).AsQueryable().ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == activityCresin[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<SupportEds> supportEdsQuery = _SupportEdsRepository.GetAll().Where(d => d.EdsId == activityCresin[0].ElemAnalysisId).AsQueryable();
                    if (supportEdsQuery != null && supportEdsQuery.Count() > 0)
                    {
                        supportEds = supportEdsQuery.ToList();
                    }
                }
                else if (activityHlevels != null && activityHlevels.Count() > 0)
                {
                    activityHlevel = activityHlevels.ToList();
                    activityHlevelDetailList = _ActivityHlevelDetailRepository.GetAll().Where(d => d.CalcuLd == activityHlevel[0].CalcuId).AsQueryable().ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == activityHlevel[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<SupportEds> supportEdsQuery = _SupportEdsRepository.GetAll().Where(d => d.EdsId == activityHlevel[0].ElemAnalysisId).AsQueryable();
                    if (supportEdsQuery != null && supportEdsQuery.Count() > 0)
                    {
                        supportEds = supportEdsQuery.ToList();
                    }
                }
                else if (activityMfilters != null && activityMfilters.Count() > 0)
                {
                    activityMfilter = activityMfilters.ToList();
                    activityMfilterDetailList = _ActivityMfilterDetailRepository.GetAll().Where(d => d.CalcuLd == activityMfilter[0].CalcuId).AsQueryable().ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == activityMfilter[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<SupportEds> supportEdsQuery = _SupportEdsRepository.GetAll().Where(d => d.EdsId == activityMfilter[0].ElemAnalysisId).AsQueryable();
                    if (supportEdsQuery != null && supportEdsQuery.Count() > 0)
                    {
                        supportEds = supportEdsQuery.ToList();
                    }
                }
                else if (activityMliquids != null && activityMliquids.Count() > 0)
                {
                    activityMliquid = activityMliquids.ToList();
                    activityMliquidDetailList = _ActivityMliquidDetailRepository.GetAll().Where(d => d.CalcuLd == activityMliquid[0].CalcuId).AsQueryable().ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == activityMliquid[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<SupportEds> supportEdsQuery = _SupportEdsRepository.GetAll().Where(d => d.EdsId == activityMliquid[0].ElemAnalysisId).AsQueryable();
                    if (supportEdsQuery != null && supportEdsQuery.Count() > 0)
                    {
                        supportEds = supportEdsQuery.ToList();
                    }
                }
                else if (activityMresins != null && activityMresins.Count() > 0)
                {
                    activityMresin = activityMresins.ToList();
                    activityMresinDetailList = _ActivityMresinDetailRepository.GetAll().Where(d => d.CalcuLd == activityMresin[0].CalcuId).AsQueryable().ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == activityMresin[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<SupportEds> supportEdsQuery = _SupportEdsRepository.GetAll().Where(d => d.EdsId == activityMresin[0].ElemAnalysisId).AsQueryable();
                    if (supportEdsQuery != null && supportEdsQuery.Count() > 0)
                    {
                        supportEds = supportEdsQuery.ToList();
                    }
                }
                else if (activityOpBuckets != null && activityOpBuckets.Count() > 0)
                {
                    activityOpBucket = activityOpBuckets.ToList();
                    activityOpBucketDetailList = _ActivityOpBucketDetailRepository.GetAll().Where(d => d.CalcuId == activityOpBucket[0].CalcuId).AsQueryable().ToList();
                    IQueryable<BasicObject> basicObjectQuery = _BasicObjectRepository.GetAll().Where(d => d.Uuid == activityOpBucket[0].WasteTypeId).AsQueryable();
                    if (basicObjectQuery != null && basicObjectQuery.Count() > 0)
                    {
                        basicObject = basicObjectQuery.ToList();
                    }
                    IQueryable<SupportEds> supportEdsQuery = _SupportEdsRepository.GetAll().Where(d => d.EdsId == activityOpBucket[0].ElemAnalysisId).AsQueryable();
                    if (supportEdsQuery != null && supportEdsQuery.Count() > 0)
                    {
                        supportEds = supportEdsQuery.ToList();
                    }
                }
            }
            #endregion
            #region 200L废物桶
            if (activityBucket != null && activityBucket.Count()>0)
            {
                sheet7.GetRow(4).GetCell(2).SetCellValue(nuclearBucket.BucketCode);
                sheet7.GetRow(4).GetCell(7).SetCellValue(activityBucket[0].EffcetDate.HasValue ? activityBucket[0].EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(5).GetCell(2).SetCellValue(basicObject[0].Name);
                sheet7.GetRow(6).GetCell(2).SetCellValue(supportEds[0].EdsSerialCode);
                sheet7.GetRow(7).GetCell(2).SetCellValue(activityBucket[0].AvgDoseRate.ToString());
                sheet7.GetRow(7).GetCell(7).SetCellValue(activityBucket[0].TransferFun.ToString());
                int num = 0;
                num = activityBucketDetailList.Count();
                NPOIHelper.CopyRow(sheet7, 11, 11, num);
                for (int i = 0; i < num; i++)
                {
                    NuclearElement nuclearElement = _NuclearElementRepository.Get(activityBucketDetailList[i].ElementId);
                    sheet7.GetRow(11 + i).GetCell(0).SetCellValue(nuclearElement.ElementName);
                    sheet7.GetRow(11 + i).GetCell(2).SetCellValue(activityBucketDetailList[i].HalfLife.ToString());
                    sheet7.GetRow(11 + i).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityBucketDetailList[i].CalcuLevel)));
                    sheet7.GetRow(11 + i).GetCell(6).SetCellValue(activityBucketDetailList[i].CalcuLevelRate.ToString());
                    sheet7.GetRow(11 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityBucketDetailList[i].ElementLevel)));
                }
                sheet7.GetRow(12 + num).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityBucketDetailList.Sum(d => d.CalcuLevel))));
                sheet7.GetRow(12 + num).GetCell(6).SetCellValue(activityBucketDetailList.Sum(d => d.CalcuLevelRate).ToString());
                sheet7.GetRow(14 + num).GetCell(4).SetCellValue((activityBucket[0].AvgDoseRate * activityBucket[0].TransferFun).ToString());
                sheet7.GetRow(15 + num).GetCell(4).SetCellValue((activityBucket[0].AvgDoseRate * activityBucket[0].TransferFun).ToString());
                sheet7.GetRow(16 + num).GetCell(4).SetCellValue(activityBucketDetailList.Sum(e => e.ElementLevel).ToString());
                sheet7.GetRow(18 + num).GetCell(3).SetCellValue(activityBucket[0].TransferFun.ToString());
                sheet7.GetRow(19 + num).GetCell(0).SetCellValue("    " + activityBucket[0].Remark);
                sheet7.GetRow(26 + num).GetCell(1).SetCellValue(activityBucket[0].ReportName);
                sheet7.GetRow(27 + num).GetCell(1).SetCellValue(activityBucket[0].RepostDate.HasValue ? activityBucket[0].RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(26 + num).GetCell(6).SetCellValue(activityBucket[0].CheckName);
                sheet7.GetRow(27 + num).GetCell(6).SetCellValue(activityBucket[0].CheckDate.HasValue ? activityBucket[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
            #endregion
            #region C1浓缩液
            if (activityCementLiquid != null && activityCementLiquid.Count()>0)
            {
                sheet7.GetRow(4).GetCell(2).SetCellValue(nuclearBucket.BucketCode);
                sheet7.GetRow(4).GetCell(7).SetCellValue("");
                sheet7.GetRow(5).GetCell(2).SetCellValue(basicObject[0].Name);
                sheet7.GetRow(6).GetCell(2).SetCellValue(supportEds[0].EdsSerialCode);
                sheet7.GetRow(7).GetCell(2).SetCellValue(activityCliquidDetailList.Sum(e => e.InitialActivity).ToString());
                sheet7.GetRow(7).GetCell(7).SetCellValue((activityCementLiquid[0].LiquidVolime / 1000).ToString());
                int num = 0;
                num = activityCliquidDetailList.Count();
                NPOIHelper.CopyRow(sheet7, 11, 11, num);
                for (int i = 0; i < num; i++)
                {
                    NuclearElement nuclearElement = _NuclearElementRepository.Get(activityCliquidDetailList[i].ElementId);
                    sheet7.GetRow(11 + i).GetCell(0).SetCellValue(nuclearElement.ElementName);
                    sheet7.GetRow(11 + i).GetCell(2).SetCellValue(activityCliquidDetailList[i].HalfLife.ToString());
                    sheet7.GetRow(11 + i).GetCell(4).SetCellValue("");
                    sheet7.GetRow(11 + i).GetCell(6).SetCellValue(activityCliquidDetailList[i].InitialActivityRate.ToString());
                    sheet7.GetRow(11 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityCliquidDetailList[i].ElementLevel)).ToString());
                }
                sheet7.GetRow(12 + num).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityCliquidDetailList.Sum(d => d.InitialActivity))));
                sheet7.GetRow(12 + num).GetCell(6).SetCellValue(activityCliquidDetailList.Sum(d => d.InitialActivityRate).ToString());
                sheet7.GetRow(14 + num).GetCell(4).SetCellValue((activityCliquidDetailList.Sum(e => e.InitialActivity) * activityCementLiquid[0].LiquidVolime / 1000).ToString());
                sheet7.GetRow(15 + num).GetCell(4).SetCellValue((activityCliquidDetailList.Sum(e => e.InitialActivity) * activityCementLiquid[0].LiquidVolime / 1000).ToString());
                sheet7.GetRow(16 + num).GetCell(4).SetCellValue(activityCliquidDetailList.Sum(e => e.ElementLevel).ToString());

                sheet7.GetRow(18 + num).GetCell(3).SetCellValue((activityCementLiquid[0].LiquidVolime / 1000).ToString());
                sheet7.GetRow(19 + num).GetCell(0).SetCellValue("    " + activityCementLiquid[0].Remark);
                sheet7.GetRow(26 + num).GetCell(1).SetCellValue(activityCementLiquid[0].ReportName);
                sheet7.GetRow(27 + num).GetCell(1).SetCellValue(activityCementLiquid[0].RepostDate.HasValue ? activityCementLiquid[0].RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(26 + num).GetCell(6).SetCellValue(activityCementLiquid[0].CheckName);
                sheet7.GetRow(27 + num).GetCell(6).SetCellValue(activityCementLiquid[0].CheckDate.HasValue ? activityCementLiquid[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
            #endregion
            #region C4过滤
            if (activityCfilter != null && activityCfilter.Count() > 0)
            {
                sheet7.GetRow(4).GetCell(2).SetCellValue(nuclearBucket.BucketCode);
                sheet7.GetRow(4).GetCell(7).SetCellValue(activityCfilter[0].EffcetDate.HasValue ? activityCfilter[0].EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(5).GetCell(2).SetCellValue(basicObject[0].Name);
                sheet7.GetRow(6).GetCell(2).SetCellValue(supportEds[0].EdsSerialCode);

                sheet7.GetRow(7).GetCell(2).SetCellValue(activityCfilter[0].AvgDoseRate.ToString());
                sheet7.GetRow(7).GetCell(7).SetCellValue(activityCfilter[0].TransferFun.ToString());
                int num = 0;
                num = activityCfilterDetailList.Count();
                NPOIHelper.CopyRow(sheet7, 11, 11, num);
                for (int i = 0; i < num; i++)
                {
                    NuclearElement nuclearElement = _NuclearElementRepository.Get(activityCfilterDetailList[i].ElementId);
                    sheet7.GetRow(11 + i).GetCell(0).SetCellValue(nuclearElement.ElementName);
                    sheet7.GetRow(11 + i).GetCell(2).SetCellValue(activityCfilterDetailList[i].HalfLife.ToString());
                    sheet7.GetRow(11 + i).GetCell(4).SetCellValue("");
                    sheet7.GetRow(11 + i).GetCell(6).SetCellValue(activityCfilterDetailList[i].InitialActivityRate.ToString());
                    sheet7.GetRow(11 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityCfilterDetailList[i].ElementLevel)));
                }
                sheet7.GetRow(12 + num).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityCfilterDetailList[0].InitialActivity)));
                sheet7.GetRow(12 + num).GetCell(6).SetCellValue(activityCfilterDetailList.Sum(d => d.InitialActivityRate).ToString());

                sheet7.GetRow(14 + num).GetCell(4).SetCellValue((activityCfilter[0].AvgDoseRate * activityCfilter[0].TransferFun).ToString());
                sheet7.GetRow(15 + num).GetCell(4).SetCellValue((activityCfilter[0].AvgDoseRate * activityCfilter[0].TransferFun).ToString());
                sheet7.GetRow(16 + num).GetCell(4).SetCellValue(activityCfilterDetailList.Sum(e => e.ElementLevel).ToString());

                sheet7.GetRow(18 + num).GetCell(3).SetCellValue(activityCfilter[0].TransferFun.ToString());
                sheet7.GetRow(19 + num).GetCell(0).SetCellValue("    " + activityCfilter[0].Remark);
                sheet7.GetRow(26 + num).GetCell(1).SetCellValue(activityCfilter[0].ReportName);
                sheet7.GetRow(27 + num).GetCell(1).SetCellValue(activityCfilter[0].RepostDate.HasValue ? activityCfilter[0].RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(26 + num).GetCell(6).SetCellValue(activityCfilter[0].CheckName);
                sheet7.GetRow(27 + num).GetCell(6).SetCellValue(activityCfilter[0].CheckDate.HasValue ? activityCfilter[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
            #endregion
            #region 多芯桶
            if (activityCore != null && activityCore.Count() > 0)
            {
                sheet7.GetRow(4).GetCell(2).SetCellValue(nuclearBucket.BucketCode);
                sheet7.GetRow(4).GetCell(7).SetCellValue(activityCore[0].EffcetDate.HasValue ? activityCore[0].EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(5).GetCell(2).SetCellValue(basicObject[0].Name);
                sheet7.GetRow(6).GetCell(2).SetCellValue(supportEds[0].EdsSerialCode);
                sheet7.GetRow(7).GetCell(2).SetCellValue(activityCore[0].AvgDoseRate.ToString());
                sheet7.GetRow(7).GetCell(7).SetCellValue(activityCore[0].TransferFun.ToString());
                int num = 0;
                num = activityCoreDetailList.Count();
                NPOIHelper.CopyRow(sheet7, 11, 11, num);
                for (int i = 0; i < num; i++)
                {
                    NuclearElement nuclearElement = _NuclearElementRepository.Get(activityCoreDetailList[i].ElementId);
                    sheet7.GetRow(11 + i).GetCell(0).SetCellValue(nuclearElement.ElementName);
                    sheet7.GetRow(11 + i).GetCell(2).SetCellValue(activityCoreDetailList[i].HalfLife.ToString());
                    sheet7.GetRow(11 + i).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityCoreDetailList[i].CalcuLevel)));
                    sheet7.GetRow(11 + i).GetCell(6).SetCellValue(activityCoreDetailList[i].CalcuLevelRate.ToString());
                    sheet7.GetRow(11 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityCoreDetailList[i].ElementLevel)));
                }
                sheet7.GetRow(12 + num).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityCoreDetailList.Sum(d => d.CalcuLevel))));
                sheet7.GetRow(12 + num).GetCell(6).SetCellValue(activityCoreDetailList.Sum(d => d.CalcuLevelRate).ToString());
                sheet7.GetRow(14 + num).GetCell(4).SetCellValue((activityCore[0].AvgDoseRate * activityCore[0].TransferFun).ToString());
                sheet7.GetRow(15 + num).GetCell(4).SetCellValue((activityCore[0].AvgDoseRate * activityCore[0].TransferFun).ToString());
                sheet7.GetRow(16 + num).GetCell(4).SetCellValue(activityCoreDetailList.Sum(e => e.ElementLevel).ToString());
                sheet7.GetRow(18 + num).GetCell(3).SetCellValue(activityCore[0].TransferFun.ToString());
                sheet7.GetRow(19 + num).GetCell(0).SetCellValue("    " + activityCore[0].Remark);
                sheet7.GetRow(26 + num).GetCell(1).SetCellValue(activityCore[0].ReportName);
                sheet7.GetRow(27 + num).GetCell(1).SetCellValue(activityCore[0].RepostDate.HasValue ? activityCore[0].RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(26 + num).GetCell(6).SetCellValue(activityCore[0].CheckName);
                sheet7.GetRow(27 + num).GetCell(6).SetCellValue(activityCore[0].CheckDate.HasValue ? activityCore[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
            #endregion
            #region C1树脂
            if (activityCresin != null && activityCresin.Count() > 0)
            {
                sheet7.GetRow(4).GetCell(2).SetCellValue(nuclearBucket.BucketCode);
                sheet7.GetRow(4).GetCell(7).SetCellValue(activityCresin[0].EffcetDate.HasValue ? activityCresin[0].EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(5).GetCell(2).SetCellValue(basicObject[0].Name);
                sheet7.GetRow(6).GetCell(2).SetCellValue(supportEds[0].EdsSerialCode);
                sheet7.GetRow(7).GetCell(2).SetCellValue(activityCresin[0].AvgDoseRate.ToString());
                sheet7.GetRow(7).GetCell(7).SetCellValue(activityCresin[0].TransferFun.ToString());
                int num = 0;
                num = activityCresinDetailList.Count();
                NPOIHelper.CopyRow(sheet7, 11, 11, num);
                for (int i = 0; i < num; i++)
                {
                    NuclearElement nuclearElement = _NuclearElementRepository.Get(activityCresinDetailList[i].ElementId);
                    sheet7.GetRow(11 + i).GetCell(0).SetCellValue(nuclearElement.ElementName);
                    sheet7.GetRow(11 + i).GetCell(2).SetCellValue(activityCresinDetailList[i].HalfLife.ToString());
                    sheet7.GetRow(11 + i).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityCresinDetailList[i].CalcuLevel)));
                    sheet7.GetRow(11 + i).GetCell(6).SetCellValue(activityCresinDetailList[i].CalcuLevelRate.ToString());
                    sheet7.GetRow(11 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityCresinDetailList[i].ElementActivity)));
                }
                sheet7.GetRow(12 + num).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityCresinDetailList.Sum(d => d.CalcuLevel))));
                sheet7.GetRow(12 + num).GetCell(6).SetCellValue(activityCresinDetailList.Sum(d => d.CalcuLevelRate).ToString());
                sheet7.GetRow(14 + num).GetCell(4).SetCellValue((activityCresin[0].AvgDoseRate * activityCresin[0].TransferFun).ToString());
                sheet7.GetRow(15 + num).GetCell(4).SetCellValue((activityCresin[0].AvgDoseRate * activityCresin[0].TransferFun).ToString());
                sheet7.GetRow(16 + num).GetCell(4).SetCellValue(activityCresinDetailList.Sum(e => e.ElementActivity).ToString());
                sheet7.GetRow(18 + num).GetCell(3).SetCellValue(activityCresin[0].TransferFun.ToString());
                sheet7.GetRow(19 + num).GetCell(0).SetCellValue("    " + activityCresin[0].Remark);
                sheet7.GetRow(26 + num).GetCell(1).SetCellValue(activityCresin[0].ReportName);
                sheet7.GetRow(27 + num).GetCell(1).SetCellValue(activityCresin[0].RepostDate.HasValue ? activityCresin[0].RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(26 + num).GetCell(6).SetCellValue(activityCresin[0].CheckName);
                sheet7.GetRow(27 + num).GetCell(6).SetCellValue(activityCresin[0].CheckDate.HasValue ? activityCresin[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
            #endregion
            #region 高放废物
            if (activityHlevel != null && activityHlevel.Count() > 0)
            {
                sheet7.GetRow(4).GetCell(2).SetCellValue(nuclearBucket.BucketCode);
                sheet7.GetRow(4).GetCell(7).SetCellValue(activityHlevel[0].EffcetDate.HasValue ? activityHlevel[0].EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(5).GetCell(2).SetCellValue(basicObject[0].Name);
                sheet7.GetRow(6).GetCell(2).SetCellValue(supportEds[0].EdsSerialCode);

                sheet7.GetRow(7).GetCell(2).SetCellValue(activityHlevel[0].AvgDoseRate.ToString());
                sheet7.GetRow(7).GetCell(7).SetCellValue(activityHlevel[0].TransferFun.ToString());
                int num = 0;
                num = activityHlevelDetailList.Count();
                NPOIHelper.CopyRow(sheet7, 11, 11, num);
                for (int i = 0; i < num; i++)
                {
                    NuclearElement nuclearElement = _NuclearElementRepository.Get(activityHlevelDetailList[i].ElementId);
                    sheet7.GetRow(11 + i).GetCell(0).SetCellValue(nuclearElement.ElementName);
                    sheet7.GetRow(11 + i).GetCell(2).SetCellValue(activityHlevelDetailList[i].HalfLife.ToString());
                    sheet7.GetRow(11 + i).GetCell(4).SetCellValue("");
                    sheet7.GetRow(11 + i).GetCell(6).SetCellValue(activityHlevelDetailList[i].InitialActivityRate.ToString());
                    sheet7.GetRow(11 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityHlevelDetailList[i].ElementLevel)));
                }
                sheet7.GetRow(12 + num).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityHlevelDetailList[0].InitialActivity)));
                sheet7.GetRow(12 + num).GetCell(6).SetCellValue(activityHlevelDetailList.Sum(d => d.InitialActivityRate).ToString());

                sheet7.GetRow(14 + num).GetCell(4).SetCellValue((activityHlevel[0].AvgDoseRate * activityHlevel[0].TransferFun).ToString());
                sheet7.GetRow(15 + num).GetCell(4).SetCellValue((activityHlevel[0].AvgDoseRate * activityHlevel[0].TransferFun).ToString());
                sheet7.GetRow(16 + num).GetCell(4).SetCellValue(activityHlevelDetailList.Sum(e => e.ElementLevel).ToString());

                sheet7.GetRow(18 + num).GetCell(3).SetCellValue(activityHlevel[0].TransferFun.ToString());
                sheet7.GetRow(19 + num).GetCell(0).SetCellValue("    " + activityHlevel[0].Remark);
                sheet7.GetRow(26 + num).GetCell(1).SetCellValue(activityHlevel[0].ReportName);
                sheet7.GetRow(27 + num).GetCell(1).SetCellValue(activityHlevel[0].RepostDate.HasValue ? activityHlevel[0].RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(26 + num).GetCell(6).SetCellValue(activityHlevel[0].CheckName);
                sheet7.GetRow(27 + num).GetCell(6).SetCellValue(activityHlevel[0].CheckDate.HasValue ? activityHlevel[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
            #endregion
            #region 400L过滤器
            if (activityMfilter != null && activityMfilter.Count() > 0)
            {
                sheet7.GetRow(4).GetCell(2).SetCellValue(nuclearBucket.BucketCode);
                sheet7.GetRow(4).GetCell(7).SetCellValue(activityMfilter[0].EffcetDate.HasValue ? activityMfilter[0].EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(5).GetCell(2).SetCellValue(basicObject[0].Name);
                sheet7.GetRow(6).GetCell(2).SetCellValue(supportEds[0].EdsSerialCode);
                sheet7.GetRow(7).GetCell(2).SetCellValue(activityMfilter[0].AvgDoseRate.ToString());
                sheet7.GetRow(7).GetCell(7).SetCellValue(activityMfilter[0].TransferFun.ToString());
                int num = 0;
                num = activityMfilterDetailList.Count();
                NPOIHelper.CopyRow(sheet7, 11, 11, num);
                for (int i = 0; i < num; i++)
                {
                    NuclearElement nuclearElement = _NuclearElementRepository.Get(activityMfilterDetailList[i].ElementId);
                    sheet7.GetRow(11 + i).GetCell(0).SetCellValue(nuclearElement.ElementName);
                    sheet7.GetRow(11 + i).GetCell(2).SetCellValue(activityMfilterDetailList[i].HalfLife.ToString());
                    sheet7.GetRow(11 + i).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityMfilterDetailList[i].CalcuLevel)));
                    sheet7.GetRow(11 + i).GetCell(6).SetCellValue(activityMfilterDetailList[i].CalcuLevelRate.ToString());
                    sheet7.GetRow(11 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityMfilterDetailList[i].ElementLevel)));
                }
                sheet7.GetRow(12 + num).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityMfilterDetailList.Sum(d => d.CalcuLevel))));
                sheet7.GetRow(12 + num).GetCell(6).SetCellValue(activityMfilterDetailList.Sum(d => d.CalcuLevelRate).ToString());
                sheet7.GetRow(14 + num).GetCell(4).SetCellValue((activityMfilter[0].AvgDoseRate * activityMfilter[0].TransferFun).ToString());
                sheet7.GetRow(15 + num).GetCell(4).SetCellValue((activityMfilter[0].AvgDoseRate * activityMfilter[0].TransferFun).ToString());
                sheet7.GetRow(16 + num).GetCell(4).SetCellValue(activityMfilterDetailList.Sum(e => e.ElementLevel).ToString());
                sheet7.GetRow(18 + num).GetCell(3).SetCellValue(activityMfilter[0].TransferFun.ToString());
                sheet7.GetRow(19 + num).GetCell(0).SetCellValue("    " + activityMfilter[0].Remark);
                sheet7.GetRow(26 + num).GetCell(1).SetCellValue(activityMfilter[0].ReportName);
                sheet7.GetRow(27 + num).GetCell(1).SetCellValue(activityMfilter[0].RepostDate.HasValue ? activityMfilter[0].RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(26 + num).GetCell(6).SetCellValue(activityMfilter[0].CheckName);
                sheet7.GetRow(27 + num).GetCell(6).SetCellValue(activityMfilter[0].CheckDate.HasValue ? activityMfilter[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
            #endregion
            #region 400L浓缩液
            if (activityMliquid != null && activityMliquid.Count() > 0)
            {
                sheet7.GetRow(4).GetCell(2).SetCellValue(nuclearBucket.BucketCode);
                sheet7.GetRow(4).GetCell(7).SetCellValue(activityMliquid[0].MeasureDate.HasValue ? activityMliquid[0].MeasureDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(5).GetCell(2).SetCellValue(basicObject[0].Name);
                sheet7.GetRow(6).GetCell(2).SetCellValue(supportEds[0].EdsSerialCode);
                sheet7.GetRow(7).GetCell(2).SetCellValue("");
                sheet7.GetRow(7).GetCell(7).SetCellValue("");
                int num = 0;
                num = activityMliquidDetailList.Count();
                NPOIHelper.CopyRow(sheet7, 11, 11, num);
                for (int i = 0; i < num; i++)
                {
                    NuclearElement nuclearElement = _NuclearElementRepository.Get(activityMliquidDetailList[i].ElementId);
                    sheet7.GetRow(11 + i).GetCell(0).SetCellValue(nuclearElement.ElementName);
                    sheet7.GetRow(11 + i).GetCell(2).SetCellValue(activityMliquidDetailList[i].HalfLife.ToString());
                    sheet7.GetRow(11 + i).GetCell(4).SetCellValue("");
                    sheet7.GetRow(11 + i).GetCell(6).SetCellValue(activityMliquidDetailList[i].InitialActivityRate.ToString());
                    sheet7.GetRow(11 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityMliquidDetailList[i].ElementLevel)));
                }
                sheet7.GetRow(12 + num).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityMliquidDetailList[0].InitialActivity)));
                sheet7.GetRow(12 + num).GetCell(6).SetCellValue(activityMliquidDetailList.Sum(d => d.InitialActivityRate).ToString());
                sheet7.GetRow(14 + num).GetCell(4).SetCellValue((activityMliquidDetailList.Sum(d => d.InitialActivityRate) * activityMliquid[0].LiquidVolime/1000).ToString());
                sheet7.GetRow(15 + num).GetCell(4).SetCellValue((activityMliquidDetailList.Sum(d => d.InitialActivityRate) * activityMliquid[0].LiquidVolime / 1000).ToString());
                sheet7.GetRow(16 + num).GetCell(4).SetCellValue(activityMliquidDetailList.Sum(e => e.ElementLevel).ToString());
                sheet7.GetRow(18 + num).GetCell(3).SetCellValue("");
                sheet7.GetRow(19 + num).GetCell(0).SetCellValue("    " + activityMliquid[0].Remark);
                sheet7.GetRow(26 + num).GetCell(1).SetCellValue(activityMliquid[0].ReportName);
                sheet7.GetRow(27 + num).GetCell(1).SetCellValue(activityMliquid[0].RepostDate.HasValue ? activityMliquid[0].RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(26 + num).GetCell(6).SetCellValue(activityMliquid[0].CheckName);
                sheet7.GetRow(27 + num).GetCell(6).SetCellValue(activityMliquid[0].CheckDate.HasValue ? activityMliquid[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
            #endregion
            #region 400L废树脂
            if (activityMresin != null && activityMresin.Count() > 0)
            {
                sheet7.GetRow(4).GetCell(2).SetCellValue(nuclearBucket.BucketCode);
                sheet7.GetRow(4).GetCell(7).SetCellValue(activityMresin[0].EffcetDate.HasValue ? activityMresin[0].EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(5).GetCell(2).SetCellValue(basicObject[0].Name);
                sheet7.GetRow(6).GetCell(2).SetCellValue(supportEds[0].EdsSerialCode);
                sheet7.GetRow(7).GetCell(2).SetCellValue(activityMresin[0].AvgDoseRate.ToString());
                sheet7.GetRow(7).GetCell(7).SetCellValue(activityMresin[0].TransferFun.ToString());
                int num = 0;
                num = activityMresinDetailList.Count();
                NPOIHelper.CopyRow(sheet7, 11, 11, num);
                for (int i = 0; i < num; i++)
                {
                    NuclearElement nuclearElement = _NuclearElementRepository.Get(activityMresinDetailList[i].ElementId);
                    sheet7.GetRow(11 + i).GetCell(0).SetCellValue(nuclearElement.ElementName);
                    sheet7.GetRow(11 + i).GetCell(2).SetCellValue(activityMresinDetailList[i].HalfLife.ToString());
                    sheet7.GetRow(11 + i).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityMresinDetailList[i].CalcuLevel)));
                    sheet7.GetRow(11 + i).GetCell(6).SetCellValue(activityMresinDetailList[i].CalcuLevelRate.ToString());
                    sheet7.GetRow(11 + i).GetCell(8).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityMresinDetailList[i].ElementLevel)));
                }
                sheet7.GetRow(12 + num).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityMresinDetailList.Sum(d => d.CalcuLevel))));
                sheet7.GetRow(12 + num).GetCell(6).SetCellValue(activityMresinDetailList.Sum(d => d.CalcuLevelRate).ToString());
                sheet7.GetRow(14 + num).GetCell(4).SetCellValue((activityMresin[0].AvgDoseRate * activityMresin[0].TransferFun).ToString());
                sheet7.GetRow(15 + num).GetCell(4).SetCellValue((activityMresin[0].AvgDoseRate * activityMresin[0].TransferFun).ToString());
                sheet7.GetRow(16 + num).GetCell(4).SetCellValue(activityMresinDetailList.Sum(e => e.ElementLevel).ToString());
                sheet7.GetRow(18 + num).GetCell(3).SetCellValue(activityMresin[0].TransferFun.ToString());
                sheet7.GetRow(19 + num).GetCell(0).SetCellValue("    " + activityMresin[0].Remark);
                sheet7.GetRow(26 + num).GetCell(1).SetCellValue(activityMresin[0].ReportName);
                sheet7.GetRow(27 + num).GetCell(1).SetCellValue(activityMresin[0].RepostDate.HasValue ? activityMresin[0].RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(26 + num).GetCell(6).SetCellValue(activityMresin[0].CheckName);
                sheet7.GetRow(27 + num).GetCell(6).SetCellValue(activityMresin[0].CheckDate.HasValue ? activityMresin[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
            #endregion
            #region 400L超压桶
            if (activityOpBucket != null && activityOpBucket.Count() > 0)
            {
                sheet7.GetRow(4).GetCell(2).SetCellValue(nuclearBucket.BucketCode);
                sheet7.GetRow(4).GetCell(7).SetCellValue(activityOpBucket[0].EffcetDate.HasValue ? activityOpBucket[0].EffcetDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(5).GetCell(2).SetCellValue(basicObject[0].Name);
                sheet7.GetRow(6).GetCell(2).SetCellValue(supportEds[0].EdsSerialCode);
                sheet7.GetRow(7).GetCell(2).SetCellValue(activityOpBucket[0].AvgDoseRate.ToString());
                sheet7.GetRow(7).GetCell(7).SetCellValue("");
                int num = 0;
                num = activityOpBucketDetailList.Count();
                NPOIHelper.CopyRow(sheet7, 11, 11, num);
                for (int i = 0; i < num; i++)
                {
                    NuclearElement nuclearElement = _NuclearElementRepository.Get(activityOpBucketDetailList[i].ElementId);
                    sheet7.GetRow(11 + i).GetCell(0).SetCellValue(nuclearElement.ElementName);
                    sheet7.GetRow(11 + i).GetCell(2).SetCellValue(activityOpBucketDetailList[i].HalfLife.ToString());
                    sheet7.GetRow(11 + i).GetCell(4).SetCellValue(commonHelper.StringFormatGetE(Convert.ToDecimal(activityOpBucketDetailList[i].InitialActivity)));
                    sheet7.GetRow(11 + i).GetCell(6).SetCellValue(activityOpBucketDetailList[i].InitialActivityRate.ToString());
                    sheet7.GetRow(11 + i).GetCell(8).SetCellValue("");
                }
                sheet7.GetRow(12 + num).GetCell(4).SetCellValue("");
                sheet7.GetRow(12 + num).GetCell(6).SetCellValue("");
                sheet7.GetRow(14 + num).GetCell(4).SetCellValue(activityOpBucketDetailList[0].GamActivity.ToString());
                sheet7.GetRow(15 + num).GetCell(4).SetCellValue(activityOpBucketDetailList[0].GamActivity.ToString());
                sheet7.GetRow(16 + num).GetCell(4).SetCellValue(activityOpBucketDetailList.Sum(e => e.TotalActivity).ToString());
                sheet7.GetRow(18 + num).GetCell(3).SetCellValue("");
                sheet7.GetRow(19 + num).GetCell(0).SetCellValue("    " + activityOpBucket[0].Remark);
                sheet7.GetRow(26 + num).GetCell(1).SetCellValue(activityOpBucket[0].ReportName);
                sheet7.GetRow(27 + num).GetCell(1).SetCellValue(activityOpBucket[0].RepostDate.HasValue ? activityOpBucket[0].RepostDate.Value.ToString("yyyy-MM-dd") : string.Empty);
                sheet7.GetRow(26 + num).GetCell(6).SetCellValue(activityOpBucket[0].CheckName);
                sheet7.GetRow(27 + num).GetCell(6).SetCellValue(activityOpBucket[0].CheckDate.HasValue ? activityOpBucket[0].CheckDate.Value.ToString("yyyy-MM-dd") : string.Empty);
            }
            #endregion
        }
    }
}
