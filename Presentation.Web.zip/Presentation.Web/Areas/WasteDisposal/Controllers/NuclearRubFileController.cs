﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels;
using RWIS.Domain.DomainObjects;
using System;
using NET01.CoreFramework;
using RWIS.Domain.DomainObjects.View.NuclearRubFile;
using System.Web;
using System.IO;
using NPOI.XWPF.UserModel;
using NPOI.OpenXmlFormats.Wordprocessing;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.SS.Util;
using RWIS.Domain.DomainObjects.View.DispiteConfirm;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Core;
using CIT.UPC.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using CIT.UPC.Domain.DomainObjects;
using NPOI.SS.UserModel;

using NPOI.HSSF.UserModel;
using System.IO;
using NPOI.XSSF.UserModel;
using RWIS.Domain.DomainObjects.View;//内存流的使用



namespace RWIS.Presentation.Web.Areas.WasteDisposal.Controllers
{
    public class NuclearRubFileController : Controller
    {

        INuclearRubFileRepository _NuclearRubFileRepository;
       IMaterialTypeRepository _MaterialTypeRepository;
       IBasicObjectRepository _BasicObjectRepository;
       INuclearWastePackageRepository _NuclearWastePackageRepository;
       INuclearRubLocationRepository _NuclearRubLocationRepository;
         IBasicWasteUnitRepository  _BasicWasteUnitRepository;
         INuclearBucketRepository _NuclearBucketRepository;
         IDispiteConfirmRepository _DispiteConfirmRepository;
         INuclearRubReceptionDRepository _NuclearRubReceptionDRepository;
         IDispiteConfirmDetailRepository _DispiteConfirmDetailRepository;
         INuclearRubReceptionRepository _NuclearRubReceptionRepository;
         INuclearBucketCheckRepository _NuclearBucketCheckRepository;
         ISupportEdsDetailRepository _SupportEdsDetailRepository;
         INuclearElementRepository _NuclearElementRepository;
         INuclearApplyDetailRepository _NuclearApplyDetailRepository;
         IDispsiteCheckDetailRepository _DispsiteCheckDetailRepository;

       public NuclearRubFileController(INuclearRubFileRepository _NuclearRubFileRepository,
                                             IMaterialTypeRepository _MaterialTypeRepository,
                                        IBasicObjectRepository _BasicObjectRepository,
                                  INuclearWastePackageRepository _NuclearWastePackageRepository,
                               INuclearRubLocationRepository _NuclearRubLocationRepository,
                              IBasicWasteUnitRepository  _BasicWasteUnitRepository,
                          INuclearBucketRepository _NuclearBucketRepository,
                        IDispiteConfirmRepository _DispiteConfirmRepository,
                       INuclearRubReceptionDRepository _NuclearRubReceptionDRepository,
            IDispiteConfirmDetailRepository _DispiteConfirmDetailRepository,
            INuclearRubReceptionRepository _NuclearRubReceptionRepository,
            INuclearBucketCheckRepository _NuclearBucketCheckRepository,
            ISupportEdsDetailRepository _SupportEdsDetailRepository,
           INuclearApplyDetailRepository _NuclearApplyDetailRepository,
            INuclearElementRepository _NuclearElementRepository,
            IDispsiteCheckDetailRepository _DispsiteCheckDetailRepository
   
           )
        {
            this._NuclearRubFileRepository = _NuclearRubFileRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
            this._NuclearRubLocationRepository = _NuclearRubLocationRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._DispiteConfirmRepository = _DispiteConfirmRepository;
            this._NuclearRubReceptionDRepository = _NuclearRubReceptionDRepository;
            this._DispiteConfirmDetailRepository = _DispiteConfirmDetailRepository;
            this._NuclearRubReceptionRepository = _NuclearRubReceptionRepository;
            this._NuclearBucketCheckRepository = _NuclearBucketCheckRepository;
            this._SupportEdsDetailRepository = _SupportEdsDetailRepository;
            this._NuclearElementRepository = _NuclearElementRepository;
            this._NuclearApplyDetailRepository = _NuclearApplyDetailRepository;
            this._DispsiteCheckDetailRepository = _DispsiteCheckDetailRepository;
        }
       /// <summary>
       /// 初始页面
       /// </summary>
       /// <returns></returns>
       [UbaFilter(OperateType = OperateType.Page, OperateDescription = "档案生成")]
        public ActionResult Index()
       {
            NuclearRubFileVM vm = new NuclearRubFileVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_File");
            return View(vm);
        }

        /// <summary>
        /// 查看页面
        /// </summary>
        /// <returns></returns>
        public ActionResult DetailView(string packageCode)
        {
            DispiteConfirmVM vm = new DispiteConfirmVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_File");
            List<NuclearWastePackage> nuclearWastePackageList = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (nuclearWastePackageList.Count() > 0)
            {
                //获得质量确认主表
                List<DispiteConfirm> dispiteConfirmList = _DispiteConfirmRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId).ToList();
                if (dispiteConfirmList.Count() > 0)
                {

                    vm.DispiteConfirm = _DispiteConfirmRepository.Get(dispiteConfirmList[0].ConfirmId);
                    List<DispiteConfirmDetail> dispiteConfirmDetail = _DispiteConfirmDetailRepository.GetAll().Where(d => d.ConfirmId == vm.DispiteConfirm.ConfirmId).ToList();
                    foreach (var item in dispiteConfirmDetail)
                    {
                        if (item.CheckType == "PREPARE")
                        {
                            vm.Prepare = item.ExplainContent;
                        }
                        if (item.CheckType == "SOLID")
                        {
                            vm.Solid = item.ExplainContent;
                        }
                        if (item.CheckType == "COVER")
                        {
                            vm.Cover = item.ExplainContent;
                        }
                        if (item.CheckType == "TRANSFER")
                        {
                            vm.Transfer = item.ExplainContent;
                        }
                        if (item.CheckType == "RECEIVE")
                        {
                            vm.Receive = item.ExplainContent;
                        }
                        if (item.CheckType == "SUPPLY")
                        {
                            vm.Supply = item.ExplainContent;
                        }

                    }
                    IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                    IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(dispiteConfirmList[0].ConfirmId, "QuestionReport");
                    vm.ConfirmAttachFiles = (List<AttachFile>)listAttachFile;
                    ViewBag.BusinessType = "QuestionReport";
                }
                else
                {
                    vm.DispiteConfirm = new DispiteConfirm();
                }
                //获得桶的信息
                List<NuclearBucket> nuclearBucketList = this._NuclearBucketRepository.GetAll().Where(d => d.BucketId == nuclearWastePackageList[0].BucketId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                if (nuclearBucketList.Count() > 0)
                {
                    vm.BucketCode = nuclearBucketList[0].BucketCode;
                    vm.WasteType = nuclearBucketList[0].WasteType;
                    vm.DealDate = nuclearBucketList[0].DealDate.HasValue ? nuclearBucketList[0].DealDate.Value.ToString("yyyy-MM-dd") : "";
                }
                //废物货包编号赋值
                vm.PackageCode = packageCode;
                //废物重量赋值
                List<NuclearRubLocation> nuclearRubLocationList = this._NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                if (nuclearRubLocationList.Count() > 0)
                {
                    vm.Weight = nuclearRubLocationList[0].Weight;
                }
                //废物货包接收、检查
                List<NuclearRubReceptionD> nuclearRubReceptionList = this._NuclearRubReceptionDRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId).ToList();
                if (nuclearRubReceptionList.Count() > 0)
                {
                    vm.Isquelified = nuclearRubReceptionList[0].Isquelified;
                }
            }
            //获得审核结果数据
            List<DispiteConfirmView> dispiteConfirmViewList = this._DispiteConfirmRepository.QueryList().Where(d => d.PackageCode == packageCode).ToList();
            if (dispiteConfirmViewList.Count() > 0)
            {
                vm.InspectIsrequired = dispiteConfirmViewList[0].InspectIsrequired;
                vm.BarrelIsrequired = dispiteConfirmViewList[0].BarrelIsrequired;
                vm.DoseIsrequired = dispiteConfirmViewList[0].DoseIsrequired;
                vm.TransferIsrequired = dispiteConfirmViewList[0].TransferIsrequired;
            }
            
            ///档案生成
            
            NuclearRubFileCondition condition = new NuclearRubFileCondition();
            List<NuclearWastePackage> nuclearWastePackage =_NuclearWastePackageRepository.GetAll().Where(d=>d.PackageCode==packageCode&&d.Stationcode==AppContext.CurrentUser.ProjectCode).ToList();
            if (nuclearWastePackage.Count() > 0)
            {
                List<NuclearRubLocation> nuclearRubLocation = _NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == nuclearWastePackage[0].PackageId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                condition.LocationId = nuclearRubLocation[0].LocationId;

                List<NuclearRubFileView> data = _NuclearRubFileRepository.QueryList(condition).ToList();
                if (data.Count > 0)
                {
                    List<NuclearRubFile> nuclearRubFileList = _NuclearRubFileRepository.GetAll().Where(d => d.PackageId == data[0].PackageId).ToList();
                    if (nuclearRubFileList.Count() > 0)
                    {
                        vm.NuclearRubFile = this._NuclearRubFileRepository.Get(nuclearRubFileList[0].FileId);
                        IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                        IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(nuclearRubFileList[0].FileId, "QuestionReport");
                        vm.FileAttachFiles = (List<AttachFile>)listAttachFile;
                    }
                    else
                    {
                        vm.NuclearRubFile = new NuclearRubFile();
                    }

                    vm.NuclearRubFile.BucketId = data[0].BucketId;
                    vm.BucketCode = data[0].BucketCode;
                    vm.NuclearRubFile.PackageId = data[0].PackageId;
                    vm.PackageCode = data[0].PackageCode;

                    List<BasicWasteUnit> dataList = _BasicWasteUnitRepository.GetAll().Where(d => d.SimpleCode == data[0].Stationcode).ToList();
                    if (dataList.Count() > 0)
                    {
                        vm.NuclearRubFile.PackageSource = dataList[0].UnitName;
                    }

                }
            }
            else
            {
                vm.NuclearRubFile = new NuclearRubFile();
            }
          
          
            ////密级
            //vm.SecrecyLevelList = new List<SelectListItem>();
            //vm.SecrecyLevelList.Add(new SelectListItem { Text = "请选择", Value = "" });
            //vm.SecrecyLevelList.Add(new SelectListItem { Text = "限制使用", Value = "Restriction" });
            //vm.SecrecyLevelList.Add(new SelectListItem { Text = "机密", Value = "Secrecy" });



            return View(vm);
        }
        /// <summary>
        /// 档案生成增加页面
        /// </summary>
        /// <returns></returns>
        public ActionResult FileAdd(string id)
        {
            NuclearRubFileVM vm = new NuclearRubFileVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_File");
            NuclearRubFileCondition condition = new NuclearRubFileCondition();
            condition.LocationId = id;
            List<NuclearRubFileView> data = _NuclearRubFileRepository.QueryList(condition).ToList();
            if (data.Count > 0)
            {
                List<NuclearRubFile> nuclearRubFileList = _NuclearRubFileRepository.GetAll().Where(d => d.PackageId == data[0].PackageId).ToList();
                if (nuclearRubFileList.Count() > 0)
                {
                    vm.NuclearRubFile = this._NuclearRubFileRepository.Get(nuclearRubFileList[0].FileId);
                    IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                    IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(nuclearRubFileList[0].FileId, "QuestionReport");
                    vm.FileAttachFiles = (List<AttachFile>)listAttachFile;
                    ViewBag.BusinessType = "QuestionReport";
                }
                else
                {
                    vm.NuclearRubFile = new NuclearRubFile();
                    vm.NuclearRubFile.FilePage = "15";
                    vm.NuclearRubFile.CommitDate = DateTime.Now.Date;

                }

            vm.NuclearRubFile.BucketId=data[0].BucketId;
            vm.BucketCode =data[0].BucketCode;
            vm.NuclearRubFile.PackageId =data[0].PackageId;
            vm.PackageCode = data[0].PackageCode;
           
            List<BasicWasteUnit> dataList = _BasicWasteUnitRepository.GetAll().Where(d => d.SimpleCode == data[0].Stationcode).ToList();
            if (dataList.Count() > 0)
            {
                vm.NuclearRubFile.PackageSource = dataList[0].UnitName;
            }
               
            }
            //密级
            vm.SecrecyLevelList = new List<SelectListItem>();
            vm.SecrecyLevelList.Add(new SelectListItem { Text = "请选择", Value = "" });
            vm.SecrecyLevelList.Add(new SelectListItem { Text = "限制使用", Value = "Restriction" });
            vm.SecrecyLevelList.Add(new SelectListItem { Text = "机密", Value = "Secrecy" });
           
            return View(vm);
        }
         /// <summary>
        /// 质量确认增加页面
        /// </summary>
        /// <returns></returns>
        public ActionResult ConfirmAdd(string packageCode)
        {
            DispiteConfirmVM vm = new DispiteConfirmVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_File");
            List<NuclearWastePackage> nuclearWastePackageList = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode&&d.Stationcode==AppContext.CurrentUser.ProjectCode).ToList();
            if (nuclearWastePackageList.Count() > 0)
            {
                //获得质量确认主表
                 List<DispiteConfirm> dispiteConfirmList= _DispiteConfirmRepository.GetAll().Where(d=>d.PackageId==nuclearWastePackageList[0].PackageId).ToList();
                if (dispiteConfirmList.Count() > 0)
                {

                    vm.DispiteConfirm = _DispiteConfirmRepository.Get(dispiteConfirmList[0].ConfirmId);
                    List<DispiteConfirmDetail> dispiteConfirmDetail = _DispiteConfirmDetailRepository.GetAll().Where(d => d.ConfirmId == vm.DispiteConfirm.ConfirmId).ToList();
                    foreach (var item in dispiteConfirmDetail)
                    {
                        if (item.CheckType == "PREPARE")
                        {
                            vm.Prepare = item.ExplainContent;
                        }
                        if (item.CheckType == "SOLID")
                        {
                            vm.Solid = item.ExplainContent;
                        }
                        if (item.CheckType == "COVER")
                        {
                            vm.Cover = item.ExplainContent;
                        }
                        if (item.CheckType == "TRANSFER")
                        {
                            vm.Transfer = item.ExplainContent;
                        }
                        if (item.CheckType == "RECEIVE")
                        {
                            vm.Receive = item.ExplainContent;
                        }
                        if (item.CheckType == "SUPPLY")
                        {
                            vm.Supply = item.ExplainContent;
                        }
                        
                    }
                    IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                    IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(dispiteConfirmList[0].ConfirmId, "QuestionReport");
                    vm.ConfirmAttachFiles = (List<AttachFile>)listAttachFile;
                    ViewBag.BusinessType = "QuestionReport";
                    vm.Weight = nuclearWastePackageList[0].Weight;
                }
                else
                {
                    vm.DispiteConfirm = new DispiteConfirm();
                }
                //获得桶的信息
                List<NuclearBucket> nuclearBucketList = this._NuclearBucketRepository.GetAll().Where(d => d.BucketId == nuclearWastePackageList[0].BucketId&&d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                if (nuclearBucketList.Count() > 0)
                {
                    vm.BucketCode = nuclearBucketList[0].BucketCode;
                    vm.WasteType = nuclearBucketList[0].WasteType;
                    vm.DealDate = nuclearBucketList[0].DealDate.HasValue?nuclearBucketList[0].DealDate.Value.ToString("yyyy-MM-dd"):"";
                    
                }
                //废物货包编号赋值
                vm.PackageCode = packageCode;
                ////废物重量赋值
                //List<NuclearRubLocation> nuclearRubLocationList = this._NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                //if (nuclearRubLocationList.Count() > 0)
                //{
                //    vm.Weight = nuclearRubLocationList[0].Weight;
                //}
                //废物货包接收、检查
                List<NuclearRubReceptionD> nuclearRubReceptionList = this._NuclearRubReceptionDRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId).ToList();
                if (nuclearRubReceptionList.Count() > 0)
                {
                    vm.Isquelified = nuclearRubReceptionList[0].CheckResult;
                    vm.Remark = nuclearRubReceptionList[0].Remark;
                }
                NuclearRubLocation nuclearRubLocation = _NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId).FirstOrDefault();
                if (nuclearRubLocation!=null)
                {
                    vm.Status = nuclearRubLocation.Status;
                    vm.RubRemark = nuclearRubLocation.Remark;
                }
               

            }




            NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == nuclearWastePackageList[0].BucketId).FirstOrDefault();
            if (nuclearApplyDetail != null)
            {
                DispsiteCheckDetail dispsiteCheckDetail = _DispsiteCheckDetailRepository.GetAll().Where(d => d.ApplyDetailId == nuclearApplyDetail.ApplyDetailId).FirstOrDefault();

                vm.BucketIsrequired = dispsiteCheckDetail.BucketIsrequired;
                vm.BucketCheckresult = dispsiteCheckDetail.BucketCheckresult;

                
                vm.InspectIsrequired = dispsiteCheckDetail.InspectIsrequired;
                vm.InspectCheckresult = dispsiteCheckDetail.InspectCheckresult;

                vm.BarrelIsrequired = dispsiteCheckDetail.BarrelIsrequired;
                vm.BarrelCheckresult = dispsiteCheckDetail.BarrelCheckresult;

                vm.DoseIsrequired = dispsiteCheckDetail.DoseIsrequired;
                vm.DoseCheckresult = dispsiteCheckDetail.DoseCheckresult;

                vm.TransferIsrequired = dispsiteCheckDetail.TransferIsrequired;
                vm.TransferCheckresult = dispsiteCheckDetail.TransferCheckresult;
            }
            ////获得审核结果数据
            //List<DispiteConfirmView> dispiteConfirmViewList = this._DispiteConfirmRepository.QueryList().Where(d => d.PackageCode == packageCode).ToList();
            //if (dispiteConfirmViewList.Count() > 0)
            //{
            //    vm.InspectIsrequired = dispiteConfirmViewList[0].InspectIsrequired;
            //    vm.BarrelIsrequired = dispiteConfirmViewList[0].BarrelIsrequired;
            //    vm.DoseIsrequired = dispiteConfirmViewList[0].DoseIsrequired;
            //    vm.TransferIsrequired = dispiteConfirmViewList[0].TransferIsrequired;
            //}
            vm.WaseteSource = _BasicWasteUnitRepository.GetNameById(AppContext.CurrentUser.ProjectCode);
            return View(vm);
        }
        /// <summary>
        /// 质量确认保存
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult DispiteSaveDraft(DispiteConfirmVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.DispiteConfirm.ConfirmId))
                {
                    DispiteDraftSave(model, "0", "");
                }
                //修改完新增
                else
                {
                    DispiteDraftUpdate(model, "0", "");
                }
                this._DispiteConfirmRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.DispiteConfirm.ConfirmId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 质量确认提交
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult DispiteSubmitDraft(DispiteConfirmVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.DispiteConfirm.ConfirmId))
                {
                    DispiteDraftSave(model, "1", "");
                }
                //修改完新增
                else
                {
                    DispiteDraftUpdate(model, "1", "");
                }
                this._DispiteConfirmRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.DispiteConfirm.ConfirmId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 质量确认确定
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "质量确认确定")]
        public JsonResult DispiteConfirmDraft(DispiteConfirmVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.DispiteConfirm.ConfirmId))
                {
                    DispiteDraftSave(model, "2", "Confirm");

                }
                //修改完新增
                else
                {
                    DispiteDraftUpdate(model, "2", "Confirm");

                }
                this._DispiteConfirmRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.DispiteConfirm.ConfirmId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确定失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 质量确认新增保存
        /// </summary>
        /// <param name="model"></param>
        private void DispiteDraftSave(DispiteConfirmVM model, string status, string type)
        {
            List<NuclearWastePackage> NuclearWastePackageList = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == model.PackageCode).ToList();
            if (NuclearWastePackageList.Count() > 0)
            {
                model.DispiteConfirm.BucketId = NuclearWastePackageList[0].BucketId;
                model.DispiteConfirm.PackageId = NuclearWastePackageList[0].PackageId;
            }
            model.DispiteConfirm.ConfirmId = Guid.NewGuid().ToString();
            model.DispiteConfirm.CreateDate = DateTime.Now;
            model.DispiteConfirm.CreateUserNo = AppContext.CurrentUser.UserId;
            model.DispiteConfirm.CreateUserName = AppContext.CurrentUser.UserName;
            if (type == "Confirm")
            {
                model.DispiteConfirm.ConfirmDate = DateTime.Now;
                model.DispiteConfirm.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.DispiteConfirm.ConfirmUserName = AppContext.CurrentUser.UserName;
            }
            this._DispiteConfirmRepository.Create(model.DispiteConfirm);
            //往质量确认详细表里插入数据
            DispiteConfirmDetailMethod(model, model.DispiteConfirm.BucketId);
            
        }
        /// <summary>
        /// 质量确认修改保存
        /// </summary>
        /// <param name="model"></param>
        private void DispiteDraftUpdate(DispiteConfirmVM model, string status, string type)
        {

            model.DispiteConfirm = _DispiteConfirmRepository.Get(model.DispiteConfirm.ConfirmId);
            UpdateModel(model);
            if (type == "Confirm")
            {
                model.DispiteConfirm.ConfirmDate = DateTime.Now;
                model.DispiteConfirm.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.DispiteConfirm.ConfirmUserName = AppContext.CurrentUser.UserName;
            }
            this._DispiteConfirmRepository.Update(model.DispiteConfirm);
            List<DispiteConfirmDetail> dispiteConfirmDetail = _DispiteConfirmDetailRepository.GetAll().Where(d => d.ConfirmId == model.DispiteConfirm.ConfirmId).ToList();
            if (dispiteConfirmDetail.Count() > 0)
            {
                foreach (var item in dispiteConfirmDetail)
                {
                    this._DispiteConfirmDetailRepository.DeleteById(item.DetailId);
                }
            }
            //往质量确认详细表里插入数据
            DispiteConfirmDetailMethod(model, model.DispiteConfirm.BucketId);

        }
        /// <summary>
        /// 往质量确认详细表里插入数据
        /// </summary>
        /// <param name="model"></param>
        private void DispiteConfirmDetailMethod(DispiteConfirmVM model,string bucketId)
        {
            NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == bucketId).FirstOrDefault();
            if (nuclearApplyDetail != null)
            {
                DispsiteCheckDetail dispsiteCheckDetail = _DispsiteCheckDetailRepository.GetAll().Where(d => d.ApplyDetailId == nuclearApplyDetail.ApplyDetailId).FirstOrDefault();
               
           
                //桶准备
                DispiteConfirmDetail dispiteConfirmDetailPrepare = new DispiteConfirmDetail();
                dispiteConfirmDetailPrepare.DetailId = Guid.NewGuid().ToString();
                dispiteConfirmDetailPrepare.ConfirmId = model.DispiteConfirm.ConfirmId;
                dispiteConfirmDetailPrepare.CheckType = "PREPARE";
                dispiteConfirmDetailPrepare.BusinessId = dispsiteCheckDetail.DetailId;
                dispiteConfirmDetailPrepare.ExplainContent = model.Prepare;
                this._DispiteConfirmDetailRepository.Create(dispiteConfirmDetailPrepare);
                //干混料制备及装桶固化
                DispiteConfirmDetail dispiteConfirmDetailSolid = new DispiteConfirmDetail();
                dispiteConfirmDetailSolid.DetailId = Guid.NewGuid().ToString();
                dispiteConfirmDetailSolid.ConfirmId = model.DispiteConfirm.ConfirmId;
                dispiteConfirmDetailSolid.CheckType = "SOLID";
                dispiteConfirmDetailSolid.BusinessId = dispsiteCheckDetail.DetailId;
                dispiteConfirmDetailSolid.ExplainContent = model.Solid;
                this._DispiteConfirmDetailRepository.Create(dispiteConfirmDetailSolid);
                //湿混料制备及封盖
                DispiteConfirmDetail dispiteConfirmDetailCover = new DispiteConfirmDetail();
                dispiteConfirmDetailCover.DetailId = Guid.NewGuid().ToString();
                dispiteConfirmDetailCover.ConfirmId = model.DispiteConfirm.ConfirmId;
                dispiteConfirmDetailCover.CheckType = "COVER";
                dispiteConfirmDetailCover.BusinessId = dispsiteCheckDetail.DetailId;
                dispiteConfirmDetailCover.ExplainContent = model.Cover;
                this._DispiteConfirmDetailRepository.Create(dispiteConfirmDetailCover);
                //废物运输及QT贮存
                DispiteConfirmDetail dispiteConfirmDetailTransfer = new DispiteConfirmDetail();
                dispiteConfirmDetailTransfer.DetailId = Guid.NewGuid().ToString();
                dispiteConfirmDetailTransfer.ConfirmId = model.DispiteConfirm.ConfirmId;
                dispiteConfirmDetailTransfer.CheckType = "TRANSFER";
                dispiteConfirmDetailTransfer.BusinessId = dispsiteCheckDetail.DetailId;
                dispiteConfirmDetailTransfer.ExplainContent = model.Transfer;
                this._DispiteConfirmDetailRepository.Create(dispiteConfirmDetailTransfer);
                //废物货包接收、检查
                DispiteConfirmDetail dispiteConfirmDetailReceive = new DispiteConfirmDetail();
                dispiteConfirmDetailReceive.DetailId = Guid.NewGuid().ToString();
                dispiteConfirmDetailReceive.ConfirmId = model.DispiteConfirm.ConfirmId;
                dispiteConfirmDetailReceive.CheckType = "RECEIVE";
                dispiteConfirmDetailReceive.BusinessId = dispsiteCheckDetail.DetailId;
                dispiteConfirmDetailReceive.ExplainContent = model.Receive;
                this._DispiteConfirmDetailRepository.Create(dispiteConfirmDetailReceive);
                //补充说明文件
                DispiteConfirmDetail dispiteConfirmDetailSupply = new DispiteConfirmDetail();
                dispiteConfirmDetailSupply.DetailId = Guid.NewGuid().ToString();
                dispiteConfirmDetailSupply.ConfirmId = model.DispiteConfirm.ConfirmId;
                dispiteConfirmDetailSupply.CheckType = "SUPPLY";
                dispiteConfirmDetailSupply.BusinessId = dispsiteCheckDetail.DetailId;
                dispiteConfirmDetailSupply.ExplainContent = model.Supply;
                this._DispiteConfirmDetailRepository.Create(dispiteConfirmDetailSupply);

            }
        }
       
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraft(NuclearRubFileVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubFile.FileId))
                {
                    DraftSave(model, "0", "");

                }
                //修改完新增
                else
                {
                    DraftUpdate(model, "0", "");
                }
                this._NuclearRubFileRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.NuclearRubFile.FileId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitDraft(NuclearRubFileVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubFile.FileId))
                {
                    DraftSave(model, "1", "");
                }
                //修改完新增
                else
                {
                    DraftUpdate(model, "1", "");
                }
                this._NuclearRubFileRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.NuclearRubFile.FileId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确定
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "档案生成确定")]
        public JsonResult ConfirmDraft(NuclearRubFileVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubFile.FileId))
                {
                    DraftSave(model, "2", "Confirm");

                }
                //修改完新增
                else
                {
                    DraftUpdate(model, "2", "Confirm");

                }
                this._NuclearRubFileRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.NuclearRubFile.FileId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确定失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 新增保存
        /// </summary>
        /// <param name="model"></param>
        private void DraftSave(NuclearRubFileVM model, string status, string type)
        {
            model.NuclearRubFile.FileId = Guid.NewGuid().ToString();
            model.NuclearRubFile.Status = status;
            model.NuclearRubFile.CreateDate = DateTime.Now;
            model.NuclearRubFile.CreateUserNo = AppContext.CurrentUser.UserId;
            model.NuclearRubFile.CreateUserName = AppContext.CurrentUser.UserName;
            model.NuclearRubFile.Stationcode = AppContext.CurrentUser.ProjectCode;
            if (type == "Confirm")
            {
                model.NuclearRubFile.ConfirmDate = DateTime.Now;
                model.NuclearRubFile.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.NuclearRubFile.ConfirmUserName = AppContext.CurrentUser.UserName;
            }
            this._NuclearRubFileRepository.Create(model.NuclearRubFile);

        }
        /// <summary>
        /// 修改保存
        /// </summary>
        /// <param name="model"></param>
        private void DraftUpdate(NuclearRubFileVM model, string status, string type)
        {

            model.NuclearRubFile = _NuclearRubFileRepository.Get(model.NuclearRubFile.FileId);
            UpdateModel(model);
            model.NuclearRubFile.Status = status;
            if (type == "Confirm")
            {
                model.NuclearRubFile.ConfirmDate = DateTime.Now;
                model.NuclearRubFile.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.NuclearRubFile.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.NuclearRubFile.Stationcode = AppContext.CurrentUser.ProjectCode;
            }
            this._NuclearRubFileRepository.Update(model.NuclearRubFile);


        }
        /// <summary>
        /// 初始化查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetNuclearRubFileList(NuclearRubFileCondition condition, string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<NuclearRubFileView> data = _NuclearRubFileRepository.QueryList(condition).AsQueryable().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.PackageStatus == "DEALED").OrderBy("CreateDate", SortDirection.Descending);
            var pagedViewModel = new PagedViewModel<NuclearRubFileView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.LocationId,
                    List = new List<object>() {
                        d.LocationId,
                        d.PackageCode,
                        d.BucketCode,
                        d.UnitId,
                        d.LocationX+"-"+d.LocationY+"-"+d.LocationZ,
                        d.ReceptionNo==null?d.ReceptionName: "【"+d.ReceptionNo+"】"+d.ReceptionName,
                        d.FileStatus
                       
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 废物货包质量确认删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult DeleteDispiteConfirm(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {

                    this._DispiteConfirmRepository.DeleteById(id);
                    List<DispiteConfirmDetail> dispiteConfirmDetailList = this._DispiteConfirmDetailRepository.GetAll().Where(d => d.ConfirmId == id).ToList();
                    if (dispiteConfirmDetailList.Count() > 0)
                    {
                        foreach (var item in dispiteConfirmDetailList)
                        {
                            this._DispiteConfirmDetailRepository.DeleteById(item.DetailId); 
                        }
                       
                    }

                }
                this._DispiteConfirmRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 档案生成删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult DeleteFile(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {

                    this._NuclearRubFileRepository.DeleteById(id);

                }
                this._NuclearRubFileRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }


        #region 废物货包质量确认导出
        /// <summary>
        /// 废物货包质量确认导出
        /// </summary>
        /// <param name="confirmId"></param>
        /// <returns></returns>
        public ActionResult Confirm(string id, string packageCode)
        {

            ToExcel(id, packageCode);
            return null;
        }

        private void ToExcel(string id, string packageCode)
      {

          //创建工作簿对象
          HSSFWorkbook hssfworkbook;
          //打开模板文件到文件流中
          using (FileStream file = new FileStream(System.Web.HttpContext.Current.Request.PhysicalApplicationPath + @"ExcelTemplate/WasteDisposal.xls", FileMode.Open, FileAccess.Read))
          {
              //将文件流中模板加载到工作簿对象中
              hssfworkbook = new HSSFWorkbook(file);
          }

          //建立一个名为Sheet1的工作表
          HSSFSheet sheet1 = (HSSFSheet)hssfworkbook.GetSheetAt(2);
          HSSFCellStyle cellstyle = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
          cellstyle.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
          cellstyle.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Justify;


            //获得数据
            DispiteConfirmVM vm = new DispiteConfirmVM();
            List<NuclearWastePackage> nuclearWastePackageList = this._NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode.Trim() && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (nuclearWastePackageList.Count() > 0)
            {
                //获得质量确认主表
                List<DispiteConfirm> dispiteConfirmList = _DispiteConfirmRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId).ToList();
                if (dispiteConfirmList.Count() > 0)
                {

                    DispiteConfirm dispiteConfirm = _DispiteConfirmRepository.Get(dispiteConfirmList[0].ConfirmId);
                    List<DispiteConfirmDetail> dispiteConfirmDetail = _DispiteConfirmDetailRepository.GetAll().Where(d => d.ConfirmId == dispiteConfirm.ConfirmId).ToList();
                    foreach (var item in dispiteConfirmDetail)
                    {
                        if (item.CheckType == "PREPARE")
                        {
                            vm.Prepare = item.ExplainContent;
                        }
                        if (item.CheckType == "SOLID")
                        {
                            vm.Solid = item.ExplainContent;
                        }
                        if (item.CheckType == "COVER")
                        {
                            vm.Cover = item.ExplainContent;
                        }
                        if (item.CheckType == "TRANSFER")
                        {
                            vm.Transfer = item.ExplainContent;
                        }
                        if (item.CheckType == "RECEIVE")
                        {
                            vm.Receive = item.ExplainContent;
                        }
                        if (item.CheckType == "SUPPLY")
                        {
                            vm.Supply = item.ExplainContent;
                        }

                    }
                    
                }
               
                //获得桶的信息
                List<NuclearBucket> nuclearBucketList = this._NuclearBucketRepository.GetAll().Where(d => d.BucketId == nuclearWastePackageList[0].BucketId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                if (nuclearBucketList.Count() > 0)
                {
                    vm.BucketCode = nuclearBucketList[0].BucketCode;
                    vm.WasteType = nuclearBucketList[0].WasteType;
                    vm.DealDate = nuclearBucketList[0].DealDate.HasValue ? nuclearBucketList[0].DealDate.Value.ToString("yyyy-MM-dd") : "";
                }
                //废物货包编号赋值
                vm.PackageCode = packageCode.Trim();
                //废物重量赋值
                List<NuclearRubLocation> nuclearRubLocationList = this._NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId && d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                if (nuclearRubLocationList.Count() > 0)
                {
                    vm.Weight = nuclearRubLocationList[0].Weight;
                }
                //废物货包接收、检查
                List<NuclearRubReceptionD> nuclearRubReceptionList = this._NuclearRubReceptionDRepository.GetAll().Where(d => d.PackageId == nuclearWastePackageList[0].PackageId).ToList();
                if (nuclearRubReceptionList.Count() > 0)
                {
                    vm.Isquelified = nuclearRubReceptionList[0].Isquelified;
                }
            }
            //获得审核结果数据
            List<DispiteConfirmView> dispiteConfirmViewList = this._DispiteConfirmRepository.QueryList().Where(d => d.PackageCode == packageCode.Trim()).ToList();
            if (dispiteConfirmViewList.Count() > 0)
            {
                vm.InspectIsrequired = dispiteConfirmViewList[0].InspectIsrequired;
                vm.BarrelIsrequired = dispiteConfirmViewList[0].BarrelIsrequired;
                vm.DoseIsrequired = dispiteConfirmViewList[0].DoseIsrequired;
                vm.TransferIsrequired = dispiteConfirmViewList[0].TransferIsrequired;
            }

           

            sheet1.GetRow(7).GetCell(0).SetCellValue(vm.BucketCode);
            sheet1.GetRow(7).GetCell(4).SetCellValue(vm.PackageCode);
            sheet1.GetRow(7).GetCell(8).SetCellValue(Convert.ToString(vm.Weight));
            sheet1.GetRow(7).GetCell(13).SetCellValue(vm.DealDate);
            sheet1.GetRow(7).GetCell(18).SetCellValue(vm.WasteType);
            if (vm.InspectIsrequired == "0")
            {
                sheet1.GetRow(14).GetCell(8).SetCellValue("不符合要求");
            }
            if (vm.InspectIsrequired == "1")
            {
                sheet1.GetRow(14).GetCell(8).SetCellValue("符合要求");
            }
            if (vm.BarrelIsrequired == "0")
            {
                sheet1.GetRow(16).GetCell(8).SetCellValue("不符合要求");
            }
            if (vm.BarrelIsrequired == "1")
            {
                sheet1.GetRow(16).GetCell(8).SetCellValue("符合要求");
            }

            if (vm.DoseIsrequired == "0")
            {
                sheet1.GetRow(18).GetCell(8).SetCellValue("不符合要求");
            }
            if (vm.DoseIsrequired == "1")
            {
                sheet1.GetRow(18).GetCell(8).SetCellValue("符合要求");
            }

            if (vm.TransferIsrequired == "0")
            {
                sheet1.GetRow(20).GetCell(8).SetCellValue("不符合要求");
            }
            if (vm.TransferIsrequired == "1")
            {
                sheet1.GetRow(20).GetCell(8).SetCellValue("符合要求");
            }


            if (vm.Isquelified == "0")
            {
                sheet1.GetRow(30).GetCell(8).SetCellValue("不符合要求");
            }
            if (vm.Isquelified == "1")
            {
                sheet1.GetRow(30).GetCell(8).SetCellValue("符合要求");
            }



            sheet1.GetRow(14).GetCell(10).SetCellValue(vm.Prepare);
            sheet1.GetRow(16).GetCell(10).SetCellValue(vm.Solid);
            sheet1.GetRow(18).GetCell(10).SetCellValue(vm.Cover);
            sheet1.GetRow(20).GetCell(10).SetCellValue(vm.Transfer);
            sheet1.GetRow(30).GetCell(10).SetCellValue(vm.Receive);
            sheet1.GetRow(34).GetCell(10).SetCellValue(vm.Supply);


            //强制Excel重新计算表中所有的公式
            sheet1.ForceFormulaRecalculation = true;
            //设置响应的类型为Excel
            Response.ContentType = "application/vnd.ms-excel";
            //设置下载的Excel文件名
            Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", "WasteDisposal.xls"));
            //Clear方法删除所有缓存中的HTML输出。但此方法只删除Response显示输入信息，不删除Response头信息。以免影响导出数据的完整性。
            Response.Clear();

            using (MemoryStream ms = new MemoryStream())
            {
                //将工作簿的内容放到内存流中
                hssfworkbook.Write(ms);
                //将内存流转换成字节数组发送到客户端
                Response.BinaryWrite(ms.GetBuffer());
                Response.End();
            }
        

    }

        #endregion
 
        #region 封面页将文件输出到页面
        /// <summary>
        /// 导出WORD格式的封面页
        /// </summary>
        /// <param name="outputId">出库单ID</param>
        /// <returns></returns>
        [HttpGet]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "封面页将文件输出到页面")]
        public ActionResult PrintCover(string fileId)
        {

            Export(fileId);
            return null;
        }
        /// <summary>
        /// 将文件输出到页面
        /// </summary>
        /// <param name="page"></param>
        /// <param name="fileStream">文件流</param>
        /// <param name="saveFileName">用户默认保存名称</param>
        private void Export(string fileId)
        {
            //根据Id求数据
            NuclearRubFile nuclearRubFile = this._NuclearRubFileRepository.Get(fileId);
            NuclearRubFileCondition condition = new NuclearRubFileCondition();
            NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(nuclearRubFile.PackageId);
            NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(nuclearWastePackage.BucketId);
            
            if (nuclearRubFile.SecrecyLevel == "Secrecy")
            {
                nuclearRubFile.SecrecyLevel = "机密";
            }
            if (nuclearRubFile.SecrecyLevel == "Restriction")
            {
                nuclearRubFile.SecrecyLevel = "限制使用";
            }
            XWPFDocument m_Docx = new XWPFDocument();
            //页面设置A4横向
            CT_SectPr m_SectPr = new CT_SectPr();
            m_SectPr.pgSz.w = (ulong)12906;
            m_Docx.Document.body.sectPr = m_SectPr;

            //设置标题
            XWPFParagraph p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.LEFT);
            XWPFRun r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("   CNPEP 记录");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(20);
            r1.SetTextPosition(100);
            //设置段落
            p0 = m_Docx.CreateParagraph();
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(30);
            r1.SetTextPosition(5);

            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.LEFT);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("      密级: "+nuclearRubFile.SecrecyLevel+"                                生成时间:");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(12);
            r1.SetTextPosition(8);

            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.LEFT);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("      记录保管期:  "+ nuclearRubFile.RecordDate +"");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(12);
            r1.SetTextPosition(8);

            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.LEFT);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("      记录存档:  " + nuclearRubFile.RecordFile + "                         文件页:         页");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(12);
            r1.SetTextPosition(80);

            p0 = m_Docx.CreateParagraph();
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(150);
            r1.SetTextPosition(5);

            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.CENTER);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("放 射 性 废 物 包 处 置 工 作 记 录");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(20);
            r1.SetTextPosition(100);

            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.LEFT);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("                 废物货包编码:   " + nuclearWastePackage.PackageCode + " ");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(12);
            r1.SetTextPosition(10);

            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.LEFT);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("                 废物桶号:  " + nuclearBucket.BucketCode + "");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(12);
            r1.SetTextPosition(10);

            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.LEFT);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("                 废物货包来源:  " + nuclearRubFile.PackageSource + "");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(12);
            r1.SetTextPosition(10);

            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.LEFT);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("                 废物货包产生年份:  还没做");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(12);
            r1.SetTextPosition(10);

            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.LEFT);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("                 近地表处置废物归类:  还没做");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(12);
            r1.SetTextPosition(300);

            p0 = m_Docx.CreateParagraph();
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(300);
            r1.SetTextPosition(4);

            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.CENTER);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("版权属于广东大亚湾核电环保有限公司财产，未经许可，不得复制");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(12);
            r1.SetTextPosition(10);
            p0 = m_Docx.CreateParagraph();
            p0.SetAlignment(ParagraphAlignment.CENTER);
            r1 = p0.CreateRun();
            r1.SetBold(true);
            r1.SetText("THIS IS THE PROPERTY OF GNPEP,THE DUPLICATION IS FORBIDDEN WITHOUT PERMISSIN");
            r1.SetBold(true);
            r1.SetFontFamily("Courier");
            r1.SetFontSize(10);
            r1.SetTextPosition(10);


            MemoryStream stream = new MemoryStream();
            m_Docx.Write(stream);

            string saveFileName = string.Format("{0}_{1}.doc", "PrintCover", DateTime.Now.ToString("yyyy-MM-dd"));
            string fileName = Server.MapPath("~") + "\\ExcelTemplate\\" + saveFileName;
            SaveToFile(stream, fileName);
            FileInfo downLoadFile = new FileInfo(fileName);
            System.Web.HttpContext context = System.Web.HttpContext.Current;
            context.Response.Clear();
            context.Response.ClearHeaders();
            context.Response.Buffer = false;
            context.Response.ContentType = "application/octet-stream";
            context.Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlDecode(saveFileName, System.Text.Encoding.UTF8));
            context.Response.AddHeader("content-length", downLoadFile.Length.ToString());
            context.Response.WriteFile(downLoadFile.FullName);
            context.Response.Flush();
            context.Response.End();
            if (System.IO.File.Exists(fileName))
            {
                System.IO.File.Delete(fileName);
            }

        }

      
        /// <summary>
        /// 跨列合并
        /// </summary>
        /// <param name="table"></param>
        /// <param name="row"></param>
        /// <param name="fromCell"></param>
        /// <param name="toCell"></param>
        public void mergeCellsHorizontal(XWPFTable table, int row, int fromCell, int toCell)
        {
            for (int cellIndex = fromCell; cellIndex <= toCell; cellIndex++)
            {
                XWPFTableCell cell = table.GetRow(row).GetCell(cellIndex);
                if (cellIndex == fromCell)
                {
                    // The first merged cell is set with RESTART merge value  
                    cell.GetCTTc().AddNewTcPr().AddNewHMerge().val = ST_Merge.restart;
                }
                else
                {
                    // Cells which join (merge) the first one, are set with CONTINUE  
                    cell.GetCTTc().AddNewTcPr().AddNewHMerge().val = ST_Merge.@continue;
                }
            }
        }

        /// <summary>
        /// 跨行融合
        /// </summary>
        /// <param name="table"></param>
        /// <param name="col"></param>
        /// <param name="fromRow"></param>
        /// <param name="toRow"></param>
        public void mergeCellsVertically(XWPFTable table, int col, int fromRow, int toRow)
        {
            for (int rowIndex = fromRow; rowIndex <= toRow; rowIndex++)
            {
                XWPFTableCell cell = table.GetRow(rowIndex).GetCell(col);
                if (rowIndex == fromRow)
                {
                    // The first merged cell is set with RESTART merge value  
                    cell.GetCTTc().AddNewTcPr().AddNewVMerge().val = ST_Merge.restart;
                }
                else
                {
                    // Cells which join (merge) the first one, are set with CONTINUE  
                    cell.GetCTTc().AddNewTcPr().AddNewVMerge().val = ST_Merge.@continue;
                }
            }
        }

        #endregion

        #region 汇总页将文件输出到页面
        /// <summary>
        /// 导出的汇总页
        /// </summary>
        /// <param name="outputId"></param>
        /// <returns></returns>
        [HttpGet]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "出库单导出")]
        public ActionResult PrintSummary(string fileId, string wastePackageCode)
        {

            ExportSummary(fileId, wastePackageCode);
            return null;
        }
       
       

      
        /// <summary>
        /// 汇总页
        /// </summary>
        /// <param name="page"></param>
        /// <param name="fileStream">文件流</param>
        /// <param name="saveFileName">用户默认保存名称</param>
        private void ExportSummary(string fileId, string wastePackageCode)
        {

            //创建工作簿对象
            XSSFWorkbook xssfworkbook;
            //打开模板文件到文件流中
            using (FileStream file = new FileStream(System.Web.HttpContext.Current.Request.PhysicalApplicationPath + @"ExcelTemplate/summary.xlsx", FileMode.Open, FileAccess.Read))
            {
                //将文件流中模板加载到工作簿对象中
                xssfworkbook = new XSSFWorkbook(file);
            }


            //根据废物包号得到废物包Id
            string packageCode = wastePackageCode.Trim();
            string bucketCode = string.Empty;
            string packageId = string.Empty;
            string bucketId = string.Empty;
            NuclearWastePackage wastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode && d.Stationcode == AppContext.CurrentUser.ProjectCode).FirstOrDefault();
            NuclearBucket nuclearBucket = null;
            if (wastePackage != null)
            {
                packageId = wastePackage.PackageId;
                bucketId = wastePackage.BucketId;
                nuclearBucket = _NuclearBucketRepository.Get(bucketId);
                bucketCode = nuclearBucket.BucketCode;
            }

            PrintUp printUp = new PrintUp();
            //封面页
            try
            {
                printUp.CoverOfPrint(fileId, xssfworkbook, packageCode, wastePackage, bucketId);
            }
            catch
            { }

            //废物包质量检查页
            try
            {
                printUp.QualityControl(fileId, xssfworkbook, bucketId);
            }
            catch
            { }

            //废物接收
            try
            {
                printUp.RubReceptionMethod(xssfworkbook, packageCode);
            }
            catch
            { }


            //北龙处置场废物包吊装定位单
            try
            {
                printUp.RubConsMethod(xssfworkbook, packageCode, bucketCode, packageId);
            }
            catch
            { }


            //放射性物质场内运输登记表
            try
            {
                printUp.TransportMethod(xssfworkbook, packageCode, bucketCode, packageId);
            }
            catch
            { }

            //QT厂房废物货包出库记录
            try
            {
                printUp.RubConsMethod(xssfworkbook, packageCode, bucketId, bucketCode, packageId);
            }
            catch
            { }

            //废物包质量检查
            try
            {
                printUp.DispiteConfirmMethod(xssfworkbook, packageCode, bucketCode, bucketId);
            }
            catch
            { }

            // 评估验算报表
            try
            {
                printUp.EvaluateMethod(xssfworkbook, wastePackage, nuclearBucket);
            }
            catch
            { }

            // DNMC封面页
            try
            {
                printUp.RecordMethod(xssfworkbook, packageCode, fileId);
            }
            catch { }

            PrintDown printDown = new PrintDown();
            //水泥桶准备
            try
            {
                printDown.CementPreparePrint(packageCode, xssfworkbook);
            }
            catch
            { }

            //湿混料制备及装通固定
            try
            {
                printDown.FixationPrint(packageCode, xssfworkbook);
            }
            catch
            { }

            //湿混料制备及封盖
            try
            {
                printDown.CoverMixPrint(packageCode, xssfworkbook);
            }
            catch
            { }

            //废物货包转运及QT贮存
            try
            {
                printDown.QTTransPrint(packageCode, xssfworkbook);
            }
            catch { }

            //循环水过滤器废物跟踪单
            try
            {
                printDown.CirculWaterFilterPrint(packageCode, xssfworkbook);
            }
            catch
            { }

            //活度计算单
            try
            {
                printDown.ActivityPrint(packageCode, xssfworkbook);
            }
            catch
            { }

            ////强制Excel重新计算表中所有的公式
            //sheet1.ForceFormulaRecalculation = true;
            //设置响应的类型为Excel
            Response.ContentType = "application/vnd.ms-excel";
            //设置下载的Excel文件名
            //string.Format("{0}_{1}.xls", stutas, DateTime.Now.ToString("yyyy-MM-dd"));
            Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}{1}", packageCode, ".xlsx"));
            //Clear方法删除所有缓存中的HTML输出。但此方法只删除Response显示输入信息，不删除Response头信息。以免影响导出数据的完整性。
            Response.Clear();

            using (MemoryStream ms = new MemoryStream())
            {
                //将工作簿的内容放到内存流中   
                xssfworkbook.Write(ms);
                //将内存流转换成字节数组发送到客户端
                Response.BinaryWrite(ms.GetBuffer());
                Response.End();
            }
        }
        
       
      
       
        #endregion
        
        private void SaveToFile(MemoryStream ms, string fileName)
        {
            using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write))
            {
                byte[] data = ms.ToArray();

                fs.Write(data, 0, data.Length);
                fs.Flush();
                data = null;
            }
        }
       
    }



}
