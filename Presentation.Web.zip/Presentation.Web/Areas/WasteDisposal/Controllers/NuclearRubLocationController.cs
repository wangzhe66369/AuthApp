﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View.NuclearRubLocation;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels;
using NET01.CoreFramework;
using RWIS.Domain.DomainObjects;
using System;
using System.Web;
using System.IO;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using NPOI.HSSF.UserModel;
using NPOI.HPSF;
using NPOI.SS.Util;
using RWIS.Presentation.Web.Core.Ftp;
using RWIS.Presentation.Web.Core;
using CIT.UPC.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using CIT.UPC.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.MaterialManage.Controllers;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.Controllers
{
    public class NuclearRubLocationController : Controller
    {

       INuclearRubLocationRepository _NuclearRubLocationRepository;
       IMaterialTypeRepository _MaterialTypeRepository;
       IBasicObjectRepository _BasicObjectRepository;
       INuclearWastePackageRepository _NuclearWastePackageRepository;
       INuclearBucketRepository _NuclearBucketRepository;
       public NuclearRubLocationController( INuclearRubLocationRepository _NuclearRubLocationRepository,
                                             IMaterialTypeRepository _MaterialTypeRepository,
                                        IBasicObjectRepository _BasicObjectRepository,
                                  INuclearWastePackageRepository _NuclearWastePackageRepository,
            INuclearBucketRepository _NuclearBucketRepository
           )
        {
            this._NuclearRubLocationRepository = _NuclearRubLocationRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
        }
        /// <summary>
        /// 初始页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物处置定位")]
        public ActionResult Index()
        {
            NuclearRubLocationVM vm = new NuclearRubLocationVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_Location");
            vm.BucketTypeList = new List<SelectListItem>();
            List<MaterialType> materialType = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.Status == "2").Where(d => d.IsBucket == "1").ToList();
            vm.BucketTypeList.Add(new SelectListItem { Text = "请选择", Value = "" });
            foreach (var item in materialType)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = item.MaterialName, Value = item.MaterialId });
            }

            return View(vm);
        }
        /// <summary>
        /// 增加页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Add()
        {
            NuclearRubLocationVM vm = new NuclearRubLocationVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_Location");
            vm.NuclearRubLocation = new NuclearRubLocation();
            vm.BucketTypeList = new List<SelectListItem>();
            vm.UnitCodeList = new List<SelectListItem>();
            vm.FlagRodiodList = new List<SelectListItem>();
            List<MaterialType> materialType = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.Status == "2").Where(d => d.IsBucket == "1").ToList();
            List<BasicObject> locationIdList = new List<BasicObject>();
            IQueryable<BasicObject> queryUnitCode = _BasicObjectRepository.GetSubobjectsByCode("UnitCode", AppContext.CurrentUser.ProjectCode);
            if (queryUnitCode != null && queryUnitCode.Count() > 0)
            {
                locationIdList = queryUnitCode.ToList();
            }
            foreach (var item in materialType)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = item.MaterialName, Value = item.MaterialId });
            }
            foreach (var item in locationIdList)
            {
                vm.UnitCodeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            vm.FlagRodiodList.Add(new SelectListItem { Text = "全水泥桶", Value = "1"});
            vm.FlagRodiodList.Add(new SelectListItem { Text = "全金属桶", Value = "2" });
            vm.FlagRodiodList.Add(new SelectListItem { Text = "金属方箱", Value = "3" });
            vm.FlagRodiodList.Add(new SelectListItem { Text = "混装", Value = "4" });

            return View(vm);
        }

        /// <summary>
        /// 选择定位
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "选择定位")]
        public ActionResult Position()
        {
            NuclearRubLocationVM vm = new NuclearRubLocationVM();
            vm.PointList = new List<PointData>();
            var LocationList = _NuclearRubLocationRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            var bucketList = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).ToList();
            var packageList = _NuclearWastePackageRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            for (int i = 1; i < 6; i++)
            {
                string a = i.ToString();
                string pointX = string.Empty;
                string pointY = string.Empty;
                string bucketCode = string.Empty;
                string packageCode = string.Empty;
                var qt = LocationList.Where(n => n.LocationZ.Contains(a)).ToList();
                for (int k = 0; k < qt.Count; k++)
                {
                    if (string.IsNullOrEmpty(qt[k].LocationX)) continue;
                    if (qt[k].LocationX.Contains(","))
                    {
                        string[] strX = qt[k].LocationX.Split(new char[] { ',' });
                        string[] strY = qt[k].LocationY.Split(new char[] { ',' });
                        int minX = Convert.ToInt32(strX[0]);
                        int maxX = Convert.ToInt32(strX[1]);
                        int minY = Convert.ToInt32(strY[0]);
                        int maxY = Convert.ToInt32(strY[1]);
                        for (int m = 0; m <= maxY - minY; m++)
                        {
                            for (int n = 0; n <= maxX - minX; n++)
                            {
                                pointX += (minX + n).ToString() + ",";
                                pointY += (minY + m).ToString() + ",";
                                var pList = packageList.Where(p => p.PackageId == qt[k].PackageId).ToList();
                                if (pList.Count > 0)
                                {
                                    packageCode += pList[0].PackageCode + ",";
                                    var bList = bucketList.Where(p => p.BucketId == pList[0].BucketId).ToList();
                                    if (bList.Count > 0)
                                        bucketCode += bList[0].BucketCode + ",";
                                    else
                                        bucketCode += "" + ",";
                                }
                                else
                                {
                                    packageCode += "" + ",";
                                }
                                  
                            }
                        }
                    }
                    else
                    {
                        pointX += qt[k].LocationX + ",";
                        pointY += qt[k].LocationY + ",";
                        var pList = packageList.Where(p => p.PackageId == qt[k].PackageId).ToList();
                        if (pList.Count > 0)
                        {
                            packageCode += pList[0].PackageCode + ",";
                            var bList = bucketList.Where(p => p.BucketId == pList[0].BucketId).ToList();
                            if (bList.Count > 0)
                                bucketCode += bList[0].BucketCode + ",";
                            else
                                bucketCode += "" + ",";
                        }
                        else
                        {
                            packageCode += "" + ",";
                        }
                    }
                }
                pointX = pointX.TrimEnd(new char[] { ',' });
                pointY = pointY.TrimEnd(new char[] { ',' });
                PointData point = new PointData();
                point.PointX = pointX;
                point.PointY = pointY;
                point.BucketCode = bucketCode;
                point.PackageCode = packageCode;
                point.PointZ = a;
                vm.PointList.Add(point);
            }
            return View(vm);
        }
        /// <summary>
        /// 查看页面
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DetailView(string id)
        {
            NuclearRubLocationVM vm = new NuclearRubLocationVM();

            NuclearRubLocation nuclearRubLocation = _NuclearRubLocationRepository.Get(id);
            if (nuclearRubLocation != null)
            {
                vm.NuclearRubLocation = nuclearRubLocation;
                NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(vm.NuclearRubLocation.PackageId);
                BasicObject unitCode = _BasicObjectRepository.Get(vm.NuclearRubLocation.UnitCode);
                MaterialType materialType = _MaterialTypeRepository.Get(vm.NuclearRubLocation.BucketTypeId);
                //废物货包id转成废物货包号
                vm.NuclearRubLocation.PackageId = nuclearWastePackage.PackageCode;
                vm.NuclearRubLocation.UnitCode = unitCode.Name;
                vm.NuclearRubLocation.BucketTypeId = materialType.MaterialName;

                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = GetAttachFileBy(id, "QuestionReport");
                vm.LocationAttachment = (List<AttachFile>)listAttachFile;
                ViewBag.BusinessType = "QuestionReport";
            }
            else {
                vm.NuclearRubLocation = new NuclearRubLocation();
            }
           

            return View(vm);
        }
        /// <summary>
        /// 编辑页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Edit(string packageCode)
        {
            NuclearRubLocationVM vm = new NuclearRubLocationVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_Location");

            List<NuclearWastePackage> nuclearWastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == packageCode).ToList();
            if (nuclearWastePackage.Count() > 0)
            {
                List<NuclearRubLocation> nuclearRubLocation = _NuclearRubLocationRepository.GetAll().Where(d => d.PackageId == nuclearWastePackage[0].PackageId).ToList();
                if (nuclearRubLocation.Count > 0)
                {
                    vm.NuclearRubLocation = nuclearRubLocation[0];

                    IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                    IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(nuclearRubLocation[0].LocationId, "QuestionReport");
                    vm.LocationAttachment = (List<AttachFile>)listAttachFile;
                    ViewBag.BusinessType = "QuestionReport";
                }
                else
                {
                    vm.NuclearRubLocation = new NuclearRubLocation();
                }
                vm.NuclearRubLocation.PackageId = nuclearWastePackage[0].PackageId;
            }

           // NuclearRubLocation nuclearRubLocation = _NuclearRubLocationRepository.Get(id);
            //根据废物货包编号求废物货包Id
            //NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(nuclearRubLocation.PackageId);
            //nuclearRubLocation.PackageId = nuclearWastePackage.PackageCode;
           
            vm.BucketTypeList = new List<SelectListItem>();
            vm.UnitCodeList = new List<SelectListItem>();
            vm.FlagRodiodList = new List<SelectListItem>();
            List<MaterialType> materialType = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.Status == "2").Where(d => d.IsBucket == "1").ToList();
            List<BasicObject> locationIdList = new List<BasicObject>();
            IQueryable<BasicObject> queryUnitCode = _BasicObjectRepository.GetSubobjectsByCode("UnitCode", AppContext.CurrentUser.ProjectCode);
            if (queryUnitCode != null && queryUnitCode.Count() > 0)
            {
                locationIdList = queryUnitCode.ToList();
            }
            foreach (var item in materialType)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = item.MaterialName, Value = item.MaterialId });
            }
            foreach (var item in locationIdList)
            {
                vm.UnitCodeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            vm.FlagRodiodList.Add(new SelectListItem { Text = "全水泥桶", Value = "1" });
            vm.FlagRodiodList.Add(new SelectListItem { Text = "全金属桶", Value = "2" });
            vm.FlagRodiodList.Add(new SelectListItem { Text = "金属方箱", Value = "3" });
            vm.FlagRodiodList.Add(new SelectListItem { Text = "混装", Value = "4" });

            vm.PointList = new List<PointData>();
            var LocationList = _NuclearRubLocationRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            for (int i = 1; i < 6; i++)
            {
                string a = i.ToString();
                string pointX = string.Empty;
                string pointY = string.Empty;
                var qt = LocationList.Where(n => n.LocationZ.Contains(a)).ToList();
                for (int k = 0; k < qt.Count; k++)
                {
                    if (string.IsNullOrEmpty(qt[k].LocationX)) continue;
                    if (qt[k].LocationX.Contains(","))
                    {
                        string[] strX = qt[k].LocationX.Split(new char[] { ',' });
                        string[] strY = qt[k].LocationY.Split(new char[] { ',' });
                        int minX = Convert.ToInt32(strX[0]);
                        int maxX = Convert.ToInt32(strX[1]);
                        int minY = Convert.ToInt32(strY[0]);
                        int maxY = Convert.ToInt32(strY[1]);
                        for (int m = 0; m <= maxY - minY; m++)
                        {
                            for (int n = 0; n <= maxX - minX; n++)
                            {
                                pointX += (minX + n).ToString() + ",";
                                pointY += (minY + m).ToString() + ",";
                            }
                        }
                    }
                    else
                    {
                        pointX += qt[k].LocationX + ",";
                        pointY += qt[k].LocationY + ",";
                    }
                }
                pointX = pointX.TrimEnd(new char[] { ',' });
                pointY = pointY.TrimEnd(new char[] { ',' });
                PointData point = new PointData();
                point.PointX = pointX;
                point.PointY = pointY;
                point.PointZ = a;
                vm.PointList.Add(point);

            }
            ViewBag.packageCode = packageCode;
           
            return View("Add",vm);
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraft(NuclearRubLocationVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubLocation.LocationId))
                {
                    string message = DraftSave(model, "0", "");
                    if (message.Equals("NoRecept"))
                    {
                        return Json("{\"result\":false,\"msg\":\"没有被接收。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("DEALED"))
                    {
                        return Json("{\"result\":false,\"msg\":\"已处置。\"}", JsonRequestBehavior.AllowGet);
                    }

                }
                //修改完新增
                else
                {
                    string message = DraftUpdate(model, "0", "");
                    if (message.Equals("NoRecept"))
                    {
                        return Json("{\"result\":false,\"msg\":\"没有被接收。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("DEALED"))
                    {
                        return Json("{\"result\":false,\"msg\":\"已处置。\"}", JsonRequestBehavior.AllowGet);
                    }

                }
                this._NuclearRubLocationRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.NuclearRubLocation.LocationId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitDraft(NuclearRubLocationVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubLocation.LocationId))
                {
                    string message = DraftSave(model, "1", "");
                    if (message.Equals("NoRecept"))
                    {
                        return Json("{\"result\":false,\"msg\":\"没有被接收。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("DEALED"))
                    {
                        return Json("{\"result\":false,\"msg\":\"已处置。\"}", JsonRequestBehavior.AllowGet);
                    }
                  
                }
                //修改完新增
                else
                {
                    string message = DraftUpdate(model, "1", "");
                    if (message.Equals("NoRecept"))
                    {
                        return Json("{\"result\":false,\"msg\":\"没有被接收。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("DEALED"))
                    {
                        return Json("{\"result\":false,\"msg\":\"已处置。\"}", JsonRequestBehavior.AllowGet);
                    }
                   
                }
                this._NuclearRubLocationRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.NuclearRubLocation.LocationId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确定
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物处置定位确认")]
        public JsonResult ConfirmDraft(NuclearRubLocationVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubLocation.LocationId))
                {
                    string message = DraftSave(model, "2", "Confirm");
                    if (message.Equals("NoRecept"))
                    {
                        return Json("{\"result\":false,\"msg\":\"没有被接收。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("DEALED"))
                    {
                        return Json("{\"result\":false,\"msg\":\"已处置。\"}", JsonRequestBehavior.AllowGet);
                    }

                }
                //修改完新增
                else
                {
                    string message = DraftUpdate(model, "2", "Confirm");
                    if (message.Equals("NoRecept"))
                    {
                        return Json("{\"result\":false,\"msg\":\"没有被接收。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("DEALED"))
                    {
                        return Json("{\"result\":false,\"msg\":\"已处置。\"}", JsonRequestBehavior.AllowGet);
                    }

                }
                this._NuclearRubLocationRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.NuclearRubLocation.LocationId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确定失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 新增保存
        /// </summary>
        /// <param name="model"></param>
        private string DraftSave(NuclearRubLocationVM model,string status, string type)
        {

                NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(model.NuclearRubLocation.PackageId);
                if (nuclearWastePackage.Status == "RECEPTED")
                {

                    model.NuclearRubLocation.LocationId = Guid.NewGuid().ToString();
                    model.NuclearRubLocation.Status = status;
                    model.NuclearRubLocation.PackageId = nuclearWastePackage.PackageId;
                    model.NuclearRubLocation.LocationX = model.pointX;
                    model.NuclearRubLocation.LocationY = model.pointY;
                    string z = string.Empty;
                    for (int i = Convert.ToInt32(model.pointZ1); i <= Convert.ToInt32(model.pointZ1) - Convert.ToInt32(model.pointZ2); i++)
			        {
                        z = model.pointZ1 + "i";
			        }
                    model.NuclearRubLocation.LocationZ = z;
                    model.NuclearRubLocation.CreateDate = DateTime.Now;
                    model.NuclearRubLocation.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearRubLocation.CreateUserName = AppContext.CurrentUser.UserName;
                    model.NuclearRubLocation.Stationcode = AppContext.CurrentUser.ProjectCode;
                    if (type == "Confirm")
                    {
                        model.NuclearRubLocation.ConfirmDate = DateTime.Now;
                        model.NuclearRubLocation.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        model.NuclearRubLocation.ConfirmUserName = AppContext.CurrentUser.UserName;
                        nuclearWastePackage.Status = "DEALED";
                        this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                    }
                    this._NuclearRubLocationRepository.Create(model.NuclearRubLocation);
                }
                else if (nuclearWastePackage.Status == "DEALED")
                {
                    return "DEALED";
                }
                else
                {
                    return "NoRecept";
                }

            
            return "Success";
        }
        /// <summary>
        /// 修改保存
        /// </summary>
        /// <param name="model"></param>
        private string DraftUpdate(NuclearRubLocationVM model, string status, string type)
        {
             
                 model.NuclearRubLocation = _NuclearRubLocationRepository.Get(model.NuclearRubLocation.LocationId);
                 NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(model.NuclearRubLocation.PackageId);
                 if (model.NuclearRubLocation.Status == "2")
                 {
                     nuclearWastePackage.Status = "RECEPTED";
                     this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                 }
                 if (nuclearWastePackage.Status == "RECEPTED")
                 {
                     
                     UpdateModel(model);
                     model.NuclearRubLocation.Status = status;
                     model.NuclearRubLocation.PackageId = nuclearWastePackage.PackageId;
                     model.NuclearRubLocation.LocationX = model.pointX;
                     model.NuclearRubLocation.LocationY = model.pointY;
                     string z = string.Empty;
                     for (int i = 0; i <= Convert.ToInt32(model.pointZ2) - Convert.ToInt32(model.pointZ1); i++)
                     {
                         if (Convert.ToInt32(model.pointZ2) - Convert.ToInt32(model.pointZ1) == 0)
                         {
                             z = model.pointZ2;
                         }
                         else
                         {
                             z = z + (Convert.ToInt32(model.pointZ1) + i);
                         }


                     }
                     model.NuclearRubLocation.LocationZ = z;
                     if (type == "Confirm")
                     {
                         model.NuclearRubLocation.ConfirmDate = DateTime.Now;
                         model.NuclearRubLocation.ConfirmUserNo = AppContext.CurrentUser.UserId;
                         model.NuclearRubLocation.ConfirmUserName = AppContext.CurrentUser.UserName;
                         model.NuclearRubLocation.Stationcode = AppContext.CurrentUser.ProjectCode;
                         nuclearWastePackage.Status = "DEALED";
                         this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                     }
                     this._NuclearRubLocationRepository.Update(model.NuclearRubLocation);
                 }
                 else if (nuclearWastePackage.Status == "DEALED")
                 {
                     return "DEALED";
                 }
                 else
                 {
                     return "NoRecept";
                 }

             
             return "Success";
        }
        /// <summary>
        /// 初始化查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetNuclearRubLocationList(NuclearRubLocationCondition condition , string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            if (!string.IsNullOrEmpty(condition.LocationXZY))
            {
                string[] arr = condition.LocationXZY.Split(new char[] { '-' });
                if (arr.Length == 1)
                {
                    condition.LocationX = arr[0];
                }
                if (arr.Length == 2)
                {
                    condition.LocationX = arr[0];
                    condition.LocationY = arr[1];
                }
                if (arr.Length == 3)
                {
                    condition.LocationX = arr[0];
                    condition.LocationY = arr[1];
                    condition.LocationZ = arr[2];
                }
               
            }

            IQueryable<NuclearRubLocationView> data = _NuclearRubLocationRepository.QueryList(condition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.WastePackageStatus == "RECEPTED" || d.WastePackageStatus == "DEALED").OrderBy("CreateDate", SortDirection.Descending);
            var pagedViewModel = new PagedViewModel<NuclearRubLocationView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.LocationId,
                    List = new List<object>() {                      
                        d.LocationId,
                        d.PackageCode,
                        d.IdentityCode,
                        d.UnitCode,
                        d.BucketTypeName,
                        d.LocationX+"-"+d.LocationY+"-"+d.LocationZ,
                        d.Weight,
                        d.ProcessNo==null?d.ProcessName: "【"+d.ProcessNo+"】"+d.ProcessName,
                        d.Status
                       
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 删除材料
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearRubLocation nuclearRubLocation = _NuclearRubLocationRepository.Get(idVal);
                        NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(nuclearRubLocation.PackageId);
                        nuclearWastePackage.Status = "RECEPTED";
                        this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                        this._NuclearRubLocationRepository.DeleteById(idVal);
                        
                    }
                    this._NuclearRubLocationRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 导出WORD格式的封面页
        /// </summary>
        /// <param name="outputId">出库单ID</param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "打印处置定位")]
        public ActionResult PrintRubLocation(string id)
        {
           
            Export(id);
            return null;
        }
         #region 封面页将文件输出到页面
        /// <summary>
        /// 将文件输出到页面
        /// </summary>
        /// <param name="page"></param>
        /// <param name="fileStream">文件流</param>
        /// <param name="saveFileName">用户默认保存名称</param>
        private void Export(string id)
        {


                //创建文档对象
                HSSFWorkbook hssfworkbook = new HSSFWorkbook();
                //然后创建DocumentSummaryInformation
                DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();
                dsi.Company = "NPOI Team";
                // 再创建SummaryInformation
                SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
                si.Subject = "NPOI SDK Example";

                // 创建好的对象赋给Workbook 保证这些信息被写入文件。
                hssfworkbook.DocumentSummaryInformation = dsi;
                hssfworkbook.SummaryInformation = si;
                //创建工作表
                HSSFSheet sheet1 = (HSSFSheet)hssfworkbook.CreateSheet("Sheet1");
                //创建行
                HSSFRow row1 = (HSSFRow)sheet1.CreateRow(0);
                HSSFRow row2 = (HSSFRow)sheet1.CreateRow(1);
                HSSFRow row3 = (HSSFRow)sheet1.CreateRow(2);
                HSSFRow row4 = (HSSFRow)sheet1.CreateRow(3);
                HSSFRow row5 = (HSSFRow)sheet1.CreateRow(4);
                HSSFRow row6 = (HSSFRow)sheet1.CreateRow(5);
                HSSFRow row7 = (HSSFRow)sheet1.CreateRow(6);
                HSSFRow row8 = (HSSFRow)sheet1.CreateRow(7);
                HSSFRow row9 = (HSSFRow)sheet1.CreateRow(8);
                HSSFRow row10 = (HSSFRow)sheet1.CreateRow(9);
                HSSFRow row11 = (HSSFRow)sheet1.CreateRow(10);
                HSSFRow row12 = (HSSFRow)sheet1.CreateRow(11);
                HSSFRow row13 = (HSSFRow)sheet1.CreateRow(12);
                HSSFRow row14 = (HSSFRow)sheet1.CreateRow(13);
                HSSFRow row15 = (HSSFRow)sheet1.CreateRow(14);
                HSSFRow row16 = (HSSFRow)sheet1.CreateRow(15);
                HSSFRow row17 = (HSSFRow)sheet1.CreateRow(16);
                HSSFRow row18 = (HSSFRow)sheet1.CreateRow(17);
                HSSFRow row19 = (HSSFRow)sheet1.CreateRow(18);
                HSSFRow row20 = (HSSFRow)sheet1.CreateRow(19);
                HSSFRow row21 = (HSSFRow)sheet1.CreateRow(20);
                HSSFRow row22 = (HSSFRow)sheet1.CreateRow(21);
                HSSFRow row23 = (HSSFRow)sheet1.CreateRow(22);
                HSSFRow row24 = (HSSFRow)sheet1.CreateRow(23);
                HSSFRow row25 = (HSSFRow)sheet1.CreateRow(24);
                HSSFRow row26 = (HSSFRow)sheet1.CreateRow(25);
                //设置列宽 
                sheet1.SetColumnWidth(0, 80 * 100);
                sheet1.SetColumnWidth(1, 80 * 100);
                sheet1.SetColumnWidth(2, 80 * 100);
                sheet1.SetColumnWidth(3, 80 * 100);

                //行高
                sheet1.CreateRow(0).Height = 30 * 20;
                sheet1.CreateRow(1).Height = 30 * 20;
                sheet1.CreateRow(2).Height = 30 * 20;
                sheet1.CreateRow(3).Height = 30 * 20;
                sheet1.CreateRow(4).Height = 30 * 20;
                sheet1.CreateRow(5).Height = 30 * 20;
                sheet1.CreateRow(6).Height = 30 * 20;
                sheet1.CreateRow(7).Height = 30 * 20;
                sheet1.CreateRow(8).Height = 30 * 20;
                sheet1.CreateRow(9).Height = 30 * 20;
                sheet1.CreateRow(10).Height = 30 * 20;
                sheet1.CreateRow(11).Height = 80 * 20;
                sheet1.CreateRow(12).Height = 30 * 20;
                sheet1.CreateRow(13).Height = 30 * 20;
                sheet1.CreateRow(14).Height = 30 * 20;
                sheet1.CreateRow(15).Height = 30 * 20;
                sheet1.CreateRow(16).Height = 30 * 20;
                sheet1.CreateRow(17).Height = 30 * 20;
              
             


                //单元格样式——正文左对齐
                HSSFCellStyle style2 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style2.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
                style2.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                style2.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                style2.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
                style2.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
                style2.Indention = 2;
                style2.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;//垂直居中
                HSSFFont font21 = (HSSFFont)hssfworkbook.CreateFont();
                font21.FontHeight = 11 * 20;//字体高度
                style2.WrapText = true;//自动换行
                style2.SetFont(font21);
                //单元格样式——正文居中
                HSSFCellStyle style3 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style3.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
                style3.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                style3.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                style3.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
                style3.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;//水平居中
                style3.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;//垂直居中
                HSSFFont font3 = (HSSFFont)hssfworkbook.CreateFont();
                font3.FontHeight = 11 * 20;//字体高度
                style3.WrapText = true;//自动换行
                style3.SetFont(font3);
                //单元格样式——正文无右边框
                HSSFCellStyle style4 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style4.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
                style4.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                style4.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
                style4.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;//水平居中
                style4.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;//垂直居中
                HSSFFont font4 = (HSSFFont)hssfworkbook.CreateFont();
                font4.FontHeight = 11 * 20;//字体高度
                style4.WrapText = true;//自动换行
                style4.SetFont(font4);
                //单元格样式——正文无左边框
                HSSFCellStyle style5 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style5.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
                style5.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
                style5.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                style5.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;//水平居中
                style5.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;//垂直居中
                HSSFFont font5 = (HSSFFont)hssfworkbook.CreateFont();
                font5.FontHeight = 11 * 20;//字体高度
                style5.WrapText = true;//自动换行
                style5.SetFont(font5);
                //单元格样式——正文无上边框
                HSSFCellStyle style6 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style6.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
                style6.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                style6.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                style6.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;//水平居左
                style6.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;//垂直居中
                style6.Indention = 2;
                HSSFFont font6 = (HSSFFont)hssfworkbook.CreateFont();
                font6.FontHeight = 11 * 20;//字体高度
                style6.WrapText = true;//自动换行
                style6.SetFont(font6);
               
               //单元格样式——正文无下边框
                HSSFCellStyle style7 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style7.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                style7.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                style7.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
                style7.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;//水平居左
                style7.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;//垂直居中
                style7.Indention = 2;
                HSSFFont font7 = (HSSFFont)hssfworkbook.CreateFont();
                font7.FontHeight = 11 * 20;//字体高度
                style7.WrapText = true;//自动换行
                style7.SetFont(font7);
                //单元格样式——正文只有左边框
                HSSFCellStyle style8 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style8.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                style8.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;//水平居中
                style8.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;//垂直居中
                HSSFFont font8 = (HSSFFont)hssfworkbook.CreateFont();
                font8.FontHeight = 11 * 20;//字体高度
                style8.WrapText = true;//自动换行
                style8.SetFont(font8);
                //单元格样式——正文居中
                HSSFCellStyle style9 = (HSSFCellStyle)hssfworkbook.CreateCellStyle();
                style9.BorderBottom = NPOI.SS.UserModel.BorderStyle.Thin;
                style9.BorderLeft = NPOI.SS.UserModel.BorderStyle.Thin;
                style9.BorderRight = NPOI.SS.UserModel.BorderStyle.Thin;
                style9.BorderTop = NPOI.SS.UserModel.BorderStyle.Thin;
                style9.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Left;
                style9.Indention = 2;
                style9.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Top;//垂直居中
                HSSFFont font9 = (HSSFFont)hssfworkbook.CreateFont();
                font9.FontHeight = 13 * 20;//字体高度
                style9.WrapText = true;//自动换行
                style9.SetFont(font9);




                //合并单元格（起始行号、终止行号、起始列号、终止列号）
                sheet1.AddMergedRegion(new CellRangeAddress(0, 0, 0, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(1, 1, 0, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(2, 2, 0, 1));
                sheet1.AddMergedRegion(new CellRangeAddress(2, 2, 2, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(3, 3, 0, 1));
                sheet1.AddMergedRegion(new CellRangeAddress(3, 3, 2, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(4, 4, 0, 1));
                sheet1.AddMergedRegion(new CellRangeAddress(4, 4, 2, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(5, 5, 0, 1));
                sheet1.AddMergedRegion(new CellRangeAddress(5, 5, 2, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(6, 6, 0, 1));
                sheet1.AddMergedRegion(new CellRangeAddress(6, 6, 2, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(7, 7, 0, 1));
                sheet1.AddMergedRegion(new CellRangeAddress(7, 7, 2, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(8, 8, 0, 1));
                sheet1.AddMergedRegion(new CellRangeAddress(8, 8, 2, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(9, 9, 0, 1));
                sheet1.AddMergedRegion(new CellRangeAddress(9, 9, 2, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(10, 10, 0, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(11, 11, 0, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(12, 12, 0, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(13, 13, 0, 3));
                sheet1.AddMergedRegion(new CellRangeAddress(14, 14, 0, 3));

                List<NuclearRubLocation> nuclearRubLocation = this._NuclearRubLocationRepository.GetAll().Where(d => d.LocationId==id).ToList();
                NuclearWastePackage nuclearWastePackage=null;
                NuclearBucket nuclearBucket=null;
                BasicObject basicObject=null;
                if (nuclearRubLocation.Count() > 0)
                {
                    nuclearWastePackage= this._NuclearWastePackageRepository.Get(nuclearRubLocation[0].PackageId);
                    nuclearBucket = this._NuclearBucketRepository.Get(nuclearWastePackage.BucketId);
                    basicObject = this._BasicObjectRepository.Get(nuclearRubLocation[0].UnitCode);
                    
                }
                //创建列
                HSSFCell cell000 = (HSSFCell)row1.CreateCell(0);
                if (nuclearBucket != null)
                {
                    cell000.SetCellValue("包装容器编码:               " + nuclearBucket.BucketCode);

                }
                else
                {
                    cell000.SetCellValue("包装容器编码:               " );
                }
                HSSFCell cell001 = (HSSFCell)row1.CreateCell(1);
                HSSFCell cell002 = (HSSFCell)row1.CreateCell(2);
                HSSFCell cell003 = (HSSFCell)row1.CreateCell(3);
                cell000.CellStyle = style2;
                cell001.CellStyle = style2;
                cell002.CellStyle = style2;
                cell003.CellStyle = style2;
                //创建列
                HSSFCell cell010 = (HSSFCell)row2.CreateCell(0);
                if (nuclearWastePackage != null)
                {
                    cell010.SetCellValue("      废物货包编码:              " + nuclearWastePackage.PackageCode);
                }
                else {
                    cell010.SetCellValue("      废物货包编码:              " );
                }
               
                HSSFCell cell011 = (HSSFCell)row2.CreateCell(1);
                HSSFCell cell012 = (HSSFCell)row2.CreateCell(2);
                HSSFCell cell013 = (HSSFCell)row2.CreateCell(3);
                cell010.CellStyle = style2;
                cell011.CellStyle = style2;
                cell012.CellStyle = style2;
                cell013.CellStyle = style2;
                //创建列
                HSSFCell cell020 = (HSSFCell)row3.CreateCell(0);
                cell020.SetCellValue("码放设计位置");
                HSSFCell cell021 = (HSSFCell)row3.CreateCell(1);
                HSSFCell cell022 = (HSSFCell)row3.CreateCell(2);
                cell022.SetCellValue("吊装操作人员确认");
                HSSFCell cell023 = (HSSFCell)row3.CreateCell(3);
                cell020.CellStyle = style3;
                cell021.CellStyle = style3;
                cell022.CellStyle = style3;
                cell023.CellStyle = style3  ;
                //创建列
                HSSFCell cell030 = (HSSFCell)row4.CreateCell(0);
                if (basicObject!=null)
                {
                 
                   cell030.SetCellValue("起吊位置:                 " + basicObject.Name);
                }
                else
                {
                    cell030.SetCellValue("起吊位置");
                }
                
                HSSFCell cell031 = (HSSFCell)row4.CreateCell(1);
                HSSFCell cell032 = (HSSFCell)row4.CreateCell(2);
                cell032.SetCellValue("是                  否                      改为:");
                HSSFCell cell033 = (HSSFCell)row4.CreateCell(3);
                cell030.CellStyle = style2;
                cell031.CellStyle = style2;
                cell032.CellStyle = style2;
                cell033.CellStyle = style2;
                //创建列
                HSSFCell cell040 = (HSSFCell)row5.CreateCell(0);
                if (basicObject != null)
                {
                    cell040.SetCellValue("目标处置单元:                 "+basicObject.Name);
                }
                else
                {
                    cell040.SetCellValue("目标处置单元:                 ");
                }
               
                HSSFCell cell041 = (HSSFCell)row5.CreateCell(1);
                HSSFCell cell042 = (HSSFCell)row5.CreateCell(2);
                cell042.SetCellValue("是                  否                      改为:");
                HSSFCell cell043 = (HSSFCell)row5.CreateCell(3);
                cell040.CellStyle = style2;
                cell041.CellStyle = style2;
                cell042.CellStyle = style2;
                cell043.CellStyle = style2;
                //创建列
                HSSFCell cell050 = (HSSFCell)row6.CreateCell(0);
                cell050.SetCellValue("坐标位置:");
                HSSFCell cell051 = (HSSFCell)row6.CreateCell(1);
                HSSFCell cell052 = (HSSFCell)row6.CreateCell(2);
                HSSFCell cell053 = (HSSFCell)row6.CreateCell(3);
                cell050.CellStyle = style7;
                cell051.CellStyle = style7;
                cell052.CellStyle = style7;
                cell053.CellStyle = style7;
                //创建列
                HSSFCell cell060 = (HSSFCell)row7.CreateCell(0);
                if (nuclearRubLocation.Count() > 0)
                {
                    cell060.SetCellValue("X:        "+nuclearRubLocation[0].LocationX);
                }
                else
                {
                    cell060.SetCellValue("X:");
                }
                HSSFCell cell061 = (HSSFCell)row7.CreateCell(1);
                HSSFCell cell062 = (HSSFCell)row7.CreateCell(2);
                cell062.SetCellValue("是                   否                     改为:");
                HSSFCell cell063 = (HSSFCell)row7.CreateCell(3);
                cell060.CellStyle = style8;
                cell061.CellStyle = style8;
                cell062.CellStyle = style6;
                cell063.CellStyle = style6;
                //创建列
                HSSFCell cell070 = (HSSFCell)row8.CreateCell(0);
                if (nuclearRubLocation.Count() > 0)
                {
                    cell070.SetCellValue("Y:        " + nuclearRubLocation[0].LocationY);
                }
                else
                {
                    cell070.SetCellValue("Y:        ");
                }
                HSSFCell cell071 = (HSSFCell)row8.CreateCell(1);
                HSSFCell cell072 = (HSSFCell)row8.CreateCell(2);
                cell072.SetCellValue("是                   否                     改为:");
                HSSFCell cell073 = (HSSFCell)row8.CreateCell(3);
                cell070.CellStyle = style8;
                cell071.CellStyle = style8;
                cell072.CellStyle = style2;
                cell073.CellStyle = style2;
                //创建列
                HSSFCell cell080 = (HSSFCell)row9.CreateCell(0);
                if (nuclearRubLocation.Count() > 0)
                {
                    cell080.SetCellValue("Z:        " + nuclearRubLocation[0].LocationZ);
                }
                else
                {
                    cell080.SetCellValue("Z:");
                }
               
                HSSFCell cell081 = (HSSFCell)row9.CreateCell(1);
                HSSFCell cell082 = (HSSFCell)row9.CreateCell(2);
                cell082.SetCellValue("是                   否                     改为:");
                HSSFCell cell083 = (HSSFCell)row9.CreateCell(3);
                cell080.CellStyle = style8;
                cell081.CellStyle = style8;
                cell082.CellStyle = style2;
                cell083.CellStyle = style2;
                //创建列
                HSSFCell cell090 = (HSSFCell)row10.CreateCell(0);
                cell090.SetCellValue("设计人(签字):");
                HSSFCell cell091 = (HSSFCell)row10.CreateCell(1);
                HSSFCell cell092 = (HSSFCell)row10.CreateCell(2);
                HSSFCell cell093 = (HSSFCell)row10.CreateCell(3);
                cell090.CellStyle = style2;
                cell091.CellStyle = style2;
                cell092.CellStyle = style2;
                cell093.CellStyle = style2;
                //创建列
                HSSFCell cell100 = (HSSFCell)row11.CreateCell(0);
                cell100.SetCellValue("异常情况说明:");
                HSSFCell cell101 = (HSSFCell)row11.CreateCell(1);
                HSSFCell cell102 = (HSSFCell)row11.CreateCell(2);
                HSSFCell cell103 = (HSSFCell)row11.CreateCell(3);
                cell100.CellStyle = style7;
                cell101.CellStyle = style7;
                cell102.CellStyle = style7;
                cell103.CellStyle = style7;
                //创建列
                HSSFCell cell110 = (HSSFCell)row12.CreateCell(0);
                HSSFCell cell111 = (HSSFCell)row12.CreateCell(1);
                HSSFCell cell112 = (HSSFCell)row12.CreateCell(2);
                HSSFCell cell113 = (HSSFCell)row12.CreateCell(3);
                cell110.CellStyle = style6;
                cell111.CellStyle = style6;
                cell112.CellStyle = style6;
                cell113.CellStyle = style6;
                //创建列
                HSSFCell cell120 = (HSSFCell)row13.CreateCell(0);
                cell120.SetCellValue("吊装操作员(签字):");
                HSSFCell cell121 = (HSSFCell)row13.CreateCell(1);
                HSSFCell cell122 = (HSSFCell)row13.CreateCell(2);
                HSSFCell cell123 = (HSSFCell)row13.CreateCell(3);
                cell120.CellStyle = style9;
                cell121.CellStyle = style9;
                cell122.CellStyle = style9;
                cell123.CellStyle = style9;
                //创建列
                HSSFCell cell130 = (HSSFCell)row14.CreateCell(0);
                cell130.SetCellValue("吊装监护员(签字):");
                HSSFCell cell131 = (HSSFCell)row14.CreateCell(1);
                HSSFCell cell132 = (HSSFCell)row14.CreateCell(2);
                HSSFCell cell133 = (HSSFCell)row14.CreateCell(3);
                cell130.CellStyle = style9;
                cell131.CellStyle = style9;
                cell132.CellStyle = style9;
                cell133.CellStyle = style9;
                //创建列
                HSSFCell cell140 = (HSSFCell)row15.CreateCell(0);
                cell140.SetCellValue("吊装日期:                   年                     月                     日");
                HSSFCell cell141 = (HSSFCell)row15.CreateCell(1);
                HSSFCell cell142 = (HSSFCell)row15.CreateCell(2);
                HSSFCell cell143 = (HSSFCell)row15.CreateCell(3);
                cell140.CellStyle = style9;
                cell141.CellStyle = style9;
                cell142.CellStyle = style9;
                cell143.CellStyle = style9;












                MemoryStream stream = new MemoryStream();
                hssfworkbook.Write(stream);
                string saveFileName = string.Format("{0}_{1}.xls", "NuclearRubLocation", DateTime.Now.ToString("yyyy-MM-dd"));
                string fileName = Server.MapPath("~") + "\\ExcelTemplate\\" + saveFileName;
                SaveToFile(stream, fileName);
                FileInfo downLoadFile = new FileInfo(fileName);
                System.Web.HttpContext context = System.Web.HttpContext.Current;
                context.Response.Clear();
                context.Response.ClearHeaders();
                context.Response.Buffer = false;
                context.Response.ContentType = "application/octet-stream";
                context.Response.AddHeader("content-disposition", "attachment;filename=" + HttpUtility.UrlDecode(saveFileName, System.Text.Encoding.UTF8));
                context.Response.AddHeader("content-length", downLoadFile.Length.ToString());
                context.Response.WriteFile(downLoadFile.FullName);
                context.Response.Flush();
                context.Response.End();
                if (System.IO.File.Exists(fileName))
                {
                    System.IO.File.Delete(fileName);
                }
          

        }
        private void SaveToFile(MemoryStream ms, string fileName)
        {
            using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write))
            {
                byte[] data = ms.ToArray();

                fs.Write(data, 0, data.Length);
                fs.Flush();
                data = null;
            }
        }
        #endregion
        /// <summary>
        /// 附件
        /// </summary>
        /// <param name="formCollection"></param>
        /// <returns></returns>

        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], "QuestionReport");
            }
            return null;
        }
        /// <summary>
        /// 下载文件
        /// 
        /// </summary>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }

        /// <summary>
        /// 根据业务编号以及业务类型得到附件列表
        /// </summary>
        /// <param name="businessId">业务编号</param>
        /// <param name="businessType">业务类型</param>
        /// <returns></returns>
        public IList<AttachFile> GetAttachFileBy(string businessId, string businessType)
        {
            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(businessId, businessType);
            return listAttachFile;
        }
    }
}
