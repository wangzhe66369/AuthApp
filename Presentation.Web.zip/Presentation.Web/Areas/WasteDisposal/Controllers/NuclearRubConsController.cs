﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels;
using RWIS.Domain.DomainObjects;
using System;
using NET01.CoreFramework;
using RWIS.Domain.DomainObjects.View.NuclearRubCons;
using RWIS.Presentation.Web.Core.Ftp;
using RWIS.Presentation.Web.Core;
using CIT.UPC.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using CIT.UPC.Domain.DomainObjects;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.Controllers
{
    public class NuclearRubConsController : Controller
    {
       INuclearRubConsRepository _NuclearRubConsRepository;
       IMaterialTypeRepository _MaterialTypeRepository;
       IBasicObjectRepository _BasicObjectRepository;
       INuclearWastePackageRepository _NuclearWastePackageRepository;
       IDispsiteApproveRepository _DispsiteApproveRepository;
       INuclearRubLocationRepository _NuclearRubLocationRepository;
       public NuclearRubConsController(  INuclearRubConsRepository _NuclearRubConsRepository,
                                             IMaterialTypeRepository _MaterialTypeRepository,
                                        IBasicObjectRepository _BasicObjectRepository,
                                  INuclearWastePackageRepository _NuclearWastePackageRepository,
                                 IDispsiteApproveRepository _DispsiteApproveRepository,
                                 INuclearRubLocationRepository _NuclearRubLocationRepository
           )
        {
            this._NuclearRubConsRepository = _NuclearRubConsRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
            this._DispsiteApproveRepository = _DispsiteApproveRepository;
            this._NuclearRubLocationRepository = _NuclearRubLocationRepository;
        }
        /// <summary>
        /// 初始页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物处置施工")]
        public ActionResult Index()
        {
            NuclearRubConsVM vm = new NuclearRubConsVM();
            vm.UnitCodeList = new List<SelectListItem>();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_Cons");
            List<BasicObject> locationIdList = new List<BasicObject>();
            IQueryable<BasicObject> queryUnitCode = _BasicObjectRepository.GetSubobjectsByCode("UnitCode", AppContext.CurrentUser.ProjectCode);
            if (queryUnitCode != null && queryUnitCode.Count() > 0)
            {
                locationIdList = queryUnitCode.ToList();
            }
            vm.UnitCodeList.Add(new SelectListItem { Text = "请选择", Value = "" });
            foreach (var item in locationIdList)
            {
                vm.UnitCodeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            return View(vm);
        }
        /// <summary>
        /// 增加页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Construct(string IdentityCode)
        {
            NuclearRubConsVM vm = new NuclearRubConsVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_Cons");
            List<NuclearRubCons> nuclearRubConsList = this._NuclearRubConsRepository.GetAll().Where(d => d.IdentityCode == IdentityCode).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
             //获得所有数据
            if (nuclearRubConsList.Count() > 0)
            {
                vm.NuclearRubCons = this._NuclearRubConsRepository.Get(nuclearRubConsList[0].ConsId);
                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(nuclearRubConsList[0].ConsId, "QuestionReport");
                vm.ConsAttachFiles = (List<AttachFile>)listAttachFile;
                ViewBag.BusinessType = "QuestionReport";
            }
            else
            {
                vm.NuclearRubCons = new NuclearRubCons();
            }

            vm.NuclearRubCons.IdentityCode = IdentityCode;
            vm.UnitCodeList = new List<SelectListItem>();
            List<BasicObject> locationIdList = new List<BasicObject>();
            IQueryable<BasicObject> queryUnitCode = _BasicObjectRepository.GetSubobjectsByCode("UnitCode", AppContext.CurrentUser.ProjectCode);
            if (queryUnitCode != null && queryUnitCode.Count() > 0)
            {
                locationIdList = queryUnitCode.ToList();
            }
            foreach (var item in locationIdList)
            {
                vm.UnitCodeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            vm.FlagRodiodList = new List<SelectListItem>();
            vm.FlagRodiodList.Add(new SelectListItem { Text = "全水泥桶", Value = "1" });
            vm.FlagRodiodList.Add(new SelectListItem { Text = "全金属桶", Value = "2" });
            vm.FlagRodiodList.Add(new SelectListItem { Text = "金属方箱", Value = "3" });
            vm.FlagRodiodList.Add(new SelectListItem { Text = "混装", Value = "4" });
           
            return View("Add",vm);
        }

        /// <summary>
        /// 查看页面
        /// </summary>
        /// <returns></returns>
        public ActionResult DetailView(string IdentityCode)
        {
            NuclearRubConsVM vm = new NuclearRubConsVM();
           
            List<NuclearRubCons> nuclearRubConsList = this._NuclearRubConsRepository.GetAll().Where(d => d.IdentityCode == IdentityCode).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (nuclearRubConsList.Count() > 0)
            {
                vm.NuclearRubCons = this._NuclearRubConsRepository.Get(nuclearRubConsList[0].ConsId);
                BasicObject unitCode = _BasicObjectRepository.Get(nuclearRubConsList[0].UnitId);

                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(nuclearRubConsList[0].ConsId, "QuestionReport");
                vm.ConsAttachFiles = (List<AttachFile>)listAttachFile;
                vm.NuclearRubCons.UnitId = unitCode.Name;
            }
            else
            {
                vm.NuclearRubCons = new NuclearRubCons();
            }
            return View(vm);
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraft(NuclearRubConsVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubCons.ConsId))
                {
                   DraftSave(model, "0", "");
                 
                }
                //修改完新增
                else
                {
                   DraftUpdate(model, "0", "");
                }
                this._NuclearRubConsRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.NuclearRubCons.ConsId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitDraft(NuclearRubConsVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubCons.ConsId))
                {
                    DraftSave(model, "1", "");
                }
                //修改完新增
                else
                {
                   DraftUpdate(model, "1", "");
                }
                this._NuclearRubConsRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.NuclearRubCons.ConsId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确定
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物处置施工确认")]
        public JsonResult ConfirmDraft(NuclearRubConsVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubCons.ConsId))
                {
                    DraftSave(model, "2", "Confirm");

                }
                //修改完新增
                else
                {
                   DraftUpdate(model, "2", "Confirm");
                   
                }
                this._NuclearRubConsRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.NuclearRubCons.ConsId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确定失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 新增保存
        /// </summary>
        /// <param name="model"></param>
        private void DraftSave(NuclearRubConsVM model, string status, string type)
        {
            model.NuclearRubCons.ConsId = Guid.NewGuid().ToString();
            model.NuclearRubCons.Status = status;
            model.NuclearRubCons.CreateDate = DateTime.Now;
            model.NuclearRubCons.CreateUserNo = AppContext.CurrentUser.UserId;
            model.NuclearRubCons.CreateUserName = AppContext.CurrentUser.UserName;
            model.NuclearRubCons.Stationcode = AppContext.CurrentUser.ProjectCode;
            List<DispsiteApprove> dispsiteApproveList = this._DispsiteApproveRepository.GetAll().Where(d => d.IdentityCode == model.NuclearRubCons.IdentityCode).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (dispsiteApproveList.Count() > 0)
            {
                model.NuclearRubCons.ApproveId = dispsiteApproveList[0].ApproveId;
            }
            if (type == "Confirm")
            {
                model.NuclearRubCons.ConfirmDate = DateTime.Now;
                model.NuclearRubCons.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.NuclearRubCons.ConfirmUserName = AppContext.CurrentUser.UserName;
            }
            this._NuclearRubConsRepository.Create(model.NuclearRubCons);

        }
        /// <summary>
        /// 修改保存
        /// </summary>
        /// <param name="model"></param>
        private void DraftUpdate(NuclearRubConsVM model, string status, string type)
        {

            model.NuclearRubCons = _NuclearRubConsRepository.Get(model.NuclearRubCons.ConsId);
            UpdateModel(model);
            model.NuclearRubCons.Status = status;
            List<DispsiteApprove> dispsiteApproveList = this._DispsiteApproveRepository.GetAll().Where(d => d.IdentityCode == model.NuclearRubCons.IdentityCode).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (dispsiteApproveList.Count() > 0)
            {
                model.NuclearRubCons.ApproveId = dispsiteApproveList[0].ApproveId;
            }
            if (type == "Confirm")
            {
                model.NuclearRubCons.ConfirmDate = DateTime.Now;
                model.NuclearRubCons.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.NuclearRubCons.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.NuclearRubCons.Stationcode = AppContext.CurrentUser.ProjectCode;
            }
            this._NuclearRubConsRepository.Update(model.NuclearRubCons);
                
               
        }
        /// <summary>
        /// 初始化查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetNuclearRubConsList(NuclearRubConsCondition condition, string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<NuclearRubConsView> data = _NuclearRubConsRepository.QueryList(condition).Where(d => d.PackageStatus == "DEALED").Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderBy("CreateDate", SortDirection.Descending);

            var pagedViewModel = new PagedViewModel<NuclearRubConsView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.LocationId,
                    List = new List<object>() {                      
                        d.LocationId,
                        d.PackageCode,
                        d.IdentityCode,
                        d.UnitCode,
                        d.LocationFlag,
                        d.FillStandard,
                        d.WorkStart.HasValue?d.WorkStart.Value.ToString("yyyy-MM-dd"):"",
                        d.WorkEnd.HasValue?d.WorkEnd.Value.ToString("yyyy-MM-dd"):"",
                        d.ConsStatus
                       
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {

                   this._NuclearRubConsRepository.DeleteById(id);

                }
                this._NuclearRubConsRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 附件
        /// </summary>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], "QuestionReport");
            }
            return null;
        }
        /// <summary>
        /// 下载文件
        /// 
        /// </summary>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }
        /// <summary>
        /// 根据业务编号以及业务类型得到附件列表
        /// </summary>
        /// <param name="businessId">业务编号</param>
        /// <param name="businessType">业务类型</param>
        /// <returns></returns>
        public IList<AttachFile> GetAttachFileBy(string businessId, string businessType)
        {
            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(businessId, businessType);
            return listAttachFile;
        }

    }
}
