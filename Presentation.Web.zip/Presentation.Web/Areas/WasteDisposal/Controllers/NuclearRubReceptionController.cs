﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels;
using RWIS.Domain.DomainObjects;
using System;
using NET01.CoreFramework;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Domain.DomainObjects.View;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
namespace RWIS.Presentation.Web.Areas.WasteDisposal.Controllers
{
    public class NuclearRubReceptionController : Controller
    {
        
       INuclearRubReceptionRepository _NuclearRubReceptionRepository;
       INuclearRubReceptionDRepository _NuclearRubReceptionDRepository;
       INuclearBucketRepository _NuclearBucketRepository;
       INuclearWastePackageRepository _NuclearWastePackageRepository;
       IBasicObjectRepository _BasicObjectRepository;
       IMaterialTypeRepository _MaterialTypeRepository;
       INuclearApplyDetailRepository _NuclearApplyDetailRepository;
       INuclearProcessApplyRepository _NuclearProcessApplyRepository;
       public NuclearRubReceptionController(INuclearRubReceptionRepository _NuclearRubReceptionRepository, 
            INuclearBucketRepository _NuclearBucketRepository,
            INuclearWastePackageRepository _NuclearWastePackageRepository,
            INuclearRubReceptionDRepository _NuclearRubReceptionDRepository,
            IBasicObjectRepository _BasicObjectRepository,
            IMaterialTypeRepository _MaterialTypeRepository,
            INuclearApplyDetailRepository _NuclearApplyDetailRepository,
            INuclearProcessApplyRepository _NuclearProcessApplyRepository
           )
        {
            this._NuclearRubReceptionRepository = _NuclearRubReceptionRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
            this._NuclearRubReceptionDRepository = _NuclearRubReceptionDRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._NuclearApplyDetailRepository = _NuclearApplyDetailRepository;
            this._NuclearProcessApplyRepository = _NuclearProcessApplyRepository;
        }
        /// <summary>
        /// 初始页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物接收")]
        public ActionResult Index()
        {
            NuclearRubReceptionVM vm = new NuclearRubReceptionVM();
            vm.NuclearRubReception = new NuclearRubReception();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_Reception");
            return View(vm);
        }
         /// <summary>
        /// 新增页面
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Add()
        {
            NuclearRubReceptionVM vm = new NuclearRubReceptionVM();
            vm.NuclearRubReception = new NuclearRubReception();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_Reception");
            List<MaterialType> materialTypeList = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.Status =="2").Where(d => d.IsBucket == "1").ToList();
            if (materialTypeList.Count() == 0)
            { 
               MaterialType materialType =new MaterialType();
               materialTypeList.Add(materialType);
            }
            SelectList SelectList = new SelectList(materialTypeList, "MaterialId", "MaterialName");
            ViewData["BucketType"] = SelectList;
            return View(vm);
        }

        /// <summary>
        /// 修改页面
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Edit(string id)
        {
            NuclearRubReceptionVM vm = new NuclearRubReceptionVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Rub_Reception");
            vm.NuclearRubReception = _NuclearRubReceptionRepository.Get(id);
            List<MaterialType> materialTypeList = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.Status == "2").Where(d => d.IsBucket == "1").ToList();
            if (materialTypeList.Count() == 0)
            {
                MaterialType materialType = new MaterialType();
                materialTypeList.Add(materialType);
            }
            SelectList SelectList = new SelectList(materialTypeList, "MaterialId", "MaterialName");
            ViewData["BucketType"] = SelectList;
            return View("Add",vm);
        }

        /// <summary>
        /// 查看页面
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DetailView(string id)
        {
            NuclearRubReceptionVM vm = new NuclearRubReceptionVM();
            vm.NuclearRubReception = _NuclearRubReceptionRepository.Get(id);
            return View("DetailView",vm);
        }
        /// <summary>
        /// 初始化查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetNuclearRubReceptionList(NuclearRubReceptionCondition condition, string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<NuclearRubReception> data = _NuclearRubReceptionRepository.QueryList(condition).OrderBy("CreateDate", SortDirection.Descending).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            var pagedViewModel = new PagedViewModel<NuclearRubReception>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ReceptId,
                    List = new List<object>() {                      
                        d.ReceptId,
                        d.OrderCode,
                        d.TransPlate,
                        d.TransDate.HasValue? d.TransDate.Value.ToString("yyyy-MM-dd"):"",
                        d.TransportDate.HasValue? d.TransportDate.Value.ToString("yyyy-MM-dd"):"",
                        "【"+d.ReceptionNo+"】"+d.ReceptionName,
                         d.ReceptionDate.HasValue? d.ReceptionDate.Value.ToString("yyyy-MM-dd"):"",
                         d.Status
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 根据容器类型判断是金属桶还是水泥桶
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public JsonResult DecideBucket(string bucketTypeId)
        {

            try
            {
                MaterialType materialType = _MaterialTypeRepository.Get(bucketTypeId);
                var bucketType = string.Empty;
                if (materialType != null)
                {
                     bucketType = materialType.IsMetal;
                
                }
                
                return Json("{\"result\":true,\"msg\":\"" + bucketType + "\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"材料有误。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 判断废物货包号是否存在
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public JsonResult IsWastePackageExist(string packageCode)
        {
           
            try
            {
                string isExist = this._NuclearWastePackageRepository.IsExist(packageCode, AppContext.CurrentUser.ProjectCode);
                if (string.IsNullOrEmpty(isExist))
                {
                    return Json("{\"result\":false,\"msg\":\"废物货包号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                //NuclearWastePackage nuclearWastePackage =_NuclearWastePackageRepository.GetAll().Where(d=>d.PackageCode.Trim()==packageCode.Trim()&&d.Stationcode==AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                //if(nuclearWastePackage!=null)
                //{
                //    NuclearRubReceptionD nuclearRubReceptionD = _NuclearRubReceptionDRepository.GetAll().Where(d => d.PackageId == nuclearWastePackage.PackageId).FirstOrDefault();
                //    if (nuclearRubReceptionD != null)
                //    {
                //        return Json("{\"result\":false,\"msg\":\"废物货包号已存在接收列表。\"}", JsonRequestBehavior.AllowGet);
                //    }
                    
                //}
                
                
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"废物货包号不存在。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 保存
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraft(NuclearRubReceptionVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubReception.ReceptId))
                {
                    //新增保存数据
                    string message=SaveRubReception(model, "0", "");
                    if (message.Equals("NoApprove"))
                    {
                        return Json("{\"result\":false,\"msg\":\"审批没通过。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                //修改完新增
                else
                {
                    //修改保存
                     string message=UpdateRubReception(model, "0", "");
                    if (message.Equals("NoApprove"))
                    {
                        return Json("{\"result\":false,\"msg\":\"审批没通过。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("DEALED"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物包已被下一环节处置。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                this._NuclearRubReceptionRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

       /// <summary>
       /// 提交
       /// </summary>
       /// <param name="model"></param>
       /// <param name="formCollection"></param>
       /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitDraft(NuclearRubReceptionVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubReception.ReceptId))
                {
                    //新增保存数据
                    string message = SaveRubReception(model, "1", "");
                    if (message.Equals("NoApprove"))
                    {
                        return Json("{\"result\":false,\"msg\":\"审批没通过。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                //修改完新增
                else
                {
                    //修改保存
                    string message = UpdateRubReception(model, "1", "");
                    if (message.Equals("NoApprove"))
                    {
                        return Json("{\"result\":false,\"msg\":\"审批没通过。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("DEALED"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物包已被下一环节处置。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                this._NuclearRubReceptionRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确定
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物接收确定")]
        public JsonResult ConfirmDraft(NuclearRubReceptionVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.NuclearRubReception.ReceptId))
                {
                    //新增保存数据
                    string message = SaveRubReception(model, "2", "Confirm");
                    if (message.Equals("NoApprove"))
                    {
                        return Json("{\"result\":false,\"msg\":\"审批没通过。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                //修改完新增
                else
                {
                    //修改保存
                    string message = UpdateRubReception(model, "2", "Confirm");
                    if (message.Equals("NoApprove"))
                    {
                        return Json("{\"result\":false,\"msg\":\"审批没通过。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("NoExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else if (message.Equals("DEALED"))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物包已被下一环节处置。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                this._NuclearRubReceptionRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        
        /// <summary>
        /// 新增保存数据
        /// </summary>
        /// <param name="model"></param>
        private string SaveRubReception(NuclearRubReceptionVM model, string status, string type)
        {
            model.NuclearRubReception.ReceptId = Guid.NewGuid().ToString();
            model.NuclearRubReception.CreateDate = DateTime.Now;
            model.NuclearRubReception.CreateUserName = AppContext.CurrentUser.UserName;
            model.NuclearRubReception.CreateUserNo = AppContext.CurrentUser.UserId;
            model.NuclearRubReception.Status = status;
            model.NuclearRubReception.Stationcode = AppContext.CurrentUser.ProjectCode;
            if (type == "Confirm")
            {
                model.NuclearRubReception.ConfirmDate = DateTime.Now;
                model.NuclearRubReception.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.NuclearRubReception.ConfirmUserName = AppContext.CurrentUser.UserName;
            }
            this._NuclearRubReceptionRepository.Create(model.NuclearRubReception);
            if (!string.IsNullOrEmpty(model.rubReceptionList))
            {
                string[] arrReceptionList = model.rubReceptionList.Split(';');
                for (int i = 0; i < arrReceptionList.Length; i++)
                {
                    NuclearRubReceptionD nuclearRubReceptionD = new NuclearRubReceptionD();
                    string[] arrReception = arrReceptionList[i].Split(',');
                    string packageId = _NuclearWastePackageRepository.IsExist(arrReception[0], AppContext.CurrentUser.ProjectCode);
                    if (!string.IsNullOrEmpty(packageId))
                    {


                        NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(packageId);
                        string isApplied = _NuclearWastePackageRepository.IsApplied(arrReception[0], AppContext.CurrentUser.ProjectCode);

                        if (!string.IsNullOrEmpty(isApplied))
                        {

                            //增加接收明细
                            ReceptionAdd(model, arrReception, packageId, nuclearWastePackage, nuclearRubReceptionD);
                        }
                        else {

                            return "NoApprove";
                        }


                    }
                    else
                    {
                        return "NoExist";
                    }

                    
                }
            }
            return "Success";

        }

        /// <summary>
        /// 修改保存
        /// </summary>
        /// <param name="model"></param>
        private string UpdateRubReception(NuclearRubReceptionVM model, string status, string type)
        {
            model.NuclearRubReception = _NuclearRubReceptionRepository.Get(model.NuclearRubReception.ReceptId);
            UpdateModel(model);
            model.NuclearRubReception.Status = status;
            if (type == "Confirm")
            {
                model.NuclearRubReception.ConfirmDate = DateTime.Now;
                model.NuclearRubReception.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.NuclearRubReception.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.NuclearRubReception.Stationcode = AppContext.CurrentUser.ProjectCode;
            }
            this._NuclearRubReceptionRepository.Update(model.NuclearRubReception);

          
            //页面得到的数据
            string[] arr = model.rubReceptionList.Split(';');
            List<string> arrListFromPage = new List<string>();
            foreach (var item in arr)
            {
                string[] arrR = item.Split(',');
                if (arrR != null)
                {
                    string packageId = _NuclearWastePackageRepository.IsExist(arrR[0], AppContext.CurrentUser.ProjectCode);
                    arrListFromPage.Add(packageId);
                }
            }
            string[] arrPackageIdFromPage = arrListFromPage.ToArray();

            
            //从数据库得到数据
            List<string> arrListFromBase = new List<string>();
            IQueryable<NuclearRubReceptionD> data = this._NuclearRubReceptionDRepository.GetAll().Where(d => d.ReceptId == model.NuclearRubReception.ReceptId).AsQueryable();
            if (data.Count() > 0)
            {
                List<NuclearRubReceptionD> listData = data.ToList();
                foreach (var item in listData)
                {
                    arrListFromBase.Add(item.PackageId);
                }

            }
            string[] arrPackageIdFromBase = arrListFromBase.ToArray();
            //求交集
            string[] sameArr = arrPackageIdFromPage.Intersect(arrPackageIdFromBase).ToArray();
            //页面中减少的数据
            string[] difArr = arrPackageIdFromBase.Except(sameArr).ToArray();
            //删除页面中减少的数据
            foreach (var itemdifArr in difArr)
            {
              
                NuclearRubReceptionD dataItemdifArr = this._NuclearRubReceptionDRepository.GetAll().Where(d => d.ReceptId == model.NuclearRubReception.ReceptId && d.PackageId == itemdifArr).FirstOrDefault();
                NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(dataItemdifArr.PackageId);
                if (nuclearWastePackage.Status == "DEALED")
                {
                    return "DEALED";
                }
                if (dataItemdifArr!=null)
                {
                    this._NuclearRubReceptionDRepository.DeleteById(dataItemdifArr.DetailId);
                }
               
               
                if (nuclearWastePackage != null)
                {
                    nuclearWastePackage.Status = "APPLIED";
                }
                this._NuclearWastePackageRepository.Update(nuclearWastePackage);

            }


            if (data.Count() > 0)
            {
                List<NuclearRubReceptionD> listData = data.ToList();
                string[] arrRub = model.rubReceptionList.Split(';');
                foreach (var itemArrRub in arrRub)
                {
                    string[] arrReception = itemArrRub.Split(',');
                    if (arrReception != null)
                    {
                        string packageExistId = _NuclearWastePackageRepository.IsExist(arrReception[0], AppContext.CurrentUser.ProjectCode);
                        NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(packageExistId);
                        string isApplied = _NuclearWastePackageRepository.IsApplied(arrReception[0], AppContext.CurrentUser.ProjectCode);
                        IQueryable<NuclearRubReceptionD> dataEvery = data.Where(d => d.PackageId == packageExistId);
                        if (dataEvery.Count() == 0)
                        {
                            NuclearRubReceptionD nuclearRubReceptionD = new NuclearRubReceptionD();

                            if (!string.IsNullOrEmpty(packageExistId))
                            {
                                if (!string.IsNullOrEmpty(isApplied))
                                {
                                    //增加接收明细
                                    ReceptionAdd(model, arrReception, packageExistId, nuclearWastePackage, nuclearRubReceptionD);
                                }
                                else
                                {

                                    return "NoApprove";
                                }


                            }
                            else
                            {
                                return "NoExist";
                            }


                        }
                        else
                        {
                            NuclearRubReceptionD nuclearRubReceptionD = dataEvery.FirstOrDefault();
                            //增加接收明细
                            ReceptionUpate(model, arrReception, packageExistId, nuclearWastePackage, nuclearRubReceptionD);
                        }
                      

                    }


                }


            }
           
            return "Success";

        }
        /// <summary>
        /// 增加接收明细
        /// </summary>
        /// <param name="model"></param>
        /// <param name="arrReception"></param>
        /// <param name="packageExistId"></param>
        /// <param name="nuclearWastePackage"></param>
        /// <param name="nuclearRubReceptionD"></param>
        private void ReceptionAdd(NuclearRubReceptionVM model, string[] arrReception, string packageExistId, NuclearWastePackage nuclearWastePackage, NuclearRubReceptionD nuclearRubReceptionD)
        {
            if (nuclearWastePackage != null)
            {
                nuclearRubReceptionD.DetailId = Guid.NewGuid().ToString();
                nuclearRubReceptionD.ReceptId = model.NuclearRubReception.ReceptId;
                nuclearRubReceptionD.PackageId = packageExistId;
                nuclearRubReceptionD.BucketId = nuclearWastePackage.BucketId;
                nuclearRubReceptionD.BucketType = arrReception[1];
                if (arrReception[2] != null)
                {
                    if (arrReception[2] == "0")
                    {
                        nuclearRubReceptionD.IsCementquelified = arrReception[3];
                    }
                    if (arrReception[2] == "1")
                    {
                        nuclearRubReceptionD.IsMetelquelified = arrReception[3];
                    }

                }
                nuclearRubReceptionD.IsSandySurface = arrReception[4];
                nuclearRubReceptionD.SandySurface = arrReception[5];
                nuclearRubReceptionD.IsCrack = arrReception[6];
                nuclearRubReceptionD.Crack = arrReception[7];
                nuclearRubReceptionD.IsBreach = arrReception[8];
                nuclearRubReceptionD.Breach = arrReception[9];
                nuclearRubReceptionD.IsCavatity = arrReception[10];
                nuclearRubReceptionD.Cavatity = arrReception[11];

                nuclearRubReceptionD.IsConcavity = arrReception[12];
                nuclearRubReceptionD.Concavity = arrReception[13];
                nuclearRubReceptionD.IsGirthWelding = arrReception[14];
                nuclearRubReceptionD.GirthWelding = arrReception[15];
                nuclearRubReceptionD.IsWeldingWidth = arrReception[16];
                nuclearRubReceptionD.WeldingWidth = arrReception[17];
                nuclearRubReceptionD.IsRingWelding = arrReception[18];
                nuclearRubReceptionD.RingWelding = arrReception[19];

                nuclearRubReceptionD.DoseSurface = Convert.ToDecimal(arrReception[20]);
                nuclearRubReceptionD.DoseMeter = Convert.ToDecimal(arrReception[21]);
                nuclearRubReceptionD.PackagePolluteA = arrReception[22];
                nuclearRubReceptionD.PackagePolluteB = arrReception[23];
                nuclearRubReceptionD.CheckResult = arrReception[24];
                nuclearRubReceptionD.Remark = arrReception[25];
                this._NuclearRubReceptionDRepository.Create(nuclearRubReceptionD);
                if (model.NuclearRubReception.Status == "2")
                {
                    nuclearWastePackage.Status = "RECEPTED";
                    this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                }
                if (nuclearRubReceptionD.CheckResult == "0")
                {
                    nuclearWastePackage.Status = "UNRECEPTED";
                    //退回后发送邮件提醒
                    SendMail(nuclearWastePackage);

                    
                      
                    this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                }

            }
        }
        /// <summary>
        /// 退回后发送邮件提醒
        /// </summary>
        /// <param name="nuclearWastePackage"></param>
        private void SendMail(NuclearWastePackage nuclearWastePackage)
        {
            NuclearApplyDetail nuclearApplyDetail = _NuclearApplyDetailRepository.GetAll().Where(d => d.BucketId == nuclearWastePackage.BucketId).FirstOrDefault();
            if (nuclearApplyDetail != null)
            {
                NuclearProcessApply nuclearProcessApply = _NuclearProcessApplyRepository.Get(nuclearApplyDetail.ProcessApplyId);
                string copyUsers = string.Empty;
                NET01.CoreFramework.Mail.ISmtpClient smtpClent = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<NET01.CoreFramework.Mail.ISmtpClient>();
                var mailService = new RWIS.Application.Implementation.MailService(smtpClent);
                string sendTitle = string.Format("废物包退回通知");
                string sendContent = " &nbsp;" + "您好！" + "</br>" + " &nbsp;&nbsp;" + "废物包号：" + "<span style='font-size:10.5pt;color:#FF0000'>" + nuclearWastePackage.PackageCode + "</span>" + "，已被退回，请确认" + "。";
                mailService.SendMailService(nuclearProcessApply.ApplyNo, copyUsers, sendTitle, sendContent);

            }
        }
        /// <summary>
        /// 修改接收明细
        /// </summary>
        /// <param name="model"></param>
        /// <param name="arrReception"></param>
        /// <param name="packageExistId"></param>
        /// <param name="nuclearWastePackage"></param>
        /// <param name="nuclearRubReceptionD"></param>
        private void ReceptionUpate(NuclearRubReceptionVM model, string[] arrReception, string packageExistId, NuclearWastePackage nuclearWastePackage, NuclearRubReceptionD nuclearRubReceptionD)
        {
            if (nuclearWastePackage != null)
            {
                nuclearRubReceptionD.ReceptId = model.NuclearRubReception.ReceptId;
                nuclearRubReceptionD.PackageId = packageExistId;
                nuclearRubReceptionD.BucketId = nuclearWastePackage.BucketId;
                nuclearRubReceptionD.BucketType = arrReception[1];
                if (arrReception[2] != null)
                {
                    if (arrReception[2] == "0")
                    {
                        nuclearRubReceptionD.IsCementquelified = arrReception[3];
                    }
                    if (arrReception[2] == "1")
                    {
                        nuclearRubReceptionD.IsMetelquelified = arrReception[3];
                    }

                }
                nuclearRubReceptionD.IsSandySurface = arrReception[4];
                nuclearRubReceptionD.SandySurface = arrReception[5];
                nuclearRubReceptionD.IsCrack = arrReception[6];
                nuclearRubReceptionD.Crack = arrReception[7];
                nuclearRubReceptionD.IsBreach = arrReception[8];
                nuclearRubReceptionD.Breach = arrReception[9];
                nuclearRubReceptionD.IsCavatity = arrReception[10];
                nuclearRubReceptionD.Cavatity = arrReception[11];

                nuclearRubReceptionD.IsConcavity = arrReception[12];
                nuclearRubReceptionD.Concavity = arrReception[13];
                nuclearRubReceptionD.IsGirthWelding = arrReception[14];
                nuclearRubReceptionD.GirthWelding = arrReception[15];
                nuclearRubReceptionD.IsWeldingWidth = arrReception[16];
                nuclearRubReceptionD.WeldingWidth = arrReception[17];
                nuclearRubReceptionD.IsRingWelding = arrReception[18];
                nuclearRubReceptionD.RingWelding = arrReception[19];

                nuclearRubReceptionD.DoseSurface = Convert.ToDecimal(arrReception[20]);
                nuclearRubReceptionD.DoseMeter = Convert.ToDecimal(arrReception[21]);
                nuclearRubReceptionD.PackagePolluteA = arrReception[22];
                nuclearRubReceptionD.PackagePolluteB = arrReception[23];
                nuclearRubReceptionD.CheckResult = arrReception[24];
                nuclearRubReceptionD.Remark = arrReception[25];
                this._NuclearRubReceptionDRepository.Update(nuclearRubReceptionD);
                if (model.NuclearRubReception.Status == "2")
                {
                    nuclearWastePackage.Status = "RECEPTED";
                    this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                }
                if (nuclearRubReceptionD.CheckResult == "0")
                {
                    nuclearWastePackage.Status = "UNRECEPTED";
                    //退回后发送邮件提醒
                    SendMail(nuclearWastePackage);
                    this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                }

            }
        }
        /// <summary>
        /// 接收单明细查询
        /// </summary>
        /// <param name="AcceptId"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetList(string ReceptId, string sord, int page, int rows, string sidx)
        {
            if (string.IsNullOrEmpty(ReceptId))
            {
                return null;
            }
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<NuclearRubReceptionDView> data = this._NuclearRubReceptionDRepository.QueryListByReceptId(ReceptId);
            var pagedViewModel = new PagedViewModel<NuclearRubReceptionDView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DetailId,
                    List = new List<object>()
                    {
                        d.DetailId, 
                        d.BucketTypeVal,
                         (d.IsCementquelified==null|| d.IsCementquelified=="")?"1":"0",
                         d.PackageCode,
                         d.BucketType,
                         (d.IsCementquelified==null|| d.IsCementquelified=="")?d.IsMetelquelified:d.IsCementquelified,

                         d.IsSandySurface,
                         d.SandySurface,
                         d.IsCrack,
                         d.Crack,
                         d.IsBreach,
                         d.Breach,
                         d.IsCavatity,
                         d.Cavatity,

                         d.IsConcavity,
                         d.Concavity,
                         d.IsGirthWelding,
                         d.GirthWelding,
                         d.IsWeldingWidth,
                         d.WeldingWidth,
                         d.IsRingWelding,
                         d.RingWelding,

                         d.DoseSurface,
                         d.DoseMeter,
                         d.PackagePolluteA,
                         d.PackagePolluteB,
                         d.CheckResult,
                         d.Remark                   
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 删除材料
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {

                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                    foreach (string idVal in idArr)
                    {
                        List<NuclearRubReceptionD> nuclearRubReceptionDList = this._NuclearRubReceptionDRepository.GetAll().Where(d => d.ReceptId == idVal).ToList();
                        if (nuclearRubReceptionDList.Count() > 0)
                        {
                            foreach (var item in nuclearRubReceptionDList)
                            {
                                 this._NuclearRubReceptionDRepository.DeleteById(item.DetailId);
                                 NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.Get(item.PackageId);
                               
                                 if (nuclearWastePackage != null)
                                 {
                                     if (nuclearWastePackage.Status == "DEALED")
                                     {
                                         return Json("{\"result\":false,\"msg\":\"已被处置,请先处理定位的废物包。\"}", JsonRequestBehavior.AllowGet);
                                     }
                                     nuclearWastePackage.Status = "APPLIED";
                                     this._NuclearWastePackageRepository.Update(nuclearWastePackage);
                                 }
                                
                            }
                        }
                        this._NuclearRubReceptionRepository.DeleteById(idVal);

                    }

                   }

                  this._NuclearRubReceptionRepository.UnitOfWork.Commit();
                  return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
              
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 废物货包联想控件
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetDataList(string keyword)
        {
            //数据源
            List<NuclearWastePackage> list = _NuclearWastePackageRepository.GetAll().Where(e => e.PackageCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable().Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count > 0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].PackageCode;
                    autoComplete.Code = list[i].PackageId;
                    autoCompleteList.Add(autoComplete);
                }
            }

            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

    }
}
