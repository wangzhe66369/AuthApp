﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels
{
    public class DispiteConfirmVM
    {
        /// <summary>
        /// 废物质量确认实体
        /// </summary>
        public DispiteConfirm DispiteConfirm { get; set; }
        /// <summary>
        /// 档案生成实体
        /// </summary>
        public NuclearRubFile NuclearRubFile { get; set; }
        /// <summary>
        /// 废物质量确认详细实体
        /// </summary>
        public DispiteConfirmDetail DispiteConfirmDetail { get; set; }
        /// <summary>
        ///处置单元号
        /// </summary>
        public List<SelectListItem> UnitCodeList { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 废物类型
        /// </summary>
        public string WasteType { get; set; }
        /// <summary>
        /// 废物固定日期
        /// </summary>
        public string DealDate { get; set; }
        /// <summary>
        /// 废物货包号
        /// </summary>
        public string PackageCode { get; set; }
        /// <summary>
        /// 废物货包重量(t)
        /// </summary>
        public Nullable<decimal> Weight { get; set; }
        /// <summary>
        /// 桶检查是否符合要求(0:不符合 1:符合)
        /// </summary>
        public string InspectIsrequired { get; set; }
        /// <summary>
        /// 装桶信息是否符合要求(0: 不符合  1:符合)
        /// </summary>
        public string BarrelIsrequired { get; set; }
        /// <summary>
        /// 封盖信息是否符合要求(0: 不符合  1:符合)
        /// </summary>
        public string DoseIsrequired { get; set; }
        /// <summary>
        /// 转运信息是否符合要求(0: 不符合  1:符合)
        /// </summary>
        public string TransferIsrequired { get; set; }
        /// <summary>
        /// 废物货包接收、检查是否合格
        /// </summary>
        public string Isquelified { get; set; }
        /// <summary>
        /// 桶准备
        /// </summary>
        public string Prepare { get; set; }
         /// <summary>
        /// 固化
        /// </summary>
        public string Solid { get; set; }
         /// <summary>
        /// 封盖
        /// </summary>
        public string Cover { get; set; }
        /// <summary>
        /// 废物货包运输
        /// </summary>
        public string Transfer { get; set; }
        /// <summary>
        /// 废物货包接收
        /// </summary>
        public string Receive { get; set; }
        /// <summary>
        /// 补充说明
        /// </summary>
        public string Supply { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }
        /// <summary>
        /// 质量确认附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> ConfirmAttachFiles { get; set; }
        /// <summary>
        /// 档案生成附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> FileAttachFiles { get; set; }

        public string WaseteSource { get; set; }

        public string InspectCheckresult { get; set; }

        public string DoseCheckresult { get; set; }

        public string BarrelCheckresult { get; set; }

        public string TransferCheckresult { get; set; }

        public string Remark { get; set; }

        public string BucketIsrequired { get; set; }

        public string BucketCheckresult { get; set; }
        /// <summary>
        /// 处置定位状态
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 处置定位备注
        /// </summary>
        public string RubRemark { get; set; }

        public string BucketMesIsrequired { get; set; }

        public string BucketMesCheckresult { get; set; }

        public string EvaluateIsrequired { get; set; }

        public string EvaluateCheckresult { get; set; }
    }
}