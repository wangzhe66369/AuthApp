﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels
{
    public class WastePackageConfirmVM
    {
        /// <summary>
        /// 处置单元号
        /// </summary>
        public List<SelectListItem> UnitCodeList { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }
    }
}