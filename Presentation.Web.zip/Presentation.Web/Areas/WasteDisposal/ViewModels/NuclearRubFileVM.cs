﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels
{
    public class NuclearRubFileVM
    {
        /// <summary>
        /// 档案生成实体
        /// </summary>
        public NuclearRubFile NuclearRubFile { get; set; }
        /// <summary>
        /// 核素
        /// </summary>
        public NuclearElement NuclearElement { get; set; }
        /// <summary>
        /// 能谱库明细
        /// </summary>
        public SupportEdsDetail SupportEdsDetail { get; set; }
        /// <summary>
        /// 密级
        /// </summary>
        public List<SelectListItem> SecrecyLevelList { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 废物货包
        /// </summary>
        public string PackageCode { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> FileAttachFiles { get; set; }

        public string PackageSource { get; set; }
        public string Weight { get; set; }
        public string ReceptionDate { get; set; }
        public string BucketType { get; set; }
        public string Spec { get; set; }
        
        public string WasteType { get; set; }

        public string ShieldMaterail { get; set; }

        public decimal? ShieldWeight { get; set; }

        public decimal? DoseSurface { get; set; }

        public decimal? DoseMeter { get; set; }

        public string PackagePolluteB { get; set; }

        public string PackagePolluteA { get; set; }

        public string UnitCode { get; set; }

        public string LocationX { get; set; }

        public string LocationY { get; set; }

        public string LocationZ { get; set; }

        public string ElementName { get; set; }

        public Nullable<double> PercentValue { get; set; }

        public decimal? TotalActivity { get; set; }

        public string SurfaceClass { get; set; }

        public decimal? Volumn { get; set; }

        public string TransFlag { get; set; }

        public string GiftWeight { get; set; }

        public decimal? WasteVolumn { get; set; }

        public string SlingLocation { get; set; }
    }
}