﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels
{
    public class NuclearRubConsVM
    {
        /// <summary>
        /// 处置施工实体
        /// </summary>
        public NuclearRubCons NuclearRubCons { get; set; }
        /// <summary>
        ///处置单元号
        /// </summary>
        public List<SelectListItem> UnitCodeList { get; set; }
        /// <summary>
        /// 定位方案
        /// </summary>
        public List<SelectListItem> FlagRodiodList { get; set; }
        /// <summary>
        /// 处置单元名
        /// </summary>
        public string UnitName { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> ConsAttachFiles { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }
    }
}