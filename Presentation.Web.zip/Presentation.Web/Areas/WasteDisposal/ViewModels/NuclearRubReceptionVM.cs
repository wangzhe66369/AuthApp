﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels
{
    public class NuclearRubReceptionVM
    {
        /// <summary>
        /// 废物接收实体
        /// </summary>
        public NuclearRubReception NuclearRubReception { get; set; }
        /// <summary>
        /// 废物接收详细实体
        /// </summary>
        public NuclearRubReceptionD NuclearRubReceptionD { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string PackageCode { get; set; }

        /// <summary>
        /// 寄存器
        /// </summary>
        public string rubReceptionList { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }

    }
}