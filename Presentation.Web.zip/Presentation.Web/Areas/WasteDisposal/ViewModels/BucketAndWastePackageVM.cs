﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels
{
    public class BucketAndWastePackageVM
    {
        public string MaterialId { get; set; }
        public string BucketCode { get; set; }
        public string WasteType { get; set; }
        public string DealDate { get; set; }
        public string PackageCode { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }
    }
}