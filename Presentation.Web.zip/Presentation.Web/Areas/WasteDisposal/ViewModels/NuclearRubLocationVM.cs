﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteDisposal.ViewModels
{
    public class NuclearRubLocationVM
    {
        
        /// <summary>
        ///废物处置定位处置
        /// </summary>
        public NuclearRubLocation NuclearRubLocation { get; set; }

        /// <summary>
        ///废物编号
        /// </summary>
        public string PackageCode { get; set; }

        
        /// <summary>
        ///处置单元号
        /// </summary>
        public List<SelectListItem>  UnitCodeList { get; set; }
        /// <summary>
        /// 定位方案
        /// </summary>
        public List<SelectListItem> FlagRodiodList { get; set; }
        /// <summary>
        /// 容器类型
        /// </summary>
        public List<SelectListItem> BucketTypeList { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> LocationAttachment { get; set; }
        /// <summary>
        /// 坐标集合
        /// </summary>
        public List<PointData> PointList { get; set; }
        /// <summary>
        /// 已被占用位置的X坐标
        /// </summary>
        public string ExistPointX { get; set; }
        /// <summary>
        /// 已被占用位置的Y坐标
        /// </summary>
        public string ExistPointY { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
        /// <summary>
        /// X坐标
        /// </summary>
        public string pointX { get; set; }
        /// <summary>
        /// Y坐标
        /// </summary>
        public string pointY { get; set; }
        /// <summary>
        /// Z坐标
        /// </summary>
        public string pointZ { get; set; }
        /// <summary>
        /// Z坐标
        /// </summary>
        public string pointZ1 { get; set; }
        /// <summary>
        /// Z坐标
        /// </summary>
        public string pointZ2 { get; set; }
        


    }
    /// <summary>
    /// 坐标集合
    /// </summary>
    public class PointData
    {
        /// <summary>
        /// 桶主键ID
        /// </summary>
        public string BucketId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 废物货包号
        /// </summary>
        public string PackageCode { get; set; }
        /// <summary>
        /// X坐标
        /// </summary>
        public string PointX { get; set; }
        /// <summary>
        /// Y坐标
        /// </summary>
        public string PointY { get; set; }
        /// <summary>
        /// Z坐标
        /// </summary>
        public string PointZ { get; set; }
    }
}