﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteDisposal
{
    public class WasteDisposalAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "WasteDisposal";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "WasteDisposal_default",
                "WasteDisposal/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
