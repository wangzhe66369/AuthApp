﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using NET01.CoreFramework;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.MaterialManage.Controllers
{
    public class MaterialTransferController : Controller
    {
        IMaterialTransferRepository _MaterialTransferRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        IMaterialInputRepository _MaterialInputRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        INuclearBucketChangeRepository _NuclearBucketChangeRepository;
        INuclearMStockRepository _NuclearMStockRepository;
        IMaterialBatchRepository _MaterialBatchRepository;
        public MaterialTransferController(IBasicObjectRepository _BasicObjectRepository,
                                            IMaterialTransferRepository _MaterialTransferRepository,
                                            IMaterialTypeRepository _MaterialTypeRepository,
                                            IMaterialInputRepository _MaterialInputRepository,
                                            INuclearBucketRepository _NuclearBucketRepository,
                                            INuclearBucketChangeRepository _NuclearBucketChangeRepository,
                                            INuclearMStockRepository _NuclearMStockRepository,
                                            IMaterialBatchRepository _MaterialBatchRepository
            )
        {
            this._MaterialTransferRepository = _MaterialTransferRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._MaterialInputRepository = _MaterialInputRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._NuclearBucketChangeRepository = _NuclearBucketChangeRepository;
            this._NuclearMStockRepository = _NuclearMStockRepository;
            this._MaterialBatchRepository = _MaterialBatchRepository;
        }
        /// <summary>
        /// 初始页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "材料转运")]
        public ActionResult Index()
        {
            MaterialTransferVM vm = new MaterialTransferVM();
            vm.OperationList = CommonHelper.GetOperationList("Material_Transfer");
            //材料名称下拉设置数据
            List<NuclearMStock> list = _NuclearMStockRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderByDescending(o => o.MaterialId).GroupBy(c => c.MaterialId).Select(g => g.First()).ToList();
            List<MaterialType> listType = new List<MaterialType>();
            foreach (var item in list)
            {
                MaterialType materialType = _MaterialTypeRepository.Get(item.MaterialId);
                if (materialType != null)
                {
                    listType.Add(materialType);
                }
            }
            SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
            ViewData["MaterialName"] = s1;
            //存放地点下拉设置数据
            IQueryable<BasicObject> storageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storageLocationList = new List<BasicObject>();
            if (storageLocationQuery!=null && storageLocationQuery.Count() > 0)
            {
                storageLocationList = storageLocationQuery.ToList();
            }
            SelectList SelectList = new SelectList(storageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;
            return View(vm);
        }

        /// <summary>
        /// 编辑页面数据显示
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Edit(string id)
        {
            //材料名称下拉设置数据
            List<NuclearMStock> list = _NuclearMStockRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderByDescending(o => o.MaterialId).GroupBy(c => c.MaterialId).Select(g => g.First()).ToList();
            List<MaterialType> listType = new List<MaterialType>();
            foreach (var item in list)
            {
                MaterialType materialType = _MaterialTypeRepository.Get(item.MaterialId);
                if (materialType != null)
                {
                    listType.Add(materialType);
                }

            }
            if (list.Count() == 0)
            {
                MaterialType materialType = new MaterialType();
                listType.Add(materialType);
            }
            SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
            ViewData["MaterialName"] = s1;

            //获得数据库数据
            MaterialTransfer model = _MaterialTransferRepository.Get(id);

            MaterialTransferVM vm = new MaterialTransferVM();
            vm.MaterialTransfer = model;
            List<NuclearBucket>  materialTransferList = new List<NuclearBucket>();
            //如果是点击修改进入此页面
            if (!string.IsNullOrEmpty(id))
            {
                IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == id).AsQueryable();
                IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
                nuclearBucket = (from i in nuclearBucket
                                 join s in nuclearBucketChange
                                       on i.BucketId equals s.BucketId
                                 select i);
                if (nuclearBucket.Count() > 0)
                {
                    materialTransferList = nuclearBucket.ToList();
                }
            }
            var query = materialTransferList.OrderBy("BucketCode", SortDirection.Ascending);
            vm.materialTransferList = query.ToList();
            //存放地点下拉设置数据
            IQueryable<BasicObject> storageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storageLocationList = new List<BasicObject>();
            if (storageLocationQuery!=null && storageLocationQuery.Count() > 0)
            {
                storageLocationList = storageLocationQuery.ToList();
            }
            if (storageLocationQuery != null && storageLocationList.Count() == 0)
            {
                BasicObject basicObject = new BasicObject();
                storageLocationList.Add(basicObject);
            }
            SelectList SelectList = new SelectList(storageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;
            vm.OperationList = CommonHelper.GetOperationList("Material_Transfer");
            ///单位下拉列表
            vm.UnitList = new List<SelectListItem>();
            IQueryable<BasicObject> query1 = _BasicObjectRepository.GetSubobjectsByCode("Unit", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> unitList = new List<BasicObject>();
            if (query1 != null && query1.Count() > 0)
            {
                unitList = query1.ToList();
            }
            foreach (var item in unitList)
            {
                vm.UnitList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            ///批次
            ///
            vm.BatchCodeList = new List<SelectListItem>();
            IQueryable<NuclearMStock> nuclearMStock = _NuclearMStockRepository.GetAll().Where(d => d.InputId != null).GroupBy(d => d.InputId).Select(p => p.First()).AsQueryable();
            List<NuclearMStock> nuclearMStockList = new List<NuclearMStock>();
            if (nuclearMStock != null && nuclearMStock.Count() > 0)
            {
                nuclearMStockList = nuclearMStock.ToList();
                vm.BatchCodeList.Add(new SelectListItem { Text = "请选择", Value = "" });
                List<MaterialInput> materialInputList = new List<MaterialInput>();
                foreach (var item in nuclearMStockList)
                {
                    MaterialInput materialInput = _MaterialInputRepository.GetAll().Where(d => d.InputId == item.InputId).FirstOrDefault();
                    if (materialInput != null)
                    {
                        materialInputList.Add(materialInput);
                    }

                }
                List<MaterialInput> materialInputByList = materialInputList.OrderBy(d => d.ConfirmDate).ToList();
                foreach (var item in materialInputByList)
                {
                    if (!string.IsNullOrEmpty(item.BatchCode))
                    {
                        vm.BatchCodeList.Add(new SelectListItem { Text = item.BatchCode, Value = item.InputId });
                    }

                }

            }
            return View("Edit", vm);
        }
        /// <summary>
        /// 查看页面
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DetailView(string id)
        { 
            //获得数据库数据
            MaterialTransfer model = _MaterialTransferRepository.Get(id);
            MaterialTransferVM vm = new MaterialTransferVM();
            vm.MaterialTransfer = model;
            //List<NuclearBucket> materialTransferList = new List<NuclearBucket>();
            //如果是点击修改进入此页面
            if (!string.IsNullOrEmpty(id))
            {
                IQueryable<NuclearBucketChange> nuclearBucketChangeQuery = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == id).AsQueryable();
                IQueryable<NuclearBucket> nuclearBucketQuery = _NuclearBucketRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();

                nuclearBucketQuery = (from bq in nuclearBucketQuery
                                     join bcq in nuclearBucketChangeQuery
                                     on bq.BucketId equals bcq.BucketId
                                      select bq).OrderBy(d => d.BucketCode);

                if (nuclearBucketQuery.Count() > 0)
                {
                    vm.materialTransferList = nuclearBucketQuery.ToList();
                }



                //IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == id).AsQueryable();
                //foreach (var itemChage in nuclearBucketChange)
                //{
                //    NuclearBucket nuclearBucket = new NuclearBucket();

                //    nuclearBucket = _NuclearBucketRepository.Get(itemChage.BucketId);

                //    materialTransferList.Add(nuclearBucket);
                //}
            }
            //var query = materialTransferList.OrderBy("BucketCode", SortDirection.Ascending);
            //vm.materialTransferList = query.ToList();
            MaterialType materialType = _MaterialTypeRepository.Get(model.MaterialId);
            BasicObject outputLoction = _BasicObjectRepository.Get(model.OutputLoctionId);
            BasicObject inputLoction = _BasicObjectRepository.Get(model.InputLoctionId);
            vm.MaterialName = materialType.MaterialName;
            vm.OutputLocationName = outputLoction.Name;
            vm.InputLocationName = inputLoction.Name;
            return View("DetailView", vm);
        }

        /// <summary>
        /// 跳转到增加页面
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Add()
        {
            MaterialTransferVM vm = new MaterialTransferVM();
            vm.MaterialTransfer = new MaterialTransfer();
            vm.OperationList = CommonHelper.GetOperationList("Material_Transfer");
            //材料名称下拉设置数据
            List<NuclearMStock> list = _NuclearMStockRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderByDescending(o => o.MaterialId).GroupBy(c => c.MaterialId).Select(g => g.First()).ToList();
            List<MaterialType> listType = new List<MaterialType>();
            foreach (var item in list)
            {
                MaterialType materialType = _MaterialTypeRepository.Get(item.MaterialId);
                if (materialType != null)
                {
                    listType.Add(materialType);
                }

            }
            if (list.Count() == 0)
            {
                MaterialType materialType = new MaterialType();
                listType.Add(materialType);
            }
            SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
            ViewData["MaterialName"] = s1;

            //存放地点下拉设置数据
            IQueryable<BasicObject> storageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storageLocationList = new List<BasicObject>();
            if (storageLocationQuery!=null && storageLocationQuery.Count() > 0)
            {
                storageLocationList = storageLocationQuery.ToList();
            }
            if (storageLocationQuery != null && storageLocationList.Count() == 0)
            {
                BasicObject basicObject = new BasicObject();
                storageLocationList.Add(basicObject);
            }
            SelectList SelectList = new SelectList(storageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;
            //单位下拉列表
            vm.UnitList = new List<SelectListItem>();
            IQueryable<BasicObject> query = _BasicObjectRepository.GetSubobjectsByCode("Unit", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> unitList = new List<BasicObject>();
            if (query != null && query.Count() > 0)
            {
                unitList = query.ToList();
            }
            foreach (var item in unitList)
            {
                vm.UnitList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            ///批次
            ///
            vm.BatchCodeList = new List<SelectListItem>();
            IQueryable<NuclearMStock> nuclearMStock = _NuclearMStockRepository.GetAll().Where(d => d.InputId != null).GroupBy(d=>d.InputId).Select(p=>p.First()).AsQueryable();
            List<NuclearMStock> nuclearMStockList = new List<NuclearMStock>();
            if (nuclearMStock != null && nuclearMStock.Count() > 0)
            {
                nuclearMStockList = nuclearMStock.ToList();
                vm.BatchCodeList.Add(new SelectListItem { Text = "请选择", Value = "" });
                List<MaterialInput> materialInputList = new List<MaterialInput>();
                foreach (var item in nuclearMStockList)
                {
                    MaterialInput materialInput = _MaterialInputRepository.GetAll().Where(d => d.InputId == item.InputId).FirstOrDefault();
                    if (materialInput != null)
                    {
                        materialInputList.Add(materialInput);
                    }
                   
                }
                List<MaterialInput> materialInputByList = materialInputList.OrderBy(d => d.ConfirmDate).ToList();
                foreach (var item in materialInputByList)
                {
                    if (!string.IsNullOrEmpty(item.BatchCode))
                    {
                        vm.BatchCodeList.Add(new SelectListItem { Text = item.BatchCode, Value = item.InputId });  
                    }
                   
                }
               
            }
            return View(vm);

        }

        /// <summary>
        /// 页面得到最低库存
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SelectedTransfer(string id,string materialId,string outputLoctionId,string inputId, FormCollection formCollection)
        {
            try
            {
                MaterialType materialType = _MaterialTypeRepository.Get(materialId);
                string isBucket = materialType != null ? materialType.IsBucket : string.Empty;
                string unit = string.Empty;
                string unitId = string.Empty;
                Nullable<double> amout = 0;
                if (materialType != null)
                {
                    BasicObject  basicObject = _BasicObjectRepository.Get(materialType.UnitId);
                    unit = basicObject != null ? basicObject.Name : "";
                    unitId = materialType.UnitId;
                }

                List<NuclearMStock> nuclearMStock=new List<NuclearMStock>();
                nuclearMStock = _NuclearMStockRepository.GetAll().Where(d => d.MaterialId == materialId).Where(d => d.LocationId == outputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                if (!string.IsNullOrEmpty(inputId))
                {
                    nuclearMStock = nuclearMStock.Where(d => d.InputId == inputId).ToList();
                  
                }
                foreach (var itemStock in nuclearMStock)
                {
                    amout = itemStock.Amount + amout;
                }
                  
                if (!string.IsNullOrEmpty(id))
                {
                    IQueryable<MaterialTransfer> materialTransfer = _MaterialTransferRepository.GetAll().AsQueryable().Where(d => d.TransferId == id).Where(d => d.MaterialId == materialId).Where(d => d.OutputLoctionId == outputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                    List<MaterialTransfer> materialTransferList = materialTransfer.ToList();
                    if (materialTransferList[0].Status == "2")
                    {
                        if (materialTransferList.Count() > 0)
                        {
                            amout = amout + materialTransferList[0].Amount;
                        }
                    }
                }
                if (string.IsNullOrEmpty(isBucket))
                {
                    return Json("{\"result\":\"" + amout + "\",\"isBucket\":\"0\",\"unit\":\"" + unit + "\",\"unitId\":\"" + unitId + "\"}", JsonRequestBehavior.AllowGet);
                }
                return Json("{\"result\":\"" + amout + "\",\"isBucket\":\"" + isBucket + "\",\"unit\":\"" + unit + "\",\"unitId\":\"" + unitId + "\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"没有查询到桶的信息。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 材料转运-草稿保存
        /// </summary>
        /// <param name="model">MaterialTransfer</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraft(MaterialTransferVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.MaterialTransfer.TransferId))
                {
                    //存入转运表
                    TransferMethod(model,"0");
                    //桶的
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //存入详细表
                        string fail = BucketDetail(model, "");
                        if (fail.Contains("Drain"))
                        {
                            string[] bucketCode = fail.Split('_');
                            return Json("{\"result\":false,\"msg\":\"" + bucketCode[1] + "桶号已被消耗,不能准运。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Equals("fail"))
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Equals("noExist"))
                        {
                            return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }  
                }//修改
                else
                {
                    //根据入库ID查询
                    IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(model.MaterialTransfer.TransferId);
                    if (dataBucketChange.Count() > 0)
                    {
                        foreach (var itemChange in dataBucketChange)
                        {   //删除材料位置明细表
                            this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                        }
                    }
                    model.MaterialTransfer = _MaterialTransferRepository.Get(model.MaterialTransfer.TransferId);
                    if (model.MaterialTransfer.Status == "2")
                    {
                        //把库存表里的数据还原到没转运时
                        MaterialRestore(model.MaterialTransfer, model.hidBucketCodeType);
                    }
                    UpdateModel(model);
                    model.MaterialTransfer.Status = "0";
                    this._MaterialTransferRepository.Update(model.MaterialTransfer);
                    //桶的
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //存入详细表
                        string fail = BucketDetail(model, "");
                        if (fail.Contains("Drain"))
                        {
                            string[] bucketCode = fail.Split('_');
                            return Json("{\"result\":false,\"msg\":\"" + bucketCode[1] + "桶号已被消耗,不能准运。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Equals("fail"))
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Equals("noExist"))
                        {
                            return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }  

                }

                this._MaterialTransferRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认人
        /// </summary>
        /// <param name="model"></param>
        private static void ConfirmMethod(MaterialTransferVM model,string status)
        {
            model.MaterialTransfer.Status = status;
            model.MaterialTransfer.ConfirmDate = DateTime.Now;
            model.MaterialTransfer.ConfirmUserNo = AppContext.CurrentUser.UserId;
            model.MaterialTransfer.ConfirmUserName = AppContext.CurrentUser.UserName;
            model.MaterialTransfer.Stationcode = AppContext.CurrentUser.ProjectCode;
        }
        /// <summary>
        /// 转运表
        /// </summary>
        /// <param name="model"></param>
        /// <param name="status"></param>
        private void TransferMethod(MaterialTransferVM model,string status)
        {
            model.MaterialTransfer.TransferId = Guid.NewGuid().ToString();
            model.MaterialTransfer.Status = status;
            model.MaterialTransfer.CreateDate = DateTime.Now;
            model.MaterialTransfer.CreateUserNo = AppContext.CurrentUser.UserId;
            model.MaterialTransfer.CreateUserName = AppContext.CurrentUser.UserName;
            model.MaterialTransfer.Stationcode = AppContext.CurrentUser.ProjectCode;
            this._MaterialTransferRepository.Create(model.MaterialTransfer);
        }
       
         /// <summary>
        /// 转运表
        /// </summary>
        /// <param name="model"></param>
        /// <param name="status"></param>
        private void ConfirmTransferMethod(MaterialTransferVM model, string status)
        {
            model.MaterialTransfer.TransferId = Guid.NewGuid().ToString();
            model.MaterialTransfer.Status = status;
            model.MaterialTransfer.CreateDate = DateTime.Now;
            model.MaterialTransfer.CreateUserNo = AppContext.CurrentUser.UserId;
            model.MaterialTransfer.CreateUserName = AppContext.CurrentUser.UserName;
            model.MaterialTransfer.Stationcode = AppContext.CurrentUser.ProjectCode;
            model.MaterialTransfer.ConfirmDate = DateTime.Now;
            model.MaterialTransfer.ConfirmUserNo = AppContext.CurrentUser.UserId;
            model.MaterialTransfer.ConfirmUserName = AppContext.CurrentUser.UserName;
            model.MaterialTransfer.Stationcode = AppContext.CurrentUser.ProjectCode;
            this._MaterialTransferRepository.Create(model.MaterialTransfer);
        }
        /// <summary>
        /// 转运的详细表
        /// </summary>
        /// <param name="model"></param>
        private string BucketDetail(MaterialTransferVM model,string type)
        {
            string[] arrayAllCode = null;
            string[] arrayCode = null;
            string[] arrayBucketCode = null;
            arrayAllCode = model.hidBucketCodeType.Trim(new char[] { ';' }).Split(new char[] { ';' });
            foreach (var code in arrayAllCode)
            {
                string bucketCode = string.Empty;
                arrayCode = code.Trim(new char[] { ',' }).Split(new char[] { ',' });
                if (arrayCode.Length == 3)
                {
                    int startBucketCode = Convert.ToInt32(arrayCode[1]);
                    int endBucketCode = Convert.ToInt32(arrayCode[2]);
                    if (startBucketCode == endBucketCode)
                    {
                        bucketCode = arrayCode[0] + arrayCode[1];
                    }
                    else
                    {
                        for (int i = startBucketCode; i <= endBucketCode; i++)
                        {
                            
                            bucketCode = bucketCode + arrayCode[0] + i.ToString().PadLeft(arrayCode[2].Length, '0') + ",";  
                        }
                    }

                }
                else if (arrayCode.Length == 2)
                {
                    bucketCode = arrayCode[0] + arrayCode[1];
                }
                else if (arrayCode.Length == 1)
                {
                    bucketCode = arrayCode[0];
                }

                arrayBucketCode = bucketCode.Trim(new char[] { ',' }).Split(new char[] { ',' });
                foreach (var itemCode in arrayBucketCode)
                {
                    IQueryable<NuclearBucket> data = _NuclearBucketRepository.GetAll().AsQueryable().Where(s => s.BucketCode == itemCode).Where(d => d.LocationId == model.MaterialTransfer.OutputLoctionId&&d.MaterialId==model.MaterialTransfer.MaterialId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                    if (data.Count() > 0)
                    {
                        foreach (var itemData in data)
                        {
                            if (itemData.IsDrain == "1")
                            {
                                return "Drain_" + itemData.BucketCode;
                            }
                            if (itemData.Status == "2")
                            {

                                if (type == "Confirm")
                                {
                                    //更新桶信息
                                    itemData.LocationId = model.MaterialTransfer.InputLoctionId;
                                    this._NuclearBucketRepository.Update(itemData);
                                }
                                //在桶位置编号表明细存入数据
                                NuclearBucketChange nuclearBucketChange = new NuclearBucketChange();
                                nuclearBucketChange.Detailid = Guid.NewGuid().ToString();
                                nuclearBucketChange.ChangeType = "TRANSFER";
                                nuclearBucketChange.BusinessId = model.MaterialTransfer.TransferId;
                                nuclearBucketChange.BucketId = itemData.BucketId;
                                this._NuclearBucketChangeRepository.Create(nuclearBucketChange);
                            }
                            else
                            {
                                return "fail";
                            }

                        }
                    }
                    else
                    {
                        return "noExist";
                    }
                   

                }
            }
            return "success";
        }

        /// <summary>
        /// 材料转运_提交
        /// </summary>
        /// <param name="model">MaterialTransfer</param>
        /// <param name="formCollection">FormCollection</param>
        /// <returns>Json</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult CommitMaterial(MaterialTransferVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
              try
            {

                if (string.IsNullOrEmpty(model.MaterialTransfer.TransferId))
                {
                    //存入转运表
                    TransferMethod(model,"1");
                    //桶的
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //存入详细表
                        string fail = BucketDetail(model, "");
                        if (fail.Contains("Drain"))
                        {
                            string[] bucketCode = fail.Split('_');
                            return Json("{\"result\":false,\"msg\":\"" + bucketCode[1] + "桶号已被消耗,不能准运。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Equals("fail"))
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Equals("noExist"))
                        {
                            return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }  
                  
                }
                else
                {
                    //根据入库ID查询
                    IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(model.MaterialTransfer.TransferId);
                    if (dataBucketChange.Count() > 0)
                    {
                        foreach (var itemChange in dataBucketChange)
                        {   //删除材料位置明细表
                            this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                        }
                    }
                    model.MaterialTransfer = _MaterialTransferRepository.Get(model.MaterialTransfer.TransferId);
                    if (model.MaterialTransfer.Status == "2")
                    {
                        //把库存表里的数据还原到没转运时
                        MaterialRestore(model.MaterialTransfer, model.hidBucketCodeType);
                    }
                    UpdateModel(model);
                    //确认人
                    model.MaterialTransfer.Status = "1";
                    this._MaterialTransferRepository.Update(model.MaterialTransfer);
                    //桶的
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //存入详细表
                        string fail = BucketDetail(model, "");
                        if (fail.Contains("Drain"))
                        {
                            string[] bucketCode = fail.Split('_');
                            return Json("{\"result\":false,\"msg\":\"" + bucketCode[1] + "桶号已被消耗,不能准运。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Equals("fail"))
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Equals("noExist"))
                        {
                            return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }  
                }

                this._MaterialTransferRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 材料转运_确认_新增
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "材料转运确认")]
        public JsonResult ConfirmMaterial(MaterialTransferVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //存入转运表
                ConfirmTransferMethod(model, "2");
                //桶的确认
                if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                {
                    //存入详细表
                    string fail = BucketDetail(model, "Confirm");
                    if (fail.Contains("Drain"))
                    {
                        string[] bucketCode = fail.Split('_');
                        return Json("{\"result\":false,\"msg\":\"" + bucketCode[1] + "桶号已被消耗,不能准运。\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (fail.Equals("fail"))
                    {
                        return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (fail.Equals("noExist"))
                    {
                        return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号。\"}", JsonRequestBehavior.AllowGet);
                    }
                }  
                //更新材料库存表
                string returnVlue=MStockafterUpdate(model);
                if (returnVlue == "No")
                {
                    return Json("{\"result\":false,\"msg\":\"输入数量大于批次数量。\"}", JsonRequestBehavior.AllowGet);
                }
                this._MaterialTransferRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 材料转运_确认_修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "材料转运确认")]
        public JsonResult ConfirmMaterialUpdate(MaterialTransferVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                model.MaterialTransfer = _MaterialTransferRepository.Get(model.MaterialTransfer.TransferId);
                 string[] sameArr=null;
                //状态是已确认
                if (model.MaterialTransfer.Status.Equals("2"))
                {
                    //更新转运表
                    UpdateModel(model);
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //查询转运明细和桶信息
                        IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == model.MaterialTransfer.TransferId).AsQueryable();
                        List<string> nuclearBucketStrList = new List<string>();
                        foreach (var itemChage in nuclearBucketChange)
                        {
                            NuclearBucket nuclearBucket = new NuclearBucket();
                            nuclearBucket = _NuclearBucketRepository.Get(itemChage.BucketId);
                            nuclearBucketStrList.Add(nuclearBucket.BucketCode);
                        }
                        //页面中传过来的数组
                        string[] arrBucketAllCode = model.hidBucketCodeType.Trim(new char[] { ';' }).Split(new char[] { ';' }); ;
                        //数据库中桶号的数组
                        string[] arrFromDataBase = nuclearBucketStrList.ToArray();
                        //求交集
                        sameArr = arrBucketAllCode.Intersect(arrFromDataBase).ToArray();
                        
                       
                        string[] difArr = arrFromDataBase.Except(sameArr).ToArray();

                        //交集
                        foreach (var itemdifArr in difArr)
                        {
                            IQueryable<NuclearBucket> data = _NuclearBucketRepository.GetAll().Where(s => s.BucketCode == itemdifArr).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
                            List<NuclearBucket> dataList = data.ToList();
                            if (dataList.Count() > 0)
                            {
                                foreach (var item in dataList)
                                {

                                    item.LocationId = model.MaterialTransfer.InputLoctionId;
                                    this._NuclearBucketRepository.Update(item);
                                   
                                }
                            }
                        }
                        //删除页面中减少的
                        foreach (var itemdifArr in difArr)
                        {
                            IQueryable<NuclearBucket> data = _NuclearBucketRepository.GetAll().Where(s => s.BucketCode == itemdifArr).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();

                            if (data.Count() > 0)
                            {
                                List<NuclearBucket> dataList = data.ToList();
                                foreach (var item in dataList)
                                {
                                   
                                    if (dataList[0].IsDrain == "1")
                                    {
                                        return Json("{\"result\":false,\"msg\":\"桶号已已被消耗,请先处理消耗桶号。\"}", JsonRequestBehavior.AllowGet);
                                    }
                                    item.LocationId = model.MaterialTransfer.OutputLoctionId;
                                    this._NuclearBucketRepository.Update(item);
                                    List<NuclearBucketChange> dataChange = this._NuclearBucketChangeRepository.GetAll().Where(s => s.BucketId == item.BucketId && s.ChangeType == "TRANSFER").ToList();
                                    if (dataChange.Count() > 0)
                                    {
                                        this._NuclearBucketChangeRepository.DeleteById(dataChange[0].Detailid);
                                    }
                                }
                            }
                        }
                        //页面中新添加的桶号
                        foreach (var bucketCode in arrBucketAllCode)
                        {
                            if (!arrFromDataBase.ToArray().Contains(bucketCode))
                            {
                                IQueryable<NuclearBucket> isData = _NuclearBucketRepository.GetAll().AsQueryable().Where(s => s.BucketCode == bucketCode).Where(d => d.LocationId == model.MaterialTransfer.OutputLoctionId&&d.MaterialId==model.MaterialTransfer.MaterialId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                                List<NuclearBucket> isDataList = isData.ToList();
                                if (isDataList.Count() == 0)
                                {
                                    return Json("{\"result\":false,\"msg\":\"该仓库不存在桶号。\"}", JsonRequestBehavior.AllowGet);
                                }
                                if (isDataList[0].Status != "2")
                                {
                                    return Json("{\"result\":false,\"msg\":\"桶号未被确认。\"}", JsonRequestBehavior.AllowGet);
                                }
                                IQueryable<NuclearBucket> data = _NuclearBucketRepository.GetAll().Where(s => s.BucketCode == bucketCode).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
                                if (data.Count() > 0)
                                {
                                    List<NuclearBucket> dataList = data.ToList();
                                    foreach (var item in dataList)
                                    {
                                        //更新桶信息
                                        item.LocationId = model.MaterialTransfer.InputLoctionId;
                                        this._NuclearBucketRepository.Update(item);
                                        //往桶明细表插入数据
                                        List<NuclearBucketChange> dataChange = this._NuclearBucketChangeRepository.GetAll().Where(s => s.BucketId == item.BucketId).ToList();
                                        if (dataChange.Count() > 0)
                                        {
                                            //在桶位置编号表明细存入数据
                                            NuclearBucketChange nuclearBucketChangeDetail = new NuclearBucketChange();
                                            nuclearBucketChangeDetail.Detailid = Guid.NewGuid().ToString();
                                            nuclearBucketChangeDetail.ChangeType = "TRANSFER";
                                            nuclearBucketChangeDetail.BusinessId = model.MaterialTransfer.TransferId;
                                            nuclearBucketChangeDetail.BucketId = item.BucketId;
                                            this._NuclearBucketChangeRepository.Create(nuclearBucketChangeDetail);
                                        }
                                    }
                                }
                              
                            }
                        }
                    }
                    //把库存表里的数据还原到没转运时
                    MaterialRestore(model.MaterialTransfer, model.hidBucketCodeType);
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //交集数据判断
                        foreach (var item in sameArr)
                        {
                            List<NuclearBucket> dataSame = _NuclearBucketRepository.GetAll().Where(s => s.BucketCode == item && s.MaterialId == model.MaterialTransfer.MaterialId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                            if (dataSame.Count() == 0)
                            {
                                return Json("{\"result\":false,\"msg\":\"该材料没有该桶号。\"}", JsonRequestBehavior.AllowGet);
                            }
                        }
                    }
                    ConfirmMethod(model, "2");
                    this._MaterialTransferRepository.Update(model.MaterialTransfer);
                  
                    //更新材料库存表
                    string returnVlue = MStockafterUpdate(model);
                    if (returnVlue == "No")
                    {
                        return Json("{\"result\":false,\"msg\":\"输入数量大于批次数量。\"}", JsonRequestBehavior.AllowGet);
                    }
                }//状态未确认
                else
                {
                    //更新转运表
                    UpdateModel(model);
                    ConfirmMethod(model, "2");
                    this._MaterialTransferRepository.Update(model.MaterialTransfer);
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //根据转运ID查询
                        IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(model.MaterialTransfer.TransferId);
                        List<NuclearBucketChange> dataBucketChangeList = dataBucketChange.ToList();
                        if (dataBucketChangeList.Count() > 0)
                        {
                            foreach (var itemChange in dataBucketChangeList)
                            {   //删除材料位置明细表
                                this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                            }
                        }
                        //存入详细表
                        string fail = BucketDetail(model, "Confirm");
                        if (fail.Contains("Drain"))
                        {
                            string[] bucketCode = fail.Split('_');
                            return Json("{\"result\":false,\"msg\":\""+bucketCode[1]+"桶号已被消耗,不能准运。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Equals("fail"))
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Equals("noExist"))
                        {
                            return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }

                    //更新材料库存表
                    MStockafterUpdate(model);
                    
                }

                this._MaterialTransferRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }

            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        
      
        ///// <summary>
        /// 把库存表里的数据还原到没转运时
        /// </summary>
        /// <param name="model"></param>
        private void MaterialRestore(MaterialTransfer model,string hidBucketCodeType)
        {


            if (string.IsNullOrEmpty(hidBucketCodeType))
            {
                NuclearMStock dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.InputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.InputId == model.InputId).FirstOrDefault();
                double? overrideAmount = 0;
                dataMStock.Amount = dataMStock.Amount - model.Amount;
                overrideAmount = ((dataMStock.OverrideAmount == null ? 0 : dataMStock.OverrideAmount) - model.Amount) < 0 ? dataMStock.OverrideAmount : model.Amount;
                ///
                ///用于过期转运
                ///
                dataMStock.OverrideAmount = ((dataMStock.OverrideAmount == null ? 0 : dataMStock.OverrideAmount) - model.Amount) < 0 ? 0 : dataMStock.OverrideAmount - model.Amount;
                this._NuclearMStockRepository.Update(dataMStock);

                NuclearMStock dataMStockafter = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.OutputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.InputId == model.InputId).FirstOrDefault();
                if (dataMStockafter == null)
                {
                    //在材料库存信息存入数据
                    NuclearMStock nuclearMStock = new NuclearMStock();
                    nuclearMStock.StockId = Guid.NewGuid().ToString();
                    nuclearMStock.MaterialId = model.MaterialId;
                    nuclearMStock.LocationId = model.OutputLoctionId;
                    nuclearMStock.Amount = model.Amount;
                    nuclearMStock.OverrideAmount = dataMStock.OverrideAmount;
                    nuclearMStock.InputId = model.InputId;
                    nuclearMStock.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearMStockRepository.Create(nuclearMStock);
                }
                else
                {
                    //出库地点加上数据
                    dataMStockafter.Amount = dataMStockafter.Amount + model.Amount;
                    ///
                    ///用于过期转运
                    ///
                    dataMStockafter.OverrideAmount = (dataMStockafter.OverrideAmount == null ? 0 : dataMStockafter.OverrideAmount) + overrideAmount;
                    this._NuclearMStockRepository.Update(dataMStockafter);
                }
                
            }
            else
            {
                //查询出库信息
                IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.InputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                List<NuclearMStock> dataMStockList = dataMStock.ToList();
                double? overrideAmount = 0;
                foreach (var itemMStock in dataMStockList)
                {   //减去入库存入的数据
                    itemMStock.Amount = itemMStock.Amount - model.Amount;
                    overrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.Amount) < 0 ? itemMStock.OverrideAmount : model.Amount;
                    ///
                    ///用于过期转运
                    ///
                    itemMStock.OverrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.Amount) < 0 ? 0 : itemMStock.OverrideAmount - model.Amount;
                    this._NuclearMStockRepository.Update(itemMStock);
                }
                IQueryable<NuclearMStock> dataMStockafter = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.OutputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                List<NuclearMStock> materialStockList = dataMStockafter.ToList();
                foreach (var item in materialStockList)
                {   //出库地点加上数据
                    item.Amount = item.Amount + model.Amount;
                    ///
                    ///用于过期转运
                    ///
                    item.OverrideAmount = (item.OverrideAmount == null ? 0 : item.OverrideAmount) + overrideAmount;
                    this._NuclearMStockRepository.Update(item);
                }
            }
            ////查询出库信息
            //IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.InputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //List<NuclearMStock> dataMStockList = dataMStock.ToList();
            //double? overrideAmount = 0;
            //foreach (var itemMStock in dataMStockList)
            //{   //减去入库存入的数据
            //    itemMStock.Amount = itemMStock.Amount - model.Amount;
            //    overrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.Amount) < 0 ? itemMStock.OverrideAmount : model.Amount;
            //    ///
            //    ///用于过期转运
            //    ///
            //    itemMStock.OverrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.Amount) < 0 ? 0 : itemMStock.OverrideAmount - model.Amount;
            //    this._NuclearMStockRepository.Update(itemMStock);
            //}
            //IQueryable<NuclearMStock> dataMStockafter = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.OutputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //List<NuclearMStock> materialStockList = dataMStockafter.ToList();
            //foreach (var item in materialStockList)
            //{   //出库地点加上数据
            //    item.Amount = item.Amount +model.Amount;
            //    ///
            //    ///用于过期转运
            //    ///
            //    item.OverrideAmount = (item.OverrideAmount == null ? 0 : item.OverrideAmount) + overrideAmount;
            //    this._NuclearMStockRepository.Update(item);
            //}
        }


        ///// <summary>
        /// 删除时把库存表里的数据还原到没转运时
        /// </summary>
        /// <param name="model"></param>
        private void MaterialRestoreDelete(MaterialTransfer model)
        {

            MaterialTransfer materialTransfer = _MaterialTransferRepository.Get(model.TransferId);
            if (!string.IsNullOrEmpty(materialTransfer.InputId))
            {
                NuclearMStock dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.InputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.InputId == model.InputId).FirstOrDefault();
                double? overrideAmount = 0;
                dataMStock.Amount = dataMStock.Amount - model.Amount;
                overrideAmount = ((dataMStock.OverrideAmount == null ? 0 : dataMStock.OverrideAmount) - model.Amount) < 0 ? dataMStock.OverrideAmount : model.Amount;
                ///
                ///用于过期转运
                ///
                dataMStock.OverrideAmount = ((dataMStock.OverrideAmount == null ? 0 : dataMStock.OverrideAmount) - model.Amount) < 0 ? 0 : dataMStock.OverrideAmount - model.Amount;
                this._NuclearMStockRepository.Update(dataMStock);

                NuclearMStock dataMStockafter = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.OutputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.InputId == model.InputId).FirstOrDefault();
                if (dataMStockafter == null)
                {
                    //在材料库存信息存入数据
                    NuclearMStock nuclearMStock = new NuclearMStock();
                    nuclearMStock.StockId = Guid.NewGuid().ToString();
                    nuclearMStock.MaterialId = model.MaterialId;
                    nuclearMStock.LocationId = model.OutputLoctionId;
                    nuclearMStock.Amount = model.Amount;
                    nuclearMStock.OverrideAmount = dataMStock.OverrideAmount;
                    nuclearMStock.InputId = model.InputId;
                    nuclearMStock.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearMStockRepository.Create(nuclearMStock);
                }
                else
                {
                    //出库地点加上数据
                    dataMStockafter.Amount = dataMStockafter.Amount + model.Amount;
                    ///
                    ///用于过期转运
                    ///
                    dataMStockafter.OverrideAmount = (dataMStockafter.OverrideAmount == null ? 0 : dataMStockafter.OverrideAmount) + overrideAmount;
                    this._NuclearMStockRepository.Update(dataMStockafter);
                }
                MaterialBatch materialBatch = _MaterialBatchRepository.GetAll().Where(d => d.BusinessId == materialTransfer.TransferId && d.BusinessType == "1").FirstOrDefault();
                _MaterialBatchRepository.DeleteById(materialBatch.DetailId);

            }
            else
            {
                //查询出库信息
                IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.InputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                List<NuclearMStock> dataMStockList = dataMStock.ToList();
                double? overrideAmount = 0;
                foreach (var itemMStock in dataMStockList)
                {   //减去入库存入的数据
                    itemMStock.Amount = itemMStock.Amount - model.Amount;
                    overrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.Amount) < 0 ? itemMStock.OverrideAmount : model.Amount;
                    ///
                    ///用于过期转运
                    ///
                    itemMStock.OverrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.Amount) < 0 ? 0 : itemMStock.OverrideAmount - model.Amount;
                    this._NuclearMStockRepository.Update(itemMStock);
                }
                IQueryable<NuclearMStock> dataMStockafter = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.OutputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                List<NuclearMStock> materialStockList = dataMStockafter.ToList();
                foreach (var item in materialStockList)
                {   //出库地点加上数据
                    item.Amount = item.Amount + model.Amount;
                    ///
                    ///用于过期转运
                    ///
                    item.OverrideAmount = (item.OverrideAmount == null ? 0 : item.OverrideAmount) + overrideAmount;
                    this._NuclearMStockRepository.Update(item);
                }
            }
            
        }
        /// <summary>
        /// 更新材料库存表
        /// </summary>
        /// <param name="model"></param>
        private string MStockafterUpdate(MaterialTransferVM model)
        {
            if (string.IsNullOrEmpty(model.hidBucketCodeType))
            {
              
                NuclearMStock dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialTransfer.MaterialId, model.MaterialTransfer.OutputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.InputId == model.MaterialTransfer.InputId).FirstOrDefault();
                if (dataMStock != null)
                {
                    double? overrideAmount = 0;
                    if (dataMStock.Amount > model.MaterialTransfer.Amount)
                    {

                        dataMStock.Amount = dataMStock.Amount - model.MaterialTransfer.Amount;
                        overrideAmount = ((dataMStock.OverrideAmount == null ? 0 : dataMStock.OverrideAmount) - model.MaterialTransfer.Amount) < 0 ? dataMStock.OverrideAmount : model.MaterialTransfer.Amount;
                        ///
                        ///用于过期转运
                        ///
                        dataMStock.OverrideAmount = ((dataMStock.OverrideAmount == null ? 0 : dataMStock.OverrideAmount) - model.MaterialTransfer.Amount) < 0 ? 0 : dataMStock.OverrideAmount - model.MaterialTransfer.Amount;
                        this._NuclearMStockRepository.Update(dataMStock);

                        //在材料库存信息存入数据
                        NuclearMStock nuclearMStock = new NuclearMStock();
                        nuclearMStock.StockId = Guid.NewGuid().ToString();
                        nuclearMStock.MaterialId = model.MaterialTransfer.MaterialId;
                        nuclearMStock.LocationId = model.MaterialTransfer.InputLoctionId;
                        nuclearMStock.Amount = model.MaterialTransfer.Amount;
                        nuclearMStock.OverrideAmount = dataMStock.OverrideAmount;
                        nuclearMStock.InputId = dataMStock.InputId;
                        nuclearMStock.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearMStockRepository.Create(nuclearMStock);

                    }
                     else if (dataMStock.Amount == model.MaterialTransfer.Amount)
                    {
                        dataMStock.Amount = dataMStock.Amount - model.MaterialTransfer.Amount;
                        overrideAmount = ((dataMStock.OverrideAmount == null ? 0 : dataMStock.OverrideAmount) - model.MaterialTransfer.Amount) < 0 ? dataMStock.OverrideAmount : model.MaterialTransfer.Amount;
                        ///
                        ///用于过期转运
                        ///
                        dataMStock.OverrideAmount = ((dataMStock.OverrideAmount == null ? 0 : dataMStock.OverrideAmount) - model.MaterialTransfer.Amount) < 0 ? 0 : dataMStock.OverrideAmount - model.MaterialTransfer.Amount;
                        this._NuclearMStockRepository.Update(dataMStock);
                        
                         //在材料库存信息存入数据
                        NuclearMStock nuclearMStock = new NuclearMStock();
                        nuclearMStock.StockId = Guid.NewGuid().ToString();
                        nuclearMStock.MaterialId = model.MaterialTransfer.MaterialId;
                        nuclearMStock.LocationId = model.MaterialTransfer.InputLoctionId;
                        nuclearMStock.Amount = model.MaterialTransfer.Amount;
                        nuclearMStock.OverrideAmount = dataMStock.OverrideAmount;
                        nuclearMStock.InputId = dataMStock.InputId;
                        nuclearMStock.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearMStockRepository.Create(nuclearMStock);
                        this._NuclearMStockRepository.DeleteById(dataMStock.StockId);

                    }else
                    {
                        return "No";
                    }
                }
                MaterialBatch materialBatch =new MaterialBatch();
                materialBatch.DetailId=Guid.NewGuid().ToString();
                materialBatch.BusinessId=model.MaterialTransfer.TransferId;
                materialBatch.BusinessType="1";
                materialBatch.InputId=dataMStock.InputId;
                _MaterialBatchRepository.Create(materialBatch);

            }
            else 
            {

                //减去出库地点的数据
                IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialTransfer.MaterialId, model.MaterialTransfer.OutputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                List<NuclearMStock> dataMStockList = dataMStock.ToList();
                double? overrideAmount = 0;
                foreach (var itemMStock in dataMStockList)
                {
                    itemMStock.Amount = itemMStock.Amount - model.MaterialTransfer.Amount;
                    overrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.MaterialTransfer.Amount) < 0 ? itemMStock.OverrideAmount : model.MaterialTransfer.Amount;
                    ///
                    ///用于过期转运
                    ///
                    itemMStock.OverrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.MaterialTransfer.Amount) < 0 ? 0 : itemMStock.OverrideAmount - model.MaterialTransfer.Amount;

                    this._NuclearMStockRepository.Update(itemMStock);
                }

                IQueryable<NuclearMStock> dataMStockafter = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialTransfer.MaterialId, model.MaterialTransfer.InputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                //材料表里已经存在,只更新数量
                if (dataMStockafter.Count() > 0)
                {
                    List<NuclearMStock> materialStockList = dataMStockafter.ToList();
                    foreach (var item in materialStockList)
                    {
                        item.Amount = item.Amount + model.MaterialTransfer.Amount;
                        ///
                        ///用于过期转运
                        ///
                        item.OverrideAmount = (item.OverrideAmount == null ? 0 : item.OverrideAmount) + overrideAmount;
                        this._NuclearMStockRepository.Update(item);
                    }
                }//材料表里不存在,新建一条
                else
                {
                    //在材料库存信息存入数据
                    NuclearMStock nuclearMStock = new NuclearMStock();
                    nuclearMStock.StockId = Guid.NewGuid().ToString();
                    nuclearMStock.MaterialId = model.MaterialTransfer.MaterialId;
                    nuclearMStock.LocationId = model.MaterialTransfer.InputLoctionId;
                    nuclearMStock.Amount = model.MaterialTransfer.Amount;
                    ///
                    ///用于过期转运
                    ///
                    nuclearMStock.OverrideAmount = overrideAmount;
                    nuclearMStock.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearMStockRepository.Create(nuclearMStock);
                }
            
            }
            return null;
            ////减去出库地点的数据
            //IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialTransfer.MaterialId, model.MaterialTransfer.OutputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //List<NuclearMStock> dataMStockList = dataMStock.ToList();
            //double? overrideAmount = 0;
            //foreach (var itemMStock in dataMStockList)
            //{
            //    itemMStock.Amount =itemMStock.Amount -model.MaterialTransfer.Amount;
            //    overrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.MaterialTransfer.Amount) < 0 ? itemMStock.OverrideAmount : model.MaterialTransfer.Amount;
            //    ///
            //    ///用于过期转运
            //    ///
            //    itemMStock.OverrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.MaterialTransfer.Amount) < 0 ? 0 : itemMStock.OverrideAmount - model.MaterialTransfer.Amount;
               
            //    this._NuclearMStockRepository.Update(itemMStock);
            //}

            //IQueryable<NuclearMStock> dataMStockafter = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialTransfer.MaterialId, model.MaterialTransfer.InputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            ////材料表里已经存在,只更新数量
            //if (dataMStockafter.Count() > 0)
            //{
            //    List<NuclearMStock> materialStockList = dataMStockafter.ToList();
            //    foreach (var item in materialStockList)
            //    {
            //        item.Amount = item.Amount + model.MaterialTransfer.Amount;
            //        ///
            //        ///用于过期转运
            //        ///
            //        item.OverrideAmount = (item.OverrideAmount == null ? 0 : item.OverrideAmount) + overrideAmount;
            //        this._NuclearMStockRepository.Update(item);
            //    }
            //}//材料表里不存在,新建一条
            //else
            //{
            //    //在材料库存信息存入数据
            //    NuclearMStock nuclearMStock = new NuclearMStock();
            //    nuclearMStock.StockId = Guid.NewGuid().ToString();
            //    nuclearMStock.MaterialId = model.MaterialTransfer.MaterialId;
            //    nuclearMStock.LocationId = model.MaterialTransfer.InputLoctionId;
            //    nuclearMStock.Amount = model.MaterialTransfer.Amount;
            //    ///
            //    ///用于过期转运
            //    ///
            //    nuclearMStock.OverrideAmount = overrideAmount;
            //    nuclearMStock.Stationcode = AppContext.CurrentUser.ProjectCode;
            //    this._NuclearMStockRepository.Create(nuclearMStock);
            //}
        }
      
        /// <summary>
        /// 初始查询
        /// </summary>
        /// <param name="materialInputCondition"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetMaterialTransferList(MaterialTransferCondition materialTransferCondition, string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<MaterialTransferView> dataEvery = this._MaterialTransferRepository.QueryList(materialTransferCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            if (!string.IsNullOrEmpty(materialTransferCondition.BucketCode))
            {
                IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(d => d.BucketCode.Trim().ToUpper().Contains(materialTransferCondition.BucketCode.Trim().ToUpper())).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);

                IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().AsQueryable().Where(d => d.ChangeType == "TRANSFER");
                nuclearBucketChange = (from i in nuclearBucketChange
                                       join s in nuclearBucket
                                       on i.BucketId equals s.BucketId
                                       select i).Distinct();

                dataEvery = (from i in dataEvery
                             join s in nuclearBucketChange
                             on i.TransferId equals s.BusinessId
                             select i).Distinct().OrderBy("CreateDate", SortDirection.Descending).OrderBy("Status", SortDirection.Ascending);

            }
            else
            {
                dataEvery = this._MaterialTransferRepository.QueryList(materialTransferCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderBy("CreateDate", SortDirection.Descending).OrderBy("Status", SortDirection.Ascending);
            }
     


           // IQueryable<MaterialTransferView> data = this._MaterialTransferRepository.QueryList(materialTransferCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderBy("CreateDate", SortDirection.Descending);
            var pagedViewModel = new PagedViewModel<MaterialTransferView>
            {
                Query = dataEvery,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.TransferId,
                    List = new List<object>() {                      
                        d.TransferId,
                        d.MaterialName,
                        d.OutputDate.HasValue? d.OutputDate.Value.ToString("yyyy-MM-dd"):"",  
                        d.Amount,
                        d.OutputLoctionName,
                        d.InputLoctionName,
                        d.OutputUserName==null?"": "【"+d.OutputUserNo+"】"+d.OutputUserName,
                        d.BatchCode,
                        d.Status
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 删除入库材料
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                   
                    foreach (string idVal in idArr)
                    {
                        //根据ID查询转运表
                        MaterialTransfer materialTransfer = _MaterialTransferRepository.Get(idVal);
                        //删除转运表信息
                        this._MaterialTransferRepository.DeleteById(idVal);
                            //根据转运ID查询
                            IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(idVal);
                            List<NuclearBucketChange> dataBucketChangeList = dataBucketChange.ToList();
                            if (dataBucketChangeList.Count() > 0)
                            {
                                foreach (var itemChange in dataBucketChangeList)
                                {   //删除材料位置明细表
                                    this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                                    if (materialTransfer.Status.Equals("2"))
                                    {
                                        NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(itemChange.BucketId);
                                        if (nuclearBucket != null)
                                        {
                                            if (nuclearBucket.IsDrain == "1")
                                            {
                                                return Json("{\"result\":false,\"msg\":\"桶号已已被消耗,请先处理消耗桶号。\"}", JsonRequestBehavior.AllowGet);
                                            }
                                            nuclearBucket.LocationId = materialTransfer.OutputLoctionId;
                                            this._NuclearBucketRepository.Update(nuclearBucket);
                                        }
                                       
                                    
                                    }

                                }
                            }
                            if (materialTransfer.Status.Equals("2"))
                            {
                                //把库存表里的数据还原到没转运时
                                MaterialRestoreDelete(materialTransfer);

                            }
                    }
                    this._MaterialTransferRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


    }

}
