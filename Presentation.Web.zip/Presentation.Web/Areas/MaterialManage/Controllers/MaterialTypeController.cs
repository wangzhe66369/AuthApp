﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using NET01.CoreFramework;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Presentation.Web.Core;
using System.Configuration;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.MaterialManage.Controllers
{
    public class MaterialTypeController : Controller
    {
        IMaterialTypeRepository _MaterialTypeRepository;
        IBasicObjectRepository _BasicObjectRepository;
        public MaterialTypeController(IMaterialTypeRepository _MaterialTypeRepository, IBasicObjectRepository _BasicObjectRepository)
        {
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
        }

    
        /// <summary>
        /// 初始页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "材料管理")]
        public ActionResult Index()
        {
            MaterialTypeVM vm = new MaterialTypeVM();
            vm.OperationList = CommonHelper.GetOperationList("MaterialType_Manage");
            return View(vm);
        }
        
        public ActionResult ConfigAndEmail()
        {
            return View();
        }

        public ActionResult SendEmail()
        {
            return View();
        }

        [HttpPost]
        public JsonResult SendEmail(string userNo)
        {
            NET01.CoreFramework.Mail.ISmtpClient smtpClent = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<NET01.CoreFramework.Mail.ISmtpClient>();
            var mailService = new RWIS.Application.Implementation.MailService(smtpClent);
            string sendTitle = string.Format("邮件发送成功提醒");
            try
            {
                mailService.SendMailService(userNo, string.Empty, sendTitle, "发送成功");
                return JsonResultHelper.JsonResult(true, "发送成功！");
            }
            catch
            {
                return JsonResultHelper.JsonResult(false, "发送失败！");
            }
        }

        [HttpPost]
        public JsonResult GetConfig()
        {
            string connection = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
            return JsonResultHelper.JsonResult(true, connection);
        }


        /// <summary>
        /// 编辑页面数据显示
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Edit(string id)
        {
            MaterialTypeVM vm = new MaterialTypeVM();
            vm.OperationList = CommonHelper.GetOperationList("MaterialType_Manage");
            //加载规格列表
            vm.SpecList = new List<SelectListItem>();
            IQueryable<BasicObject> mateterialSpec = _BasicObjectRepository.GetSubobjectsByName("桶规格", AppContext.CurrentUser.ProjectCode);

            SelectListItem selectItem1 = new SelectListItem();
            selectItem1.Text = "请选择";
            selectItem1.Value = "";
            vm.SpecList.Add(selectItem1);
            foreach (var item in mateterialSpec)
            {
                SelectListItem selectItem = new SelectListItem();
                selectItem.Text = item.Name;
                selectItem.Value = item.Uuid;
                vm.SpecList.Add(selectItem);
            }

            //加载单位列表
            vm.UnitList = new List<SelectListItem>();
            IQueryable<BasicObject> mateterialUnit = _BasicObjectRepository.GetSubobjectsByName("单位", AppContext.CurrentUser.ProjectCode);
            foreach (var item in mateterialUnit)
            {
                SelectListItem selectItem = new SelectListItem();
                selectItem.Text = item.Name;
                selectItem.Value = item.Uuid;
                vm.UnitList.Add(selectItem);
            }

            //加载是否是桶
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "是", Value = "1" });
            vm.RodiodList.Add(new SelectListItem { Text = "否", Value = "0" });


            //加载是否是桶
            vm.BucketTypeList = new List<SelectListItem>();
            vm.BucketTypeList.Add(new SelectListItem { Text = "水泥桶", Value = "0" });
            vm.BucketTypeList.Add(new SelectListItem { Text = "金属桶", Value = "1" });
            vm.BucketTypeList.Add(new SelectListItem { Text = "不适合", Value = "2" });

            //加载是否标准包装
            vm.RodiodPackList = new List<SelectListItem>();
            vm.RodiodPackList.Add(new SelectListItem { Text = "是", Value = "1" });
            vm.RodiodPackList.Add(new SelectListItem { Text = "否", Value = "0" });

            MaterialType model = _MaterialTypeRepository.Get(id);
            vm.MaterialType = model;

            //单位名称、规格名称
            if (model != null)
            {
                BasicObject materialSpec = this._BasicObjectRepository.Get(model.SpecId);
                if (materialSpec != null)
                {
                    vm.Spec = materialSpec.Name;
                }

                BasicObject materialUnit = this._BasicObjectRepository.Get(model.UnitId);
                if (materialUnit != null)
                {
                    vm.Unit = materialUnit.Name;
                }
            }
           

            return View("Edit", vm);
        }

        [HttpGet]
        public ActionResult Add()
        {

            MaterialTypeVM vm = new MaterialTypeVM();
            vm.OperationList = CommonHelper.GetOperationList("MaterialType_Manage");
            //加载是否是桶
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "是", Value = "1" });
            vm.RodiodList.Add(new SelectListItem { Text = "否", Value = "0" });

            //加载是否是桶
            vm.BucketTypeList = new List<SelectListItem>();
            vm.BucketTypeList.Add(new SelectListItem { Text = "水泥桶", Value = "0" });
            vm.BucketTypeList.Add(new SelectListItem { Text = "金属桶", Value = "1" });
            vm.BucketTypeList.Add(new SelectListItem { Text = "不适合", Value = "2" });

            //加载是否标准包装
            vm.RodiodPackList = new List<SelectListItem>();
            vm.RodiodPackList.Add(new SelectListItem { Text = "是", Value = "1" });
            vm.RodiodPackList.Add(new SelectListItem { Text = "否", Value = "0" });

            //加载规格列表
            vm.SpecList = new List<SelectListItem>();
            IQueryable<BasicObject> mateterialSpec = _BasicObjectRepository.GetSubobjectsByName("桶规格", AppContext.CurrentUser.ProjectCode);
            SelectListItem selectItem1 = new SelectListItem();
            selectItem1.Text = "请选择";
            selectItem1.Value = "";
            vm.SpecList.Add(selectItem1);
            foreach (var item in mateterialSpec)
            {
                SelectListItem selectItem = new SelectListItem();
                selectItem.Text = item.Name;
                selectItem.Value = item.Uuid;
                vm.SpecList.Add(selectItem);
            }
           
            //加载单位列表
            vm.UnitList = new List<SelectListItem>();
            IQueryable<BasicObject> mateterialUnit = _BasicObjectRepository.GetSubobjectsByName("单位", AppContext.CurrentUser.ProjectCode);
            foreach (var item in mateterialUnit)
            {
                SelectListItem selectItem = new SelectListItem();
                selectItem.Text = item.Name;
                selectItem.Value = item.Uuid;
                vm.UnitList.Add(selectItem);
            }
            return View(vm);
        }

        /// <summary>
        /// 查看页面
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DetailView(string id)
        {
            MaterialTypeVM vm = new MaterialTypeVM();
            MaterialType model = _MaterialTypeRepository.Get(id);
            vm.MaterialType = model;

            //单位名称、规格名称
            if (model != null)
            {
                BasicObject materialSpec = this._BasicObjectRepository.Get(model.SpecId);
                if (materialSpec != null)
                {
                    vm.Spec = materialSpec.Name;
                }

                BasicObject materialUnit = this._BasicObjectRepository.Get(model.UnitId);
                if (materialUnit != null)
                {
                    vm.Unit = materialUnit.Name;
                }
            }

            return View("DetailView", vm);
        }

        /// <summary>
        /// 材料保存
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraft(MaterialTypeVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {   //新增保存
                if (string.IsNullOrEmpty(model.MaterialType.MaterialId))
                {
                    model.MaterialType.MaterialId = Guid.NewGuid().ToString();
                    model.MaterialType.Status = "0";
                    model.MaterialType.CreateDate = DateTime.Now;
                    model.MaterialType.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.MaterialType.CreateUserName = AppContext.CurrentUser.UserName;
                    model.MaterialType.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._MaterialTypeRepository.Create(model.MaterialType);
                    this._MaterialTypeRepository.UnitOfWork.Commit();
                }//修改保存
                else
                {
                    model.MaterialType = _MaterialTypeRepository.Get(model.MaterialType.MaterialId);
                    UpdateModel(model);
                    model.MaterialType.Status = "0";
                    this._MaterialTypeRepository.Update(model.MaterialType);
                    this._MaterialTypeRepository.UnitOfWork.Commit();
                }

                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch 
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 材料增加提交
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult CommitMaterial(MaterialTypeVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {   //新增提交
                if (string.IsNullOrEmpty(model.MaterialType.MaterialId))
                {
                    model.MaterialType.MaterialId = Guid.NewGuid().ToString();
                    model.MaterialType.Status = "1";
                    model.MaterialType.CreateDate = DateTime.Now;
                    model.MaterialType.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.MaterialType.CreateUserName = AppContext.CurrentUser.UserName;
                    model.MaterialType.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._MaterialTypeRepository.Create(model.MaterialType);
                    this._MaterialTypeRepository.UnitOfWork.Commit();
                }//修改提交
                else
                {
                    model.MaterialType = _MaterialTypeRepository.Get(model.MaterialType.MaterialId);
                    UpdateModel(model);
                    model.MaterialType.Status = "1";
                    this._MaterialTypeRepository.Update(model.MaterialType);
                    this._MaterialTypeRepository.UnitOfWork.Commit();
                }
                
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch 
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}" , JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "材料信息确认")]
        public JsonResult ConfirmMaterial(MaterialTypeVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {   //新增确认
                if (string.IsNullOrEmpty(model.MaterialType.MaterialId))
                {
                    model.MaterialType.MaterialId = Guid.NewGuid().ToString();
                    model.MaterialType.Status = "2";
                    model.MaterialType.CreateDate = DateTime.Now;
                    model.MaterialType.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.MaterialType.CreateUserName = AppContext.CurrentUser.UserName;
                    model.MaterialType.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.MaterialType.ConfirmDate = DateTime.Now;
                    model.MaterialType.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.MaterialType.ConfirmUserName = AppContext.CurrentUser.UserName;
                    this._MaterialTypeRepository.Create(model.MaterialType);
                    this._MaterialTypeRepository.UnitOfWork.Commit();
                }//修改确认
                else
                {
                    model.MaterialType = _MaterialTypeRepository.Get(model.MaterialType.MaterialId);
                    UpdateModel(model);
                    model.MaterialType.Status = "2";
                    model.MaterialType.ConfirmDate = DateTime.Now;
                    model.MaterialType.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.MaterialType.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.MaterialType.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._MaterialTypeRepository.Update(model.MaterialType);
                    this._MaterialTypeRepository.UnitOfWork.Commit();
                }
                
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch 
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}" , JsonRequestBehavior.AllowGet);
            }
        }
       
        /// <summary>
        /// 初始化查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetMaterialTypeList(MaterialTypeCondition materialTypeCondition, string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<MaterialType> data = this._MaterialTypeRepository.QueryList(materialTypeCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderBy("CreateDate", SortDirection.Descending);
            var pagedViewModel = new PagedViewModel<MaterialType>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.MaterialId,
                    List = new List<object>() {
                    d.MaterialId,
                    d.MaterialName,
                    d.MinStock,
                    d.IsBucket,
                    d.Height,
                    d.Diamerter,
                    d.Status
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 删除材料
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._MaterialTypeRepository.DeleteById(idVal);
                    }
                    this._MaterialTypeRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }
        
    }
}
