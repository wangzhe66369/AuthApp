﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using NET01.CoreFramework;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.MaterialManage.Controllers
{
    public class MaterialDrainController : Controller
    {
        IMaterialTransferRepository _MaterialTransferRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        IMaterialInputRepository _MaterialInputRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IMaterialDrainRepository _MaterialDrainRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        INuclearBucketChangeRepository _NuclearBucketChangeRepository;
        INuclearMStockRepository _NuclearMStockRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        IMaterialBatchRepository _MaterialBatchRepository;
        public MaterialDrainController(IMaterialDrainRepository _MaterialDrainRepository,
                                        IBasicObjectRepository _BasicObjectRepository,
                                        IMaterialTransferRepository _MaterialTransferRepository,
                                        IMaterialTypeRepository _MaterialTypeRepository,
                                        IMaterialInputRepository _MaterialInputRepository,
                                        INuclearBucketRepository _NuclearBucketRepository,
                                        INuclearBucketChangeRepository _NuclearBucketChangeRepository,
                                        INuclearMStockRepository _NuclearMStockRepository,
                                       INuclearTempstockRepository _NuclearTempstockRepository,
                                        IMaterialBatchRepository _MaterialBatchRepository
            )
        {
            this._MaterialTransferRepository = _MaterialTransferRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._MaterialInputRepository = _MaterialInputRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._MaterialDrainRepository = _MaterialDrainRepository;

            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._NuclearBucketChangeRepository = _NuclearBucketChangeRepository;
            this._NuclearMStockRepository = _NuclearMStockRepository;
            this._NuclearTempstockRepository = _NuclearTempstockRepository;
            this._MaterialBatchRepository = _MaterialBatchRepository;
        }

        /// <summary>
        /// 初始页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "材料消耗")]
        public ActionResult Index()
        {
            MaterialDrainVM vm = new MaterialDrainVM();
            vm.OperationList = CommonHelper.GetOperationList("Material_Drain");
            //材料名称下拉设置数据
            List<NuclearMStock> list = _NuclearMStockRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderByDescending(o => o.MaterialId).GroupBy(c => c.MaterialId).Select(g => g.First()).ToList();
            List<MaterialType> listType = new List<MaterialType>();
            foreach (var item in list)
            {
                MaterialType materialType = _MaterialTypeRepository.Get(item.MaterialId);
                if (materialType != null)
                {
                    listType.Add(materialType);
                }
                
            }
            SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
            ViewData["MaterialName"] = s1;
            //存放地点下拉设置数据
            IQueryable<BasicObject> storageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storageLocationList = new List<BasicObject>();
            if (storageLocationQuery!=null && storageLocationQuery.Count() > 0)
            {
                storageLocationList = storageLocationQuery.ToList();
            }
            SelectList SelectList = new SelectList(storageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;

            //用途
            IQueryable<BasicObject> query = _BasicObjectRepository.GetSubobjectsByCode("Use", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> useList = new List<BasicObject>();
            if (query != null && query.Count() > 0)
            {
                useList = query.ToList();
            }
            if (useList.Count() ==0)
            {
                BasicObject basicObject=new BasicObject();
                useList.Add(basicObject);
            }
            SelectList UseList = new SelectList(useList, "Uuid", "Name");
            ViewData["UseList"] = UseList;

            //状态
            List<SelectListItem> selectItems = new List<SelectListItem>();
            SelectListItem draftItem = new SelectListItem();
            draftItem.Text = "草稿";
            draftItem.Value ="0";
            selectItems.Add(draftItem);
            SelectListItem submitItem = new SelectListItem();
            submitItem.Text = "未确认";
            submitItem.Value = "1";
            selectItems.Add(submitItem);
            SelectListItem confirmItem = new SelectListItem();
            confirmItem.Text = "已确认";
            confirmItem.Value = "2";
            selectItems.Add(confirmItem);
            SelectList statusList = new SelectList(selectItems, "Value", "Text");
            ViewData["Status"] = statusList;
            return View(vm);
        }

        /// <summary>
        /// 编辑页面数据显示
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Edit(string id)
        {
            //获得数据库数据
            MaterialDrain model = _MaterialDrainRepository.Get(id);
            MaterialDrainVM vm = new MaterialDrainVM();
            vm.OperationList = CommonHelper.GetOperationList("Material_Drain");
            vm.MaterialDrain = model;
            List<NuclearBucket> nuclearBucketList = new List<NuclearBucket>();
            //如果是点击修改进入此页面
            if (!string.IsNullOrEmpty(id))
            {
                IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == id).AsQueryable();
                IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
                nuclearBucket = (from i in nuclearBucket
                                 join s in nuclearBucketChange
                                       on i.BucketId equals s.BucketId
                                 select i);
                if (nuclearBucket.Count() > 0)
                {
                    nuclearBucketList = nuclearBucket.ToList();
                }
            }
            var query = nuclearBucketList.OrderBy("BucketCode", SortDirection.Ascending);
            vm.nuclearBucketList = query.ToList();
            //材料名称下拉设置数据
            List<NuclearMStock> list = _NuclearMStockRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderByDescending(o => o.MaterialId).GroupBy(c => c.MaterialId).Select(g => g.First()).ToList();
            List<MaterialType> listType = new List<MaterialType>();
            foreach (var item in list)
            {
                MaterialType materialType = _MaterialTypeRepository.Get(item.MaterialId);
                if (materialType != null)
                {
                    listType.Add(materialType);
                }

            }
            if (list.Count() == 0)
            {
                listType.Add(null);
            }
            SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
            ViewData["MaterialName"] = s1;

            //用途下拉列表设置数据
            IQueryable<BasicObject> UnitQuery = _BasicObjectRepository.GetSubobjectsByCode("Use",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> UseList = new List<BasicObject>();
            if (UnitQuery.Count() > 0)
            {
                UseList = UnitQuery.ToList();
            }
            if (UnitQuery.Count() == 0)
            {
                BasicObject basicObject = new BasicObject();
                UseList.Add(basicObject);
            }
            SelectList SelectUnitList = new SelectList(UseList, "Uuid", "Name");
            ViewData["Use"] = SelectUnitList;

            //存放地点下拉设置数据
            IQueryable<BasicObject> StorageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> StorageLocationList = new List<BasicObject>();
            if (StorageLocationQuery.Count() > 0)
            {
                StorageLocationList = StorageLocationQuery.ToList();
            }
            if (StorageLocationQuery.Count() == 0)
            {
                BasicObject basicObject = new BasicObject();
                StorageLocationList.Add(basicObject);
            }
            SelectList SelectList = new SelectList(StorageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;
            ///单位下拉列表
            vm.UnitList = new List<SelectListItem>();
            List<BasicObject> unitList = new List<BasicObject>();
            IQueryable<BasicObject> query1 = _BasicObjectRepository.GetSubobjectsByCode("Unit",AppContext.CurrentUser.ProjectCode);
            if (query1 != null && query1.Count() > 0)
            {
                unitList = query1.ToList();
            }
            foreach (var item in unitList)
            {
                vm.UnitList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            ///批次
            ///
            vm.BatchCodeList = new List<SelectListItem>();
            IQueryable<NuclearMStock> nuclearMStock = _NuclearMStockRepository.GetAll().Where(d => d.InputId != null).GroupBy(d => d.InputId).Select(p => p.First()).AsQueryable();
            List<NuclearMStock> nuclearMStockList = new List<NuclearMStock>();
            if (nuclearMStock != null && nuclearMStock.Count() > 0)
            {
                nuclearMStockList = nuclearMStock.ToList();
                vm.BatchCodeList.Add(new SelectListItem { Text = "请选择", Value = "" });
                List<MaterialInput> materialInputList = new List<MaterialInput>();
                foreach (var item in nuclearMStockList)
                {
                    MaterialInput materialInput = _MaterialInputRepository.GetAll().Where(d => d.InputId == item.InputId).FirstOrDefault();
                    if (materialInput != null)
                    {
                        materialInputList.Add(materialInput);
                    }

                }
                List<MaterialInput> materialInputByList = materialInputList.OrderBy(d => d.ConfirmDate).ToList();
                foreach (var item in materialInputByList)
                {
                    if (!string.IsNullOrEmpty(item.BatchCode))
                    {
                        vm.BatchCodeList.Add(new SelectListItem { Text = item.BatchCode, Value = item.InputId });
                    }

                }

            }
            return View(vm);
        }

        /// <summary>
        /// 查看页面
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DetailView(string id)
        {
            //获得数据库数据
            MaterialDrain model = _MaterialDrainRepository.Get(id);
            MaterialDrainVM vm = new MaterialDrainVM();
            vm.MaterialDrain = model;
            //vm.nuclearBucketList = new List<NuclearBucket>();
            //如果是点击修改进入此页面
            if (!string.IsNullOrEmpty(id))
            {
                IQueryable<NuclearBucketChange> nuclearBucketChangeQuery = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == id).AsQueryable();
                IQueryable<NuclearBucket> nuclearBucketQuery = _NuclearBucketRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();

                nuclearBucketQuery = (from bq in nuclearBucketQuery
                                      join bcq in nuclearBucketChangeQuery
                                      on bq.BucketId equals bcq.BucketId
                                      select bq).OrderBy(d => d.BucketCode);

                if (nuclearBucketQuery.Count() > 0)
                {
                    vm.nuclearBucketList = nuclearBucketQuery.ToList();
                }
                //foreach (var itemChage in nuclearBucketChangeQuery)
                //{
                //    NuclearBucket nuclearBucket = new NuclearBucket();

                //    nuclearBucket = nuclearBucketQuery.Where(d => d.BucketId == itemChage.BucketId).FirstOrDefault();

                //    vm.nuclearBucketList.Add(nuclearBucket);
                //}
            }
            MaterialType materialType = _MaterialTypeRepository.Get(model.MaterialId);
            BasicObject basicObjectLocation = _BasicObjectRepository.Get(model.OutputLocationId);
            BasicObject useName = _BasicObjectRepository.Get(model.UseId);
            vm.MaterialName = materialType.MaterialName;
            vm.OutputLocationName = basicObjectLocation.Name;
            vm.UseName = useName.Name;
            return View("DetailView", vm);
        }

        /// <summary>
        /// 增加页面
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Add()
        {
            MaterialDrainVM vm = new MaterialDrainVM();
            vm.MaterialDrain = new MaterialDrain();
            vm.OperationList = CommonHelper.GetOperationList("Material_Drain");
            //材料名称下拉设置数据
            List<NuclearMStock> list = _NuclearMStockRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderByDescending(o => o.MaterialId).GroupBy(c => c.MaterialId).Select(g => g.First()).ToList();
            List<MaterialType> listType = new List<MaterialType>();
            foreach (var item in list)
            {
                MaterialType materialType = _MaterialTypeRepository.Get(item.MaterialId);
                if (materialType != null)
                {
                    listType.Add(materialType);
                }

            }
            if (list.Count() == 0)
            {
                listType.Add(null);
            }
            SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
            ViewData["MaterialName"] = s1;

            //用途下拉列表设置数据
            IQueryable<BasicObject> UnitQuery = _BasicObjectRepository.GetSubobjectsByCode("Use",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> UseList = new List<BasicObject>();
            if (UnitQuery!=null && UnitQuery.Count() > 0)
            {
                UseList = UnitQuery.ToList();
            }
            if (UnitQuery != null && UnitQuery.Count() == 0)
            {
                BasicObject basicObject = new BasicObject();
                UseList.Add(basicObject);
            }
            SelectList SelectUnitList = new SelectList(UseList, "Uuid", "Name");
            ViewData["Use"] = SelectUnitList;

            //存放地点下拉设置数据
            IQueryable<BasicObject> storageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storageLocationList = new List<BasicObject>();
            if (storageLocationQuery!=null && storageLocationQuery.Count() > 0)
            {
                storageLocationList = storageLocationQuery.ToList();
            }
            if (storageLocationQuery!=null && storageLocationList.Count() == 0)
            {
                BasicObject basicObject = new BasicObject();
                storageLocationList.Add(basicObject);
            }
            SelectList SelectList = new SelectList(storageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;
            ///单位下拉列表
            vm.UnitList = new List<SelectListItem>();
            List<BasicObject> unitList = new List<BasicObject>();
            IQueryable<BasicObject> query = _BasicObjectRepository.GetSubobjectsByCode("Unit", AppContext.CurrentUser.ProjectCode);
            if (query != null && query.Count() > 0)
            {
                unitList = query.ToList();
            }
            foreach (var item in unitList)
            {
                vm.UnitList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }


            ///批次
            ///
            vm.BatchCodeList = new List<SelectListItem>();
            IQueryable<NuclearMStock> nuclearMStock = _NuclearMStockRepository.GetAll().Where(d => d.InputId != null).GroupBy(d => d.InputId).Select(p => p.First()).AsQueryable();
            List<NuclearMStock> nuclearMStockList = new List<NuclearMStock>();
            if (nuclearMStock != null && nuclearMStock.Count() > 0)
            {
                nuclearMStockList = nuclearMStock.ToList();
                vm.BatchCodeList.Add(new SelectListItem { Text = "请选择", Value = "" });
                List<MaterialInput> materialInputList = new List<MaterialInput>();
                foreach (var item in nuclearMStockList)
                {
                    MaterialInput materialInput = _MaterialInputRepository.GetAll().Where(d => d.InputId == item.InputId).FirstOrDefault();
                    if (materialInput != null)
                    {
                        materialInputList.Add(materialInput);
                    }

                }
                List<MaterialInput> materialInputByList = materialInputList.OrderBy(d => d.ConfirmDate).ToList();
                foreach (var item in materialInputByList)
                {
                    if (!string.IsNullOrEmpty(item.BatchCode))
                    {
                        vm.BatchCodeList.Add(new SelectListItem { Text = item.BatchCode, Value = item.InputId });
                    }

                }

            }
            return View(vm);

        }

        /// <summary>
        /// 页面得到最低库存
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SelectedTransfer(string id, string materialId, string outputLoctionId,string inputId, FormCollection formCollection)
        {

            try
            {

                MaterialType materialType = _MaterialTypeRepository.Get(materialId);
                string unit = string.Empty;
                string unitId = string.Empty;
                if (materialType != null)
                {


                    BasicObject basicObject = _BasicObjectRepository.Get(materialType.UnitId);
                    unit = basicObject != null ? basicObject.Name : "";
                    unitId = materialType.UnitId;
                }
                Nullable<double> amout = 0;
                Nullable<double> amoutAll = 0;
                string isBucket = materialType != null ? materialType.IsBucket : string.Empty;
                double minStock = materialType != null ? materialType.MinStock : 0;//获得最低库存

                List<NuclearMStock> nuclearMStock = new List<NuclearMStock>();
                nuclearMStock = _NuclearMStockRepository.GetAll().Where(d => d.MaterialId == materialId).Where(d => d.LocationId == outputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                if (!string.IsNullOrEmpty(inputId))
                {
                    nuclearMStock = nuclearMStock.Where(d => d.InputId == inputId).ToList();

                }
                foreach (var itemStock in nuclearMStock)
                {
                    amout = itemStock.Amount + amout;
                }
                  
               
                if (!string.IsNullOrEmpty(id))
                {
                    IQueryable<MaterialDrain> materialDrain = _MaterialDrainRepository.GetAll().AsQueryable().Where(d => d.DrainId == id).Where(d => d.MaterialId == materialId).Where(d => d.OutputLocationId == outputLoctionId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                    List<MaterialDrain> materialDrainList =materialDrain.ToList();
                    if (materialDrainList.Count() > 0)
                    {
                        if (materialDrainList[0].Status == "2")
                        {
                           
                            amout = amout + materialDrainList[0].Amount;
                          
                        }
                    
                    }
                   
                    
                }
                //库存总数
                List<NuclearMStock> nuclearMStockAll = _NuclearMStockRepository.GetAll().Where(d => d.MaterialId == materialId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                foreach (var itemStockAll in nuclearMStockAll)
                {
                    amoutAll = amoutAll + itemStockAll.Amount;
                    
                }
             
                if (string.IsNullOrEmpty(isBucket))
                {
                    return Json("{\"result\":\"" + amout + "\",\"amoutAll\":\"" + amoutAll + "\",\"minStock\":\"" + minStock + "\",\"isBucket\":\"0\",\"unitId\":\"" + unitId + "\",\"unit\":\"" + unit + "\"}", JsonRequestBehavior.AllowGet);
                }
                return Json("{\"result\":\"" + amout + "\",\"amoutAll\":\"" + amoutAll + "\",\"minStock\":\"" + minStock + "\",\"isBucket\":\"" + isBucket + "\",\"unitId\":\"" + unitId + "\",\"unit\":\"" + unit + "\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"没有查询到桶的信息。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 消耗的详细表
        /// </summary>
        /// <param name="model"></param>
        private string BucketDetail(MaterialDrainVM model, string isDrain)
        {
            string[] arrayAllCode = null;
            string[] arrayCode = null;
            string[] arrayBucketCode = null;
            arrayAllCode = model.hidBucketCodeType.Trim(new char[] { ';' }).Split(new char[] { ';' });
            foreach (var code in arrayAllCode)
            {
                string bucketCode = string.Empty;
                arrayCode = code.Trim(new char[] { ',' }).Split(new char[] { ',' });
                if (arrayCode.Length == 3)
                {
                    int startBucketCode = Convert.ToInt32(arrayCode[1]);
                    int endBucketCode = Convert.ToInt32(arrayCode[2]);
                    if (startBucketCode == endBucketCode)
                    {
                        bucketCode = arrayCode[0] + arrayCode[1];
                    }
                    else
                    {
                        for (int i = startBucketCode; i <= endBucketCode; i++)
                        {
                            bucketCode = bucketCode + arrayCode[0] + i.ToString().PadLeft(arrayCode[2].Length, '0') + ",";  
                        }
                    }

                }
                else if (arrayCode.Length == 2)
                {
                    bucketCode = arrayCode[0] + arrayCode[1];
                }
                else if (arrayCode.Length == 1)
                {
                    bucketCode = arrayCode[0];
                }

                arrayBucketCode = bucketCode.Trim(new char[] { ',' }).Split(new char[] { ',' });
                string drain = string.Empty;
                string noExist = string.Empty; 
                foreach (var itemCode in arrayBucketCode)
                {
                    IQueryable<NuclearBucket> data = _NuclearBucketRepository.GetAll().AsQueryable().Where(s => s.BucketCode == itemCode).Where(s => s.LocationId == model.MaterialDrain.OutputLocationId && s.MaterialId == model.MaterialDrain.MaterialId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                    if (data.Count() > 0)
                    {
                        foreach (var itemData in data)
                        {
                            if (itemData.IsDrain == "1")
                            {
                                drain = drain + itemData + ",";
                               
                            }
                            if (itemData.Status == "2")
                            {
                                //更新桶信息
                                itemData.IsDrain = isDrain;
                                itemData.BucketStatus = "DRAINEMPTY";
                                this._NuclearBucketRepository.Update(itemData);

                                //在桶位置编号表明细存入数据
                                NuclearBucketChange nuclearBucketChange = new NuclearBucketChange();
                                nuclearBucketChange.Detailid = Guid.NewGuid().ToString();
                                nuclearBucketChange.ChangeType = "DRAIN";
                                nuclearBucketChange.BusinessId = model.MaterialDrain.DrainId;
                                nuclearBucketChange.BucketId = itemData.BucketId;
                                this._NuclearBucketChangeRepository.Create(nuclearBucketChange);
                            }
                            else {

                                return "fail";
                            }
                           
                        }
                    }
                    else
                    {
                        noExist = noExist + itemCode + ";";
                    }
                   

                }
                if(!string.IsNullOrEmpty(drain))
                {
                    return drain;
                }
                if (!string.IsNullOrEmpty(noExist))
                {
                    return noExist;
                }

            }

            return "success";
        }
        /// <summary>
        /// 存入消耗表
        /// </summary>
        /// <param name="model"></param>
        private void DrainMethod(MaterialDrainVM model, string status)
        {
            model.MaterialDrain.DrainId = Guid.NewGuid().ToString();
            model.MaterialDrain.Status = status;
            model.MaterialDrain.CreateDate = DateTime.Now;
            model.MaterialDrain.CreateUserNo = AppContext.CurrentUser.UserId;
            model.MaterialDrain.CreateUserName = AppContext.CurrentUser.UserName;
            model.MaterialDrain.Stationcode = AppContext.CurrentUser.ProjectCode;
            this._MaterialDrainRepository.Create(model.MaterialDrain);
        }
        /// <summary>
        /// 确认时存入消耗表
        /// </summary>
        /// <param name="model"></param>
        private void ConfirmDrainMethod(MaterialDrainVM model, string status)
        {
            model.MaterialDrain.DrainId = Guid.NewGuid().ToString();
            model.MaterialDrain.Status = status;
            model.MaterialDrain.CreateDate = DateTime.Now;
            model.MaterialDrain.CreateUserNo = AppContext.CurrentUser.UserId;
            model.MaterialDrain.CreateUserName = AppContext.CurrentUser.UserName;
            model.MaterialDrain.Stationcode = AppContext.CurrentUser.ProjectCode;
            model.MaterialDrain.ConfirmDate = DateTime.Now;
            model.MaterialDrain.ConfirmUserNo = AppContext.CurrentUser.UserId;
            model.MaterialDrain.ConfirmUserName = AppContext.CurrentUser.UserName;
            model.MaterialDrain.Stationcode = AppContext.CurrentUser.ProjectCode;
            this._MaterialDrainRepository.Create(model.MaterialDrain);
        }
        /// <summary>
        /// 确认人
        /// </summary>
        /// <param name="model"></param>
        private  void ConfirmMethod(MaterialDrainVM model, string status)
        {
            model.MaterialDrain.Status = status;
            model.MaterialDrain.ConfirmDate = DateTime.Now;
            model.MaterialDrain.ConfirmUserNo = AppContext.CurrentUser.UserId;
            model.MaterialDrain.ConfirmUserName = AppContext.CurrentUser.UserName;
            model.MaterialDrain.Stationcode = AppContext.CurrentUser.ProjectCode;
            this._MaterialDrainRepository.Update(model.MaterialDrain);
        }
        /// <summary>
        /// 材料转运-草稿保存
        /// </summary>
        /// <param name="model">MaterialTransfer</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraft(MaterialDrainVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                if (string.IsNullOrEmpty(model.MaterialDrain.DrainId))
                {
                    //存入消耗表
                    DrainMethod(model,"0");
                    //桶的
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //存入详细表
                        string fail = BucketDetail(model, "0");
                        if (fail.Contains(","))
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号为"+fail+"的桶已被消耗。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail == "fail")
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Contains(";"))
                        {
                            return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号  " + fail + "。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }  
                }
                else
                {
                    //根据入库ID查询
                    IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(model.MaterialDrain.DrainId);
                    if (dataBucketChange.Count() > 0)
                    {
                        foreach (var itemChange in dataBucketChange)
                        {   //删除材料位置明细表
                            this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                        }
                    }
                    model.MaterialDrain = _MaterialDrainRepository.Get(model.MaterialDrain.DrainId);
                    if (model.MaterialDrain.Status == "2")
                    {
                        //还原数据
                        NuclearMStockMethod(model.MaterialDrain, model.hidBucketCodeType);
                    }
                    UpdateModel(model);
                    model.MaterialDrain.Status = "0";
                    this._MaterialDrainRepository.Update(model.MaterialDrain);
                    //桶的
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //存入详细表
                        string fail = BucketDetail(model, "0");
                        if (fail.Contains(","))
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号为" + fail + "的桶已被消耗。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail == "fail")
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Contains(";"))
                        {
                            return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号  " + fail + "。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }  
                }
                this._MaterialDrainRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

            }
            catch 
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// 材料转运_提交
        /// </summary>
        /// <param name="model">MaterialTransfer</param>
        /// <param name="formCollection">FormCollection</param>
        /// <returns>Json</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult CommitMaterial(MaterialDrainVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                if (string.IsNullOrEmpty(model.MaterialDrain.DrainId))
                {
                    //存入消耗表
                    DrainMethod(model,"1");
                    //桶的
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //存入详细表
                        string fail = BucketDetail(model, "0");
                        if (fail.Contains(","))
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号为" + fail + "的桶已被消耗。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail == "fail")
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Contains(";"))
                        {
                            return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号  " + fail + "。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                }
                else
                {
                    //根据入库ID查询
                    IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(model.MaterialDrain.DrainId);
                    if (dataBucketChange.Count() > 0)
                    {
                        foreach (var itemChange in dataBucketChange)
                        {   //删除材料位置明细表
                            this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                        }
                    }
                    model.MaterialDrain = _MaterialDrainRepository.Get(model.MaterialDrain.DrainId);
                    if (model.MaterialDrain.Status == "2")
                    {
                        //还原数据
                        NuclearMStockMethod(model.MaterialDrain, model.hidBucketCodeType);
                    }
                    UpdateModel(model);
                    model.MaterialDrain.Status = "1";
                    this._MaterialDrainRepository.Update(model.MaterialDrain);
                    //桶的
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //存入详细表
                        string fail = BucketDetail(model, "0");
                        if (fail.Contains(","))
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号为" + fail + "的桶已被消耗。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail == "fail")
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Contains(";"))
                        {
                            return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号  " + fail + "。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                }
                this._MaterialDrainRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "材料消耗确认")]
        public JsonResult ConfirmMaterial(MaterialDrainVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
               
                //新增确认
                if (string.IsNullOrEmpty(model.MaterialDrain.DrainId))
                {
                    //存入消耗表
                    ConfirmDrainMethod(model, "2");
                    //桶的
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {                       
                        //存入详细表
                        string fail = BucketDetail(model, "1");
                        if (fail.Contains(","))
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号为" + fail + "的桶已被消耗。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail == "fail")
                        {
                            return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (fail.Contains(";"))
                        {
                            return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号  " + fail + "。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                  
                }//编辑确认
                else
                {
                    model.MaterialDrain = _MaterialDrainRepository.Get(model.MaterialDrain.DrainId);
                     //状态是已确认
                    if (model.MaterialDrain.Status.Equals("2"))
                    {
                        string[] sameArr =null;
                        if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                        {
                            //查询转运明细和桶信息
                            IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == model.MaterialDrain.DrainId).AsQueryable();
                            List<string> nuclearBucketStrList = new List<string>();
                            foreach (var itemChage in nuclearBucketChange)
                            {
                                NuclearBucket nuclearBucket = new NuclearBucket();
                                nuclearBucket = _NuclearBucketRepository.Get(itemChage.BucketId);
                                nuclearBucketStrList.Add(nuclearBucket.BucketCode);
                            }
                            //页面中传过来的数组
                            string[] arrBucketAllCode = model.hidBucketCodeType.Trim(new char[] { ';' }).Split(new char[] { ';' });
                            //数据库中桶号的数组
                            string[] arrFromDataBase = nuclearBucketStrList.ToArray();
                            //求交集
                            sameArr = arrBucketAllCode.Intersect(arrFromDataBase).ToArray();
                            string[] difArr = arrFromDataBase.Except(sameArr).ToArray();
                            //删除页面中减少的
                            foreach (var itemdifArr in difArr)
                            {
                                IQueryable<NuclearBucket> data = _NuclearBucketRepository.GetAll().Where(s => s.BucketCode == itemdifArr).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
                                List<NuclearBucket> dataList = data.ToList();
                                if (dataList.Count() > 0)
                                {
                                    foreach (var item in dataList)
                                    {
                                        item.IsDrain = "0";
                                        this._NuclearBucketRepository.Update(item);
                                        List<NuclearBucketChange> dataChange = this._NuclearBucketChangeRepository.GetAll().Where(s => s.BucketId == item.BucketId && s.ChangeType == "DRAIN").ToList();
                                        if (dataChange.Count() > 0)
                                        {
                                            this._NuclearBucketChangeRepository.DeleteById(dataChange[0].Detailid);
                                        }
                                    }
                                }
                            }
                            //页面中新添加的桶号时进行如下操作
                            foreach (var bucketCode in arrBucketAllCode)
                            {
                                if (!arrFromDataBase.ToArray().Contains(bucketCode))
                                {
                                    IQueryable<NuclearBucket> isData = _NuclearBucketRepository.GetAll().AsQueryable().Where(s => s.BucketCode == bucketCode).Where(d => d.LocationId == model.MaterialDrain.OutputLocationId&&d.MaterialId==model.MaterialDrain.MaterialId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                                    List<NuclearBucket> isDataList = isData.ToList();
                                    if (isDataList.Count() == 0)
                                    {
                                        return Json("{\"result\":false,\"msg\":\"该仓库不存在桶号。\"}", JsonRequestBehavior.AllowGet);
                                    }
                                    if (isDataList[0].Status != "2")
                                    {
                                        return Json("{\"result\":false,\"msg\":\"桶号未被确认。\"}", JsonRequestBehavior.AllowGet);
                                    }
                                    IQueryable<NuclearBucket> data = _NuclearBucketRepository.GetAll().Where(s => s.BucketCode == bucketCode).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
                                    List<NuclearBucket> dataList = data.ToList();
                                    foreach (var item in dataList)
                                    {
                                        //更新桶信息
                                        item.IsDrain = "1";
                                        item.BucketStatus = "DRAINEMPTY";
                                        this._NuclearBucketRepository.Update(item);

                                        //在桶位置编号表明细存入数据
                                        NuclearBucketChange nuclearBucketChangeDetail = new NuclearBucketChange();
                                        nuclearBucketChangeDetail.Detailid = Guid.NewGuid().ToString();
                                        nuclearBucketChangeDetail.ChangeType = "DRAIN";
                                        nuclearBucketChangeDetail.BusinessId = model.MaterialDrain.DrainId;
                                        nuclearBucketChangeDetail.BucketId = item.BucketId;
                                        this._NuclearBucketChangeRepository.Create(nuclearBucketChangeDetail);
                                    }
                                }
                            }
                        }
                        //把库存表里的数据还原到没消耗时
                        NuclearMStockMethod(model.MaterialDrain,model.hidBucketCodeType);
                        //更新入库表
                        UpdateModel(model);
                        foreach (var item in sameArr)
                        {
                            List<NuclearBucket> dataSame = _NuclearBucketRepository.GetAll().Where(s => s.BucketCode == item && s.MaterialId == model.MaterialDrain.MaterialId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                            if (dataSame.Count() == 0)
                            {
                                return Json("{\"result\":false,\"msg\":\"该材料没有该桶号。\"}", JsonRequestBehavior.AllowGet);
                            }
                        }
                        //更新材料消耗表
                        ConfirmMethod(model, "2");
                        ////暂存表还原
                        NuclearTempStockMethod(model.MaterialDrain);
                    }
                    else
                    {
                        //桶的
                        if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                        {
                            //根据转运ID查询
                            IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(model.MaterialDrain.DrainId);
                            List<NuclearBucketChange> dataBucketChangeList = dataBucketChange.ToList();
                            if (dataBucketChangeList.Count() > 0)
                            {
                                foreach (var itemChange in dataBucketChangeList)
                                {   //删除材料位置明细表
                                    this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);

                                }
                            }
                            //存入详细表
                            string fail = BucketDetail(model, "1");
                            if (fail.Contains(","))
                            {
                                return Json("{\"result\":false,\"msg\":\"桶号为" + fail + "的桶已被消耗。\"}", JsonRequestBehavior.AllowGet);
                            }
                            if (fail == "fail")
                            {
                                return Json("{\"result\":false,\"msg\":\"桶号未确认。\"}", JsonRequestBehavior.AllowGet);
                            }
                            if (fail.Contains(";"))
                            {
                                return Json("{\"result\":false,\"msg\":\"该仓库不存在该桶号  " + fail + "。\"}", JsonRequestBehavior.AllowGet);
                            }
                        }
                       
                       
                        //更新入库表
                        UpdateModel(model);
                        //更新材料消耗表
                        ConfirmMethod(model, "2");
                    }
                }
                if (string.IsNullOrEmpty(model.hidBucketCodeType))
                {

                    NuclearMStock dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialDrain.MaterialId, model.MaterialDrain.OutputLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.InputId == model.MaterialDrain.InputId).FirstOrDefault();
                    if (dataMStock != null)
                    {
                        
                        if (dataMStock.Amount > model.MaterialDrain.Amount)
                        {

                            //材料表消耗
                            dataMStock.Amount = dataMStock.Amount - model.MaterialDrain.Amount;
                            ///
                            ///用于过期转运
                            ///
                            dataMStock.OverrideAmount = ((dataMStock.OverrideAmount == null ? 0 : dataMStock.OverrideAmount) - model.MaterialDrain.Amount) < 0 ? 0 : dataMStock.OverrideAmount - model.MaterialDrain.Amount;
                            this._NuclearMStockRepository.Update(dataMStock);

                          

                        }
                        else if (dataMStock.Amount == model.MaterialDrain.Amount)
                        {
                            //材料表消耗
                            dataMStock.Amount = dataMStock.Amount - model.MaterialDrain.Amount;
                            ///
                            ///用于过期转运
                            ///
                            dataMStock.OverrideAmount = ((dataMStock.OverrideAmount == null ? 0 : dataMStock.OverrideAmount) - model.MaterialDrain.Amount) < 0 ? 0 : dataMStock.OverrideAmount - model.MaterialDrain.Amount;
                            this._NuclearMStockRepository.Update(dataMStock);

                            this._NuclearMStockRepository.DeleteById(dataMStock.StockId);

                        }
                        else
                        {
                            return Json("{\"result\":false,\"msg\":\"消耗数量大于批次数量。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                    MaterialBatch materialBatch = new MaterialBatch();
                    materialBatch.DetailId = Guid.NewGuid().ToString();
                    materialBatch.BusinessId = model.MaterialDrain.DrainId;
                    materialBatch.BusinessType = "2";
                    materialBatch.InputId = dataMStock.InputId;
                    _MaterialBatchRepository.Create(materialBatch);


                }
                else
                {

                    //查询出库信息
                    IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialDrain.MaterialId, model.MaterialDrain.OutputLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                    List<NuclearMStock> dataMStockList = dataMStock.ToList();
                    foreach (var itemMStock in dataMStockList)
                    {

                        //材料表消耗
                        itemMStock.Amount = itemMStock.Amount - model.MaterialDrain.Amount;
                        ///
                        ///用于过期转运
                        ///
                        itemMStock.OverrideAmount = ((itemMStock.OverrideAmount == null ? 0 : itemMStock.OverrideAmount) - model.MaterialDrain.Amount) < 0 ? 0 : itemMStock.OverrideAmount - model.MaterialDrain.Amount;

                        this._NuclearMStockRepository.Update(itemMStock);
                    }
                    this._NuclearTempstockRepository.MergeMaterialTmpStock(model.MaterialDrain.MaterialId, model.MaterialDrain.OutputLocationId, AppContext.CurrentUser.ProjectCode, Convert.ToDecimal(model.MaterialDrain.Amount));
               
                
                }
                

                this._MaterialDrainRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        
        /// <summary>
        /// 把库存表里的数据还原到没消耗时
        /// </summary>
        /// <param name="model"></param>
        private void NuclearMStockMethod(MaterialDrain model, string hidBucketCodeType)
        {
            if (string.IsNullOrEmpty(hidBucketCodeType))
            {
                NuclearMStock dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.OutputLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.InputId == model.InputId).FirstOrDefault();
                if (dataMStock == null)
                {
                    MaterialInput materialInput = _MaterialInputRepository.Get(dataMStock.InputId);
                    //在材料库存信息存入数据
                    NuclearMStock nuclearMStock = new NuclearMStock();
                    nuclearMStock.StockId = Guid.NewGuid().ToString();
                    nuclearMStock.MaterialId = model.MaterialId;
                    nuclearMStock.LocationId = model.OutputLocationId;
                    nuclearMStock.Amount = model.Amount;
                    if (materialInput.EffectDate <= DateTime.Now)
                    {
                        nuclearMStock.OverrideAmount = model.Amount;
                    }
                    nuclearMStock.InputId = model.InputId;
                    nuclearMStock.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearMStockRepository.Create(nuclearMStock);
                }
                else
                {
                    dataMStock.Amount = dataMStock.Amount + model.Amount;
                    this._NuclearMStockRepository.Update(dataMStock);
                }
           
            
            }
            else
            {
                IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.OutputLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                List<NuclearMStock> dataMStockList = dataMStock.ToList();
                foreach (var itemMStock in dataMStockList)
                {
                    itemMStock.Amount = itemMStock.Amount + model.Amount;
                    this._NuclearMStockRepository.Update(itemMStock);
                }
            
            }
            //IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialId, model.OutputLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //List<NuclearMStock> dataMStockList = dataMStock.ToList();
            //foreach (var itemMStock in dataMStockList)
            //{  
            //    itemMStock.Amount = itemMStock.Amount + model.Amount;
            //    this._NuclearMStockRepository.Update(itemMStock);
            //}
        }
        /// <summary>
        /// 把暂存库存表里的数据还原到库存时
        /// </summary>
        /// <param name="model"></param>
        private void NuclearTempStockMethod(MaterialDrain model)
        {
            IQueryable<NuclearTempstock> dataTempstock = _NuclearTempstockRepository.GetAll().Where(d=>d.MaterialId==model.MaterialId&&d.LocationId==model.OutputLocationId).Where(d => d.StationCode == AppContext.CurrentUser.ProjectCode).AsQueryable();
            List<NuclearTempstock> dataTempstockList = dataTempstock.ToList();
            foreach (var itemTempStock in dataTempstockList)
            {
                itemTempStock.Amount = Convert.ToDecimal(itemTempStock.Amount) - Convert.ToDecimal(model.Amount);
                this._NuclearTempstockRepository.Update(itemTempStock);
            }
        }


        /// <summary>
        /// 获得查询列表
        /// </summary>
        /// <param name="condition"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetMaterialDrainList(MaterialDrainCondition condition, string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

           
            IQueryable<MaterialDrainView> dataEvery = this._MaterialDrainRepository.QueryList(condition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            if (!string.IsNullOrEmpty(condition.BucketCode))
            {
                IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(d => d.BucketCode.Trim().ToUpper().Contains(condition.BucketCode.Trim().ToUpper())).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
               
                IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().AsQueryable().Where(d => d.ChangeType == "DRAIN");
                nuclearBucketChange = (from i in nuclearBucketChange
                            join s in nuclearBucket
                            on i.BucketId equals s.BucketId
                            select i).Distinct();

                 dataEvery = (from i in dataEvery
                                join s in nuclearBucketChange
                                on i.DrainId equals s.BusinessId
                                 select i).Distinct().OrderBy("CreateDate", SortDirection.Descending).OrderBy("Status", SortDirection.Ascending);

            }
            else
            {
                dataEvery = this._MaterialDrainRepository.QueryList(condition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderBy("CreateDate", SortDirection.Descending).OrderBy("Status", SortDirection.Ascending);
            }
     
            var pagedViewModel = new PagedViewModel<MaterialDrainView>
            {
                Query = dataEvery,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
           
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DrainId,
                    List = new List<object>() {                      
                        d.DrainId,
                        d.MaterialName,
                        d.OutputDate.HasValue? d.OutputDate.Value.ToString("yyyy-MM-dd"):"",  
                        d.Amount,
                        d.UseName,
                        d.OutputLocationName,
                        d.OutputUserName==null?"" : "【"+d.OutputUserNo+"】"+d.OutputUserName,
                        d.BatchCode,
                        d.Status
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 删除入库材料
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        //删除消耗表信息
                        this._MaterialDrainRepository.DeleteById(idVal);
                        //根据ID查询消耗表
                        MaterialDrain materialDrain = _MaterialDrainRepository.Get(idVal);
                        //根据消耗ID查询
                        IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(materialDrain.DrainId);
                        if (dataBucketChange.Count() > 0)
                        {
                            foreach (var itemChange in dataBucketChange)
                            {   //删除材料位置明细表
                                this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                                //更改到未消耗
                                    //状态是确认的删除
                                if (materialDrain.Status.Equals("2"))
                                {
                                    NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(itemChange.BucketId);
                                    if (nuclearBucket != null)
                                    {
                                        if (nuclearBucket.BucketStatus == "DRAINEMPTY")
                                        {
                                            nuclearBucket.IsDrain = "0";
                                            nuclearBucket.BucketStatus = "";
                                            this._NuclearBucketRepository.Update(nuclearBucket);
                                        }
                                        else
                                        {
                                            this._NuclearBucketRepository.UnitOfWork.RollbackChanges();
                                            return Json("{\"result\":true,\"msg\":\"本批消耗的桶中,有部分桶已经到了其他工序,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                                        }
                                    }
                                    
                                }
                                    
                            }
                        }
                        if (materialDrain.Status.Equals("2"))
                        {
                            if (!string.IsNullOrEmpty(materialDrain.InputId))
                            {

                                NuclearMStock dataMStock = _NuclearMStockRepository.QueryListByMLocationId(materialDrain.MaterialId, materialDrain.OutputLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.InputId == materialDrain.InputId).FirstOrDefault();
                                if (dataMStock == null)
                                {
                                    MaterialInput materialInput = _MaterialInputRepository.Get(dataMStock.InputId);
                                    //在材料库存信息存入数据
                                    NuclearMStock nuclearMStock = new NuclearMStock();
                                    nuclearMStock.StockId = Guid.NewGuid().ToString();
                                    nuclearMStock.MaterialId = materialDrain.MaterialId;
                                    nuclearMStock.LocationId = materialDrain.OutputLocationId;
                                    nuclearMStock.Amount = materialDrain.Amount;
                                    if (materialInput.EffectDate <= DateTime.Now)
                                    {
                                        nuclearMStock.OverrideAmount = materialDrain.Amount;
                                    }
                                    nuclearMStock.InputId = materialDrain.InputId;
                                    nuclearMStock.Stationcode = AppContext.CurrentUser.ProjectCode;
                                    this._NuclearMStockRepository.Create(nuclearMStock);
                                }
                                else
                                {
                                    dataMStock.Amount = dataMStock.Amount + materialDrain.Amount;
                                    this._NuclearMStockRepository.Update(dataMStock);
                                }
                                MaterialBatch materialBatch =_MaterialBatchRepository.GetAll().Where(d=>d.BusinessId==materialDrain.DrainId&&d.BusinessType=="2").FirstOrDefault();
                                _MaterialBatchRepository.DeleteById(materialBatch.DetailId);

                            }
                            else
                            {
                                IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(materialDrain.MaterialId, materialDrain.OutputLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                                List<NuclearMStock> dataMStockList = dataMStock.ToList();
                                foreach (var itemMStock in dataMStockList)
                                {   //加上之前存入的数据
                                    itemMStock.Amount = itemMStock.Amount + materialDrain.Amount;
                                    this._NuclearMStockRepository.Update(itemMStock);
                                }
                            
                            }
                           
                        }
                    }
                    this._MaterialDrainRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

    }
}
