﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Domain.DomainObjects;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;

using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Core;
namespace RWIS.Presentation.Web.Areas.MaterialManage.Controllers
{
    /// <summary>
    /// 桶信息
    /// </summary>
    public class BucketInfoController : Controller
    {
        #region"变量"

        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IMaterialInputRepository _MaterialInputRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        INuclearBucketCheckRepository _NuclearBucketCheckRepository;
        INuclearBucketSolutionRepository _NuclearBucketSolutionRepository;
        INuclearBucketResinRepository _NuclearBucketResinRepository;
        INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository;
        INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository;
        INuclearCoverMetalRepository _NuclearCoverMetalRepository;
        INuclearCoverMixRepository _NuclearCoverMixRepository;
        INuclearQtTransRepository _NuclearQtTransRepository;
        INuclearFcTransRepository _NuclearFcTransRepository;
        INuclearTsGoodsInRepository _NuclearTsGoodsInRepository;
        INuclearTsGoodsOutRepository _NuclearTsGoodsOutRepository;
        INuclearBucketChangeRepository _NuclearBucketChangeRepository;
        INuclearTrackDepositRepository _NuclearTrackDepositRepository;
        INuclearTrackSolventRepository _NuclearTrackSolventRepository;
        INuclearTrackFilterRepository _NuclearTrackFilterRepository;
        INuclearTrackTechBRepository _NuclearTrackTechBRepository;
        INuclearTrackTechSRepository _NuclearTrackTechSRepository;
        ITrackLiquorRepository _TrackLiquorRepository;
        INuclearTrackResinRepository _NuclearTrackResinRepository;
        INuclearTrackElementRepository _NuclearTrackElementRepository;
        INuclearWasteClearRepository _NuclearWasteClearRepository;
        INuclearWasteDegradeRepository _NuclearWasteDegradeRepository;
        INuclearWasteDismantleRepository _NuclearWasteDismantleRepository;
        INuclearWasteFireRepository _NuclearWasteFireRepository;
        INuclearWasteHDisposeRepository _NuclearWasteHDisposeRepository;
        INuclearWasteLDisposeRepository _NuclearWasteLDisposeRepository;
        INuclearWasteSmeltRepository _NuclearWasteSmeltRepository;
        INuclearSpecialPackageRepository _NuclearSpecialPackageRepository;
        INuclearFixationRepository _NuclearFixationRepository;
        INuclearGiftDetailRepository _NuclearGiftDetailRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        #endregion

        #region"构造函数"

        public BucketInfoController(INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository
            , IMaterialInputRepository MaterialInputRepository
            , IMaterialTypeRepository MaterialTypeRepository
            , INuclearBucketCheckRepository NuclearBucketCheckRepository
            , INuclearBucketSolutionRepository NuclearBucketSolutionRepository
            , INuclearBucketResinRepository NuclearBucketResinRepository
            , INuclearBucketRSolidifyRepository NuclearBucketRSolidifyRepository
            , INuclearBucketSSolidifyRepository NuclearBucketSSolidifyRepository
            , INuclearCoverMetalRepository NuclearCoverMetalRepository
            , INuclearCoverMixRepository NuclearCoverMixRepository
            , INuclearQtTransRepository NuclearQtTransRepository
            , INuclearFcTransRepository NuclearFcTransRepository
            , INuclearTsGoodsInRepository NuclearTsGoodsInRepository
            , INuclearTsGoodsOutRepository NuclearTsGoodsOutRepository
            , INuclearBucketChangeRepository NuclearBucketChangeRepository
            , INuclearTrackDepositRepository NuclearTrackDepositRepository
            , INuclearTrackSolventRepository NuclearTrackSolventRepository
            , INuclearTrackFilterRepository NuclearTrackFilterRepository
            , INuclearTrackTechBRepository NuclearTrackTechBRepository
            , INuclearTrackTechSRepository NuclearTrackTechSRepository
            , ITrackLiquorRepository TrackLiquorRepository
            , INuclearTrackResinRepository NuclearTrackResinRepository
            , INuclearTrackElementRepository NuclearTrackElementRepository
            , INuclearSpecialPackageRepository NuclearSpecialPackageRepository
            , INuclearWasteClearRepository NuclearWasteClearRepository
            , INuclearWasteDegradeRepository NuclearWasteDegradeRepository
            , INuclearWasteDismantleRepository NuclearWasteDismantleRepository
            , INuclearWasteFireRepository NuclearWasteFireRepository
            , INuclearWasteHDisposeRepository NuclearWasteHDisposeRepository
            , INuclearWasteLDisposeRepository NuclearWasteLDisposeRepository
            , INuclearWasteSmeltRepository NuclearWasteSmeltRepository
            , INuclearFixationRepository NuclearFixationRepository
            , INuclearGiftDetailRepository NuclearGiftDetailRepository
            ,INuclearWastePackageRepository NuclearWastePackageRepository)
        {
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._MaterialInputRepository = MaterialInputRepository;
            this._MaterialTypeRepository = MaterialTypeRepository;
            this._NuclearBucketCheckRepository = NuclearBucketCheckRepository;
            this._NuclearBucketSolutionRepository = NuclearBucketSolutionRepository;
            this._NuclearBucketResinRepository = NuclearBucketResinRepository;
            this._NuclearBucketRSolidifyRepository = NuclearBucketRSolidifyRepository;
            this._NuclearBucketSSolidifyRepository = NuclearBucketSSolidifyRepository;
            this._NuclearCoverMetalRepository = NuclearCoverMetalRepository;
            this._NuclearCoverMixRepository = NuclearCoverMixRepository;
            this._NuclearQtTransRepository = NuclearQtTransRepository;
            this._NuclearFcTransRepository = NuclearFcTransRepository;
            this._NuclearTsGoodsInRepository = NuclearTsGoodsInRepository;
            this._NuclearTsGoodsOutRepository = NuclearTsGoodsOutRepository;
            this._NuclearBucketChangeRepository = NuclearBucketChangeRepository;
            this._NuclearTrackDepositRepository = NuclearTrackDepositRepository;
            this._NuclearTrackSolventRepository = NuclearTrackSolventRepository;
            this._NuclearTrackFilterRepository = NuclearTrackFilterRepository;
            this._NuclearTrackTechBRepository = NuclearTrackTechBRepository;
            this._NuclearTrackTechSRepository = NuclearTrackTechSRepository;
            this._TrackLiquorRepository = TrackLiquorRepository;
            this._NuclearTrackResinRepository = NuclearTrackResinRepository;
            this._NuclearTrackElementRepository = NuclearTrackElementRepository;
            this._NuclearWasteClearRepository = NuclearWasteClearRepository;
            this._NuclearWasteDegradeRepository = NuclearWasteDegradeRepository;
            this._NuclearWasteDismantleRepository = NuclearWasteDismantleRepository;
            this._NuclearWasteFireRepository = NuclearWasteFireRepository;
            this._NuclearWasteHDisposeRepository = NuclearWasteHDisposeRepository;
            this._NuclearWasteLDisposeRepository = NuclearWasteLDisposeRepository;
            this._NuclearWasteSmeltRepository = NuclearWasteSmeltRepository;
            this._NuclearSpecialPackageRepository = NuclearSpecialPackageRepository;
            this._NuclearFixationRepository = NuclearFixationRepository;
            this._NuclearGiftDetailRepository = NuclearGiftDetailRepository;
            this._NuclearWastePackageRepository = NuclearWastePackageRepository;
        }

        #endregion

        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "桶信息")]
        public ActionResult Index()
        {
            BucketInfoVM vm = new BucketInfoVM();
            vm.BucketTypeList = new List<SelectListItem>();
            vm.BucketStatusList = new List<SelectListItem>();
            vm.BucketLocationList = new List<SelectListItem>();
            IQueryable<BasicObject> query = _BasicObjectRepository.GetSubobjectsByCode("Bucket", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> listBasicObject = new List<BasicObject>();
            if (query != null && query.Count() > 0)
            {
                listBasicObject = query.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.BucketLocationList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }

            //加载是否启用列表 UNAPPLY:未申请处置  UNCHECKED:未审核 CHECKED:已审核 APPLIED：已申报  RECEPTED：已接收 DEALED:已处置 RETURN:已退回
            List<SelectListItem> statusList = new List<SelectListItem>();
            statusList.Add(new SelectListItem { Text = "请选择", Value = "" });
            statusList.Add(new SelectListItem { Text = "未申请处置", Value = "UNAPPLY" });
            statusList.Add(new SelectListItem { Text = "未审核", Value = "UNCHECKED" });
            statusList.Add(new SelectListItem { Text = "已审核", Value = "CHECKED" });
            statusList.Add(new SelectListItem { Text = "已申报", Value = "APPLIED" });
            statusList.Add(new SelectListItem { Text = "已接收", Value = "RECEPTED" });
            statusList.Add(new SelectListItem { Text = "已处置", Value = "DEALED" });
            statusList.Add(new SelectListItem { Text = "已拒收", Value = "UNRECEPTED" });
            vm.StatusList = statusList;
            return View(vm);
        }
        /// <summary>
        /// 桶信息明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "桶信息明细")]
        public ActionResult Detail()
        {
            string bucketId = Request["id"];
            string stationCode = AppContext.CurrentUser.ProjectCode;
            BucketInfoVM vm = new BucketInfoVM();
            vm.BucketInfoDetail = new NuclearBucket();
            vm.BucketInfoInputDetail = new MaterialInput();
            vm.BucketCheckDetail = new NuclearBucketCheck();
            vm.TrackInfoList = new List<TrackInfo>();
            var SolutionModel = _NuclearBucketSolutionRepository.GetAll().Where(n => n.BucketId == bucketId && n.Stationcode == stationCode).FirstOrDefault();
            var ResinModel = _NuclearBucketResinRepository.GetAll().Where(n => n.BucketId == bucketId && n.Stationcode == stationCode).FirstOrDefault();
            var RSolidifyModel = _NuclearBucketRSolidifyRepository.GetAll().Where(n => n.BucketId == bucketId && n.Stationcode == stationCode).FirstOrDefault();
            var SSolidifyModel = _NuclearBucketSSolidifyRepository.GetAll().Where(n => n.BucketId == bucketId && n.Stationcode == stationCode).FirstOrDefault();
            var FixAtionModel = _NuclearFixationRepository.GetAll().Where(n => n.BucketId == bucketId && n.Stationcode == stationCode).FirstOrDefault();
            var MetaModel = _NuclearCoverMetalRepository.GetAll().Where(n => n.BucketId == bucketId && n.Stationcode == stationCode).FirstOrDefault();
            var MixModel = _NuclearCoverMixRepository.GetAll().Where(n => n.BucketId == bucketId && n.Stationcode == stationCode).FirstOrDefault();
            var QtTransModel = _NuclearQtTransRepository.GetAll().Where(n => n.BucketId == bucketId && n.Stationcode == stationCode).FirstOrDefault();
            var FcTransModel = _NuclearFcTransRepository.GetModelByBucketId(bucketId);
            var GoodsInModel = _NuclearTsGoodsInRepository.GetModelByBucketId(bucketId);
            var GoodsOutModel = _NuclearTsGoodsOutRepository.GetModelByBucketId(bucketId);

            #region"根据桶ID获取源项信息"

            List<string> trackIdList = new List<string>();
            var fixDetail = _NuclearFixationRepository.GetFixAtionDetail();
            var fixAtion = _NuclearFixationRepository.GetQueryList().Where(n => n.Stationcode == stationCode && n.BucketId == bucketId);
            fixDetail.Join(fixAtion, a => a.FixationId, b => b.FixationId, (a, b) => new
              {
                  a.TrackId
              }).ToList().ForEach(n =>
              {
                  trackIdList.Add(n.TrackId);
              });
            _NuclearBucketSolutionRepository.GetAll().Where(n => n.Stationcode == stationCode && n.BucketId == bucketId).ToList()
                .ForEach(n =>
                {
                    trackIdList.Add(n.TrackId);
                });

            List<NuclearBucketResin> bucketResinList = _NuclearBucketResinRepository.GetAll().Where(n => n.Stationcode == stationCode && n.BucketId == bucketId).ToList();
            if (bucketResinList != null && bucketResinList.Count > 0)
            {
                string giftId = bucketResinList[0].ResinId;
                _NuclearGiftDetailRepository.GetAll().AsQueryable().Where(c => c.GiftId == giftId).ToList().ForEach(n =>
                {
                    trackIdList.Add(n.TrackId);
                });
            }

            List<NuclearBucketRSolidify> bucketRSolidifyList = _NuclearBucketRSolidifyRepository.GetAll().Where(n => n.Stationcode == stationCode && n.BucketId == bucketId).ToList();
            if (bucketRSolidifyList != null && bucketRSolidifyList.Count > 0)
            {
                string giftId = bucketRSolidifyList[0].SolidifyRId;
                _NuclearGiftDetailRepository.GetAll().AsQueryable().Where(c => c.GiftId == giftId).ToList().ForEach(n =>
                {
                    trackIdList.Add(n.TrackId);
                });
            }

            _NuclearBucketSSolidifyRepository.GetAll().Where(n => n.Stationcode == stationCode && n.BucketId == bucketId).ToList()
                .ForEach(n =>
                {
                    trackIdList.Add(n.TrackId);
                });

            //添加源项跟踪单
            if (trackIdList.Count > 0)
            {
                vm.TrackInfoList = new List<TrackInfo>();
                for (int i = 0; i < trackIdList.Count; i++)
                {
                    IQueryable<TrackItemVM> query = TrackItemBuilder.GetAllTrackList(trackIdList[i]);
                    if (query != null && query.Count()>0)
                        foreach (var item in query)
                        {
                            TrackInfo info = new TrackInfo();
                            info.BucketId = bucketId;
                            info.TrackType = ConvertType(item.TrackType);
                            info.TrackId = item.TrackId;
                            info.TrackCode = item.TrackCode;
                            vm.TrackInfoList.Add(info);
                        }
                }
            }

            #endregion

            #region"根据桶ID获取其他工艺信息"

            var clearList = _NuclearWasteClearRepository.GetAll().Where(n => n.Stationcode == stationCode && n.Code == bucketId).ToList();
            var degradesList = _NuclearWasteDegradeRepository.GetAll().Where(n => n.Stationcode == stationCode && n.WasteCode == bucketId).ToList();
            var dismantleList = _NuclearWasteDismantleRepository.GetAll().Where(n => n.Stationcode == stationCode && n.Code == bucketId).ToList();
            var fireList = _NuclearWasteFireRepository.GetAll().Where(n => n.Stationcode == stationCode && n.WasteCode == bucketId).ToList();
            var hdisposeList = _NuclearWasteHDisposeRepository.GetAll().Where(n => n.Stationcode == stationCode && n.ContainerCode == bucketId).ToList();
            var ldisposeList = _NuclearWasteLDisposeRepository.GetAll().Where(n => n.Stationcode == stationCode && n.Code == bucketId).ToList();
            var packageList = _NuclearSpecialPackageRepository.GetAll().Where(n => n.Stationcode == stationCode && n.Code == bucketId).ToList();
            var smeltList = _NuclearWasteSmeltRepository.GetAll().Where(n => n.Stationcode == stationCode && n.Code == bucketId).ToList();

            if (clearList.Count > 0)
                vm.ClearId = clearList[0].ClearId;
            if (degradesList.Count > 0)
                vm.DegradesId = degradesList[0].DegradeId;
            if (dismantleList.Count > 0)
                vm.DismantleId = dismantleList[0].DismantleId;
            if (fireList.Count > 0)
                vm.FireId = fireList[0].FireId;
            if (hdisposeList.Count > 0)
                vm.HDisposeId = hdisposeList[0].DisposeHId;
            if (ldisposeList.Count > 0)
                vm.LDisposeId = ldisposeList[0].DisposeLId;
            if (packageList.Count > 0)
                vm.PackageId = packageList[0].PackageId;
            if (smeltList.Count > 0)
                vm.SmeltId = smeltList[0].SmeltId;

            #endregion

            if (SolutionModel != null)
                vm.SolutionId = SolutionModel.SolutionId;
            if (ResinModel != null)
                vm.ResinId = ResinModel.ResinId;
            if (RSolidifyModel != null)
                vm.RSolidifyId = RSolidifyModel.SolidifyRId;
            if (SSolidifyModel != null)
                vm.SSolidifyId = SSolidifyModel.SolidifySIdd;
            if (FixAtionModel != null)
                vm.FixAtionId = FixAtionModel.FixationId;
            if (MetaModel != null)
                vm.MetalId = MetaModel.MetalId;
            if (MixModel != null)
                vm.MixId = MixModel.MixId;
            if (QtTransModel != null)
                vm.QtTransId = QtTransModel.QtTransId;
            if (FcTransModel != null)
                vm.FcTransId = FcTransModel.FcTransId;
            if (GoodsInModel != null)
                vm.GoodsInId = GoodsInModel.GoodsInDetailId;
            if (GoodsOutModel != null)
                vm.GoodsOutId = GoodsOutModel.GoodsOutDetailId;
            vm.BucketInfoDetail = _NuclearBucketRepository.GetBucketInfoModel(bucketId);
            vm.BucketCheckDetail = _NuclearBucketCheckRepository.GetBucketCheckByBucketId(bucketId).FirstOrDefault();
            BasicObject basic = new BasicObject();
            if (vm.BucketCheckDetail != null)
            {
                basic = _BasicObjectRepository.GetBasicById(vm.BucketCheckDetail.BucketTypeId);
                vm.BucketCheckDetail.BucketTypeId = basic.Name;
                vm.BucketCheckDetail.BucketId = vm.BucketInfoDetail.BucketCode;
            }
            else
            {
                vm.BucketCheckDetail = new NuclearBucketCheck();
            }
            if (vm.BucketInfoDetail != null)
            {
                if (vm.BucketInfoDetail.BucketStatus == "DRAINEMPTY")
                {
                    vm.BucketInfoDetail.BucketStatus = "空桶";
                }
                else if (vm.BucketInfoDetail.BucketStatus == "EMPTY")
                {
                    vm.BucketInfoDetail.BucketStatus = "空桶准备";
                }
                else if (vm.BucketInfoDetail.BucketStatus == "PREPARE")
                {
                    vm.BucketInfoDetail.BucketStatus = "桶准备";
                }
                else if (vm.BucketInfoDetail.BucketStatus == "FILL")
                {
                    vm.BucketInfoDetail.BucketStatus = "填充";
                }
                else if (vm.BucketInfoDetail.BucketStatus == "COVER")
                {
                    vm.BucketInfoDetail.BucketStatus = "封盖";
                }
                else
                {
                    vm.BucketInfoDetail.BucketStatus = "材料桶";
                }
            }
            var listBucket = _NuclearBucketRepository.QueryListByCode(vm.BucketInfoDetail.BucketCode, AppContext.CurrentUser.ProjectCode).ToList();
            if (listBucket != null && listBucket.Count > 0)
            {
                var listBucketChange = _NuclearBucketChangeRepository.QueryListByBucketId(listBucket[0].BucketId, "INPUT").ToList();
                if (listBucketChange != null && listBucketChange.Count > 0)
                {
                    List<string> listInputDetailId = new List<string>();
                    for (int i = 0; i < listBucketChange.Count; i++)
                    {
                        listInputDetailId.Add(listBucketChange[i].BusinessId);
                    }
                    listInputDetailId = listInputDetailId.Distinct().ToList();
                    string inputId = listInputDetailId[0];
                    vm.BucketInfoInputDetail = _MaterialInputRepository.GetInputList().Where(m => m.InputId == inputId).FirstOrDefault();


                    if (vm.BucketInfoInputDetail != null)
                    {
                        vm.BucketInfoInputDetail.MaterialId = _MaterialTypeRepository.GetMaterialModel(vm.BucketInfoInputDetail.MaterialId).MaterialName;
                        vm.BucketInfoInputDetail.UnitId = _BasicObjectRepository.GetBasicById(vm.BucketInfoInputDetail.UnitId).Name;
                        vm.BucketInfoInputDetail.StorageLocationId = _BasicObjectRepository.GetBasicById(vm.BucketInfoInputDetail.StorageLocationId).Name;

                        if (vm.BucketInfoInputDetail.HasLining == "1")
                            vm.BucketInfoInputDetail.HasLining = "无";
                        if (vm.BucketInfoInputDetail.HasLining == "2")
                            vm.BucketInfoInputDetail.HasLining = "有";
                        if (vm.BucketInfoInputDetail.HasLining == "0")
                            vm.BucketInfoInputDetail.HasLining = "不适用";

                        if (vm.BucketInfoInputDetail.HasStirrer == "1")
                            vm.BucketInfoInputDetail.HasStirrer = "无";
                        if (vm.BucketInfoInputDetail.HasStirrer == "2")
                            vm.BucketInfoInputDetail.HasStirrer = "有";
                        if (vm.BucketInfoInputDetail.HasStirrer == "0")
                            vm.BucketInfoInputDetail.HasStirrer = "不适用";

                        if (vm.BucketInfoInputDetail.IsEmptyBucket == "1")
                            vm.BucketInfoInputDetail.IsEmptyBucket = "否";
                        if (vm.BucketInfoInputDetail.IsEmptyBucket == "2")
                            vm.BucketInfoInputDetail.IsEmptyBucket = "是";
                        if (vm.BucketInfoInputDetail.IsEmptyBucket == "0")
                            vm.BucketInfoInputDetail.IsEmptyBucket = "不适用";

                        if (vm.BucketInfoInputDetail.HasDefect == "1")
                            vm.BucketInfoInputDetail.HasDefect = "无";
                        if (vm.BucketInfoInputDetail.HasDefect == "2")
                            vm.BucketInfoInputDetail.HasDefect = "有";
                        if (vm.BucketInfoInputDetail.HasDefect == "0")
                            vm.BucketInfoInputDetail.HasDefect = "不适用";
                    }
                    else
                    {
                        vm.BucketInfoInputDetail = new MaterialInput();
                    }
                }
            }
            return View(vm);
        }

        /// <summary>
        /// 源项类型转换
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        string ConvertType(string type)
        {
            string trackType = string.Empty;
            switch (type)
            {
                case "LIQUID":
                    trackType="浓缩液";
                    break;
                case "RESIN":
                    trackType = "废树脂";
                    break;
                case "ELEMENT":
                    trackType = "废滤芯";
                    break;
                case "DEPOSIT":
                    trackType = "淤积物";
                    break;
                case "SOLVENT":
                    trackType = "废油和溶剂";
                    break;
                case "FILTER":
                    trackType = "通风过滤器";
                    break;
                case "TECH1":
                    trackType = "技术废物1";
                    break;
                case "TECH2":
                    trackType = "技术废物2";
                    break;
                case "SUNDRY":
                    trackType = "杂项";
                    break;
                default:
                    break;
            }
            return trackType;
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(BucketInfoCondition bucketInfoCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var query = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.Stationcode.ToUpper().Trim() == AppContext.CurrentUser.ProjectCode.ToUpper().Trim() && (n.IsCompress=="" || n.IsCompress==null)).AsQueryable();
            var iqueryLocaiton = _BasicObjectRepository.GetAll().AsQueryable().Where(c => c.StationCode.ToUpper().Trim() == AppContext.CurrentUser.ProjectCode.ToUpper().Trim());
            var iqueryMaterial = _MaterialTypeRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == AppContext.CurrentUser.ProjectCode.ToUpper().Trim());
            var iqueryWastePackage = _NuclearWastePackageRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == AppContext.CurrentUser.ProjectCode.ToUpper().Trim());
            var newQuery = from q in query
                           join i in iqueryLocaiton on q.LocationId equals i.Uuid into iEmpt
                           from i in iEmpt.DefaultIfEmpty()
                           join m in iqueryMaterial on q.MaterialId equals m.MaterialId into mEmpt
                           from m in mEmpt.DefaultIfEmpty()
                           join p in iqueryWastePackage on q.BucketId equals p.BucketId into pEmpt
                           from p in pEmpt.DefaultIfEmpty()
                           select new BucketVM
                           {
                               NuclearBucket = q,
                               LocationName = i.Name,
                               MaterialName = m.MaterialName,
                               NuclearWastePackage = p,
                               
                           };

            if (!string.IsNullOrEmpty(bucketInfoCondition.BucketCode))
            {
                newQuery = newQuery.Where(n => n.NuclearBucket.BucketCode.ToUpper().Contains(bucketInfoCondition.BucketCode.ToUpper()));
            }
            if (!string.IsNullOrEmpty(bucketInfoCondition.BucketLocation) && bucketInfoCondition.BucketLocation != "0")
            {
                newQuery = newQuery.Where(n => n.NuclearBucket.LocationId == bucketInfoCondition.BucketLocation);
            }
            if (!string.IsNullOrEmpty(bucketInfoCondition.BucketStatus) && bucketInfoCondition.BucketStatus != "0")
            {
                if (bucketInfoCondition.BucketStatus == "材料桶")
                {
                    newQuery = newQuery.Where(n => n.NuclearBucket.IsDrain == "0");
                }
                else if (bucketInfoCondition.BucketStatus == "DRAINEMPTY")
                {
                    newQuery = newQuery.Where(n => n.NuclearBucket.IsDrain == "1" && (n.NuclearBucket.BucketStatus == null || n.NuclearBucket.BucketStatus == "" || n.NuclearBucket.BucketStatus == "DRAINEMPTY"));
                }
                else if (bucketInfoCondition.BucketStatus == "EMPTY")
                {
                    newQuery = newQuery.Where(n => n.NuclearBucket.IsDrain == "1" && (n.NuclearBucket.BucketStatus == "EMPTY" || n.NuclearBucket.BucketStatus == "UNPREPARE" ));
                }
                else
                {
                    newQuery = newQuery.Where(n => n.NuclearBucket.BucketStatus == bucketInfoCondition.BucketStatus);
                }
            }
            if (!string.IsNullOrEmpty(bucketInfoCondition.StartDate) && !string.IsNullOrEmpty(bucketInfoCondition.EndDate))
            {
                DateTime sDate = Convert.ToDateTime(bucketInfoCondition.StartDate);
                DateTime eDate = Convert.ToDateTime(bucketInfoCondition.EndDate);
                IQueryable<MaterialInput> InputQuery = _MaterialInputRepository.GetInputList().Where(m => m.InputDate >= sDate && m.InputDate <= eDate);
                IQueryable<NuclearBucketChange> changeQuery = _NuclearBucketChangeRepository.GetAll().AsQueryable();
                changeQuery = from a in changeQuery join b in InputQuery on a.BusinessId equals b.InputId select a;
                newQuery = from a in newQuery join b in changeQuery on a.NuclearBucket.BucketId equals b.BucketId select a;
            }
            IQueryable<BucketInfoList> data = newQuery.Select(n => new BucketInfoList
            {
                NuclearBucket = n.NuclearBucket,
                BucketId = n.NuclearBucket.BucketId,
                IsDrill = n.NuclearBucket.IsDrain,
                BucketCode = n.NuclearBucket.BucketCode,
                BucketStatus = n.NuclearBucket.BucketStatus,
                BucketFiller = n.NuclearBucket.WasteType,
                LocationName = n.LocationName,
                MaterialName = n.MaterialName,
                NuclearWastePackage = n.NuclearWastePackage,
                PackageCode = n.NuclearWastePackage == null ? string.Empty : n.NuclearWastePackage.PackageCode,
                WasteType = n.NuclearBucket.WasteType,
                DealStatus = n.NuclearWastePackage == null ? string.Empty : n.NuclearWastePackage.Status,

            });
            if (!string.IsNullOrEmpty(bucketInfoCondition.PackageCode))
            {
                data = data.Where(c => c.PackageCode.ToUpper().Contains(bucketInfoCondition.PackageCode.ToUpper()));
            }
            if (!string.IsNullOrEmpty(bucketInfoCondition.DealStatus))
            {
                if (bucketInfoCondition.DealStatus == "UNAPPLY")
                    data = data.Where(c => c.DealStatus == bucketInfoCondition.DealStatus || string.IsNullOrEmpty(c.DealStatus));
                else
                    data = data.Where(c => c.DealStatus == bucketInfoCondition.DealStatus);
            }
            //绑定前台JqGrid参数
            sord = "asc";
            var pagedViewModel = new PagedViewModel<BucketInfoList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.BucketId,
                    List = new List<object>() {
                    d.BucketId,
                    d.IsDrill,
                    d.BucketCode,
                    d.PackageCode,
                    d.MaterialName,
                    d.BucketStatus,
                    d.BucketFiller,
                    d.LocationName,
                    string.IsNullOrEmpty(d.NuclearBucket.XPosition)?string.Empty:CommonHelper.ConverToString(d.NuclearBucket.XPosition) + "," + CommonHelper.ConverToString(d.NuclearBucket.YPosition) + "," + CommonHelper.ConverToString(d.NuclearBucket.ZPosition),
                    d.WasteType,
                    d.DealStatus,
                    d.NuclearWastePackage == null ? string.Empty : (string.IsNullOrEmpty(d.NuclearWastePackage.XPosition)?string.Empty:CommonHelper.ConverToString(d.NuclearWastePackage.XPosition) + "," + CommonHelper.ConverToString(d.NuclearWastePackage.YPosition) + "," + CommonHelper.ConverToString(d.NuclearWastePackage.ZPosition))
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
