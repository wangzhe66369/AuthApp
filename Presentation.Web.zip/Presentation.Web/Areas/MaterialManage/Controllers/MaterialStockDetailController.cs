﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;

using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using NET01.CoreFramework;
using System;
using CIT.App.Lib.PlanTaskClient;
using CIT.App.Lib.PlanTask.Client;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using System.Web;
using System.Data;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModelBuilder;
using RWIS.Presentation.Web.Services;




namespace RWIS.Presentation.Web.Areas.MaterialManage.Controllers
{
    /// <summary>
    /// 材料库存信息
    /// </summary>
    public class MaterialStockDetailController : Controller
    {
        IMaterialTransferRepository _MaterialTransferRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        IMaterialInputRepository _MaterialInputRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        INuclearMStockRepository _NuclearMStockRepository;
        INuclearBucketChangeRepository _NuclearBucketChangeRepository;
        public MaterialStockDetailController(
                                                IBasicObjectRepository _BasicObjectRepository,
                                                IMaterialTransferRepository _MaterialTransferRepository,
                                                IMaterialTypeRepository _MaterialTypeRepository,
                                                IMaterialInputRepository _MaterialInputRepository,
                                                INuclearMStockRepository _NuclearMStockRepository,
                                                INuclearBucketRepository _NuclearBucketRepository,
                                                INuclearBucketChangeRepository _NuclearBucketChangeRepository

            )
        {
            this._MaterialTransferRepository = _MaterialTransferRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._MaterialInputRepository = _MaterialInputRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._NuclearMStockRepository = _NuclearMStockRepository;
            this._NuclearBucketChangeRepository = _NuclearBucketChangeRepository;
        }
       
        
        /// <summary>
        /// 
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult Import()
        {
            return View();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult Import(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的电缆数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    {
                        //删除文件
                        if (System.IO.File.Exists(strNewImportPath))
                        {
                            System.IO.File.Delete(strNewImportPath);
                        }
                        jsonResult = JsonResultHelper.JsonResult(false, "数据必须是EXCEL格式!");
                        jsonResult.ContentType = "text/html";
                        return jsonResult;
                    }
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);
                      
                        TableBuilder.Import(ds, strNewImportPath);
                        
                    }
                }
                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }
      

        /// <summary>
        /// 获得列的json对象
        /// </summary>
        /// <returns></returns>
        public JsonResult GetListJSON()
        {
            //从数据库里查询地点
            IQueryable<BasicObject> storageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storageLocationList = new List<BasicObject>();
            if (storageLocationQuery!=null && storageLocationQuery.Count() > 0)
            {
                storageLocationList = storageLocationQuery.ToList();
            }
            //行ColNames  list
            List<string> listColNs = new List<string>();
            //行ColModels list
            List<MaterialStockDetailVM> listColMs = new List<MaterialStockDetailVM>();
            //表头
            listColNs.Add("材料名称");
            listColNs.Add("单位");
            listColNs.Add("汇总");

            //列
            for (int i = 0; i < 3; i++)
            {
                MaterialStockDetailVM model = new MaterialStockDetailVM();
                model.name = "name";
                model.index = "name";
                model.align = "center";
                listColMs.Add(model);

            }
            foreach (var storageLocation in storageLocationList)
            {
                MaterialStockDetailVM model = new MaterialStockDetailVM();
                model.name = storageLocation.Name;
                model.index = storageLocation.Name;
                model.align = "center";

                listColNs.Add(storageLocation.Name);
                listColMs.Add(model);
            }
            var resultObj = new
            {
                ColNs = listColNs,
                ColMs = listColMs
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 初始页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "材料库存")]
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 初始查询
        /// </summary>
        /// <param name="materialInputCondition"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetMaterialStockDetailList()
        {
            //将数据取出的List转成Dictionary
            Dictionary<string, List<NuclearMStock>> dataDic = ListToDictionary();
            //从数据库里查询地点
            IQueryable<BasicObject> storageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storageLocationList = new List<BasicObject>();
            if (storageLocationQuery!=null && storageLocationQuery.Count() > 0)
            {
                storageLocationList = storageLocationQuery.ToList();
            }
            string storageLocationID = string.Empty;
            //从数据库取出地点ID
            foreach (var storageLocation in storageLocationList)
            {
                storageLocationID = storageLocationID + storageLocation.Uuid + ",";
            }

            //从数据库取出所有材料ID和材料名
            List<MaterialInput> materialInputList = this._MaterialInputRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderByDescending(o => o.MaterialId).GroupBy(c => c.MaterialId).Select(g => g.First()).ToList();

            string materialID = string.Empty;
            string materialName = string.Empty;
            foreach (var item in materialInputList)
            {
                materialID = materialID + item.MaterialId + ",";
                MaterialType mterialType = this._MaterialTypeRepository.Get(item.MaterialId);
                if (mterialType != null)
                {
                    materialName = materialName + mterialType.MaterialName + ",";
                }

            }
            //拆分材料Id
            string[] materialArr = materialID.TrimEnd(',').Split(',');
            //拆分材料名称
            string[] materialNameArr = materialName.TrimEnd(',').Split(',');
            string total = string.Empty;
            string totalq = string.Empty;
           
            Dictionary<int, string> dataValue = new Dictionary<int, string>();
            int m = 0;
            for (int i = 0; i < materialArr.Length; i++)
            {
                Nullable<double> totalAll = 0;
                //根据材料名称取出单位名
                IQueryable<MaterialInputView> dataInput = this._NuclearMStockRepository.QueryListUnit(materialArr[i]);
                List<MaterialInputView> listInput = new List<MaterialInputView>();
                listInput = dataInput.ToList();
                string unit = string.Empty;
                foreach (var itemInpt in listInput)
                {
                    unit = itemInpt.UnitName;
                }
                total = materialNameArr[i] + "," + unit + ",";
                string[] storageLocationArr = storageLocationID.TrimEnd(',').Split(',');
                //把dictionary里的数据构造成在页面中显示的数据
                foreach (KeyValuePair<string, List<NuclearMStock>> Kvp in dataDic)
                {
                    if (Kvp.Key == materialArr[i])
                    {
                        dataValue.Clear();
                        foreach (var itemValue in Kvp.Value)
                        {
                            dataValue.Add(m++, itemValue.LocationId);
                        }
                        for (int j = 0; j < storageLocationArr.Length; j++)
                        {
                            if (dataValue.Values.Contains(storageLocationArr[j]))
                            {
                                foreach (var item in Kvp.Value)
                                {
                                    if (item.LocationId == storageLocationArr[j])
                                    {
                                        var materialLocation = materialArr[i] + "/" + item.LocationId;
                                        if (item.OverrideAmount!=0 && item.OverrideAmount!=null)
                                        {
                                            total = total + "<font style='color:red'>" + item.OverrideAmount + "</font>" + "/" + "<a href='javascript:void(0)' onclick='viewRecord(\"" + materialLocation + "\")'>" + (item.Amount!=0 ? item.Amount.ToString() : "0") + "</a>" + ",";
                                            totalAll = totalAll + item.Amount;
                                        }
                                        else
                                        {
                                            total = total + "<a href='javascript:void(0)' onclick='viewRecord(\"" + materialLocation + "\")'>" + (item.Amount!=0 ? item.Amount.ToString() : "0") + "</a>" + ",";
                                            totalAll = totalAll + item.Amount;
                                        }

                                    }

                                }
                            }
                            else
                            {
                                total = total + "0" + ",";
                            }

                        }
                    }

                }
                int index = total.IndexOf(",");
                int indexTow = total.IndexOf(",", index + 1);
                total = total.Insert(indexTow + 1, "<font size='2'>" + totalAll.ToString() + "</font>" + ",");
                total = total.TrimEnd(',') + ";";

                totalq = totalq + total;
            }
            //把构造的数据转成接送在页面显示
            string[] totalqArr = totalq.TrimEnd(';').Split(';');
            var jqGridResponse = new JqGridResponse { JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            for (int i = 0; i < totalqArr.Length; i++)
            {
                string[] showArr = totalqArr[i].Split(',');
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = 1,
                    List = new List<object>(showArr)
                });
            }
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 将数据取出的List转成Dictionary
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<NuclearMStock>> ListToDictionary()
        {
            //从材料表取出数据
            //IQueryable<NuclearMStock> dataStock = this._NuclearMStockRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
            IQueryable<NuclearMStockGroup> dataStock = this._NuclearMStockRepository.SelectByGroup();
            List<NuclearMStockGroup> listStock = dataStock.ToList();
            //将数据库的中表表数据转成dictionary
            Dictionary<string, List<NuclearMStock>> dataDic = new Dictionary<string, List<NuclearMStock>>();
            foreach (NuclearMStockGroup item in listStock)
            {
                List<NuclearMStock> materialStockDetailViewList = new List<NuclearMStock>();
                //如果dictionary中的key包含了材料Id,只需要在value中的List中添加一个对象
                if (dataDic.Keys.Contains(item.MaterialId))
                {

                    NuclearMStock model = new NuclearMStock();
                    model.LocationId = item.LocationId;
                    model.Amount = item.Amount;
                    model.OverrideAmount = item.OverrideAmount;
                    dataDic[item.MaterialId].Add(model);

                }//如果dictionary中的key不包含了材料Id,要在value中新生成一个List
                else
                {

                    NuclearMStock model = new NuclearMStock();
                    model.LocationId = item.LocationId;
                    model.Amount = item.Amount;
                    model.OverrideAmount = item.OverrideAmount;
                    materialStockDetailViewList.Add(model);
                    dataDic.Add(item.MaterialId, materialStockDetailViewList);
                }

            }
            return dataDic;
        }
        /// <summary>
        /// 查看页面
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DetailView(string materialLocation)
        {
            MaterialCheckVM vm = new MaterialCheckVM();
             string[] materialLocationArr =materialLocation.Split('/');
             string materialId=string.Empty;
             string locationId = string.Empty;
             List<NuclearBucket> nuclearBucket = new List<NuclearBucket>();
             vm.materialInputList = new List<MaterialInput>();
             if(materialLocationArr.Length>0)
             {
                    materialId = materialLocationArr[0];
                    locationId = materialLocationArr[1];
                    MaterialType materialType = _MaterialTypeRepository.Get(materialId);
                    if (materialType!=null)
                    {
                        if (materialType.IsBucket == "1")
                        {
                            nuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.MaterialId == materialId && d.LocationId == locationId && d.IsDrain == "0").OrderBy(d=>d.BucketCode).ToList();
                    
                        }
                    }
                    ViewBag.materialName = materialType.MaterialName;
                    ViewBag.IsBucket = materialType.IsBucket;
                    MaterialInput materialInput=_MaterialInputRepository.GetAll().Where(d => d.MaterialId == materialId && d.StorageLocationId == locationId && d.Status == "2").FirstOrDefault();
                    if (materialInput != null) 
                    {
                        ViewBag.EffectDate = materialInput.EffectDate.HasValue ? materialInput.EffectDate.Value.ToString("yyyy-MM-dd") : "";

                    }


                    List<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(materialId, locationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                    if (dataMStock.Count() > 0)
                    {
                        foreach (var item in dataMStock)
	                    {
                            MaterialInput input = _MaterialInputRepository.Get(item.InputId);
                            vm.materialInputList.Add(input);
	                    }
                    }
                 
              };
            BasicObject basicObjectLocation = _BasicObjectRepository.Get(locationId);
            if (basicObjectLocation != null)
            {
                ViewBag.locationName=basicObjectLocation.Name;
            }
            vm.nuclearBucketList = nuclearBucket;

           
            return View(vm);
        }

        /// <summary>
        /// 查看页面
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Det( )
        {
            ExecuteContext context = new ExecuteContext();
            MyPlanTask myPlanTask = new MyPlanTask();
            myPlanTask.Execute(context);
            return JsonResultHelper.JsonResult(true, "提醒成功！");
        }

        public ActionResult Importeee()
        {
            RwisWebService obj = new RwisWebService();
            MySoapHeader header = new MySoapHeader();
            header.UserName = "PCISMSG";
            header.PassWord = "cissmsgtol79";

            string outErrorMessage = "";
            string bucketCode = "1170001";
            //string[] arrBucketCode = { "G160413", "G160771", "G160488" };
            //string[] arrayDate = { "2017-02-01", "2016-11-06", "2017-06-14" };
            //string[] arrTrackCode = { "DIFI20120009", "DIFI20160002", "DIFI20090003" };
            NuclearQtTransDetail[] arrQtTransDetail={};
            NuclearQtTransDetailB[] arrQtTransDetailB={};
            try
            {
               
                //string bucketCode = "HJ00002";
                NuclearQtTrans item = new NuclearQtTrans();
                item.TicketCode= "80000234432 ";
                item.BucketWeight= 23;
                item.ProcessNo= "800 ";
                item.ProcessDate= Convert.ToDateTime("2017-07-07");
                item.InspectionNo= "34432 ";
                item.InspectionDate= Convert.ToDateTime("2017-07-07");
                item.TicketCode= "8000432 ";
                //item.BucketTypeId = "33329854-d7bc-42f6-84c8-2051c1e3ec32";
                //item.ControlPersonNo = "HJ";
                //item.CheckPersonNo = "HJ";
                //item.ControlDate = Convert.ToDateTime("2017-07-07");
                //item.CheckDate = Convert.ToDateTime("2017-07-07");
                obj.InsertQTTransfer(item, bucketCode, arrQtTransDetail, arrQtTransDetailB, "CC", out outErrorMessage);
              
              

            }
            catch
            {

               
            
            }


            return null;
        }
    }
}
  