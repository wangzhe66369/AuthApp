﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using NET01.CoreFramework;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Presentation.Web.Core.Ftp;
using RWIS.Presentation.Web.Core;
using System.Web;
using System.IO;
using NET01.CoreFramework.Ftp;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.Areas.MaterialManage.Common.ViewModels;
using RWIS.Presentation.Web.Areas.MaterialManage.Common;
using RWIS.Domain.DomainObjects.View.MaterialCheck;
using CIT.UPC.Domain.Repositories;
using CIT.UPC.Domain.DomainObjects;
using RWIS.Presentation.Web.ViewModels.Common;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;


namespace RWIS.Presentation.Web.Areas.MaterialManage.Controllers
{
    public class MaterialCheckController : Controller
    {
        IMaterialCheckRepository _MaterialCheckRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IMetelAcceptDetailRepository _MetelAcceptDetailRepository;
        IMetelAcceptRepository _MetelAcceptRepository;
        ICementAcceptDetailRepository _CementAcceptDetailRepository;
        ICementAcceptRepository _CementAcceptRepository;
        ISolidAcceptDetailRepository _SolidAcceptDetailRepository;
        ISolidAcceptRepository _SolidAcceptRepository;
        IOtherAcceptRepository _OtherAcceptRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        public MaterialCheckController(ICementAcceptDetailRepository _CementAcceptDetailRepository,
                                        ICementAcceptRepository _CementAcceptRepository,
                                        ISolidAcceptDetailRepository _SolidAcceptDetailRepository,
                                        ISolidAcceptRepository _SolidAcceptRepository,
                                        IMetelAcceptRepository _MetelAcceptRepository,
                                        IMetelAcceptDetailRepository _MetelAcceptDetailRepository,
                                        IMaterialCheckRepository _MaterialCheckRepository,
                                        IBasicObjectRepository _BasicObjectRepository,
                                        IOtherAcceptRepository _OtherAcceptRepository,
                                        INuclearBucketRepository _NuclearBucketRepository,
                                        IMaterialTypeRepository _MaterialTypeRepository
                                        )
        {   //注入材料验收对象
            this._MaterialCheckRepository = _MaterialCheckRepository;
            //注入基础数据对象
            this._BasicObjectRepository = _BasicObjectRepository;
            //注入金属验收详细对象
            this._MetelAcceptDetailRepository = _MetelAcceptDetailRepository;
            //注入金属验收对象
            this._MetelAcceptRepository = _MetelAcceptRepository;
            //注入水泥桶验收详细对象
            this._CementAcceptDetailRepository = _CementAcceptDetailRepository;
            //注入水泥桶验收对象
            this._CementAcceptRepository = _CementAcceptRepository;
            //注入固化验收详细对象
            this._SolidAcceptDetailRepository = _SolidAcceptDetailRepository;
            //注入固化验收对象
            this._SolidAcceptRepository = _SolidAcceptRepository;
            //注入其他验收单对象
            this._OtherAcceptRepository = _OtherAcceptRepository;
           
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
        }

        /// <summary>
        /// 初始页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "材料验收")]
        public ActionResult Index()
        {
            MaterialCheckVM vm = new MaterialCheckVM();
            vm.OperationList = CommonHelper.GetOperationList("Material_Check");
            return View(vm);
        }

        /// <summary>
        ///金属桶现场验收单 
        /// </summary>
        /// <returns></returns>
         [UbaFilter(OperateType = OperateType.Page, OperateDescription = "金属桶现场验收单")]
        public ActionResult IndexMetel()
        {
            MetelAcceptVM model = new MetelAcceptVM();
            model.OperationList = CommonHelper.GetOperationList("Index_Metel");
            MetelAccept MetelAccept = new MetelAccept();
            model.MetelAccept = MetelAccept;
            return View(model);
        }
        /// <summary>
        /// 水泥桶现场验收单
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "水泥桶现场验收单")]
        public ActionResult IndexCement()
        {
            CementAcceptVM model = new CementAcceptVM();
            CementAccept CementAccept = new CementAccept();
            model.OperationList = CommonHelper.GetOperationList("Index_Cement");
            model.CementAccept = CementAccept;
            return View(model);
        }
        /// <summary>
        /// 固化材料验收单
        /// </summary>
        /// <returns></returns>
         [UbaFilter(OperateType = OperateType.Page, OperateDescription = "固化材料验收单")]
        public ActionResult IndexSolid()
        {

            SolidAcceptVM vm = new SolidAcceptVM();
            vm.OperationList = CommonHelper.GetOperationList("Index_Solid");
            vm.InputLocationIdList = new List<SelectListItem>();
            IQueryable<BasicObject> inputLocationIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> inputLocationIdList = new List<BasicObject>();
            if (inputLocationIdQuery.Count() > 0)
            {
                inputLocationIdList = inputLocationIdQuery.ToList();
            }
            foreach (var item in inputLocationIdList)
            {
                vm.InputLocationIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            SolidAccept SolidAccept = new SolidAccept();
            vm.SolidAccept = SolidAccept;
            //材料名称下拉设置数据
            List<MaterialType> listType = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode&&d.IsBucket=="0").Where(d => d.Status == "2").ToList();
            SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
            ViewData["MaterialName"] = s1;
            return View(vm);
        }
        /// <summary>
        /// 其他验收单
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "其他验收单")]
        public ActionResult IndexOther()
        {
            OtherAcceptVM model = new OtherAcceptVM();
            model.OperationList = CommonHelper.GetOperationList("Index_Other");
            OtherAccept OtherAccept = new OtherAccept();
            model.OtherAccept = OtherAccept;
            return View(model);

        }

        /// <summary>
        /// 编辑页面数据显示
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Edit(string id, string type)
        {

            //存放地点下拉设置数据
            IQueryable<BasicObject> StorageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> StorageLocationList = new List<BasicObject>();
            if (StorageLocationQuery.Count() > 0)
            {
                StorageLocationList = StorageLocationQuery.ToList();
            }
            SelectList SelectList = new SelectList(StorageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;
            if (type == "MetelAccept")
            {
                MetelAccept metelAccept = _MetelAcceptRepository.Get(id);
                MetelAcceptVM model = new MetelAcceptVM();
                model.MetelAccept = metelAccept;
                model.OperationList = CommonHelper.GetOperationList("Index_Metel");

                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "QuestionReport");
                model.MetalAttachFiles = (List<AttachFile>)listAttachFile;
                ViewBag.BusinessType = "QuestionReport";
                return View("IndexMetel", model);


            }
            if (type == "CementlAccept")
            {
                CementAccept CementAccept = _CementAcceptRepository.Get(id);
                CementAcceptVM model = new CementAcceptVM();
                model.CementAccept = CementAccept;
                model.OperationList = CommonHelper.GetOperationList("Index_Cement");

                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "QuestionReport");
                model.CementAttachFiles = (List<AttachFile>)listAttachFile;
                ViewBag.BusinessType = "QuestionReport";

                return View("IndexCement", model);

            }
            if (type == "SolidAccept")
            {
                SolidAcceptVM vm = new SolidAcceptVM();
                vm.InputLocationIdList = new List<SelectListItem>();
                IQueryable<BasicObject> inputLocationIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
                List<BasicObject> inputLocationIdList = new List<BasicObject>();
                if (inputLocationIdQuery.Count() > 0)
                {
                    inputLocationIdList = inputLocationIdQuery.ToList();
                }
                foreach (var item in inputLocationIdList)
                {
                    vm.InputLocationIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }


                SolidAccept SolidAccept = _SolidAcceptRepository.Get(id);
                vm.OperationList = CommonHelper.GetOperationList("Index_Solid");
                vm.SolidAccept = SolidAccept;
                //材料名称下拉设置数据
                List<MaterialType> listType = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.IsBucket == "0").Where(d => d.Status == "2").ToList();
                SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
                ViewData["MaterialName"] = s1;

                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "QuestionReport");
                vm.SolidAttachFiles = (List<AttachFile>)listAttachFile;
                ViewBag.BusinessType = "QuestionReport";

                return View("IndexSolid", vm);

            }
            if (type == "OtherAccept")
            {
                OtherAccept otherAccept = _OtherAcceptRepository.Get(id);
                OtherAcceptVM model = new OtherAcceptVM();
                model.OperationList = CommonHelper.GetOperationList("Index_Other");
                model.OtherAccept = otherAccept;

                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile =GetAttachFileBy(id, "QuestionReport");
                model.OtherAttachFiles = (List<AttachFile>)listAttachFile;
                ViewBag.BusinessType = "QuestionReport";

                return View("IndexOther", model);

            }
            return View();
        }
        [HttpGet]
        public ActionResult DetailView(string id, string type)
        {
            if (type == "MetelAccept")
            {
                MetelAcceptVM model = new MetelAcceptVM();
                MetelAccept metelAccept = _MetelAcceptRepository.Get(id);
                model.MetelAccept = metelAccept;

                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "QuestionReport");
                model.MetalAttachFiles = (List<AttachFile>)listAttachFile;
                ViewBag.BusinessType = "QuestionReport";
                return View("ViewMetel", model);
            }
            if (type == "CementlAccept")
            {
                CementAccept CementAccept = _CementAcceptRepository.Get(id);
                CementAcceptVM model = new CementAcceptVM();
                model.CementAccept = CementAccept;

                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "QuestionReport");
                model.CementAttachFiles = (List<AttachFile>)listAttachFile;
                ViewBag.BusinessType = "QuestionReport";
                return View("ViewCement", model);

            }
            if (type == "SolidAccept")
            {
                SolidAcceptVM vm = new SolidAcceptVM();
                SolidAccept SolidAccept = _SolidAcceptRepository.Get(id);
                BasicObject basicObjectLocation = _BasicObjectRepository.Get(SolidAccept.InputLocationId);
                vm.LocationName = basicObjectLocation.Name;
                vm.SolidAccept = SolidAccept;

                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "QuestionReport");
                vm.SolidAttachFiles = (List<AttachFile>)listAttachFile;
                ViewBag.BusinessType = "QuestionReport";
                return View("ViewSolid", vm);

            }
            if (type == "OtherAccept")
            {
                OtherAccept otherAccept = _OtherAcceptRepository.Get(id);
                OtherAcceptVM model = new OtherAcceptVM();
                model.OtherAccept = otherAccept;


                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = GetAttachFileBy(id, "QuestionReport");
                model.OtherAttachFiles = (List<AttachFile>)listAttachFile;
                ViewBag.BusinessType = "QuestionReport";

                return View("ViewOther", model);

            }
            return View();
        
        }
        /// <summary>
        /// 是否存在桶号
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public JsonResult IsExisBucketCode(string bucketCode)
        {
           
            try
            {
                List<NuclearBucket> nuclearBucketList = this._NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).Where(d=>d.Status=="2").ToList();
                if (nuclearBucketList.Count() >0)
                {
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 初始查询所有验证单
        /// </summary>
        /// <param name="materialInputCondition"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetMaterialCheckList(MaterialCheckCondition condition, string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<MaterialCheckView> data = this._MaterialCheckRepository.QueryList(condition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderBy("CreateDate", SortDirection.Descending);
            var pagedViewModel = new PagedViewModel<MaterialCheckView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.AcceptId,
                    List = new List<object>() {                      
                        d.AcceptId,
                        d.OrderCode,  
                        d.Type,
                        d.ExceptionCondition,
                        string.IsNullOrEmpty(d.AcceptUserName)?"": "["+d.AcceptUserNo+"]"+d.AcceptUserName,
                        string.IsNullOrEmpty(d.CheckUserName)?"": "["+d.CheckUserNo+"]"+d.CheckUserName,
                        d.Status
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 保存金属桶验收单
        /// </summary>
        /// <param name="model">金属验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraftMetel(MetelAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.MetelAccept.AcceptId))
                {
                    //新增保存数据
                   string message = SaveMetel(model, "0","");
                   if (!string.IsNullOrEmpty(message))
                   {
                       return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                   }
                }
                //修改完新增
                else
                {
                    //修改保存
                     string message = UpdateMetel(model, "0","");
                     if (!string.IsNullOrEmpty(message))
                     {
                         return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                     }
                }

                this._MetelAcceptDetailRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.MetelAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交金属桶验收单
        /// </summary>
        /// <param name="model">金属验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitDraftMetel(MetelAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //新增
                if (string.IsNullOrEmpty(model.MetelAccept.AcceptId))
                {
                    //新增保存数据
                     string message =SaveMetel(model, "1","");
                     if (!string.IsNullOrEmpty(message))
                     {
                         return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                     }
                }
                //修改完新增
                else
                {
                    //修改保存
                     string message =UpdateMetel(model, "1","");
                     if (!string.IsNullOrEmpty(message))
                     {
                         return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                     }
                }
              
                this._MetelAcceptDetailRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.MetelAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确定金属桶验收单
        /// </summary>
        /// <param name="model">金属验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "金属桶验收单确认")]
        public JsonResult ConfirmDraftMetel(MetelAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
               
                //新增
                if (string.IsNullOrEmpty(model.MetelAccept.AcceptId))
                {
                    //新增保存数据
                    string message = SaveMetel(model, "2", "Confirm");
                    if (!string.IsNullOrEmpty(message))
                    {
                        return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                //修改完新增
                else
                {
                    //修改保存
                    string message = UpdateMetel(model, "2", "Confirm");
                    if (!string.IsNullOrEmpty(message))
                    {
                        return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
              
                this._MetelAcceptDetailRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.MetelAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改保存
        /// </summary>
        /// <param name="model"></param>
        private string UpdateMetel(MetelAcceptVM model, string status,string type)
        {
            //更新金属桶验收单
            model.MetelAccept = _MetelAcceptRepository.Get(model.MetelAccept.AcceptId);
            UpdateModel(model);
            model.MetelAccept.Status = status;
            if (type == "Confirm")
            {
             model.MetelAccept.ConfirmDate = DateTime.Now;
             model.MetelAccept.ConfirmUserNo=AppContext.CurrentUser.UserId;
             model.MetelAccept.ConfirmUserName= AppContext.CurrentUser.UserName;
             model.MetelAccept.Stationcode = AppContext.CurrentUser.ProjectCode;
            }
            this._MetelAcceptRepository.Update(model.MetelAccept);
            //根据金属桶验收单ID查询金属桶验收单详细
            IQueryable<MetelAcceptDetailView> data = this._MetelAcceptDetailRepository.QueryListByAcceptId(model.MetelAccept.AcceptId);
            List<MetelAcceptDetailView> listData = data.ToList();
            //删除金属桶验收单详细的数据
            foreach (var item in listData)
            {
                this._MetelAcceptDetailRepository.DeleteById(item.DetailId);
            }

            if (!string.IsNullOrEmpty(model.MetelBuckets))
            {
                //新增金属验收单明细
                string[] arrMetelBucketList = model.MetelBuckets.Split(';');
                for (int i = 0; i < arrMetelBucketList.Length; i++)
                {

                    MetelAcceptDetail metelAcceptDetail = new MetelAcceptDetail();
                    string[] arrMetelBucket = arrMetelBucketList[i].Split(',');
                    IQueryable<NuclearBucket> bucketCodeList = _NuclearBucketRepository.QueryListByCode(arrMetelBucket[2], AppContext.CurrentUser.ProjectCode);
                    if (bucketCodeList.Count() > 0)
                    {
                        string bucketId = string.Empty;
                        foreach (var item in bucketCodeList)
                        {
                            bucketId = item.BucketId;
                        }
                        if (arrMetelBucket.Length == 9)
                        {
                            metelAcceptDetail.DetailId = Guid.NewGuid().ToString();
                            metelAcceptDetail.AcceptId = model.MetelAccept.AcceptId;
                            metelAcceptDetail.BucketId = bucketId;
                            metelAcceptDetail.BucketHeight = arrMetelBucket[3];
                            metelAcceptDetail.ExternalDiameter = arrMetelBucket[4];
                            metelAcceptDetail.InnerDiameter = arrMetelBucket[5];
                            metelAcceptDetail.ExternalQuality = arrMetelBucket[6];
                            metelAcceptDetail.InnerQuality = arrMetelBucket[7];
                            metelAcceptDetail.AcceptResult = arrMetelBucket[8];

                            this._MetelAcceptDetailRepository.Create(metelAcceptDetail);
                        }

                    }
                    else
                    {
                        return "fail";
                    }
                   
                }

            }
            return null;
        }
        /// <summary>
        /// 新增保存数据
        /// </summary>
        /// <param name="model"></param>
        private string SaveMetel(MetelAcceptVM model, string status,string type)
        {
            //新增金属桶验收单主单
            model.MetelAccept.AcceptId = Guid.NewGuid().ToString();
            model.MetelAccept.CreateDate = DateTime.Now;
            model.MetelAccept.CreateUserName = AppContext.CurrentUser.UserName;
            model.MetelAccept.CreateUserNo = AppContext.CurrentUser.UserId;
            model.MetelAccept.Status = status;
            model.MetelAccept.Stationcode = AppContext.CurrentUser.ProjectCode;
            if (type == "Confirm")
            {
                model.MetelAccept.ConfirmDate = DateTime.Now;
                model.MetelAccept.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.MetelAccept.ConfirmUserName = AppContext.CurrentUser.UserName;
            }
            this._MetelAcceptRepository.Create(model.MetelAccept);
            if (!string.IsNullOrEmpty(model.MetelBuckets))
            {
                //新增金属验收单明细
                string[] arrMetelBucketList = model.MetelBuckets.Split(';');
                for (int i = 0; i < arrMetelBucketList.Length; i++)
                {
                    MetelAcceptDetail metelAcceptDetail = new MetelAcceptDetail();
                    string[] arrMetelBucket = arrMetelBucketList[i].Split(',');
                    IQueryable<NuclearBucket> bucketCodeList = _NuclearBucketRepository.QueryListByCode(arrMetelBucket[2], AppContext.CurrentUser.ProjectCode);
                    List<NuclearBucket> bucketCodeListNuclea = bucketCodeList.ToList();
                    if (bucketCodeListNuclea.Count() > 0)
                    {
                        string bucketId = string.Empty;
                        foreach (var item in bucketCodeListNuclea)
                        {
                            bucketId = item.BucketId;
                        }
                        if (arrMetelBucket.Length == 9)
                        {
                            metelAcceptDetail.DetailId = Guid.NewGuid().ToString();
                            metelAcceptDetail.AcceptId = model.MetelAccept.AcceptId;
                            metelAcceptDetail.BucketId = bucketId;
                            metelAcceptDetail.BucketHeight = arrMetelBucket[3];
                            metelAcceptDetail.ExternalDiameter = arrMetelBucket[4];
                            metelAcceptDetail.InnerDiameter = arrMetelBucket[5];
                            metelAcceptDetail.ExternalQuality = arrMetelBucket[6];
                            metelAcceptDetail.InnerQuality = arrMetelBucket[7];
                            metelAcceptDetail.AcceptResult = arrMetelBucket[8];

                            this._MetelAcceptDetailRepository.Create(metelAcceptDetail);
                        }

                    }
                    else
                    {
                        return "fail";
                    }
                }

            }
            return null;

          
        }

        /// <summary>
        /// 金属桶初始化查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetMetelAcceptDetailList(string AcceptId, string sord, int page, int rows, string sidx)
        {
            if (string.IsNullOrEmpty(AcceptId))
            {
                return null;
            }
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<MetelAcceptDetailView> data = this._MetelAcceptDetailRepository.QueryListByAcceptId(AcceptId);
            var pagedViewModel = new PagedViewModel<MetelAcceptDetailView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DetailId,
                    List = new List<object>() {   
                        d.DetailId,
                        d.BucketCode,
                        d.BucketHeight,
                        d.ExternalDiameter,
                        d.InnerDiameter,
                        d.ExternalQuality,
                        d.InnerQuality,
                        d.AcceptResult                    
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 保存水泥桶验收单
        /// </summary>
        /// <param name="model">水泥验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraftCement(CementAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                //新增
                if (string.IsNullOrEmpty(model.CementAccept.AcceptId))
                {
                     string message =SaveCement(model, "0","");
                     if (!string.IsNullOrEmpty(message))
                     {
                         return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                     }
                }//修改
                else
                {
                     string message =UpdateCement(model, "0","");
                     if (!string.IsNullOrEmpty(message))
                     {
                         return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                     }
                }
                //提交
               
                this._CementAcceptDetailRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.CementAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        /// <summary>
        /// 提交水泥桶验收单
        /// </summary>
        /// <param name="model">水泥验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitDraftCement(CementAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                //新增
                if (string.IsNullOrEmpty(model.CementAccept.AcceptId))
                {
                    string message = SaveCement(model, "1", "");
                    if (!string.IsNullOrEmpty(message))
                    {
                        return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }


                }//修改
                else
                {
                    string message = UpdateCement(model, "1", "");
                    if (!string.IsNullOrEmpty(message))
                    {
                        return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }

                }
                //提交
                
                this._CementAcceptDetailRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.CementAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认水泥桶验收单
        /// </summary>
        /// <param name="model">水泥验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "水泥桶验收单确认")]
        public JsonResult ConfirmDraftCement(CementAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                //新增
                if (string.IsNullOrEmpty(model.CementAccept.AcceptId))
                {
                    string message = SaveCement(model, "2", "Confirm");
                    if (!string.IsNullOrEmpty(message))
                    {
                        return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                }//修改
                else
                {
                    string message = UpdateCement(model, "2", "Confirm");
                    if (!string.IsNullOrEmpty(message))
                    {
                        return Json("{\"result\":false,\"msg\":\"桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                //提交
               
                this._CementAcceptDetailRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.CementAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确定失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        private string UpdateCement(CementAcceptVM model, string status,string type)
        {
            //更新水泥桶验收单
            model.CementAccept = _CementAcceptRepository.Get(model.CementAccept.AcceptId);
            UpdateModel(model);
            model.CementAccept.Status = status;
            if (type == "Confirm")
            {
                model.CementAccept.ConfirmDate = DateTime.Now;
                model.CementAccept.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.CementAccept.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.CementAccept.Stationcode = AppContext.CurrentUser.ProjectCode;
            }
            this._CementAcceptRepository.Update(model.CementAccept);
            //根据水泥桶验收单ID查询金属桶验收单详细
            IQueryable<CementAcceptDetailView> data = this._CementAcceptDetailRepository.QueryListByAcceptId(model.CementAccept.AcceptId);
            List<CementAcceptDetailView> listData = data.ToList();
            //删除水泥桶验收单详细的数据
            foreach (var item in listData)
            {
                this._CementAcceptDetailRepository.DeleteById(item.DetailId);
            }

            //新增水泥验收单明细
            if (!string.IsNullOrEmpty(model.CenmentBuckets))
            {
                string[] arrCementBucketList = model.CenmentBuckets.Split(';');
                for (int i = 0; i < arrCementBucketList.Length; i++)
                {
                    CementAcceptDetail CementAcceptDetail = new CementAcceptDetail();
                   
                        string[] arrCementBucket = arrCementBucketList[i].Split(',');

                        IQueryable<NuclearBucket> bucketCodeList = _NuclearBucketRepository.QueryListByCode(arrCementBucket[1], AppContext.CurrentUser.ProjectCode);
                        if (bucketCodeList.Count() > 0)
                        {
                            string bucketId = string.Empty;
                            foreach (var item in bucketCodeList)
                            {
                                bucketId = item.BucketId;
                            }
                            if (arrCementBucket.Length == 9)
                            {

                                CementAcceptDetail.DetailId = Guid.NewGuid().ToString();
                                CementAcceptDetail.AcceptId = model.CementAccept.AcceptId;
                                CementAcceptDetail.CreateDate = DateTime.Parse(arrCementBucket[0]);
                                CementAcceptDetail.BucketId = bucketId;
                                CementAcceptDetail.SandySurface = arrCementBucket[2];
                                CementAcceptDetail.Cavatity = arrCementBucket[3];
                                CementAcceptDetail.Crack = arrCementBucket[4];
                                CementAcceptDetail.Breach = arrCementBucket[5];
                                CementAcceptDetail.BucketHeight = arrCementBucket[6];
                                CementAcceptDetail.InnerDiameter = arrCementBucket[7];
                                CementAcceptDetail.Concentric = arrCementBucket[8];
                                this._CementAcceptDetailRepository.Create(CementAcceptDetail);
                            }

                        }
                        else
                        {
                            return "fail";
                        }
                   

                }
            }
            return null;
        }
        /// <summary>
        /// 保存提交
        /// </summary>
        /// <param name="model"></param>
        private string SaveCement(CementAcceptVM model, string status, string type)
        {
            //新增水泥桶验收单主单
            model.CementAccept.AcceptId = Guid.NewGuid().ToString();
            model.CementAccept.CreateDate = DateTime.Now;
            model.CementAccept.CreateUserName = AppContext.CurrentUser.UserName;
            model.CementAccept.CreateUserNo = AppContext.CurrentUser.UserId;
            model.CementAccept.Status = status;
            model.CementAccept.Stationcode = AppContext.CurrentUser.ProjectCode;
            if (type == "Confirm")
            {
                model.CementAccept.ConfirmDate = DateTime.Now;
                model.CementAccept.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.CementAccept.ConfirmUserName = AppContext.CurrentUser.UserName;
            }
            this._CementAcceptRepository.Create(model.CementAccept);

            //新增水泥验收单明细
            if (!string.IsNullOrEmpty(model.CenmentBuckets))
            {
                string[] arrCementBucketList = model.CenmentBuckets.Split(';');
                for (int i = 0; i < arrCementBucketList.Length; i++)
                {
                    CementAcceptDetail CementAcceptDetail = new CementAcceptDetail();
                   
                        string[] arrCementBucket = arrCementBucketList[i].Split(',');
                        IQueryable<NuclearBucket> bucketCodeList = _NuclearBucketRepository.QueryListByCode(arrCementBucket[1], AppContext.CurrentUser.ProjectCode);
                        if (bucketCodeList.Count() > 0)
                        {
                            string bucketId = string.Empty;
                            foreach (var item in bucketCodeList)
                            {
                                bucketId = item.BucketId;
                            }
                            if (arrCementBucket.Length == 9)
                            {

                                CementAcceptDetail.DetailId = Guid.NewGuid().ToString();
                                CementAcceptDetail.AcceptId = model.CementAccept.AcceptId;
                                CementAcceptDetail.CreateDate = DateTime.Parse(arrCementBucket[0]);
                                CementAcceptDetail.BucketId = bucketId;
                                CementAcceptDetail.SandySurface = arrCementBucket[2];
                                CementAcceptDetail.Cavatity = arrCementBucket[3];
                                CementAcceptDetail.Crack = arrCementBucket[4];
                                CementAcceptDetail.Breach = arrCementBucket[5];
                                CementAcceptDetail.BucketHeight = arrCementBucket[6];
                                CementAcceptDetail.InnerDiameter = arrCementBucket[7];
                                CementAcceptDetail.Concentric = arrCementBucket[8];
                                this._CementAcceptDetailRepository.Create(CementAcceptDetail);
                            }

                        }
                        else
                        {
                            return "fail";
                        }
                   

                }
            }
            return null;
        }
        /// <summary>
        /// 初始化查询水泥桶详细信息列表
        /// </summary>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetCementAcceptDetailList(string AcceptId, string sord, int page, int rows, string sidx)
        {
            if (string.IsNullOrEmpty(AcceptId))
            {
                return null;
            }
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            IQueryable<CementAcceptDetailView> data = this._CementAcceptDetailRepository.QueryListByAcceptId(AcceptId);
            var pagedViewModel = new PagedViewModel<CementAcceptDetailView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DetailId,
                    List = new List<object>() {   
                        d.DetailId,
                        d.CreateDate.HasValue? d.CreateDate.Value.ToString("yyyy-MM-dd"):"",  
                        d.BucketCode,
                        d.SandySurface,
                        d.Cavatity,
                        d.Crack,
                        d.Breach,
                        d.BucketHeight,
                        d.InnerDiameter,
                        d.Concentric                    
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 保存固化验收单
        /// </summary>
        /// <param name="model">其他验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]

        public JsonResult SaveDraftSolid(SolidAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {//新增
                if (string.IsNullOrEmpty(model.SolidAccept.AcceptId))
                {
                    //新增固化验收单及明细
                    SaveSolid(model, "0","");
                }//修改
                else
                {
                    //修改固化验收单及明细
                    UpdateSolid(model, "0","");
                }

                //提交
                
                this._SolidAcceptDetailRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.SolidAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {

                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交固化验收单
        /// </summary>
        /// <param name="model">其他验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitDraftSolid(SolidAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {//新增
                if (string.IsNullOrEmpty(model.SolidAccept.AcceptId))
                {
                    //新增固化验收单及明细
                    SaveSolid(model, "1","");
                }//修改
                else
                {
                    //修改固化验收单及明细
                    UpdateSolid(model, "1","");
                }
                //提交
             
                this._SolidAcceptDetailRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.SolidAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {

                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认固化验收单
        /// </summary>
        /// <param name="model">其他验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "固化验收单确认")]
        public JsonResult ConfirmDraftSolid(SolidAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {//新增
                if (string.IsNullOrEmpty(model.SolidAccept.AcceptId))
                {
                    //新增固化验收单及明细
                    SaveSolid(model, "2","Confirm");
                }//修改
                else
                {
                    //修改固化验收单及明细
                    UpdateSolid(model, "2","Confirm");
                }
                //提交
                
                this._SolidAcceptDetailRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.SolidAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {

                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }



        /// <summary>
        /// 修改固化验收单及明细
        /// </summary>
        /// <param name="model"></param>
        private void UpdateSolid(SolidAcceptVM model, string status,string type)
        {
            //更新固化验收单
            model.SolidAccept = _SolidAcceptRepository.Get(model.SolidAccept.AcceptId);
            UpdateModel(model);
            model.SolidAccept.Status = status;
            if (type == "Confirm")
            {
                model.SolidAccept.ConfirmDate = DateTime.Now;
                model.SolidAccept.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.SolidAccept.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.SolidAccept.Stationcode = AppContext.CurrentUser.ProjectCode;
            }
            this._SolidAcceptRepository.Update(model.SolidAccept);
            //根据固化验收单ID查询金属桶验收单详细
            IQueryable<SolidAcceptDetail> data = this._SolidAcceptDetailRepository.QueryListByAcceptId(model.SolidAccept.AcceptId);
            List<SolidAcceptDetail> listData = data.ToList();
            //删除固化验收单详细的数据
            foreach (var item in listData)
            {
                this._SolidAcceptDetailRepository.DeleteById(item.DetailId);
            }
            if (!string.IsNullOrEmpty(model.SolidBuckets))
            {
                //新增固化验收单明细
                string[] arrSolidBucketList = model.SolidBuckets.Split(';');
                for (int i = 0; i < arrSolidBucketList.Length; i++)
                {
                    SolidAcceptDetail solidAcceptDetail = new SolidAcceptDetail();
                    string[] arrSolidBucket = arrSolidBucketList[i].Split(',');
                    if (arrSolidBucket.Length == 4)
                    {
                        solidAcceptDetail.DetailId = Guid.NewGuid().ToString();
                        solidAcceptDetail.AcceptId = model.SolidAccept.AcceptId;
                        solidAcceptDetail.AcceptMaterial = arrSolidBucket[0];
                        solidAcceptDetail.Amount = Convert.ToDecimal(arrSolidBucket[1] == "" ? "0" : arrSolidBucket[1]);
                        solidAcceptDetail.Goodsdoc = arrSolidBucket[2];
                        solidAcceptDetail.Report = arrSolidBucket[3];

                        this._SolidAcceptDetailRepository.Create(solidAcceptDetail);
                    }
                }


            }
        }
        /// <summary>
        /// 新增固化验收单及明细
        /// </summary>
        /// <param name="model"></param>
        private void SaveSolid(SolidAcceptVM model, string status,string type)
        {
            //新增固化验收单主单
            model.SolidAccept.AcceptId = Guid.NewGuid().ToString();
            model.SolidAccept.CreateDate = DateTime.Now;
            model.SolidAccept.CreateUserName = AppContext.CurrentUser.UserName;
            model.SolidAccept.CreateUserNo = AppContext.CurrentUser.UserId;
            model.SolidAccept.Status = status;
            model.SolidAccept.Stationcode = AppContext.CurrentUser.ProjectCode;
            if (type == "Confirm")
            {
                model.SolidAccept.ConfirmDate = DateTime.Now;
                model.SolidAccept.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.SolidAccept.ConfirmUserName = AppContext.CurrentUser.UserName;
            }
            this._SolidAcceptRepository.Create(model.SolidAccept);
            if (!string.IsNullOrEmpty(model.SolidBuckets))
            {
                //新增固化验收单明细
                string[] arrSolidBucketList = model.SolidBuckets.Split(';');
                for (int i = 0; i < arrSolidBucketList.Length; i++)
                {
                    SolidAcceptDetail solidAcceptDetail = new SolidAcceptDetail();
                    string[] arrSolidBucket = arrSolidBucketList[i].Split(',');
                    if (arrSolidBucket.Length == 4)
                    {
                        solidAcceptDetail.DetailId = Guid.NewGuid().ToString();
                        solidAcceptDetail.AcceptId = model.SolidAccept.AcceptId;
                        solidAcceptDetail.AcceptMaterial = arrSolidBucket[0];
                        solidAcceptDetail.Amount = Convert.ToDecimal(arrSolidBucket[1] == "" ? "0" : arrSolidBucket[1]);
                        solidAcceptDetail.Goodsdoc = arrSolidBucket[2];
                        solidAcceptDetail.Report = arrSolidBucket[3];

                        this._SolidAcceptDetailRepository.Create(solidAcceptDetail);
                    }
                }


            }
        }
        /// <summary>
        /// 固化验收单查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetSolidAcceptDetailList(string AcceptId, string sord, int page, int rows, string sidx)
        {

            if (string.IsNullOrEmpty(AcceptId))
            {
                return null;
            }
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<SolidAcceptDetail> data = this._SolidAcceptDetailRepository.QueryListByAcceptId(AcceptId);
            foreach (var item in data)
	        {
		      MaterialType materialType= this._MaterialTypeRepository.Get(item.AcceptMaterial);
              if (materialType != null)
              {
                  item.AcceptMaterial = materialType.MaterialName;
              }
	        }

            var pagedViewModel = new PagedViewModel<SolidAcceptDetail>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DetailId,
                    List = new List<object>() {   
                        d.DetailId,
                        //d.AcceptId,
                        d.AcceptMaterial,
                        d.Amount,
                        d.Goodsdoc,
                        d.Report                   
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 保存其他验收单
        /// </summary>
        /// <param name="model">其他验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraftOther(OtherAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            { //新增
                if (string.IsNullOrEmpty(model.OtherAccept.AcceptId))
                {
                    SaveOther(model,"0","");
                }//编辑
                else
                {
                    model = UpdateOther(model, "0","");            
                }
               
                this._OtherAcceptRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.OtherAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交其他验收单
        /// </summary>
        /// <param name="model">其他验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SubmitDraftOther(OtherAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                //新增
                if (string.IsNullOrEmpty(model.OtherAccept.AcceptId))
                {
                    SaveOther(model, "1","");


                }//编辑
                else
                {

                    model = UpdateOther(model, "1","");            

                }
                this._OtherAcceptRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.OtherAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确定其他验收单
        /// </summary>
        /// <param name="model">其他验收单实体</param>
        /// <param name="formCollection">页面集合</param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "其他验收单确认")]
        public JsonResult ConfirmDraftOther(OtherAcceptVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                //新增
                if (string.IsNullOrEmpty(model.OtherAccept.AcceptId))
                {
                    SaveOther(model, "2", "Confirm");
                }//编辑
                else
                {
                    model = UpdateOther(model, "2", "Confirm");            
                }
                this._OtherAcceptRepository.UnitOfWork.Commit();
                this.SaveAttachFile(model.OtherAccept.AcceptId, "UploadOther", formCollection);
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 修改保存验收单
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private OtherAcceptVM UpdateOther(OtherAcceptVM model, string status,string type)
        {
            model.OtherAccept = _OtherAcceptRepository.Get(model.OtherAccept.AcceptId);
            UpdateModel(model);
            model.OtherAccept.Status = status;
            if (type == "Confirm")
            {
                model.OtherAccept.ConfirmDate = DateTime.Now;
                model.OtherAccept.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.OtherAccept.ConfirmUserName = AppContext.CurrentUser.UserName;
                model.OtherAccept.Stationcode = AppContext.CurrentUser.ProjectCode;
            }
            this._OtherAcceptRepository.Update(model.OtherAccept);
            return model;
        }
        /// <summary>
        /// 保存验收单
        /// </summary>
        /// <param name="model"></param>
        private void SaveOther(OtherAcceptVM model, string status,string type)
        {
            //新增其他验收单
            model.OtherAccept.AcceptId = Guid.NewGuid().ToString();
            model.OtherAccept.CreateDate = DateTime.Now;
            model.OtherAccept.CreateUserName = AppContext.CurrentUser.UserName;
            model.OtherAccept.CreateUserNo = AppContext.CurrentUser.UserId;
            model.OtherAccept.Status = status;
            model.OtherAccept.Stationcode = AppContext.CurrentUser.ProjectCode;
            if (type == "Confirm")
            {
                model.OtherAccept.ConfirmDate = DateTime.Now;
                model.OtherAccept.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.OtherAccept.ConfirmUserName = AppContext.CurrentUser.UserName;
            }
            this._OtherAcceptRepository.Create(model.OtherAccept);
        }

        /// <summary>
        /// 删除材料
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id, string type)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    if (type == "金属桶现场验收")
                    {
                        this._MetelAcceptRepository.DeleteById(id);
                        IQueryable<MetelAcceptDetailView> metelAcceptDetail = _MetelAcceptDetailRepository.QueryListByAcceptId(id);
                        List<MetelAcceptDetailView> metelAcceptDetailList = metelAcceptDetail.ToList();
                        foreach (var itemAcceptDetail in metelAcceptDetailList)
                        {
                            this._MetelAcceptDetailRepository.DeleteById(itemAcceptDetail.DetailId);
                        }

                    }
                    if (type == "水泥桶现象验收")
                    {
                        this._CementAcceptRepository.DeleteById(id);
                        IQueryable<CementAcceptDetailView> cementAcceptDetail = _CementAcceptDetailRepository.QueryListByAcceptId(id);
                        List<CementAcceptDetailView> cementAcceptDetailList = cementAcceptDetail.ToList();
                        foreach (var itemAcceptDetail in cementAcceptDetailList)
                        {
                            this._CementAcceptDetailRepository.DeleteById(itemAcceptDetail.DetailId);
                        }

                    }
                    if (type == "固化材料验收单")
                    {

                        this._SolidAcceptRepository.DeleteById(id);
                        IQueryable<SolidAcceptDetail> solidAcceptDetail = _SolidAcceptDetailRepository.QueryListByAcceptId(id);
                        List<SolidAcceptDetail> solidAcceptDetailList = solidAcceptDetail.ToList();
                        foreach (var itemAcceptDetail in solidAcceptDetailList)
                        {
                            this._SolidAcceptDetailRepository.DeleteById(itemAcceptDetail.DetailId);
                        }
                    }
                    if (type == "其他验收单")
                    {

                        this._OtherAcceptRepository.DeleteById(id);
                       
                    }

                    this._SolidAcceptDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 附件
        /// </summary>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], "QuestionReport");
            }
            return null;
        }
        /// <summary>
        /// 下载文件
        /// 
        /// </summary>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }

        /// <summary>
        /// 删除
        /// </summary>
        [AcceptVerbs(HttpVerbs.Post)]
        public bool DeleteFile(string fileId, string fileName, string businessType)
        {
            bool bResult;

            try
            {
                IAttachFileRepository AttachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                AttachFileRepository.DeleteById(fileId);
                AttachFileRepository.UnitOfWork.Commit();
                bResult = true;
            }
            catch (Exception)
            {
                bResult = false;
            }
            try
            {
                string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
                FtpFileStore.DeleteFile(fileId + "." + fileTypeStr, businessType);
            }
            catch (Exception)
            {
                bResult = true;
            }
            return bResult;
        }

        /// <summary>
        /// 根据业务编号以及业务类型得到附件列表
        /// </summary>
        /// <param name="businessId">业务编号</param>
        /// <param name="businessType">业务类型</param>
        /// <returns></returns>
        public IList<AttachFile> GetAttachFileBy(string businessId, string businessType)
        {
            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(businessId, businessType);
            return listAttachFile;
        }

    }
}
