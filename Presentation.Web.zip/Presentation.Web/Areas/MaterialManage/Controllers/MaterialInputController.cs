﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using NET01.CoreFramework;

using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;

using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Infrastructure.Data.UnitOfWork;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using CIT.UPC.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using CIT.UPC.Domain.DomainObjects;


namespace RWIS.Presentation.Web.Areas.MaterialManage.Controllers
{
    public class MaterialInputController : Controller
    {
        
        IMaterialInputRepository _MaterialInputRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        INuclearBucketChangeRepository _NuclearBucketChangeRepository;
        INuclearMStockRepository _NuclearMStockRepository;

        public MaterialInputController(INuclearMStockRepository _NuclearMStockRepository
            , INuclearBucketChangeRepository _NuclearBucketChangeRepository
            , INuclearBucketRepository _NuclearBucketRepository
            , IMaterialInputRepository _MaterialInputRepository
            , IMaterialTypeRepository _MaterialTypeRepository
            , IBasicObjectRepository _BasicObjectRepository
           )
        {
            this._MaterialInputRepository = _MaterialInputRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearBucketChangeRepository = _NuclearBucketChangeRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._NuclearMStockRepository = _NuclearMStockRepository;
            
        }
        /// <summary>
        /// 初始页面
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "材料入库")]
        public ActionResult Index()
        {
         
            MaterialInputVM vm = new MaterialInputVM();
            vm.OperationList = CommonHelper.GetOperationList("Material_Input");
            //材料名称下拉设置数据
            IQueryable<MaterialType> listTypeQuery = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.Status == "2").AsQueryable();
               
            List<MaterialType> listType = listTypeQuery.ToList();
            SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
            ViewData["MaterialName"] = s1;
                
            //存放地点下拉设置数据
            IQueryable<BasicObject> storageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storageLocationList = new List<BasicObject>();
            if (storageLocationQuery != null && storageLocationQuery.Count() > 0)
            {
                storageLocationList = storageLocationQuery.ToList();
            }
            SelectList SelectList = new SelectList(storageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;
            return View(vm);

           
        }

        /// <summary>
        /// 编辑页面数据显示
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Edit(string id)
        {
            MaterialInput modelInput = _MaterialInputRepository.Get(id);
            MaterialInputVM vm = new MaterialInputVM();
            vm.OperationList = CommonHelper.GetOperationList("Material_Input");
            vm.MaterialInput = modelInput;
            List<NuclearBucket> nuclearBucketList = new List<NuclearBucket>();
            //如果是点击修改进入此页面
            if (!string.IsNullOrEmpty(id))
            {
                IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == id).AsQueryable();
                IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().Where(d=>d.Stationcode==AppContext.CurrentUser.ProjectCode).AsQueryable();
                nuclearBucket = (from i in nuclearBucket
                                 join s in nuclearBucketChange
                                       on i.BucketId equals s.BucketId
                                       select i);
                if (nuclearBucket.Count() > 0)
                {
                    nuclearBucketList = nuclearBucket.ToList();
                }
            }
            var query = nuclearBucketList.OrderBy("BucketCode", SortDirection.Ascending);
            vm.nuclearBucketList = query.ToList();

            //材料名称下拉设置数据
            List<MaterialType> listType = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.Status =="2").ToList();
            if (listType.Count() == 0)
            {
                MaterialType materialType = new MaterialType();
                listType.Add(materialType);
            }
            SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
            ViewData["MaterialName"] = s1;

            //存放地点下拉设置数据
            IQueryable<BasicObject> storageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storageLocationList = new List<BasicObject>();
            if (storageLocationQuery.Count() > 0)
            {
                storageLocationList = storageLocationQuery.ToList();
            }
            if (storageLocationQuery.Count() == 0)
            {
                BasicObject basicObject = new BasicObject();
                storageLocationList.Add(basicObject);
            }
            SelectList SelectList = new SelectList(storageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;
            //单位下拉列表设置数据
            IQueryable<BasicObject> unitQuery = _BasicObjectRepository.GetSubobjectsByCode("Unit", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> unitList = new List<BasicObject>();
            if (unitQuery!=null && unitQuery.Count() > 0)
            {
                unitList = unitQuery.ToList();
            }
            if (unitQuery != null && unitList.Count() == 0)
            {
                BasicObject basicObject = new BasicObject();
                unitList.Add(basicObject);
            }
            SelectList SelectUnitList = new SelectList(unitList, "Uuid", "Name");
            ViewData["Unit"] = SelectUnitList;

            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "QuestionReport");
            vm.MaterialInputAttachFiles = (List<AttachFile>)listAttachFile;
            ViewBag.BusinessType = "QuestionReport";

            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View("Edit", vm);
        }
        /// <summary>
        /// 查看页面
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DetailView(string id)
        {
            MaterialInput modelInput = _MaterialInputRepository.Get(id);
            MaterialInputVM vm = new MaterialInputVM();
            vm.MaterialInput = modelInput;
           // List<NuclearBucket>  nuclearBucketList = new List<NuclearBucket>();
            //如果是点击修改进入此页面
            if (!string.IsNullOrEmpty(id))
            {

                IQueryable<NuclearBucketChange> nuclearBucketChangeQuery = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == id).AsQueryable();
                IQueryable<NuclearBucket> nuclearBucketQuery = _NuclearBucketRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();

                nuclearBucketQuery = (from bq in nuclearBucketQuery
                                     join bcq in nuclearBucketChangeQuery
                                     on bq.BucketId equals bcq.BucketId
                                      select bq).OrderBy(d=>d.BucketCode);

                if (nuclearBucketQuery.Count() > 0)
                {
                    vm.nuclearBucketList = nuclearBucketQuery.ToList();
                }
                //IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == id).AsQueryable();
                //foreach (var itemChage in nuclearBucketChange)
                //{
                //    NuclearBucket nuclearBucket = new NuclearBucket();

                //    nuclearBucket = _NuclearBucketRepository.Get(itemChage.BucketId);

                //    nuclearBucketList.Add(nuclearBucket);
                //}
            }
            //var query = nuclearBucketList.OrderBy("BucketCode", SortDirection.Ascending);
            //vm.nuclearBucketList = query.ToList();
            MaterialType materialType = _MaterialTypeRepository.Get(modelInput.MaterialId);
            BasicObject basicObjectLocation = _BasicObjectRepository.Get(modelInput.StorageLocationId);
            BasicObject basicObjectUnit = _BasicObjectRepository.Get(modelInput.UnitId);
            vm.MaterialName = materialType.MaterialName;
            vm.LocationName = basicObjectLocation.Name;
            vm.UuidName = basicObjectUnit.Name;


            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "QuestionReport");
            vm.MaterialInputAttachFiles = (List<AttachFile>)listAttachFile;
            ViewBag.BusinessType = "QuestionReport";


            return View("DetailView", vm);
        }
        /// <summary>
        /// 新增页面
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Add()
        {
            MaterialInputVM vm = new MaterialInputVM();
            vm.MaterialInput = new MaterialInput();
            vm.OperationList = CommonHelper.GetOperationList("Material_Input");
            //材料名称下拉设置数据
            List<MaterialType> listType = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.Status =="2").ToList();
            if (listType.Count() == 0)
            {
                MaterialType materialType = new MaterialType();
                listType.Add(materialType);
            }
            SelectList s1 = new SelectList(listType, "MaterialId", "MaterialName");
            ViewData["MaterialName"] = s1;
            //存放地点下拉设置数据
            IQueryable<BasicObject> storageLocationQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storageLocationList = new List<BasicObject>();
            if (storageLocationQuery!=null && storageLocationQuery.Count() > 0)
            {
                storageLocationList = storageLocationQuery.ToList();
            }
            if (storageLocationQuery != null && storageLocationQuery.Count() == 0)
            {
                BasicObject basicObject = new BasicObject();
                storageLocationList.Add(basicObject);
            }
            SelectList SelectList = new SelectList(storageLocationList, "Uuid", "Name");
            ViewData["StorageLocation"] = SelectList;
            //单位下拉列表设置数据
            IQueryable<BasicObject> unitQuery = _BasicObjectRepository.GetSubobjectsByCode("Unit", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> unitList = new List<BasicObject>();
            if (unitQuery!=null && unitQuery.Count() > 0)
            {
                unitList = unitQuery.ToList();
            }
            if (unitQuery != null && unitList.Count() == 0)
            {
                BasicObject basicObject = new BasicObject();
                unitList.Add(basicObject);
            }
            SelectList SelectUnitList = new SelectList(unitList, "Uuid", "Name");
            ViewData["Unit"] = SelectUnitList;

            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(vm.MaterialInput.InputId, "QuestionReport");
            vm.MaterialInputAttachFiles = (List<AttachFile>)listAttachFile;
            ViewBag.BusinessType = "QuestionReport";

            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);

        }
        /// <summary>
        /// 根据下拉列表求是不是桶
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SelectedInput(string materialId)
        {

            try
            {
                MaterialType materialType = _MaterialTypeRepository.Get(materialId);
                string isBucket = materialType != null ? materialType.IsBucket : string.Empty;
                BasicObject basicObject=new BasicObject();
                string materialSpec = "";
                string unit = "";
                string unitId = "";
                if (materialType != null)
                {

                    basicObject = _BasicObjectRepository.Get(materialType.SpecId);
                    materialSpec = basicObject != null ? basicObject.Name : "";
                    basicObject = _BasicObjectRepository.Get(materialType.UnitId);
                    unit = basicObject != null ? basicObject.Name : "";
                    unitId = materialType.UnitId;
                }
                
                if (string.IsNullOrEmpty(isBucket))
                {
                    return Json("{\"result\":\"0\"}", JsonRequestBehavior.AllowGet);
                }
                return Json("{\"result\":" + isBucket + ",\"unit\":\"" + unit + "\",\"MaterialSpec\":\"" + materialSpec + "\",\"unitId\":\"" + unitId + "\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"没有查询到桶的信息。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 新增入库表
        /// </summary>
        /// <param name="model"></param>
        private MaterialInput MaterialInputSingle(MaterialInputVM model, string status)
        {
            //MaterialType materialType = _MaterialTypeRepository.Get(model.MaterialInput.MaterialId);
            //if (materialType.IsBucket == "0")
            //{
            //    MaterialInput materialInput = _MaterialInputRepository.GetAll().Where(d => d.MaterialId == model.MaterialInput.MaterialId && d.StorageLocationId == model.MaterialInput.StorageLocationId).OrderByDescending(d => d.Batch).FirstOrDefault();
            //   if (materialInput.Batch == null)
            //   {
            //       materialInput.Batch = 1;
            //   }
            //    model.MaterialInput.Batch = materialInput.Batch++;
            //}
            model.MaterialInput.InputId = Guid.NewGuid().ToString();
            model.MaterialInput.Status = status;
            model.MaterialInput.CreateDate = DateTime.Now;
            model.MaterialInput.CreateUserNo = AppContext.CurrentUser.UserId;
            model.MaterialInput.CreateUserName = AppContext.CurrentUser.UserName;
            model.MaterialInput.Stationcode = AppContext.CurrentUser.ProjectCode;
            this._MaterialInputRepository.Create(model.MaterialInput);
            return model.MaterialInput;
        }
        /// <summary>
        /// 确认时存入入库表
        /// </summary>
        /// <param name="model"></param>
        private MaterialInput MaterialInput(MaterialInputVM model, string status)
        {
            model.MaterialInput.InputId = Guid.NewGuid().ToString();
            model.MaterialInput.Status = status;
            model.MaterialInput.CreateDate = DateTime.Now;
            model.MaterialInput.CreateUserNo = AppContext.CurrentUser.UserId;
            model.MaterialInput.CreateUserName = AppContext.CurrentUser.UserName;
            model.MaterialInput.Stationcode = AppContext.CurrentUser.ProjectCode;
            model.MaterialInput.ConfirmDate = DateTime.Now;
            model.MaterialInput.ConfirmUserNo = AppContext.CurrentUser.UserId;
            model.MaterialInput.ConfirmUserName = AppContext.CurrentUser.UserName;
            this._MaterialInputRepository.Create(model.MaterialInput);
            return model.MaterialInput;
        }
        /// <summary>
        /// 在材料库存信息存入数据
        /// </summary>
        /// <param name="model"></param>
        private void NuclearMStock(MaterialInputVM model, Nullable<double> amount, string hidBucketCodeType)
        {
            NuclearMStock nuclearMStock = new NuclearMStock();
            if (string.IsNullOrEmpty(hidBucketCodeType))
            {
                if (model.MaterialInput.EffectDate < DateTime.Now)
                {
                    nuclearMStock.OverrideAmount = amount;
                }
            }
            nuclearMStock.StockId = Guid.NewGuid().ToString();
            nuclearMStock.MaterialId = model.MaterialInput.MaterialId;
            nuclearMStock.LocationId = model.MaterialInput.StorageLocationId;
            nuclearMStock.Stationcode = AppContext.CurrentUser.ProjectCode;
            nuclearMStock.Amount = amount;
            ///
            nuclearMStock.InputId = model.MaterialInput.InputId;
            this._NuclearMStockRepository.Create(nuclearMStock);
        }
        /// <summary>
        /// 在桶位置编号表明细存入数据
        /// </summary>
        /// <param name="materialInput"></param>
        /// <param name="nuclearBucket"></param>
        private void NuclearBucketChange(string inputId, NuclearBucket nuclearBucket)
        {
            NuclearBucketChange nuclearBucketChange = new NuclearBucketChange();
            nuclearBucketChange.Detailid = Guid.NewGuid().ToString();
            nuclearBucketChange.ChangeType = "INPUT";
            nuclearBucketChange.BusinessId = inputId;
            nuclearBucketChange.BucketId = nuclearBucket.BucketId;
            this._NuclearBucketChangeRepository.Create(nuclearBucketChange);
        }
        /// <summary>
        /// 在桶信息表里存入数据
        /// </summary>
        /// <param name="model"></param>
        /// <param name="materialType"></param>
        /// <param name="bucketCode"></param>
        /// <returns></returns>
        private NuclearBucket NuclearBucke(MaterialInputVM model, string bucketCode,string status)
        {
            NuclearBucket nuclearBucket = new NuclearBucket();
            nuclearBucket.BucketId = Guid.NewGuid().ToString();
            nuclearBucket.MaterialId = model.MaterialInput.MaterialId;
            nuclearBucket.BucketCode = bucketCode;
            nuclearBucket.LocationId = model.MaterialInput.StorageLocationId;
            nuclearBucket.Status = status;
            nuclearBucket.IsDrain = "0";
            nuclearBucket.Stationcode = AppContext.CurrentUser.ProjectCode;
            this._NuclearBucketRepository.Create(nuclearBucket);
            return nuclearBucket;
        }
      
        /// <summary>
        /// 往桶信息和明细信息插入数据
        /// </summary>
        /// <param name="model"></param>
        /// <param name="materialType"></param>
        /// <param name="inputId"></param>
        /// <returns></returns>
        private string BucketAndChange(MaterialInputVM model, string inputId,string status,string isSure,string submit)
        {
            string[] arrayAllCode = null;
            string[] arrayCode = null;
            string[] arrayBucketCode = null;
            arrayAllCode = model.hidBucketCodeType.Trim(new char[] { ';' }).Split(new char[] { ';' });
            foreach (var code in arrayAllCode)
            {
                string bucketCode = string.Empty;
                arrayCode = code.Trim(new char[] { ',' }).Split(new char[] { ',' });
                if (arrayCode.Length == 3)
                {
                    int startBucketCode = Convert.ToInt32(arrayCode[1]);
                    int endBucketCode = Convert.ToInt32(arrayCode[2]);
                    if (startBucketCode == endBucketCode)
                    {
                        bucketCode = arrayCode[0] + arrayCode[1];
                    }
                    else
                    {
                        for (int i = startBucketCode; i <= endBucketCode; i++)
                        {
                            bucketCode = bucketCode + arrayCode[0] + i.ToString().PadLeft(arrayCode[2].Length, '0') + ",";
                        }
                    }
                    

                }
                else if (arrayCode.Length == 2)
                {
                     bucketCode = arrayCode[0] + arrayCode[1];
                }
                else if (arrayCode.Length == 1)
                {
                     bucketCode = arrayCode[0];
                }
               

                arrayBucketCode = bucketCode.Trim(new char[] { ',' }).Split(new char[] { ',' });
                foreach (var itemBucketCode in arrayBucketCode)
                {
                    
                    if (isSure != "sure")
                    {
                        if (!string.IsNullOrEmpty(model.MaterialInput.InputId))
                        {
                            if (string.IsNullOrEmpty(submit))
                            {
                                //判断桶号是否重复
                                IQueryable<NuclearBucket> data = _NuclearBucketRepository.GetAll().AsQueryable().Where(s => s.BucketCode == itemBucketCode).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                                if (data.Count() > 0)
                                {
                                    return itemBucketCode;
                                }
                            }
                          
                        }
                    }
                


                    //在桶信息表里存入数据
                    try
                    {
                        NuclearBucket nuclearBucket = NuclearBucke(model, itemBucketCode, status);

                        //在桶位置编号表明细存入数据
                        NuclearBucketChange(inputId, nuclearBucket);
                    }
                    catch
                    {
                        continue;
                    }  
                }  
            }
            return null;
        }
        /// <summary>
        /// 材料草稿保存
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveDraft(MaterialInputVM model, FormCollection formCollection)
        {

            //if (!ModelState.IsValid)
            //{
            //    return Json("{\"result\":false,\"msg\":\"未通过验证\"}", JsonRequestBehavior.AllowGet);
            //}
            try
            {
                this.SaveAttachFile(model.MaterialInput.InputId, "UploadOther", formCollection);
                //新增保存
                if (string.IsNullOrEmpty(model.MaterialInput.InputId))
                {
                    //在入库表里存入数据
                    MaterialInput materialInput = MaterialInputSingle(model, "0");
                    //桶
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                       //往桶和明细表插入数据
                       string bucketCode = BucketAndChange(model, materialInput.InputId,"0","","");
                       if (!string.IsNullOrEmpty(bucketCode))
                       {
                           return Json("{\"result\":false,\"msg\":\"" + "桶号 " + bucketCode + " 已存在" + "\"}", JsonRequestBehavior.AllowGet);
                       }
                    }
                    this._MaterialInputRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改保存
                else
                {
                    //根据入库ID查询
                    IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(model.MaterialInput.InputId);
                    if (dataBucketChange.Count() > 0)
                    {
                        foreach (var itemChange in dataBucketChange)
                        {   //删除材料位置明细表
                            _NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                            //删除桶信息表
                            _NuclearBucketRepository.DeleteById(itemChange.BucketId);
                        }
                    }
                    
                    model.MaterialInput=_MaterialInputRepository.Get(model.MaterialInput.InputId);
                    //如果之前的确认了要减去数据
                    if (model.MaterialInput.Status == "2")
                    {
                        MinusMstock(model);
                    }
                    UpdateModel(model);
                    model.MaterialInput.Status = "0";
                    this._MaterialInputRepository.Update(model.MaterialInput);
                    //桶
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //往桶和明细表插入数据
                        string bucketCode = BucketAndChange(model, model.MaterialInput.InputId, "0", "", "submit");
                        if (!string.IsNullOrEmpty(bucketCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"" + "桶号 " + bucketCode + " 已存在" + "\"}", JsonRequestBehavior.AllowGet);
                        }
                       
                    }
                    this._MaterialInputRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }

               
            }
            catch 
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
       }

        private void MinusMstock(MaterialInputVM model)
        {
            IQueryable<NuclearMStock> dataMStockafter = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialInput.MaterialId, model.MaterialInput.StorageLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //材料表里已经存在,只更新数量
            if (dataMStockafter.Count() > 0)
            {
                List<NuclearMStock> materialStockList = dataMStockafter.ToList();
                foreach (var item in materialStockList)
                {

                    item.Amount = item.Amount - model.MaterialInput.Amount;
                    this._NuclearMStockRepository.Update(item);
                }
            }
        }
        /// <summary>
        /// 材料增加提交
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult CommitMaterial(MaterialInputVM model, FormCollection formCollection)
        {
            //if (!ModelState.IsValid)
            //{
            //    return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            //}

            try
            {
                this.SaveAttachFile(model.MaterialInput.InputId, "UploadOther", formCollection);
                //新增保存
                if (string.IsNullOrEmpty(model.MaterialInput.InputId))
                {
                    //在入库表里存入数据
                    MaterialInput materialInput = MaterialInputSingle(model, "1");
                    //桶
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                       //往桶和明细表插入数据
                       string bucketCode = BucketAndChange(model, materialInput.InputId,"1","","");
                       if (!string.IsNullOrEmpty(bucketCode))
                       {
                           return Json("{\"result\":false,\"msg\":\"" + "桶号 " + bucketCode + " 已存在" + "\"}", JsonRequestBehavior.AllowGet);
                       }
                    }
                    this._MaterialInputRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }//修改保存
                else
                {
                    //根据入库ID查询
                    IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(model.MaterialInput.InputId);
                    if (dataBucketChange.Count() > 0)
                    {
                        foreach (var itemChange in dataBucketChange)
                        {   //删除材料位置明细表
                            this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                            //删除桶信息表
                            this._NuclearBucketRepository.DeleteById(itemChange.BucketId);
                        }
                    }                 
                    model.MaterialInput=_MaterialInputRepository.Get(model.MaterialInput.InputId);
                    //如果之前的确认了要减去数据
                    if (model.MaterialInput.Status == "2")
                    {

                        MinusMstock(model);
                    }

                    UpdateModel(model);
                    model.MaterialInput.Status = "1";
                    this._MaterialInputRepository.Update(model.MaterialInput);
                    //桶
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //往桶和明细表插入数据
                        string bucketCode = BucketAndChange(model, model.MaterialInput.InputId, "1", "", "submit");
                        if (!string.IsNullOrEmpty(bucketCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"" + "桶号 " + bucketCode + " 已存在" + "\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                    this._MaterialInputRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);

                }
            }
            catch 
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 材料确认新增
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "材料入库确认")]
        public JsonResult MaterialConvince(MaterialInputVM model, FormCollection formCollection)
        {
            //if (!ModelState.IsValid)
            //{
            //    return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            //}
            try
            {
                this.SaveAttachFile(model.MaterialInput.InputId, "UploadOther", formCollection);
                MaterialInput materialInput = MaterialInput(model, "2");
                //桶
                if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                {
                    //往桶和明细表插入数据
                    string bucketCode = BucketAndChange(model, materialInput.InputId, "2","","");
                    if (!string.IsNullOrEmpty(bucketCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"" + "桶号 " + bucketCode + " 已存在" + "\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                //判断材料表里是否存在并存入数据
                UpdateNuclearMStock(model, model.hidBucketCodeType);
                this._MaterialInputRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 判断材料表里是否存在并存入数据
        /// </summary>
        /// <param name="model"></param>
        private void UpdateNuclearMStock(MaterialInputVM model, string hidBucketCodeType)
        {

            if (string.IsNullOrEmpty(hidBucketCodeType))
            {
                NuclearMStock(model, model.MaterialInput.Amount, hidBucketCodeType);
            }
            else {
                IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialInput.MaterialId, model.MaterialInput.StorageLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                // 材料表里已经存在,只更新数量
                if (dataMStock.Count() > 0)
                {
                    List<NuclearMStock> materialStockList = dataMStock.ToList();
                    foreach (var item in materialStockList)
                    {
                        if (string.IsNullOrEmpty(hidBucketCodeType))
                        {
                            //过期数量
                            if (model.MaterialInput.EffectDate < DateTime.Now)
                            {
                                item.OverrideAmount = (item.OverrideAmount == null ? 0 : item.OverrideAmount) + model.MaterialInput.Amount;
                            }
                        }
                        item.Amount = item.Amount + model.MaterialInput.Amount;
                        this._NuclearMStockRepository.Update(item);
                    }
                }//材料表里不存在,新建一条
                else
                {
                    //在材料库存信息存入数据
                    NuclearMStock(model, model.MaterialInput.Amount, hidBucketCodeType);
                }
            }
            //IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialInput.MaterialId, model.MaterialInput.StorageLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //if (string.IsNullOrEmpty(hidBucketCodeType))
            //{
            //    if (dataMStock.Count() > 0)
            //    {
            //        List<NuclearMStock> materialStockList = dataMStock.ToList();
            //        foreach (var item in materialStockList)
            //        {
            //            if (string.IsNullOrEmpty(hidBucketCodeType))
            //            {
            //                //过期数量
            //                if (model.MaterialInput.EffectDate < DateTime.Now)
            //                {
            //                    item.OverrideAmount = (item.OverrideAmount == null ? 0 : item.OverrideAmount) + model.MaterialInput.Amount;
            //                }
            //            }
            //            item.Amount = item.Amount + model.MaterialInput.Amount;
            //            this._NuclearMStockRepository.Update(item);
            //        }
            //    }
            //}
            //else
            //{
            //    //材料表里已经存在,只更新数量
            //    if (dataMStock.Count() > 0)
            //    {
            //        List<NuclearMStock> materialStockList = dataMStock.ToList();
            //        foreach (var item in materialStockList)
            //        {
            //            if (string.IsNullOrEmpty(hidBucketCodeType))
            //            {
            //                //过期数量
            //                if (model.MaterialInput.EffectDate < DateTime.Now)
            //                {
            //                    item.OverrideAmount = (item.OverrideAmount == null ? 0 : item.OverrideAmount) + model.MaterialInput.Amount;
            //                }
            //            }
            //            item.Amount = item.Amount + model.MaterialInput.Amount;
            //            this._NuclearMStockRepository.Update(item);
            //        }
            //    }//材料表里不存在,新建一条
            //    else
            //    {
            //        //在材料库存信息存入数据
            //        NuclearMStock(model, model.MaterialInput.Amount, hidBucketCodeType);
            //    }
            //}
           
        }
        /// <summary>
        /// 材料确认修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        private string storageLocationId = null;
        private double? amountBfore = 0;

        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "材料入库确认")]
        public JsonResult MaterialConvinceUpdate(MaterialInputVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }
             
            try
            {
               
                this.SaveAttachFile(model.MaterialInput.InputId, "UploadOther", formCollection);
                //根据ID查询入库表
                model.MaterialInput = _MaterialInputRepository.Get(model.MaterialInput.InputId);
                storageLocationId = model.MaterialInput.StorageLocationId;
                amountBfore = model.MaterialInput.Amount;
                //状态是已确认
                if (model.MaterialInput.Status.Equals("2"))
                {
                    //桶
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //更新入库表
                        UpdateModel(model);
                        //修改页面中存入库表
                        UpdateModelMaterial(model);
                        //查询数据库桶信息
                        IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().Where(d => d.BusinessId == model.MaterialInput.InputId).AsQueryable();
                        List<string> nuclearBucketStrList = new List<string>();
                        foreach (var itemChage in nuclearBucketChange)
                        {
                            NuclearBucket nuclearBucket = new NuclearBucket();
                           
                            nuclearBucket = _NuclearBucketRepository.Get(itemChage.BucketId);
                            nuclearBucket.LocationId = model.MaterialInput.StorageLocationId;
                            this._NuclearBucketRepository.Update(nuclearBucket);
                            nuclearBucketStrList.Add(nuclearBucket.BucketCode);
                        }
                        //页面中传过来的数组
                        string[] arrBucketAllCode = model.hidBucketCodeType.Trim(new char[] { ';' }).Split(new char[] { ';' }); ;
                        //数据库中桶号的数组
                        string[] arrFromDataBase = nuclearBucketStrList.ToArray();

                        //求交集
                        string[] sameArr = arrBucketAllCode.Intersect(arrFromDataBase).ToArray();
                        string[] difArr = arrFromDataBase.Except(sameArr).ToArray();
                        //交集
                        foreach (var itemdifArr in difArr)
                        {
                            IQueryable<NuclearBucket> data = _NuclearBucketRepository.GetAll().Where(s => s.BucketCode == itemdifArr).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
                            List<NuclearBucket> dataList = data.ToList();
                            if (dataList.Count() > 0)
                            {
                                foreach (var item in dataList)
                                {
                                    item.MaterialId = model.MaterialInput.MaterialId;
                                    item.LocationId = model.MaterialInput.StorageLocationId;
                                    this._NuclearBucketRepository.Update(item);

                                }
                            }
                        }
                        //删除页面中减少的数据
                        foreach (var itemdifArr in difArr)
                        {
                            List<NuclearBucket> data = _NuclearBucketRepository.GetAll().Where(s => s.BucketCode == itemdifArr).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                            if (data.Count() > 0)
                            {
                                IQueryable<NuclearBucketChange> dataChangess = this._NuclearBucketChangeRepository.GetAll().Where(s => s.BucketId == data[0].BucketId && s.ChangeType == "TRANSFER").AsQueryable();
                                if (dataChangess.Count() > 0)
                                {
                                    return Json("{\"result\":false,\"msg\":\"桶号已被转运,请先处理转运桶号。\"}", JsonRequestBehavior.AllowGet);
                                }
                                if (data[0].IsDrain =="1")
                                {
                                    return Json("{\"result\":false,\"msg\":\"桶号已已被消耗,请先处理消耗桶号。\"}", JsonRequestBehavior.AllowGet);
                                }
                                this._NuclearBucketRepository.DeleteById(data[0].BucketId);
                                List<NuclearBucketChange> dataChange = this._NuclearBucketChangeRepository.GetAll().Where(s => s.BucketId == data[0].BucketId && s.ChangeType == "INPUT").ToList();
                                if (dataChange.Count() > 0)
                                {
                                    this._NuclearBucketChangeRepository.DeleteById(dataChange[0].Detailid);
                                }
                            }
                        }



                        //增加页面中添加的数据
                        foreach (var bucketCode in arrBucketAllCode)
                        {
                           
                            IQueryable<NuclearBucket> data = _NuclearBucketRepository.GetAll().AsQueryable().Where(s => s.BucketCode == bucketCode).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                            if (data.Count() == 0)
                            {
                                NuclearBucket nuclearBucket = NuclearBucke(model, bucketCode, "2");
                                //在桶位置编号表明细存入数据
                                NuclearBucketChange(model.MaterialInput.InputId, nuclearBucket);
                            }
                        }
                  }
                    IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialInput.MaterialId, model.MaterialInput.StorageLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                    List<NuclearMStock> dataMStockList = dataMStock.ToList();
                    foreach (var itemMStock in dataMStockList)
                    {   //减去之前存入的数据
                        itemMStock.Amount = itemMStock.Amount - amountBfore;
                        if (model.MaterialInput.EffectDate < DateTime.Now)
                        {
                            itemMStock.OverrideAmount = itemMStock.OverrideAmount - amountBfore;
                        }
                        this._NuclearMStockRepository.Update(itemMStock);
                    }
                    //修改存储地点后数据变化
                    if (model.MaterialInput.StorageLocationId != storageLocationId)
                    {
                        IQueryable<NuclearMStock> dataMStockb = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialInput.MaterialId, model.MaterialInput.StorageLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                        List<NuclearMStock> dataMStockListb = dataMStock.ToList();
                        foreach (var itemMStock in dataMStockListb)
                        {  
                            itemMStock.Amount = itemMStock.Amount + model.MaterialInput.Amount;
                           
                            this._NuclearMStockRepository.Update(itemMStock);
                        }

                        IQueryable<NuclearMStock> dataMStocks = _NuclearMStockRepository.QueryListByMLocationId(model.MaterialInput.MaterialId, storageLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                        List<NuclearMStock> dataMStockLists= dataMStock.ToList();
                        foreach (var itemMStock in dataMStockLists)
                        {   //减去之前存入的数据
                            itemMStock.Amount = itemMStock.Amount - model.MaterialInput.Amount;

                            this._NuclearMStockRepository.Update(itemMStock);
                        }
                    
                    }
                    //更新入库表
                    UpdateModel(model);
                    //判断材料表里是否存在并存入数据
                    UpdateNuclearMStock(model, model.hidBucketCodeType);
                }//状态未确认
                else
                {
                    //更新入库表
                    UpdateModel(model);
                    //修改页面中存入库表
                    UpdateModelMaterial(model);
                    //如果之前是桶,删除明细表数据和桶数据
                    DeleteBucketAndChange(model);
                    this._MaterialInputRepository.UnitOfWork.Commit();
                    //桶
                    if (!string.IsNullOrEmpty(model.hidBucketCodeType))
                    {
                        //往桶和明细表插入数据
                        string bucketCode = BucketAndChange(model, model.MaterialInput.InputId, "2","","");
                        if (!string.IsNullOrEmpty(bucketCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"" + "桶号 " + bucketCode + " 已存在" + "\"}", JsonRequestBehavior.AllowGet);
                        }
                    }

                    //判断材料表里是否存在并存入数据
                    UpdateNuclearMStock(model, model.hidBucketCodeType);
                }
                this._MaterialInputRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);


            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 如果之前是桶,删除明细表数据和桶数据
        /// </summary>
        /// <param name="model"></param>
        private void DeleteBucketAndChange(MaterialInputVM model)
        {
            IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(model.MaterialInput.InputId);
            if (dataBucketChange.Count() > 0)
            {
                foreach (var itemChange in dataBucketChange)
                {   //删除材料位置明细表
                    this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                    //删除桶信息表
                    this._NuclearBucketRepository.DeleteById(itemChange.BucketId);
                }

            }
        }
       
        /// <summary>
        /// 修改页面中存入库表
        /// </summary>
        /// <param name="model"></param>
        private void UpdateModelMaterial(MaterialInputVM model)
        {
            model.MaterialInput.Status = "2";
            model.MaterialInput.ConfirmDate = DateTime.Now;
            model.MaterialInput.ConfirmUserNo = AppContext.CurrentUser.UserId;
            model.MaterialInput.ConfirmUserName = AppContext.CurrentUser.UserName;
            model.MaterialInput.Stationcode = AppContext.CurrentUser.ProjectCode;
            this._MaterialInputRepository.Update(model.MaterialInput);
        }
        

        /// <summary>
        /// 初始化查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetMaterialInputList(MaterialInputCondition materialInputCondition, string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            //List<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode.Trim().ToUpper().Contains(materialInputCondition.BucketCode.ToUpper().Trim()))).Where(d=>d.Stationcode==AppContext.CurrentUser.ProjectCode).FirstOrDefault();
            //if (nuclearBucket != null)
            //{
            //    NuclearBucketChange nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().Where(d => d.BucketId == nuclearBucket.BucketId).FirstOrDefault();
            //    if (nuclearBucketChange != null)
            //    {
            //        materialInputCondition.InputId = nuclearBucketChange.BusinessId;
            //    }

            //}
            //else
            //{
            //    if (!string.IsNullOrEmpty(materialInputCondition.BucketCode))
            //    {
            //        materialInputCondition.InputId = "null";
            //    }

            //}

            IQueryable<MaterialInputView> dataEvery = this._MaterialInputRepository.QueryList(materialInputCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            if (!string.IsNullOrEmpty(materialInputCondition.BucketCode))
            {
                IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(d => d.BucketCode.Trim().ToUpper().Contains(materialInputCondition.BucketCode.Trim().ToUpper())).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);

                IQueryable<NuclearBucketChange> nuclearBucketChange = _NuclearBucketChangeRepository.GetAll().AsQueryable().Where(d => d.ChangeType == "INPUT");
                nuclearBucketChange = (from i in nuclearBucketChange
                                       join s in nuclearBucket
                                       on i.BucketId equals s.BucketId
                                       select i).Distinct();

                dataEvery = (from i in dataEvery
                             join s in nuclearBucketChange
                             on i.InputId equals s.BusinessId
                             select i).Distinct().OrderBy("CreateDate", SortDirection.Descending).OrderBy("Status", SortDirection.Ascending);

            }
            else
            {
                dataEvery = this._MaterialInputRepository.QueryList(materialInputCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderBy("CreateDate", SortDirection.Descending).OrderBy("Status", SortDirection.Ascending);
            }
     

            //IQueryable<MaterialInputView> data = this._MaterialInputRepository.QueryList(materialInputCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderBy("CreateDate", SortDirection.Descending);
            var pagedViewModel = new PagedViewModel<MaterialInputView>
            {
                Query = dataEvery,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.InputId,
                    List = new List<object>() {                      
                        d.InputId,
                        d.MaterialName,
                        d.MaterialSpec,
                        d.ProductDate.HasValue? d.ProductDate.Value.ToString("yyyy-MM-dd"):"",
                        d.InputDate.HasValue? d.InputDate.Value.ToString("yyyy-MM-dd"):"",
                        d.EffectDate.HasValue? d.EffectDate.Value.ToString("yyyy-MM-dd"):"",
                        d.Amount,
                        d.UnitName,
                        d.StorageLocation,
                        d.BatchCode,
                        d.Status
                       
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 删除材料
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                   
                    foreach (string idVal in idArr)
                    {
                        this._MaterialInputRepository.DeleteById(idVal);
                        //根据ID查询入库表
                        MaterialInput materialInput = _MaterialInputRepository.Get(idVal);
                        //状态是确认的删除
                        if (materialInput.Status.Equals("2"))
                        {
                            //判断是否被其他环节引用
                            IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(materialInput.InputId);
                            if (dataBucketChange.Count() > 0)
                            {
                                foreach (var itemChange in dataBucketChange)
                                {

                                    IQueryable<NuclearBucketChange> dataChangess = this._NuclearBucketChangeRepository.GetAll().Where(s => s.BucketId == itemChange.BucketId && s.ChangeType == "TRANSFER").AsQueryable();
                                    if (dataChangess.Count() > 0)
                                    {
                                        return Json("{\"result\":false,\"msg\":\"桶号已被转运,请先处理转运桶号。\"}", JsonRequestBehavior.AllowGet);
                                    }
                                    NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(itemChange.BucketId);
                                    if (nuclearBucket != null)
                                    {
                                        if (nuclearBucket.IsDrain == "1")
                                        {
                                            return Json("{\"result\":false,\"msg\":\"桶号已已被消耗,请先处理消耗桶号。\"}", JsonRequestBehavior.AllowGet);
                                        }
                                    }
                                    
                                  
                                }

                            }
                           

                            //删除
                            if (dataBucketChange.Count() > 0)
                            {
                                foreach (var itemChange in dataBucketChange)
                                {   //删除材料位置明细表
                                    this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                                    //删除桶信息表
                                    this._NuclearBucketRepository.DeleteById(itemChange.BucketId);
                                }

                            }
                            if (string.IsNullOrEmpty(materialInput.BatchCode))
                            {
                                IQueryable<NuclearMStock> dataMStock = _NuclearMStockRepository.QueryListByMLocationId(materialInput.MaterialId, materialInput.StorageLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                                List<NuclearMStock> dataMStockList = dataMStock.ToList();
                                foreach (var itemMStock in dataMStockList)
                                {   //减去之前存入的数据
                                    itemMStock.Amount = itemMStock.Amount - materialInput.Amount;
                                    this._NuclearMStockRepository.Update(itemMStock);
                                }
                            }
                            else
                            {
                                NuclearMStock dataMStock = _NuclearMStockRepository.QueryListByMLocationId(materialInput.MaterialId, materialInput.StorageLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode && d.InputId == materialInput.InputId).FirstOrDefault();
                                dataMStock.Amount = dataMStock.Amount - materialInput.Amount;
                                this._NuclearMStockRepository.Update(dataMStock);
                            }
                           

                        }//状态是草稿跟已提交的删除
                        else
                        {
                            IQueryable<NuclearBucketChange> dataBucketChange = _NuclearBucketChangeRepository.QueryListByBusinessId(materialInput.InputId);
                            if (dataBucketChange.Count() > 0)
                            {
                                foreach (var itemChange in dataBucketChange)
                                {   //删除材料位置明细表
                                    this._NuclearBucketChangeRepository.DeleteById(itemChange.Detailid);
                                    //删除桶信息表
                                    this._NuclearBucketRepository.DeleteById(itemChange.BucketId);
                                }

                            }
                        }

                    }
                    this._MaterialInputRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }
        
    }
}
