﻿using System;
using CIT.App.Lib.PlanTask.Client;
using CIT.UPC.Authorization.Client;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Practices.ServiceLocation;
using NET01.CoreFramework.Mail;
using System.Configuration;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using MvcContrib.Sorting;
using NET01.CoreFramework;

namespace CIT.App.Lib.PlanTaskClient
{
    public class MyPlanTask : IPlanTask
    {
        #region IPlanTask 成员

        /// <summary>
        /// 执行
        /// </summary>
        /// <param name="context"></param>
        public void Execute(ExecuteContext context)
        {

            //-----------执行具体的业务START-------------------------------
            try {
                //提醒快到期的库存材料
                RemindOverideDate();
                //低于最低库存每周提醒
                RemindMstock();
            }
            catch { }

            //-----------执行具体的业务END---------------------------------

            //反馈执行结果
            context.Result = true;
            context.ResultDescription = "执行成功";
        }

        #endregion

        #region 定时提醒任务
        /// <summary>
        /// 提醒快到期材料
        /// </summary>
        public void RemindOverideDate()
        {
            var systemAddress = ConfigurationManager.AppSettings["SystemAddress"];
            //实例化邮件父类
            ISmtpClient smtpClent = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<ISmtpClient>();
            var mailService = new RWIS.Application.Implementation.MailService(smtpClent);

            //提前一个月提醒
            DateTime compareDate30 = Convert.ToDateTime(DateTime.Now.AddDays(30).ToLongDateString());
            DateTime compareDate15 = Convert.ToDateTime(DateTime.Now.AddDays(15).ToLongDateString());
            DateTime compareDate1 = Convert.ToDateTime(DateTime.Now.AddDays(1).ToLongDateString());
            DateTime compareDate = Convert.ToDateTime(DateTime.Now.ToLongDateString());
            //提前一个月提醒
            List<MaterialInputView> materialInput30 = GetRemindMaterialInputList(compareDate30);
            //提前15月提醒
            List<MaterialInputView> materialInput15 = GetRemindMaterialInputList(compareDate15);
            //提前1提醒
            List<MaterialInputView> materialInput1 = GetRemindMaterialInputList(compareDate1);
            //今天到期
            List<MaterialInputView> materialInput = GetRemindMaterialInputList(compareDate);

            if (materialInput30.Count > 0)
            {
                SendAllFactoryOverrideEmail(materialInput30, "compareDate30");
            }
            if (materialInput15.Count > 0)
            {
                SendAllFactoryOverrideEmail(materialInput15, "compareDate15");
            }
            if (materialInput1.Count > 0)
            {
                SendAllFactoryOverrideEmail(materialInput1, "compareDate1");
            }
            if (materialInput.Count > 0)
            {
                Override(materialInput);
            }

        }
        /// <summary>
        /// 过期数量
        /// </summary>
        /// <param name="materialInput"></param>
        public void Override(List<MaterialInputView> materialInput)
        {
            INuclearMStockRepository _NuclearMStockRepository = ServiceLocator.Current.GetInstance<INuclearMStockRepository>();
            foreach (var itemInput in materialInput)
            {
                IQueryable<NuclearMStock> dataMStockafter = _NuclearMStockRepository.QueryListByMLocationId(itemInput.MaterialId, itemInput.StorageLocationId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
                //材料表里已经存在,只更新数量
                if (dataMStockafter.Count() > 0)
                {
                    List<NuclearMStock> materialStockList = dataMStockafter.ToList();
                    foreach (var item in materialStockList)
                    {
                        if (itemInput.EffectDate == Convert.ToDateTime(DateTime.Now.ToLongDateString()))
                        {
                            item.OverrideAmount = item.OverrideAmount+itemInput.Amount;
                        }
                        _NuclearMStockRepository.Update(item);
                    }
                }
            }
            _NuclearMStockRepository.UnitOfWork.Commit();
        }
        /// <summary>
        /// 低于最低库存每周提醒
        /// </summary>
        public void RemindMstock()
        {
            //实例化入库仓储
            IMaterialTypeRepository _MaterialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
            INuclearMStockRepository _NuclearMStockRepository = ServiceLocator.Current.GetInstance<INuclearMStockRepository>();
            IMaterialInputRepository _MaterialInputRepository = ServiceLocator.Current.GetInstance<IMaterialInputRepository>();
            IBasicObjectRepository _BasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            var systemAddress = ConfigurationManager.AppSettings["SystemAddress"];
            //从数据库取出所有材料ID和材料名
            List<MaterialType> mterialTypeList = _MaterialTypeRepository.GetAll().Where(d=>d.Status=="2"&&d.Stationcode==AppContext.CurrentUser.ProjectCode).ToList();
            foreach (var item in mterialTypeList)
            { 
                List<NuclearMStock> nuclearMStock = _NuclearMStockRepository.GetAll().Where(d => d.MaterialId == item.MaterialId).ToList();
                Nullable<double> amout = 0;
                foreach (var itemStock in nuclearMStock)
                {

                    amout = amout + itemStock.Amount;
                }

                if (amout < item.MinStock)
                {
                    if (DateTime.Now.DayOfWeek.ToString().Equals("Monday"))
                    {
                        List<MaterialInput> materialInput = _MaterialInputRepository.GetAll().OrderBy("CreateDate", SortDirection.Descending).ToList();
                        
                        if (materialInput.Count() > 0)
                        {
                            BasicObject basicObject = _BasicObjectRepository.Get(materialInput[0].StorageLocationId);
                            if (basicObject != null)
                            {
                                string copyUsers = string.Empty;// "P479003" + "," + "PCITZLG" + "," + "P120624";
                                NET01.CoreFramework.Mail.ISmtpClient smtpClent = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<NET01.CoreFramework.Mail.ISmtpClient>();
                                var mailService = new RWIS.Application.Implementation.MailService(smtpClent);
                                string sendTitle = string.Format("当前库存低于最低库存");
                                string sendContent = " &nbsp;" + "您好！" + "</br>" + " &nbsp;&nbsp;" + "<span style='font-size:10.5pt;color:#FF0000'>" + basicObject.Name + "</span>" + "仓库中" + "<span style='font-size:10.5pt;color:#FF0000'>" + item.MaterialName + "</span>" + "当前的库存数量是：" + "<span style='font-size:10.5pt;color:#FF0000'>" + amout + "</span>" + "，" + "低于最低最低库量：" + "<span style='font-size:10.5pt;color:#FF0000'>" + (decimal)item.MinStock + "</span>" + "，" + "当前库存低于最低库存,请点击" + "<a href=" + systemAddress + ">材料入库</a>" + "进入系统及时补充材料" + "。";
                                mailService.SendMailService(materialInput[0].ReceiveUserNo, copyUsers, sendTitle, sendContent);
                            }

                        }

                    }
                   
                
                }
            }

        }

        /// <summary>
        /// 根据查询条件得到正确提醒的暂存数据
        /// </summary>
        /// <param name="compareDate"></param>
        /// <returns></returns>
        /// 
        private List<MaterialInputView> GetRemindMaterialInputList(DateTime compareDate)
        {
            //实例化入库仓储
            IMaterialInputRepository _MaterialInputRepository = ServiceLocator.Current.GetInstance<IMaterialInputRepository>();

            IQueryable<MaterialInputView> iquerybleMaterialInput = _MaterialInputRepository.QueryListByReceive(compareDate);

            List<MaterialInputView> iquerybleMaterialInputList = iquerybleMaterialInput.ToList();
            return iquerybleMaterialInputList;
        }
       


        /// <summary>
        /// 提醒快到期的库存材料
        /// </summary>
        /// <param name="list"></param>
        private void SendAllFactoryOverrideEmail(List<MaterialInputView> list, string type)
        {
           
            if (list.Count > 0)
            {
                var systemAddress = ConfigurationManager.AppSettings["SystemAddress"];
                
                foreach (var item in list)
                {
                    string copyUsers = "P479003" + "," + "PCITZLG" + "," + "P120624";
                    NET01.CoreFramework.Mail.ISmtpClient smtpClent = Microsoft.Practices.ServiceLocation.ServiceLocator.Current.GetInstance<NET01.CoreFramework.Mail.ISmtpClient>();
                    var mailService = new RWIS.Application.Implementation.MailService(smtpClent);
                    string sendTitle = string.Format("材料即将到期提醒");
                    string sendContent = string.Empty;
                    if ("compareDate30".Equals(type))
                    {
                        sendContent = "你好!" + "</br>" + "&nbsp;" + "在" + item.StorageLocation + "仓库中" + "，" + "材料" + "（" + item.MaterialName + "）" + "还有<span style='font-size:10.5pt;color:#FF0000'>1</span>天过期" + "，" +"请点击"+ "<a href=" + systemAddress + ">查看</a>" + "进入系统及时处理材料" + "。";
                    }
                    if ("compareDate15".Equals(type))
                    {
                        sendContent = "你好!" + "</br>" + "&nbsp;" + "在" + item.StorageLocation + "仓库中" + "，" + "材料" + "（" + item.MaterialName + "）" + "还有<span style='font-size:10.5pt;color:#FF0000'>1</span>天过期" + "，" + "请点击" + "<a href=" + systemAddress + ">查看</a>" + "进入系统及时处理材料" + "。";
                    }
                    if ("compareDate1".Equals(type))
                    {
                        sendContent = "你好!" + "</br>" + "&nbsp;" + "在" + item.StorageLocation + "仓库中" + "，" + "材料" + "（" + item.MaterialName + "）" + "还有<span style='font-size:10.5pt;color:#FF0000'>1</span>天过期" + "，" + "请点击" + "<a href=" + systemAddress + ">查看</a>" + "进入系统及时处理材料" + "。";
                    }
                    if (!string.IsNullOrEmpty(item.ReceiveUserNo))
                    {
                        mailService.SendMailService(item.ReceiveUserNo, copyUsers, sendTitle, sendContent);
                    }
                   
                }
            }
        }

        #endregion


    }
}