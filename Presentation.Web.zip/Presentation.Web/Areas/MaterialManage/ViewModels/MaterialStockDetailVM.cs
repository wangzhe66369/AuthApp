﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
    public class MaterialStockDetailVM
    {

        /// <summary>
        /// 名字
        /// </summary>
        public string name { get; set; }
        /// <summary>
        ///页面
        /// </summary>
        public string index { get; set; }
        /// <summary>
        /// 位置
        /// </summary>
        public string align { get; set; }

        /// <summary>
        /// 是否隐藏
        /// </summary>
        public string hidden { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }
    }
}