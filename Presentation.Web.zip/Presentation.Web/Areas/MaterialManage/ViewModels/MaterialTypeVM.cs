﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
    public class MaterialTypeVM
    {
        /// <summary>
        /// 实体
        /// </summary>
        public MaterialType MaterialType { get; set; }

        /// <summary>
        /// 是否是桶
        /// </summary>
        public List<SelectListItem> RodiodList { get; set; }

        /// <summary>
        /// 桶类别 0：水泥桶 1：金属桶 2：不适合
        /// </summary>
        public List<SelectListItem> BucketTypeList { get; set; }

        /// <summary>
        /// 是否标准包装
        /// </summary>
        public List<SelectListItem> RodiodPackList { get; set; }
        /// <summary>
        /// 桶规格列表
        /// </summary>
        public List<SelectListItem> SpecList { get; set; }

        /// <summary>
        /// 单位列表
        /// </summary>
        public List<SelectListItem> UnitList { get; set; }

        /// <summary>
        /// 桶规格
        /// </summary>
        public string Spec { get; set; }

        /// <summary>
        /// 单位
        /// </summary>
        public string Unit { get; set; }

        //当前页面所有操作
        public string OperationList { get; set; }
    }
}