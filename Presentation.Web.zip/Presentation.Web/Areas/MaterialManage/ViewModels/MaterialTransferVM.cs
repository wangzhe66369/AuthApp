﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
    public class MaterialTransferVM
    {
        /// <summary>
        /// 材料转运实体
        /// </summary>
        public MaterialTransfer MaterialTransfer { get; set; }

        /// <summary>
        /// 材料转运明细
        /// </summary>
        public string NuclearBucketChanges { get; set; }

        /// <summary>
        /// 转运桶号类型
        /// </summary>
        public string hidBucketCodeType { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public List<NuclearBucket> materialTransferList { get; set; }
         /// <summary>
        /// 材料名称
        /// </summary>
        public string MaterialName { get; set; }
        /// <summary>
        /// 出库名称
        /// </summary>
        public string OutputLocationName { get; set; }
        /// <summary>
        ///转入库名称
        /// </summary>
        public string InputLocationName { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }
        /// <summary>
        ///单位
        /// </summary>
        public List<SelectListItem> UnitList { get; set; }
        /// <summary>
        /// 批次
        /// </summary>
        public List<SelectListItem> BatchCodeList { get; set; }
    }
}