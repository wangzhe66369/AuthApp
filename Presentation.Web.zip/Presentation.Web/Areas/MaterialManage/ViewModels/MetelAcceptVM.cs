﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;


namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
     public class MetelAcceptVM
    {
        //金属桶验收单实体
         public RWIS.Domain.DomainObjects.MetelAccept MetelAccept { get; set; }
        //金属桶验收单-详细 实体
        public MetelAcceptDetail MetelAcceptDetail { get; set; }
        //页面寄存器
        public string MetelBuckets { get; set; }
         /// <summary>
         /// 桶号
         /// </summary>
        public string BucketCode { get; set; }
         /// <summary>
         /// 附件
         /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> MetalAttachFiles { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }


    }
}