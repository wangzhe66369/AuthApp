﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;
namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
    public class BucketVM
    {
        public string MaterialName { get; set; }
        public NuclearBucket NuclearBucket { get; set; }
        public string LocationName { get; set; }
        public NuclearWastePackage NuclearWastePackage { get; set; }
    }
}