﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;

namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
    public class MaterialCheckVM
    {
        //当前页面所有操作
        public string OperationList { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public List<NuclearBucket> nuclearBucketList { get; set; }
        /// <summary>
        /// 过期桶号
        /// </summary>
        public List<NuclearBucket> nuclearOverrideList { get; set; }
        /// <summary>
        /// 批次号跟有效日期
        /// </summary>
        public List<MaterialInput> materialInputList { get; set; }
       
       
    }
   
}