﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;


namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
    public class SolidAcceptVM
    {
        //水泥桶验收单 实体
        public RWIS.Domain.DomainObjects.SolidAccept SolidAccept { get; set; }
        //水泥桶验收单-详细  实体
        public RWIS.Domain.DomainObjects.SolidAcceptDetail SolidAcceptDetail { get; set; }
        //页面寄存器
        public string SolidBuckets { get; set; }

        /// <summary>
        /// 存放地点
        /// </summary>
        public List<SelectListItem> InputLocationIdList { get; set; }
        /// <summary>
        /// 验收材料
        /// </summary>
        public List<SelectListItem> MaterialList { get; set; }

        public RWIS.Domain.DomainObjects.SolidAccept InputLocation { get; set; }
        /// <summary>
        /// 地点名称
        /// </summary>
        public string LocationName { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> SolidAttachFiles { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }

    }
}
