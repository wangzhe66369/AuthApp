﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
    public class BucketInfoVM
    {
        /// <summary>
        /// 桶类型列表
        /// </summary>
        public List<SelectListItem> BucketTypeList { get; set; }
        /// <summary>
        /// 桶状态列表
        /// </summary>
        public List<SelectListItem> BucketStatusList { get; set; }
        /// <summary>
        /// 存放地点列表
        /// </summary>
        public List<SelectListItem> BucketLocationList { get; set; }

        /// <summary>
        /// 处置状态列表
        /// </summary>
        public List<SelectListItem> StatusList { get; set; }

        /// <summary>
        /// 单条桶信息
        /// </summary>
        public NuclearBucket BucketInfoDetail { get; set; }
        /// <summary>
        /// 单条入库信息
        /// </summary>
        public MaterialInput BucketInfoInputDetail { get; set; }
        /// <summary>
        /// 单条桶检查信息
        /// </summary>
        public NuclearBucketCheck BucketCheckDetail { get; set; }
        /// <summary>
        /// 源项信息列表
        /// </summary>
        public List<TrackInfo> TrackInfoList { get; set; }
        /// <summary>
        /// 源项主键ID集合
        /// </summary>
        public List<TrackIdInfo> TrackIdList { get; set; }

        /// <summary>
        /// 处置状态
        /// </summary>
        public string DealStatus { get; set; }

        /// <summary>
        /// 浓缩液装桶固化400l金属桶主键ID
        /// </summary>
        public string SolutionId { get; set; }
        /// <summary>
        /// 废树脂装桶固化400l金属桶主键ID
        /// </summary>
        public string ResinId { get; set; }
        /// <summary>
        /// 干湿料制备及废树脂装桶固化主键ID
        /// </summary>
        public string RSolidifyId { get; set; }
        /// <summary>
        /// 干湿料制备及浓缩液装桶固化主键ID
        /// </summary>
        public string SSolidifyId { get; set; }
        /// <summary>
        /// 固定主键ID
        /// </summary>
        public string FixAtionId { get; set; }
        /// <summary>
        /// 湿混料制备及400L金属桶装桶封盖
        /// </summary>
        public string MetalId { get; set; }
        /// <summary>
        /// 湿混料制备及封盖
        /// </summary>
        public string MixId { get; set; }
        /// <summary>
        /// 废物货包转运及QT贮存移动单
        /// </summary>
        public string QtTransId { get; set; }
        /// <summary>
        /// 厂房间废物桶转运
        /// </summary>
        public string FcTransId { get; set; }
        /// <summary>
        /// QT厂房废物货包入库记录
        /// </summary>
        public string GoodsInId { get; set; }
        /// <summary>
        /// QT厂房废物货包出库记录
        /// </summary>
        public string GoodsOutId { get; set; }
        /// <summary>
        /// 废物解控
        /// </summary>
        public string ClearId { get; set; }
        /// <summary>
        /// 废物降解
        /// </summary>
        public string DegradesId { get; set; }
        /// <summary>
        /// 废物拆解
        /// </summary>
        public string DismantleId { get; set; }
        /// <summary>
        /// 废物焚烧
        /// </summary>
        public string FireId { get; set; }
        /// <summary>
        /// 高整体容器处理
        /// </summary>
        public string HDisposeId { get; set; }
        /// <summary>
        /// 极低放废物处理
        /// </summary>
        public string LDisposeId { get; set; }
        /// <summary>
        /// 特殊包装
        /// </summary>
        public string PackageId { get; set; }
        /// <summary>
        /// 废物熔炼
        /// </summary>
        public string SmeltId { get; set; }
    }

    /// <summary>
    /// 桶查询条件
    /// </summary>
    public class BucketInfoCondition
    {
        /// <summary>
        /// 桶类型
        /// </summary>
        public string BucketType { get; set; }
        /// <summary>
        /// 桶状态
        /// </summary>
        public string BucketStatus { get; set; }
        /// <summary>
        /// 处置状态
        /// </summary>
        public string DealStatus { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 废物货包编号
        /// </summary>
        public string PackageCode { get; set; }
        /// <summary>
        /// 存放地点
        /// </summary>
        public string BucketLocation { get; set; }
        /// <summary>
        /// 入库时间(起)
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 入库时间(止)
        /// </summary>
        public string EndDate { get; set; }
    }
   
    /// <summary>
    /// 桶信息
    /// </summary>
    public class BucketInfoList
    {
        public NuclearWastePackage NuclearWastePackage { get; set; }
        public NuclearBucket NuclearBucket { get; set; }
        /// <summary>
        /// 桶信息主键ID
        /// </summary>
        public string BucketId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 桶状态
        /// </summary>
        public string BucketStatus { get; set; }
        /// <summary>
        /// 填充物
        /// </summary>
        public string BucketFiller { get; set; }

        /// <summary>
        /// 是否消耗 
        /// </summary>
        public string IsDrill { get; set; }

        /// <summary>
        /// 所在厂房名称  
        /// </summary>
        public string LocationName { get; set; }

        /// <summary>
        /// 所在厂房坐标
        /// </summary>
        public string FactoryPoint { get; set; }

        /// <summary>
        /// 材料名称
        /// </summary>
        public string MaterialName { get; set; }

        /// <summary>
        /// 废物货包编号
        /// </summary>
        public string PackageCode { get; set; }

        /// <summary>
        /// 废物类型
        /// </summary>
        public string WasteType { get; set; }

        /// <summary>
        /// 处置状态
        /// </summary>
        public string DealStatus { get; set; }

        /// <summary>
        /// 处置单元坐标
        /// </summary>
        public string UnitPoint { get; set; }
    }
    /// <summary>
    /// 源项信息
    /// </summary>
    public class TrackInfo
    {
        /// <summary>
        /// 桶主键ID
        /// </summary>
        public string BucketId { get; set; }
        /// <summary>
        /// 源项类型
        /// </summary>
        public string TrackType { get; set; }
        /// <summary>
        /// 跟踪单号
        /// </summary>
        public string TrackCode { get; set; }
        /// <summary>
        /// 跟踪单ID
        /// </summary>
        public string TrackId { get; set; }
    }
    /// <summary>
    /// 源项主键ID信息
    /// </summary>
    public class TrackIdInfo
    {
        /// <summary>
        /// 跟踪单主键ID
        /// </summary>
        public string TrackId { get; set; }
    }
}