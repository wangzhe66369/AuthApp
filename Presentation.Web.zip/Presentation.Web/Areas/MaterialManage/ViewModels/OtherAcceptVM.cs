﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using CIT.UPC.Domain.DomainObjects;
using RWIS.Presentation.Web.ViewModels.Common;



namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
    public class OtherAcceptVM
    {
      
        /// <summary>
        /// 其他验收单
        /// </summary>
        public OtherAccept OtherAccept { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> OtherAttachFiles { get; set; }

        public UploadFileListVM UploadFileListVM { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }
    }
}