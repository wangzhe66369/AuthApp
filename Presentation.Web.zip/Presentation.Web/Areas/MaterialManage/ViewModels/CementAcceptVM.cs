﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
     public class CementAcceptVM
    {
        //水泥桶验收单 实体
        public CementAccept CementAccept { get; set; }
        //水泥桶验收单-详细  实体
        public CementAcceptDetail CementAcceptDetail { get; set; }
        //页面寄存器
        public string CenmentBuckets { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> CementAttachFiles { get; set; }
        //当前页面所有操作
        public string OperationList { get; set; }

    }
}