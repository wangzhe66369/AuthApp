﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModels
{
    public class MaterialInputVM
    {
        /// <summary>
        /// 材料入库实体
        /// </summary>
        public MaterialInput MaterialInput { get; set; }

        /// <summary>
        /// 材料入库明细
        /// </summary>
        public string NuclearBucketChanges { get; set; }

        /// <summary>
        /// 入库桶号类型
        /// </summary>
        public string hidBucketCodeType { get; set; }

        /// <summary>
        /// 桶号
        /// </summary>
        public List<NuclearBucket> nuclearBucketList { get; set; }

        /// <summary>
        /// 桶号 
        /// </summary>
        public string BucketCode { get; set; }

        /// <summary>
        /// 材料名称
        /// </summary>
        public string MaterialName { get; set; }

        /// <summary>
        /// 材料规格
        /// </summary>
        public string MaterialSpec { get; set; }

        /// <summary>
        /// 地点名称
        /// </summary>
        public string LocationName { get; set; }

        /// <summary>
        /// 单位名称
        /// </summary>
        public string UuidName { get; set; }

        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }

        /// <summary>
        /// 附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> MaterialInputAttachFiles { get; set; }
    }
}