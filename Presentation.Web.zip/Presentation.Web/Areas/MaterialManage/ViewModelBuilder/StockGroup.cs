﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModelBuilder
{
    public class StockGroup
    {
        public string Material { get; set; }
        public string Location { get; set; }
        public Nullable<decimal> Amount { get; set; }

    }
}