﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RWIS.Presentation.Web.Core.Common;

namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModelBuilder
{
    public class NuclearBucketCodeErr
    {
        /// <summary>
        /// 桶号
        /// </summary>
        [ExportAttribute(DisplayName = "桶号", Order = 1)]
        public string bucketCode { get; set; }
        /// <summary>
        /// 错误描述
        /// </summary>
        [ExportAttribute(DisplayName = "错误描述", Order = 2)]
        public string Error { get; set; }
    }

    public class NuclearBucketCode
    {
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 桶状态
        /// </summary>
        public string BucketStatus { get; set; }
    }
}
