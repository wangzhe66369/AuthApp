﻿/********************************************************************************
 *
 *   项目名称   ：   ECDS
 *   文 件 名   ：   ElectricCableBuilder.cs
 *   描    述   ：   电缆信息管理
 *   创 建 者   ：   PXMWSWG[王哲]
 *   创建日期   ：   2017-2-21 
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2017-2-21               1.0.0.0    王哲       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.IO;
using Microsoft.Practices.ServiceLocation;
using NET01.CoreFramework;
using MvcContrib.Sorting;
using CIT.App.Lib.Uwf.Client.Factory;
using CIT.App.Lib.Uwf.Model;
using CIT.PSC.Service.Entity.DTO;
using CIT.Common.Common;
using NPOI.HSSF.UserModel;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels;

namespace RWIS.Presentation.Web.Areas.MaterialManage.ViewModelBuilder
{
    public class TableBuilder
    {
        /// <summary>
        /// 材料桶
        /// </summary>
        /// <param name="ds"></param>
        public static void Import(DataSet ds, string strNewImportPath)
        {
            IMaterialTransferRepository _MaterialTransferRepository = ServiceLocator.Current.GetInstance<IMaterialTransferRepository>();
            IMaterialTypeRepository _MaterialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
            IMaterialInputRepository _MaterialInputRepository = ServiceLocator.Current.GetInstance<IMaterialInputRepository>();
            INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            INuclearMStockRepository _NuclearMStockRepository = ServiceLocator.Current.GetInstance<INuclearMStockRepository>();
            INuclearBucketChangeRepository _NuclearBucketChangeRepository = ServiceLocator.Current.GetInstance<INuclearBucketChangeRepository>();
            IBasicObjectRepository _BasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
          

            DataTable dt = ds.Tables[0];
            //单位集合
            List<BasicObject> unitList = _BasicObjectRepository.GetSubobjectsByName("单位", AppContext.CurrentUser.ProjectCode).ToList();
            //存放地点集合
            List<BasicObject> locationList = _BasicObjectRepository.GetSubobjectsByName("厂房", AppContext.CurrentUser.ProjectCode).ToList();
            //dtElectricCable.Columns.Add("错误描述", typeof(string));
            var query = from t in dt.AsEnumerable()
                        group t by new { t1 = t.Field<string>("材料名称"), t2 = t.Field<string>("存放地点") } into m
                        select new StockGroup
                        {
                            Material = m.Key.t1,
                            Location = m.Key.t2,
                        };
            List<StockGroup> stockGroupList = query.ToList();

            foreach (var item in stockGroupList)
            {
                DataRow[] dtSle = dt.Select("材料名称='" + item.Material + "'and 存放地点='" + item.Location + "'");
                double amountAll = 0;
                string locationId = string.Empty;

                MaterialType materialType = _MaterialTypeRepository.GetAll().Where(d => d.MaterialName == item.Material).FirstOrDefault();
                foreach (var itemArr in dtSle)
                {

                    string materialName = CommonFunc.ObjectToNullStr(itemArr["材料名称"]).Trim();
                    string materialSpec = CommonFunc.ObjectToNullStr(itemArr["规格"]).Trim();
                    string bucketCode = CommonFunc.ObjectToNullStr(itemArr["桶号"]).Trim();
                    string productDate = CommonFunc.ObjectToNullStr(itemArr["生产日期"]).Trim();
                    string inputDate = CommonFunc.ObjectToNullStr(itemArr["入库时间"]).Trim();
                    string amount = CommonFunc.ObjectToNullStr(itemArr["数量"]).Trim();
                    string unitName = CommonFunc.ObjectToNullStr(itemArr["单位"]).Trim();
                    string locationName = CommonFunc.ObjectToNullStr(itemArr["存放地点"]).Trim();

                    if (!string.IsNullOrEmpty(amount))
                    {

                        //单位ID
                        string unitId = string.Empty;
                        if (!string.IsNullOrEmpty(unitName))
                        {
                            unitId = _BasicObjectRepository.GetBasicObjectIdByName(unitName, unitList);

                        }
                        //厂房ID
                        if (!string.IsNullOrEmpty(unitName))
                        {
                            locationId = _BasicObjectRepository.GetBasicObjectIdByName(locationName, locationList);

                        }

                        MaterialInput materialInput = new MaterialInput();
                        materialInput.InputId = Guid.NewGuid().ToString();
                        if (materialType != null)
                        {
                            materialInput.MaterialId = materialType.MaterialId;
                        }
                        materialInput.MaterialSpec = materialSpec;
                        materialInput.ProductDate = Convert.ToDateTime(productDate);
                        materialInput.InputDate = Convert.ToDateTime(inputDate);
                        materialInput.Amount = Convert.ToDouble(amount);
                        materialInput.UnitId = unitId;
                        materialInput.StorageLocationId = locationId;
                        materialInput.Stationcode = AppContext.CurrentUser.ProjectCode;
                        materialInput.Status ="2";
                        _MaterialInputRepository.Create(materialInput);
                        if (materialType != null)
                        {
                            if (materialType.IsBucket == "1")
                            {
                                NuclearBucket nuclearBucket = new NuclearBucket();
                                nuclearBucket.BucketId = Guid.NewGuid().ToString();
                                nuclearBucket.MaterialId = materialType.MaterialId;
                                nuclearBucket.BucketCode = bucketCode;
                                nuclearBucket.LocationId = locationId;
                                nuclearBucket.Status = "2";
                                nuclearBucket.IsDrain = "0";
                                nuclearBucket.Stationcode = AppContext.CurrentUser.ProjectCode;
                                _NuclearBucketRepository.Create(nuclearBucket);

                                NuclearBucketChange nuclearBucketChange = new NuclearBucketChange();
                                nuclearBucketChange.Detailid = Guid.NewGuid().ToString();
                                nuclearBucketChange.ChangeType = "INPUT";
                                nuclearBucketChange.BusinessId = materialInput.InputId;
                                nuclearBucketChange.BucketId = nuclearBucket.BucketId;
                                _NuclearBucketChangeRepository.Create(nuclearBucketChange);
                            }

                        }

                        amountAll += Convert.ToDouble(itemArr["数量"]);
                    }
                }
                NuclearMStock nuclearMStock = new NuclearMStock();
                nuclearMStock.StockId = Guid.NewGuid().ToString();
                nuclearMStock.Amount = amountAll;
                nuclearMStock.Stationcode = AppContext.CurrentUser.ProjectCode;
                if (materialType != null)
                {
                    nuclearMStock.MaterialId = materialType.MaterialId;
                }
                nuclearMStock.LocationId = locationId;
                _NuclearMStockRepository.Create(nuclearMStock);


            }
            _NuclearMStockRepository.UnitOfWork.Commit();
            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);



        }

        /// <summary>
        /// 400L浓缩液
        /// </summary>
        /// <param name="ds"></param>
        public static void ImportSolution(DataSet ds, string strNewImportPath)
        {
            INuclearBucketSolutionRepository _NuclearBucketSolutionRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolutionRepository>();
            INuclearBucketResinRepository _NuclearBucketResinRepository = ServiceLocator.Current.GetInstance<INuclearBucketResinRepository>();
            INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketRSolidifyRepository>();
            INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketSSolidifyRepository>();
            INuclearBucketSolidifyDetailRepository _NuclearBucketSolidifyDetailRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolidifyDetailRepository>();
            INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicObjectRepository _BasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INonComformanceRepository _NonComformanceRepository = ServiceLocator.Current.GetInstance<INonComformanceRepository>();
            INuclearGiftDetailRepository _NuclearGiftDetailRepository = ServiceLocator.Current.GetInstance<INuclearGiftDetailRepository>();
            List<NuclearBucketSolutionErr> errList = new List<NuclearBucketSolutionErr>();
            NuclearBucketSolutionErr err = null;
         
            DataTable dt = ds.Tables[0];
            dt.Columns.Add("错误描述", typeof(string));
            //固化桶类型集合
            List<BasicObject> unitList = _BasicObjectRepository.GetSubobjectsByName("固化桶类型", AppContext.CurrentUser.ProjectCode).ToList();
            for (int i = 1; i < dt.Rows.Count; i++)
            {
                err = new NuclearBucketSolutionErr();
                DataRow row = dt.Rows[i];
                string bucketCode = err.BucketCode = CommonFunc.ObjectToNullStr(row["桶号"]).Trim();
                string workTicket = err.WorkTicket = CommonFunc.ObjectToNullStr(row["工作票号"]).Trim();
                string trackCode = err.TrackCode = CommonFunc.ObjectToNullStr(row["废物跟踪单编号"]).Trim();
                string ppmQuantity = err.PpmQuantity = CommonFunc.ObjectToNullStr(row["硼浓度"]).Trim();
                string density = err.Density = CommonFunc.ObjectToNullStr(row["浓缩液密度"]).Trim();
                string saltQuantity = err.SaltQuantity = CommonFunc.ObjectToNullStr(row["浓缩液含盐量"]).Trim();
                string bucketType = err.BucketType = CommonFunc.ObjectToNullStr(row["固化桶类型"]).Trim();
                string tesBa = err.TesBa = CommonFunc.ObjectToNullStr(row["TES实际值"]).Trim();
                string additive = err.Additive = CommonFunc.ObjectToNullStr(row["添加剂实际值"]).Trim();
                string water = err.Water = CommonFunc.ObjectToNullStr(row["水的实际值"]).Trim();
                string lime = err.Lime = CommonFunc.ObjectToNullStr(row["石灰实际值"]).Trim();
                string cement = err.Cement = CommonFunc.ObjectToNullStr(row["水泥真实值"]).Trim();
                string cementFlag = err.CementFlag = CommonFunc.ObjectToNullStr(row["水泥是否有效"]).Trim();
                string shakeTime = err.ShakeTime = CommonFunc.ObjectToNullStr(row["总搅拌时间"]).Trim();
                string visual = err.Visual = CommonFunc.ObjectToNullStr(row["固化体目视检查"]).Trim();
                string overStatus = err.OverStatus = CommonFunc.ObjectToNullStr(row["封盖状态"]).Trim();
                string meteringAve = err.MeteringAve = CommonFunc.ObjectToNullStr(row["桶周围平均剂量率"]).Trim();
                string meteringTop = err.MeteringTop = CommonFunc.ObjectToNullStr(row["固化体上部剂量率"]).Trim();
                string meteringMax = err.MeteringMax = CommonFunc.ObjectToNullStr(row["桶周围最大剂量率"]).Trim();
                string controlPersonName = err.ControlPersonName = CommonFunc.ObjectToNullStr(row["操作员"]).Trim();
                string controlDate = err.ControlDate = CommonFunc.ObjectToNullStr(row["操作日期"]).Trim();
                string checkPersonName = err.CheckPersonName = CommonFunc.ObjectToNullStr(row["检查人"]).Trim();
                string checkDate = err.CheckDate = CommonFunc.ObjectToNullStr(row["检查日期"]).Trim();
                string remark = err.Remark = CommonFunc.ObjectToNullStr(row["备注"]).Trim();
                string stationCode = AppContext.CurrentUser.ProjectCode;
                //固化桶类型
                string bucketTypeId = string.Empty;
                if (!string.IsNullOrEmpty(bucketType))
                {
                    bucketTypeId = _BasicObjectRepository.GetBasicObjectIdByName(bucketType, unitList);

                }

                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    err.Error += "您填的桶号不存在！";
               
                }
             
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (listBucket.Count() > 0)
                {
                    if (listBucket[0].BucketStatus != "PREPARE")
                    {
                        err.Error += "您填的桶未经过检查或者不是空桶！";

                    }

                    var listBucketSolution = _NuclearBucketSolutionRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listBucketSolution != null)
                    {
                        err.Error += "您填的桶已经填充过！";
                    }
                }
              
              
                var trackList = TrackItemBuilder.GetTrackList(AppContext.CurrentUser.ProjectCode).Where(d => d.TrackCode == trackCode).ToList();
                if (trackList.Count == 0)
                {
                    err.Error += "您填的废物跟踪单号不存在！";
                }
                string tId = string.Empty;
                if (trackList.Count > 0)
                {
                    tId=trackList[0].TrackId;
                }
              
                var solutionList = _NuclearBucketSolutionRepository.GetQueryList().Where(n => n.TrackId == tId).ToList();
                if (solutionList.Count > 0)
                {
                    err.Error += "您填的废物跟踪单已经经过处理！";
                }
                //判断数据是否正确
                if (CommonFunc.IsNotNullString(err.Error))
                {
                    errList.Add(err);
                    continue;
                }
                var bucketCodeList = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).Where(d => d.Stationcode == stationCode).ToList();
                //主表信息
                NuclearBucketSolution nuclearBucketSolution = new NuclearBucketSolution();
                nuclearBucketSolution.SolutionId = Guid.NewGuid().ToString();
                nuclearBucketSolution.TrackId = trackList[0].TrackId;
                nuclearBucketSolution.BucketId = bucketCodeList[0].BucketId;
                nuclearBucketSolution.WorkTicket = workTicket;
                nuclearBucketSolution.BucketTypeId = bucketTypeId;
                nuclearBucketSolution.PpmQuantity = Convert.ToDecimal(ppmQuantity);
                nuclearBucketSolution.Density = Convert.ToDecimal(density);
                nuclearBucketSolution.SaltQuantity = Convert.ToDecimal(saltQuantity);
                nuclearBucketSolution.TesBa = Convert.ToDecimal(tesBa);
                nuclearBucketSolution.Additive = Convert.ToDecimal(additive);
                nuclearBucketSolution.Water = Convert.ToDecimal(water);
                nuclearBucketSolution.Cement = Convert.ToDecimal(cement);
                if (cementFlag == "N")
                {
                    nuclearBucketSolution.CementFlag = "0";
                }
                if (cementFlag == "Y")
                {
                    nuclearBucketSolution.CementFlag = "1";
                }
                nuclearBucketSolution.ShakeTime = Convert.ToDecimal(shakeTime);
                if (visual == "N")
                {
                    nuclearBucketSolution.Visual = "0";
                }
                if (visual == "Y")
                {
                    nuclearBucketSolution.Visual = "1";
                }
               
                if (overStatus == "N")
                {
                    nuclearBucketSolution.OverStatus = "0";
                }
                if (overStatus == "Y")
                {
                    nuclearBucketSolution.OverStatus = "1";
                }
                nuclearBucketSolution.MeteringAve = Convert.ToDecimal(meteringAve);
                nuclearBucketSolution.MeteringTop = Convert.ToDecimal(meteringTop);
                nuclearBucketSolution.MeteringMax = Convert.ToDecimal(meteringMax);
                nuclearBucketSolution.ControlPersonName = controlPersonName;
                nuclearBucketSolution.ControlDate = Convert.ToDateTime(controlDate);
                nuclearBucketSolution.CheckPersonName = checkPersonName;
                nuclearBucketSolution.CheckDate = Convert.ToDateTime(checkDate);
                nuclearBucketSolution.Remark = remark;
                nuclearBucketSolution.Stationcode = stationCode;
               // _NuclearBucketSolutionRepository.Create(nuclearBucketSolution);

                string confirmFlag = nuclearBucketSolution.Status;
                if (confirmFlag != "2")
                {
                    if (trackList.Count > 0)
                    {
                        var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(nuclearBucketSolution.BucketId);
                        modelBucket.StationId = trackList[0].StationId;
                        _NuclearBucketRepository.Update(modelBucket);

                        string trackType = TrackItemBuilder.GetNameByCode(trackList[0].TrackType);
                        _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, trackType, "浓缩液装桶固化", "FILL");
                        if (trackList[0].TrackType == "ELEMENT" || trackList[0].TrackType == "TECH2" || trackList[0].TrackType == "SUNDRY")
                        {
                            TrackItemBuilder.UpdateTrackDealStatus(trackList[0].TrackType, trackList[0].TrackId, "1");
                        }
                       
                    }
                }
                
                List<NuclearSolidifyDetail> detailList = new List<NuclearSolidifyDetail>();
                NuclearSolidifyDetail detail = new NuclearSolidifyDetail();
                detail.DetailId = Guid.NewGuid().ToString();
                detail.SolidifyId = nuclearBucketSolution.SolutionId;
                detail.SolidifyType = "1";
                detail.BucketId = bucketCodeList[0].BucketId;
                detailList.Add(detail);

                bool isJudge= _NuclearBucketSolutionRepository.AddBucketSolution(nuclearBucketSolution, detailList);
                if(!isJudge)
                {
                    err.Error += "导入没有保存成功！";
                    errList.Add(err);
                    continue;
                }
            }
            _NuclearBucketSolutionRepository.UnitOfWork.Commit();
         
            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);
            #region 错误文档
            if (errList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (errList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("400L浓缩液装桶固化");
                    ImportExportHelper.FillSheet<NuclearBucketSolutionErr>(errList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<NuclearBucketSolutionErr>(stream);
            }
            #endregion
          
        }

        /// <summary>
        /// 400L废树脂
        /// </summary>
        /// <param name="ds"></param>
        public static void ImportResin(DataSet ds, string strNewImportPath)
        {



            INuclearBucketSolutionRepository _NuclearBucketSolutionRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolutionRepository>();
            INuclearBucketResinRepository _NuclearBucketResinRepository = ServiceLocator.Current.GetInstance<INuclearBucketResinRepository>();
            INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketRSolidifyRepository>();
            INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketSSolidifyRepository>();
            INuclearBucketSolidifyDetailRepository _NuclearBucketSolidifyDetailRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolidifyDetailRepository>();
            INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicObjectRepository _BasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INonComformanceRepository _NonComformanceRepository = ServiceLocator.Current.GetInstance<INonComformanceRepository>();
            INuclearGiftDetailRepository _NuclearGiftDetailRepository = ServiceLocator.Current.GetInstance<INuclearGiftDetailRepository>();
            List<NuclearBucketResinErr> errList = new List<NuclearBucketResinErr>();
            NuclearBucketResinErr err = null;
            DataTable dt = ds.Tables[0];
            dt.Columns.Add("错误描述", typeof(string));
            //固化桶类型集合
            List<BasicObject> unitList = _BasicObjectRepository.GetSubobjectsByName("固化桶类型", AppContext.CurrentUser.ProjectCode).ToList();
            for (int i = 1; i < dt.Rows.Count; i++)
            {

                err = new NuclearBucketResinErr();
                DataRow row = dt.Rows[i];
                string bucketCode =err.BucketCode= CommonFunc.ObjectToNullStr(row["桶号"]).Trim();
                string workTicket = err.WorkTicket = CommonFunc.ObjectToNullStr(row["工作票号"]).Trim();
                string trackCode = err.TrackCode = CommonFunc.ObjectToNullStr(row["废物跟踪单编号"]).Trim();
                string bucketType = err.BucketType = CommonFunc.ObjectToNullStr(row["固化桶类型"]).Trim();
                //string systemName = CommonFunc.ObjectToNullStr(row["树脂含硼硼"]).Trim();
                string tesBa = err.TesBa = CommonFunc.ObjectToNullStr(row["TES实际值"]).Trim();
                string additive = err.Additive = CommonFunc.ObjectToNullStr(row["添加剂实际值"]).Trim();
                string water = err.Water = CommonFunc.ObjectToNullStr(row["水的实际值"]).Trim();
                string lime = err.Lime = CommonFunc.ObjectToNullStr(row["石灰实际值"]).Trim();
                string cement = err.Cement = CommonFunc.ObjectToNullStr(row["水泥真实值"]).Trim();
                string cementFlag = err.CementFlag = CommonFunc.ObjectToNullStr(row["水泥是否有效"]).Trim();
                string shakeTime = err.ShakeTime = CommonFunc.ObjectToNullStr(row["总搅拌时间"]).Trim();

                string visual = err.Visual = CommonFunc.ObjectToNullStr(row["固化体目视检查"]).Trim();
                string overStatus = err.OverStatus = CommonFunc.ObjectToNullStr(row["封盖状态"]).Trim();
                string meteringAve = err.MeteringAve = CommonFunc.ObjectToNullStr(row["桶周围平均剂量率"]).Trim();
                string meteringTop = err.MeteringTop = CommonFunc.ObjectToNullStr(row["固化体上部剂量率"]).Trim();

                string meteringMax = err.MeteringMax = CommonFunc.ObjectToNullStr(row["桶周围最大剂量率"]).Trim();
                string controlPersonName = err.ControlPersonName = CommonFunc.ObjectToNullStr(row["操作员"]).Trim();
                string controlDate = err.ControlDate = CommonFunc.ObjectToNullStr(row["操作日期"]).Trim();
                string checkPersonName = err.CheckPersonName = CommonFunc.ObjectToNullStr(row["检查人"]).Trim();
                string checkDate = err.CheckDate = CommonFunc.ObjectToNullStr(row["检查日期"]).Trim();
                string remark = err.Remark = CommonFunc.ObjectToNullStr(row["备注"]).Trim();
                string stationCode = AppContext.CurrentUser.ProjectCode;
                //固化桶类型
                string bucketTypeId = string.Empty;
                if (!string.IsNullOrEmpty(bucketType))
                {
                    bucketTypeId = _BasicObjectRepository.GetBasicObjectIdByName(bucketType, unitList);

                }
                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    err.Error += "您填的桶号不存在！";

                }
                
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (listBucket.Count>0&&listBucket[0].BucketStatus != "PREPARE")
                {
                    err.Error += "您填的桶未经过检查或者不是空桶！";

                }
                if (listBucket.Count() > 0)
                {
                    var listBucketSolution = _NuclearBucketSolutionRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listBucketSolution != null)
                    {
                        err.Error += "您填的桶已经填充过！";
                    }
                
                }
               
                var bucketCodeList = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).Where(d => d.Stationcode == stationCode).ToList();
                var trackList = TrackItemBuilder.GetTrackList(AppContext.CurrentUser.ProjectCode).Where(d => d.TrackCode == trackCode).ToList();
                if (trackList.Count == 0)
                {
                    err.Error += "您填的废物跟踪单号不存在！";
                }
                //判断数据是否正确
                if (CommonFunc.IsNotNullString(err.Error))
                {
                    errList.Add(err);
                    continue;
                }
                //更新废物跟踪单
                string trackStation = string.Empty;  
                if(trackList.Count()>0)
                {
                     trackStation = trackList[0].StationId;
                    string trackType = trackList[0].TrackType;
                }
               
                               
                NuclearBucketResin nuclearBucketResin = new NuclearBucketResin();
                nuclearBucketResin.ResinId = Guid.NewGuid().ToString();
                nuclearBucketResin.TrackId = trackList[0].TrackId;
                nuclearBucketResin.BucketId = bucketCodeList[0].BucketId;
                nuclearBucketResin.WorkTicket = workTicket;
                nuclearBucketResin.BucketTypeId = bucketTypeId;
                nuclearBucketResin.TesBa = Convert.ToDecimal(tesBa);
                nuclearBucketResin.Additive = Convert.ToDecimal(additive);
                nuclearBucketResin.Water = Convert.ToDecimal(water);
                nuclearBucketResin.Cement = Convert.ToDecimal(cement);
                if (cementFlag == "N")
                {
                    nuclearBucketResin.CementFlag = "0";
                }
                if (cementFlag == "Y")
                {
                    nuclearBucketResin.CementFlag = "1";
                }
                nuclearBucketResin.ShakeTime = Convert.ToDecimal(shakeTime);
                if (visual == "N")
                {
                    nuclearBucketResin.Visual = "0";
                }
                if (visual == "Y")
                {
                    nuclearBucketResin.Visual = "1";
                }
                if (overStatus == "N")
                {
                    nuclearBucketResin.OverStatus = "0";
                }
                if (overStatus == "Y")
                {
                    nuclearBucketResin.OverStatus = "1";
                }
                nuclearBucketResin.MeteringAve = Convert.ToDecimal(meteringAve);
                nuclearBucketResin.MeteringTop = Convert.ToDecimal(meteringTop);
                nuclearBucketResin.MeteringMax = Convert.ToDecimal(meteringMax);
                nuclearBucketResin.ControlPersonName = controlPersonName;
                nuclearBucketResin.ControlDate = Convert.ToDateTime(controlDate);
                nuclearBucketResin.CheckPersonName = checkPersonName;
                nuclearBucketResin.CheckDate = Convert.ToDateTime(checkDate);
                nuclearBucketResin.Remark = remark;
                nuclearBucketResin.Stationcode = stationCode;

               // _NuclearBucketResinRepository.Create(nuclearBucketResin);

                if (trackList.Count > 0)
                {
                    var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(nuclearBucketResin.BucketId);
                    modelBucket.StationId = trackStation;
                    _NuclearBucketRepository.Update(modelBucket);
                    string trackType = TrackItemBuilder.GetNameByCode(trackList[0].TrackType);
                    _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, "废树脂", "废树脂固化", "FILL");
                }
                List<string>tracArraykList=new  List<string>();
                tracArraykList.Add( trackList[0].TrackId);

                bool isJudge = _NuclearBucketResinRepository.AddBucketResin(nuclearBucketResin, tracArraykList.ToArray());
                if (!isJudge)
                {
                    err.Error += "导入没有保存成功！";
                    errList.Add(err);
                    continue;
                }
            }
            _NuclearBucketResinRepository.UnitOfWork.Commit();

            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);
            #region 错误文档
            if (errList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (errList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("400L废树脂装桶固化");
                    ImportExportHelper.FillSheet<NuclearBucketResinErr>(errList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<NuclearBucketResinErr>(stream);
            }
            #endregion
           
        }
        /// <summary>
        /// 废树脂
        /// </summary>
        /// <param name="ds"></param>
        public static void ImportSolidify(DataSet ds, string strNewImportPath)
        {



            INuclearBucketSolutionRepository _NuclearBucketSolutionRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolutionRepository>();
            INuclearBucketResinRepository _NuclearBucketResinRepository = ServiceLocator.Current.GetInstance<INuclearBucketResinRepository>();
            INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketRSolidifyRepository>();
            INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketSSolidifyRepository>();
            INuclearBucketSolidifyDetailRepository _NuclearBucketSolidifyDetailRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolidifyDetailRepository>();
            INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicObjectRepository _BasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INonComformanceRepository _NonComformanceRepository = ServiceLocator.Current.GetInstance<INonComformanceRepository>();
            INuclearGiftDetailRepository _NuclearGiftDetailRepository = ServiceLocator.Current.GetInstance<INuclearGiftDetailRepository>();
            List<NuclearBucketRSolidifyErr> errList = new List<NuclearBucketRSolidifyErr>();
            NuclearBucketRSolidifyErr err = null;
         
            DataTable dt = ds.Tables[0];
            dt.Columns.Add("错误描述", typeof(string));
            //固化桶类型集合
            List<BasicObject> unitList = _BasicObjectRepository.GetSubobjectsByName("固化桶类型", AppContext.CurrentUser.ProjectCode).ToList();
            ////存放地点集合
            //List<BasicObject> locationList = _BasicObjectRepository.GetSubobjectsByName("厂房", AppContext.CurrentUser.ProjectCode).ToList();
            for (int i = 1; i < dt.Rows.Count; i++)
            {

                err = new NuclearBucketRSolidifyErr();
                DataRow row = dt.Rows[i];
                string bucketCode =err.BucketCode= CommonFunc.ObjectToNullStr(row["桶号"]).Trim();
                string workTicket = err.WorkTicket = CommonFunc.ObjectToNullStr(row["工作票号"]).Trim();
                string trackCode = err.TrackCode = CommonFunc.ObjectToNullStr(row["废物跟踪单编号"]).Trim();
                string cementQuantity = err.cementQuantity = CommonFunc.ObjectToNullStr(row["水泥数量"]).Trim();
                string sandQuantity = err.sandQuantity = CommonFunc.ObjectToNullStr(row["沙子数量"]).Trim();
                string shakeTime = err.ShakeTime = CommonFunc.ObjectToNullStr(row["搅拌时间"]).Trim();
                string additive = err.Additive = CommonFunc.ObjectToNullStr(row["添加剂"]).Trim();
                string cementFlag = err. CementFlag = CommonFunc.ObjectToNullStr(row["水泥是否有效"]).Trim();
                string TesBa = err.TesBa = CommonFunc.ObjectToNullStr(row["固化TES值"]).Trim();
                string water = err.Water = CommonFunc.ObjectToNullStr(row["固化补充水量"]).Trim();
                string shakeTimeM = err.ShakeTimeM = CommonFunc.ObjectToNullStr(row["固化总搅拌时间"]).Trim();
                string meteringAve = err.MeteringAve = CommonFunc.ObjectToNullStr(row["固化桶周围平均剂量率"]).Trim();
                string meteringTop = err.MeteringTop = CommonFunc.ObjectToNullStr(row["固化体上部剂量率"]).Trim();
                string meteringMax = err.MeteringMax = CommonFunc.ObjectToNullStr(row["固化桶周围最大剂量率"]).Trim();
                string shakeFlag = err.shakeFlag = CommonFunc.ObjectToNullStr(row["搅拌桨"]).Trim();
                string controlPersonName = err.ControlPersonName = CommonFunc.ObjectToNullStr(row["操作员"]).Trim();
                string controlDate = err.ControlDate = CommonFunc.ObjectToNullStr(row["操作日期"]).Trim();
                string checkPersonName = err.CheckPersonName = CommonFunc.ObjectToNullStr(row["检查人"]).Trim();
                string checkDate = err.CheckDate = CommonFunc.ObjectToNullStr(row["检查日期"]).Trim();
                string remark = err.Remark = CommonFunc.ObjectToNullStr(row["备注"]).Trim();
                string stationCode = AppContext.CurrentUser.ProjectCode;

                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    err.Error += "您填的桶号不存在！";

                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (listBucket.Count > 0 && listBucket[0].BucketStatus != "PREPARE")
                {
                    err.Error += "您填的桶未经过检查或者不是空桶！";

                }
                if (listBucket.Count() > 0)
                {
                    var listBucketSolution = _NuclearBucketSolutionRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listBucketSolution != null)
                    {
                        err.Error += "您填的桶已经填充过！";
                    }

                }


                var bucketCodeList = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).Where(d => d.Stationcode == stationCode).ToList();
                var trackList = TrackItemBuilder.GetTrackList(AppContext.CurrentUser.ProjectCode).Where(d => d.TrackCode == trackCode).ToList();
                if (trackList.Count == 0)
                {
                    err.Error += "您填的废物跟踪单号不存在！";
                }

                //判断数据是否正确
                if (CommonFunc.IsNotNullString(err.Error))
                {
                    errList.Add(err);
                    continue;
                }
                //更新废物跟踪单
                string trackStation = string.Empty;
                if (trackList.Count() > 0)
                {
                    trackStation = trackList[0].StationId;
                    string trackType = trackList[0].TrackType;
                }
               
                       
                NuclearBucketRSolidify nuclearBucketRSolidify = new NuclearBucketRSolidify();
                nuclearBucketRSolidify.SolidifyRId = Guid.NewGuid().ToString();
                nuclearBucketRSolidify.TrackId = trackList[0].TrackId;
                nuclearBucketRSolidify.BucketId = bucketCodeList[0].BucketId;
                nuclearBucketRSolidify.WorkTicket = workTicket;
                nuclearBucketRSolidify.CementQuantity = Convert.ToDecimal(cementQuantity);
                nuclearBucketRSolidify.SandQuantity = Convert.ToDecimal(sandQuantity);
                nuclearBucketRSolidify.ShakeTime = Convert.ToDecimal(shakeTime);
                nuclearBucketRSolidify.Additive = Convert.ToDecimal(additive);
                if (cementFlag == "N")
                {
                    nuclearBucketRSolidify.CementFlag = "0";
                }
                if (cementFlag == "Y")
                {
                    nuclearBucketRSolidify.CementFlag = "1";
                }
               
                nuclearBucketRSolidify.TesBa =  Convert.ToDecimal(TesBa);
                nuclearBucketRSolidify.Water =  Convert.ToDecimal(water);
                nuclearBucketRSolidify.ShakeTimeM = Convert.ToDecimal(shakeTimeM);
                if (shakeFlag == "N")
                {
                    nuclearBucketRSolidify.ShakeFlag = "0";
                }
                if (shakeFlag == "Y")
                {
                    nuclearBucketRSolidify.ShakeFlag = "1";
                }
                nuclearBucketRSolidify.MeteringAve = Convert.ToDecimal(meteringAve);
                nuclearBucketRSolidify.MeteringTop = Convert.ToDecimal(meteringTop);
                nuclearBucketRSolidify.MeteringMax = Convert.ToDecimal(meteringMax);
                nuclearBucketRSolidify.ControlPersonName = controlPersonName;
                nuclearBucketRSolidify.ControlDate = Convert.ToDateTime(controlDate);
                nuclearBucketRSolidify.CheckPersonName = checkPersonName;
                nuclearBucketRSolidify.CheckDate = Convert.ToDateTime(checkDate);
                nuclearBucketRSolidify.Remark = remark;
                nuclearBucketRSolidify.Stationcode = stationCode;
                //_NuclearBucketRSolidifyRepository.Create(nuclearBucketRSolidify);

               //更新桶信息
                if (trackList.Count > 0)
                {
                    var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(nuclearBucketRSolidify.BucketId);
                    modelBucket.StationId = trackStation;
                    _NuclearBucketRepository.Update(modelBucket);
                    _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, "废树脂", "干湿料制备及废树脂装桶固化", "FILL");
                }


                List<string> tracArraykList = new List<string>();
                tracArraykList.Add(trackList[0].TrackId);

                bool isJudge = _NuclearBucketRSolidifyRepository.AddBucketRSolidify(nuclearBucketRSolidify, tracArraykList.ToArray());
                if (!isJudge)
                {
                    err.Error += "导入没有保存成功！";
                    errList.Add(err);
                    continue;
                }

            }
            _NuclearBucketRSolidifyRepository.UnitOfWork.Commit();
            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);
            #region 错误文档
            if (errList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (errList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("废树脂固化");
                    ImportExportHelper.FillSheet<NuclearBucketRSolidifyErr>(errList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<NuclearBucketRSolidifyErr>(stream);
            }
            #endregion
        }

        /// <summary>
        /// 浓缩液
        /// </summary>
        /// <param name="ds"></param>
        public static void ImportSSolidify(DataSet ds, string strNewImportPath)
        {



            INuclearBucketSolutionRepository _NuclearBucketSolutionRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolutionRepository>();
            INuclearBucketResinRepository _NuclearBucketResinRepository = ServiceLocator.Current.GetInstance<INuclearBucketResinRepository>();
            INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketRSolidifyRepository>();
            INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository = ServiceLocator.Current.GetInstance<INuclearBucketSSolidifyRepository>();
            INuclearBucketSolidifyDetailRepository _NuclearBucketSolidifyDetailRepository = ServiceLocator.Current.GetInstance<INuclearBucketSolidifyDetailRepository>();
            INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicObjectRepository _BasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INonComformanceRepository _NonComformanceRepository = ServiceLocator.Current.GetInstance<INonComformanceRepository>();
            INuclearGiftDetailRepository _NuclearGiftDetailRepository = ServiceLocator.Current.GetInstance<INuclearGiftDetailRepository>();
            List<NuclearBucketSSolidifyErr> errList = new List<NuclearBucketSSolidifyErr>();
            NuclearBucketSSolidifyErr err = null;
            DataTable dt = ds.Tables[0];
            dt.Columns.Add("错误描述", typeof(string));
            //固化桶类型集合
            List<BasicObject> unitList = _BasicObjectRepository.GetSubobjectsByName("固化桶类型", AppContext.CurrentUser.ProjectCode).ToList();
            ////存放地点集合
            //List<BasicObject> locationList = _BasicObjectRepository.GetSubobjectsByName("厂房", AppContext.CurrentUser.ProjectCode).ToList();
            for (int i = 1; i < dt.Rows.Count; i++)
            {

                err = new NuclearBucketSSolidifyErr();
                DataRow row = dt.Rows[i];
                string bucketCode = err.BucketCode=CommonFunc.ObjectToNullStr(row["桶号"]).Trim();
                string workTicket = err.WorkTicket = CommonFunc.ObjectToNullStr(row["工作票号"]).Trim();
                string WasteType = err.WasteType = CommonFunc.ObjectToNullStr(row["废物类型"]).Trim();
                string trackCode = err.TrackCode = CommonFunc.ObjectToNullStr(row["废物跟踪单编号"]).Trim();
                string CementSQuantity = err.CementSQuantity = CommonFunc.ObjectToNullStr(row["浓缩液水泥数量"]).Trim();
                string SandSQuantity = err.SandSQuantity = CommonFunc.ObjectToNullStr(row["浓缩液沙子数量"]).Trim();
                string ShakeSTime = err.ShakeSTime = CommonFunc.ObjectToNullStr(row["浓缩液搅拌时间"]).Trim();
                string CementWQuantity = err.CementWQuantity = CommonFunc.ObjectToNullStr(row["淤泥物水泥数量"]).Trim();
                string SandWQuantity = err.SandWQuantity = CommonFunc.ObjectToNullStr(row["淤泥物沙子数量"]).Trim();
                string ShakeWTime = err.ShakeWTime = CommonFunc.ObjectToNullStr(row["淤泥物搅拌时间"]).Trim();
                string cementFlag = err.cementFlag = CommonFunc.ObjectToNullStr(row["水泥是否有效"]).Trim();
                string TesBaA = err.TesBaA = CommonFunc.ObjectToNullStr(row["固化浓缩液TES"]).Trim();
                string WaterA = err.WaterA = CommonFunc.ObjectToNullStr(row["固化浓缩液补水量"]).Trim();
                string ShakeTimeMA = err.ShakeTimeMA = CommonFunc.ObjectToNullStr(row["固化浓缩液总搅拌时间"]).Trim();
                string MeteringAveA = err.MeteringAveA = CommonFunc.ObjectToNullStr(row["固化桶周围平均剂量率"]).Trim();
                string MeteringTopA = err.MeteringTopA = CommonFunc.ObjectToNullStr(row["浓缩液固化体上部剂量率"]).Trim();
                string MeteringMaxA = err.MeteringMaxA = CommonFunc.ObjectToNullStr(row["浓缩液固化周围最大剂量率"]).Trim();
                string TesBaB = err.TesBaB = CommonFunc.ObjectToNullStr(row["固化淤泥物TES"]).Trim();
                string WaterB = err.WaterB = CommonFunc.ObjectToNullStr(row["固化淤泥物补水量"]).Trim();
                string ShakeTimeMB = err.ShakeTimeMB = CommonFunc.ObjectToNullStr(row["固化淤泥物补水量总搅拌时间"]).Trim();
                string meteringAveB = err.meteringAveB = CommonFunc.ObjectToNullStr(row["淤泥物固化体周围平均剂量率"]).Trim();
                string meteringTopB = err.meteringTopB = CommonFunc.ObjectToNullStr(row["淤泥物固化体上部剂量率"]).Trim();
                string meteringMaxB = err.meteringMaxB = CommonFunc.ObjectToNullStr(row["淤泥物固化体周围最大剂量率"]).Trim();
                string shakeFlag = err.shakeFlag = CommonFunc.ObjectToNullStr(row["搅拌桨"]).Trim();
                string controlPersonName = err.controlPersonName = CommonFunc.ObjectToNullStr(row["操作员"]).Trim();
                string controlDate = err.controlDate = CommonFunc.ObjectToNullStr(row["操作日期"]).Trim();
                string checkPersonName = err.checkPersonName = CommonFunc.ObjectToNullStr(row["检查人"]).Trim();
                string checkDate = err.checkDate = CommonFunc.ObjectToNullStr(row["检查日期"]).Trim();
                string remark = err.remark = CommonFunc.ObjectToNullStr(row["备注"]).Trim();
                string stationCode = AppContext.CurrentUser.ProjectCode;
                ////固化桶类型
                //string bucketTypeId = string.Empty;
                //if (!string.IsNullOrEmpty(bucketType))
                //{
                //    bucketTypeId = _BasicObjectRepository.GetBasicObjectIdByName(bucketType, unitList);

                //}

                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    err.Error += "您填的桶号不存在！";

                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (listBucket.Count > 0 && listBucket[0].BucketStatus != "PREPARE")
                {
                    err.Error += "您填的桶未经过检查或者不是空桶！";

                }
                if (listBucket.Count() > 0)
                {
                    var listBucketSolution = _NuclearBucketSolutionRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listBucketSolution != null)
                    {
                        err.Error += "您填的桶已经填充过！";
                    }

                }

                var trackList = TrackItemBuilder.GetTrackList(AppContext.CurrentUser.ProjectCode).Where(d => d.TrackCode == trackCode).ToList();
                if (trackList.Count == 0)
                {
                    err.Error += "您填的废物跟踪单号不存在！";
                }
                if (trackList.Count > 0)
                {
                    string tId = trackList[0].TrackId;
                    var solutionList = _NuclearBucketSolutionRepository.GetQueryList().Where(n => n.TrackId == tId).ToList();
                    if (solutionList.Count > 0)
                    {
                        err.Error += "您填的废物跟踪单号已经存在！";
                    }
                }
               
              
                var bucketCodeList = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).Where(d => d.Stationcode == stationCode).ToList();
                if (bucketCodeList.Count == 0)
                {
                    err.Error += "您填的桶号不存在！";
                }


                //判断数据是否正确
                if (CommonFunc.IsNotNullString(err.Error))
                {
                    errList.Add(err);
                    continue;
                }
                NuclearBucketSSolidify nuclearBucketSSolidify = new NuclearBucketSSolidify();
                nuclearBucketSSolidify.SolidifySIdd = Guid.NewGuid().ToString();
                if (trackList.Count() > 0)
                {
                    nuclearBucketSSolidify.TrackId = trackList[0].TrackId;
                
                }
                if (bucketCodeList.Count() > 0)
                {
                    nuclearBucketSSolidify.BucketId = bucketCodeList[0].BucketId;
                }
                nuclearBucketSSolidify.WorkTicket = workTicket;
                nuclearBucketSSolidify.CementSQuantity = Convert.ToDecimal(CementSQuantity == "" ? 0 : Convert.ToDecimal(CementSQuantity));
                nuclearBucketSSolidify.SandSQuantity = Convert.ToDecimal(SandSQuantity == "" ? 0 : Convert.ToDecimal(SandSQuantity));
                nuclearBucketSSolidify.ShakeSTime = Convert.ToDecimal(ShakeSTime == "" ? 0 : Convert.ToDecimal(ShakeSTime));
                nuclearBucketSSolidify.CementWQuantity = Convert.ToDecimal(CementWQuantity == "" ? 0 : Convert.ToDecimal(CementWQuantity));
                nuclearBucketSSolidify.SandWQuantity = Convert.ToDecimal(SandWQuantity == "" ? 0 : Convert.ToDecimal(SandWQuantity));
                nuclearBucketSSolidify.ShakeWTime = Convert.ToDecimal(ShakeWTime == "" ? 0 : Convert.ToDecimal(ShakeWTime));
                if (cementFlag == "N")
                {
                    nuclearBucketSSolidify.CementFlag = "0";
                }
                if (cementFlag == "Y")
                {
                    nuclearBucketSSolidify.CementFlag = "1";
                }

                nuclearBucketSSolidify.TesBaA = Convert.ToDecimal(TesBaA == "" ? 0 : Convert.ToDecimal(TesBaA));
                nuclearBucketSSolidify.WaterA = Convert.ToDecimal(WaterA == "" ? 0 : Convert.ToDecimal(WaterA));
                nuclearBucketSSolidify.ShakeTimeMA = Convert.ToDecimal(ShakeTimeMA == "" ? 0 : Convert.ToDecimal(ShakeTimeMA));
                nuclearBucketSSolidify.MeteringAveA = Convert.ToDecimal(MeteringAveA == "" ? 0 : Convert.ToDecimal(MeteringAveA));
                nuclearBucketSSolidify.MeteringTopA = Convert.ToDecimal(MeteringTopA == "" ? 0 : Convert.ToDecimal(MeteringTopA));
                nuclearBucketSSolidify.MeteringMaxA = Convert.ToDecimal(MeteringMaxA == "" ? 0 : Convert.ToDecimal(MeteringMaxA));

                nuclearBucketSSolidify.TesBaB = Convert.ToDecimal(TesBaB == "" ? 0 : Convert.ToDecimal(TesBaB));
                nuclearBucketSSolidify.WaterB = Convert.ToDecimal(WaterB == "" ? 0 : Convert.ToDecimal(WaterB));
                nuclearBucketSSolidify.ShakeTimeMB = Convert.ToDecimal(ShakeTimeMB == "" ? 0 : Convert.ToDecimal(ShakeTimeMB));
                nuclearBucketSSolidify.MeteringAveB = Convert.ToDecimal(meteringAveB == "" ? 0 : Convert.ToDecimal(meteringAveB));
                nuclearBucketSSolidify.MeteringTopB = Convert.ToDecimal(meteringTopB == "" ? 0 : Convert.ToDecimal(meteringTopB));
                nuclearBucketSSolidify.MeteringMaxB = Convert.ToDecimal(meteringMaxB == "" ? 0 : Convert.ToDecimal(meteringMaxB));
                if (shakeFlag == "N")
                {
                    nuclearBucketSSolidify.ShakeFlag = "0";
                }
                if (shakeFlag == "Y")
                {
                    nuclearBucketSSolidify.ShakeFlag = "1";
                }
                nuclearBucketSSolidify.ControlPersonName = controlPersonName;
                nuclearBucketSSolidify.ControlDate = Convert.ToDateTime(controlDate);
                nuclearBucketSSolidify.CheckPersonName = checkPersonName;
                nuclearBucketSSolidify.CheckDate = Convert.ToDateTime(checkDate);
                nuclearBucketSSolidify.Remark = remark;
                nuclearBucketSSolidify.Stationcode = stationCode;
               // _NuclearBucketSSolidifyRepository.Create(nuclearBucketSSolidify);

                List<NuclearSolidifyDetail> detailList=new List<NuclearSolidifyDetail>();
                NuclearSolidifyDetail detail = new NuclearSolidifyDetail();
                detail.DetailId = Guid.NewGuid().ToString();
                detail.SolidifyId = nuclearBucketSSolidify.SolidifySIdd;
                detail.SolidifyType = "1";
                detail.BucketId = nuclearBucketSSolidify.BucketId;
                detailList.Add(detail);

                if (trackList.Count > 0)
                {
                    var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(nuclearBucketSSolidify.BucketId);
                    modelBucket.StationId = trackList[0].StationId;
                    _NuclearBucketRepository.Update(modelBucket);
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    string trackType = TrackItemBuilder.GetNameByCode(trackList[0].TrackType);
                    _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, trackType, "干湿料制备及浓废树脂固化", "FILL");
                    if (trackList[0].TrackType == "ELEMENT" || trackList[0].TrackType == "TECH2" || trackList[0].TrackType == "SUNDRY")
                    {
                        TrackItemBuilder.UpdateTrackDealStatus(trackList[0].TrackType, trackList[0].TrackId, "1");
                    }
                }


                bool isJudge= _NuclearBucketSSolidifyRepository.AddBucketSSolidify(nuclearBucketSSolidify, detailList);
                if (!isJudge)
                {
                    err.Error += "导入没有保存成功！";
                    errList.Add(err);
                    continue;
                }
            }
            _NuclearBucketSSolidifyRepository.UnitOfWork.Commit();
            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);
            #region 错误文档
            if (errList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (errList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("废树脂固化");
                    ImportExportHelper.FillSheet<NuclearBucketSSolidifyErr>(errList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<NuclearBucketSSolidifyErr>(stream);
            }
            #endregion
        }

        /// <summary>
        /// 固化
        /// </summary>
        /// <param name="ds"></param>
        public static void ImportFix(DataSet ds, string strNewImportPath)
        {

            INuclearWastePackageRepository _NuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
            INuclearFixationRepository _NuclearFixationRepository = ServiceLocator.Current.GetInstance<INuclearFixationRepository>();
            INuclearFixationDetailRepository _NuclearFixationDetailRepository = ServiceLocator.Current.GetInstance<INuclearFixationDetailRepository>();
            INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicObjectRepository _BasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INonComformanceRepository _NonComformanceRepository = ServiceLocator.Current.GetInstance<INonComformanceRepository>();
            IMaterialTypeRepository _MaterialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();

            List<NuclearFixationErr> errList = new List<NuclearFixationErr>();
            NuclearFixationErr err = null;
            DataTable dt = ds.Tables[0];
            dt.Columns.Add("错误描述", typeof(string));
            //废物类型集合
            List<BasicObject> typeList = _BasicObjectRepository.GetSubobjectsByName("废物类型", AppContext.CurrentUser.ProjectCode).ToList();
            for (int i = 1; i < dt.Rows.Count; i++)
            {

                err = new NuclearFixationErr();
                DataRow row = dt.Rows[i];
                string bucketCode =err.bucketCode= CommonFunc.ObjectToNullStr(row["桶号"]).Trim();
                string OrderCode = err.OrderCode = CommonFunc.ObjectToNullStr(row["工作票号"]).Trim();
                string BucketTypeName = err.BucketTypeName = CommonFunc.ObjectToNullStr(row["桶的类型"]).Trim();

                string trackCode = err.trackCode = CommonFunc.ObjectToNullStr(row["废物跟踪单编号"]).Trim();
                string Cement = err.Cement = CommonFunc.ObjectToNullStr(row["水泥数量"]).Trim();
                string Sand = err.Sand = CommonFunc.ObjectToNullStr(row["沙子数量"]).Trim();
                string Meterial = err.Meterial = CommonFunc.ObjectToNullStr(row["骨料数量"]).Trim();
                string Water = err.Water = CommonFunc.ObjectToNullStr(row["补充水数量"]).Trim();
                string Additive = err.Additive = CommonFunc.ObjectToNullStr(row["添加剂数量"]).Trim();
                string ShakeTime = err.ShakeTime = CommonFunc.ObjectToNullStr(row["搅拌时间"]).Trim();
                string CementFlag = err.CementFlag = CommonFunc.ObjectToNullStr(row["水泥是否有效"]).Trim();

                string WasteSourse = err.WasteSourse = CommonFunc.ObjectToNullStr(row["废物来源"]).Trim();
                string WasteTypeName = err.WasteTypeName = CommonFunc.ObjectToNullStr(row["废物类型"]).Trim();
                string WastePosition = err.WastePosition = CommonFunc.ObjectToNullStr(row["废物装桶位置"]).Trim();
                string WaterShakeTime = err.WaterShakeTime = CommonFunc.ObjectToNullStr(row["操作振动时间"]).Trim();

                string ReduceTime = err.ReduceTime = CommonFunc.ObjectToNullStr(row["操作压缩时间"]).Trim();
                string OverStatus = err.OverStatus = CommonFunc.ObjectToNullStr(row["固化体及封盖状态"]).Trim();
                string MeteringAve = err.MeteringAve = CommonFunc.ObjectToNullStr(row["桶周围平均剂量率"]).Trim();
                string MeteringTop = err.MeteringTop = CommonFunc.ObjectToNullStr(row["固化体上部剂量率"]).Trim();
                string MeteringMax = err.MeteringMax = CommonFunc.ObjectToNullStr(row["桶周围最大剂量率"]).Trim();

                string MaterialControlName = err.MaterialControlName = CommonFunc.ObjectToNullStr(row["操作员"]).Trim();
                string MaterialControlDate = err.MaterialControlDate = CommonFunc.ObjectToNullStr(row["操作日期"]).Trim();
                string MaterialCheckName = err.MaterialCheckName = CommonFunc.ObjectToNullStr(row["检查人"]).Trim();
                string MaterialCheckDate = err.MaterialCheckDate = CommonFunc.ObjectToNullStr(row["检查日期"]).Trim();
                string Remark = err.Remark = CommonFunc.ObjectToNullStr(row["备注"]).Trim();
                string stationCode = AppContext.CurrentUser.ProjectCode;

                var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (trackList.Count == 0)
                {
                    err.Error += "您填的废物跟踪单号不存在！";
                }
                var bucketCodeList = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).Where(d => d.Stationcode == stationCode).ToList();
                if (bucketCodeList.Count == 0)
                {
                    err.Error += "桶号不存在！";
                }

                MaterialType materialType = _MaterialTypeRepository.GetAll().Where(d => d.MaterialName == BucketTypeName).FirstOrDefault();
                if (materialType == null)
                {
                    err.Error += "材料不存在！";
                }

                //固化桶类型
                string wasteTypeId = string.Empty;
                if (!string.IsNullOrEmpty(WasteTypeName))
                {
                    wasteTypeId = _BasicObjectRepository.GetBasicObjectIdByName(WasteTypeName, typeList);
                    if (string.IsNullOrEmpty(wasteTypeId))
                    {
                        err.Error += "固化桶类型不存在！";
                    }

                }

                //判断数据是否正确
                if (CommonFunc.IsNotNullString(err.Error))
                {
                    errList.Add(err);
                    continue;
                }

                try
                {
                    //主表
                    NuclearFixation nuclearFixation = new NuclearFixation();
                    nuclearFixation.FixationId = Guid.NewGuid().ToString();
                    nuclearFixation.BucketId = bucketCodeList[0].BucketId;
                    nuclearFixation.OrderCode = OrderCode;
                    nuclearFixation.BucketTypeId = materialType.MaterialId;
                    nuclearFixation.Cement = Convert.ToDecimal(Cement);
                    nuclearFixation.Sand = Convert.ToDecimal(Sand);
                    nuclearFixation.Meterial = Convert.ToDecimal(Meterial);
                    nuclearFixation.Additive = Convert.ToDecimal(Additive);
                    nuclearFixation.ShakeTime = Convert.ToDecimal(ShakeTime);

                    if (CementFlag == "N")
                    {
                        nuclearFixation.CementFlag = "0";
                    }
                    if (CementFlag == "Y")
                    {
                        nuclearFixation.CementFlag = "1";
                    }
                    nuclearFixation.WasteSourse = WasteSourse;
                    nuclearFixation.WasteTypeId = wasteTypeId;
                    nuclearFixation.WastePosition = WastePosition;
                    nuclearFixation.WaterShakeTime = Convert.ToDecimal(WaterShakeTime);
                    nuclearFixation.ReduceTime = Convert.ToDecimal(ReduceTime);

                    if (OverStatus == "N")
                    {
                        nuclearFixation.OverStatus = "0";
                    }
                    if (OverStatus == "Y")
                    {
                        nuclearFixation.OverStatus = "1";
                    }

                    nuclearFixation.MeteringAve = Convert.ToDecimal(MeteringAve);
                    nuclearFixation.MeteringTop = Convert.ToDecimal(MeteringTop);
                    nuclearFixation.MeteringMax = Convert.ToDecimal(MeteringMax);
                    nuclearFixation.MaterialControlName = MaterialControlName;
                    nuclearFixation.MaterialControlDate = Convert.ToDateTime(MaterialControlDate);
                    nuclearFixation.MaterialCheckName = MaterialCheckName;
                    nuclearFixation.MaterialCheckDate = Convert.ToDateTime(MaterialCheckDate);
                    nuclearFixation.Remark = Remark;
                    nuclearFixation.Stationcode = stationCode;
                    _NuclearFixationRepository.Create(nuclearFixation);

                    //详细表
                    NuclearFixationDetail detail = new NuclearFixationDetail();
                    detail.FixationDetailId = Guid.NewGuid().ToString();
                    detail.FixationId = nuclearFixation.FixationId;
                    detail.TrackId = trackList[0].TrackId;
                    _NuclearFixationDetailRepository.Create(detail);


                    string trackStation = string.Empty;
                    var trackListt = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode);

                    var trackModel = trackListt.Where(n => n.TrackId == trackList[0].TrackId).ToList();
                    if (trackModel.Count > 0)
                    {
                        trackStation = trackModel[0].StationId;
                        TrackItemBuilder.UpdateTrackDealStatus(trackModel[0].TrackType, trackModel[0].TrackId, "1");
                    }

                    if (!string.IsNullOrEmpty(trackStation))
                    {
                        var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(nuclearFixation.BucketId);
                        modelBucket.StationId = trackStation;
                        _NuclearBucketRepository.Update(modelBucket);
                    }

                    var wasteTypeList = _BasicObjectRepository.GetAll().Where(d => d.Uuid == wasteTypeId).ToList();
                    if (wasteTypeList.Count() > 0)
                    {
                        _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, wasteTypeList[0].Name, wasteTypeList[0].Name + "固定", "FILL");

                    }
                    string packageCode = _NuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                    var wasteList = _NuclearWastePackageRepository.GetAll().Where(n => n.BucketId == nuclearFixation.BucketId && n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                    if (wasteList.Count == 0)
                    {
                        //NuclearWastePackage package = new NuclearWastePackage();
                        //package.PackageId = Guid.NewGuid().ToString();
                        //package.PackageCode = packageCode;
                        //package.BucketId = nuclearFixation.BucketId;
                        //package.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        //package.ConfirmUserName = AppContext.CurrentUser.UserName;
                        //package.ConfirmDate = DateTime.Now;
                        //package.Stationcode = AppContext.CurrentUser.ProjectCode;
                        //_NuclearWastePackageRepository.Create(package);

                    }
                }
                catch (Exception)
                {
                    err.Error += "导入没有保存成功！";
                    errList.Add(err);
                    continue;
                }
                
            }
            _NuclearFixationRepository.UnitOfWork.Commit();
             //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);
            #region 错误文档
            if (errList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (errList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("废树脂固化");
                    ImportExportHelper.FillSheet<NuclearFixationErr>(errList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<NuclearFixationErr>(stream);
            }
            #endregion


        }

        /// <summary>
        /// 导入桶号
        /// </summary>
        /// <param name="ds"></param>
        public static List<NuclearBucketCode> ImportBucketCode(DataSet ds, string strNewImportPath)
        {

            
            INuclearBucketRepository _NuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            List<NuclearBucketCodeErr> errList = new List<NuclearBucketCodeErr>();
            NuclearBucketCodeErr err = null;
            DataTable dt = ds.Tables[0];
            dt.Columns.Add("错误描述", typeof(string));
            List<NuclearBucketCode> nuclearBucketCodeList = new List<NuclearBucketCode>();
            for (int i = 1; i < dt.Rows.Count; i++)
            {

                err = new NuclearBucketCodeErr();
                DataRow row = dt.Rows[i];
                string bucketCode = err.bucketCode = CommonFunc.ObjectToNullStr(row["桶号"]).Trim();
                bool bucketCheck = _NuclearBucketRepository.IsExistPackage(bucketCode, AppContext.CurrentUser.ProjectCode);
                string bucketStatus = string.Empty;
                if (!bucketCheck)
                {
                    err.Error += "您填的桶还未生成废物货包！";
                }
                else
                {
                   
                    var modelBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.BucketCode == bucketCode && n.Stationcode == AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                    if (modelBucket != null)
                    {
                        if (modelBucket.BucketStatus == "EMPTY" || string.IsNullOrEmpty(modelBucket.BucketStatus))
                            bucketStatus = "空桶";
                        if (modelBucket.BucketStatus == "PREPARE")
                            bucketStatus = "桶准备";
                        if (modelBucket.BucketStatus == "FILL")
                            bucketStatus = "填充";
                        if (modelBucket.BucketStatus == "COVER")
                            bucketStatus = "封盖";
                    }
                }

                //判断数据是否正确
                if (CommonFunc.IsNotNullString(err.Error))
                {
                    errList.Add(err);
                    continue;
                }

                NuclearBucketCode nuclearBucketCode = new NuclearBucketCode();
                nuclearBucketCode.BucketCode = bucketCode;
                nuclearBucketCode.BucketStatus = bucketStatus;
                nuclearBucketCodeList.Add(nuclearBucketCode);
              
            }
            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);
            #region 错误文档
            if (errList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (errList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("桶号");
                    ImportExportHelper.FillSheet<NuclearBucketCodeErr>(errList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<NuclearBucketCodeErr>(stream);
            }
            #endregion
            return nuclearBucketCodeList;

        }
    }
}