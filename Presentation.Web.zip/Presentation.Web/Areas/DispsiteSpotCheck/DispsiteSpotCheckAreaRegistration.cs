﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.DispsiteSpotCheck
{
    public class DispsiteSpotCheckAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "DispsiteSpotCheck";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "DispsiteSpotCheck_default",
                "DispsiteSpotCheck/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
