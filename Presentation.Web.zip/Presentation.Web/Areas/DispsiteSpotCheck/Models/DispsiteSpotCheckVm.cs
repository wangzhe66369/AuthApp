﻿/********************************************************************************
 *
 *   项目名称   ：   核电废物信息系统
 *   文 件 名   ：   DispsiteSpotCheckVm.cs
 *   描    述   ：   抽检管理vm
 *   创 建 者   ：   郑浩宇 
 *   创建日期   ：   2016-09-13 12:01:45
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-13 12:01:45    1.0.0.0    郑浩宇       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.DispsiteSpotCheck.Models
{
    /// <summary>
    /// 抽检管理vm
    /// </summary>
    public class DispsiteSpotCheckVm
    {
        /// <summary>
        /// 抽检管理实体
        /// </summary>
        public RWIS.Domain.DomainObjects.DispsiteSpotCheck DispsiteSpotCheck { get; set; }

        /// <summary>
        /// 抽检详细实体
        /// </summary>
        public DispsiteSpotDetail DispsiteSpotDetail { get; set; }

        /// <summary>
        /// 废物货包实体
        /// </summary>
        public NuclearWastePackage NuclearWastePackage { get; set; }

        /// <summary>
        /// 核素库
        /// </summary>
        public NuclearElement NuclearElement { get; set; }

        /// <summary>
        /// 结论
        /// </summary>
        public List<SelectListItem> RodiodList { get; set; }

       /// <summary>
        /// 页面寄存器
       /// </summary>
        public string DispsiteSpotChecks { get; set; }

        /// <summary>
        /// 状态 
        /// </summary>
        public List<SelectListItem> StatusList { get; set; }

        /// <summary>
        /// 权限验证
        /// </summary>
        public string OperationList { get; set; }
    }
}
