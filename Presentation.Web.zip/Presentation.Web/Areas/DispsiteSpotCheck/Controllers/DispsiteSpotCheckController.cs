﻿/********************************************************************************
 *
 *   项目名称   ：   核电废物信息系统
 *   文 件 名   ：   DispsiteSpotCheckController.cs
 *   描    述   ：   DispsiteSpotCheckController
 *   创 建 者   ：   郑浩宇 
 *   创建日期   ：   2016-09-13 12:01:45
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-13 12:01:45    1.0.0.0    郑浩宇       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View.Support;
using MvcContrib.UI.Grid;
using RWIS.Presentation.Web.Areas.DispsiteSpotCheck.Models;
using NET01.CoreFramework;
using RWIS.Domain.DomainObjects.View.DispsiteSpotCheck;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.DispsiteSpotCheck.Controllers
{
    public class DispsiteSpotCheckController : Controller
    {
        IDispsiteSpotCheckRepository _DispsiteSpotCheckRepository;
        IDispsiteSpotDetailRepository _DispsiteSpotDetailRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearElementRepository _NuclearElementRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        INuclearApplyDetailRepository _NuclearApplyDetailRepository;
        IDispsiteCheckRepository _DispsiteCheckRepository;
        IDispsiteCheckDetailRepository _DispsiteCheckDetailRepository;
        CommonHelper commonHelper = new CommonHelper();
        public DispsiteSpotCheckController(IDispsiteSpotCheckRepository _DispsiteSpotCheckRepository, 
                                            IDispsiteSpotDetailRepository _DispsiteSpotDetailRepository,
                                            IBasicObjectRepository _BasicObjectRepository, 
                                            INuclearElementRepository _NuclearElementRepository, 
                                            INuclearWastePackageRepository _NuclearWastePackageRepository,
                                            INuclearBucketRepository _NuclearBucketRepository, 
                                            INuclearApplyDetailRepository _NuclearApplyDetailRepository,
                                            IDispsiteCheckRepository _DispsiteCheckRepository,
                                            IDispsiteCheckDetailRepository _DispsiteCheckDetailRepository)
        {
            this._DispsiteSpotCheckRepository = _DispsiteSpotCheckRepository;
            this._DispsiteSpotDetailRepository = _DispsiteSpotDetailRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearElementRepository = _NuclearElementRepository;
            this._NuclearWastePackageRepository = _NuclearWastePackageRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._NuclearApplyDetailRepository = _NuclearApplyDetailRepository;
            this._DispsiteCheckRepository = _DispsiteCheckRepository;
            this._DispsiteCheckDetailRepository = _DispsiteCheckDetailRepository;
        }

        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "抽检管理")]
        public ActionResult Index()
        {
            DispsiteSpotCheckVm vm = new DispsiteSpotCheckVm();
            vm.OperationList = CommonHelper.GetOperationList("Dispsite_Spot_Check");//权限控制

            //加载结论
            vm.StatusList = new List<SelectListItem>();
            vm.StatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.StatusList.Add(new SelectListItem { Text = "草稿", Value = "0" });
            vm.StatusList.Add(new SelectListItem { Text = "未确认", Value = "1" });
            vm.StatusList.Add(new SelectListItem { Text = "已确认", Value = "2" });
            return View(vm);
        }

        public ActionResult Add()
        {
            DispsiteSpotCheckVm vm = new DispsiteSpotCheckVm();
            vm.OperationList = CommonHelper.GetOperationList("Dispsite_Spot_Check");//权限控制

            //加载结论
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "通过", Value = "1", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "不通过", Value = "0" });
            return View(vm);
        }

        public ActionResult Edit(string id)
        {
            DispsiteSpotCheckVm vm = new DispsiteSpotCheckVm();
            vm.OperationList = CommonHelper.GetOperationList("Dispsite_Spot_Check");//权限控制
            RWIS.Domain.DomainObjects.DispsiteSpotCheck model = _DispsiteSpotCheckRepository.Get(id);
            NuclearWastePackage Pac = _NuclearWastePackageRepository.Get(model.PackageId);
            if (Pac!=null)
            {
                string packageCode = Pac.PackageCode;
                model.PackageId = packageCode;
            }
           
           
            
            //加载结论
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "通过", Value = "1", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "不通过", Value = "0" });
            vm.DispsiteSpotCheck = model;

            ///如果数字类型不为空,且存在小数点，截取小数点后三位
            if (vm.DispsiteSpotCheck.DoseSurface != null)
            {
                if (vm.DispsiteSpotCheck.DoseSurface.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.DoseSurface = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.DoseSurface));
                }
            }

            if (vm.DispsiteSpotCheck.DoseMeter != null)
            {
                if (vm.DispsiteSpotCheck.DoseMeter.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.DoseMeter = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.DoseMeter));
                }
            }

            if (vm.DispsiteSpotCheck.PolluteSurface != null)
            {
                if (vm.DispsiteSpotCheck.PolluteSurface.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.PolluteSurface = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.PolluteSurface));
                }
            }

            if (vm.DispsiteSpotCheck.PackageSumA != null)
            {
                if (vm.DispsiteSpotCheck.PackageSumA.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.PackageSumA = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.PackageSumA));
                }
            }

            if (vm.DispsiteSpotCheck.PackageSumB != null)
            {
                if (vm.DispsiteSpotCheck.PackageSumB.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.PackageSumB = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.PackageSumB));
                }
            }

            if (vm.DispsiteSpotCheck.ActivityAll != null)
            {
                if (vm.DispsiteSpotCheck.ActivityAll.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.ActivityAll = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.ActivityAll));
                }
            }

            if (vm.DispsiteSpotCheck.Weight != null)
            {
                if (vm.DispsiteSpotCheck.Weight.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.Weight = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.Weight));
                }
            }

            return View("Edit", vm);
        }
        /// <summary>
        /// 查看
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
       new public ActionResult View(string id)
        {
            DispsiteSpotCheckVm vm = new DispsiteSpotCheckVm();
            RWIS.Domain.DomainObjects.DispsiteSpotCheck model = _DispsiteSpotCheckRepository.Get(id);
            NuclearWastePackage Pac = _NuclearWastePackageRepository.Get(model.PackageId);
            if (Pac!=null)
            {
                string packageCode = Pac.PackageCode;
                model.PackageId = packageCode;
            }
           
            //加载结论
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "通过", Value = "1", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "不通过", Value = "0" });

            vm.DispsiteSpotCheck = model;

            ///如果数字类型不为空，截取小数点后三位
            if (vm.DispsiteSpotCheck.DoseSurface != null)
            {
                if (vm.DispsiteSpotCheck.DoseSurface.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.DoseSurface = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.DoseSurface));
                }
            }

            if (vm.DispsiteSpotCheck.DoseMeter != null)
            {
                if (vm.DispsiteSpotCheck.DoseMeter.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.DoseMeter = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.DoseMeter));
                }
            }

            if (vm.DispsiteSpotCheck.PolluteSurface != null)
            {
                if (vm.DispsiteSpotCheck.PolluteSurface.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.PolluteSurface = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.PolluteSurface));
                }
            }

            if (vm.DispsiteSpotCheck.PackageSumA != null)
            {
                if (vm.DispsiteSpotCheck.PackageSumA.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.PackageSumA = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.PackageSumA));
                }
            }

            if (vm.DispsiteSpotCheck.PackageSumB != null)
            {
                if (vm.DispsiteSpotCheck.PackageSumB.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.PackageSumB = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.PackageSumB));
                }
            }

            if (vm.DispsiteSpotCheck.ActivityAll != null)
            {
                if (vm.DispsiteSpotCheck.ActivityAll.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.ActivityAll = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.ActivityAll));
                }
            }

            if (vm.DispsiteSpotCheck.Weight != null)
            {
                if (vm.DispsiteSpotCheck.Weight.Value.ToString().IndexOf('.') > 0)
                {
                    vm.DispsiteSpotCheck.Weight = Convert.ToDecimal(String.Format("{0:00.000}", vm.DispsiteSpotCheck.Weight));
                }
            }
            return View("View", vm);
        }

        public ActionResult AddDetail()
        {
            return View();
        }

        /// <summary>
        /// 查询核素库列表
        /// </summary>
        /// <param name="keyWord">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNuclearElementList(NuclearElementCondition nuclearElementCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearElementView> data = this._NuclearElementRepository.QueryList(nuclearElementCondition);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearElementView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ElementId,
                    List = new List<object>() {
                    d.ElementId,                   
                    d.ElementName                    
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询抽检管理列表
        /// </summary>
        /// <param name="">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetDispsiteSpotCheckList(DispsiteSpotCheckCondition DispsiteSpotCheckCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<DispsiteSpotCheckView> data = this._DispsiteSpotCheckRepository.QueryList(DispsiteSpotCheckCondition,AppContext.CurrentUser.ProjectCode);                        
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<DispsiteSpotCheckView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.SpotCheckId,
                    List = new List<object>() {
                    d.SpotCheckId,
                    d.PackageId,
                    d.WasteType,
                    d.BucketCode,
                     d.SpotDate.HasValue?d.SpotDate.Value.ToString("yyyy-MM-dd"):string.Empty,  
                    d.CheckName,    
                    d.ResultFlag,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询抽检管理详细列表
        /// </summary>
        /// <param name="">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetDispsiteSpotDetailList(string SpotCheckId, string sord, int page, int rows, string sidx)
        {            
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            IQueryable<DispsiteSpotCheckView> data = this._DispsiteSpotDetailRepository.QueryListBySpotDetailId(SpotCheckId).Where(d => d.SpotCheckId == SpotCheckId).AsQueryable();            
            var pagedViewModel = new PagedViewModel<DispsiteSpotCheckView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.SpotDetailId,
                    List = new List<object>() {   
                        d.SpotDetailId,
                       d.SpotCheckId,
                        d.ElementId,
                        d.ElementName,
                        d.ElementValue                   
                    }
                });
            });
            return jqGridResponse.ToJsonResult();
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken] 
        public JsonResult Save(DispsiteSpotCheckVm model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证!\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //判断废物货包是否存在 
                string packageId = this._NuclearWastePackageRepository.IsExistDispsiteSpotCheck(model.DispsiteSpotCheck.PackageId, AppContext.CurrentUser.ProjectCode);
                if (string.IsNullOrEmpty(packageId))
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包没有经过处置申请!\"}", JsonRequestBehavior.AllowGet);
                }
                model.DispsiteSpotCheck.PackageId = packageId;
               
                //判断废物货包是否通过审核
                NuclearWastePackage nuclearWastePackage = this._NuclearWastePackageRepository.Get(packageId);
                if (nuclearWastePackage.Status == "RETURN")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包已退回!\"}", JsonRequestBehavior.AllowGet);
                }

                if (nuclearWastePackage.Status == "CHECKED")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包已通过审核!\"}", JsonRequestBehavior.AllowGet);
                }

                if (nuclearWastePackage.Status == "APPLIED")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包已审批!\"}", JsonRequestBehavior.AllowGet);
                }
                if (nuclearWastePackage.Status == "RECEPTED")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包已接收!\"}", JsonRequestBehavior.AllowGet);
                }
                if (nuclearWastePackage.Status == "DEALED")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包已处置!\"}", JsonRequestBehavior.AllowGet);
                }
                if (nuclearWastePackage.Status == "UNCHECKED")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包正在审核!\"}", JsonRequestBehavior.AllowGet);
                }
                //新增
                if (string.IsNullOrEmpty(model.DispsiteSpotCheck.SpotCheckId))
                {
                    //判断废物货包是否重复
                    if (this._DispsiteSpotCheckRepository.IsRepeat(model.DispsiteSpotCheck.PackageId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包重复。\"}", JsonRequestBehavior.AllowGet);
                    }
                    //IQueryable<RWIS.Domain.DomainObjects.DispsiteSpotCheck> dispsiteSpotCheck = this._DispsiteSpotCheckRepository.GetAll().Where(d => d.PackageId == packageId).AsQueryable();
                    //if (dispsiteSpotCheck.Count() > 0)
                    //{
                    //    return Json("{\"result\":false,\"msg\":\"该废物货包已发起抽检!\"}", JsonRequestBehavior.AllowGet);

                    //}

                    //新增抽检管理主单
                    model.DispsiteSpotCheck.SpotCheckId = Guid.NewGuid().ToString();
                    model.DispsiteSpotCheck.CreateDate = DateTime.Now;
                    model.DispsiteSpotCheck.CreateUserName = AppContext.CurrentUser.UserName;
                    model.DispsiteSpotCheck.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.DispsiteSpotCheck.Status = "0";
                    model.DispsiteSpotCheck.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._DispsiteSpotCheckRepository.Create(model.DispsiteSpotCheck);
                    if (!string.IsNullOrEmpty(model.DispsiteSpotChecks))
                    {
                        //新增抽检管理明细
                        string[] arrDispsiteSpotD = model.DispsiteSpotChecks.Split(';');
                        for (int i = 0; i < arrDispsiteSpotD.Length; i++)
                        {
                            DispsiteSpotDetail DispsiteSpotDetail = new DispsiteSpotDetail();
                            string[] arrDispsiteSpotDetail = arrDispsiteSpotD[i].Split(',');
                            if (arrDispsiteSpotDetail.Length == 3)
                            {
                                DispsiteSpotDetail.SpotDetailId = Guid.NewGuid().ToString();
                                DispsiteSpotDetail.SpotCheckId = model.DispsiteSpotCheck.SpotCheckId;
                                DispsiteSpotDetail.ElementId = arrDispsiteSpotDetail[0];
                                DispsiteSpotDetail.ElementValue = Convert.ToDecimal(arrDispsiteSpotDetail[2]);
                                this._DispsiteSpotDetailRepository.Create(DispsiteSpotDetail);
                            }
                        }
                    }

                    //提交
                    this._DispsiteSpotDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }
                //修改完新增
                else
                {
                    //更新抽检管理
                    string newPackageId = model.DispsiteSpotCheck.PackageId;
                    //更新能谱库
                    model.DispsiteSpotCheck = _DispsiteSpotCheckRepository.Get(model.DispsiteSpotCheck.SpotCheckId);

                    //判断废物货包是否重复
                    if (model.DispsiteSpotCheck.PackageId != newPackageId && this._DispsiteSpotCheckRepository.IsRepeat(model.DispsiteSpotCheck.PackageId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包重复。\"}", JsonRequestBehavior.AllowGet);
                    }
                    UpdateModel(model);
                    model.DispsiteSpotCheck = _DispsiteSpotCheckRepository.Get(model.DispsiteSpotCheck.SpotCheckId);
                    model.DispsiteSpotCheck.PackageId = packageId;
                    UpdateModel(model);
                    model.DispsiteSpotCheck.Status = "0";
                    if (string.IsNullOrEmpty(packageId))
                    {
                        return Json("{\"result\":false,\"msg\":\"该废物货包没有经过处置申请!\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.DispsiteSpotCheck.PackageId = packageId;

                    this._DispsiteSpotCheckRepository.Update(model.DispsiteSpotCheck);
                    //根据抽检管理ID查询抽检管理详细
                    IQueryable<DispsiteSpotDetail> data = this._DispsiteSpotCheckRepository.GetSpotDtail(model.DispsiteSpotCheck.SpotCheckId);
                    List<DispsiteSpotDetail> listData = data.ToList();
                    //删除抽检管理详细的数据
                    foreach (var item in listData)
                    {
                        this._DispsiteSpotDetailRepository.DeleteById(item.SpotDetailId);
                    }

                    if (!string.IsNullOrEmpty(model.DispsiteSpotChecks))
                    {
                        //新增抽检管理明细
                        string[] arrDispsiteSpotD = model.DispsiteSpotChecks.Split(';');
                        for (int i = 0; i < arrDispsiteSpotD.Length; i++)
                        {
                            DispsiteSpotDetail DispsiteSpotDetail = new DispsiteSpotDetail();
                            string[] arrDispsiteSpotDetail = arrDispsiteSpotD[i].Split(',');
                            if (arrDispsiteSpotDetail.Length == 3)
                            {
                                DispsiteSpotDetail.SpotDetailId = Guid.NewGuid().ToString();
                                DispsiteSpotDetail.SpotCheckId = model.DispsiteSpotCheck.SpotCheckId;
                                DispsiteSpotDetail.ElementId = arrDispsiteSpotDetail[0];
                                DispsiteSpotDetail.ElementValue = Convert.ToDecimal(arrDispsiteSpotDetail[2]);
                                this._DispsiteSpotDetailRepository.Create(DispsiteSpotDetail);
                            }
                        }

                    }
                    this._DispsiteSpotCheckRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                this._DispsiteSpotDetailRepository.UnitOfWork.Commit();
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Submit(DispsiteSpotCheckVm model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证!\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //判断废物货包是否存在 
                string packageId = this._NuclearWastePackageRepository.IsExistDispsiteSpotCheck(model.DispsiteSpotCheck.PackageId, AppContext.CurrentUser.ProjectCode);
                if (string.IsNullOrEmpty(packageId))
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包没有经过处置申请!\"}", JsonRequestBehavior.AllowGet);
                }
                model.DispsiteSpotCheck.PackageId = packageId;

                //判断废物货包是否通过审核
                NuclearWastePackage nuclearWastePackage = this._NuclearWastePackageRepository.Get(packageId);
                if (nuclearWastePackage.Status == "RETURN")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包已退回!\"}", JsonRequestBehavior.AllowGet);
                }

                if (nuclearWastePackage.Status == "CHECKED")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包已通过审核!\"}", JsonRequestBehavior.AllowGet);
                }

                if (nuclearWastePackage.Status == "APPLIED")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包已审批!\"}", JsonRequestBehavior.AllowGet);
                }
                if (nuclearWastePackage.Status == "RECEPTED")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包已接收!\"}", JsonRequestBehavior.AllowGet);
                }
                if (nuclearWastePackage.Status == "DEALED")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包已处置!\"}", JsonRequestBehavior.AllowGet);
                }
                if (nuclearWastePackage.Status == "UNCHECKED")
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包正在审核!\"}", JsonRequestBehavior.AllowGet);
                }
                //新增
                if (string.IsNullOrEmpty(model.DispsiteSpotCheck.SpotCheckId))
                {
                    //判断废物货包是否重复
                    if (this._DispsiteSpotCheckRepository.IsRepeat(model.DispsiteSpotCheck.PackageId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包重复。\"}", JsonRequestBehavior.AllowGet);
                    }

                    //新增抽检管理主单
                    model.DispsiteSpotCheck.SpotCheckId = Guid.NewGuid().ToString();
                    model.DispsiteSpotCheck.CreateDate = DateTime.Now;
                    model.DispsiteSpotCheck.CreateUserName = AppContext.CurrentUser.UserName;
                    model.DispsiteSpotCheck.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.DispsiteSpotCheck.Status = "1";
                    model.DispsiteSpotCheck.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._DispsiteSpotCheckRepository.Create(model.DispsiteSpotCheck);
                    if (!string.IsNullOrEmpty(model.DispsiteSpotChecks))
                    {
                        //新增抽检管理明细
                        string[] arrDispsiteSpotD = model.DispsiteSpotChecks.Split(';');
                        for (int i = 0; i < arrDispsiteSpotD.Length; i++)
                        {
                            DispsiteSpotDetail DispsiteSpotDetail = new DispsiteSpotDetail();
                            string[] arrDispsiteSpotDetail = arrDispsiteSpotD[i].Split(',');
                            if (arrDispsiteSpotDetail.Length == 3)
                            {
                                DispsiteSpotDetail.SpotDetailId = Guid.NewGuid().ToString();
                                DispsiteSpotDetail.SpotCheckId = model.DispsiteSpotCheck.SpotCheckId;
                                DispsiteSpotDetail.ElementId = arrDispsiteSpotDetail[0];
                                DispsiteSpotDetail.ElementValue = Convert.ToDecimal(arrDispsiteSpotDetail[2]);
                                this._DispsiteSpotDetailRepository.Create(DispsiteSpotDetail);
                            }
                        }
                    }
                    //提交
                    this._DispsiteSpotDetailRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                //修改完新增
                else
                {
                    //更新抽检管理
                    string newPackageId = model.DispsiteSpotCheck.PackageId;
                    //更新能谱库
                    model.DispsiteSpotCheck = _DispsiteSpotCheckRepository.Get(model.DispsiteSpotCheck.SpotCheckId);

                    //判断废物货包是否重复
                    if (model.DispsiteSpotCheck.PackageId != newPackageId && this._DispsiteSpotCheckRepository.IsRepeat(model.DispsiteSpotCheck.PackageId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包重复。\"}", JsonRequestBehavior.AllowGet);
                    }
                    UpdateModel(model);

                    //更新抽检管理
                    model.DispsiteSpotCheck = _DispsiteSpotCheckRepository.Get(model.DispsiteSpotCheck.SpotCheckId);
                    model.DispsiteSpotCheck.PackageId = packageId;
                    UpdateModel(model);
                    model.DispsiteSpotCheck.Status = "1";
                    if (string.IsNullOrEmpty(packageId))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.DispsiteSpotCheck.PackageId = packageId;

                    this._DispsiteSpotCheckRepository.Update(model.DispsiteSpotCheck);
                    //根据抽检管理ID查询抽检管理详细
                    IQueryable<DispsiteSpotDetail> data = this._DispsiteSpotDetailRepository.GetAll().AsQueryable();
                    List<DispsiteSpotDetail> listData = data.ToList();
                    //删除抽检管理详细的数据
                    foreach (var item in listData)
                    {
                        this._DispsiteSpotDetailRepository.DeleteById(item.SpotDetailId);
                    }

                    if (!string.IsNullOrEmpty(model.DispsiteSpotChecks))
                    {
                        //新增抽检管理明细
                        string[] arrDispsiteSpotD = model.DispsiteSpotChecks.Split(';');
                        for (int i = 0; i < arrDispsiteSpotD.Length; i++)
                        {
                            DispsiteSpotDetail DispsiteSpotDetail = new DispsiteSpotDetail();
                            string[] arrDispsiteSpotDetail = arrDispsiteSpotD[i].Split(',');
                            if (arrDispsiteSpotDetail.Length == 3)
                            {
                                DispsiteSpotDetail.SpotDetailId = Guid.NewGuid().ToString();
                                DispsiteSpotDetail.SpotCheckId = model.DispsiteSpotCheck.SpotCheckId;
                                DispsiteSpotDetail.ElementId = arrDispsiteSpotDetail[0];
                                DispsiteSpotDetail.ElementValue = Convert.ToDecimal(arrDispsiteSpotDetail[2]);
                                this._DispsiteSpotDetailRepository.Create(DispsiteSpotDetail);
                            }
                        }
                    }
                    this._DispsiteSpotCheckRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                this._DispsiteSpotDetailRepository.UnitOfWork.Commit();
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "抽检管理确认")]
        public JsonResult Confirm(DispsiteSpotCheckVm model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未通过验证!\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //判断废物货包是否存在 
                string packageId = this._NuclearWastePackageRepository.IsExistDispsiteSpotCheck(model.DispsiteSpotCheck.PackageId, AppContext.CurrentUser.ProjectCode);
                if (string.IsNullOrEmpty(packageId))
                {
                    return Json("{\"result\":false,\"msg\":\"该废物货包没有经过处置申请!\"}", JsonRequestBehavior.AllowGet);
                }
                model.DispsiteSpotCheck.PackageId = packageId;

                //判断废物货包是否通过审核
                NuclearWastePackage nuclearWastePackage = this._NuclearWastePackageRepository.Get(packageId);
                
                //新增
                if (string.IsNullOrEmpty(model.DispsiteSpotCheck.SpotCheckId))
                {
                    //判断废物货包是否重复
                    if (this._DispsiteSpotCheckRepository.IsRepeat(model.DispsiteSpotCheck.PackageId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包重复。\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (nuclearWastePackage.Status == "RETURN")
                    {
                        return Json("{\"result\":false,\"msg\":\"该废物货包已退回!\"}", JsonRequestBehavior.AllowGet);
                    }

                    if (nuclearWastePackage.Status == "CHECKED")
                    {
                        return Json("{\"result\":false,\"msg\":\"该废物货包已通过审核!\"}", JsonRequestBehavior.AllowGet);
                    }

                    if (nuclearWastePackage.Status == "APPLIED")
                    {
                        return Json("{\"result\":false,\"msg\":\"该废物货包已审批!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (nuclearWastePackage.Status == "RECEPTED")
                    {
                        return Json("{\"result\":false,\"msg\":\"该废物货包已接收!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (nuclearWastePackage.Status == "DEALED")
                    {
                        return Json("{\"result\":false,\"msg\":\"该废物货包已处置!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (nuclearWastePackage.Status == "UNCHECKED")
                    {
                        return Json("{\"result\":false,\"msg\":\"该废物货包正在审核!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //新增抽检管理主单
                    model.DispsiteSpotCheck.SpotCheckId = Guid.NewGuid().ToString();
                    model.DispsiteSpotCheck.CreateDate = DateTime.Now;
                    model.DispsiteSpotCheck.CreateUserName = AppContext.CurrentUser.UserName;
                    model.DispsiteSpotCheck.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.DispsiteSpotCheck.ConfirmDate = DateTime.Now;
                    model.DispsiteSpotCheck.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.DispsiteSpotCheck.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.DispsiteSpotCheck.Status = "2";
                    model.DispsiteSpotCheck.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._DispsiteSpotCheckRepository.Create(model.DispsiteSpotCheck);
                   
                    if (!string.IsNullOrEmpty(model.DispsiteSpotChecks))
                    {
                        //新增抽检管理明细
                        string[] arrDispsiteSpotD = model.DispsiteSpotChecks.Split(';');
                        for (int i = 0; i < arrDispsiteSpotD.Length; i++)
                        {
                            DispsiteSpotDetail DispsiteSpotDetail = new DispsiteSpotDetail();
                            string[] arrDispsiteSpotDetail = arrDispsiteSpotD[i].Split(',');
                            if (arrDispsiteSpotDetail.Length == 3)
                            {
                                DispsiteSpotDetail.SpotDetailId = Guid.NewGuid().ToString();
                                DispsiteSpotDetail.SpotCheckId = model.DispsiteSpotCheck.SpotCheckId;
                                DispsiteSpotDetail.ElementId = arrDispsiteSpotDetail[0];
                                DispsiteSpotDetail.ElementValue = Convert.ToDecimal(arrDispsiteSpotDetail[2]);
                                this._DispsiteSpotDetailRepository.Create(DispsiteSpotDetail);
                            }
                        }
                    }                   
                    DispsiteCheck dispsiteCheck = new DispsiteCheck();
                    DispsiteCheckDetail dispsiteCheckDetail = new DispsiteCheckDetail();
                    NuclearApplyDetail nuclearApplyDetail = new NuclearApplyDetail();
                    IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().AsQueryable().Where(c => c.BucketId == nuclearWastePackage.BucketId).AsQueryable();
                    foreach (var item in nuclearApplyDetailQuery)
                    {
                        item.Status = "1";
                        this._NuclearApplyDetailRepository.Update(item);
                    }

                    //提交
                    this._DispsiteSpotCheckRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                }
                //修改完新增
                else
                {
                    //更新抽检管理
                    string newPackageId = model.DispsiteSpotCheck.PackageId;
                    //更新能谱库
                    model.DispsiteSpotCheck = _DispsiteSpotCheckRepository.Get(model.DispsiteSpotCheck.SpotCheckId);

                    //判断废物货包是否重复
                    if (model.DispsiteSpotCheck.PackageId != newPackageId && this._DispsiteSpotCheckRepository.IsRepeat(model.DispsiteSpotCheck.PackageId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包重复。\"}", JsonRequestBehavior.AllowGet);
                    }
                    UpdateModel(model);

                    //更新抽检管理
                    model.DispsiteSpotCheck = _DispsiteSpotCheckRepository.Get(model.DispsiteSpotCheck.SpotCheckId);
                    model.DispsiteSpotCheck.PackageId = packageId;
                    UpdateModel(model);
                    model.DispsiteSpotCheck.Status = "2";
                    model.DispsiteSpotCheck.ConfirmDate = DateTime.Now;
                    model.DispsiteSpotCheck.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.DispsiteSpotCheck.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    if (string.IsNullOrEmpty(packageId))
                    {
                        return Json("{\"result\":false,\"msg\":\"废物货包不存在!\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.DispsiteSpotCheck.PackageId = packageId;

                    this._DispsiteSpotCheckRepository.Update(model.DispsiteSpotCheck);
                    //根据抽检管理ID查询抽检管理详细
                    IQueryable<DispsiteSpotDetail> data = this._DispsiteSpotDetailRepository.GetAll().AsQueryable();
                    List<DispsiteSpotDetail> listData = data.ToList();
                    //删除抽检管理详细的数据
                    foreach (var item in listData)
                    {
                        this._DispsiteSpotDetailRepository.DeleteById(item.SpotDetailId);
                    }

                    if (!string.IsNullOrEmpty(model.DispsiteSpotChecks))
                    {
                        //新增抽检管理明细
                        string[] arrDispsiteSpotD = model.DispsiteSpotChecks.Split(';');
                        for (int i = 0; i < arrDispsiteSpotD.Length; i++)
                        {
                            DispsiteSpotDetail DispsiteSpotDetail = new DispsiteSpotDetail();
                            string[] arrDispsiteSpotDetail = arrDispsiteSpotD[i].Split(',');
                            if (arrDispsiteSpotDetail.Length == 3)
                            {
                                DispsiteSpotDetail.SpotDetailId = Guid.NewGuid().ToString();
                                DispsiteSpotDetail.SpotCheckId = model.DispsiteSpotCheck.SpotCheckId;
                                DispsiteSpotDetail.ElementId = arrDispsiteSpotDetail[0];
                                DispsiteSpotDetail.ElementValue = Convert.ToDecimal(arrDispsiteSpotDetail[2]);
                                this._DispsiteSpotDetailRepository.Create(DispsiteSpotDetail);
                            }
                        }
                    }
                    //提交
                    this._DispsiteSpotDetailRepository.UnitOfWork.Commit();


                    //NuclearApplyDetail nuclearApplyDetail = new NuclearApplyDetail();
                    //IQueryable<NuclearApplyDetail> nuclearApplyDetailQuery = _NuclearApplyDetailRepository.GetAll().AsQueryable().Where(c => c.BucketId == nuclearWastePackage.BucketId).AsQueryable();
                    //foreach (var item in nuclearApplyDetailQuery)
                    //{
                    //    item.Status = "1";
                    //    this._NuclearApplyDetailRepository.Update(item);
                    //}
                    ////提交
                    //this._NuclearApplyDetailRepository.UnitOfWork.Commit();

                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }

            }
            catch
            {

                this._DispsiteSpotDetailRepository.UnitOfWork.Commit();
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(DispsiteSpotCheckVm model, FormCollection formCollection)
        {
            //判断废物货包是否存在 
            string packageId = this._NuclearWastePackageRepository.IsExist(model.DispsiteSpotCheck.PackageId, AppContext.CurrentUser.ProjectCode);
            if (string.IsNullOrEmpty(packageId))
            {
                return Json("{\"result\":false,\"msg\":\"该废物货包没有经过处置申请!\"}", JsonRequestBehavior.AllowGet);
            }
            model.DispsiteSpotCheck.PackageId = packageId;           
            try
            {
                model.DispsiteSpotCheck.SpotCheckId = model.DispsiteSpotDetail.SpotCheckId;
                model.DispsiteSpotCheck.Status = "0";//状态
                this._DispsiteSpotCheckRepository.Update(model.DispsiteSpotCheck);//提交数据库
                this._DispsiteSpotCheckRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除不符合项信息
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string SpotCheckId)
        {
            try
            {
                IQueryable<DispsiteSpotDetail> DetailIdQuery = _DispsiteSpotDetailRepository.QueryListDelete(SpotCheckId);
                List<DispsiteSpotDetail> DetailIdQueryList = DetailIdQuery.ToList();
                foreach (var items in DetailIdQueryList)
                {
                    this._DispsiteSpotDetailRepository.DeleteById(items.SpotDetailId);
                }
                this._DispsiteSpotCheckRepository.DeleteById(SpotCheckId);
                this._DispsiteSpotCheckRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        //自动填充控件-废物货包
        public JsonResult GetDataList(string keyword)
        {
            //数据源
            List<NuclearWastePackage> list = _NuclearWastePackageRepository.GetBuildPackageList(AppContext.CurrentUser.ProjectCode).Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count>0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].PackageCode;
                    autoComplete.Code = list[i].PackageId;
                    autoCompleteList.Add(autoComplete);
                }
            }
           
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
