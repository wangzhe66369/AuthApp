﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteTracking
{
    public class WasteTrackingAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "WasteTracking";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "WasteTracking_default",
                "WasteTracking/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
