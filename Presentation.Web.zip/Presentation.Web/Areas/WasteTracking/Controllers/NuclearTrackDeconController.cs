﻿/********************************************************************************
 *
 *   项目名称   ：   废物跟踪单
 *   文 件 名   ：   NuclearTrackDeconController.cs
 *   描    述   ：   去污申请单
 *   创 建 者   ：   PXMWAHY
 *   创建日期   ：   2016-01-29 11:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-01-29 11:00:00    1.0.0.0    PXMWAHY       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View.SourceManage;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.WasteTracking.Controllers
{
    public class NuclearTrackDeconController : Controller
    {
        INuclearTrackDeconRepository _NuclearTrackDeconRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        public NuclearTrackDeconController(INuclearTrackDeconRepository _NuclearTrackDeconRepository, IBasicObjectRepository _BasicObjectRepository,IBasicWasteUnitRepository _BasicWasteUnitRepository)
        {
            this._NuclearTrackDeconRepository = _NuclearTrackDeconRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "去污申请单列表")]
        public ActionResult Index()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Decon");
            //加载工作类型
            vm.WorkTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> workTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("WorkType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> workTypeList = new List<BasicObject>();
            if (workTypeQuery!=null && workTypeQuery.Count() > 0)
            {
                workTypeList = workTypeQuery.ToList();
                vm.WorkTypeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in workTypeList)
                {
                    vm.WorkTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            

            //加载状态
            vm.StatusList = new List<SelectListItem>();
            vm.StatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.StatusList.Add(new SelectListItem { Text = "草稿", Value = "0" });
            vm.StatusList.Add(new SelectListItem { Text = "未确认", Value = "1" });
            vm.StatusList.Add(new SelectListItem { Text = "已确认", Value = "2" });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                vm.StationCodeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            return View(vm);
        }
        public ActionResult Add()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Decon");
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });
            //加载质量安全
            vm.QualityFlagList = new List<SelectListItem>();
            vm.QualityFlagList.Add(new SelectListItem { Text = "QSR", Value = "0", Selected = true });
            vm.QualityFlagList.Add(new SelectListItem { Text = "QR", Value = "1" });
            vm.QualityFlagList.Add(new SelectListItem { Text = "NQR", Value = "2" });
            //加载污染时温度
            vm.PolluteTempFlagList = new List<SelectListItem>();
            vm.PolluteTempFlagList.Add(new SelectListItem { Text = "高于200℃", Value = "1", Selected = true });
            vm.PolluteTempFlagList.Add(new SelectListItem { Text = "低于200℃", Value = "0" });
            //加载去污后去向
            vm.DeconAfterFlagList = new List<SelectListItem>();
            vm.DeconAfterFlagList.Add(new SelectListItem { Text = "控制区内重新使用", Value = "0", Selected = true });
            vm.DeconAfterFlagList.Add(new SelectListItem { Text = "控制区外重新使用", Value = "1" });
            vm.DeconAfterFlagList.Add(new SelectListItem { Text = "出厂区", Value = "2" });
            //加载去污时需拆卸
            vm.DismountFlagList = new List<SelectListItem>();
            vm.DismountFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.DismountFlagList.Add(new SelectListItem { Text = "是", Value = "1" });
            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!= null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            NuclearTrackDecon nuclearTrackDecon = new NuclearTrackDecon();
            string simpleCode = "";
            if (stationList.Count() > 0)
            {
                simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationList[0].UnitId);
            }
            string demo = simpleCode + "DC" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackDeconRepository.GetAll().Where(d => d.DeconCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.DeconCode).First().DeconCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            nuclearTrackDecon.DeconCode = demo;
            vm.NuclearTrackDecon = nuclearTrackDecon;
            return View(vm);
        }
        public ActionResult DetailView(string id)
        {
            NuclearTrackDecon model = _NuclearTrackDeconRepository.Get(id);
            WasteTrackingVM vm = new WasteTrackingVM();
            BasicWasteUnit basicObjectStationcode = _BasicWasteUnitRepository.Get(model.StationId);
            if (basicObjectStationcode != null)
            {
                vm.StationCodeName = basicObjectStationcode.UnitName;
            }
            else {
                vm.StationCodeName = "";
            }
            vm.NuclearTrackDecon = model;
            #region 截取小数点位数
            ///如果数字类型不为空，截取小数点后三位
            if (vm.NuclearTrackDecon.EstimateWeight != null)
            {
                if (vm.NuclearTrackDecon.EstimateWeight.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.EstimateWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.EstimateWeight));
            }
            if (vm.NuclearTrackDecon.OriginalPolluteA != null)
            {
                if (vm.NuclearTrackDecon.OriginalPolluteA.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.OriginalPolluteA = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.OriginalPolluteA));
            }
            if (vm.NuclearTrackDecon.OriginalPolluteB != null)
            {
                if (vm.NuclearTrackDecon.OriginalPolluteB.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.OriginalPolluteB = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.OriginalPolluteB));
            }
            if (vm.NuclearTrackDecon.OriginalPolluteC != null)
            {
                if (vm.NuclearTrackDecon.OriginalPolluteC.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.OriginalPolluteC = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.OriginalPolluteC));
            }
            if (vm.NuclearTrackDecon.SurfaceDoseA != null)
            {
                if (vm.NuclearTrackDecon.SurfaceDoseA.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.SurfaceDoseA = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.SurfaceDoseA));
            }
            if (vm.NuclearTrackDecon.SurfaceDoseB != null)
            {
                if (vm.NuclearTrackDecon.SurfaceDoseB.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.SurfaceDoseB = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.SurfaceDoseB));
            }
            if (vm.NuclearTrackDecon.SurfaceDoseC != null)
            {
                if (vm.NuclearTrackDecon.SurfaceDoseC.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.SurfaceDoseC = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.SurfaceDoseC));
            }
            if (vm.NuclearTrackDecon.CollectiveDose != null)
            {
                if (vm.NuclearTrackDecon.CollectiveDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.CollectiveDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.CollectiveDose));
            }
            if (vm.NuclearTrackDecon.DeconWeight != null)
            {
                if (vm.NuclearTrackDecon.DeconWeight.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.DeconWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.DeconWeight));
            }
            if (vm.NuclearTrackDecon.DeconBrush != null)
            {
                if (vm.NuclearTrackDecon.DeconBrush.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.DeconBrush = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.DeconBrush));
            }
            if (vm.NuclearTrackDecon.DeconCloth != null)
            {
                if (vm.NuclearTrackDecon.DeconCloth.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.DeconCloth = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.DeconCloth));
            }
            if (vm.NuclearTrackDecon.DeconOthers != null)
            {
                if (vm.NuclearTrackDecon.DeconOthers.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.DeconOthers = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.DeconOthers));
            }
            if (vm.NuclearTrackDecon.PollutionLevel != null)
            {
                if (vm.NuclearTrackDecon.PollutionLevel.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.PollutionLevel = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.PollutionLevel));
            }
            if (vm.NuclearTrackDecon.SurfaceDose != null)
            {
                if (vm.NuclearTrackDecon.SurfaceDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.SurfaceDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.SurfaceDose));
            }
            #endregion
            return View("DetailView", vm);
        }
        public ActionResult Edit(string id)
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Decon");
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0" });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });
            //加载质量安全
            vm.QualityFlagList = new List<SelectListItem>();
            vm.QualityFlagList.Add(new SelectListItem { Text = "QSR", Value = "0", Selected = true });
            vm.QualityFlagList.Add(new SelectListItem { Text = "QR", Value = "1" });
            vm.QualityFlagList.Add(new SelectListItem { Text = "NQR", Value = "2" });
            //加载污染时温度
            vm.PolluteTempFlagList = new List<SelectListItem>();
            vm.PolluteTempFlagList.Add(new SelectListItem { Text = "高于200℃", Value = "1", Selected = true });
            vm.PolluteTempFlagList.Add(new SelectListItem { Text = "低于200℃", Value = "0" });
            //加载去污后去向
            vm.DeconAfterFlagList = new List<SelectListItem>();
            vm.DeconAfterFlagList.Add(new SelectListItem { Text = "控制区内重新使用", Value = "0", Selected = true });
            vm.DeconAfterFlagList.Add(new SelectListItem { Text = "控制区外重新使用", Value = "1" });
            vm.DeconAfterFlagList.Add(new SelectListItem { Text = "出厂区", Value = "2" });
            //加载去污时需拆卸
            vm.DismountFlagList = new List<SelectListItem>();
            vm.DismountFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.DismountFlagList.Add(new SelectListItem { Text = "是", Value = "1" });
            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null &&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            NuclearTrackDecon model = _NuclearTrackDeconRepository.Get(id);
            vm.NuclearTrackDecon = model;
            vm.TrackCode = model.DeconCode;
            #region 截取小数点位数
            ///如果数字类型不为空，截取小数点后三位
            if (vm.NuclearTrackDecon.EstimateWeight != null)
            {
                if (vm.NuclearTrackDecon.EstimateWeight.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.EstimateWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.EstimateWeight));
            }
            if (vm.NuclearTrackDecon.OriginalPolluteA != null)
            {
                if (vm.NuclearTrackDecon.OriginalPolluteA.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.OriginalPolluteA = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.OriginalPolluteA));
            }
            if (vm.NuclearTrackDecon.OriginalPolluteB != null)
            {
                if (vm.NuclearTrackDecon.OriginalPolluteB.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.OriginalPolluteB = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.OriginalPolluteB));
            }
            if (vm.NuclearTrackDecon.OriginalPolluteC != null)
            {
                if (vm.NuclearTrackDecon.OriginalPolluteC.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.OriginalPolluteC = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.OriginalPolluteC));
            }
            if (vm.NuclearTrackDecon.SurfaceDoseA != null)
            {
                if (vm.NuclearTrackDecon.SurfaceDoseA.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.SurfaceDoseA = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.SurfaceDoseA));
            }
            if (vm.NuclearTrackDecon.SurfaceDoseB != null)
            {
                if (vm.NuclearTrackDecon.SurfaceDoseB.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.SurfaceDoseB = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.SurfaceDoseB));
            }
            if (vm.NuclearTrackDecon.SurfaceDoseC != null)
            {
                if (vm.NuclearTrackDecon.SurfaceDoseC.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.SurfaceDoseC = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.SurfaceDoseC));
            }
            if (vm.NuclearTrackDecon.CollectiveDose != null)
            {
                if (vm.NuclearTrackDecon.CollectiveDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.CollectiveDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.CollectiveDose));
            }
            if (vm.NuclearTrackDecon.DeconWeight != null)
            {
                if (vm.NuclearTrackDecon.DeconWeight.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.DeconWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.DeconWeight));
            }
            if (vm.NuclearTrackDecon.DeconBrush != null)
            {
                if (vm.NuclearTrackDecon.DeconBrush.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.DeconBrush = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.DeconBrush));
            }
            if (vm.NuclearTrackDecon.DeconCloth != null)
            {
                if (vm.NuclearTrackDecon.DeconCloth.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.DeconCloth = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.DeconCloth));
            }
            if (vm.NuclearTrackDecon.DeconOthers != null)
            {
                if (vm.NuclearTrackDecon.DeconOthers.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.DeconOthers = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.DeconOthers));
            }
            if (vm.NuclearTrackDecon.PollutionLevel != null)
            {
                if (vm.NuclearTrackDecon.PollutionLevel.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.PollutionLevel = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.PollutionLevel));
            }
            if (vm.NuclearTrackDecon.SurfaceDose != null)
            {
                if (vm.NuclearTrackDecon.SurfaceDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackDecon.SurfaceDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackDecon.SurfaceDose));
            }
            #endregion
            return View(vm);
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNuclearTrackDeconList(NuclearTrackDeconCondition nuclearTrackDeconCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearTrackDeconView> data = this._NuclearTrackDeconRepository.QueryList(nuclearTrackDeconCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearTrackDeconView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DeconId,
                    List = new List<object>() {
                    d.DeconId,
                    d.DeconCode,
                    d.FunctionPosition,
                    d.WorkTicket,
                    d.MachineStatus,
                    d.DeconName,
                    d.CompleteDate.HasValue? d.CompleteDate.Value.ToString("yyyy-MM-dd"):string.Empty,               
                    d.Status,
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        [HttpPost]
        public JsonResult StationChange(string stationId)
        {
            string simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationId);
            string demo = simpleCode + "DC" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackDeconRepository.GetAll().Where(d => d.DeconCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.DeconCode).First().DeconCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            return Json("{\"result\":\"" + demo + "\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(WasteTrackingVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证通过。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //判断编号是否重复
                if (this._NuclearTrackDeconRepository.IsRepeat(model.NuclearTrackDecon.DeconCode, AppContext.CurrentUser.ProjectCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填写的编号已存在。\"}", JsonRequestBehavior.AllowGet);
                }
                model.NuclearTrackDecon.OriginalPolluteA = model.NuclearTrackDecon.OriginalPolluteA.HasValue ? model.NuclearTrackDecon.OriginalPolluteA : 0;
                model.NuclearTrackDecon.OriginalPolluteB = model.NuclearTrackDecon.OriginalPolluteB.HasValue ? model.NuclearTrackDecon.OriginalPolluteB : 0;
                model.NuclearTrackDecon.OriginalPolluteC = model.NuclearTrackDecon.OriginalPolluteC.HasValue ? model.NuclearTrackDecon.OriginalPolluteC : 0;
                model.NuclearTrackDecon.SurfaceDoseA = model.NuclearTrackDecon.SurfaceDoseA.HasValue ? model.NuclearTrackDecon.SurfaceDoseA : 0;
                model.NuclearTrackDecon.SurfaceDoseB = model.NuclearTrackDecon.SurfaceDoseB.HasValue ? model.NuclearTrackDecon.SurfaceDoseB : 0;
                model.NuclearTrackDecon.SurfaceDoseC = model.NuclearTrackDecon.SurfaceDoseC.HasValue ? model.NuclearTrackDecon.SurfaceDoseC : 0;
                model.NuclearTrackDecon.DeconId = Guid.NewGuid().ToString();
                model.NuclearTrackDecon.Status = "0";
                model.NuclearTrackDecon.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                model.NuclearTrackDecon.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                model.NuclearTrackDecon.CreateDate = DateTime.Now.Date;//创建时间
                model.NuclearTrackDecon.Stationcode = AppContext.CurrentUser.ProjectCode;
                this._NuclearTrackDeconRepository.Create(model.NuclearTrackDecon);
                this._NuclearTrackDeconRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet); 
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._NuclearTrackDeconRepository.DeleteById(idVal);
                    }
                    this._NuclearTrackDeconRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 编辑
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(WasteTrackingVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证通过。\"}", JsonRequestBehavior.AllowGet);
            }
            string newDeconCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackDecon.DeconCode != newDeconCode && this._NuclearTrackDeconRepository.IsRepeat(model.NuclearTrackDecon.DeconCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            model.NuclearTrackDecon = _NuclearTrackDeconRepository.Get(model.NuclearTrackDecon.DeconId);
            UpdateModel(model);
            try
            {
                model.NuclearTrackDecon.Status = "0";
                this._NuclearTrackDeconRepository.Update(model.NuclearTrackDecon);
                this._NuclearTrackDeconRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);                          
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(WasteTrackingVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证通过。\"}", JsonRequestBehavior.AllowGet);
            }
            string newDeconCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackDecon.DeconCode != newDeconCode && this._NuclearTrackDeconRepository.IsRepeat(model.NuclearTrackDecon.DeconCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            model.NuclearTrackDecon = _NuclearTrackDeconRepository.Get(model.NuclearTrackDecon.DeconId);
            UpdateModel(model);
            try
            {
                if (!string.IsNullOrEmpty(model.NuclearTrackDecon.DeconId))
                {
                    model.NuclearTrackDecon.Status = "1";
                    this._NuclearTrackDeconRepository.Update(model.NuclearTrackDecon);
                    this._NuclearTrackDeconRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else 
                {
                    if (this._NuclearTrackDeconRepository.IsRepeat(model.NuclearTrackDecon.DeconCode, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的编号已存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.NuclearTrackDecon.DeconId = Guid.NewGuid().ToString(); 
                    model.NuclearTrackDecon.Status = "1";
                    model.NuclearTrackDecon.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackDecon.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackDecon.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackDecon.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.NuclearTrackDecon.OriginalPolluteA = model.NuclearTrackDecon.OriginalPolluteA.HasValue ? model.NuclearTrackDecon.OriginalPolluteA : 0;
                    model.NuclearTrackDecon.OriginalPolluteB = model.NuclearTrackDecon.OriginalPolluteB.HasValue ? model.NuclearTrackDecon.OriginalPolluteB : 0;
                    model.NuclearTrackDecon.OriginalPolluteC = model.NuclearTrackDecon.OriginalPolluteC.HasValue ? model.NuclearTrackDecon.OriginalPolluteC : 0;
                    model.NuclearTrackDecon.SurfaceDoseA = model.NuclearTrackDecon.SurfaceDoseA.HasValue ? model.NuclearTrackDecon.SurfaceDoseA : 0;
                    model.NuclearTrackDecon.SurfaceDoseB = model.NuclearTrackDecon.SurfaceDoseB.HasValue ? model.NuclearTrackDecon.SurfaceDoseB : 0;
                    model.NuclearTrackDecon.SurfaceDoseC = model.NuclearTrackDecon.SurfaceDoseC.HasValue ? model.NuclearTrackDecon.SurfaceDoseC : 0;
                    this._NuclearTrackDeconRepository.Create(model.NuclearTrackDecon);
                    this._NuclearTrackDeconRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "去污申请单列表确认")]
        public JsonResult Confirm(WasteTrackingVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证通过。\"}", JsonRequestBehavior.AllowGet);
            }
            string newDeconCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackDecon.DeconCode != newDeconCode && this._NuclearTrackDeconRepository.IsRepeat(model.NuclearTrackDecon.DeconCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            model.NuclearTrackDecon = _NuclearTrackDeconRepository.Get(model.NuclearTrackDecon.DeconId);
            UpdateModel(model);
            try
            {
                if (!string.IsNullOrEmpty(model.NuclearTrackDecon.DeconId))
                {
                    model.NuclearTrackDecon.Status = "2";
                    model.NuclearTrackDecon.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearTrackDecon.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.NuclearTrackDecon.ConfirmDate = DateTime.Now;
                    this._NuclearTrackDeconRepository.Update(model.NuclearTrackDecon);
                    this._NuclearTrackDeconRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    if (this._NuclearTrackDeconRepository.IsRepeat(model.NuclearTrackDecon.DeconCode, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的编号已存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.NuclearTrackDecon.DeconId = Guid.NewGuid().ToString();
                    model.NuclearTrackDecon.Status = "1";
                    model.NuclearTrackDecon.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackDecon.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackDecon.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackDecon.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.NuclearTrackDecon.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearTrackDecon.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.NuclearTrackDecon.ConfirmDate = DateTime.Now;
                    model.NuclearTrackDecon.OriginalPolluteA = model.NuclearTrackDecon.OriginalPolluteA.HasValue ? model.NuclearTrackDecon.OriginalPolluteA : 0;
                    model.NuclearTrackDecon.OriginalPolluteB = model.NuclearTrackDecon.OriginalPolluteB.HasValue ? model.NuclearTrackDecon.OriginalPolluteB : 0;
                    model.NuclearTrackDecon.OriginalPolluteC = model.NuclearTrackDecon.OriginalPolluteC.HasValue ? model.NuclearTrackDecon.OriginalPolluteC : 0;
                    model.NuclearTrackDecon.SurfaceDoseA = model.NuclearTrackDecon.SurfaceDoseA.HasValue ? model.NuclearTrackDecon.SurfaceDoseA : 0;
                    model.NuclearTrackDecon.SurfaceDoseB = model.NuclearTrackDecon.SurfaceDoseB.HasValue ? model.NuclearTrackDecon.SurfaceDoseB : 0;
                    model.NuclearTrackDecon.SurfaceDoseC = model.NuclearTrackDecon.SurfaceDoseC.HasValue ? model.NuclearTrackDecon.SurfaceDoseC : 0;
                    this._NuclearTrackDeconRepository.Create(model.NuclearTrackDecon);
                    this._NuclearTrackDeconRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
    }
}
