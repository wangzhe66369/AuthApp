﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   NuclearTrackFilterController.cs
 *   描    述   ：   通风过滤器Controller
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View.SourceManage;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.WasteTracking.Controllers
{
    public class NuclearTrackFilterController : Controller
    {
        INuclearTrackFilterRepository _NuclearTrackFilterRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        IEquipInfoRepository _EquipInfoRepository;
        INuclearTrackTechSRepository _NuclearTrackTechSRepository;

        public NuclearTrackFilterController(INuclearTrackFilterRepository _NuclearTrackFilterRepository, IBasicObjectRepository _BasicObjectRepository, INuclearBucketRepository _NuclearBucketRepository, IBasicWasteUnitRepository _BasicWasteUnitRepository, INuclearTempstockRepository _NuclearTempstockRepository
            , IEquipInfoRepository _EquipInfoRepository, INuclearTrackTechSRepository _NuclearTrackTechSRepository)
        {
            this._NuclearTrackFilterRepository = _NuclearTrackFilterRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
            this._NuclearTempstockRepository = _NuclearTempstockRepository;
            this._EquipInfoRepository = _EquipInfoRepository;
            this._NuclearTrackTechSRepository = _NuclearTrackTechSRepository; 
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "通风过滤器列表")]
        public ActionResult Index()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Filter");
            //加载工作类型
            vm.WorkTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> workTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("WorkType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> workTypeList = new List<BasicObject>();
            if (workTypeQuery!=null&&workTypeQuery.Count() > 0)
            {
                workTypeList = workTypeQuery.ToList();
                vm.WorkTypeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in workTypeList)
                {
                    vm.WorkTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            string locationId = Request["locationId"];
            ViewBag.Location = locationId;
            string bucketId = Request["bucketId"];
            ViewBag.BucketId = bucketId;
            //加载状态
            vm.StatusList = new List<SelectListItem>();
            vm.StatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.StatusList.Add(new SelectListItem { Text = "草稿", Value = "0" });
            vm.StatusList.Add(new SelectListItem { Text = "未确认", Value = "1" });
            vm.StatusList.Add(new SelectListItem { Text = "已确认", Value = "2" });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                vm.StationCodeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null && storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
               
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
         
            return View(vm);
        }
        public ActionResult Add()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Filter");
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });

            //加载处理方式
            vm.ProcessModeFlagList = new List<SelectListItem>();
            vm.ProcessModeFlagList.Add(new SelectListItem { Text = "暂存", Value = "1", Selected = true });
            vm.ProcessModeFlagList.Add(new SelectListItem { Text = "非放", Value = "0" });

            //加载吸入新鲜空气
            vm.ClearAirFlagList = new List<SelectListItem>();
            vm.ClearAirFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.ClearAirFlagList.Add(new SelectListItem { Text = "是", Value = "1" });

            //加载非放射性过滤器
            vm.FilterFlagNoList = new List<SelectListItem>();
            vm.FilterFlagNoList.Add(new SelectListItem { Text = "非放射性过滤器", Value = "0", Selected = true });

            //加载放射性过滤器
            vm.FilterFlagYesList = new List<SelectListItem>();
            vm.FilterFlagYesList.Add(new SelectListItem { Text = "放射性过滤器", Value = "1" });

            //加载过滤器类型
            vm.FilterTypeList = new List<SelectListItem>();
            vm.FilterTypeList.Add(new SelectListItem { Text = "预过滤器(FP)", Value = "FP", Selected = true });
            vm.FilterTypeList.Add(new SelectListItem { Text = "高效过滤器(FA)", Value = "FA" });
            vm.FilterTypeList.Add(new SelectListItem { Text = "碘过滤器(PI)", Value = "PI" });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();

                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null&&storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                vm.StoragePositionIdList.Add(new SelectListItem { Text = "请选择", Value = string.Empty });
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            NuclearTrackFilter nuclearTrackFilter = new NuclearTrackFilter();
            string simpleCode = "";
            if (stationList.Count() > 0)
            {
                simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationList[0].UnitId);
            }
            string demo = simpleCode + "AF" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackFilterRepository.GetAll().Where(d => d.FilterCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.FilterCode).First().FilterCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            nuclearTrackFilter.FilterCode = demo;
            vm.NuclearTrackFilter = nuclearTrackFilter;
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);
        }
        public ActionResult DetailView(string id)
        {
            ViewBag.ViewStatus = Request["status"];
            NuclearTrackFilter model = _NuclearTrackFilterRepository.Get(id);
            WasteTrackingVM vm = new WasteTrackingVM();
            BasicWasteUnit basicObjectStationcode = _BasicWasteUnitRepository.Get(model.StationId);
            BasicObject basicObjectStoragePositionId = _BasicObjectRepository.Get(model.StoragePositionId);
            if (basicObjectStationcode != null)
            {
                vm.StationCodeName = basicObjectStationcode.UnitName;
            }
            else {
                vm.StationCodeName = "";
            }
            if (basicObjectStoragePositionId != null)
            {
                vm.StoragePositionName = basicObjectStoragePositionId.Name;
            }
            else {
                vm.StoragePositionName = "";
            }
            if (!string.IsNullOrEmpty(model.StorageContainerId))
            {
                NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(model.StorageContainerId);
                if (nuclearBucket != null)
                {
                    model.StorageContainerId = nuclearBucket.BucketCode;
                }
                else
                {
                    model.StorageContainerId = "";
                }
            }
            vm.NuclearTrackFilter = model;
            ///如果数字类型不为空，截取小数点后三位
            if (vm.NuclearTrackFilter.DownFilterUnit != null)
            {
                if (vm.NuclearTrackFilter.DownFilterUnit.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackFilter.DownFilterUnit = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackFilter.DownFilterUnit));
            }
            if (vm.NuclearTrackFilter.SingleWeight != null)
            {
                if (vm.NuclearTrackFilter.SingleWeight.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackFilter.SingleWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackFilter.SingleWeight));
            }
            if (vm.NuclearTrackFilter.Bulk != null)
            {
                if (vm.NuclearTrackFilter.Bulk.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackFilter.Bulk = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackFilter.Bulk));
            }
            if (vm.NuclearTrackFilter.SurfaceDose != null)
            {
                if (vm.NuclearTrackFilter.SurfaceDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackFilter.SurfaceDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackFilter.SurfaceDose));
            }
            return View("DetailView", vm);
        }
        public ActionResult Edit(string id)
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Filter");
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0" });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });

            //加载处理方式
            vm.ProcessModeFlagList = new List<SelectListItem>();
            vm.ProcessModeFlagList.Add(new SelectListItem { Text = "暂存", Value = "1", Selected = true });
            vm.ProcessModeFlagList.Add(new SelectListItem { Text = "非放", Value = "0" });

            //加载吸入新鲜空气
            vm.ClearAirFlagList = new List<SelectListItem>();
            vm.ClearAirFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.ClearAirFlagList.Add(new SelectListItem { Text = "是", Value = "1" });

            //加载非放射性过滤器
            vm.FilterFlagNoList = new List<SelectListItem>();
            vm.FilterFlagNoList.Add(new SelectListItem { Text = "非放射性过滤器", Value = "0", Selected = true });

            //加载放射性过滤器
            vm.FilterFlagYesList = new List<SelectListItem>();
            vm.FilterFlagYesList.Add(new SelectListItem { Text = "放射性过滤器", Value = "1" });

            //加载过滤器类型
            vm.FilterTypeList = new List<SelectListItem>();
            vm.FilterTypeList.Add(new SelectListItem { Text = "预过滤器(FP)", Value = "FP", Selected = true });
            vm.FilterTypeList.Add(new SelectListItem { Text = "高效过滤器(FA)", Value = "FA" });
            vm.FilterTypeList.Add(new SelectListItem { Text = "碘过滤器(PI)", Value = "PI" });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null&&storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                vm.StoragePositionIdList.Add(new SelectListItem { Text = "请选择", Value = string.Empty });
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            NuclearTrackFilter model = _NuclearTrackFilterRepository.Get(id);
            if (!string.IsNullOrEmpty(model.StorageContainerId))
            {
                NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(model.StorageContainerId);
                if (nuclearBucket != null)
                {
                    model.StorageContainerId = nuclearBucket.BucketCode;
                }
                else
                {
                    model.StorageContainerId = "";
                }
            }
            vm.NuclearTrackFilter = model;
            vm.NewStoragePositionId = model.StoragePositionId;
            vm.TrackCode = model.FilterCode;
            ///如果数字类型不为空，截取小数点后三位
            if (vm.NuclearTrackFilter.DownFilterUnit != null)
            {
                if (vm.NuclearTrackFilter.DownFilterUnit.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackFilter.DownFilterUnit = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackFilter.DownFilterUnit));
            }
            if (vm.NuclearTrackFilter.SingleWeight != null)
            {
                if (vm.NuclearTrackFilter.SingleWeight.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackFilter.SingleWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackFilter.SingleWeight));
            }
            if (vm.NuclearTrackFilter.Bulk != null)
            {
                if (vm.NuclearTrackFilter.Bulk.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackFilter.Bulk = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackFilter.Bulk));
            }
            if (vm.NuclearTrackFilter.SurfaceDose != null)
            {
                if (vm.NuclearTrackFilter.SurfaceDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackFilter.SurfaceDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackFilter.SurfaceDose));
            }
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNuclearTrackFilterList(NuclearTrackFilterCondition nuclearTrackFilterCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearTrackFilterView> data = this._NuclearTrackFilterRepository.QueryList(nuclearTrackFilterCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            string locationId = Request["locationId"];
            if (!string.IsNullOrEmpty(locationId))
                data = data.Where(n => n.StoragePositionId == locationId);
            string bucketId = Request["bucketId"];
            if (!string.IsNullOrEmpty(bucketId))
                data = data.Where(n => n.BucketId == bucketId);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearTrackFilterView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.FilterId,
                    List = new List<object>() {
                    d.FilterId,
                    d.FilterCode,
                    d.SystemCode,
                    d.WorkTicket,
                    d.FilterType,
                    d.DownFilterUnit,
                    d.StoragePositionIds,
                    d.StorageContainerId,
                    d.Bulk,                                        
                    d.ControlName,
                    d.ControlDate.HasValue? d.ControlDate.Value.ToString("yyyy-MM-dd"):string.Empty,
                    d.Status,
                    d.DealStatus
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        [HttpPost]
        public JsonResult StationChange(string stationId)
        {
            string simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationId);
            string demo = simpleCode + "AF" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackFilterRepository.GetAll().Where(d => d.FilterCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.FilterCode).First().FilterCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            return Json("{\"result\":\"" + demo + "\"}", JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult GetBucketCode(string bucketCode)
        {
            Nullable<double> bucketCodeNum = 0;
            List<NuclearBucket> NuclearBucket = new List<NuclearBucket>();
            IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).AsQueryable();
            if (nuclearBucket != null && nuclearBucket.Count() > 0)
            {
                NuclearBucket = nuclearBucket.ToList();
            }
            string bucketId = null;
            if (NuclearBucket.Count() > 0)
            {
                bucketId = NuclearBucket[0].BucketId;
                List<NuclearTrackFilter> nuclearTrackFilter = _NuclearTrackFilterRepository.GetAll().Where(d => d.StorageContainerId == bucketId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                bucketCodeNum = nuclearTrackFilter.Count();
            }
            return Json("{\"bucketCodeNum\":\"" + bucketCodeNum + "\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 新增通风过滤器
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(WasteTrackingVM model, FormCollection formCollection)
        {
            try
            {
                //判断编号是否重复
                if (this._NuclearTrackFilterRepository.IsRepeat(model.NuclearTrackFilter.FilterCode, AppContext.CurrentUser.ProjectCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
                }
                bool bucketCode = false;
                if (model.NuclearTrackFilter.StorageContainerId != null)
                {
                    //判断桶号是否存在 
                    string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号"+ model.NuclearTrackFilter.StorageContainerId +"不正确!\"}", JsonRequestBehavior.AllowGet);
                    }
                    string existFactory = _NuclearBucketRepository.IsExistByFactory(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode, model.NuclearTrackFilter.StoragePositionId);
                    if (string.IsNullOrEmpty(existFactory))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不在所选厂房中!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    int num = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (num > 0)
                    {
                        bucketCode = true;
                    }
                    model.NuclearTrackFilter.BucketId = bucketId;
                    model.NuclearTrackFilter.StorageContainerId = bucketId;
                }
                model.NuclearTrackFilter.FilterId = Guid.NewGuid().ToString();
                model.NuclearTrackFilter.Status = "0";
                model.NuclearTrackFilter.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                model.NuclearTrackFilter.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                model.NuclearTrackFilter.CreateDate = DateTime.Now.Date;//创建时间
                model.NuclearTrackFilter.Stationcode = AppContext.CurrentUser.ProjectCode;
                this._NuclearTrackFilterRepository.Create(model.NuclearTrackFilter);
                this._NuclearTrackFilterRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除通风过滤器
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    NuclearTrackFilter nuclearTrackFilter = this._NuclearTrackFilterRepository.Get(id);
                    if (nuclearTrackFilter.Status == "2")
                    {
                        if (nuclearTrackFilter.DealStatus == "1")
                        {
                            return Json("{\"result\":false,\"msg\":\"删除失败，该条源项废物已被处理。\"}", JsonRequestBehavior.AllowGet);
                        }
                        _NuclearTempstockRepository.MergeWasteTmpStock("FILTER", nuclearTrackFilter.StoragePositionId, AppContext.CurrentUser.ProjectCode, -1);
                    }
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._NuclearTrackFilterRepository.DeleteById(idVal);
                    }
                    this._NuclearTrackFilterRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 提交处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SubmitDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearTrackFilter nuclearTrackFilter = this._NuclearTrackFilterRepository.Get(idVal);
                        nuclearTrackFilter.DealStatus = "0";
                        this._NuclearTrackFilterRepository.Update(nuclearTrackFilter);
                    }
                    this._NuclearTrackFilterRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ConfirmDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearTrackFilter nuclearTrackFilter = this._NuclearTrackFilterRepository.Get(idVal);
                        nuclearTrackFilter.DealStatus = "1";
                        this._NuclearTrackFilterRepository.Update(nuclearTrackFilter);
                    }
                    this._NuclearTrackFilterRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确认处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 编辑通风过滤器
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(WasteTrackingVM model, FormCollection formCollection)
        {
            string newFilterCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackFilter.FilterCode != newFilterCode && this._NuclearTrackFilterRepository.IsRepeat(model.NuclearTrackFilter.FilterCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                bool bucketCode = false;
                if (model.NuclearTrackFilter.StorageContainerId != null)
                {
                    //判断桶号是否存在 
                    string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                    }
                    string existFactory = _NuclearBucketRepository.IsExistByFactory(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode, model.NuclearTrackFilter.StoragePositionId);
                    if (string.IsNullOrEmpty(existFactory))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不在所选厂房中!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    int num = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (num > 1)
                    {
                        bucketCode = true;
                    }
                    model.NuclearTrackFilter.BucketId = bucketId;
                    model.NuclearTrackFilter.StorageContainerId = bucketId;
                }
                model.NuclearTrackFilter.Status = "0";
                model.NuclearTrackFilter.Stationcode = AppContext.CurrentUser.ProjectCode;
                this._NuclearTrackFilterRepository.Update(model.NuclearTrackFilter);
                this._NuclearTrackFilterRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);    
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(WasteTrackingVM model, FormCollection formCollection)
        {
            string newFilterCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackFilter.FilterCode != newFilterCode && this._NuclearTrackFilterRepository.IsRepeat(model.NuclearTrackFilter.FilterCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                bool bucketCode = false;
                //编辑提交
                if (model.NuclearTrackFilter.FilterId != null)
                {
                    if (model.NuclearTrackFilter.StorageContainerId != null)
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        string existFactory = _NuclearBucketRepository.IsExistByFactory(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode, model.NuclearTrackFilter.StoragePositionId);
                        if (string.IsNullOrEmpty(existFactory))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不在所选厂房中!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 1)
                        {
                            bucketCode = true;
                        }
                        model.NuclearTrackFilter.BucketId = bucketId;
                        model.NuclearTrackFilter.StorageContainerId = bucketId;
                    }
                    model.NuclearTrackFilter.Status = "1";
                    model.NuclearTrackFilter.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackFilterRepository.Update(model.NuclearTrackFilter);
                    this._NuclearTrackFilterRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                //新增提交
                else if (model.NuclearTrackFilter.FilterId == null)
                {
                    if (model.NuclearTrackFilter.StorageContainerId != null)
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        string existFactory = _NuclearBucketRepository.IsExistByFactory(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode, model.NuclearTrackFilter.StoragePositionId);
                        if (string.IsNullOrEmpty(existFactory))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不在所选厂房中!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 0)
                        {
                            bucketCode = true;
                        }
                        model.NuclearTrackFilter.BucketId = bucketId;
                        model.NuclearTrackFilter.StorageContainerId = bucketId;
                    }
                    model.NuclearTrackFilter.FilterId = Guid.NewGuid().ToString();
                    model.NuclearTrackFilter.Status = "1";
                    model.NuclearTrackFilter.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackFilter.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackFilter.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackFilter.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackFilterRepository.Create(model.NuclearTrackFilter);
                    this._NuclearTrackFilterRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "通风过滤器列表确认")]
        public JsonResult Confirm(WasteTrackingVM model, FormCollection formCollection)
        {
            string newFilterCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackFilter.FilterCode != newFilterCode && this._NuclearTrackFilterRepository.IsRepeat(model.NuclearTrackFilter.FilterCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                bool bucketCode = false;
                //编辑确认
                if (model.NuclearTrackFilter.FilterId != null)
                {
                    if (model.NuclearTrackFilter.StorageContainerId != null)
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        string existFactory = _NuclearBucketRepository.IsExistByFactory(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode, model.NuclearTrackFilter.StoragePositionId);
                        if (string.IsNullOrEmpty(existFactory))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不在所选厂房中!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 1)
                        {
                            bucketCode = true;
                        }
                      //  _NuclearBucketRepository.UpdateBucketWasteType(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode, "过滤器","");
                        model.NuclearTrackFilter.BucketId = bucketId;
                        model.NuclearTrackFilter.StorageContainerId = bucketId;
                    }
                    else
                    {
                        if (model.NuclearTrackFilter.Status != "2")
                        {
                            _NuclearTempstockRepository.MergeWasteTmpStock("FILTER", model.NuclearTrackFilter.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                        }
                        else
                        {
                            if (model.NuclearTrackFilter.StoragePositionId != model.NewStoragePositionId) {
                                _NuclearTempstockRepository.MergeWasteTmpStock("FILTER", model.NewStoragePositionId, AppContext.CurrentUser.ProjectCode, -1);
                                _NuclearTempstockRepository.MergeWasteTmpStock("FILTER", model.NuclearTrackFilter.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                            }
                        }
                    }
                    model.NuclearTrackFilter.Status = "2";
                    model.NuclearTrackFilter.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.NuclearTrackFilter.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearTrackFilter.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.NuclearTrackFilter.ConfirmDate = DateTime.Now.Date;
                    //model.NuclearTrackFilter.DealStatus = "0";
                    this._NuclearTrackFilterRepository.Update(model.NuclearTrackFilter);

                    IQueryable<EquipInfo> FunctionPositionQuery = _NuclearTrackFilterRepository.QueryListByFunctionPosition(model.NuclearTrackFilter.SystemCode, AppContext.CurrentUser.ProjectCode);
                    List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                    if (FunctionPositionQuery.Count() != 0)
                    {
                        foreach (var itemList in FunctionPositionQueryList)
                        {
                            EquipInfo equipInfo = this._EquipInfoRepository.Get(itemList.EquipId);
                            if (model.NuclearTrackFilter.FilterType == "FP")
                            {
                                equipInfo.EquipSpec = "预过滤器(FP)";
                            }
                            if (model.NuclearTrackFilter.FilterType == "FA")
                            {
                                equipInfo.EquipSpec = "高效过滤器(FA)";
                            }
                            if (model.NuclearTrackFilter.FilterType == "PI")
                            {
                                equipInfo.EquipSpec = "碘过滤器(PI)";
                            }
                           // equipInfo.UpdateDate = model.NuclearTrackFilter.ConfirmDate;
                            this._EquipInfoRepository.Update(equipInfo);//提交数据库  
                        }
                    }
                    this._NuclearTrackFilterRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                //新增确认
                else if (model.NuclearTrackFilter.FilterId == null)
                {
                    if (model.NuclearTrackFilter.StorageContainerId != null)
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        string existFactory = _NuclearBucketRepository.IsExistByFactory(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode, model.NuclearTrackFilter.StoragePositionId);
                        if (string.IsNullOrEmpty(existFactory))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "不在所选厂房中!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器编号" + model.NuclearTrackFilter.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 0)
                        {
                            bucketCode = true;
                        }
                       // _NuclearBucketRepository.UpdateBucketWasteType(model.NuclearTrackFilter.StorageContainerId, AppContext.CurrentUser.ProjectCode, "过滤器","");
                        model.NuclearTrackFilter.BucketId = bucketId;
                        model.NuclearTrackFilter.StorageContainerId = bucketId;
                    }
                    else
                    {
                        _NuclearTempstockRepository.MergeWasteTmpStock("FILTER", model.NuclearTrackFilter.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                    }
                    model.NuclearTrackFilter.FilterId = Guid.NewGuid().ToString();
                    model.NuclearTrackFilter.Status = "2";
                    model.NuclearTrackFilter.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackFilter.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackFilter.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackFilter.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.NuclearTrackFilter.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearTrackFilter.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.NuclearTrackFilter.ConfirmDate = DateTime.Now;
                    //model.NuclearTrackFilter.DealStatus = "0";
                    this._NuclearTrackFilterRepository.Create(model.NuclearTrackFilter);

                    IQueryable<EquipInfo> FunctionPositionQuery = _NuclearTrackFilterRepository.QueryListByFunctionPosition(model.NuclearTrackFilter.SystemCode, AppContext.CurrentUser.ProjectCode);
                    List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                    if (FunctionPositionQuery.Count() != 0)
                    {
                        foreach (var itemList in FunctionPositionQueryList)
                        {
                            EquipInfo equipInfo = this._EquipInfoRepository.Get(itemList.EquipId);
                            if (model.NuclearTrackFilter.FilterType == "FP")
                            {
                                equipInfo.EquipSpec = "预过滤器(FP)";
                            }
                            if (model.NuclearTrackFilter.FilterType == "FA")
                            {
                                equipInfo.EquipSpec = "高效过滤器(FA)";
                            }
                            if (model.NuclearTrackFilter.FilterType == "PI")
                            {
                                equipInfo.EquipSpec = "碘过滤器(PI)";
                            }
                            //equipInfo.UpdateDate = model.NuclearTrackFilter.ConfirmDate;
                            this._EquipInfoRepository.Update(equipInfo);//提交数据库  
                        }
                    }
                    this._NuclearTrackFilterRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        //获得所有桶号
        public JsonResult GetDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            if (keyword.ToUpper().Trim() != null && keyword.ToUpper().Trim() != "")
            {
                IQueryable<NuclearBucket> iqueryNuclearBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsOutSend == "0" || e.IsOutSend == null));

                if (iqueryNuclearBucket.Count() > 0)
                {
                    list = iqueryNuclearBucket.ToList();
                }
            } 
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
       
    }
}
