﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   NuclearTrackSundryController.cs
 *   描    述   ：   杂项Controller
 *   创 建 者   ：   PXMWAHY 安洪岩
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0     安洪岩       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View.SourceManage;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.WasteTracking.Controllers
{
    public class NuclearTrackSundryController : Controller
    {
        INuclearTrackSundryRepository _NuclearTrackSundryRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        INuclearTrackTechSRepository _NuclearTrackTechSRepository;
        INuclearTrackTechBRepository _NuclearTrackTechBRepository;
        public NuclearTrackSundryController(INuclearTrackSundryRepository _NuclearTrackSundryRepository, IBasicObjectRepository _BasicObjectRepository, INuclearBucketRepository _NuclearBucketRepository, IBasicWasteUnitRepository _BasicWasteUnitRepository,
            INuclearTrackTechSRepository _NuclearTrackTechSRepository, INuclearTrackTechBRepository _NuclearTrackTechBRepository)
        {
            this._NuclearTrackSundryRepository = _NuclearTrackSundryRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
            this._NuclearTrackTechSRepository = _NuclearTrackTechSRepository;
            this._NuclearTrackTechBRepository = _NuclearTrackTechBRepository;  
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "杂项")]
        public ActionResult Index()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Sundry");
            //加载工作类型
            vm.WorkTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> workTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("WorkType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> workTypeList = new List<BasicObject>();
            if (workTypeQuery!=null&&workTypeQuery.Count() > 0)
            {
                workTypeList = workTypeQuery.ToList();
                vm.WorkTypeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in workTypeList)
                {
                    vm.WorkTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            

            //加载状态
            vm.StatusList = new List<SelectListItem>();
            vm.StatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.StatusList.Add(new SelectListItem { Text = "草稿", Value = "0" });
            vm.StatusList.Add(new SelectListItem { Text = "未确认", Value = "1" });
            vm.StatusList.Add(new SelectListItem { Text = "已确认", Value = "2" });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                vm.StationCodeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
           
            return View(vm);
        }
        public ActionResult Add()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Sundry");
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });
            //加载废物类型
            vm.WasteTypeList = new List<SelectListItem>();
            vm.WasteTypeList.Add(new SelectListItem { Text = "极低放废物", Value = "LowLevelL", Selected = true });
            vm.WasteTypeList.Add(new SelectListItem { Text = "废钢铁", Value = "ScrapSteel" });
            vm.WasteTypeList.Add(new SelectListItem { Text = "劳保用品", Value = "Labor" });
            vm.WasteTypeList.Add(new SelectListItem { Text = "其他", Value = "Other" });
            //加载是否拆解
            vm.DismantleFlagList = new List<SelectListItem>();
            vm.DismantleFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.DismantleFlagList.Add(new SelectListItem { Text = "是", Value = "1" });
            //加载是否冶炼
            vm.SmeltFlagList = new List<SelectListItem>();
            vm.SmeltFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.SmeltFlagList.Add(new SelectListItem { Text = "是", Value = "1" });
            //加载是否沾污
            vm.SullyFlagList = new List<SelectListItem>();
            vm.SullyFlagList.Add(new SelectListItem { Text = "无", Value = "0", Selected = true });
            vm.SullyFlagList.Add(new SelectListItem { Text = "有", Value = "1" });
            //加载存储方式—暂存包装容器
            vm.PackContainerList = new List<SelectListItem>();
            vm.PackContainerList.Add(new SelectListItem { Text = "暂存包装容器", Value = "0"});
            //暂存位置
            vm.FactoryList = new List<SelectListItem>();
            vm.FactoryList.Add(new SelectListItem { Text = "暂存厂房", Value = "1", Selected = true });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null&&storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            NuclearTrackSundry nuclearTrackSundry = new NuclearTrackSundry();
            string simpleCode = "";
            if (stationList.Count() > 0)
            {
                simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationList[0].UnitId);
            }
            string demo = simpleCode + "MW" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackSundryRepository.GetAll().Where(d => d.SundryCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.SundryCode).First().SundryCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            nuclearTrackSundry.SundryCode = demo;
            vm.NuclearTrackSundry = nuclearTrackSundry;
            return View(vm);
        }
        public ActionResult DetailView(string id)
        {
            NuclearTrackSundry model = _NuclearTrackSundryRepository.Get(id);
            WasteTrackingVM vm = new WasteTrackingVM();
            BasicWasteUnit basicObjectStationcode = _BasicWasteUnitRepository.Get(model.StationId);
            BasicObject basicObjectStoragePositionId = _BasicObjectRepository.Get(model.StoragePositionId);
            if (basicObjectStationcode != null)
            {
                vm.StationCodeName = basicObjectStationcode.UnitName;
            }
            else {
                vm.StationCodeName = "";
            }
            if (basicObjectStoragePositionId != null)
            {
                vm.StoragePositionName = basicObjectStoragePositionId.Name;
            }
            else {
                vm.StoragePositionName = "";
            }
            if (!string.IsNullOrEmpty(model.StorageContainerId))
            {
                NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(model.StorageContainerId);
                if (nuclearBucket != null)
                {
                    model.StorageContainerId = nuclearBucket.BucketCode;
                }
                else
                {
                    model.StorageContainerId = "";
                }
            }
            vm.NuclearTrackSundry = model;
            ///如果数字类型不为空，截取小数点后三位
            if (vm.NuclearTrackSundry.WasteQuantity != null)
            {
                if (vm.NuclearTrackSundry.WasteQuantity.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackSundry.WasteQuantity = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackSundry.WasteQuantity));
            }
            if (vm.NuclearTrackSundry.WasteBulk != null)
            {
                if (vm.NuclearTrackSundry.WasteBulk.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackSundry.WasteBulk = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackSundry.WasteBulk));
            }
            if (vm.NuclearTrackSundry.SullyValue != null)
            {
                if (vm.NuclearTrackSundry.SullyValue.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackSundry.SullyValue = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackSundry.SullyValue));
            }
            if (vm.NuclearTrackSundry.SurfaceDose != null)
            {
                if (vm.NuclearTrackSundry.SurfaceDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackSundry.SurfaceDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackSundry.SurfaceDose));
            }
            if (vm.NuclearTrackSundry.EvaDose != null)
            {
                if (vm.NuclearTrackSundry.EvaDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackSundry.EvaDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackSundry.EvaDose));
            }
            return View("DetailView", vm);
        }
        public ActionResult Edit(string id)
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Sundry");
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0" });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });
            //加载废物类型
            vm.WasteTypeList = new List<SelectListItem>();
            vm.WasteTypeList.Add(new SelectListItem { Text = "极低放废物", Value = "LowLevelL", Selected = true });
            vm.WasteTypeList.Add(new SelectListItem { Text = "废钢铁", Value = "ScrapSteel" });
            vm.WasteTypeList.Add(new SelectListItem { Text = "劳保用品", Value = "Labor" });
            vm.WasteTypeList.Add(new SelectListItem { Text = "其他", Value = "Other" });
            //加载是否拆解
            vm.DismantleFlagList = new List<SelectListItem>();
            vm.DismantleFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.DismantleFlagList.Add(new SelectListItem { Text = "是", Value = "1" });
            //加载是否冶炼
            vm.SmeltFlagList = new List<SelectListItem>();
            vm.SmeltFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.SmeltFlagList.Add(new SelectListItem { Text = "是", Value = "1" });
            //加载是否沾污
            vm.SullyFlagList = new List<SelectListItem>();
            vm.SullyFlagList.Add(new SelectListItem { Text = "无", Value = "0", Selected = true });
            vm.SullyFlagList.Add(new SelectListItem { Text = "有", Value = "1" });
            //加载存储方式—暂存包装容器
            vm.PackContainerList = new List<SelectListItem>();
            vm.PackContainerList.Add(new SelectListItem { Text = "暂存包装容器", Value = "0"});
            //暂存位置
            vm.FactoryList = new List<SelectListItem>();
            vm.FactoryList.Add(new SelectListItem { Text = "暂存厂房", Value = "1", Selected = true });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null&&storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            NuclearTrackSundry model = _NuclearTrackSundryRepository.Get(id);
            if (!string.IsNullOrEmpty(model.StorageContainerId))
            {
                NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(model.StorageContainerId);
                if (nuclearBucket != null)
                {
                    model.StorageContainerId = nuclearBucket.BucketCode;
                }
                else
                {
                    model.StorageContainerId = "";
                }
            }
            vm.NuclearTrackSundry = model;
            vm.TrackCode = model.SundryCode;
            ///如果数字类型不为空，截取小数点后三位
            if (vm.NuclearTrackSundry.WasteQuantity != null)
            {
                if (vm.NuclearTrackSundry.WasteQuantity.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackSundry.WasteQuantity = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackSundry.WasteQuantity));
            }
            if (vm.NuclearTrackSundry.WasteBulk != null)
            {
                if (vm.NuclearTrackSundry.WasteBulk.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackSundry.WasteBulk = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackSundry.WasteBulk));
            }
            if (vm.NuclearTrackSundry.SullyValue != null)
            {
                if (vm.NuclearTrackSundry.SullyValue.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackSundry.SullyValue = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackSundry.SullyValue));
            }
            if (vm.NuclearTrackSundry.SurfaceDose != null)
            {
                if (vm.NuclearTrackSundry.SurfaceDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackSundry.SurfaceDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackSundry.SurfaceDose));
            }
            if (vm.NuclearTrackSundry.EvaDose != null)
            {
                if (vm.NuclearTrackSundry.EvaDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackSundry.EvaDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackSundry.EvaDose));
            }
            return View(vm);
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="nuclearTrackSundryCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNuclearTrackSundryList(NuclearTrackSundryCondition nuclearTrackSundryCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearTrackSundryView> data = this._NuclearTrackSundryRepository.QueryList(nuclearTrackSundryCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearTrackSundryView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.SundryId,
                    List = new List<object>() {
                    d.SundryId,
                    d.SundryCode,
                    d.SystemCode,
                    d.WorkTicket,
                    d.MachineStatus,
                    d.WasteType,
                    d.StorageContainerId,
                    d.Description,                    
                    d.ControlName,
                    d.ControlDate.HasValue? d.ControlDate.Value.ToString("yyyy-MM-dd"):string.Empty,
                    d.Status,
                    d.DealStatus
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        [HttpPost]
        public JsonResult StationChange(string stationId)
        {
            string simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationId);
            string demo = simpleCode + "MW" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackSundryRepository.GetAll().Where(d => d.SundryCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.SundryCode).First().SundryCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            return Json("{\"result\":\"" + demo + "\"}", JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult GetBucketCode(string bucketCode)
        {
            Nullable<double> bucketCodeNum = 0;
            List<NuclearBucket> NuclearBucket = new List<NuclearBucket>();
            IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).AsQueryable();
            if (nuclearBucket != null && nuclearBucket.Count() > 0)
            {
                NuclearBucket = nuclearBucket.ToList();
            }
            string bucketId = null;
            if (NuclearBucket.Count() > 0)
            {
                bucketId = NuclearBucket[0].BucketId;
                List<NuclearTrackSundry> nuclearTrackSundry = _NuclearTrackSundryRepository.GetAll().Where(d => d.StorageContainerId == bucketId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                bucketCodeNum = nuclearTrackSundry.Count();
            }
            return Json("{\"bucketCodeNum\":\"" + bucketCodeNum + "\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(WasteTrackingVM model, FormCollection formCollection)
        {
            try
            {
                //判断编号是否重复
                if (this._NuclearTrackSundryRepository.IsRepeat(model.NuclearTrackSundry.SundryCode, AppContext.CurrentUser.ProjectCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
                }
                bool bucketCode = false;
                //存储方式为暂存包装容器
                if (model.NuclearTrackSundry.StorageMethods == "0")
                {
                  
                    //判断桶号是否存在 
                    string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackSundry.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器" + model.NuclearTrackSundry.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    int num = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (num > 0)
                    {
                        bucketCode = true;
                    }
                    model.NuclearTrackSundry.StorageContainerId = bucketId;
                    model.NuclearTrackSundry.SundryId = Guid.NewGuid().ToString();
                    model.NuclearTrackSundry.Status = "0";
                    model.NuclearTrackSundry.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackSundry.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackSundry.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackSundry.Stationcode  = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackSundryRepository.Create(model.NuclearTrackSundry);
                    this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    
                }
                //存储方式为暂存位置
                else 
                {
                    model.NuclearTrackSundry.SundryId = Guid.NewGuid().ToString();
                    model.NuclearTrackSundry.Status = "0";
                    model.NuclearTrackSundry.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackSundry.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackSundry.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackSundryRepository.Create(model.NuclearTrackSundry);
                    this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    NuclearTrackSundry nuclearTrackSundry = this._NuclearTrackSundryRepository.Get(id);
                    if (nuclearTrackSundry.Status == "2")
                    {
                        if (nuclearTrackSundry.DealStatus == "1")
                        {
                            return Json("{\"result\":false,\"msg\":\"删除失败，该条源项废物已被处理。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._NuclearTrackSundryRepository.DeleteById(idVal);
                    }
                    this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 提交处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SubmitDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearTrackSundry nuclearTrackSundry = this._NuclearTrackSundryRepository.Get(idVal);
                        nuclearTrackSundry.DealStatus = "0";
                        this._NuclearTrackSundryRepository.Update(nuclearTrackSundry);
                    }
                    this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ConfirmDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearTrackSundry nuclearTrackSundry = this._NuclearTrackSundryRepository.Get(idVal);
                        nuclearTrackSundry.DealStatus = "1";
                        this._NuclearTrackSundryRepository.Update(nuclearTrackSundry);
                    }
                    this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确认处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 编辑
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(WasteTrackingVM model, FormCollection formCollection)
        {
            string newSundryCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackSundry.SundryCode != newSundryCode && this._NuclearTrackSundryRepository.IsRepeat(model.NuclearTrackSundry.SundryCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                bool bucketCode = false;
                //存储方式为暂存包装容器
                if (model.NuclearTrackSundry.StorageMethods == "0")
                {
                    //判断桶号是否存在 
                    string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackSundry.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器" + model.NuclearTrackSundry.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    int num = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (num > 1)
                    {
                        bucketCode = true;
                    }
                    model.NuclearTrackSundry.StorageContainerId = bucketId;
                    model.NuclearTrackSundry.Status = "0";
                    model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackSundryRepository.Update(model.NuclearTrackSundry);
                    this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                //存储方式为暂存位置
                else
                {
                    model.NuclearTrackSundry.Status = "0";
                    model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackSundryRepository.Update(model.NuclearTrackSundry);
                    this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(WasteTrackingVM model, FormCollection formCollection)
        {
            string newSundryCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackSundry.SundryCode != newSundryCode && this._NuclearTrackSundryRepository.IsRepeat(model.NuclearTrackSundry.SundryCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                bool bucketCode = false;
                //编辑提交
                if (model.NuclearTrackSundry.SundryId != null)
                {
                    //存储方式为暂存包装容器
                    if (model.NuclearTrackSundry.StorageMethods == "0")
                    {
                       //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackSundry.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器" + model.NuclearTrackSundry.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 1)
                        {
                            bucketCode = true;
                        }
                        model.NuclearTrackSundry.StorageContainerId = bucketId;
                        model.NuclearTrackSundry.Status = "1";
                        model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearTrackSundryRepository.Update(model.NuclearTrackSundry);
                        this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        model.NuclearTrackSundry.Status = "1";
                        model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearTrackSundryRepository.Update(model.NuclearTrackSundry);
                        this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                //新增提交
                else if (model.NuclearTrackSundry.SundryId == null)
                {
                    //存储方式为暂存位置
                    if (model.NuclearTrackSundry.StorageMethods == "0")
                    {
                       //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackSundry.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器" + model.NuclearTrackSundry.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 0)
                        {
                            bucketCode = true;
                        }
                        model.NuclearTrackSundry.StorageContainerId = bucketId;
                        model.NuclearTrackSundry.SundryId = Guid.NewGuid().ToString();
                        model.NuclearTrackSundry.Status = "1";
                        model.NuclearTrackSundry.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                        model.NuclearTrackSundry.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                        model.NuclearTrackSundry.CreateDate = DateTime.Now.Date;//创建时间
                        model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearTrackSundryRepository.Create(model.NuclearTrackSundry);
                        this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);

                    }
                    else
                    {
                        model.NuclearTrackSundry.SundryId = Guid.NewGuid().ToString();
                        model.NuclearTrackSundry.Status = "1";
                        model.NuclearTrackSundry.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                        model.NuclearTrackSundry.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                        model.NuclearTrackSundry.CreateDate = DateTime.Now.Date;//创建时间
                        model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearTrackSundryRepository.Create(model.NuclearTrackSundry);
                        this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "杂项确认")]
        public JsonResult Confirm(WasteTrackingVM model, FormCollection formCollection)
        {
            string newSundryCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackSundry.SundryCode != newSundryCode && this._NuclearTrackSundryRepository.IsRepeat(model.NuclearTrackSundry.SundryCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                bool bucketCode = false;
                //编辑确认
                if (model.NuclearTrackSundry.SundryId != null)
                {
                    //存储方式为暂存包装容器
                    if (model.NuclearTrackSundry.StorageMethods == "0")
                    {
                       //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackSundry.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器" + model.NuclearTrackSundry.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 1)
                        {
                            bucketCode = true;
                        }
                        model.NuclearTrackSundry.StorageContainerId = bucketId;
                        model.NuclearTrackSundry.Status = "2";
                        model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                        model.NuclearTrackSundry.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        model.NuclearTrackSundry.ConfirmUserName = AppContext.CurrentUser.UserName;
                        model.NuclearTrackSundry.ConfirmDate = DateTime.Now;
                        //model.NuclearTrackSundry.DealStatus = "0";
                        this._NuclearTrackSundryRepository.Update(model.NuclearTrackSundry);
                        this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                    //存储方式为暂存位置
                    else
                    {
                        model.NuclearTrackSundry.Status = "2";
                        model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                        model.NuclearTrackSundry.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        model.NuclearTrackSundry.ConfirmUserName = AppContext.CurrentUser.UserName;
                        model.NuclearTrackSundry.ConfirmDate = DateTime.Now;
                        //model.NuclearTrackSundry.DealStatus = "0";
                        this._NuclearTrackSundryRepository.Update(model.NuclearTrackSundry);
                        this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                //新增确认
                else if (model.NuclearTrackSundry.SundryId == null)
                {
                    if (model.NuclearTrackSundry.StorageMethods == "0")
                    {
                       //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackSundry.StorageContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器" + model.NuclearTrackSundry.StorageContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的暂存包装容器号" + model.NuclearTrackSundry.StorageContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 0)
                        {
                            bucketCode = true;
                        }
                        model.NuclearTrackSundry.StorageContainerId = bucketId;
                        model.NuclearTrackSundry.SundryId = Guid.NewGuid().ToString();
                        model.NuclearTrackSundry.Status = "2";
                        model.NuclearTrackSundry.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                        model.NuclearTrackSundry.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                        model.NuclearTrackSundry.CreateDate = DateTime.Now.Date;//创建时间
                        model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                        model.NuclearTrackSundry.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        model.NuclearTrackSundry.ConfirmUserName = AppContext.CurrentUser.UserName;
                        model.NuclearTrackSundry.ConfirmDate = DateTime.Now;
                        //model.NuclearTrackSundry.DealStatus = "0";
                        this._NuclearTrackSundryRepository.Create(model.NuclearTrackSundry);
                        this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        model.NuclearTrackSundry.SundryId = Guid.NewGuid().ToString();
                        model.NuclearTrackSundry.Status = "2";
                        model.NuclearTrackSundry.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                        model.NuclearTrackSundry.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                        model.NuclearTrackSundry.CreateDate = DateTime.Now.Date;//创建时间
                        model.NuclearTrackSundry.Stationcode = AppContext.CurrentUser.ProjectCode;
                        model.NuclearTrackSundry.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        model.NuclearTrackSundry.ConfirmUserName = AppContext.CurrentUser.UserName;
                        model.NuclearTrackSundry.ConfirmDate = DateTime.Now;
                        //model.NuclearTrackSundry.DealStatus = "0";
                        this._NuclearTrackSundryRepository.Create(model.NuclearTrackSundry);
                        this._NuclearTrackSundryRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        //获得所有桶号
        public JsonResult GetDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            if (keyword.ToUpper().Trim() != null && keyword.ToUpper().Trim() != "")
            {
                IQueryable<NuclearBucket> iqueryNuclearBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsOutSend == "0" || e.IsOutSend == null));

                if (iqueryNuclearBucket.Count() > 0)
                {
                    list = iqueryNuclearBucket.ToList();
                }
            } 
            //string factoryId = Request["factory"];
            //if (!string.IsNullOrEmpty(factoryId))
            //    list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
