﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.DomainObjects.View;
using RWIS.Domain.DomainObjects.View.EquipManage;
using RWIS.Domain.DomainObjects.View.SourceManage;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.WasteTracking.Controllers
{
    public class TempTrackController : Controller
    {
        ITrackLiquorRepository _TrackLiquorRepository;
        INuclearTrackResinRepository _NuclearTrackResinRepository;
        INuclearTrackElementRepository _NuclearTrackElementRepository;
        INuclearTrackDepositRepository _NuclearTrackDepositRepository;
        INuclearTrackSolventRepository _NuclearTrackSolventRepository;
        INuclearTrackFilterRepository _NuclearTrackFilterRepository;
        INuclearTrackTechBRepository _NuclearTrackTechBRepository;
        INuclearTrackTechSRepository _NuclearTrackTechSRepository;

        public TempTrackController(ITrackLiquorRepository TrackLiquorRepository
            , INuclearTrackResinRepository NuclearTrackResinRepository
            , INuclearTrackElementRepository NuclearTrackElementRepository
            , INuclearTrackDepositRepository NuclearTrackDepositRepository
            , INuclearTrackSolventRepository NuclearTrackSolventRepository
            , INuclearTrackFilterRepository NuclearTrackFilterRepository
            , INuclearTrackTechBRepository NuclearTrackTechBRepository
            , INuclearTrackTechSRepository NuclearTrackTechSRepository)
        {
            this._TrackLiquorRepository = TrackLiquorRepository;
            this._NuclearTrackResinRepository = NuclearTrackResinRepository;
            this._NuclearTrackElementRepository = NuclearTrackElementRepository;
            this._NuclearTrackDepositRepository = NuclearTrackDepositRepository;
            this._NuclearTrackSolventRepository = NuclearTrackSolventRepository;
            this._NuclearTrackFilterRepository = NuclearTrackFilterRepository;
            this._NuclearTrackTechBRepository = NuclearTrackTechBRepository;
            this._NuclearTrackTechSRepository = NuclearTrackTechSRepository;
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "库存源项信息")]
        public ActionResult Index()
        {
            ViewBag.Factory = Request["locationId"];
            ViewBag.Type = Request["type"];
            return View();
        }
        public ActionResult GetWasteList(TempWasteTrackCondition tempCondition, string sord, int page, int rows, string sidx)
        {
            List<TempWasteTrackInfo> temp = new List<TempWasteTrackInfo>();
            switch (tempCondition.Type)
            {
                case "LIQUOR":
                    var listLIQUOR = _TrackLiquorRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.StoragePositionId == tempCondition.Factory && n.Status == "2").ToList();
                    for (int i = 0; i < listLIQUOR.Count; i++)
                    {
                        TempWasteTrackInfo info = new TempWasteTrackInfo();
                        info.WasteId = listLIQUOR[i].LiquorId;
                        info.WasteCode = listLIQUOR[i].LiquorCode;
                        info.SystemCode = listLIQUOR[i].SystemCode;
                        info.WorkTicket = listLIQUOR[i].WorkTicket;
                        info.ControlName = listLIQUOR[i].ControlName;
                        if (listLIQUOR[i].ControlDate != null)
                            info.ControlDate = Convert.ToDateTime(listLIQUOR[i].ControlDate.ToString()).ToShortDateString();
                        info.CreateDate = listLIQUOR[i].CreateDate;
                        temp.Add(info);
                    }
                    break;
                case "RESIN":
                    var listRESIN = _NuclearTrackResinRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.StoragePositionId == tempCondition.Factory && n.Status == "2").ToList();
                    for (int i = 0; i < listRESIN.Count; i++)
                    {
                        TempWasteTrackInfo info = new TempWasteTrackInfo();
                        info.WasteId = listRESIN[i].ResinId;
                        info.WasteCode = listRESIN[i].ResinCode;
                        info.SystemCode = listRESIN[i].SystemCode;
                        info.WorkTicket = listRESIN[i].WorkTicket;
                        info.ControlName = listRESIN[i].ControlName;
                        if (listRESIN[i].ControlDate != null)
                            info.ControlDate = Convert.ToDateTime(listRESIN[i].ControlDate.ToString()).ToShortDateString();
                        info.CreateDate = listRESIN[i].CreateDate;
                        temp.Add(info);
                    }
                    break;
                case "ELEMENT":
                    var listELEMENT = _NuclearTrackElementRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.FactoryPositionId == tempCondition.Factory && n.Status == "2").ToList();
                    for (int i = 0; i < listELEMENT.Count; i++)
                    {
                        TempWasteTrackInfo info = new TempWasteTrackInfo();
                        info.WasteId = listELEMENT[i].ElementId;
                        info.WasteCode = listELEMENT[i].ElementCode;
                        info.SystemCode = listELEMENT[i].SystemCode;
                        info.WorkTicket = listELEMENT[i].WorkTicket;
                        info.ControlName = listELEMENT[i].ControlName;
                        if (listELEMENT[i].ControlDate != null)
                            info.ControlDate = Convert.ToDateTime(listELEMENT[i].ControlDate.ToString()).ToShortDateString();
                        info.CreateDate = listELEMENT[i].CreateDate;
                        temp.Add(info);
                    }
                    break;
                case "DEPOSIT":
                    var listDEPOSIT = _NuclearTrackDepositRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.StoragePositionId == tempCondition.Factory && n.Status == "2").ToList();
                    for (int i = 0; i < listDEPOSIT.Count; i++)
                    {
                        TempWasteTrackInfo info = new TempWasteTrackInfo();
                        info.WasteId = listDEPOSIT[i].DepositId;
                        info.WasteCode = listDEPOSIT[i].DepositCode;
                        info.SystemCode = listDEPOSIT[i].SystemCode;
                        info.WorkTicket = listDEPOSIT[i].WorkTicket;
                        info.ControlName = listDEPOSIT[i].ControlName;
                        if (listDEPOSIT[i].ControlDate != null)
                            info.ControlDate = Convert.ToDateTime(listDEPOSIT[i].ControlDate.ToString()).ToShortDateString();
                        info.CreateDate = listDEPOSIT[i].CreateDate;
                        temp.Add(info);
                    }
                    break;
                case "SOLVENT":
                    var listSOLVENT = _NuclearTrackSolventRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.StoragePositionId == tempCondition.Factory && n.Status == "2").ToList();
                    for (int i = 0; i < listSOLVENT.Count; i++)
                    {
                        TempWasteTrackInfo info = new TempWasteTrackInfo();
                        info.WasteId = listSOLVENT[i].SolventId;
                        info.WasteCode = listSOLVENT[i].SolventCode;
                        info.SystemCode = listSOLVENT[i].SystemCode;
                        info.WorkTicket = listSOLVENT[i].WorkTicket;
                        info.ControlName = listSOLVENT[i].ControlName;
                        if (listSOLVENT[i].ControlDate != null)
                            info.ControlDate = Convert.ToDateTime(listSOLVENT[i].ControlDate.ToString()).ToShortDateString();
                        info.CreateDate = listSOLVENT[i].CreateDate;
                        temp.Add(info);
                    }
                    break;
                case "FILTER":
                    var listFILTER = _NuclearTrackFilterRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.StoragePositionId == tempCondition.Factory && n.Status == "2").ToList();
                    for (int i = 0; i < listFILTER.Count; i++)
                    {
                        TempWasteTrackInfo info = new TempWasteTrackInfo();
                        info.WasteId = listFILTER[i].FilterId;
                        info.WasteCode = listFILTER[i].FilterCode;
                        info.SystemCode = listFILTER[i].SystemCode;
                        info.WorkTicket = listFILTER[i].WorkTicket;
                        info.ControlName = listFILTER[i].ControlName;
                        if (listFILTER[i].ControlDate != null)
                            info.ControlDate = Convert.ToDateTime(listFILTER[i].ControlDate.ToString()).ToShortDateString();
                        info.CreateDate = listFILTER[i].CreateDate;
                        temp.Add(info);
                    }
                    break;
                case "TECH1":
                    var listTECH1 = _NuclearTrackTechBRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.StoragePositionId == tempCondition.Factory && n.Status == "2").ToList();
                    for (int i = 0; i < listTECH1.Count; i++)
                    {
                        TempWasteTrackInfo info = new TempWasteTrackInfo();
                        info.WasteId = listTECH1[i].TechBId;
                        info.WasteCode = listTECH1[i].TechBCode;
                        info.SystemCode = listTECH1[i].SystemCode;
                        info.WorkTicket = listTECH1[i].WorkTicket;
                        info.ControlName = listTECH1[i].ControlName;
                        if (listTECH1[i].ControlDate != null)
                            info.ControlDate = Convert.ToDateTime(listTECH1[i].ControlDate.ToString()).ToShortDateString();
                        info.CreateDate = listTECH1[i].CreateDate;
                        temp.Add(info);
                    }
                    break;
                case "TECH2":
                    break;
                default:
                    break;
            }
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            var data = temp.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<TempWasteTrackInfo>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.WasteId,
                    List = new List<object>() {
                    d.WasteId,
                    d.WasteCode,
                    d.SystemCode,
                    d.WorkTicket,
                    d.ControlName,                                     
                    d.ControlDate,
                    d.CreateDate
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
    }
}
