﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   NuclearTrackTechSController.cs
 *   描    述   ：   技术废物(<2mSv/h)Controller
 *   创 建 者   ：   PXMWAHY 安洪岩
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0     安洪岩       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View.SourceManage;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using System.Data;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using Newtonsoft.Json;

namespace RWIS.Presentation.Web.Areas.WasteTracking.Controllers
{
    public class NuclearTrackTechSController : Controller
    {
        INuclearTrackTechSRepository _NuclearTrackTechSRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        INuclearTrackElementRepository _NuclearTrackElementRepository;
        INuclearTrackDepositRepository _NuclearTrackDepositRepository;
        INuclearTrackSolventRepository _NuclearTrackSolventRepository;
        INuclearTrackFilterRepository _NuclearTrackFilterRepository;
        INuclearTrackTechBRepository _NuclearTrackTechBRepository;
        INuclearTrackSundryRepository _NuclearTrackSundryRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        public NuclearTrackTechSController(INuclearTrackTechSRepository _NuclearTrackTechSRepository, IBasicObjectRepository _BasicObjectRepository, INuclearBucketRepository _NuclearBucketRepository, IBasicWasteUnitRepository _BasicWasteUnitRepository, INuclearTempstockRepository _NuclearTempstockRepository
            ,INuclearTrackElementRepository _NuclearTrackElementRepository,INuclearTrackDepositRepository _NuclearTrackDepositRepository,INuclearTrackSolventRepository _NuclearTrackSolventRepository,INuclearTrackFilterRepository _NuclearTrackFilterRepository,INuclearTrackTechBRepository _NuclearTrackTechBRepository
            , INuclearTrackSundryRepository _NuclearTrackSundryRepository, IMaterialTypeRepository MaterialTypeRepository)
        {
            this._NuclearTrackTechSRepository = _NuclearTrackTechSRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
            this._NuclearTempstockRepository = _NuclearTempstockRepository;
            this._NuclearTrackElementRepository = _NuclearTrackElementRepository;
            this._NuclearTrackDepositRepository = _NuclearTrackDepositRepository;
            this._NuclearTrackSolventRepository = _NuclearTrackSolventRepository;
            this._NuclearTrackFilterRepository = _NuclearTrackFilterRepository;
            this._NuclearTrackTechBRepository = _NuclearTrackTechBRepository;
            this._NuclearTrackSundryRepository = _NuclearTrackSundryRepository;
            this._MaterialTypeRepository = MaterialTypeRepository;
        }

        /// <summary>
        /// 灵活条件查询
        /// </summary>
        /// <param name="stationId"></param>
        /// <returns></returns>
        public JsonResult SelecteCondition(string activityId)
        {


            List<ActivityCountCode> ActivityCountCodeList = new List<ActivityCountCode>();
            ActivityCountCode activityCount = new ActivityCountCode();
            activityCount.Name = "请选择";
            activityCount.Code = "";
            ActivityCountCodeList.Add(activityCount);

            //加载电站

            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList != null && QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    ActivityCountCode activityCountCode = new ActivityCountCode();
                    activityCountCode.Name = item.UnitName;
                    activityCountCode.Code = item.UnitId.ToString();
                    ActivityCountCodeList.Add(activityCountCode);
                }
            }


            string str = JsonConvert.SerializeObject(ActivityCountCodeList);
            return Json(str, JsonRequestBehavior.AllowGet);

        }

        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "技术废物(<2mSv/h)")]
        public ActionResult Index()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_TechS");
            //加载工作类型
            vm.WorkTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> workTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("WorkType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> workTypeList = new List<BasicObject>();
            if (workTypeQuery!=null&&workTypeQuery.Count() > 0)
            {
                workTypeList = workTypeQuery.ToList();
                vm.WorkTypeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in workTypeList)
                {
                    vm.WorkTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            string locationId = Request["locationId"];
            ViewBag.Location = locationId;
            string bucketId = Request["bucketId"];
            ViewBag.BucketId = bucketId;
            //加载状态
            vm.StatusList = new List<SelectListItem>();
            vm.StatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.StatusList.Add(new SelectListItem { Text = "草稿", Value = "0" });
            vm.StatusList.Add(new SelectListItem { Text = "未确认", Value = "1" });
            vm.StatusList.Add(new SelectListItem { Text = "已确认", Value = "2" });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                vm.StationCodeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
           
            return View(vm);
        }
        public ActionResult Add()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_TechS");
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });
            //加载废物1类型
            vm.RubbishKindList = new List<SelectListItem>();
            vm.RubbishKindList = new List<SelectListItem>();
            IQueryable<BasicObject> RubbishKindListQuery = _BasicObjectRepository.GetSubobjectsByCode("RubbishKind", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> rubbishKindList = new List<BasicObject>();
            if (RubbishKindListQuery!=null && RubbishKindListQuery.Count() > 0)
            {
                rubbishKindList = RubbishKindListQuery.ToList();
                foreach (var item in rubbishKindList)
                {
                    vm.RubbishKindList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            //加载废物2类型
            vm.RubbishKindsList = new List<SelectListItem>();
            IQueryable<BasicObject> RubbishKindsListQuery = _BasicObjectRepository.GetSubobjectsByCode("RubbishKinds", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> rubbishKindsList = new List<BasicObject>();
            if (RubbishKindsListQuery!=null && RubbishKindsListQuery.Count() > 0)
            {
                rubbishKindsList = RubbishKindsListQuery.ToList();
                foreach (var item in rubbishKindsList)
                {
                    vm.RubbishKindsList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            //加载是否可焚烧
            vm.BurnFlagList = new List<SelectListItem>();
            vm.BurnFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.BurnFlagList.Add(new SelectListItem { Text = "是", Value = "1" });
            //加载是否可压缩
            vm.CompressFlagList = new List<SelectListItem>();
            vm.CompressFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.CompressFlagList.Add(new SelectListItem { Text = "是", Value = "1" });
            //加载吸水材料
            vm.WaterMaterialFlagList = new List<SelectListItem>();
            vm.WaterMaterialFlagList.Add(new SelectListItem { Text = "无", Value = "0", Selected = true });
            vm.WaterMaterialFlagList.Add(new SelectListItem { Text = "有", Value = "1" });


            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            NuclearTrackTechS nuclearTrackTechS = new NuclearTrackTechS();
            string simpleCode = "";
            if (stationList.Count() > 0)
            {
                simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationList[0].UnitId);
            }
            string demo = simpleCode + "TL" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackTechSRepository.GetAll().Where(d => d.TechSCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.TechSCode).First().TechSCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            nuclearTrackTechS.TechSCode = demo;
            vm.NuclearTrackTechS = nuclearTrackTechS;

            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);
        }
        public ActionResult DetailView(string id)
        {
            ViewBag.ViewStatus = Request["status"];
            NuclearTrackTechS model = _NuclearTrackTechSRepository.Get(id);
            WasteTrackingVM vm = new WasteTrackingVM();
            //加载废物1类型
            vm.RubbishKindList = new List<SelectListItem>();
            vm.RubbishKindList = new List<SelectListItem>();
            IQueryable<BasicObject> RubbishKindListQuery = _BasicObjectRepository.GetSubobjectsByCode("RubbishKind", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> rubbishKindList = new List<BasicObject>();
            if (RubbishKindListQuery.Count() > 0)
            {
                rubbishKindList = RubbishKindListQuery.ToList();
            }
            foreach (var item in rubbishKindList)
            {
                vm.RubbishKindList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            //加载废物2类型
            vm.RubbishKindsList = new List<SelectListItem>();
            IQueryable<BasicObject> RubbishKindsListQuery = _BasicObjectRepository.GetSubobjectsByCode("RubbishKinds", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> rubbishKindsList = new List<BasicObject>();
            if (RubbishKindsListQuery.Count() > 0)
            {
                rubbishKindsList = RubbishKindsListQuery.ToList();
            }
            foreach (var item in rubbishKindsList)
            {
                vm.RubbishKindsList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            BasicWasteUnit basicObjectStationcode = _BasicWasteUnitRepository.Get(model.StationId);
            if (basicObjectStationcode != null)
            {
                vm.StationCodeName = basicObjectStationcode.UnitName;
            }
            else {
                vm.StationCodeName = "";
            }
            if (!string.IsNullOrEmpty(model.BucketId))
            {
                NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(model.BucketId);
                if (nuclearBucket != null)
                {
                    model.BucketId = nuclearBucket.BucketCode;
                }
                else
                {
                    model.BucketId = "";
                }
            }
            vm.NuclearTrackTechS = model;
            ///如果数字类型不为空，截取小数点后三位
            if (vm.NuclearTrackTechS.RubbishWeight != null)
            {
                if (vm.NuclearTrackTechS.RubbishWeight.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackTechS.RubbishWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackTechS.RubbishWeight));
            }
            if (vm.NuclearTrackTechS.WaterMaterialWeight != null)
            {
                if (vm.NuclearTrackTechS.WaterMaterialWeight.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackTechS.WaterMaterialWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackTechS.WaterMaterialWeight));
            }
            if (vm.NuclearTrackTechS.SurfaceDose != null)
            {
                if (vm.NuclearTrackTechS.SurfaceDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackTechS.SurfaceDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackTechS.SurfaceDose));
            }
            if (vm.NuclearTrackTechS.EvaDose != null)
            {
                if (vm.NuclearTrackTechS.EvaDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackTechS.EvaDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackTechS.EvaDose));
            }
            return View("DetailView", vm);
        }
        public ActionResult Edit(string id)
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_TechS");
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0" });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });
            //加载废物1类型
            vm.RubbishKindList = new List<SelectListItem>();
            vm.RubbishKindList = new List<SelectListItem>();
            IQueryable<BasicObject> RubbishKindListQuery = _BasicObjectRepository.GetSubobjectsByCode("RubbishKind", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> rubbishKindList = new List<BasicObject>();
            if (RubbishKindListQuery!=null&&RubbishKindListQuery.Count() > 0)
            {
                rubbishKindList = RubbishKindListQuery.ToList();
                foreach (var item in rubbishKindList)
                {
                    vm.RubbishKindList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
           
            //加载废物2类型
            vm.RubbishKindsList = new List<SelectListItem>();
            IQueryable<BasicObject> RubbishKindsListQuery = _BasicObjectRepository.GetSubobjectsByCode("RubbishKinds", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> rubbishKindsList = new List<BasicObject>();
            if (RubbishKindsListQuery!=null&&RubbishKindsListQuery.Count() > 0)
            {
                rubbishKindsList = RubbishKindsListQuery.ToList();
                foreach (var item in rubbishKindsList)
                {
                    vm.RubbishKindsList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            

            //加载是否可焚烧
            vm.BurnFlagList = new List<SelectListItem>();
            vm.BurnFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.BurnFlagList.Add(new SelectListItem { Text = "是", Value = "1" });
            //加载是否可压缩
            vm.CompressFlagList = new List<SelectListItem>();
            vm.CompressFlagList.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.CompressFlagList.Add(new SelectListItem { Text = "是", Value = "1" });
            //加载吸水材料
            vm.WaterMaterialFlagList = new List<SelectListItem>();
            vm.WaterMaterialFlagList.Add(new SelectListItem { Text = "无", Value = "0", Selected = true });
            vm.WaterMaterialFlagList.Add(new SelectListItem { Text = "有", Value = "1" });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            NuclearTrackTechS model = _NuclearTrackTechSRepository.Get(id);
            if (!string.IsNullOrEmpty(model.BucketId))
            {
                NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(model.BucketId);
                if (nuclearBucket != null)
                {
                    model.BucketId = nuclearBucket.BucketCode;
                }
                else
                {
                    model.BucketId = "";
                }
            }
            vm.NuclearTrackTechS = model;
            vm.TrackCode = model.TechSCode;
            vm.BucketId = model.BucketId;
            ///如果数字类型不为空，截取小数点后三位
            if (vm.NuclearTrackTechS.RubbishWeight != null)
            {
                if (vm.NuclearTrackTechS.RubbishWeight.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackTechS.RubbishWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackTechS.RubbishWeight));
            }
            if (vm.NuclearTrackTechS.WaterMaterialWeight != null)
            {
                if (vm.NuclearTrackTechS.WaterMaterialWeight.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackTechS.WaterMaterialWeight = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackTechS.WaterMaterialWeight));
            }
            if (vm.NuclearTrackTechS.SurfaceDose != null)
            {
                if (vm.NuclearTrackTechS.SurfaceDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackTechS.SurfaceDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackTechS.SurfaceDose));
            }
            if (vm.NuclearTrackTechS.EvaDose != null)
            {
                if (vm.NuclearTrackTechS.EvaDose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackTechS.EvaDose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackTechS.EvaDose));
            }

            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNuclearTrackTechSList(NuclearTrackTechSCondition nuclearTrackTechSCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearTrackTechSView> data = this._NuclearTrackTechSRepository.QueryList(nuclearTrackTechSCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            string bucketId = Request["bucketId"];
            if (!string.IsNullOrEmpty(bucketId))
                data = data.Where(n => n.BucketId == bucketId);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearTrackTechSView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.TechSId,
                    List = new List<object>() {
                    d.TechSId,
                    d.TechSCode,
                    d.BucketIds,
                    //d.SystemCode,
                    d.WorkTicket,
                    d.MachineStatus,
                    d.Description,
                    d.RubbishWeight,
                    d.SurfaceDose,
                    d.EvaDose,     
                    d.ControlName,
                    d.ControlDate.HasValue? d.ControlDate.Value.ToString("yyyy-MM-dd"):string.Empty,
                    d.Status,
                    d.DealStatus
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        [HttpPost]
        public JsonResult StationChange(string stationId)
        {
            string simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationId);
            string demo = simpleCode + "TL" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackTechSRepository.GetAll().Where(d => d.TechSCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.TechSCode).First().TechSCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            return Json("{\"result\":\"" + demo + "\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(WasteTrackingVM model, FormCollection formCollection)
        {
            try
            {
                //判断编号是否重复
                if (this._NuclearTrackTechSRepository.IsRepeat(model.NuclearTrackTechS.TechSCode, AppContext.CurrentUser.ProjectCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
                }
                if (model.NuclearTrackTechS.BucketId != null)
                {
                    //判断桶号是否存在 
                    string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackTechS.BucketId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号不正确!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的208L金属桶编号重复。\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被废滤芯使用
                    int elementbucketId = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (elementbucketId>0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    int elementbucketIds = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (elementbucketIds > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被淤积物使用
                    int depositbucketId = this._NuclearTrackDepositRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (depositbucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被淤积物列表中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被废油和溶剂使用
                    int solventbucketId = this._NuclearTrackSolventRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (solventbucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废油和溶剂中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被通风过滤器使用
                    int filerbucketId = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (filerbucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被通风过滤器中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被技术废物1使用
                    int techBbucketId = this._NuclearTrackTechBRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (techBbucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被技术废物1中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被杂项使用
                    int sundrybucketId = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (sundrybucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被杂项中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.NuclearTrackTechS.BucketId = bucketId;
                }
                model.NuclearTrackTechS.RubbishKind = Request.Form["hidRubbishKind"].Trim(new char[] { ',' });
                model.NuclearTrackTechS.RubbishKinds = Request.Form["hidRubbishKinds"].Trim(new char[] { ',' });
                model.NuclearTrackTechS.TechSId = Guid.NewGuid().ToString();
                model.NuclearTrackTechS.Status = "0";
                model.NuclearTrackTechS.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                model.NuclearTrackTechS.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                model.NuclearTrackTechS.CreateDate = DateTime.Now.Date;//创建时间
                model.NuclearTrackTechS.Stationcode = AppContext.CurrentUser.ProjectCode;
                this._NuclearTrackTechSRepository.Create(model.NuclearTrackTechS);

                _NuclearTempstockRepository.MergeWasteTmpStock("TECH2", null, AppContext.CurrentUser.ProjectCode, Convert.ToDecimal(null));
                this._NuclearTrackTechSRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    NuclearTrackTechS nuclearTrackTechS = this._NuclearTrackTechSRepository.Get(id);
                    if (nuclearTrackTechS.Status == "2")
                    {
                        if (nuclearTrackTechS.DealStatus == "1")
                        {
                            return Json("{\"result\":false,\"msg\":\"删除失败，该条源项废物已被处理。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._NuclearTrackTechSRepository.DeleteById(idVal);
                    }
                    this._NuclearTrackTechSRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 提交处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SubmitDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearTrackTechS nuclearTrackTechS = this._NuclearTrackTechSRepository.Get(idVal);
                        nuclearTrackTechS.DealStatus = "0";
                        this._NuclearTrackTechSRepository.Update(nuclearTrackTechS);
                    }
                    this._NuclearTrackTechSRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ConfirmDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearTrackTechS nuclearTrackTechS = this._NuclearTrackTechSRepository.Get(idVal);
                        nuclearTrackTechS.DealStatus = "1";
                        this._NuclearTrackTechSRepository.Update(nuclearTrackTechS);
                    }
                    this._NuclearTrackTechSRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确认处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 编辑
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(WasteTrackingVM model, FormCollection formCollection)
        {
            string newTechSCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackTechS.TechSCode != newTechSCode && this._NuclearTrackTechSRepository.IsRepeat(model.NuclearTrackTechS.TechSCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                if (model.NuclearTrackTechS.BucketId != null)
                {
                    //判断桶号是否存在 
                    string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackTechS.BucketId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号不正确!\"}", JsonRequestBehavior.AllowGet);
                    }
                    string newBucketId = model.BucketId;
                    if (model.NuclearTrackTechS.BucketId != newBucketId && this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的208L金属桶编号重复。\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被废滤芯使用
                    int elementbucketId = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (elementbucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    int elementbucketIds = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (elementbucketIds > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被淤积物使用
                    int depositbucketId = this._NuclearTrackDepositRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (depositbucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被淤积物列表中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被废油和溶剂使用
                    int solventbucketId = this._NuclearTrackSolventRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (solventbucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废油和溶剂中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被通风过滤器使用
                    int filerbucketId = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (filerbucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被通风过滤器中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被技术废物1使用
                    int techBbucketId = this._NuclearTrackTechBRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (techBbucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被技术废物1中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    //判断桶是否被杂项使用
                    int sundrybucketId = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (sundrybucketId > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被杂项中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.NuclearTrackTechS.BucketId = bucketId;
                }
                model.NuclearTrackTechS.RubbishKind = Request.Form["hidRubbishKind"].Trim(new char[] { ',' });
                model.NuclearTrackTechS.RubbishKinds = Request.Form["hidRubbishKinds"].Trim(new char[] { ',' });
                model.NuclearTrackTechS.Status = "0";
                model.NuclearTrackTechS.Stationcode = AppContext.CurrentUser.ProjectCode;
                this._NuclearTrackTechSRepository.Update(model.NuclearTrackTechS);
                this._NuclearTrackTechSRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(WasteTrackingVM model, FormCollection formCollection)
        {
            string newTechSCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackTechS.TechSCode != newTechSCode && this._NuclearTrackTechSRepository.IsRepeat(model.NuclearTrackTechS.TechSCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //编辑提交
                if (model.NuclearTrackTechS.TechSId != null)
                {
                    if (model.NuclearTrackTechS.BucketId != null)
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackTechS.BucketId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        string newBucketId = model.BucketId;
                        if (model.NuclearTrackTechS.BucketId != newBucketId && this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的208L金属桶编号重复。\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被废滤芯使用
                        int elementbucketId = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (elementbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        int elementbucketIds = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (elementbucketIds > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被淤积物使用
                        int depositbucketId = this._NuclearTrackDepositRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (depositbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被淤积物列表中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被废油和溶剂使用
                        int solventbucketId = this._NuclearTrackSolventRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (solventbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废油和溶剂中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被通风过滤器使用
                        int filerbucketId = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (filerbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被通风过滤器中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被技术废物1使用
                        int techBbucketId = this._NuclearTrackTechBRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (techBbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被技术废物1中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被杂项使用
                        int sundrybucketId = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (sundrybucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被杂项中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        model.NuclearTrackTechS.BucketId = bucketId;
                    }
                    model.NuclearTrackTechS.RubbishKind = Request.Form["hidRubbishKind"].Trim(new char[] { ',' });
                    model.NuclearTrackTechS.RubbishKinds = Request.Form["hidRubbishKinds"].Trim(new char[] { ',' });
                    model.NuclearTrackTechS.Status = "1";
                    model.NuclearTrackTechS.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackTechSRepository.Update(model.NuclearTrackTechS);
                    this._NuclearTrackTechSRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                //新增提交
                else if (model.NuclearTrackTechS.TechSId == null)
                {
                    if (model.NuclearTrackTechS.BucketId != null)
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackTechS.BucketId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的208L金属桶编号重复。\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被废滤芯使用
                        int elementbucketId = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (elementbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        int elementbucketIds = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (elementbucketIds > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被淤积物使用
                        int depositbucketId = this._NuclearTrackDepositRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (depositbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被淤积物列表中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被废油和溶剂使用
                        int solventbucketId = this._NuclearTrackSolventRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (solventbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废油和溶剂中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被通风过滤器使用
                        int filerbucketId = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (filerbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被通风过滤器中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被技术废物1使用
                        int techBbucketId = this._NuclearTrackTechBRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (techBbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被技术废物1中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被杂项使用
                        int sundrybucketId = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (sundrybucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被杂项中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        model.NuclearTrackTechS.BucketId = bucketId;
                    }
                    model.NuclearTrackTechS.RubbishKind = Request.Form["hidRubbishKind"].Trim(new char[] { ',' });
                    model.NuclearTrackTechS.RubbishKinds = Request.Form["hidRubbishKinds"].Trim(new char[] { ',' });
                    model.NuclearTrackTechS.TechSId = Guid.NewGuid().ToString();
                    model.NuclearTrackTechS.Status = "1";
                    model.NuclearTrackTechS.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackTechS.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackTechS.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackTechS.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackTechSRepository.Create(model.NuclearTrackTechS);
                    this._NuclearTrackTechSRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "技术废物(<2mSv/h)")]
        public JsonResult Confirm(WasteTrackingVM model, FormCollection formCollection)
        {
            string newTechSCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackTechS.TechSCode != newTechSCode && this._NuclearTrackTechSRepository.IsRepeat(model.NuclearTrackTechS.TechSCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //编辑确认
                if (model.NuclearTrackTechS.TechSId != null)
                {
                    if (model.NuclearTrackTechS.BucketId != null)
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackTechS.BucketId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        string newBucketId = model.BucketId;
                        if (model.NuclearTrackTechS.BucketId != newBucketId && this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的208L金属桶编号重复。\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被废滤芯使用
                        int elementbucketId = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (elementbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        int elementbucketIds = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (elementbucketIds > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被淤积物使用
                        int depositbucketId = this._NuclearTrackDepositRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (depositbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被淤积物列表中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被废油和溶剂使用
                        int solventbucketId = this._NuclearTrackSolventRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (solventbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废油和溶剂中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被通风过滤器使用
                        int filerbucketId = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (filerbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被通风过滤器中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被技术废物1使用
                        int techBbucketId = this._NuclearTrackTechBRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (techBbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被技术废物1中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被杂项使用
                        int sundrybucketId = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (sundrybucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被杂项中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        model.NuclearTrackTechS.BucketId = bucketId;
                    }

                    model.NuclearTrackTechS.RubbishKind = Request.Form["hidRubbishKind"].Trim(new char[] { ',' });
                    model.NuclearTrackTechS.RubbishKinds = Request.Form["hidRubbishKinds"].Trim(new char[] { ',' });
                    model.NuclearTrackTechS.Status = "2";
                    model.NuclearTrackTechS.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.NuclearTrackTechS.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearTrackTechS.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.NuclearTrackTechS.ConfirmDate = DateTime.Now;
                    this._NuclearTrackTechSRepository.Update(model.NuclearTrackTechS);
                    this._NuclearTrackTechSRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                //新增提交
                else if (model.NuclearTrackTechS.TechSId == null)
                {
                    if (model.NuclearTrackTechS.BucketId != null)
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackTechS.BucketId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的208L金属桶编号重复。\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被废滤芯使用
                        int elementbucketId = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (elementbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        int elementbucketIds = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (elementbucketIds > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废滤芯列表中包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被淤积物使用
                        int depositbucketId = this._NuclearTrackDepositRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (depositbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被淤积物列表中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被废油和溶剂使用
                        int solventbucketId = this._NuclearTrackSolventRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (solventbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被废油和溶剂中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被通风过滤器使用
                        int filerbucketId = this._NuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (filerbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被通风过滤器中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被技术废物1使用
                        int techBbucketId = this._NuclearTrackTechBRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (techBbucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被技术废物1中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        //判断桶是否被杂项使用
                        int sundrybucketId = this._NuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (sundrybucketId > 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写208L金属桶编号已经被杂项中暂存包装容器使用!\"}", JsonRequestBehavior.AllowGet);
                        }
                        model.NuclearTrackTechS.BucketId = bucketId;
                    }

                    model.NuclearTrackTechS.RubbishKind = Request.Form["hidRubbishKind"].Trim(new char[] { ',' });
                    model.NuclearTrackTechS.RubbishKinds = Request.Form["hidRubbishKinds"].Trim(new char[] { ',' });
                    model.NuclearTrackTechS.TechSId = Guid.NewGuid().ToString();
                    model.NuclearTrackTechS.Status = "2";
                    model.NuclearTrackTechS.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackTechS.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackTechS.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackTechS.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.NuclearTrackTechS.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearTrackTechS.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.NuclearTrackTechS.ConfirmDate = DateTime.Now;
                    //model.NuclearTrackTechS.DealStatus = "0";
                    this._NuclearTrackTechSRepository.Create(model.NuclearTrackTechS);
                    this._NuclearTrackTechSRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        //获得所有桶号
        public JsonResult GetDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            if (keyword.ToUpper().Trim() != null && keyword.ToUpper().Trim() != "")
            {
                IQueryable<MaterialType> iqueryMaterialType = _MaterialTypeRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.MaterialName.ToUpper().Trim().Contains("208L"));
                var iqueryBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsCompress == null || e.IsCompress == "" || e.IsCompress == "0") && (e.IsOutSend == "" || e.IsOutSend == null));
                list = (from m in iqueryMaterialType
                        join b in iqueryBucket on m.MaterialId equals b.MaterialId
                        select b).ToList();
            }
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        /// 导入历史数据页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Import()
        {
            return View();
        }

        #region 导入历史数据
        /// <summary>
        /// 导入技术废物2数据
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult Import(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的历史数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    //string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    //if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    //{
                    //    //删除文件
                    //    if (System.IO.File.Exists(strNewImportPath))
                    //    {
                    //        System.IO.File.Delete(strNewImportPath);
                    //    }
                    //    jsonResult = JsonResultHelper.JsonResult(false, "历史数据必须是EXCEL格式!");
                    //    jsonResult.ContentType = "text/html";
                    //    return jsonResult;
                    //}
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);
                        if (ds.Tables.Count < 1)
                        {
                            //删除文件
                            if (System.IO.File.Exists(strNewImportPath))
                            {
                                System.IO.File.Delete(strNewImportPath);
                            }
                            jsonResult = JsonResultHelper.JsonResult(false, "历史数据格式错误!");
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //判断EXCEL格式是否正确
                        string checkColumns = ImportDataBuilder.GetImporttrackTechSErr(ds, strNewImportPath);
                        if (!string.IsNullOrEmpty(checkColumns))
                        {
                            jsonResult = JsonResultHelper.JsonResult(false, checkColumns);
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //导入数据
                        if (ds != null && ds.Tables.Count == 1)
                        {
                            ImportDataBuilder.ImporttrackTechS(ds, strNewImportPath, AppContext.CurrentUser);
                        }
                    }
                }
                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }
        #endregion
    }
}
