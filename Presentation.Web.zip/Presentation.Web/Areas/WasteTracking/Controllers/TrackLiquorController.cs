﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   EquipDetailController.cs
 *   描    述   ：   EquipDetailController
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.DomainObjects.View;
using RWIS.Domain.DomainObjects.View.EquipManage;
using RWIS.Domain.DomainObjects.View.SourceManage;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.WasteTracking.Controllers
{
    public class TrackLiquorController : Controller
    {
        ITrackLiquorRepository _TrackLiquorRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IEquipInfoRepository _EquipInfoRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        public TrackLiquorController(ITrackLiquorRepository _TrackLiquorRepository, IBasicObjectRepository _BasicObjectRepository, IEquipInfoRepository _EquipInfoRepository, IBasicWasteUnitRepository _BasicWasteUnitRepository, INuclearTempstockRepository _NuclearTempstockRepository)
        {
            this._TrackLiquorRepository = _TrackLiquorRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._EquipInfoRepository = _EquipInfoRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
            this._NuclearTempstockRepository = _NuclearTempstockRepository;
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "浓缩液列表")]
        public ActionResult Index()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Track_Liquor");
            //加载工作类型
            vm.WorkTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> workTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("WorkType", AppContext.CurrentUser.ProjectCode);  
            List<BasicObject> workTypeList = new List<BasicObject>();
            if (workTypeQuery!=null&&workTypeQuery.Count() > 0)
            {
                workTypeList = workTypeQuery.ToList();
                vm.WorkTypeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in workTypeList)
                {
                    vm.WorkTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
           
            string locationId = Request["locationId"];
            ViewBag.Location = locationId;
            //加载状态
            vm.StatusList = new List<SelectListItem>();
            vm.StatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.StatusList.Add(new SelectListItem { Text = "草稿", Value = "0" });
            vm.StatusList.Add(new SelectListItem { Text = "未确认", Value = "1" });
            vm.StatusList.Add(new SelectListItem { Text = "已确认", Value = "2" });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = this._BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                vm.StationCodeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载暂存位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);  
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null&&storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            return View(vm);
        }

        public ActionResult Add()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Track_Liquor");
            //机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });

            //机组状态
            vm.TransTypeList = new List<SelectListItem>();
            vm.TransTypeList.Add(new SelectListItem { Text = "设备", Value = "EQUIP", Selected = true });
            vm.TransTypeList.Add(new SelectListItem { Text = "其他", Value = "OTHER" });
            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = this._BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载暂存位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null && storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                vm.StoragePositionIdList.Add(new SelectListItem { Text = "请选择", Value = null });
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
           
            TrackLiquor trackLiquor = new TrackLiquor();
            string simpleCode = "";
            if (stationList.Count() > 0)
            {
                simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationList[0].UnitId);
            }
            string demo = simpleCode + "CO" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._TrackLiquorRepository.GetAll().Where(d => d.LiquorCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.LiquorCode).First().LiquorCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            trackLiquor.LiquorCode = demo;
            vm.TrackLiquor = trackLiquor;
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);

        }

        public ActionResult DetailView(string id)
        {
            ViewBag.ViewStatus = Request["status"];
            TrackLiquor model = _TrackLiquorRepository.Get(id);
            WasteTrackingVM vm = new WasteTrackingVM();
            BasicWasteUnit basicObjectStationcode = _BasicWasteUnitRepository.Get(model.StationId);
            BasicObject basicObjectStoragePositionId = _BasicObjectRepository.Get(model.StoragePositionId);
            if (basicObjectStationcode != null)
            {
                vm.StationCodeName = basicObjectStationcode.UnitName;
            }
            else {
                vm.StationCodeName = "";
            }
            if (basicObjectStoragePositionId != null)
            {
                vm.StoragePositionName = basicObjectStoragePositionId.Name;
            }
            else {
                vm.StoragePositionName = "";
            }
            vm.TrackLiquor = model;
            ///如果数字类型不为空，截取小数点后三位
            if (vm.TrackLiquor.LiquorBulk != null)
            {
                if (vm.TrackLiquor.LiquorBulk.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.LiquorBulk = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.LiquorBulk));
            }
            if (vm.TrackLiquor.Ppm != null)
            {
                if (vm.TrackLiquor.Ppm.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.Ppm = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.Ppm));
            }
            if (vm.TrackLiquor.Salt != null)
            {
                if (vm.TrackLiquor.Salt.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.Salt = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.Salt));
            }
            if (vm.TrackLiquor.Liveness != null)
            {
                if (vm.TrackLiquor.Liveness.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.Liveness = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.Liveness));
            }
            if (vm.TrackLiquor.Nab != null)
            {
                if (vm.TrackLiquor.Nab.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.Nab = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.Nab));
            }
            if (vm.TrackLiquor.Density != null)
            {
                if (vm.TrackLiquor.Density.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.Density = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.Density));
            }
            if (vm.TrackLiquor.LiquorPosition != null)
            {
                if (vm.TrackLiquor.LiquorPosition.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.LiquorPosition = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.LiquorPosition));
            }
            if (vm.TrackLiquor.PositionBulk != null)
            {
                if (vm.TrackLiquor.PositionBulk.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.PositionBulk = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.PositionBulk));
            }
           
            return View("DetailView", vm);
        }
        public ActionResult Edit(string id)
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Track_Liquor");
            TrackLiquor model = _TrackLiquorRepository.Get(id);
            vm.TrackLiquor = model;
            vm.LiquorCode = model.LiquorCode;
            vm.NewStoragePositionId = model.StoragePositionId;
            vm.Status = model.Status;
            vm.OldVoulumn = Convert.ToDecimal(model.PositionBulk);
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0"});
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1"});
            //机组状态
            vm.TransTypeList = new List<SelectListItem>();
            vm.TransTypeList.Add(new SelectListItem { Text = "设备", Value = "EQUIP", Selected = true });
            vm.TransTypeList.Add(new SelectListItem { Text = "其他", Value = "OTHER" });
            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = this._BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载暂存位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);  
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null&&storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                vm.StoragePositionIdList.Add(new SelectListItem { Text = "请选择", Value = null });
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            ///如果数字类型不为空，截取小数点后三位
            if (vm.TrackLiquor.LiquorBulk != null){
                if (vm.TrackLiquor.LiquorBulk.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.LiquorBulk = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.LiquorBulk));
            }
            if (vm.TrackLiquor.Ppm != null)
            {
                if (vm.TrackLiquor.Ppm.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.Ppm = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.Ppm));
            }
            if (vm.TrackLiquor.Salt != null)
            {
                if (vm.TrackLiquor.Salt.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.Salt = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.Salt));
            }
            if (vm.TrackLiquor.Liveness != null)
            {
                if (vm.TrackLiquor.Liveness.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.Liveness = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.Liveness));
            }
            if (vm.TrackLiquor.Nab != null)
            {
                if (vm.TrackLiquor.Nab.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.Nab = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.Nab));
            }
            if (vm.TrackLiquor.Density != null)
            {
                if (vm.TrackLiquor.Density.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.Density = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.Density));
            }
            if (vm.TrackLiquor.LiquorPosition != null)
            {
                if (vm.TrackLiquor.LiquorPosition.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.LiquorPosition = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.LiquorPosition));
            }
            if (vm.TrackLiquor.PositionBulk != null)
            {
                if (vm.TrackLiquor.PositionBulk.Value.ToString().IndexOf('.') > 0)
                    vm.TrackLiquor.PositionBulk = Convert.ToDecimal(String.Format("{0:00.000}", vm.TrackLiquor.PositionBulk));
            }
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View("Edit", vm);
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetTrackLiquorList(TrackLiquorCondition trackLiquorCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<TrackLiquorView> data = this._TrackLiquorRepository.QueryList(trackLiquorCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            string locationId = Request["locationId"];
            if (!string.IsNullOrEmpty(locationId))
                data = data.Where(n => n.StoragePositionId == locationId);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<TrackLiquorView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.LiquorId,
                    List = new List<object>() {
                    d.LiquorId,
                    d.LiquorCode,
                    d.SystemCode,
                    d.WorkTicket,
                    d.Ppm,                                     
                    d.Salt,
                    d.Nab,
                    d.Liveness,
                    d.TransEnd.HasValue? d.TransEnd.Value.ToString("yyyy-MM-dd"):string.Empty,       
                    d.LiquorPosition,
                    d.Cycle,
                    d.ControlName,
                    d.Status,
                    d.DealStatus
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 获得设备信息中的功能位置
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetEquipInfoList(EquipInfoCondition equipInfoCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<EquipInfoView> data = this._EquipInfoRepository.QueryList(equipInfoCondition);  
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<EquipInfoView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.EquipId,
                    List = new List<object>() {
                    d.EquipId,
                    d.EquipName,
                    d.FunctionPosition,                    
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        [HttpPost]
        public JsonResult StationChange(string stationId)
        {
            string simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationId);
            string demo = simpleCode + "CO" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._TrackLiquorRepository.GetAll().Where(d => d.LiquorCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.LiquorCode).First().LiquorCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            return Json("{\"result\":\"" + demo + "\"}", JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 新增浓缩液信息
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(WasteTrackingVM model, FormCollection formCollection)
        {
            //if (ModelState.IsValid)
            //{
            //    return Json("{\"result\":false,\"msg\":\"未验证通过。\"}", JsonRequestBehavior.AllowGet);
            //}
            try
            {
                if (this._TrackLiquorRepository.IsRepeat(model.TrackLiquor.LiquorCode, AppContext.CurrentUser.ProjectCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
                }
                string factoryId = Request["factory"];
                
                if (model.TrackLiquor.TransType == "EQUIP")
                {
                    IQueryable<EquipInfo> functionPositionQuery = _TrackLiquorRepository.QueryListByFunctionPosition(model.TrackLiquor.Trans, AppContext.CurrentUser.ProjectCode);
                    if (functionPositionQuery.Count() != 0)
                    {
                        model.TrackLiquor.EquipId = model.EquipInfo.EquipId;
                        model.TrackLiquor.LiquorId = Guid.NewGuid().ToString();
                        model.TrackLiquor.Status = "0";
                        //model.TrackLiquor.DealStatus = null;
                        model.TrackLiquor.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                        model.TrackLiquor.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                        model.TrackLiquor.CreateDate = DateTime.Now.Date;//创建时间
                        model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._TrackLiquorRepository.Create(model.TrackLiquor);
                        this._TrackLiquorRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的设备编码错误!\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else {
                    model.TrackLiquor.LiquorId = Guid.NewGuid().ToString();
                    model.TrackLiquor.Status = "0";
                    model.TrackLiquor.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.TrackLiquor.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.TrackLiquor.CreateDate = DateTime.Now.Date;//创建时间
                    model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._TrackLiquorRepository.Create(model.TrackLiquor);
                    this._TrackLiquorRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除浓缩液信息
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    TrackLiquor trackLiquor = this._TrackLiquorRepository.Get(id);

                   
                    if (trackLiquor.Status == "2")
                    {
                        if (trackLiquor.DealStatus == "1")
                        {
                            return Json("{\"result\":false,\"msg\":\"删除失败，该条源项废物已被处理。\"}", JsonRequestBehavior.AllowGet);
                        }
                        _NuclearTempstockRepository.MergeWasteTmpStock("LIQUOR", trackLiquor.StoragePositionId, AppContext.CurrentUser.ProjectCode, -1);
                    }
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._TrackLiquorRepository.DeleteById(idVal);
                        TrackLiquor trackLiquorDelete = this._TrackLiquorRepository.Get(idVal);
                        IQueryable<EquipInfo> FunctionPositionQuery = _TrackLiquorRepository.QueryListByFunctionPosition(trackLiquorDelete.Trans, AppContext.CurrentUser.ProjectCode);
                       // List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                        if (FunctionPositionQuery.Count() > 0)
                        {
                            foreach (var item in FunctionPositionQuery)
                            {
                                item.Bulk = item.Bulk - trackLiquorDelete.PositionBulk;
                                this._EquipInfoRepository.Update(item);//提交数据库   
                            }
                        
                        }

                    }
                    this._TrackLiquorRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 提交处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SubmitDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        TrackLiquor trackLiquor = this._TrackLiquorRepository.Get(idVal);
                        trackLiquor.DealStatus = "0";
                        this._TrackLiquorRepository.Update(trackLiquor);
                    }
                    this._TrackLiquorRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ConfirmDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        TrackLiquor trackLiquor = this._TrackLiquorRepository.Get(idVal);
                        trackLiquor.DealStatus = "1";
                        this._TrackLiquorRepository.Update(trackLiquor);
                    }
                    this._TrackLiquorRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确认处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 编辑浓缩液信息
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(WasteTrackingVM model, FormCollection formCollection)
        {
            //if (!ModelState.IsValid)
            //{
            //    return Json("{\"result\":false,\"msg\":\"未验证通过。\"}", JsonRequestBehavior.AllowGet);
            //}

            string newLiquorCode = model.LiquorCode;
            //判断编号是否重复
            if (model.TrackLiquor.LiquorCode != newLiquorCode && this._TrackLiquorRepository.IsRepeat(model.TrackLiquor.LiquorCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                if (model.TrackLiquor.TransType == "EQUIP")
                {
                    IQueryable<EquipInfo> functionPositionQuery = _TrackLiquorRepository.QueryListByFunctionPosition(model.TrackLiquor.Trans, AppContext.CurrentUser.ProjectCode);
                    if (functionPositionQuery.Count() != 0)
                    {
                        model.TrackLiquor.EquipId = model.EquipInfo.EquipId;
                        model.TrackLiquor.Status = "0";
                        model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._TrackLiquorRepository.Update(model.TrackLiquor);
                        this._TrackLiquorRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的设备编码错误!\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else {
                    model.TrackLiquor.Status = "0";
                    model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._TrackLiquorRepository.Update(model.TrackLiquor);
                    this._TrackLiquorRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交浓缩液信息
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(WasteTrackingVM model, FormCollection formCollection)
        {
            //if (!ModelState.IsValid)
            //{
            //    return Json("{\"result\":false,\"msg\":\"未验证通过。\"}", JsonRequestBehavior.AllowGet);
            //}
            string newLiquorCode = model.LiquorCode;
            //判断编号是否重复
            if (model.TrackLiquor.LiquorCode != newLiquorCode && this._TrackLiquorRepository.IsRepeat(model.TrackLiquor.LiquorCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {  
                if (model.TrackLiquor.LiquorId != null)
                {
                    if (model.TrackLiquor.TransType == "EQUIP")
                    {
                        IQueryable<EquipInfo> functionPositionQuery = _TrackLiquorRepository.QueryListByFunctionPosition(model.TrackLiquor.Trans, AppContext.CurrentUser.ProjectCode);
                        if (functionPositionQuery.Count() != 0)
                        {
                            model.TrackLiquor.EquipId = model.EquipInfo.EquipId;
                            model.TrackLiquor.Status = "1";
                            model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                            this._TrackLiquorRepository.Update(model.TrackLiquor);
                            this._TrackLiquorRepository.UnitOfWork.Commit();
                            return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的设备编码错误!\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                    else {
                        model.TrackLiquor.Status = "1";
                        model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._TrackLiquorRepository.Update(model.TrackLiquor);
                        this._TrackLiquorRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else if (model.TrackLiquor.LiquorId == null)
                {
                    if (model.TrackLiquor.TransType == "EQUIP")
                    {
                        IQueryable<EquipInfo> functionPositionQuery = _TrackLiquorRepository.QueryListByFunctionPosition(model.TrackLiquor.Trans, AppContext.CurrentUser.ProjectCode);
                        if (functionPositionQuery.Count() != 0)
                        {
                            model.TrackLiquor.EquipId = model.EquipInfo.EquipId;
                            model.TrackLiquor.LiquorId = Guid.NewGuid().ToString();
                            model.TrackLiquor.Status = "1";
                            model.TrackLiquor.CreateUserNo = AppContext.CurrentUser.UserId;
                            model.TrackLiquor.CreateUserName = AppContext.CurrentUser.UserName;
                            model.TrackLiquor.CreateDate = DateTime.Now.Date;
                            model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                            this._TrackLiquorRepository.Create(model.TrackLiquor);
                            this._TrackLiquorRepository.UnitOfWork.Commit();
                            return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的设备编码错误!\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                    else {
                        model.TrackLiquor.LiquorId = Guid.NewGuid().ToString();
                        model.TrackLiquor.Status = "1";
                        model.TrackLiquor.CreateUserNo = AppContext.CurrentUser.UserId;
                        model.TrackLiquor.CreateUserName = AppContext.CurrentUser.UserName;
                        model.TrackLiquor.CreateDate = DateTime.Now.Date;
                        model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._TrackLiquorRepository.Create(model.TrackLiquor);
                        this._TrackLiquorRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json("{\"result\":true,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认浓缩液信息
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "浓缩液列表")]
        public JsonResult Confirm(WasteTrackingVM model, FormCollection formCollection)
        {
            string newLiquorCode = model.LiquorCode;
            //判断编号是否重复
            if (model.TrackLiquor.LiquorCode != newLiquorCode && this._TrackLiquorRepository.IsRepeat(model.TrackLiquor.LiquorCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                if (model.TrackLiquor.LiquorId != null)
                {
                    if (model.TrackLiquor.TransType == "EQUIP")
                    {
                        IQueryable<EquipInfo> FunctionPositionQuery = _TrackLiquorRepository.QueryListByFunctionPosition(model.TrackLiquor.Trans, AppContext.CurrentUser.ProjectCode);
                        List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                        if (FunctionPositionQuery.Count() != 0)
                        {
                            foreach (var item in FunctionPositionQueryList)
                            {
                                model.EquipInfo.EquipId = item.EquipId;
                                model.TrackLiquor.EquipId = model.EquipInfo.EquipId;

                                if (model.TrackLiquor.PositionBulk != null)
                                {
                                    if (model.Status == "2")
                                    {
                                        if (item.Bulk == null)
                                        {
                                            item.Bulk = model.TrackLiquor.PositionBulk;
                                        }else{
                                        item.Bulk = item.Bulk + (model.TrackLiquor.PositionBulk - model.OldVoulumn);}
                                    }
                                    else {
                                        if (item.Bulk == null)
                                        {
                                            item.Bulk = model.TrackLiquor.PositionBulk;
                                        }
                                        else {
                                            item.Bulk = item.Bulk + model.TrackLiquor.PositionBulk;
                                        } 
                                    }
                                }
                                //if (item.UpdateDate < model.TrackLiquor.TransStart)
                                //{
                                //    item.UpdateDate = model.TrackLiquor.TransStart;
                                //}
                               
                                this._EquipInfoRepository.Update(item);//提交数据库   
                            }
                            if (model.Status != "2")
                            {
                                _NuclearTempstockRepository.MergeWasteTmpStock("LIQUOR", model.TrackLiquor.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                            }
                            else {
                                if (model.TrackLiquor.StoragePositionId != model.NewStoragePositionId) {
                                    _NuclearTempstockRepository.MergeWasteTmpStock("LIQUOR", model.NewStoragePositionId, AppContext.CurrentUser.ProjectCode, -1);
                                    _NuclearTempstockRepository.MergeWasteTmpStock("LIQUOR", model.TrackLiquor.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                                }
                            }
                            model.TrackLiquor.EquipId = model.EquipInfo.EquipId;
                            
                            model.TrackLiquor.Status = "2";
                            model.TrackLiquor.ConfirmUserNo = AppContext.CurrentUser.UserId;
                            model.TrackLiquor.ConfirmUserName = AppContext.CurrentUser.UserName;
                            model.TrackLiquor.ConfirmDate = DateTime.Now.Date;
                            model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                            this._TrackLiquorRepository.Update(model.TrackLiquor);
                            
                            
                            this._TrackLiquorRepository.UnitOfWork.Commit();
                            return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的设备编码错误!\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                    else {
                        model.TrackLiquor.Status = "2";
                        model.TrackLiquor.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        model.TrackLiquor.ConfirmUserName = AppContext.CurrentUser.UserName;
                        model.TrackLiquor.ConfirmDate = DateTime.Now.Date;
                        model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._TrackLiquorRepository.Update(model.TrackLiquor);
                        if (model.Status != "2")
                        {
                            _NuclearTempstockRepository.MergeWasteTmpStock("LIQUOR", model.TrackLiquor.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                        }
                        else
                        {
                            if (model.TrackLiquor.StoragePositionId != model.NewStoragePositionId)
                            {
                                _NuclearTempstockRepository.MergeWasteTmpStock("LIQUOR", model.NewStoragePositionId, AppContext.CurrentUser.ProjectCode, -1);
                                _NuclearTempstockRepository.MergeWasteTmpStock("LIQUOR", model.TrackLiquor.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                            }
                        }
                        this._TrackLiquorRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else if (model.TrackLiquor.LiquorId == null)
                {
                    if (model.TrackLiquor.TransType == "EQUIP")
                    {
                        IQueryable<EquipInfo> FunctionPositionQuery = _TrackLiquorRepository.QueryListByFunctionPosition(model.TrackLiquor.Trans, AppContext.CurrentUser.ProjectCode);
                        List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                        if (FunctionPositionQuery.Count() != 0)
                        {
                            foreach (var item in FunctionPositionQueryList)
                            {
                                model.EquipInfo.EquipId = item.EquipId;
                                model.TrackLiquor.EquipId = model.EquipInfo.EquipId;
                            }
                            model.TrackLiquor.LiquorId = Guid.NewGuid().ToString();
                            model.TrackLiquor.Status = "2";
                            model.TrackLiquor.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                            model.TrackLiquor.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                            model.TrackLiquor.CreateDate = DateTime.Now.Date;//创建时间
                            model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                            model.TrackLiquor.ConfirmUserNo = AppContext.CurrentUser.UserId;
                            model.TrackLiquor.ConfirmUserName = AppContext.CurrentUser.UserName;
                            model.TrackLiquor.ConfirmDate = DateTime.Now;
                            this._TrackLiquorRepository.Create(model.TrackLiquor);
                            EquipInfo equipInfo = this._EquipInfoRepository.Get(model.EquipInfo.EquipId);
                            if (model.TrackLiquor.PositionBulk != null)
                            {
                                if (equipInfo.Bulk == null)
                                { 
                                    equipInfo.Bulk = model.TrackLiquor.PositionBulk; 
                                }
                                else
                                {
                                    equipInfo.Bulk = equipInfo.Bulk + model.TrackLiquor.PositionBulk;
                                }
                            }
                           
                            //if (equipInfo.UpdateDate < model.TrackLiquor.TransStart)
                            //{
                            //    equipInfo.UpdateDate = model.TrackLiquor.TransStart;
                            //}
                            this._EquipInfoRepository.Update(equipInfo);//提交数据库   
                            _NuclearTempstockRepository.MergeWasteTmpStock("LIQUOR", model.TrackLiquor.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                            this._TrackLiquorRepository.UnitOfWork.Commit();
                            return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的设备编码错误!\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                    else {
                        model.TrackLiquor.LiquorId = Guid.NewGuid().ToString();
                        model.TrackLiquor.Status = "2";
                        model.TrackLiquor.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                        model.TrackLiquor.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                        model.TrackLiquor.CreateDate = DateTime.Now.Date;//创建时间
                        model.TrackLiquor.Stationcode = AppContext.CurrentUser.ProjectCode;
                        model.TrackLiquor.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        model.TrackLiquor.ConfirmUserName = AppContext.CurrentUser.UserName;
                        model.TrackLiquor.ConfirmDate = DateTime.Now;
                        this._TrackLiquorRepository.Create(model.TrackLiquor);
                        _NuclearTempstockRepository.MergeWasteTmpStock("LIQUOR", model.TrackLiquor.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                        this._TrackLiquorRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        //获得设备编号
        public JsonResult GetDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<EquipInfo> list = new List<EquipInfo>();
            if (keyword.ToUpper().Trim() != null && keyword.ToUpper().Trim() != "")
            {
                IQueryable<EquipInfo> iqueryEquipInfo = _EquipInfoRepository.GetAll().AsQueryable().Where(e => e.FunctionPosition.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.Status == "2");
                if (iqueryEquipInfo.Count() > 0)
                {
                    list = iqueryEquipInfo.ToList();
                }
            }
            List<BasicObject> functionQuery = _BasicObjectRepository.GetAll().Where(d => d.Name == "固体废物处理设备").AsQueryable().ToList();
            if (!string.IsNullOrEmpty(functionQuery[0].Uuid))
                list = list.Where(n => n.EquipTypeId == functionQuery[0].Uuid).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].FunctionPosition;
                autoComplete.Code = list[i].EquipId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        #region 得到所有的源项跟踪单信息
        /// <summary>
        /// 得到所有的源项跟踪单信息
        /// </summary>
        /// <param name="trackCode">废物跟踪单号</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetSourceTrackList(string trackCode,string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<TrackItemVM> data = TrackItemBuilder.GetAllTrackList(trackCode,AppContext.CurrentUser.ProjectCode);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<TrackItemVM>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.TrackId,
                    List = new List<object>() {
                    d.TrackId,
                    ConvertTypeToName(d.TrackType),
                    d.TrackCode,
                    d.SystemCode,
                    d.UnitStatus=="0"?"大修":"日常",        
                    d.Cycle
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 根据源项类型编号返回源项类型名称
        /// </summary>
        /// <param name="trackType">源项类型编号</param>
        /// <returns></returns>
        public string ConvertTypeToName(string trackType)
        {
            string trackTypeName = string.Empty;
            switch (trackType)
            {
                case "LIQUID":
                    trackTypeName = "浓缩液";
                    break;
                case "RESIN":
                    trackTypeName = "废树脂";
                    break;
                case "ELEMENT":
                    trackTypeName = "废滤芯";
                    break;
                case "DEPOSIT":
                    trackTypeName = "淤积物";
                    break;
                case "SOLVENT":
                    trackTypeName = "废油和溶剂";
                    break;
                case "FILTER":
                    trackTypeName = "通风过滤器";
                    break;
                case "TECH1":
                    trackTypeName = "技术废物(>2mSv/h)";
                    break;
                case "TECH2":
                    trackTypeName = "技术废物<2mSv/h)";
                    break;
                case "SUNDRY":
                    trackTypeName = "杂项";
                    break;
                default:
                    break;
            }
            return trackTypeName;
        }
        #endregion
    }
}
