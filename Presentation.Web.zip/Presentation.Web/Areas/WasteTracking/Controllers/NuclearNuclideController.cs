﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View.SourceManage;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using RWIS.Domain.DomainObjects.View.Support;
using Newtonsoft.Json;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.WasteTracking.Controllers
{
    public class NuclearNuclideController : Controller
    {
        INuclearNuclideRepository _NuclearNuclideRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearNuclideSampleRepository _NuclearNuclideSampleRepository;
        INuclearSampleDetailRepository _NuclearSampleDetailRepository;
        ISupportEdsRepository _SupportEdsRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        INuclearElementRepository iNuclearElementRepository;
        ISupportEdsDetailRepository _SupportEdsDetailRepository;
        public NuclearNuclideController(INuclearNuclideRepository _NuclearNuclideRepository, IBasicObjectRepository _BasicObjectRepository, INuclearNuclideSampleRepository _NuclearNuclideSampleRepository, ISupportEdsRepository _SupportEdsRepository, INuclearSampleDetailRepository _NuclearSampleDetailRepository, INuclearBucketRepository _NuclearBucketRepository
            , INuclearElementRepository _iNuclearElementRepository, ISupportEdsDetailRepository _SupportEdsDetailRepository)
        {
            this._NuclearNuclideRepository = _NuclearNuclideRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearNuclideSampleRepository = _NuclearNuclideSampleRepository;
            this._SupportEdsRepository = _SupportEdsRepository;
            this._NuclearSampleDetailRepository = _NuclearSampleDetailRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this.iNuclearElementRepository = _iNuclearElementRepository;
            this._SupportEdsDetailRepository = _SupportEdsDetailRepository;
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "核素分析单列表")]
        public ActionResult Index()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Nuclide");
            //加载废物类型
            vm.NuClearTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> nuClearTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> nuClearTypeList = new List<BasicObject>();
            if (nuClearTypeQuery!=null && nuClearTypeQuery.Count() > 0)
            {
                nuClearTypeList = nuClearTypeQuery.ToList();
                vm.NuClearTypeList.Add(new SelectListItem { Text = "请选择", Value = "" });
                foreach (var item in nuClearTypeList)
                {
                    vm.NuClearTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            return View(vm);
        }
        public ActionResult Add()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Nuclide");
            LoadWasteTracking(vm);
            return View(vm);
        }
        public ActionResult Edit(string id)
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Nuclide");
            LoadWasteTracking(vm);
            NuclearNuclide model = _NuclearNuclideRepository.Get(id);
            model.EdsId = _SupportEdsRepository.GetCodeById(model.EdsId, AppContext.CurrentUser.ProjectCode);
            IQueryable<NuclearSampleDetail> nuclearSampleDetail = _NuclearSampleDetailRepository.QueryListById(model.NuclideId);
            foreach (var item in nuclearSampleDetail)
            {
                NuclearSampleDetail models = _NuclearSampleDetailRepository.Get(item.DetailId);
            }
            List<NuclearNuclideSample> nuclearNuclideSampleList = new List<NuclearNuclideSample>();
            List<NuclearSampleDetail> nuclearSampleDetailList = new List<NuclearSampleDetail>();
            vm.NuclearNuclide = model;
            SupportEds supportEds = new SupportEds();
            IQueryable<SupportEds> supportEdsQuery = _NuclearNuclideRepository.QueryListByEdsId(model.EdsId);
            foreach (var item in supportEdsQuery)
            {
                supportEds.EdsId = item.EdsId ; 
            } 
            vm.SupportEds = supportEds;
            List<NuclearSampleDetail> nuclearSampleDetailQuery = _NuclearSampleDetailRepository.GetAll().Where(d => d.NuclideId == model.NuclideId).ToList();
            ///如果数字类型不为空，截取小数点后三位
            for (int i = 0; i < nuclearSampleDetailQuery.Count(); i++)
			{
			    if (nuclearSampleDetailQuery[i].ActivityValue != null)
                {
                    if (nuclearSampleDetailQuery[i].ActivityValue.Value.ToString().IndexOf('.') > 0)
                        nuclearSampleDetailQuery[i].ActivityValue = Convert.ToDecimal(String.Format("{0:00.000}", nuclearSampleDetailQuery[i].ActivityValue));
                }
			}
            vm.NuclearSampleDetailList = nuclearSampleDetailQuery;
            return View(vm);
        }
        public ActionResult DetailView(string id)
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Nuclide");
            LoadWasteTracking(vm);
            NuclearNuclide model = _NuclearNuclideRepository.Get(id);
            if (model != null)
            {
                model.EdsId = _SupportEdsRepository.GetCodeById(model.EdsId, AppContext.CurrentUser.ProjectCode);
            }
            IQueryable<NuclearSampleDetail> nuclearSampleDetail = _NuclearSampleDetailRepository.QueryListById(model.NuclideId);
            foreach (var item in nuclearSampleDetail)
            {
                NuclearSampleDetail models = _NuclearSampleDetailRepository.Get(item.DetailId);
            }
            List<NuclearNuclideSample> nuclearNuclideSampleList = new List<NuclearNuclideSample>();
            List<NuclearSampleDetail> nuclearSampleDetailList = new List<NuclearSampleDetail>();
            BasicObject basicObjectNuClearType = _BasicObjectRepository.Get(model.WasteTypeId);
            if (basicObjectNuClearType != null)
            {
                vm.WasteTypeName = basicObjectNuClearType.Name;
            }
            SupportEds supportEds = new SupportEds();
            IQueryable<SupportEds> supportEdsQuery = _NuclearNuclideRepository.QueryListByEdsId(model.EdsId);
            foreach (var item in supportEdsQuery)
            {
                supportEds.EdsId = item.EdsId; 
                supportEds.EdsSerialCode = item.EdsSerialCode;
            }
            vm.SupportEds = supportEds;
            vm.NuclearNuclide = model;
            List<NuclearSampleDetail> nuclearSampleDetailQuery = _NuclearSampleDetailRepository.GetAll().Where(d => d.NuclideId == model.NuclideId).ToList();
            ///如果数字类型不为空，截取小数点后三位
            for (int i = 0; i < nuclearSampleDetailQuery.Count(); i++)
            {
                if (nuclearSampleDetailQuery[i].ActivityValue != null)
                {
                    if (nuclearSampleDetailQuery[i].ActivityValue.Value.ToString().IndexOf('.') > 0)
                        nuclearSampleDetailQuery[i].ActivityValue = Convert.ToDecimal(String.Format("{0:00.000}", nuclearSampleDetailQuery[i].ActivityValue));
                }
            }
            return View("DetailView", vm);
        }
        /// <summary>
        /// 加载废物类型以及能谱类项
        /// </summary>
        /// <param name="vm"></param>
        /// <returns></returns>
        WasteTrackingVM LoadWasteTracking(WasteTrackingVM vm)
        {
            //加载废物类型
            vm.NuClearTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> nuClearTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("NuClearType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> nuClearTypeList = new List<BasicObject>();
            if (nuClearTypeQuery!=null&&nuClearTypeQuery.Count() > 0)
            {
                nuClearTypeList = nuClearTypeQuery.ToList();
                foreach (var item in nuClearTypeList)
                {
                    vm.NuClearTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            

            //加载谱类型
            vm.EdsTypeList = new List<SelectListItem>();
            vm.EdsTypeList.Add(new SelectListItem { Text = "请选择", Value = "" });
            vm.EdsTypeList.Add(new SelectListItem { Text = "标准谱", Value = "S" });
            vm.EdsTypeList.Add(new SelectListItem { Text = "测量谱", Value = "M" });
            vm.EdsTypeList.Add(new SelectListItem { Text = "计算谱", Value = "C" });
            return vm;
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNuclearNuclideList(NuclearTrackNuclideCondition nuclearTrackNuclideCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearTrackNuclideView> data = this._NuclearNuclideRepository.QueryList(nuclearTrackNuclideCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode); ;
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearTrackNuclideView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.NuclideId,
                    List = new List<object>() {
                    d.NuclideId,
                    d.WasteSource,
                    d.WasteTypeName,
                    d.WasteTypeId,
                    d.AnalyzeName,
                    d.AnalyzeDate.HasValue? d.AnalyzeDate.Value.ToString("yyyy-MM-dd"):string.Empty,  
                    d.AnalyzeCompany,
                    d.Status,
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNuclearNuclideSampleList(string NuclideId, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearNuclideSampleView> data = this._NuclearNuclideSampleRepository.QueryList(NuclideId).Where(d => d.NuclideId == NuclideId).AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearNuclideSampleView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.SampleId,
                    List = new List<object>() {
                    d.SampleId,
                    d.NuclideId,
                    d.SampleNum,
                    d.SamplingDate,
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetSupportEdsList(SupportEdsCondition supportEdsCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<SupportEdsView> data = this._SupportEdsRepository.QueryList(supportEdsCondition);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<SupportEdsView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.EdsId,
                    List = new List<object>() {
                    d.EdsId,
                    d.EdsSerialCode,
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._NuclearNuclideRepository.DeleteById(idVal);
                    }
                    this._NuclearNuclideRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        #region 保存或提交核素分析单
        /// <summary>
        /// 保存或修改核素分析单
        /// </summary>
        /// <param name="model">核素分析单信息</param>
        /// <param name="detailList">样品明细信息</param>
        /// <returns></returns>
        private string SaveNuclide(WasteTrackingVM model, List<ElementDetail> detailList)
        {
            string saveResult = string.Empty;
            var iquerySample = from i in detailList
                               where i.Id == "SampleNum" || i.Id == "SampleDate"
                               select i;

            List<ElementDetail> selectedList = new List<ElementDetail>();
            if (iquerySample.Count() > 0)
            {
                selectedList = iquerySample.ToList();
            }

            #region 新增或修改

            if (string.IsNullOrEmpty(model.NuclearNuclide.NuclideId))
            {
                //核素分析单主单信息
                model.NuclearNuclide.NuclideId = Guid.NewGuid().ToString();
                model.NuclearNuclide.CreateDate = DateTime.Now;
                model.NuclearNuclide.CreateUserNo = AppContext.CurrentUser.UserId;
                model.NuclearNuclide.CreateUserName = AppContext.CurrentUser.UserName;
                model.NuclearNuclide.StationCode = AppContext.CurrentUser.ProjectCode;
                //核素能谱序号转成Id
                model.NuclearNuclide.EdsId = _SupportEdsRepository.GetIdByCode(model.NuclearNuclide.EdsId, AppContext.CurrentUser.ProjectCode);
                this._NuclearNuclideRepository.Create(model.NuclearNuclide);

                //样品信息
                string bucketId = "";
                foreach (var item in selectedList)
                {
                    if (item.Id == "SampleDate")
                    {
                        bucketId = this._NuclearBucketRepository.IsExistWasteBucket(item.BucketCode, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            saveResult = "桶号" + item.BucketCode + "在系统中不存在";
                            return saveResult;
                        }

                        //添加样品信息
                        NuclearNuclideSample sample = new NuclearNuclideSample();
                        sample.SampleId = Guid.NewGuid().ToString();
                        sample.NuclideId = model.NuclearNuclide.NuclideId;
                        sample.SampleNum = bucketId;
                        sample.SamplingDate = DateTime.Parse(item.Value);
                        this._NuclearNuclideSampleRepository.Create(sample);

                        //添加样品核素信息
                        foreach (var detail in detailList)
                        {
                            NuclearSampleDetail sampleDetail = new NuclearSampleDetail();
                            if (detail.Id != "SampleNum" && detail.Id != "SampleDate" && detail.BucketCode.ToUpper().Trim() == item.BucketCode.ToUpper().Trim())
                            {
                                sampleDetail.NuclideId = model.NuclearNuclide.NuclideId;
                                sampleDetail.SampleId = sample.SampleId;
                                sampleDetail.ElementId =iNuclearElementRepository.GetIdByName( detail.Id);
                                sampleDetail.DetailId = Guid.NewGuid().ToString();
                                sampleDetail.ActivityValue = string.IsNullOrEmpty(detail.Value) ? 0 : decimal.Parse(detail.Value);
                                this._NuclearSampleDetailRepository.Create(sampleDetail);
                            }
                        }
                        continue;
                    }
                }
            }
            else {

                model.NuclearNuclide.StationCode = AppContext.CurrentUser.ProjectCode;
                //核素能谱序号转成Id
                model.NuclearNuclide.EdsId = _SupportEdsRepository.GetIdByCode(model.NuclearNuclide.EdsId, AppContext.CurrentUser.ProjectCode);

                this._NuclearNuclideRepository.Update(model.NuclearNuclide);
                //根据核素分析单ID查询核素分析单样品
                IQueryable<NuclearNuclideSample> data = this._NuclearNuclideRepository.QueryListSampleId(model.NuclearNuclide.NuclideId);
                List<NuclearNuclideSample> listData = data.ToList();
                //删除核素分析单样品数据
                foreach (var item in listData)
                {
                    this._NuclearNuclideSampleRepository.DeleteById(item.SampleId);
                }
                //根据核素分析单ID查询样品分析表
                IQueryable<NuclearSampleDetail> datas = this._NuclearNuclideRepository.QueryListDetailId(model.NuclearNuclide.NuclideId);
                List<NuclearSampleDetail> listDatas = datas.ToList();
                //删除核素分析单样品数据
                foreach (var item in listDatas)
                {
                    this._NuclearSampleDetailRepository.DeleteById(item.DetailId);
                }
                //样品信息
                string bucketId = "";
                foreach (var item in selectedList)
                {
                    if (item.Id == "SampleDate")
                    {
                        bucketId = this._NuclearBucketRepository.IsExistWasteBucket(item.BucketCode, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            saveResult = "桶号" + item.BucketCode + "在系统中不存在";
                            return saveResult;
                        }

                        //添加样品信息
                        NuclearNuclideSample sample = new NuclearNuclideSample();
                        sample.SampleId = Guid.NewGuid().ToString();
                        sample.NuclideId = model.NuclearNuclide.NuclideId;
                        sample.SampleNum = bucketId;
                        sample.SamplingDate = DateTime.Parse(item.Value);
                        this._NuclearNuclideSampleRepository.Create(sample);

                        //添加样品核素信息
                        foreach (var detail in detailList)
                        {
                            NuclearSampleDetail sampleDetail = new NuclearSampleDetail();
                            if (detail.Id != "SampleNum" && detail.Id != "SampleDate" && detail.BucketCode.ToUpper().Trim() == item.BucketCode.ToUpper().Trim())
                            {
                                sampleDetail.NuclideId = model.NuclearNuclide.NuclideId;
                                sampleDetail.SampleId = sample.SampleId;
                                sampleDetail.ElementId = iNuclearElementRepository.GetIdByName(detail.Id);
                                sampleDetail.DetailId = Guid.NewGuid().ToString();
                                sampleDetail.ActivityValue = string.IsNullOrEmpty(detail.Value) ? 0 : decimal.Parse(detail.Value);
                                this._NuclearSampleDetailRepository.Create(sampleDetail);
                            }
                        }
                        continue;
                    }
                }
            }
            #endregion 新增或修改
            return saveResult;
        }

        /// <summary>
        /// 保存或修改核素分析单
        /// </summary>
        /// <param name="model">核素分析单信息</param>
        /// <param name="list">样品明细信息</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Save(WasteTrackingVM model,string list, FormCollection formCollection)
        {
            List<ElementDetail> detailList = JsonConvert.DeserializeObject<List<ElementDetail>>(list);
            try
            {
                model.NuclearNuclide.Status = "0";
               string saveResult= SaveNuclide(model, detailList);
               if (!string.IsNullOrEmpty(saveResult))
               {
                   return Json("{\"result\":false,\"msg\":\"" + saveResult + "。\"}", JsonRequestBehavior.AllowGet);
               }
                this._NuclearNuclideRepository.UnitOfWork.Commit();
            }
            catch(Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"保存失败"+ex.Message+"。\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 提交核素分析单
        /// </summary>
        /// <param name="model">核素分析单信息</param>
        /// <param name="list">样品明细信息</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(WasteTrackingVM model, string list, FormCollection formCollection)
        {
            List<ElementDetail> detailList = JsonConvert.DeserializeObject<List<ElementDetail>>(list);
            try
            {
                model.NuclearNuclide.Status = "1";
                string saveResult = SaveNuclide(model, detailList);
                if (!string.IsNullOrEmpty(saveResult))
                {
                    return Json("{\"result\":false,\"msg\":\"" + saveResult + "。\"}", JsonRequestBehavior.AllowGet);
                }
                this._NuclearNuclideRepository.UnitOfWork.Commit();
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"提交失败" + ex.Message + "。\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 确认核素分析单
        /// </summary>
        /// <param name="model">核素分析单信息</param>
        /// <param name="list">样品明细信息</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "核素分析单列表确认")]
        public JsonResult Confirm(WasteTrackingVM model, string list, FormCollection formCollection)
        {
            List<ElementDetail> detailList = JsonConvert.DeserializeObject<List<ElementDetail>>(list);
            try
            {
                model.NuclearNuclide.Status = "2";
                model.NuclearNuclide.ConfirmDate = DateTime.Now;
                model.NuclearNuclide.ConfirmUserNo = AppContext.CurrentUser.UserId;
                model.NuclearNuclide.ConfirmUserName = AppContext.CurrentUser.UserName;
                string saveResult = SaveNuclide(model, detailList);
                if (!string.IsNullOrEmpty(saveResult))
                {
                    return Json("{\"result\":false,\"msg\":\"" + saveResult + "。\"}", JsonRequestBehavior.AllowGet);
                }
                this._NuclearNuclideRepository.UnitOfWork.Commit();
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"确认失败" + ex.Message + "。\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
        }
        #endregion
        //获得所有桶号
        public JsonResult GetDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            if (keyword.ToUpper().Trim() != null && keyword.ToUpper().Trim() != "")
            {
                IQueryable<NuclearBucket> iqueryNuclearBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsOutSend == "0" || e.IsOutSend == null));

                if (iqueryNuclearBucket.Count() > 0)
                {
                    list = iqueryNuclearBucket.ToList();
                }
            }
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        #region 获取核素信息

        public JsonResult GetNuclearElementInfo(WasteTrackingVM activityVM)
        {
            try
            {
                List<NuclearNuclideSample> nuclearNuclideSampleList = new List<NuclearNuclideSample>();
                nuclearNuclideSampleList = _NuclearNuclideSampleRepository.GetAll().Where(e => e.NuclideId == activityVM.NuclearNuclide.NuclideId).ToList();
               
               List<List<NuclearSampleDetail>> nuclearSampleDetailList = new List<List<NuclearSampleDetail>>();

               List<List<NuclearElementDetail>> nuclearElementDetailList = new List<List<NuclearElementDetail>>();
                
                if (nuclearNuclideSampleList!=null||nuclearNuclideSampleList.Count>0)
                {
                    for (int i = 0; i < nuclearNuclideSampleList.Count; i++)
                    {
                        List<NuclearSampleDetail> nuclearSampleDetail=new List<NuclearSampleDetail>();

                        string sapId=nuclearNuclideSampleList[i].SampleId;
                        nuclearSampleDetail=_NuclearSampleDetailRepository.GetAll().Where(e=>e.SampleId==sapId).ToList();

                        nuclearSampleDetailList.Add(nuclearSampleDetail);

                        List<NuclearElementDetail> nuclearElementDetail = new List<NuclearElementDetail>();

                        for (int j = 0; j < nuclearSampleDetail.Count; j++)
                        {
                            NuclearElementDetail nuc = new NuclearElementDetail();
                            //nuc.Name= _NuclearNuclideRepository.IsExistElenentNameById(elementId, AppContext.CurrentUser.ProjectCode);
                            nuc.Name = iNuclearElementRepository.GetNameById(nuclearSampleDetail[j].ElementId);
                            nuc.Value = nuclearSampleDetail[j].ActivityValue;
                            //nuc.SampleNum = nuclearNuclideSampleList[i].SampleNum;
                            //nuc.StrSamplingDate = nuclearNuclideSampleList[i].SamplingDate.HasValue ? nuclearNuclideSampleList[i].SamplingDate.Value.ToString("yyyy-MM-dd") : string.Empty;
                            nuclearElementDetail.Add(nuc);
                        }

                        nuclearElementDetailList.Add(nuclearElementDetail);
                    }
                }


                for (int i = 0; i < nuclearNuclideSampleList.Count; i++)
                {
                    nuclearNuclideSampleList[i].SampleNum = _NuclearNuclideRepository.IsExistWasteBucketById(nuclearNuclideSampleList[i].SampleNum, AppContext.CurrentUser.ProjectCode);
                    nuclearNuclideSampleList[i].StrSamplingDate = nuclearNuclideSampleList[i].SamplingDate.HasValue ? nuclearNuclideSampleList[i].SamplingDate.Value.ToString("yyyy-MM-dd") : string.Empty;

                }

                var resultObj = new
                {
                    nuclearNuclideSampleList,
                    nuclearElementDetailList
                };
                return Json(resultObj, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {

                throw;
            }

        }

        public JsonResult GetSupportEdsInfo(WasteTrackingVM activityVM)
        {
            try
            {
                List<SupportEds> supportEds = _SupportEdsRepository.GetAll().Where(d => d.EdsSerialCode == activityVM.NuclearNuclide.EdsId).AsQueryable().ToList();
                List<SupportEdsDetail> supportEdsDetailList = new List<SupportEdsDetail>();

                supportEdsDetailList = _SupportEdsDetailRepository.GetAll().Where(e => e.EdsId == supportEds[0].EdsId).ToList();

                List<NuclearElementDetail> nuclearElementDetailList = new List<NuclearElementDetail>();
                if (supportEdsDetailList != null || supportEdsDetailList.Count > 0)
                {
                    for (int i = 0; i < supportEdsDetailList.Count; i++)
                    {
                        NuclearElementDetail nuc = new NuclearElementDetail();
                        nuc.Name = iNuclearElementRepository.GetNameById(supportEdsDetailList[i].ElementId);
                        nuc.Value = Convert.ToDecimal(supportEdsDetailList[i].PercentValue);
                        nuclearElementDetailList.Add(nuc);
                    }
                }
                var resultObj = new
                {
                    nuclearElementDetailList
                };
                return Json(resultObj, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {

                throw;
            }

        }
        #endregion
    }
}
