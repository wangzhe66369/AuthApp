﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   NuclearTrackElementController.cs
 *   描    述   ：   废滤芯Controller
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View.SourceManage;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using RWIS.Presentation.Web.Core.Common;
using System.Data;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Areas.Activity.ViewModels;
using Newtonsoft.Json;

namespace RWIS.Presentation.Web.Areas.WasteTracking.Controllers
{
    public class NuclearTrackElementController : Controller
    {
        INuclearTrackElementRepository _NuclearTrackElementRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IEquipInfoRepository _EquipInfoRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        INuclearTrackTechSRepository _NuclearTrackTechSRepository;
        INuclearTrackTechBRepository _NuclearTrackTechBRepository;
        public NuclearTrackElementController(INuclearTrackElementRepository _NuclearTrackElementRepository, IBasicObjectRepository _BasicObjectRepository, IEquipInfoRepository _EquipInfoRepository, INuclearBucketRepository _NuclearBucketRepository, IBasicWasteUnitRepository _BasicWasteUnitRepository,
            INuclearTempstockRepository _NuclearTempstockRepository,
            INuclearTrackTechSRepository _NuclearTrackTechSRepository,
            INuclearTrackTechBRepository _NuclearTrackTechBRepository)
        {
            this._NuclearTrackElementRepository = _NuclearTrackElementRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._EquipInfoRepository = _EquipInfoRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
            this._NuclearTempstockRepository = _NuclearTempstockRepository;
            this._NuclearTrackTechSRepository = _NuclearTrackTechSRepository;
            this._NuclearTrackTechBRepository = _NuclearTrackTechBRepository;
        }
        /// <summary>
        /// 灵活条件查询
        /// </summary>
        /// <param name="stationId"></param>
        /// <returns></returns>
        public JsonResult SelecteCondition(string activityId)
        {


            List<ActivityCountCode> ActivityCountCodeList = new List<ActivityCountCode>();
            ActivityCountCode activityCount = new ActivityCountCode();
            activityCount.Name = "请选择";
            activityCount.Code = "";
            ActivityCountCodeList.Add(activityCount);
           
            //加载电站

            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList != null && QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    ActivityCountCode activityCountCode = new ActivityCountCode();
                    activityCountCode.Name = item.UnitName;
                    activityCountCode.Code = item.UnitId.ToString();
                    ActivityCountCodeList.Add(activityCountCode);
                }
            }


            string str = JsonConvert.SerializeObject(ActivityCountCodeList);
            return Json(str, JsonRequestBehavior.AllowGet);

        }

        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废滤芯列表")]
        public ActionResult Index()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Element");
            //加载工作类型
            vm.WorkTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> workTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("WorkType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> workTypeList = new List<BasicObject>();
            if (workTypeQuery!=null&&workTypeQuery.Count() > 0)
            {
                workTypeList = workTypeQuery.ToList();
                vm.WorkTypeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in workTypeList)
                {
                    vm.WorkTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            string locationId = Request["locationId"];
            ViewBag.Location = locationId;
            //加载状态
            vm.StatusList = new List<SelectListItem>();
            vm.StatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.StatusList.Add(new SelectListItem { Text = "草稿", Value = "0" });
            vm.StatusList.Add(new SelectListItem { Text = "未确认", Value = "1" });
            vm.StatusList.Add(new SelectListItem { Text = "已确认", Value = "2" });

            vm.DealStatusList = new List<SelectListItem>();
            vm.DealStatusList.Add(new SelectListItem { Text = "待确认处理状态", Value = "0" });
            vm.DealStatusList.Add(new SelectListItem { Text = "已处理", Value = "1" });


            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                vm.StationCodeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null && storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
          
            return View(vm);
        }

        public ActionResult Add()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Element");
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });
            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null && storagePositionIdQuery.Count() > 0)
            {
                vm.StoragePositionIdList.Add(new SelectListItem { Text = "请选择", Value = string.Empty});
                storagePositionIdList = storagePositionIdQuery.ToList();
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
          
            NuclearTrackElement nuclearTrackElement = new NuclearTrackElement();
            string simpleCode = "";
            if (stationList.Count() > 0)
            {
                simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationList[0].UnitId);
            }
            string demo = simpleCode + "FI" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackElementRepository.GetAll().Where(d => d.ElementCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.ElementCode).First().ElementCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            nuclearTrackElement.ElementCode = demo;
            vm.NuclearTrackElement = nuclearTrackElement;
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DetailView(string id)
        {
            ViewBag.ViewStatus = Request["status"];
            NuclearTrackElement model = _NuclearTrackElementRepository.Get(id);
            WasteTrackingVM vm = new WasteTrackingVM();
            BasicWasteUnit basicObjectStationcode = _BasicWasteUnitRepository.Get(model.StationId);
            BasicObject basicObjectFactoryPositionId = _BasicObjectRepository.Get(model.FactoryPositionId);
            BasicObject basicObjectStorageContainerId = _BasicObjectRepository.Get(model.StorageContainerId);
            if (basicObjectStationcode != null)
            {
                vm.StationCodeName = basicObjectStationcode.UnitName;
            }
            else {
                vm.StationCodeName = "";
            }
            if (basicObjectFactoryPositionId != null)
            {
                vm.StoragePositionName = basicObjectFactoryPositionId.Name;
            }
            else {
                vm.StoragePositionName = "";
            }
            if (basicObjectStorageContainerId != null)
            {
                vm.StorageContainerName = basicObjectStorageContainerId.Name;
            }
            else {
                vm.StorageContainerName = "";
            }
            if (!string.IsNullOrEmpty(model.ContainerId))
            {
                NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(model.ContainerId);
                if (nuclearBucket != null)
                {
                    model.ContainerId = nuclearBucket.BucketCode;
                }
                else
                {
                    model.ContainerId = "";
                }
            }
            if (!string.IsNullOrEmpty(model.InputContainerId))
            {
                NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(model.InputContainerId);
                if (nuclearBucket != null)
                {
                    model.InputContainerId = nuclearBucket.BucketCode;
                }
                else
                {
                    model.InputContainerId = "";
                }
            }
            vm.NuclearTrackElement = model;
            ///如果数字类型不为空，截取小数点后三位
            if (vm.NuclearTrackElement.SurfaceTouch != null)
            {
                if (vm.NuclearTrackElement.SurfaceTouch.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackElement.SurfaceTouch = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackElement.SurfaceTouch));
            }
            if (vm.NuclearTrackElement.LeadSurface != null)
            {
                if (vm.NuclearTrackElement.LeadSurface.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackElement.LeadSurface = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackElement.LeadSurface));
            }
            if (vm.NuclearTrackElement.ContainerTouchdose != null)
            {
                if (vm.NuclearTrackElement.ContainerTouchdose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackElement.ContainerTouchdose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackElement.ContainerTouchdose));
            }
            if (vm.NuclearTrackElement.InputContainerTouchdose != null)
            {
                if (vm.NuclearTrackElement.InputContainerTouchdose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackElement.InputContainerTouchdose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackElement.InputContainerTouchdose));
            }
            return View("DetailView", vm);
        }
        public ActionResult Edit(string id)
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Element");
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0" });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });

            //加载放射性
            vm.FilterFlagYesList = new List<SelectListItem>();
            vm.FilterFlagYesList.Add(new SelectListItem { Text = "放射性", Value = "1" });
            //加载非放射性
            vm.FilterFlagNoList = new List<SelectListItem>();
            vm.FilterFlagNoList.Add(new SelectListItem { Text = "非放射性", Value = "0" });

            //加载暂存厂房
            vm.FactoryList = new List<SelectListItem>();
            vm.FactoryList.Add(new SelectListItem { Text = "暂存厂房", Value = "Factory" });
            //加载暂存铅容器
            vm.LeadContainerList = new List<SelectListItem>();
            vm.LeadContainerList.Add(new SelectListItem { Text = "暂存铅容器", Value = "LeadContainer" });
            //加载暂存包装容器
            vm.PackContainerList = new List<SelectListItem>();
            vm.PackContainerList.Add(new SelectListItem { Text = "暂存包装容器", Value = "PackContainer" });
            //加载装入包装容器
            vm.InputPackContainerList = new List<SelectListItem>();
            vm.InputPackContainerList.Add(new SelectListItem { Text = "装入包装容器", Value = "InputPackContainer" });
            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null&&storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
           
            NuclearTrackElement model = _NuclearTrackElementRepository.Get(id);
            if (!string.IsNullOrEmpty(model.ContainerId))
            {
                NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(model.ContainerId);
                if (nuclearBucket != null)
                {
                    model.ContainerId = nuclearBucket.BucketCode;
                }
                else
                {
                    model.ContainerId = "";
                }
            }
            if (!string.IsNullOrEmpty(model.InputContainerId))
            {
                NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(model.InputContainerId);
                if (nuclearBucket != null)
                {
                    model.InputContainerId = nuclearBucket.BucketCode;
                }
                else
                {
                    model.InputContainerId = "";
                }
            }
            vm.NuclearTrackElement = model;
            vm.NewStoragePositionId = model.FactoryPositionId;
            vm.Status = model.Status;
            vm.TrackCode = model.ElementCode;
            ///如果数字类型不为空，截取小数点后三位
            if (vm.NuclearTrackElement.SurfaceTouch != null)
            {
                if (vm.NuclearTrackElement.SurfaceTouch.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackElement.SurfaceTouch = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackElement.SurfaceTouch));
            }
            if (vm.NuclearTrackElement.LeadSurface != null)
            {
                if (vm.NuclearTrackElement.LeadSurface.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackElement.LeadSurface = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackElement.LeadSurface));
            }
            if (vm.NuclearTrackElement.ContainerTouchdose != null)
            {
                if (vm.NuclearTrackElement.ContainerTouchdose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackElement.ContainerTouchdose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackElement.ContainerTouchdose));
            }
            if (vm.NuclearTrackElement.InputContainerTouchdose != null)
            {
                if (vm.NuclearTrackElement.InputContainerTouchdose.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackElement.InputContainerTouchdose = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackElement.InputContainerTouchdose));
            }
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View("Edit", vm);
        }

        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNuclearTrackElementList(NuclearTrackElementCondition nuclearTrackElementCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearTrackElementView> data = this._NuclearTrackElementRepository.QueryList(nuclearTrackElementCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            string locationId = Request["locationId"];
            if (!string.IsNullOrEmpty(locationId))
                data = data.Where(n => n.FactoryPositionId == locationId);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearTrackElementView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ElementId,
                    List = new List<object>() {
                    d.ElementId,
                    d.ElementCode,
                    d.SystemCode,
                    d.WorkTicket,
                    d.Cycle,
                    d.SurfaceTouch,                                     
                    d.ElementVersionNew,
                    d.ElementVersionOld,
                    d.ContainerId,
                    d.InputContainerId,
                    d.ControlName,
                    d.MeasureDate.HasValue? d.MeasureDate.Value.ToString("yyyy-MM-dd"):string.Empty,
                    d.Status,
                    d.DealStatus
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        [HttpPost]
        public JsonResult StationChange(string stationId)
        {
            string simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationId);
            string demo = simpleCode + "FI" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackElementRepository.GetAll().Where(d => d.ElementCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.ElementCode).First().ElementCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            return Json("{\"result\":\"" + demo + "\"}", JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetBucketCode(string bucketCode, string bucketCodes)
        {
                Nullable<double> bucketCodeNum = 0;
                Nullable<double> bucketCodesNums = 0;
                List<NuclearBucket> NuclearBucket = new List<NuclearBucket>();
                List<NuclearBucket> NuclearBuckets = new List<NuclearBucket>();
                IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCode).AsQueryable();
                if (nuclearBucket != null && nuclearBucket.Count() > 0)
                {
                    NuclearBucket = nuclearBucket.ToList();
                }
                IQueryable<NuclearBucket> nuclearBuckets = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == bucketCodes).AsQueryable();
                if (nuclearBuckets != null && nuclearBuckets.Count() > 0)
                {
                    NuclearBuckets = nuclearBuckets.ToList();
                }
                string bucketId = null;
                if (NuclearBucket.Count() > 0)
                {
                    bucketId = NuclearBucket[0].BucketId;
                    List<NuclearTrackElement> nuclearTrackElement = _NuclearTrackElementRepository.GetAll().Where(d => d.ContainerId == bucketId).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                    bucketCodeNum = nuclearTrackElement.Count();
                }
                string bucketIds = null;
                if (NuclearBuckets.Count() > 0)
                {
                    bucketIds = NuclearBuckets[0].BucketId;
                    List<NuclearTrackElement> nuclearTrackElements = _NuclearTrackElementRepository.GetAll().Where(d => d.InputContainerId == bucketIds).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                    bucketCodesNums = nuclearTrackElements.Count();
                }
                return Json("{\"bucketCodeNum\":\"" + bucketCodeNum + "\",\"bucketCodesNums\":\"" + bucketCodesNums + "\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 新增废滤芯
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(WasteTrackingVM model, FormCollection formCollection)
        {
            try
            {
                if (this._NuclearTrackElementRepository.IsRepeat(model.NuclearTrackElement.ElementCode, AppContext.CurrentUser.ProjectCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
                }
                //判断存储位置
                bool bucketCode = false;
                if (model.NuclearTrackElement.ContainerId != null && model.NuclearTrackElement.ContainerId != "")
                {
                    //判断桶号是否存在 
                    string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.ContainerId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    int num = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (num > 0)
                    {
                        bucketCode = true;
                    };
                    model.NuclearTrackElement.ContainerId = bucketId;         
                }
                bool bucketCodes = false;
                if (model.NuclearTrackElement.InputContainerId != null && model.NuclearTrackElement.InputContainerId != "")
                {
                   //判断桶号是否存在 
                    string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.InputContainerId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    int num = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (num > 0) {
                        bucketCodes = true;
                    }
                    model.NuclearTrackElement.InputContainerId = bucketId;
                   
                }
                    model.NuclearTrackElement.ElementId = Guid.NewGuid().ToString();
                    model.NuclearTrackElement.Status = "0";
                    model.NuclearTrackElement.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackElement.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackElement.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackElement.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackElementRepository.Create(model.NuclearTrackElement);
                    this._NuclearTrackElementRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"bucketCodes\":\"" + bucketCodes + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet); 
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除废滤芯
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    NuclearTrackElement nuclearTrackElement = this._NuclearTrackElementRepository.Get(id);
                    if (nuclearTrackElement.Status == "2")
                    {
                        if (nuclearTrackElement.DealStatus == "1")
                        {
                            return Json("{\"result\":false,\"msg\":\"删除失败，该条源项废物已被处理。\"}", JsonRequestBehavior.AllowGet);
                        }
                        _NuclearTempstockRepository.MergeWasteTmpStock("ELEMENT", nuclearTrackElement.FactoryPositionId, AppContext.CurrentUser.ProjectCode, -1);
                    }
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._NuclearTrackElementRepository.DeleteById(idVal);
                    }
                    this._NuclearTrackElementRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 提交处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SubmitDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearTrackElement nuclearTrackElement = this._NuclearTrackElementRepository.Get(idVal);
                        nuclearTrackElement.DealStatus = "0";
                        this._NuclearTrackElementRepository.Update(nuclearTrackElement);
                    }
                    this._NuclearTrackElementRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ConfirmDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearTrackElement nuclearTrackElement = this._NuclearTrackElementRepository.Get(idVal);
                        nuclearTrackElement.DealStatus = "1";
                        this._NuclearTrackElementRepository.Update(nuclearTrackElement);
                    }
                    this._NuclearTrackElementRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确认处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 编辑废滤芯
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(WasteTrackingVM model, FormCollection formCollection)
        {
            string newElementCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackElement.ElementCode != newElementCode && this._NuclearTrackElementRepository.IsRepeat(model.NuclearTrackElement.ElementCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                bool bucketCode = false;
                if (model.NuclearTrackElement.ContainerId != null && model.NuclearTrackElement.ContainerId != "")
                {
                    //判断桶号是否存在 
                    string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.ContainerId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                   int num = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                   if (num > 1) {
                       bucketCode = true;
                   };
                    model.NuclearTrackElement.ContainerId = bucketId;
                }
                bool bucketCodes = false;
                 if (model.NuclearTrackElement.InputContainerId != null && model.NuclearTrackElement.InputContainerId != "")
                {
                    //判断桶号是否存在 
                    string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.InputContainerId, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                    }
                    int num = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (num > 1)
                    {
                        bucketCodes = true;
                    }
                    model.NuclearTrackElement.InputContainerId = bucketId;
                }

                    model.NuclearTrackElement.Status = "0";
                    model.NuclearTrackElement.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackElementRepository.Update(model.NuclearTrackElement);
                    this._NuclearTrackElementRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"bucketCodes\":\"" + bucketCodes + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet); 
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交废滤芯
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(WasteTrackingVM model, FormCollection formCollection)
        {
            string newElementCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackElement.ElementCode != newElementCode && this._NuclearTrackElementRepository.IsRepeat(model.NuclearTrackElement.ElementCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //修改提交
                if (model.NuclearTrackElement.ElementId != null)
                {
                    bool bucketCode = false;
                    if (model.NuclearTrackElement.ContainerId != null && model.NuclearTrackElement.ContainerId != "")
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.ContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 1)
                        {
                            bucketCode = true;
                        };
                        model.NuclearTrackElement.ContainerId = bucketId;
                    }
                    bool bucketCodes = false;
                    if (model.NuclearTrackElement.InputContainerId != null && model.NuclearTrackElement.InputContainerId != "")
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.InputContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 1)
                        {
                            bucketCodes = true;
                        }
                        model.NuclearTrackElement.InputContainerId = bucketId;
                    }
                        model.NuclearTrackElement.Status = "1";
                        model.NuclearTrackElement.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearTrackElementRepository.Update(model.NuclearTrackElement);
                        //EquipInfo equipInfo = _EquipInfoRepository.GetAll().Where(d => d.FunctionPosition == model.NuclearTrackElement.SystemCode).FirstOrDefault();
                        //NuclearTrackElement nuclearTrackElement = _NuclearTrackElementRepository.GetAll().Where(d => d.MeasureDate == equipInfo.UpdateDate).FirstOrDefault();
                        //if (nuclearTrackElement != null)
                        //{
                        //    equipInfo.ProductDate = nuclearTrackElement.ElementProductionDate;
                        //}
                        //_EquipInfoRepository.Update(equipInfo);
                        this._NuclearTrackElementRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"bucketCodes\":\"" + bucketCodes + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet); 
                }
                //新增提交
                else if (model.NuclearTrackElement.ElementId == null)
                {
                    bool bucketCode = false;
                    if (model.NuclearTrackElement.ContainerId != null && model.NuclearTrackElement.ContainerId != "")
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.ContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 0)
                        {
                            bucketCode = true;
                        };
                        model.NuclearTrackElement.ContainerId = bucketId;
                    }
                    bool bucketCodes = false;
                    if (model.NuclearTrackElement.InputContainerId != null && model.NuclearTrackElement.InputContainerId != "")
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.InputContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 0)
                        {
                            bucketCodes = true;
                        }
                        model.NuclearTrackElement.InputContainerId = bucketId;
                    }
                        model.NuclearTrackElement.ElementId = Guid.NewGuid().ToString();
                        model.NuclearTrackElement.Status = "1";
                        model.NuclearTrackElement.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                        model.NuclearTrackElement.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                        model.NuclearTrackElement.CreateDate = DateTime.Now.Date;//创建时间
                        model.NuclearTrackElement.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearTrackElementRepository.Create(model.NuclearTrackElement);

                        //EquipInfo equipInfo = _EquipInfoRepository.GetAll().Where(d => d.FunctionPosition == model.NuclearTrackElement.SystemCode).FirstOrDefault();
                        //NuclearTrackElement nuclearTrackElement = _NuclearTrackElementRepository.GetAll().Where(d => d.MeasureDate == equipInfo.UpdateDate).FirstOrDefault();
                        //if (nuclearTrackElement != null)
                        //{
                        //    equipInfo.ProductDate = nuclearTrackElement.ElementProductionDate;
                        //}
                        //_EquipInfoRepository.Update(equipInfo);
                        this._NuclearTrackElementRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"bucketCodes\":\"" + bucketCodes + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet); 
                }
                else 
                {
                    return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认废滤芯
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废滤芯列表确认")]
        public JsonResult Confirm(WasteTrackingVM model, FormCollection formCollection)
        {
            string newElementCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackElement.ElementCode != newElementCode && this._NuclearTrackElementRepository.IsRepeat(model.NuclearTrackElement.ElementCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                //修改确认
                if (model.NuclearTrackElement.ElementId != null)
                {
                    IQueryable<EquipInfo> FunctionQuery = _NuclearTrackElementRepository.QueryListByFunction(model.NuclearTrackElement.SystemCode, AppContext.CurrentUser.ProjectCode);
                    List<EquipInfo> FunctionQueryList = FunctionQuery.ToList();
                    if (FunctionQuery.Count() != 0)
                    {
                        foreach (var itemList in FunctionQueryList)
                        {
                            EquipInfo equipInfo = this._EquipInfoRepository.Get(itemList.EquipId);
                            
                            equipInfo.EquipSpec = model.NuclearTrackElement.ElementVersionNew;//
                            if (equipInfo.UpdateDate <= model.NuclearTrackElement.MeasureDate||equipInfo.UpdateDate == null)
                            {
                                equipInfo.UpdateDate = model.NuclearTrackElement.MeasureDate;
                                equipInfo.ProductDate = model.NuclearTrackElement.ElementProductionDate;
                            }
                            this._EquipInfoRepository.Update(equipInfo);//提交数据库  
                        }
                    }
                    //else
                    //{
                    //    return Json("{\"result\":false,\"msg\":\"您填写的系统号编错误!\"}", JsonRequestBehavior.AllowGet);
                    //}
                    bool bucketCode = false;
                    if (model.NuclearTrackElement.ContainerId != null && model.NuclearTrackElement.ContainerId != "")
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.ContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 1)
                        {
                            bucketCode = true;
                        };
                       // _NuclearBucketRepository.UpdateBucketWasteType(model.NuclearTrackElement.ContainerId, AppContext.CurrentUser.ProjectCode, "废滤芯","");
                        model.NuclearTrackElement.ContainerId = bucketId;
                    }
                    bool bucketCodes = false;
                    if (model.NuclearTrackElement.InputContainerId != null && model.NuclearTrackElement.InputContainerId != "")
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.InputContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 1)
                        {
                            bucketCodes = true;
                        }
                        //_NuclearBucketRepository.UpdateBucketWasteType(model.NuclearTrackElement.InputContainerId, AppContext.CurrentUser.ProjectCode, "废滤芯","");
                        model.NuclearTrackElement.InputContainerId = bucketId;  
                    }
                    if (model.NuclearTrackElement.ContainerId == null && model.NuclearTrackElement.InputContainerId == null)
                    { 
                        if (model.Status != "2")
                        {
                            _NuclearTempstockRepository.MergeWasteTmpStock("ELEMENT", model.NuclearTrackElement.FactoryPositionId, AppContext.CurrentUser.ProjectCode, 1);
                        }
                        else {
                            if (model.NuclearTrackElement.FactoryPositionId != model.NewStoragePositionId)
                            {
                                _NuclearTempstockRepository.MergeWasteTmpStock("ELEMENT", model.NewStoragePositionId, AppContext.CurrentUser.ProjectCode, -1);
                                _NuclearTempstockRepository.MergeWasteTmpStock("ELEMENT", model.NuclearTrackElement.FactoryPositionId, AppContext.CurrentUser.ProjectCode, 1);
                            }
                        }
                    }
                        model.NuclearTrackElement.Status = "2";
                        model.NuclearTrackElement.Stationcode = AppContext.CurrentUser.ProjectCode;
                        model.NuclearTrackElement.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        model.NuclearTrackElement.ConfirmUserName = AppContext.CurrentUser.UserName;
                        model.NuclearTrackElement.ConfirmDate = DateTime.Now;
                        //model.NuclearTrackElement.DealStatus = "0";
                        this._NuclearTrackElementRepository.Update(model.NuclearTrackElement);
                        //EquipInfo equipInfo = _EquipInfoRepository.GetAll().Where(d => d.FunctionPosition == model.NuclearTrackElement.SystemCode).FirstOrDefault();
                        //equipInfo.ProductDate = model.NuclearTrackElement.ElementProductionDate;
                        //_EquipInfoRepository.Update(equipInfo);
                       
                        this._NuclearTrackElementRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"bucketCodes\":\"" + bucketCodes + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet); 
                    
                }
                //新增确认
                else if (model.NuclearTrackElement.ElementId == null)
                {
                    IQueryable<EquipInfo> FunctionQuery = _NuclearTrackElementRepository.QueryListByFunction(model.NuclearTrackElement.SystemCode, AppContext.CurrentUser.ProjectCode);
                    List<EquipInfo> FunctionQueryList = FunctionQuery.ToList();
                    if (FunctionQuery.Count() != 0)
                    {
                        foreach (var itemList in FunctionQueryList)
                        {
                            EquipInfo equipInfo = this._EquipInfoRepository.Get(itemList.EquipId);
                            equipInfo.EquipSpec = model.NuclearTrackElement.ElementVersionNew;//
                            if (equipInfo.UpdateDate <= model.NuclearTrackElement.MeasureDate || equipInfo.UpdateDate == null)
                            {
                                equipInfo.UpdateDate = model.NuclearTrackElement.MeasureDate;
                                equipInfo.ProductDate = model.NuclearTrackElement.ElementProductionDate;
                            }

                            this._EquipInfoRepository.Update(equipInfo);//提交数据库  
                        }
                    }
                    bool bucketCode = false;
                    bool bucketCodes = false;
                    if (model.NuclearTrackElement.ContainerId != null && model.NuclearTrackElement.ContainerId != "")
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.ContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.ContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackElementRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 0)
                        {
                            bucketCode = true;
                        };
                       // _NuclearBucketRepository.UpdateBucketWasteType(model.NuclearTrackElement.ContainerId, AppContext.CurrentUser.ProjectCode, "废滤芯","");
                        model.NuclearTrackElement.ContainerId = bucketId;
                    }
                    if (model.NuclearTrackElement.InputContainerId != null && model.NuclearTrackElement.InputContainerId != "")
                    {
                        //判断桶号是否存在 
                        string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NuclearTrackElement.InputContainerId, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketId))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "不正确!\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechSRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物2中208L金属桶使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        if (this._NuclearTrackTechBRepository.IsRepeatBucketCodes(bucketId, AppContext.CurrentUser.ProjectCode))
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的包装容器号" + model.NuclearTrackElement.InputContainerId + "已被技术废物1中暂存包装容器使用。\"}", JsonRequestBehavior.AllowGet);
                        }
                        int num = this._NuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                        if (num > 0)
                        {
                            bucketCodes = true;
                        }
                       // _NuclearBucketRepository.UpdateBucketWasteType(model.NuclearTrackElement.InputContainerId, AppContext.CurrentUser.ProjectCode, "废滤芯","");
                        model.NuclearTrackElement.InputContainerId = bucketId;
                    }
                    if (model.NuclearTrackElement.ContainerId == null && model.NuclearTrackElement.InputContainerId == null)
                    {      
                        _NuclearTempstockRepository.MergeWasteTmpStock("ELEMENT", model.NuclearTrackElement.FactoryPositionId, AppContext.CurrentUser.ProjectCode, 1);    
                    }
                    model.NuclearTrackElement.ElementId = Guid.NewGuid().ToString();
                    model.NuclearTrackElement.Status = "2";
                    model.NuclearTrackElement.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackElement.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackElement.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackElement.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.NuclearTrackElement.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.NuclearTrackElement.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.NuclearTrackElement.ConfirmDate = DateTime.Now;
                    //model.NuclearTrackElement.DealStatus = "0";
                    this._NuclearTrackElementRepository.Create(model.NuclearTrackElement);
                    //EquipInfo equipInfo = _EquipInfoRepository.GetAll().Where(d => d.FunctionPosition == model.NuclearTrackElement.SystemCode).FirstOrDefault();
                    //equipInfo.ProductDate = model.NuclearTrackElement.ElementProductionDate;
                    //_EquipInfoRepository.Update(equipInfo);
                    this._NuclearTrackElementRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"bucketCode\":\"" + bucketCode + "\",\"bucketCodes\":\"" + bucketCodes + "\",\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet); 
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
                }
               
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        //得到废滤芯型号信息
        [HttpPost]
        public JsonResult GetResinData(string systemCode)
        {
            string resinVersionNew = "";
            var functionPosition = this._EquipInfoRepository.GetAll().Where(d => d.FunctionPosition == systemCode && d.Status == "2");
            if (functionPosition.Count() > 0)
            {
                var query = this._EquipInfoRepository.GetAll().Where(d => d.FunctionPosition == systemCode && d.Status == "2");
                if (query.Count() > 0)
                {
                    resinVersionNew = query.First().EquipSpec;
                }
                else
                {
                    resinVersionNew = "";
                }
            }
            else
            {
                resinVersionNew = "";
            }
            return Json("{\"resinVersionNew\":\"" + resinVersionNew + "\"}", JsonRequestBehavior.AllowGet);
        }
        //获得设备编号
        public JsonResult GetEquipDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<EquipInfo> list = new List<EquipInfo>();
            if (keyword.ToUpper().Trim() != null && keyword.ToUpper().Trim() != "")
            {
                IQueryable<EquipInfo> iqueryEquipInfo = _EquipInfoRepository.GetAll().AsQueryable().Where(e => e.FunctionPosition.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.Status == "2");
                if (iqueryEquipInfo.Count() > 0)
                {
                    list = iqueryEquipInfo.ToList();
                }
            }
            //List<BasicObject> functionQuery = _BasicObjectRepository.GetAll().Where(d => d.Name == "固体废物处理设备").AsQueryable().ToList();
            //if (!string.IsNullOrEmpty(functionQuery[0].Uuid))
            //    list = list.Where(n => n.EquipTypeId == functionQuery[0].Uuid).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].FunctionPosition;
                autoComplete.Code = list[i].EquipId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        //获得所有桶号
        public JsonResult GetDataList(string keyword)//string storagePositionId
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            if (keyword.ToUpper().Trim() != null && keyword.ToUpper().Trim() != "")
            {
                IQueryable<NuclearBucket> iqueryNuclearBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsOutSend == "0" || e.IsOutSend == null));

                if (iqueryNuclearBucket.Count() > 0)
                {
                    list = iqueryNuclearBucket.ToList();
                }
            } 
            //string factoryId = Request["factory"];
            //if (!string.IsNullOrEmpty(factoryId))
            //    list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 导入历史数据页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Import()
        {
            return View();
        }

        #region 导入历史数据
        /// <summary>
        /// 导入废滤芯数据
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult Import(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的历史数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    //string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    //if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    //{
                    //    //删除文件
                    //    if (System.IO.File.Exists(strNewImportPath))
                    //    {
                    //        System.IO.File.Delete(strNewImportPath);
                    //    }
                    //    jsonResult = JsonResultHelper.JsonResult(false, "历史数据必须是EXCEL格式!");
                    //    jsonResult.ContentType = "text/html";
                    //    return jsonResult;
                    //}
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);
                        if (ds.Tables.Count < 1)
                        {
                            //删除文件
                            if (System.IO.File.Exists(strNewImportPath))
                            {
                                System.IO.File.Delete(strNewImportPath);
                            }
                            jsonResult = JsonResultHelper.JsonResult(false, "历史数据格式错误!");
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //判断EXCEL格式是否正确
                        string checkColumns = ImportDataBuilder.GetImportTrackElementErr(ds, strNewImportPath);
                        if (!string.IsNullOrEmpty(checkColumns))
                        {
                            jsonResult = JsonResultHelper.JsonResult(false, checkColumns);
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //导入数据
                        if (ds != null && ds.Tables.Count == 1)
                        {
                            ImportDataBuilder.ImportTrackElement(ds, strNewImportPath, AppContext.CurrentUser);
                        }
                    }
                }
                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }
        #endregion
    }
}
