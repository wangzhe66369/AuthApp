﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   NuclearTrackResinController.cs
 *   描    述   ：   废树脂Controller
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using RWIS.Presentation.Web.Core.Common;
using System.Data;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;

namespace RWIS.Presentation.Web.Areas.WasteTracking.Controllers
{
    public class NuclearTrackResinController : Controller
    {
        INuclearTrackResinRepository _NuclearTrackResinRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IEquipInfoRepository _EquipInfoRepository;
        IEquipDetailRepository _EquipDetailRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        public NuclearTrackResinController(
            INuclearTrackResinRepository _NuclearTrackResinRepository, 
            IBasicObjectRepository _BasicObjectRepository, 
            IEquipInfoRepository _EquipInfoRepository,
            IEquipDetailRepository _EquipDetailRepository,
            IBasicWasteUnitRepository _BasicWasteUnitRepository,
            INuclearTempstockRepository _NuclearTempstockRepository
            )
        {
            this._NuclearTrackResinRepository = _NuclearTrackResinRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._EquipInfoRepository = _EquipInfoRepository;
            this._EquipDetailRepository = _EquipDetailRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
            this._NuclearTempstockRepository = _NuclearTempstockRepository;
        }
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废树脂列表")]
        public ActionResult Index()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Resin");
            //加载工作类型
            vm.WorkTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> workTypeQuery = _BasicObjectRepository.GetSubobjectsByCode("WorkType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> workTypeList = new List<BasicObject>();
            if (workTypeQuery!=null&&workTypeQuery.Count() > 0)
            {
                workTypeList = workTypeQuery.ToList();
                vm.WorkTypeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in workTypeList)
                {
                    vm.WorkTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            
            string locationId = Request["locationId"];
            ViewBag.Location = locationId;
            //加载状态
            vm.StatusList = new List<SelectListItem>();
            vm.StatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            vm.StatusList.Add(new SelectListItem { Text = "草稿", Value = "0" });
            vm.StatusList.Add(new SelectListItem { Text = "未确认", Value = "1" });
            vm.StatusList.Add(new SelectListItem { Text = "已确认", Value = "2" });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                vm.StationCodeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            

            //加载暂存位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null && storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
       
            return View(vm);
        }

        public ActionResult Add()
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Resin");
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0", Selected = true });
            vm.RodiodList.Add(new SelectListItem { Text = "大修", Value = "1" });
            //倒空
            vm.IsEmpty = new List<SelectListItem>();
            vm.IsEmpty.Add(new SelectListItem { Text = "否", Value = "0", Selected = true });
            vm.IsEmpty.Add(new SelectListItem { Text = "是", Value = "1" });
            
            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载暂存位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null && storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                vm.StoragePositionIdList.Add(new SelectListItem { Text = "请选择", Value = null });
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
        
            NuclearTrackResin nuclearTrackResin = new NuclearTrackResin();
            string simpleCode = "";
            if (stationList.Count > 0)
            {
                simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationList[0].UnitId);
            }
            string demo = simpleCode + "DE" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackResinRepository.GetAll().Where(d => d.ResinCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.ResinCode).First().ResinCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            nuclearTrackResin.ResinCode = demo;
            vm.NuclearTrackResin = nuclearTrackResin;
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);

        }
        public ActionResult DetailView(string id)
        {
            ViewBag.ViewStatus = Request["status"];
            NuclearTrackResin model = _NuclearTrackResinRepository.Get(id);
            WasteTrackingVM vm = new WasteTrackingVM();
            BasicWasteUnit basicObjectStationcode = _BasicWasteUnitRepository.Get(model.StationId);
            BasicObject basicObjectStoragePositionId = _BasicObjectRepository.Get(model.StoragePositionId);
            BasicObject basicObjectSaveStorage = _BasicObjectRepository.Get(model.SavePosition);
            if (basicObjectStationcode != null)
            {
                vm.StationCodeName = basicObjectStationcode.UnitName;
            }
            else {
                vm.StationCodeName = "";
            }
            if (basicObjectStoragePositionId != null)
            {
                vm.StoragePositionName = basicObjectStoragePositionId.Name;
            }
            else {
                vm.StoragePositionName = "";
            }
            if (basicObjectSaveStorage != null)
            {
                vm.StoragePosition = basicObjectSaveStorage.Name;
            }
            else {
                vm.StoragePosition = "";
            }
            vm.NuclearTrackResin = model;
            if (vm.NuclearTrackResin.RadioactionValue != null)
            {
                if (vm.NuclearTrackResin.RadioactionValue.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackResin.RadioactionValue = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackResin.RadioactionValue));
            }
            return View("DetailView", vm);
        }
        public ActionResult Edit(string id)
        {
            WasteTrackingVM vm = new WasteTrackingVM();
            vm.OperationList = CommonHelper.GetOperationList("Nuclear_Track_Resin");
            NuclearTrackResin model = _NuclearTrackResinRepository.Get(id);
            vm.NuclearTrackResin = model;
            vm.NewStoragePositionId = model.StoragePositionId;
            vm.Status = model.Status;
            vm.TrackCode = model.ResinCode;
            vm.NewIsEmpty = model.IsEmpty;
            vm.NewSavePosition = model.SavePosition;
            vm.OldBulk = Convert.ToDecimal(model.ResinBulkOld);
            //加载机组状态
            vm.RodiodList = new List<SelectListItem>();
            vm.RodiodList.Add(new SelectListItem { Text = "日常", Value = "0" });
            vm.RodiodList.Add(new SelectListItem {  Text = "大修", Value = "1"});

            //加载放射性
            vm.FilterFlagYesList = new List<SelectListItem>();
            vm.FilterFlagYesList.Add(new SelectListItem { Text = "放射性(IC处接触剂量率):", Value = "1" });
            //加载非放射性
            vm.FilterFlagNoList = new List<SelectListItem>();
            vm.FilterFlagNoList.Add(new SelectListItem { Text = "非放射性", Value = "0" });

            //倒空
            vm.IsEmpty = new List<SelectListItem>();
            vm.IsEmpty.Add(new SelectListItem { Text = "否", Value = "0" });
            vm.IsEmpty.Add(new SelectListItem { Text = "是", Value = "1" });
           
            //加载更换原因
            vm.ChangeFlagList = new List<SelectListItem>();
            vm.ChangeFlagList.Add(new SelectListItem { Text = "树脂饱和", Value = "2" });
            vm.ChangeFlagList.Add(new SelectListItem { Text = "压差高", Value = "1" });
            vm.ChangeFlagList.Add(new SelectListItem { Text = "其他原因", Value = "0" });

            //加载传送
            vm.TransList = new List<SelectListItem>();
            vm.TransList.Add(new SelectListItem { Text = "TES 002 BA", Value = "TES 002 BA" });
            vm.TransList.Add(new SelectListItem { Text = "TES 003 BA", Value = "TES 003 BA" });
            vm.TransList.Add(new SelectListItem { Text = "TES 004 BA", Value = "TES 004 BA" });

            //加载电站
            vm.StationCodeList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList!=null&&QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                foreach (var item in stationList)
                {
                    vm.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
                }
            }
            
            //加载暂存位置
            vm.StoragePositionIdList = new List<SelectListItem>();
            IQueryable<BasicObject> storagePositionIdQuery = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> storagePositionIdList = new List<BasicObject>();
            if (storagePositionIdQuery!=null&&storagePositionIdQuery.Count() > 0)
            {
                storagePositionIdList = storagePositionIdQuery.ToList();
                vm.StoragePositionIdList.Add(new SelectListItem { Text = "请选择", Value = null });
                foreach (var item in storagePositionIdList)
                {
                    vm.StoragePositionIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }

            if (vm.NuclearTrackResin.RadioactionValue != null)
            {
                if (vm.NuclearTrackResin.RadioactionValue.Value.ToString().IndexOf('.') > 0)
                    vm.NuclearTrackResin.RadioactionValue = Convert.ToDecimal(String.Format("{0:00.000}", vm.NuclearTrackResin.RadioactionValue));
            }
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View("Edit", vm);
        }
        
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNuclearTrackResinList(NuclearTrackResinCondition nuclearTrackResinCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NuclearTrackResinView> data = this._NuclearTrackResinRepository.QueryList(nuclearTrackResinCondition).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode);
            string locationId = Request["locationId"];
            if (!string.IsNullOrEmpty(locationId))
                data = data.Where(n => n.StoragePositionId == locationId);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NuclearTrackResinView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.ResinId,
                    List = new List<object>() {
                    d.ResinId,
                    d.ResinCode,
                    d.SystemCode,
                    d.WorkTicket,
                    d.ResinVersionNew,
                    d.ResinBulkNew,
                    d.ResinVersionOld,                                     
                    d.ResinBulkOld,
                    d.ResinChangeDate.HasValue? d.ResinChangeDate.Value.ToString("yyyy-MM-dd"):string.Empty,       
                    d.RadioactionValue,
                    d.Trans,
                    d.Cycle,
                    d.ControlName,
                    d.Status,
                    d.DealStatus
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        [HttpPost]
        public JsonResult StationChange(string stationId)
        {
            string simpleCode = this._BasicWasteUnitRepository.GetSimpleCodeById(stationId);
            string demo = simpleCode + "DE" + DateTime.Now.ToString("yyyy");
            int num = 0;
            string stationCode = AppContext.CurrentUser.ProjectCode;
            var query = this._NuclearTrackResinRepository.GetAll().Where(d => d.ResinCode.Contains(demo) && d.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim());
            if (query.Count() > 0)
            {
                string maxCode = query.OrderByDescending(d => d.ResinCode).First().ResinCode;
                num = Convert.ToInt32(maxCode.Substring(maxCode.Length - 4)) + 1;
                demo += num.ToString("0000");
            }
            else
            {
                demo += (num + 1).ToString("0000");
            }
            return Json("{\"result\":\"" + demo + "\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 新增废树脂信息
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Add(WasteTrackingVM model, FormCollection formCollection)
        {
            //if (!ModelState.IsValid)
            //{
            //    return Json("{\"result\":false,\"msg\":\"未验证通过。\"}", JsonRequestBehavior.AllowGet);
            //}
            try
            {
                if (this._NuclearTrackResinRepository.IsRepeat(model.NuclearTrackResin.ResinCode, AppContext.CurrentUser.ProjectCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
                }
                IQueryable<EquipInfo> FunctionPositionQuery = _NuclearTrackResinRepository.QueryListByFunctionPosition(model.NuclearTrackResin.Trans, AppContext.CurrentUser.ProjectCode);
                List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                if (FunctionPositionQuery.Count() != 0)
                {
                    foreach (var itemList in FunctionPositionQueryList)
                    {
                        model.NuclearTrackResin.EquipId = itemList.EquipId;
                    }
                    model.NuclearTrackResin.ResinId = Guid.NewGuid().ToString();
                    model.NuclearTrackResin.Status = "0";
                    model.NuclearTrackResin.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NuclearTrackResin.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NuclearTrackResin.CreateDate = DateTime.Now.Date;//创建时间
                    model.NuclearTrackResin.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackResinRepository.Create(model.NuclearTrackResin);
                    this._NuclearTrackResinRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else {
                    return Json("{\"result\":false,\"msg\":\"您填写的传送编码错误!\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除废树脂信息
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    NuclearTrackResin nuclearTrackResin = this._NuclearTrackResinRepository.Get(id);
                    if (nuclearTrackResin.Status == "2")
                    {
                        if (nuclearTrackResin.DealStatus == "1")
                        {
                            return Json("{\"result\":false,\"msg\":\"删除失败，该条源项废物已被处理。\"}", JsonRequestBehavior.AllowGet);
                        }
                        EquipInfo equipInfo = this._EquipInfoRepository.Get(nuclearTrackResin.EquipId);
                        EquipDetail equipDetail = this._EquipDetailRepository.Get(nuclearTrackResin.EquipDetailId);
                        //equipInfo.Bulk = equipInfo.Bulk + equipDetail.DetailNum;//记录体积容量
                        this._EquipDetailRepository.DeleteById(equipDetail.DetailId);
                        this._EquipInfoRepository.Update(equipInfo);//提交数据库  
                        if (nuclearTrackResin.IsEmpty == "0")
                        {
                            _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", nuclearTrackResin.StoragePositionId, AppContext.CurrentUser.ProjectCode, -1);
                        }
                        else
                        {
                            _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", nuclearTrackResin.SavePosition, AppContext.CurrentUser.ProjectCode, -1);
                        }
                    }
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._NuclearTrackResinRepository.DeleteById(idVal);
                        NuclearTrackResin nuclearTrackResinList = this._NuclearTrackResinRepository.Get(id);
                        IQueryable<EquipInfo> FunctionQuery = _NuclearTrackResinRepository.QueryListByFunction(nuclearTrackResinList.SystemCode, AppContext.CurrentUser.ProjectCode);
                        if (FunctionQuery.Count() > 0)
                        {
                            foreach (var item in FunctionQuery)
                            {
                                item.Bulk = item.Bulk - Convert.ToDecimal(nuclearTrackResinList.ResinBulkNew + nuclearTrackResinList.ResinBulkOld);
                                this._EquipInfoRepository.Update(item);//提交数据库   
                            }

                        }
                    }
                    this._NuclearTrackResinRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 提交处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult SubmitDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearTrackResin nuclearTrackResin = this._NuclearTrackResinRepository.Get(idVal);
                        nuclearTrackResin.DealStatus = "0";
                        this._NuclearTrackResinRepository.Update(nuclearTrackResin);
                    }
                    this._NuclearTrackResinRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认处理状态
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ConfirmDealStatus(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        NuclearTrackResin nuclearTrackResin = this._NuclearTrackResinRepository.Get(idVal);
                        nuclearTrackResin.DealStatus = "1";
                        this._NuclearTrackResinRepository.Update(nuclearTrackResin);
                    }
                    this._NuclearTrackResinRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确认处理状态成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认处理状态失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 编辑废树脂信息
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(WasteTrackingVM model, FormCollection formCollection)
        {
            string newResinCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackResin.ResinCode != newResinCode && this._NuclearTrackResinRepository.IsRepeat(model.NuclearTrackResin.ResinCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                IQueryable<EquipInfo> FunctionPositionQuery = _NuclearTrackResinRepository.QueryListByFunctionPosition(model.NuclearTrackResin.Trans, AppContext.CurrentUser.ProjectCode);
                List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                if (FunctionPositionQuery.Count() != 0)
                {
                    foreach (var itemList in FunctionPositionQueryList)
                    {
                        model.NuclearTrackResin.EquipId = itemList.EquipId;
                    }
                    model.NuclearTrackResin.Status = "0";
                    model.NuclearTrackResin.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._NuclearTrackResinRepository.Update(model.NuclearTrackResin);
                    this._NuclearTrackResinRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"您填写的传送编码错误!\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交浓缩液信息
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Commit(WasteTrackingVM model, FormCollection formCollection)
        {
            string newResinCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackResin.ResinCode != newResinCode && this._NuclearTrackResinRepository.IsRepeat(model.NuclearTrackResin.ResinCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {
                if (model.NuclearTrackResin.ResinId != null)
                {
                    IQueryable<EquipInfo> FunctionPositionQuery = _NuclearTrackResinRepository.QueryListByFunctionPosition(model.NuclearTrackResin.Trans, AppContext.CurrentUser.ProjectCode);
                    List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                    if (FunctionPositionQuery.Count() != 0)
                    {
                        foreach (var itemList in FunctionPositionQueryList)
                        {
                            model.NuclearTrackResin.EquipId = itemList.EquipId;
                        }
                        model.NuclearTrackResin.Status = "1";
                        model.NuclearTrackResin.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearTrackResinRepository.Update(model.NuclearTrackResin);
                        this._NuclearTrackResinRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的传送编码错误!\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else if (model.NuclearTrackResin.ResinId == null)
                {
                    IQueryable<EquipInfo> FunctionPositionQuery = _NuclearTrackResinRepository.QueryListByFunctionPosition(model.NuclearTrackResin.Trans, AppContext.CurrentUser.ProjectCode);
                    List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                    if (FunctionPositionQuery.Count() != 0)
                    {
                        foreach (var itemList in FunctionPositionQueryList)
                        {
                            model.NuclearTrackResin.EquipId = itemList.EquipId;
                        }
                        model.NuclearTrackResin.ResinId = Guid.NewGuid().ToString();
                        model.NuclearTrackResin.Status = "1";
                        model.NuclearTrackResin.CreateUserNo = AppContext.CurrentUser.UserId;
                        model.NuclearTrackResin.CreateUserName = AppContext.CurrentUser.UserName;
                        model.NuclearTrackResin.CreateDate = DateTime.Now.Date;
                        model.NuclearTrackResin.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearTrackResinRepository.Create(model.NuclearTrackResin);
                        this._NuclearTrackResinRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的传送编码错误!\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json("{\"result\":true,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认废树脂信息
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废树脂列表确认")]
        public JsonResult Confirm(WasteTrackingVM model, FormCollection formCollection)
        {
            string newResinCode = model.TrackCode;
            //判断编号是否重复
            if (model.NuclearTrackResin.ResinCode != newResinCode && this._NuclearTrackResinRepository.IsRepeat(model.NuclearTrackResin.ResinCode, AppContext.CurrentUser.ProjectCode))
            {
                return Json("{\"result\":false,\"msg\":\"您填写的编号重复，请获取最新编号。\"}", JsonRequestBehavior.AllowGet);
            }
            try
            {

                if (model.NuclearTrackResin.ResinId != null)
                {
                    //处理系统号即功能位置对应的设备的信息
                    IQueryable<EquipInfo> FunctionQuery = _NuclearTrackResinRepository.QueryListByFunction(model.NuclearTrackResin.SystemCode, AppContext.CurrentUser.ProjectCode);
                    List<EquipInfo> FunctionQueryList = FunctionQuery.ToList();
                    if (FunctionQuery.Count() != 0)
                    {
                        foreach (var itemList in FunctionQueryList)
                        {
                            EquipInfo equipInfo = this._EquipInfoRepository.Get(itemList.EquipId);
                            equipInfo.EquipSpec = model.NuclearTrackResin.ResinVersionNew;
                            equipInfo.Bulk = Convert.ToDecimal(model.NuclearTrackResin.ResinBulkNew);//记录体积容量
                            if (equipInfo.UpdateDate <= model.NuclearTrackResin.ResinChangeDate)
                            {
                                equipInfo.UpdateDate = model.NuclearTrackResin.ResinChangeDate;//废树脂更换时间=更新设备时间
                            }
                            else if (equipInfo.UpdateDate == null)
                            {
                                equipInfo.UpdateDate = model.NuclearTrackResin.ResinChangeDate;//废树脂更换时间=更新设备时间
                            
                            }
                            
                            this._EquipInfoRepository.Update(equipInfo);//提交数据库  
                        }
                    }
                    else {
                        return Json("{\"result\":false,\"msg\":\"您填写的系统号编错误!\"}", JsonRequestBehavior.AllowGet);
                    }

                    //传送设备
                    IQueryable<EquipInfo> FunctionPositionQuery = _NuclearTrackResinRepository.QueryListByFunctionPosition(model.NuclearTrackResin.Trans, AppContext.CurrentUser.ProjectCode);
                    List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                    if (FunctionPositionQuery.Count() != 0)
                    {
                        foreach (var itemList in FunctionPositionQueryList)
                        {
                            model.EquipInfo.EquipId = itemList.EquipId;
                            model.NuclearTrackResin.EquipId = model.EquipInfo.EquipId;
                        }
                        if (model.Status != "2")
                        {
                            if (model.NuclearTrackResin.IsEmpty == "0")
                            {
                                _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NuclearTrackResin.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                            }
                            else {
                                _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NuclearTrackResin.SavePosition, AppContext.CurrentUser.ProjectCode, 1);
                            }
                        }
                        else {
                            if (model.NuclearTrackResin.IsEmpty == "0" && model.NewIsEmpty == "0")
                            {
                                if (model.NuclearTrackResin.StoragePositionId != model.NewStoragePositionId)
                                {
                                    _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NewStoragePositionId, AppContext.CurrentUser.ProjectCode, -1);
                                    _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NuclearTrackResin.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                                }
                            }
                            if (model.NuclearTrackResin.IsEmpty == "1" && model.NewIsEmpty == "1")
                            {
                                if (model.NuclearTrackResin.SavePosition != model.NewSavePosition)
                                {
                                    _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NewSavePosition, AppContext.CurrentUser.ProjectCode, -1);
                                    _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NuclearTrackResin.SavePosition, AppContext.CurrentUser.ProjectCode, 1);
                                }
                            }
                            if (model.NuclearTrackResin.IsEmpty == "1" && model.NewIsEmpty == "0")
                            {
                                _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NuclearTrackResin.StoragePositionId, AppContext.CurrentUser.ProjectCode, -1);
                                _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NuclearTrackResin.SavePosition, AppContext.CurrentUser.ProjectCode, 1);
                            }
                            if (model.NuclearTrackResin.IsEmpty == "0" && model.NewIsEmpty == "1")
                            {
                                _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NuclearTrackResin.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                                _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NuclearTrackResin.SavePosition, AppContext.CurrentUser.ProjectCode, -1);
                            }
                        }
                        model.NuclearTrackResin.Status = "2";
                        model.NuclearTrackResin.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        model.NuclearTrackResin.ConfirmUserName = AppContext.CurrentUser.UserName;
                        model.NuclearTrackResin.ConfirmDate = DateTime.Now.Date;
                        model.NuclearTrackResin.Stationcode = AppContext.CurrentUser.ProjectCode;
                        this._NuclearTrackResinRepository.Update(model.NuclearTrackResin);

                        //设备状态中自动加入一条数据
                        model.EquipDetail.EquipId = model.EquipInfo.EquipId;
                        model.EquipDetail.Status = "2";//状态
                        model.EquipDetail.DetailId = Guid.NewGuid().ToString();
                        model.NuclearTrackResin.EquipDetailId = model.EquipDetail.DetailId;
                        model.EquipDetail.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                        model.EquipDetail.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                        model.EquipDetail.CreateDate = DateTime.Now;//创建时间
                        model.EquipDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        IQueryable<BasicObject> TypeStatusQuery = _NuclearTrackResinRepository.QueryListByTypeStatus("S状态变化");
                        List<BasicObject> TypeStatusQueryList = TypeStatusQuery.ToList();
                        foreach (var itemList in TypeStatusQueryList)
                        {
                            model.EquipDetail.TypeStatus = itemList.Uuid;
                        }
                        model.NuclearTrackResin.ResinBulkOld = model.NuclearTrackResin.ResinBulkOld.HasValue ? model.NuclearTrackResin.ResinBulkOld : 0;
                        model.EquipDetail.DetailNum =Convert.ToDecimal(model.NuclearTrackResin.ResinBulkOld);//数值
                        model.EquipDetail.Usability = "1";//可用性
                        model.EquipDetail.EventDate = DateTime.Now;//事件日期
                        model.EquipDetail.EventDesc = DateTime.Now.ToString("yyyy-MM-dd") + "接收废树脂";
                        this._EquipDetailRepository.Create(model.EquipDetail);//提交数据库

                        EquipInfo equipInfo = this._EquipInfoRepository.Get(model.EquipInfo.EquipId);
                        if (model.NuclearTrackResin.IsEmpty == "0")
                        {
                            if (model.Status == "2")
                            {
                                if (equipInfo.Bulk == null)
                                {
                                    equipInfo.Bulk = model.EquipDetail.DetailNum;//记录体积容量 - model.OldBulk
                                }
                                else
                                {
                                    if (model.NewIsEmpty == "0")
                                    {
                                        equipInfo.Bulk = equipInfo.Bulk + (model.EquipDetail.DetailNum - model.OldBulk);//记录体积容量
                                    }
                                    else {
                                        equipInfo.Bulk = equipInfo.Bulk + model.EquipDetail.DetailNum;//记录体积容量
                                    }
                                }
                            }
                            else
                            {
                                if (equipInfo.Bulk == null)
                                {
                                    equipInfo.Bulk = model.EquipDetail.DetailNum;//记录体积容量
                                }else{
                                equipInfo.Bulk = equipInfo.Bulk + model.EquipDetail.DetailNum;//记录体积容量
                                }
                            }
                        }
                        else
                        {
                            if(model.NewIsEmpty == "0")
                            {
                                 equipInfo.Bulk = equipInfo.Bulk - model.EquipDetail.DetailNum;//记录体积容量
                            }else{
                                equipInfo.Bulk = equipInfo.Bulk - model.EquipDetail.DetailNum;//记录体积容量
                            }
                        }
                        equipInfo.EquipSpec = model.NuclearTrackResin.ResinVersionOld;
                        if (equipInfo.UpdateDate <= model.NuclearTrackResin.MeasureDate)
                        {
                            equipInfo.UpdateDate = model.NuclearTrackResin.MeasureDate;//RP测量日期=更新设备时间
                        }
                        else if (equipInfo.UpdateDate == null)
                        {
                            equipInfo.UpdateDate = model.NuclearTrackResin.ResinChangeDate;//废树脂更换时间=更新设备时间

                        }
                        this._EquipInfoRepository.Update(equipInfo);//提交数据库  
                        this._NuclearTrackResinRepository.UnitOfWork.Commit();

                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的传送编码错误!\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else if (model.NuclearTrackResin.ResinId == null)
                {
                    IQueryable<EquipInfo> FunctionQuery = _NuclearTrackResinRepository.QueryListByFunction(model.NuclearTrackResin.SystemCode, AppContext.CurrentUser.ProjectCode);
                    List<EquipInfo> FunctionQueryList = FunctionQuery.ToList();
                    if (FunctionQuery.Count() != 0)
                    {
                        foreach (var itemList in FunctionQueryList)
                        {
                            EquipInfo equipInfo = this._EquipInfoRepository.Get(itemList.EquipId);
                            equipInfo.EquipSpec = model.NuclearTrackResin.ResinVersionNew;
                            equipInfo.Bulk = Convert.ToDecimal(model.NuclearTrackResin.ResinBulkNew);//记录体积容量
                            if (equipInfo.UpdateDate <= model.NuclearTrackResin.ResinChangeDate)
                            {
                                equipInfo.UpdateDate = model.NuclearTrackResin.ResinChangeDate;//更新设备时间
                            }
                            else if (equipInfo.UpdateDate == null)
                            {
                                equipInfo.UpdateDate = model.NuclearTrackResin.ResinChangeDate;//废树脂更换时间=更新设备时间

                            }
                            this._EquipInfoRepository.Update(equipInfo);//提交数据库  
                        }
                    }
                    else
                    {
                        return Json("{\"result\":false,\"msg\":\"您填写的系统号编错误!\"}", JsonRequestBehavior.AllowGet);
                    }
                    IQueryable<EquipInfo> FunctionPositionQuery = _NuclearTrackResinRepository.QueryListByFunctionPosition(model.NuclearTrackResin.Trans, AppContext.CurrentUser.ProjectCode);
                    List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                    if (FunctionPositionQuery.Count() != 0)
                    {
                        foreach (var itemList in FunctionPositionQueryList)
                        {
                            model.EquipInfo.EquipId = itemList.EquipId;
                            model.NuclearTrackResin.EquipId = model.EquipInfo.EquipId;
                        }
                        model.NuclearTrackResin.ResinId = Guid.NewGuid().ToString();
                        model.NuclearTrackResin.Status = "2";
                        model.NuclearTrackResin.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                        model.NuclearTrackResin.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                        model.NuclearTrackResin.CreateDate = DateTime.Now.Date;//创建时间
                        model.NuclearTrackResin.Stationcode = AppContext.CurrentUser.ProjectCode;
                        model.NuclearTrackResin.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        model.NuclearTrackResin.ConfirmUserName = AppContext.CurrentUser.UserName;
                        model.NuclearTrackResin.ConfirmDate = DateTime.Now.Date;
                        this._NuclearTrackResinRepository.Create(model.NuclearTrackResin);

                        //设备状态中自动加入一条数据
                        model.EquipDetail.EquipId = model.EquipInfo.EquipId;
                        model.EquipDetail.Status = "2";//状态
                        model.EquipDetail.DetailId = Guid.NewGuid().ToString();
                        model.NuclearTrackResin.EquipDetailId = model.EquipDetail.DetailId;
                        model.EquipDetail.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                        model.EquipDetail.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                        model.EquipDetail.CreateDate = DateTime.Now.Date;//创建时间
                        model.EquipDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        IQueryable<BasicObject> TypeStatusQuery = _NuclearTrackResinRepository.QueryListByTypeStatus("S状态变化");
                        List<BasicObject> TypeStatusQueryList = TypeStatusQuery.ToList();
                        foreach (var itemList in TypeStatusQueryList)
                        {
                            model.EquipDetail.TypeStatus = itemList.Uuid;
                        }
                        model.NuclearTrackResin.ResinBulkOld = model.NuclearTrackResin.ResinBulkOld.HasValue ? model.NuclearTrackResin.ResinBulkOld : 0;
                        model.EquipDetail.DetailNum = Convert.ToDecimal(model.NuclearTrackResin.ResinBulkOld);//数值
                        model.EquipDetail.Usability = "1";//可用性
                        model.EquipDetail.EventDate = DateTime.Now;//事件日期
                        model.EquipDetail.EventDesc = DateTime.Now.ToString("yyyy-MM-dd") + "接收废树脂";
                        this._EquipDetailRepository.Create(model.EquipDetail);//提交数据库

                        //更新传送设备数据
                        EquipInfo equipInfo = this._EquipInfoRepository.Get(model.EquipInfo.EquipId);
                        if (model.NuclearTrackResin.IsEmpty == "0")
                        {
                            if (equipInfo.Bulk == null)
                            {
                                equipInfo.Bulk = model.EquipDetail.DetailNum;//记录体积容量
                            }
                            else
                            {
                                equipInfo.Bulk = equipInfo.Bulk + model.EquipDetail.DetailNum;//记录体积容量
                            }
                        }
                        else
                        {
                            if(equipInfo.Bulk != null)
                            {

                                  equipInfo.Bulk = equipInfo.Bulk - model.EquipDetail.DetailNum;//记录体积容量
                            }
                        }
                        equipInfo.EquipSpec = model.NuclearTrackResin.ResinVersionOld;
                        if (equipInfo.UpdateDate <= model.NuclearTrackResin.MeasureDate)
                        {
                            equipInfo.UpdateDate = model.NuclearTrackResin.MeasureDate;//RP测量日期=更新设备时间
                        }
                        else if (equipInfo.UpdateDate == null)
                        {
                            equipInfo.UpdateDate = model.NuclearTrackResin.ResinChangeDate;//废树脂更换时间=更新设备时间

                        }
                        this._EquipInfoRepository.Update(equipInfo);//提交数据库  
                        if (model.NuclearTrackResin.IsEmpty == "0")
                        {
                            _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NuclearTrackResin.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                        }
                        else {
                            _NuclearTempstockRepository.MergeWasteTmpStock("RESIN", model.NuclearTrackResin.SavePosition, AppContext.CurrentUser.ProjectCode, 1);
                        }
                        this._NuclearTrackResinRepository.UnitOfWork.Commit();
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        if (AppContext.CurrentUser.ProjectCode != "FCGNP")
                        {
                            return Json("{\"result\":false,\"msg\":\"您填写的传送编码错误!\"}", JsonRequestBehavior.AllowGet);
                        }
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        //得到树脂型号信息
        [HttpPost]
        public JsonResult GetResinData(string systemCode)
        {
            string resinVersionNew = "";
            string resinBulkNew = "";
            var functionPosition = this._EquipInfoRepository.GetAll().Where(d => d.FunctionPosition == systemCode && d.Status == "2");
            if (functionPosition.Count() > 0)
            {
                var query = this._EquipInfoRepository.GetAll().Where(d => d.FunctionPosition == systemCode && d.Status == "2");
                if (query.Count() > 0)
                {
                    resinVersionNew = query.First().EquipSpec;
                    resinBulkNew = Convert.ToString(query.First().Bulk);
                }
                else
                {
                    resinVersionNew = "";
                    resinBulkNew = "";
                }
            }
            else {
                resinVersionNew = "";
                resinBulkNew = "";
            }
            return Json("{\"resinVersionNew\":\"" + resinVersionNew + "\",\"resinBulkNew\":\"" + resinBulkNew + "\"}", JsonRequestBehavior.AllowGet);
        }
        //获得设备编号
        public JsonResult GetDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<EquipInfo> list = new List<EquipInfo>();
            if (keyword.ToUpper().Trim() != null && keyword.ToUpper().Trim() != "")
            {
                IQueryable<EquipInfo> iqueryEquipInfo = _EquipInfoRepository.GetAll().AsQueryable().Where(e => e.FunctionPosition.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.Status == "2");
                if (iqueryEquipInfo.Count() > 0)
                {
                    list = iqueryEquipInfo.ToList();
                }
            }
            //List<BasicObject> functionQuery = _BasicObjectRepository.GetAll().Where(d => d.Name == "固体废物处理设备").AsQueryable().ToList();
            //if (!string.IsNullOrEmpty(functionQuery[0].Uuid))
            //    list = list.Where(n => n.EquipTypeId == functionQuery[0].Uuid).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].FunctionPosition;
                autoComplete.Code = list[i].EquipId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

         /// <summary>
        /// 导入历史数据页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Import()
        {
            return View();
        }

        #region 导入历史数据
        /// <summary>
        /// 导入技术废物2数据
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult Import(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的历史数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    //string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    //if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    //{
                    //    //删除文件
                    //    if (System.IO.File.Exists(strNewImportPath))
                    //    {
                    //        System.IO.File.Delete(strNewImportPath);
                    //    }
                    //    jsonResult = JsonResultHelper.JsonResult(false, "历史数据必须是EXCEL格式!");
                    //    jsonResult.ContentType = "text/html";
                    //    return jsonResult;
                    //}
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);
                        if (ds.Tables.Count < 1)
                        {
                            //删除文件
                            if (System.IO.File.Exists(strNewImportPath))
                            {
                                System.IO.File.Delete(strNewImportPath);
                            }
                            jsonResult = JsonResultHelper.JsonResult(false, "历史数据格式错误!");
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //判断EXCEL格式是否正确
                        string checkColumns = ImportDataBuilder.GetImportTrackResinErr(ds, strNewImportPath);
                        if (!string.IsNullOrEmpty(checkColumns))
                        {
                            jsonResult = JsonResultHelper.JsonResult(false, checkColumns);
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //导入数据
                        if (ds != null && ds.Tables.Count == 1)
                        {
                            ImportDataBuilder.ImportTrackResin(ds, strNewImportPath, AppContext.CurrentUser);
                        }
                    }
                }
                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }
        #endregion
    }
}


