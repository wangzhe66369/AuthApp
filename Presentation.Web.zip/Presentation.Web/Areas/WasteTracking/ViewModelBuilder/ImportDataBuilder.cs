﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.DomainObjects;
using MvcContrib.Sorting;
using NET01.CoreFramework;
using System.Data;
using RWIS.Presentation.Web.Core;
using CIT.Common.Common;
using RWIS.Presentation.Web.Core.Common;
using System.IO;
using NPOI.HSSF.UserModel;
using System.Web.Mvc;
using RWIS.Presentation.Web.Core.Common;
using System.Data.Entity.Validation;

namespace RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder
{
    public class ImportDataBuilder
    {
        #region 实体转化

        /// <summary>
        /// 实体转化 把草稿数据转化为正式的数据
        /// </summary>
        /// <param name="electricCableDraftVM"></param>
        /// <returns></returns>
        public static NuclearTrackTechS TransferFromDraft(NuclearTrackTechS nuclearTrackTechSs)
        {
            NuclearTrackTechS nuclearTrackTechS = new NuclearTrackTechS();
            nuclearTrackTechS.TechSId = nuclearTrackTechSs.TechSId;
            nuclearTrackTechS.BucketId = nuclearTrackTechSs.BucketId;
            nuclearTrackTechS.BucketCode = nuclearTrackTechSs.BucketCode;
            nuclearTrackTechS.TechSCode = nuclearTrackTechSs.TechSCode;
            nuclearTrackTechS.WorkTicket = nuclearTrackTechSs.WorkTicket;
            nuclearTrackTechS.SystemCode = nuclearTrackTechSs.SystemCode;
            nuclearTrackTechS.MachineStatus = nuclearTrackTechSs.MachineStatus;
            nuclearTrackTechS.RepairRound = nuclearTrackTechSs.RepairRound;
            nuclearTrackTechS.Description = nuclearTrackTechSs.Description;
            nuclearTrackTechS.RubbishKind = nuclearTrackTechSs.RubbishKind;
            nuclearTrackTechS.RubbishKindValue = nuclearTrackTechSs.RubbishKindValue;
            nuclearTrackTechS.RubbishKinds = nuclearTrackTechSs.RubbishKinds;
            nuclearTrackTechS.RubbishKindsValue = nuclearTrackTechSs.RubbishKindsValue;
            nuclearTrackTechS.RubbishWeight = nuclearTrackTechSs.RubbishWeight;
            nuclearTrackTechS.ProductionDate = nuclearTrackTechSs.ProductionDate;
            nuclearTrackTechS.CompressFlag = nuclearTrackTechSs.CompressFlag;
            nuclearTrackTechS.BurnFlag = nuclearTrackTechSs.BurnFlag;
            nuclearTrackTechS.WaterMaterialFlag = nuclearTrackTechSs.WaterMaterialFlag;
            nuclearTrackTechS.WaterMaterialName = nuclearTrackTechSs.WaterMaterialName;
            nuclearTrackTechS.WaterMaterialWeight = nuclearTrackTechSs.WaterMaterialWeight;
            nuclearTrackTechS.SurfaceDose = nuclearTrackTechSs.SurfaceDose;
            nuclearTrackTechS.EvaDose = nuclearTrackTechSs.EvaDose;
            nuclearTrackTechS.Remark = nuclearTrackTechSs.Remark;
            nuclearTrackTechS.ControlNo = nuclearTrackTechSs.ControlNo;
            nuclearTrackTechS.ControlName = nuclearTrackTechSs.ControlName;
            nuclearTrackTechS.ControlDate = nuclearTrackTechSs.ControlDate;
            nuclearTrackTechS.StatisticsNo = nuclearTrackTechSs.StatisticsNo;
            nuclearTrackTechS.StatisticsName = nuclearTrackTechSs.StatisticsName;
            nuclearTrackTechS.StatisticsDate = nuclearTrackTechSs.StatisticsDate;
            nuclearTrackTechS.CreateUserNo = nuclearTrackTechSs.CreateUserNo;
            nuclearTrackTechS.CreateUserName = nuclearTrackTechSs.CreateUserName;
            nuclearTrackTechS.CreateDate = nuclearTrackTechSs.CreateDate;
            nuclearTrackTechS.ConfirmUserNo = nuclearTrackTechSs.ConfirmUserNo;
            nuclearTrackTechS.ConfirmUserName = nuclearTrackTechSs.ConfirmUserName;
            nuclearTrackTechS.ConfirmDate = nuclearTrackTechSs.ConfirmDate;
            nuclearTrackTechS.Stationcode = nuclearTrackTechSs.Stationcode;
            nuclearTrackTechS.StationId = nuclearTrackTechSs.StationId;
            nuclearTrackTechS.Status = nuclearTrackTechSs.Status;
            nuclearTrackTechS.DealStatus = nuclearTrackTechSs.DealStatus;
            return nuclearTrackTechS;
        }
        #endregion 实体转化
        #region 导入技术废物2数据
        #region 添加数据

        /// <summary>
        /// 创建技术废物2数据
        /// </summary>
        /// <param name="wasteTrackingVM"></param>
        /// <returns></returns>
        public static string InsertData(WasteTrackingVM wasteTrackingVM, INuclearTrackTechSRepository nuclearTrackTechSRepository)
        {
            //INuclearTrackTechSRepository nuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
            try
            {
                //string guid = wasteTrackingVM.NuclearTrackTechS.TechSId;

                //判断编号是否重复
                if (nuclearTrackTechSRepository.IsRepeat(wasteTrackingVM.NuclearTrackTechS.TechSCode, AppContext.CurrentUser.ProjectCode))
                {
                    return "您填写的编号重复，请获取最新编号";
                }
                wasteTrackingVM.NuclearTrackTechS.TechSId = Guid.NewGuid().ToString();
                wasteTrackingVM.NuclearTrackTechS.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                wasteTrackingVM.NuclearTrackTechS.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                wasteTrackingVM.NuclearTrackTechS.CreateDate = DateTime.Now.Date;//创建时间
                wasteTrackingVM.NuclearTrackTechS.Stationcode = AppContext.CurrentUser.ProjectCode;
                wasteTrackingVM.NuclearTrackTechS.ConfirmUserNo = AppContext.CurrentUser.UserId;
                wasteTrackingVM.NuclearTrackTechS.ConfirmUserName = AppContext.CurrentUser.UserName;
                wasteTrackingVM.NuclearTrackTechS.ConfirmDate = DateTime.Now;
                wasteTrackingVM.NuclearTrackTechS.DealStatus = "0";
                if (wasteTrackingVM.NuclearTrackTechS.RepairRound != null&&wasteTrackingVM.NuclearTrackTechS.RepairRound != "")
                {
                    wasteTrackingVM.NuclearTrackTechS.MachineStatus = "1";
                }
                else {
                    wasteTrackingVM.NuclearTrackTechS.MachineStatus = "0";
                }
                //新增电缆信息
                nuclearTrackTechSRepository.Create(wasteTrackingVM.NuclearTrackTechS);
                nuclearTrackTechSRepository.UnitOfWork.Commit();
                return string.Empty;
            }
            catch
            {
                return "保存失败！";
            }
        }
        
        #endregion 添加数据

        /// <summary>
        /// 导入技术废物2数据
        /// </summary>
        /// <param name="ds">技术废物2数据集合</param>
        public static void ImporttrackTechS(DataSet ds, string strNewImportPath, ApplicationUser currentUser)
        {
            INuclearTrackTechSDraftRepository iNuclearTrackTechSDraftRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSDraftRepository>();
            INuclearTrackTechSRepository iNuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicWasteUnitRepository iBasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
            INuclearTrackElementRepository iNuclearTrackElementRepository = ServiceLocator.Current.GetInstance<INuclearTrackElementRepository>();
            INuclearTrackDepositRepository iNuclearTrackDepositRepository = ServiceLocator.Current.GetInstance<INuclearTrackDepositRepository>();
            INuclearTrackSolventRepository iNuclearTrackSolventRepository = ServiceLocator.Current.GetInstance<INuclearTrackSolventRepository>();
            INuclearTrackFilterRepository iNuclearTrackFilterRepository = ServiceLocator.Current.GetInstance<INuclearTrackFilterRepository>();
            INuclearTrackTechBRepository iNuclearTrackTechBRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechBRepository>();
            INuclearTrackSundryRepository iNuclearTrackSundryRepository = ServiceLocator.Current.GetInstance<INuclearTrackSundryRepository>();
            List<ImportTrackTechSErr> trackTechSErrList = new List<ImportTrackTechSErr>();
            ImportTrackTechSErr trackTechSErr = null;


            //得到电缆列表信息，并新增"错误描述"列
            DataTable dtElectricCable = ds.Tables[0];
            dtElectricCable.Columns.Add("错误描述", typeof(string));

            for (int i = 0; i < dtElectricCable.Rows.Count; i++)
            {
                #region 添加电缆数据
                trackTechSErr = new ImportTrackTechSErr();
                DataRow row = dtElectricCable.Rows[i];
                string techSCode = trackTechSErr.TechSCode = CommonFunc.ObjectToNullStr(row["单号"]).Trim();
                string stationId = trackTechSErr.StationId = CommonFunc.ObjectToNullStr(row["电站"]).Trim();
                string repairRound = trackTechSErr.RepairRound = CommonFunc.ObjectToNullStr(row["大修Cycle"]).Trim();
                string bucketId = trackTechSErr.BucketId = CommonFunc.ObjectToNullStr(row["200升金属桶编号"]).Trim();
                string workTicket = trackTechSErr.WorkTicket = CommonFunc.ObjectToNullStr(row["工作票号"]).Trim();
                string description = trackTechSErr.Description = CommonFunc.ObjectToNullStr(row["废物描述"]).Trim();
                string productionDate = Convert.ToString(trackTechSErr.ProductionDate);productionDate = CommonFunc.ObjectToNullStr(row["废物产生日期"]).Trim();
                string rubbishWeight = Convert.ToString(trackTechSErr.RubbishWeight);rubbishWeight = CommonFunc.ObjectToNullStr(row["重量"]).Trim();                
                string surfaceDose = Convert.ToString(trackTechSErr.SurfaceDose);surfaceDose = CommonFunc.ObjectToNullStr(row["最大剂量率"]).Trim();               
                string evaDose = Convert.ToString(trackTechSErr.EvaDose);evaDose = CommonFunc.ObjectToNullStr(row["平均剂量率"]).Trim();               
                string statisticsName = trackTechSErr.StatisticsName = CommonFunc.ObjectToNullStr(row["统计员"]).Trim();
                string statisticsDate = Convert.ToString(trackTechSErr.StatisticsDate); statisticsDate = CommonFunc.ObjectToNullStr(row["统计日期"]).Trim();
                string controlName = trackTechSErr.ControlName = CommonFunc.ObjectToNullStr(row["操作员"]).Trim();
                string controlDate = Convert.ToString(trackTechSErr.ControlDate); controlDate = CommonFunc.ObjectToNullStr(row["操作日期"]).Trim();
                string waterMaterialFlag = trackTechSErr.WaterMaterialFlag = CommonFunc.ObjectToNullStr(row["是否吸水"]).Trim();
                string waterMaterialName = trackTechSErr.WaterMaterialName = CommonFunc.ObjectToNullStr(row["吸水材料"]).Trim();
                string waterMaterialWeight = Convert.ToString(trackTechSErr.WaterMaterialWeight); waterMaterialWeight = CommonFunc.ObjectToNullStr(row["材料重量"]).Trim();
                string compressFlag = trackTechSErr.CompressFlag = CommonFunc.ObjectToNullStr(row["是否可压缩"]).Trim();
                string remark = trackTechSErr.Remark = CommonFunc.ObjectToNullStr(row["备注"]).Trim();

                //电站
                string stationCode = string.Empty;
                if (!string.IsNullOrEmpty(stationId))
                {
                    if(stationId == "L")
                    {
                        List<BasicWasteUnit> basicWasteUnitQuery = iBasicWasteUnitRepository.GetAll().Where(d => d.UnitName == "岭澳核电站" && d.Status == "2").AsQueryable().ToList();
                        if (basicWasteUnitQuery != null && basicWasteUnitQuery.Count() > 0)
                        {
                            stationCode = basicWasteUnitQuery[0].UnitId;
                        }
                    }
                    if (stationId == "D")
                    {
                        List<BasicWasteUnit> basicWasteUnitQuery = iBasicWasteUnitRepository.GetAll().Where(d => d.UnitName == "大亚湾" && d.Status == "2").AsQueryable().ToList();
                        if (basicWasteUnitQuery != null && basicWasteUnitQuery.Count() > 0)
                        {
                            stationCode = basicWasteUnitQuery[0].UnitId;
                        }
                    }
                    if (stationId == "K")
                    {
                        List<BasicWasteUnit> basicWasteUnitQuery = iBasicWasteUnitRepository.GetAll().Where(d => d.UnitName == "岭东核电站" && d.Status == "2").AsQueryable().ToList();
                        if (basicWasteUnitQuery != null && basicWasteUnitQuery.Count() > 0)
                        {
                            stationCode = basicWasteUnitQuery[0].UnitId;
                        }
                    }
                    //stationCode = iBasicObjectRepository.GetSubobjectsByCode(stationcode, AppContext.CurrentUser.ProjectCode).ToString();
                    //if (string.IsNullOrEmpty(stationCode))
                    //{
                    //    trackTechSErr.Error += "系统中不存在该电站！";
                    //}
                }

                //208L金属桶号
                string bucketCode = string.Empty;
                if (!string.IsNullOrEmpty(bucketId))
                {
                    bucketCode = iNuclearBucketRepository.IsExistWasteBucket(bucketId, AppContext.CurrentUser.ProjectCode).ToString();
                    if (string.IsNullOrEmpty(bucketCode))
                    {
                        trackTechSErr.Error += "系统中不存在该桶号！";
                    }
                    if (iNuclearTrackTechSRepository.IsRepeatBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode))
                    {
                        trackTechSErr.Error +="您填写的208L金属桶编号重复";
                    }
                    //判断桶是否被废滤芯使用
                    int elementbucketId = iNuclearTrackElementRepository.IsRepeatBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (elementbucketId > 0)
                    {
                        trackTechSErr.Error +="您填写208L金属桶编号已经被废滤芯列表中包装容器使用";
                    }
                    int elementbucketIds = iNuclearTrackElementRepository.IsRepeatInputBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (elementbucketIds > 0)
                    {
                        trackTechSErr.Error +="您填写208L金属桶编号已经被废滤芯列表中包装容器使用";
                    }
                    //判断桶是否被淤积物使用
                    int depositbucketId = iNuclearTrackDepositRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (depositbucketId > 0)
                    {
                        trackTechSErr.Error +="您填写208L金属桶编号已经被淤积物列表中暂存包装容器使用";
                    }
                    //判断桶是否被废油和溶剂使用
                    int solventbucketId = iNuclearTrackSolventRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (solventbucketId > 0)
                    {
                        trackTechSErr.Error +="您填写208L金属桶编号已经被废油和溶剂中暂存包装容器使用";
                    }
                    //判断桶是否被通风过滤器使用
                    int filerbucketId = iNuclearTrackFilterRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (filerbucketId > 0)
                    {
                        trackTechSErr.Error +="您填写208L金属桶编号已经被通风过滤器中暂存包装容器使用";
                    }
                    //判断桶是否被技术废物1使用
                    int techBbucketId = iNuclearTrackTechBRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (techBbucketId > 0)
                    {
                        trackTechSErr.Error +="您填写208L金属桶编号已经被技术废物1中暂存包装容器使用";
                    }
                    //判断桶是否被杂项使用
                    int sundrybucketId = iNuclearTrackSundryRepository.IsRepeatBucketCode(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (sundrybucketId > 0)
                    {
                        trackTechSErr.Error +="您填写208L金属桶编号已经被杂项中暂存包装容器使用";
                    }
                }
                //是否吸水
                string waterMaterialFlags = string.Empty;
                if (!string.IsNullOrEmpty(waterMaterialFlag))
                {
                    if (waterMaterialFlag == "N")
                    {
                        waterMaterialFlags = "0";
                    }
                    if (waterMaterialFlag == "Y")
                    {
                        waterMaterialFlags = "1";
                    }
                }
                //是否可压缩
                string compressFlags = string.Empty;
                if (!string.IsNullOrEmpty(compressFlag))
                {
                    if (compressFlag == "否")
                    {
                        compressFlags = "0";
                    }
                    if (compressFlag == "是")
                    {
                        compressFlags = "1";
                    }
                }
                //判断数据是否正确
                if (CommonFunc.IsNotNullString(trackTechSErr.Error))
                {
                    trackTechSErrList.Add(trackTechSErr);
                    continue;
                }
                else
                {
                    NuclearTrackTechS nuclearTrackTechSs = new NuclearTrackTechS();
                    nuclearTrackTechSs.TechSCode = techSCode;
                    nuclearTrackTechSs.StationId = stationCode;
                    //nuclearTrackTechSDraft.Stationcode = AppContext.CurrentUser.ProjectCode;
                    nuclearTrackTechSs.RepairRound = repairRound;
                    nuclearTrackTechSs.BucketId = bucketCode;
                    nuclearTrackTechSs.WorkTicket = workTicket;
                    nuclearTrackTechSs.Description = description;
                    if (productionDate != null && productionDate != "")
                    {
                        nuclearTrackTechSs.ProductionDate = Convert.ToDateTime(productionDate);
                    }
                    else {
                        nuclearTrackTechSs.ProductionDate = null;
                    }
                    if (rubbishWeight != null && rubbishWeight != "")
                    {
                        nuclearTrackTechSs.RubbishWeight = Convert.ToDecimal(rubbishWeight);
                    }
                    else {
                        nuclearTrackTechSs.RubbishWeight = null;
                    }
                    if (surfaceDose != null && surfaceDose != "")
                    {
                        nuclearTrackTechSs.SurfaceDose = Convert.ToDecimal(surfaceDose);
                    }
                    else {
                        nuclearTrackTechSs.SurfaceDose = null;
                    }
                    if (evaDose != null && evaDose != "")
                    {
                        nuclearTrackTechSs.EvaDose = Convert.ToDecimal(evaDose);
                    }
                    else {
                        nuclearTrackTechSs.EvaDose = null;
                    }
                    if (statisticsName != null && statisticsName != "")
                    {
                        nuclearTrackTechSs.StatisticsNo = statisticsName.Substring(1, 7);
                        nuclearTrackTechSs.StatisticsName = statisticsName.Substring(9);
                    }
                    else {
                        nuclearTrackTechSs.StatisticsNo = null;
                        nuclearTrackTechSs.StatisticsName = null;
                    }
                    if (statisticsDate != null && statisticsDate != "")
                    {
                        nuclearTrackTechSs.StatisticsDate = Convert.ToDateTime(statisticsDate);
                    }
                    else {
                        nuclearTrackTechSs.StatisticsDate = null;
                    }
                    if (controlName != null && controlName != "")
                    {
                        nuclearTrackTechSs.ControlNo = controlName.Substring(1, 7);
                        nuclearTrackTechSs.ControlName = controlName.Substring(9);
                    }
                    else {
                        nuclearTrackTechSs.ControlNo = null;
                        nuclearTrackTechSs.ControlName = null;
                    }
                    if (controlDate != null && controlDate != "")
                    {
                        nuclearTrackTechSs.ControlDate = Convert.ToDateTime(controlDate);
                    }
                    else {
                        nuclearTrackTechSs.ControlDate = null;
                    }
                    nuclearTrackTechSs.WaterMaterialFlag = waterMaterialFlags;
                    nuclearTrackTechSs.WaterMaterialName = waterMaterialName;
                    if (waterMaterialWeight != null && waterMaterialWeight!= "")
                    {
                        nuclearTrackTechSs.WaterMaterialWeight = Convert.ToDecimal(waterMaterialWeight);
                    }
                    else {
                        nuclearTrackTechSs.WaterMaterialWeight = null;
                    }
                    nuclearTrackTechSs.CompressFlag = compressFlags;
                    nuclearTrackTechSs.Remark = remark;
                    nuclearTrackTechSs.Status = "2";

                    //添加电缆草稿信息
                    WasteTrackingVM vm = new WasteTrackingVM();
                    vm.NuclearTrackTechS = nuclearTrackTechSs;
                    string messge = InsertData(vm, iNuclearTrackTechSRepository);
                    if (!string.IsNullOrEmpty(messge))
                    {
                        trackTechSErr.Error += messge;
                        trackTechSErrList.Add(trackTechSErr);
                        iNuclearTrackTechSRepository.UnitOfWork.RollbackChanges();
                        continue;
                    }
                    //else
                    //{
                    //    //添加电缆信息
                    //    NuclearTrackTechS nuclearTrackTechSData = ImportDataBuilder.TransferFromDraft(nuclearTrackTechSs);
                    //    nuclearTrackTechSData.TechSId = Guid.NewGuid().ToString();
                    //    iNuclearTrackTechSRepository.Create(nuclearTrackTechSData);
                    //    iNuclearTrackTechSRepository.UnitOfWork.Commit();

                    //}

                }
                #endregion 添加电缆数据
            }

            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);

            #region 错误文档
            if (trackTechSErrList.Count() > 0 )
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (trackTechSErrList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("技术废物2数据错误信息");
                    ImportExportHelper.FillSheet<ImportTrackTechSErr>(trackTechSErrList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<ImportTrackTechSErr>(stream);
            }

            #endregion
        }

        /// <summary>
        /// 检查导入的技术废物2数据表格列头是否正确
        /// </summary>
        /// <param name="ds">技术废物2数据数据集</param>
        /// <param name="strNewImportPath">技术废物2数据数据所在的物理路径</param>
        /// <returns></returns>
        public static string GetImporttrackTechSErr(DataSet ds, string strNewImportPath)
        {
            string errMsg = string.Empty;

            //得到电缆列头信息
            DataTable dtElectricCable = ds.Tables[0];
            string columnNames = ",";
            for (int i = 0; i < dtElectricCable.Columns.Count; i++)
            {
                columnNames += dtElectricCable.Columns[i].ColumnName + ",";
            }
            bool isCorrectStyle = true;
            isCorrectStyle = (columnNames.Contains(",单号,") && columnNames.Contains(",电站,") && columnNames.Contains(",大修Cycle,") && columnNames.Contains(",200升金属桶编号,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",工作票号,") && columnNames.Contains(",废物描述,") && columnNames.Contains(",废物产生日期,") && columnNames.Contains(",重量,") && columnNames.Contains(",最大剂量率,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",平均剂量率,") && columnNames.Contains(",统计员,") && columnNames.Contains(",统计日期,") && columnNames.Contains(",操作员,") && columnNames.Contains(",操作日期,") && columnNames.Contains(",是否吸水,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",吸水材料,") && columnNames.Contains(",材料重量,") && columnNames.Contains(",是否可压缩,") && columnNames.Contains(",备注,"));
            if (isCorrectStyle == false)
            {
                //删除文件
                if (System.IO.File.Exists(strNewImportPath))
                {
                    System.IO.File.Delete(strNewImportPath);
                }
                errMsg = "电缆数据模板格式有误,请仔细检查列头！";
            }
            return errMsg;
        }

        #endregion 导入技术废物2数据

        #region 导入废滤芯数据
        #region 添加数据

        /// <summary>
        /// 创建废滤芯数据
        /// </summary>
        /// <param name="wasteTrackingVM"></param>
        /// <returns></returns>
        public static string InsertElementData(WasteTrackingVM wasteTrackingVM, INuclearTrackElementRepository nuclearTrackElementRepository)
        {
            IEquipInfoRepository equipInfoRepository = ServiceLocator.Current.GetInstance<IEquipInfoRepository>();
            IBasicWasteUnitRepository iBasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
            try
            {
                //string guid = wasteTrackingVM.NuclearTrackTechS.TechSId;

                //判断编号是否重复
                if (nuclearTrackElementRepository.IsRepeat(wasteTrackingVM.NuclearTrackElement.ElementCode, AppContext.CurrentUser.ProjectCode))
                {
                    return "您填写的编号重复，请获取最新编号";
                }
                wasteTrackingVM.NuclearTrackElement.ElementId = Guid.NewGuid().ToString();
                //加载电站
                //IQueryable<BasicWasteUnit> QueryStationList = iBasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
                //List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
                //if (QueryStationList != null && QueryStationList.Count() > 0)
                //{
                //    stationList = QueryStationList.ToList();
                //    wasteTrackingVM.NuclearTrackElement.StationId = stationList[0].UnitId;
                //}
                ////加载电站
                if (wasteTrackingVM.NuclearTrackElement.ElementCode.Substring(0, 1) == "D")
                {
                    UnitMethod(wasteTrackingVM, iBasicWasteUnitRepository, "DI");
                }
                if (wasteTrackingVM.NuclearTrackElement.ElementCode.Substring(0, 1) == "L")
                {
                    UnitMethod(wasteTrackingVM, iBasicWasteUnitRepository, "LI");
                }
                if (wasteTrackingVM.NuclearTrackElement.ElementCode.Substring(0, 1) == "K")
                {
                    UnitMethod(wasteTrackingVM, iBasicWasteUnitRepository, "KI");
                }
                wasteTrackingVM.NuclearTrackElement.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                wasteTrackingVM.NuclearTrackElement.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                wasteTrackingVM.NuclearTrackElement.CreateDate = DateTime.Now.Date;//创建时间
                wasteTrackingVM.NuclearTrackElement.Stationcode = AppContext.CurrentUser.ProjectCode;
                wasteTrackingVM.NuclearTrackElement.ConfirmUserNo = AppContext.CurrentUser.UserId;
                wasteTrackingVM.NuclearTrackElement.ConfirmUserName = AppContext.CurrentUser.UserName;
                wasteTrackingVM.NuclearTrackElement.ConfirmDate = DateTime.Now;
                wasteTrackingVM.NuclearTrackElement.DealStatus = "0";
                wasteTrackingVM.NuclearTrackElement.MachineStatus = "0";
                IQueryable<EquipInfo> FunctionQuery = nuclearTrackElementRepository.QueryListByFunction(wasteTrackingVM.NuclearTrackElement.SystemCode, AppContext.CurrentUser.ProjectCode);
                List<EquipInfo> FunctionQueryList = FunctionQuery.ToList();
                if (FunctionQuery != null && FunctionQuery.Count()>0)
                {
                    foreach (var itemList in FunctionQueryList)
                    {
                        EquipInfo equipInfo = equipInfoRepository.Get(itemList.EquipId);
                        //equipInfo.UpdateDate = DateTime.Now.Date;//更新设备时间
                        equipInfo.EquipSpec = wasteTrackingVM.NuclearTrackElement.ElementVersionNew;//
                        equipInfoRepository.Update(equipInfo);//提交数据库  
                    }
                }
                //新增电缆信息
                nuclearTrackElementRepository.Create(wasteTrackingVM.NuclearTrackElement);
                nuclearTrackElementRepository.UnitOfWork.Commit();
                return string.Empty;
            }
            catch
            {
                return "保存失败！";
            }
        }

        #endregion 添加数据

        /// <summary>
        /// 导入技术废物2数据
        /// </summary>
        /// <param name="ds">技术废物2数据集合</param>
        public static void ImportTrackElement(DataSet ds, string strNewImportPath, ApplicationUser currentUser)
        {
            INuclearTrackElementRepository iNuclearTrackElementRepository = ServiceLocator.Current.GetInstance<INuclearTrackElementRepository>();
            INuclearTrackTechSRepository iNuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicWasteUnitRepository iBasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();

            List<ImportTrackElementErr> trackElementErrList = new List<ImportTrackElementErr>();
            ImportTrackElementErr trackElementErr = null;


            //得到电缆列表信息，并新增"错误描述"列
            DataTable dtElectricCable = ds.Tables[0];
            dtElectricCable.Columns.Add("错误描述", typeof(string));

            for (int i = 0; i < dtElectricCable.Rows.Count; i++)
            {
                #region 添加电缆数据
                trackElementErr = new ImportTrackElementErr();
                DataRow row = dtElectricCable.Rows[i];
                string elementCode = trackElementErr.ElementCode = CommonFunc.ObjectToNullStr(row["跟踪单号"]).Trim();
                string systemCode = trackElementErr.SystemCode = CommonFunc.ObjectToNullStr(row["系统号"]).Trim();
                string workTicket = trackElementErr.WorkTicket = CommonFunc.ObjectToNullStr(row["申请票号"]).Trim();
                string filterStopDate = Convert.ToString(trackElementErr.FilterStopDate); filterStopDate = CommonFunc.ObjectToNullStr(row["停运日期"]).Trim();
                string surfaceTouch = Convert.ToString(trackElementErr.SurfaceTouch); surfaceTouch = CommonFunc.ObjectToNullStr(row["表面剂量率"]).Trim();
                string elementVersionNew = trackElementErr.ElementVersionNew = CommonFunc.ObjectToNullStr(row["新过滤器类型"]).Trim();
                string elementVersionOld = trackElementErr.ElementVersionOld = CommonFunc.ObjectToNullStr(row["旧过滤器类型"]).Trim();
                string remark = trackElementErr.Remark = CommonFunc.ObjectToNullStr(row["备注"]).Trim();

                //判断数据是否正确
                if (CommonFunc.IsNotNullString(trackElementErr.Error))
                {
                    trackElementErrList.Add(trackElementErr);
                    continue;
                }
                else
                {
                    NuclearTrackElement nuclearTrackElement = new NuclearTrackElement();
                    nuclearTrackElement.ElementCode = elementCode;
                    nuclearTrackElement.SystemCode = systemCode;
                    nuclearTrackElement.WorkTicket = workTicket;
                    if (filterStopDate != null && filterStopDate != "")
                    {
                        nuclearTrackElement.FilterStopDate = Convert.ToDateTime(filterStopDate);
                    }
                    else {
                        nuclearTrackElement.FilterStopDate = null;
                    }
                    if (surfaceTouch != null && surfaceTouch != "")
                    {
                        nuclearTrackElement.SurfaceTouch = Convert.ToDecimal(surfaceTouch);
                    }
                    else {
                        nuclearTrackElement.SurfaceTouch = null;
                    }
                    nuclearTrackElement.ElementVersionNew = elementVersionNew;
                    nuclearTrackElement.ElementVersionOld = elementVersionOld;
                    nuclearTrackElement.Remark = remark;
                    nuclearTrackElement.Status = "2";

                    //添加电缆草稿信息
                    WasteTrackingVM vm = new WasteTrackingVM();
                    vm.NuclearTrackElement = nuclearTrackElement;
                    string messge = InsertElementData(vm, iNuclearTrackElementRepository);
                    if (!string.IsNullOrEmpty(messge))
                    {
                        trackElementErr.Error += messge;
                        trackElementErrList.Add(trackElementErr);
                        iNuclearTrackElementRepository.UnitOfWork.RollbackChanges();
                        continue;
                    }
                    //else
                    //{
                    //    //添加电缆信息
                    //    NuclearTrackTechS nuclearTrackTechSData = ImportDataBuilder.TransferFromDraft(nuclearTrackTechSs);
                    //    nuclearTrackTechSData.TechSId = Guid.NewGuid().ToString();
                    //    iNuclearTrackTechSRepository.Create(nuclearTrackTechSData);
                    //    iNuclearTrackTechSRepository.UnitOfWork.Commit();

                    //}

                }
                #endregion 添加电缆数据
            }

            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);

            #region 错误文档
            if (trackElementErrList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (trackElementErrList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("废滤芯数据错误信息");
                    ImportExportHelper.FillSheet<ImportTrackElementErr>(trackElementErrList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<ImportTrackElementErr>(stream);
            }

            #endregion
        }

        /// <summary>
        /// 检查导入的技术废物2数据表格列头是否正确
        /// </summary>
        /// <param name="ds">技术废物2数据数据集</param>
        /// <param name="strNewImportPath">技术废物2数据数据所在的物理路径</param>
        /// <returns></returns>
        public static string GetImportTrackElementErr(DataSet ds, string strNewImportPath)
        {
            string errMsg = string.Empty;

            //得到电缆列头信息
            DataTable dtElectricCable = ds.Tables[0];
            string columnNames = ",";
            for (int i = 0; i < dtElectricCable.Columns.Count; i++)
            {
                columnNames += dtElectricCable.Columns[i].ColumnName + ",";
            }
            bool isCorrectStyle = true;
            isCorrectStyle = (columnNames.Contains(",跟踪单号,") && columnNames.Contains(",系统号,") && columnNames.Contains(",申请票号,") && columnNames.Contains(",停运日期,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",表面剂量率,") && columnNames.Contains(",新过滤器类型,") && columnNames.Contains(",旧过滤器类型,") && columnNames.Contains(",备注,"));
            if (isCorrectStyle == false)
            {
                //删除文件
                if (System.IO.File.Exists(strNewImportPath))
                {
                    System.IO.File.Delete(strNewImportPath);
                }
                errMsg = "废滤芯数据模板格式有误,请仔细检查列头！";
            }
            return errMsg;
        }

        #endregion 导入废滤芯数据

        #region 导入废树脂数据
        #region 添加数据

        /// <summary>
        /// 创建废树脂数据
        /// </summary>
        /// <param name="wasteTrackingVM"></param>
        /// <returns></returns>
        public static string InsertResinData(WasteTrackingVM wasteTrackingVM, INuclearTrackResinRepository nuclearTrackResinRepository)
        {
            IEquipInfoRepository iEquipInfoRepository = ServiceLocator.Current.GetInstance<IEquipInfoRepository>();
            IEquipDetailRepository iEquipDetailRepository = ServiceLocator.Current.GetInstance<IEquipDetailRepository>();
            IBasicWasteUnitRepository iBasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
            INuclearTempstockRepository iNuclearTempstockRepository = ServiceLocator.Current.GetInstance<INuclearTempstockRepository>();
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            try
            {
                //string guid = wasteTrackingVM.NuclearTrackTechS.TechSId;

                //判断编号是否重复
                if (nuclearTrackResinRepository.IsRepeat(wasteTrackingVM.NuclearTrackResin.ResinCode, AppContext.CurrentUser.ProjectCode))
                {
                    return "您填写的编号重复，请获取最新编号";
                }
                wasteTrackingVM.NuclearTrackResin.ResinId = Guid.NewGuid().ToString();
                ////加载电站
                if (wasteTrackingVM.NuclearTrackResin.ResinCode.Substring(0,1) == "D")
                {
                    UnitMethod(wasteTrackingVM, iBasicWasteUnitRepository, "DI");
                }
                if (wasteTrackingVM.NuclearTrackResin.ResinCode.Substring(0, 1) == "L")
                {
                    UnitMethod(wasteTrackingVM, iBasicWasteUnitRepository, "LI");
                }
                if (wasteTrackingVM.NuclearTrackResin.ResinCode.Substring(0, 1) == "K")
                {
                    UnitMethod(wasteTrackingVM, iBasicWasteUnitRepository, "KI");
                }
               //UnitMethod(wasteTrackingVM, iBasicWasteUnitRepository, simpleCode);
                wasteTrackingVM.NuclearTrackResin.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                wasteTrackingVM.NuclearTrackResin.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                wasteTrackingVM.NuclearTrackResin.CreateDate = DateTime.Now.Date;//创建时间
                wasteTrackingVM.NuclearTrackResin.Stationcode = AppContext.CurrentUser.ProjectCode;
                wasteTrackingVM.NuclearTrackResin.ConfirmUserNo = AppContext.CurrentUser.UserId;
                wasteTrackingVM.NuclearTrackResin.ConfirmUserName = AppContext.CurrentUser.UserName;
                wasteTrackingVM.NuclearTrackResin.ConfirmDate = DateTime.Now;
                wasteTrackingVM.NuclearTrackResin.DealStatus = "0";
                wasteTrackingVM.NuclearTrackResin.MachineStatus = "0";
                wasteTrackingVM.NuclearTrackResin.IsEmpty = "0";
                IQueryable<EquipInfo> FunctionQuery = nuclearTrackResinRepository.QueryListByFunction(wasteTrackingVM.NuclearTrackResin.SystemCode, AppContext.CurrentUser.ProjectCode);
                List<EquipInfo> FunctionQueryList = FunctionQuery.ToList();
                if (FunctionQuery != null && FunctionQuery.Count() > 0)
                {
                    foreach (var itemList in FunctionQueryList)
                    {
                        EquipInfo equipInfo = iEquipInfoRepository.Get(itemList.EquipId);
                        if (wasteTrackingVM.NuclearTrackResin.ResinVersionNew != null && wasteTrackingVM.NuclearTrackResin.ResinVersionNew != "")
                        {
                            equipInfo.EquipSpec = wasteTrackingVM.NuclearTrackResin.ResinVersionNew;
                        }
                        equipInfo.Bulk = Convert.ToDecimal(wasteTrackingVM.NuclearTrackResin.ResinBulkNew);//记录体积容量
                        //equipInfo.UpdateDate = wasteTrackingVM.NuclearTrackResin.MeasureDate;//更新设备时间
                        iEquipInfoRepository.Update(equipInfo);//提交数据库  
                    }
                }
                IQueryable<EquipInfo> FunctionPositionQuery = nuclearTrackResinRepository.QueryListByFunctionPosition(wasteTrackingVM.NuclearTrackResin.Trans, AppContext.CurrentUser.ProjectCode);
                List<EquipInfo> FunctionPositionQueryList = FunctionPositionQuery.ToList();
                EquipInfo equipInfos = new EquipInfo();
                if (FunctionPositionQuery.Count() != 0)
                {
                    foreach (var itemList in FunctionPositionQueryList)
                    {   
                        equipInfos.EquipId = itemList.EquipId;
                        //wasteTrackingVM.EquipInfo.EquipId = equipInfos.EquipId;
                        wasteTrackingVM.NuclearTrackResin.EquipId = equipInfos.EquipId;
                    }
                    //设备状态中自动加入一条数据
                    EquipDetail equipDetail = new EquipDetail();
                    equipDetail.EquipId = wasteTrackingVM.NuclearTrackResin.EquipId;
                    equipDetail.Status = "2";//状态
                    equipDetail.DetailId = Guid.NewGuid().ToString();
                    wasteTrackingVM.NuclearTrackResin.EquipDetailId = equipDetail.DetailId;
                    equipDetail.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    equipDetail.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    equipDetail.CreateDate = DateTime.Now.Date;//创建时间
                    equipDetail.Stationcode = AppContext.CurrentUser.ProjectCode;
                    IQueryable<BasicObject> TypeStatusQuery = nuclearTrackResinRepository.QueryListByTypeStatus("S状态变化");
                    List<BasicObject> TypeStatusQueryList = TypeStatusQuery.ToList();
                    foreach (var itemList in TypeStatusQueryList)
                    {
                        equipDetail.TypeStatus = itemList.Uuid;
                    }
                    wasteTrackingVM.NuclearTrackResin.ResinBulkOld = wasteTrackingVM.NuclearTrackResin.ResinBulkOld.HasValue ? wasteTrackingVM.NuclearTrackResin.ResinBulkOld : 0;
                    equipDetail.DetailNum = Convert.ToDecimal(wasteTrackingVM.NuclearTrackResin.ResinBulkOld);//数值
                    equipDetail.Usability = "1";//可用性
                    equipDetail.EventDate = DateTime.Now;//事件日期
                    equipDetail.EventDesc = DateTime.Now.ToString("yyyy-MM-dd") + "接收废树脂";
                    iEquipDetailRepository.Create(equipDetail);//提交数据库
                    EquipInfo equipInfoQuery = iEquipInfoRepository.Get(wasteTrackingVM.NuclearTrackResin.EquipId);
                    if (equipInfoQuery.Bulk == null)
                    {
                        equipInfoQuery.Bulk = equipDetail.DetailNum;//记录体积容量
                    }
                    else
                    {
                        equipInfoQuery.Bulk = equipInfoQuery.Bulk + equipDetail.DetailNum;//记录体积容量
                    }
                    iEquipInfoRepository.Update(equipInfoQuery);//提交数据库  
                }
                IQueryable<BasicObject> storagePositionIdQuery = iBasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
                List<BasicObject> storagePositionIdList = new List<BasicObject>();
                if (storagePositionIdQuery != null && storagePositionIdQuery.Count() > 0)
                {
                    storagePositionIdList = storagePositionIdQuery.ToList();
                    wasteTrackingVM.NuclearTrackResin.StoragePositionId = storagePositionIdList[0].Uuid;
                    iNuclearTempstockRepository.MergeWasteTmpStock("RESIN", wasteTrackingVM.NuclearTrackResin.StoragePositionId, AppContext.CurrentUser.ProjectCode, 1);
                }
                //新增电缆信息
                nuclearTrackResinRepository.Create(wasteTrackingVM.NuclearTrackResin);
                nuclearTrackResinRepository.UnitOfWork.Commit();
                return string.Empty;
            }
            catch(DbEntityValidationException dbEx )
            {
                return "保存失败！";
            }
        }

        private static void UnitMethod(WasteTrackingVM wasteTrackingVM, IBasicWasteUnitRepository iBasicWasteUnitRepository,string simpleCode)
        {
            IQueryable<BasicWasteUnit> QueryStationList = iBasicWasteUnitRepository.GetAll().Where(d => d.SimpleCode.ToUpper() == simpleCode).AsQueryable();
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList != null && QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
                wasteTrackingVM.NuclearTrackElement.StationId = stationList[0].UnitId;
            }
        }

        #endregion 添加数据

        /// <summary>
        /// 导入废树脂数据
        /// </summary>
        /// <param name="ds">废树脂数据集合</param>
        public static void ImportTrackResin(DataSet ds, string strNewImportPath, ApplicationUser currentUser)
        {
            INuclearTrackResinRepository iNuclearTrackResinRepository = ServiceLocator.Current.GetInstance<INuclearTrackResinRepository>();
            INuclearTrackTechSRepository iNuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicWasteUnitRepository iBasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();

            List<ImportTrackResinErr> trackResinErrList = new List<ImportTrackResinErr>();
            ImportTrackResinErr trackResinErr = null;


            //得到电缆列表信息，并新增"错误描述"列
            DataTable dtElectricCable = ds.Tables[0];
            dtElectricCable.Columns.Add("错误描述", typeof(string));

            for (int i = 0; i < dtElectricCable.Rows.Count; i++)
            {
                #region 添加电缆数据
                trackResinErr = new ImportTrackResinErr();
                DataRow row = dtElectricCable.Rows[i];
                string resinCode = trackResinErr.ResinCode = CommonFunc.ObjectToNullStr(row["跟踪单号"]).Trim();
                string systemCode = trackResinErr.SystemCode = CommonFunc.ObjectToNullStr(row["系统号"]).Trim();
                string workTicket = trackResinErr.WorkTicket = CommonFunc.ObjectToNullStr(row["申请票号"]).Trim();
                string processName = trackResinErr.ProcessName = CommonFunc.ObjectToNullStr(row["运行人员"]).Trim();
                string processDate = Convert.ToString(trackResinErr.ProcessDate); processDate = CommonFunc.ObjectToNullStr(row["运行日期"]).Trim();
                string changeCause = trackResinErr.ChangeCause = CommonFunc.ObjectToNullStr(row["更换原因"]).Trim();
                string resinVersionNew = trackResinErr.ResinVersionNew = CommonFunc.ObjectToNullStr(row["新树脂类型"]).Trim();
                string resinBulkNew = Convert.ToString(trackResinErr.ResinBulkNew); resinBulkNew = CommonFunc.ObjectToNullStr(row["新树脂体积"]).Trim();
                string resinVersionOld = trackResinErr.ResinVersionOld = CommonFunc.ObjectToNullStr(row["旧树脂类型"]).Trim();
                string resinBulkOld = Convert.ToString(trackResinErr.ResinBulkOld); resinBulkOld = CommonFunc.ObjectToNullStr(row["旧树脂体积"]).Trim();
                string saltbedStopDate = Convert.ToString(trackResinErr.SaltbedStopDate); saltbedStopDate = CommonFunc.ObjectToNullStr(row["停运日期"]).Trim();
                string chemistryName = trackResinErr.ChemistryName = CommonFunc.ObjectToNullStr(row["化学人员"]).Trim();
                string chemistryDate = Convert.ToString(trackResinErr.ChemistryDate); chemistryDate = CommonFunc.ObjectToNullStr(row["化学日期"]).Trim();
                string radioactionFlag = trackResinErr.RadioactionFlag = CommonFunc.ObjectToNullStr(row["有无放射性"]).Trim();
                string radioactionValue = Convert.ToString(trackResinErr.RadioactionValue); radioactionValue = CommonFunc.ObjectToNullStr(row["剂量率"]).Trim();
                string meterVersion = trackResinErr.MeterVersion = CommonFunc.ObjectToNullStr(row["仪表型号"]).Trim();
                string measureName = trackResinErr.MeasureName = CommonFunc.ObjectToNullStr(row["测量人员"]).Trim();
                string measureDate = Convert.ToString(trackResinErr.MeasureDate); measureDate = CommonFunc.ObjectToNullStr(row["测量日期"]).Trim();
                string trans = trackResinErr.Trans = CommonFunc.ObjectToNullStr(row["传送方向"]).Trim();
                string controlName = trackResinErr.ControlName = CommonFunc.ObjectToNullStr(row["操作人"]).Trim();
                string controlDate = Convert.ToString(trackResinErr.ControlDate); controlDate = CommonFunc.ObjectToNullStr(row["操作日期"]).Trim();
                if (!string.IsNullOrEmpty(resinCode))
                {
                    if (iNuclearTrackResinRepository.IsRepeat(resinCode, AppContext.CurrentUser.ProjectCode))
                    {
                        trackResinErr.Error += "跟踪单号重复！";
                    }
                }

             
                if (!string.IsNullOrEmpty(trans))
                {
                    IQueryable<EquipInfo> FunctionPositionQuery = iNuclearTrackResinRepository.QueryListByFunctionPosition(trans, AppContext.CurrentUser.ProjectCode);
                    if (FunctionPositionQuery.Count() == 0)
                    {
                        trackResinErr.Error += "系统中不存在该设备编码！";
                    }
                }
                //有无放射性
                string radioactionFlags = string.Empty;
                if (!string.IsNullOrEmpty(radioactionFlag))
                {
                    if (radioactionFlag == "N")
                    {
                        radioactionFlags = "0";
                    }
                    if (radioactionFlag == "Y")
                    {
                        radioactionFlags = "1";
                    }
                }
                //判断数据是否正确
                if (CommonFunc.IsNotNullString(trackResinErr.Error))
                {
                    trackResinErrList.Add(trackResinErr);
                    continue;
                }
                else
                {
                    NuclearTrackResin nuclearTrackResin = new NuclearTrackResin();
                    nuclearTrackResin.ResinCode = resinCode;
                    nuclearTrackResin.SystemCode = systemCode;
                    nuclearTrackResin.WorkTicket = workTicket;
                    if (processName != null && processName != "")
                    {
                        nuclearTrackResin.ProcessNo = processName.Substring(1, 7);
                        nuclearTrackResin.ProcessName = processName.Substring(9);
                    }
                    else
                    {
                        nuclearTrackResin.ProcessNo = null;
                        nuclearTrackResin.ProcessName = null;
                    }
                    if (processDate != null && processDate != ""){
                        nuclearTrackResin.ProcessDate = Convert.ToDateTime(processDate);
                    }else{
                        nuclearTrackResin.ProcessDate = null;
                    }
                    if (changeCause != null && changeCause != "")
                    {
                        nuclearTrackResin.ChangeFlag = "0";
                        nuclearTrackResin.ChangeCause = changeCause;
                    }
                    nuclearTrackResin.ResinVersionNew = resinVersionNew;
                    if (resinBulkNew != null && resinBulkNew != "")
                    {
                        nuclearTrackResin.ResinBulkNew = Convert.ToDouble(resinBulkNew.Substring(0, resinBulkNew.IndexOf('L')));
                    }
                    else
                    {
                        nuclearTrackResin.ResinBulkNew = 0;
                    }
                    nuclearTrackResin.ResinVersionOld = resinVersionOld;
                    if (resinBulkOld != null && resinBulkOld != "")
                    {
                        nuclearTrackResin.ResinBulkOld = Convert.ToDouble(resinBulkOld.Substring(0, resinBulkOld.IndexOf('L')));
                    }
                    else
                    {
                        nuclearTrackResin.ResinBulkOld = 0;
                    }
                    if (saltbedStopDate != null && saltbedStopDate != "")
                    {
                        nuclearTrackResin.SaltbedStopDate = Convert.ToDateTime(saltbedStopDate);
                    }
                    else
                    {
                        nuclearTrackResin.SaltbedStopDate = null;
                    }
                    if (chemistryName != null && chemistryName != "")
                    {
                        nuclearTrackResin.ChemistryNo = chemistryName.Substring(1, 7);
                        nuclearTrackResin.ChemistryName = chemistryName.Substring(9);
                    }
                    else
                    {
                        nuclearTrackResin.ChemistryNo = null;
                        nuclearTrackResin.ChemistryName = null;
                    }
                    if (chemistryDate != null && chemistryDate != "")
                    {
                        nuclearTrackResin.ChemistryDate = Convert.ToDateTime(chemistryDate);
                    }
                    else
                    {
                        nuclearTrackResin.ChemistryDate = null;
                    }
                    nuclearTrackResin.RadioactionFlag = radioactionFlags;
                    if (radioactionFlag == "Y")
                    {
                        if (radioactionValue != null && radioactionValue != "")
                        {
                            nuclearTrackResin.RadioactionValue = Convert.ToDecimal(radioactionValue);
                        }
                        else
                        {
                            nuclearTrackResin.RadioactionValue = null;
                        }
                    }
                    else {
                        nuclearTrackResin.RadioactionValue = null;
                    }
                    nuclearTrackResin.MeterVersion = meterVersion;
                    if (measureName != null && measureName != "")
                    {
                        nuclearTrackResin.MeasureNo = measureName.Substring(1, 7);
                        nuclearTrackResin.MeasureName = measureName.Substring(9);
                    }
                    else
                    {
                        nuclearTrackResin.MeasureNo = null;
                        nuclearTrackResin.MeasureName = null;
                    }
                    if (measureDate != null && measureDate != "")
                    {
                        nuclearTrackResin.MeasureDate = Convert.ToDateTime(measureDate);
                    }
                    else
                    {
                        nuclearTrackResin.MeasureDate = null;
                    }
                    nuclearTrackResin.Trans = trans;
                    if (controlName != null && controlName != "")
                    {
                        nuclearTrackResin.ControlNo = controlName.Substring(1, 7);
                        nuclearTrackResin.ControlName = controlName.Substring(9);
                    }
                    else
                    {
                        nuclearTrackResin.ControlNo = null;
                        nuclearTrackResin.ControlName = null;
                    }
                    if (controlDate != null && controlDate != "")
                    {
                        nuclearTrackResin.ControlDate = Convert.ToDateTime(controlDate);
                    }
                    else
                    {
                        nuclearTrackResin.ControlDate = null;
                    }
                    nuclearTrackResin.Status = "2";

                    //添加电缆草稿信息
                    WasteTrackingVM vm = new WasteTrackingVM();
                    vm.NuclearTrackResin = nuclearTrackResin;
                    string messge = InsertResinData(vm, iNuclearTrackResinRepository);
                    if (!string.IsNullOrEmpty(messge))
                    {
                        trackResinErr.Error += messge;
                        trackResinErrList.Add(trackResinErr);
                        iNuclearTrackResinRepository.UnitOfWork.RollbackChanges();
                        continue;
                    }
                    //else
                    //{
                    //    //添加电缆信息
                    //    NuclearTrackTechS nuclearTrackTechSData = ImportDataBuilder.TransferFromDraft(nuclearTrackTechSs);
                    //    nuclearTrackTechSData.TechSId = Guid.NewGuid().ToString();
                    //    iNuclearTrackTechSRepository.Create(nuclearTrackTechSData);
                    //    iNuclearTrackTechSRepository.UnitOfWork.Commit();

                    //}

                }
                #endregion 添加电缆数据
            }

            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);

            #region 错误文档
            if (trackResinErrList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (trackResinErrList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("废树脂数据错误信息");
                    ImportExportHelper.FillSheet<ImportTrackResinErr>(trackResinErrList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<ImportTrackResinErr>(stream);
            }

            #endregion
        }

        /// <summary>
        /// 检查导入的技术废物2数据表格列头是否正确
        /// </summary>
        /// <param name="ds">技术废物2数据数据集</param>
        /// <param name="strNewImportPath">技术废物2数据数据所在的物理路径</param>
        /// <returns></returns>
        public static string GetImportTrackResinErr(DataSet ds, string strNewImportPath)
        {
            string errMsg = string.Empty;

            //得到电缆列头信息
            DataTable dtElectricCable = ds.Tables[0];
            string columnNames = ",";
            for (int i = 0; i < dtElectricCable.Columns.Count; i++)
            {
                columnNames += dtElectricCable.Columns[i].ColumnName + ",";
            }
            bool isCorrectStyle = true;
            isCorrectStyle = (columnNames.Contains(",跟踪单号,") && columnNames.Contains(",系统号,") && columnNames.Contains(",申请票号,") && columnNames.Contains(",运行人员,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",运行日期,") && columnNames.Contains(",更换原因,") && columnNames.Contains(",新树脂类型,") && columnNames.Contains(",新树脂体积,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",旧树脂类型,") && columnNames.Contains(",旧树脂体积,") && columnNames.Contains(",启动日期,") && columnNames.Contains(",停运日期,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",化学人员,") && columnNames.Contains(",化学日期,") && columnNames.Contains(",机组包壳严重破损,") && columnNames.Contains(",事件单号,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",姓名,") && columnNames.Contains(",日期,") && columnNames.Contains(",有无放射性,") && columnNames.Contains(",剂量率,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",仪表型号,") && columnNames.Contains(",测量人员,") && columnNames.Contains(",测量日期,") && columnNames.Contains(",传送方向,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",操作人,") && columnNames.Contains(",操作日期,"));
            if (isCorrectStyle == false)
            {
                //删除文件
                if (System.IO.File.Exists(strNewImportPath))
                {
                    System.IO.File.Delete(strNewImportPath);
                }
                errMsg = "废树脂数据模板格式有误,请仔细检查列头！";
            }
            return errMsg;
        }

        #endregion 导入废滤芯数据
    }
}