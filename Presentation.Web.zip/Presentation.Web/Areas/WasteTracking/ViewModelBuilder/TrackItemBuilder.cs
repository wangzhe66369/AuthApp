﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   TrackItemBuilder.cs
 *   描    述   ：   各类源项跟踪单
 *   创 建 者   ：   PXMWSWG[苏武刚]
 *   创建日期   ：   2016-10-3 
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-3              1.0.0.0    苏武刚       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.DomainObjects;
using MvcContrib.Sorting;
using NET01.CoreFramework;

namespace RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder
{
    public class TrackItemBuilder
    {
        /// <summary>
        /// 根据电站编号得到所有的源项跟踪单信息
        /// </summary>
        /// <param name="stationCode">电站编号</param>
        /// <returns></returns>
        public static IQueryable<TrackItemVM> GetAllTrackList(string trackCode, string stationCode)
        {
            
            var query = GetTrackList(stationCode);
            if (!string.IsNullOrEmpty(trackCode))
            {
                query = query.Where(c => c.TrackCode.ToUpper().Contains(trackCode.Trim().ToUpper()));
            }
            return query;
        }

        /// <summary>
        /// 根据废物跟踪单ID得到源项跟踪单信息
        /// </summary>
        /// <param name="trackId">废物跟踪单ID</param>
        /// <returns></returns>
        public static IQueryable<TrackItemVM> GetAllTrackList(string trackId)
        {
            var query = GetTrackList(AppContext.CurrentUser.ProjectCode);
            if (!string.IsNullOrEmpty(trackId))
            {
                query = query.Where(c => c.TrackId == trackId);
            }
            return query;
        }

        public static IQueryable<TrackItemVM> GetTrackList(string stationCode)
        {
            stationCode = stationCode.ToUpper().Trim();
            //浓缩液跟源项跟踪单
            ITrackLiquorRepository iTrackLiquorRepository = ServiceLocator.Current.GetInstance<ITrackLiquorRepository>();
            IQueryable<TrackLiquor> iqueryTrackLiquor = iTrackLiquorRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.Status == "2");
            var liquorList = (from l in iqueryTrackLiquor
                             select new TrackItemVM
                             {
                                 TrackType = "LIQUID",
                                 TrackId = l.LiquorId,
                                 TrackCode = l.LiquorCode,
                                 LocationId = l.StoragePositionId,
                                 SystemCode = l.SystemCode,
                                 UnitStatus = l.MachineStatus,
                                 Cycle = l.Cycle,
                                 StationId = l.StationId,
                                 ConfirmDate = l.ConfirmDate,
                                 DealStatus = l.DealStatus,
                                 ControlDate=l.ControlDate
                             }).AsQueryable();

            //废树脂跟源项跟踪单
            INuclearTrackResinRepository iNuclearTrackResinRepository = ServiceLocator.Current.GetInstance<INuclearTrackResinRepository>();
            IQueryable<NuclearTrackResin> iqueryNuclearTrackResin = iNuclearTrackResinRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.Status == "2");
            var resinList = (from r in iqueryNuclearTrackResin
                            select new TrackItemVM
                            {
                                TrackType = "RESIN",
                                TrackId = r.ResinId,
                                TrackCode = r.ResinCode,
                                LocationId = r.StoragePositionId,
                                SystemCode = r.SystemCode,
                                UnitStatus = r.MachineStatus,
                                Cycle = r.Cycle,
                                StationId = r.StationId,
                                ConfirmDate = r.ConfirmDate,
                                DealStatus = r.DealStatus,
                                ControlDate = r.ControlDate
                            }).AsQueryable();

            //废滤芯跟源项跟踪单
            INuclearTrackElementRepository iNuclearTrackElementRepository = ServiceLocator.Current.GetInstance<INuclearTrackElementRepository>();
            IQueryable<NuclearTrackElement> iqueryNuclearTrackElement = iNuclearTrackElementRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.Status == "2");
            var elementList = (from r in iqueryNuclearTrackElement
                              select new TrackItemVM
                              {
                                  TrackType = "ELEMENT",
                                  TrackId = r.ElementId,
                                  TrackCode = r.ElementCode,
                                  LocationId = r.FactoryPositionId,
                                  SystemCode = r.SystemCode,
                                  UnitStatus = r.MachineStatus,
                                  Cycle = r.Cycle,
                                  StationId = r.StationId,
                                  ConfirmDate = r.ConfirmDate,
                                  DealStatus = r.DealStatus,
                                  ControlDate = r.ControlDate
                              }).AsQueryable();

            //淤积物跟源项跟踪单
            INuclearTrackDepositRepository iNuclearTrackDepositRepository = ServiceLocator.Current.GetInstance<INuclearTrackDepositRepository>();
            IQueryable<NuclearTrackDeposit> iqueryNuclearTrackDeposit = iNuclearTrackDepositRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.Status == "2");
            var depositList = (from r in iqueryNuclearTrackDeposit
                              select new TrackItemVM
                              {
                                  TrackType = "DEPOSIT",
                                  TrackId = r.DepositId,
                                  TrackCode = r.DepositCode,
                                  LocationId = r.StoragePositionId,
                                  SystemCode = r.SystemCode,
                                  UnitStatus = r.MachineStatus,
                                  Cycle = r.Cycle,
                                  StationId = r.StationId,
                                  ConfirmDate = r.ConfirmDate,
                                  DealStatus = r.DealStatus,
                                  ControlDate = r.ControlDate
                              }).AsQueryable();

            //废油和溶剂源项跟踪单
            INuclearTrackSolventRepository iNuclearTrackSolventRepository = ServiceLocator.Current.GetInstance<INuclearTrackSolventRepository>();
            IQueryable<NuclearTrackSolvent> iqueryNuclearTrackSolvent = iNuclearTrackSolventRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.Status == "2");
            var solventList = (from r in iqueryNuclearTrackSolvent
                              select new TrackItemVM
                              {
                                  TrackType = "SOLVENT",
                                  TrackId = r.SolventId,
                                  TrackCode = r.SolventCode,
                                  LocationId = r.StoragePositionId,
                                  SystemCode = r.SystemCode,
                                  UnitStatus = r.MachineStatus,
                                  Cycle = r.Cycle,
                                  StationId = r.StationId,
                                  ConfirmDate = r.ConfirmDate,
                                  DealStatus = r.DealStatus,
                                  ControlDate = r.ControlDate
                              }).AsQueryable();

            //通风过滤器源项跟踪单
            INuclearTrackFilterRepository iNuclearTrackFilterRepository = ServiceLocator.Current.GetInstance<INuclearTrackFilterRepository>();
            IQueryable<NuclearTrackFilter> iqueryNuclearTrackFilter = iNuclearTrackFilterRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.Status == "2");
            var filterList = (from r in iqueryNuclearTrackFilter
                             select new TrackItemVM
                             {
                                 TrackType = "FILTER",
                                 TrackId = r.FilterId,
                                 TrackCode = r.FilterCode,
                                 LocationId = r.StoragePositionId,
                                 SystemCode = r.SystemCode,
                                 UnitStatus = r.MachineStatus,
                                 Cycle = r.Cycle,
                                 StationId = r.StationId,
                                 ConfirmDate = r.ConfirmDate,
                                 DealStatus = r.DealStatus,
                                 ControlDate = r.ControlDate
                             }).AsQueryable();

            //技术废物(>2mSv/h)源项跟踪单
            INuclearTrackTechBRepository iNuclearTrackTechBRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechBRepository>();
            IQueryable<NuclearTrackTechB> iqueryNuclearTrackTechB = iNuclearTrackTechBRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.Status == "2");
            var tech1List = (from r in iqueryNuclearTrackTechB
                            select new TrackItemVM
                            {
                                TrackType = "TECH1",
                                TrackId = r.TechBId,
                                TrackCode = r.TechBCode,
                                LocationId = r.StoragePositionId,
                                SystemCode = r.SystemCode,
                                UnitStatus = r.MachineStatus,
                                Cycle = r.RepairRound,
                                StationId = r.StationId,
                                ConfirmDate = r.ConfirmDate,
                                DealStatus = r.DealStatus,
                                ControlDate = r.ControlDate
                            }).AsQueryable();

            //技术废物(<2mSv/h)源项跟踪单
            INuclearTrackTechSRepository iNuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
            IQueryable<NuclearTrackTechS> iqueryNuclearTrackTechS = iNuclearTrackTechSRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.Status == "2");
            var tech2List = (from r in iqueryNuclearTrackTechS
                            select new TrackItemVM
                            {
                                TrackType = "TECH2",
                                TrackId = r.TechSId,
                                TrackCode = r.TechSCode,
                                LocationId = "",
                                SystemCode = r.SystemCode,
                                UnitStatus = r.MachineStatus,
                                Cycle = r.RepairRound,
                                StationId = r.StationId,
                                ConfirmDate = r.ConfirmDate,
                                DealStatus = r.DealStatus,
                                ControlDate = r.ControlDate
                            }).AsQueryable();

            //杂项源项跟踪单
            INuclearTrackSundryRepository iNuclearTrackSundryRepository = ServiceLocator.Current.GetInstance<INuclearTrackSundryRepository>();
            IQueryable<NuclearTrackSundry> iqueryNuclearTrackSundry = iNuclearTrackSundryRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.Status == "2");
            var sundryList = (from r in iqueryNuclearTrackSundry
                             select new TrackItemVM
                             {
                                 TrackType = "SUNDRY",
                                 TrackId = r.SundryId,
                                 TrackCode = r.SundryCode,
                                 LocationId = r.StoragePositionId,
                                 SystemCode = r.SystemCode,
                                 UnitStatus = r.MachineStatus,
                                 Cycle = r.Cycle,
                                 StationId = r.StationId,
                                 ConfirmDate = r.ConfirmDate,
                                 DealStatus = r.DealStatus,
                                 ControlDate = r.ControlDate
                             }).AsQueryable();
            var query = liquorList.Union(resinList).Union(elementList).Union(depositList).Union(solventList).Union(filterList).Union(tech2List).Union(sundryList).Union(tech1List);
            return query;
        }

        public static void UpdateTrackByType(string trackType, string trackId, string bucketId, string factoryId)
        {
            //浓缩液跟源项跟踪单 LIQUID
            ITrackLiquorRepository iTrackLiquorRepository = ServiceLocator.Current.GetInstance<ITrackLiquorRepository>();
            //废树脂跟源项跟踪单 RESIN
            INuclearTrackResinRepository iNuclearTrackResinRepository = ServiceLocator.Current.GetInstance<INuclearTrackResinRepository>();
            //废滤芯跟源项跟踪单 ELEMENT
            INuclearTrackElementRepository iNuclearTrackElementRepository = ServiceLocator.Current.GetInstance<INuclearTrackElementRepository>();
            //淤积物跟源项跟踪单 DEPOSIT
            INuclearTrackDepositRepository iNuclearTrackDepositRepository = ServiceLocator.Current.GetInstance<INuclearTrackDepositRepository>();
            //废油和溶剂源项跟踪单 SOLVENT
            INuclearTrackSolventRepository iNuclearTrackSolventRepository = ServiceLocator.Current.GetInstance<INuclearTrackSolventRepository>();
            //通风过滤器源项跟踪单 FILTER
            INuclearTrackFilterRepository iNuclearTrackFilterRepository = ServiceLocator.Current.GetInstance<INuclearTrackFilterRepository>();
            //技术废物(>2mSv/h)源项跟踪单 TECH1
            INuclearTrackTechBRepository iNuclearTrackTechBRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechBRepository>();
            //技术废物(<2mSv/h)源项跟踪单 TECH2
            INuclearTrackTechSRepository iNuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
            //杂项源项跟踪单  SUNDRY
            INuclearTrackSundryRepository iNuclearTrackSundryRepository = ServiceLocator.Current.GetInstance<INuclearTrackSundryRepository>();
            switch (trackType)
            {
                case "SUNDRY":
                    var trackSUNDRY = iNuclearTrackSundryRepository.GetAll().Where(n => n.SundryId == trackId).FirstOrDefault();
                    if (trackSUNDRY != null)
                    {
                        trackSUNDRY.StoragePositionId = factoryId;
                        iNuclearTrackSundryRepository.Update(trackSUNDRY);
                        iNuclearTrackSundryRepository.UnitOfWork.Commit();
                    }
                    break;
                case "TECH2":
                    var trackTECH2 = iNuclearTrackTechSRepository.GetAll().Where(n => n.TechSId == trackId).FirstOrDefault();
                    if (trackTECH2 != null)
                    {
                        if (!string.IsNullOrEmpty(bucketId))
                            trackTECH2.BucketId = bucketId;
                        iNuclearTrackTechSRepository.Update(trackTECH2);
                        iNuclearTrackTechSRepository.UnitOfWork.Commit();
                    }
                    break;
                case "TECH1":
                    var trackTECH1 = iNuclearTrackTechBRepository.GetAll().Where(n => n.TechBId == trackId).FirstOrDefault();
                    if (trackTECH1 != null)
                    {
                        trackTECH1.StoragePositionId = factoryId;
                        if (!string.IsNullOrEmpty(bucketId))
                            trackTECH1.BucketId = bucketId;
                        iNuclearTrackTechBRepository.Update(trackTECH1);
                        iNuclearTrackTechBRepository.UnitOfWork.Commit();
                    }
                    break;
                case "FILTER":
                    var trackFILTER = iNuclearTrackFilterRepository.GetAll().Where(n => n.FilterId == trackId).FirstOrDefault();
                    if (trackFILTER != null)
                    {
                        trackFILTER.StoragePositionId = factoryId;
                        if (!string.IsNullOrEmpty(bucketId))
                            trackFILTER.BucketId = bucketId;
                        iNuclearTrackFilterRepository.Update(trackFILTER);
                        iNuclearTrackFilterRepository.UnitOfWork.Commit();
                    }
                    break;
                case "SOLVENT":
                    var trackSOLVENT = iNuclearTrackSolventRepository.GetAll().Where(n => n.SolventId == trackId).FirstOrDefault();
                    if (trackSOLVENT != null)
                    {
                        trackSOLVENT.StoragePositionId = factoryId;
                        if (!string.IsNullOrEmpty(bucketId))
                            trackSOLVENT.BucketId = bucketId;
                        iNuclearTrackSolventRepository.Update(trackSOLVENT);
                        iNuclearTrackSolventRepository.UnitOfWork.Commit();
                    }
                    break;
                case "DEPOSIT":
                    var trackDEPOSIT = iNuclearTrackDepositRepository.GetAll().Where(n => n.DepositId == trackId).FirstOrDefault();
                    if (trackDEPOSIT != null)
                    {
                        trackDEPOSIT.StoragePositionId = factoryId;
                        if (!string.IsNullOrEmpty(bucketId))
                            trackDEPOSIT.BucketId = bucketId;
                        iNuclearTrackDepositRepository.Update(trackDEPOSIT);
                        iNuclearTrackDepositRepository.UnitOfWork.Commit();
                    }
                    break;
                case "ELEMENT":
                    var trackELEMENT = iNuclearTrackElementRepository.GetAll().Where(n => n.ElementId == trackId).FirstOrDefault();
                    if (trackELEMENT != null)
                    {
                        trackELEMENT.FactoryPositionId = factoryId;
                        if (!string.IsNullOrEmpty(bucketId))
                            trackELEMENT.ContainerId = bucketId;
                        iNuclearTrackElementRepository.Update(trackELEMENT);
                        iNuclearTrackElementRepository.UnitOfWork.Commit();
                    }
                    break;
                case "RESIN":
                    var trackRESIN = iNuclearTrackResinRepository.GetAll().Where(n => n.ResinId == trackId).FirstOrDefault();
                    if (trackRESIN != null)
                    {
                        trackRESIN.StoragePositionId = factoryId;
                        iNuclearTrackResinRepository.Update(trackRESIN);
                        iNuclearTrackResinRepository.UnitOfWork.Commit();
                    }
                    break;
                case "LIQUID":
                    var trackLIQUID = iTrackLiquorRepository.GetAll().Where(n => n.LiquorId == trackId).FirstOrDefault();
                    if (trackLIQUID != null)
                    {
                        trackLIQUID.StoragePositionId = factoryId;
                        iTrackLiquorRepository.Update(trackLIQUID);
                        iTrackLiquorRepository.UnitOfWork.Commit();
                    }
                    break;
                default:
                    break;
            }
        }
        public static void UpdateTrackDealStatus(string trackType, string trackId, string dealStatus)
        {
            //浓缩液跟源项跟踪单 LIQUID
            ITrackLiquorRepository iTrackLiquorRepository = ServiceLocator.Current.GetInstance<ITrackLiquorRepository>();
            //废树脂跟源项跟踪单 RESIN
            INuclearTrackResinRepository iNuclearTrackResinRepository = ServiceLocator.Current.GetInstance<INuclearTrackResinRepository>();
            //废滤芯跟源项跟踪单 ELEMENT
            INuclearTrackElementRepository iNuclearTrackElementRepository = ServiceLocator.Current.GetInstance<INuclearTrackElementRepository>();
            //淤积物跟源项跟踪单 DEPOSIT
            INuclearTrackDepositRepository iNuclearTrackDepositRepository = ServiceLocator.Current.GetInstance<INuclearTrackDepositRepository>();
            //废油和溶剂源项跟踪单 SOLVENT
            INuclearTrackSolventRepository iNuclearTrackSolventRepository = ServiceLocator.Current.GetInstance<INuclearTrackSolventRepository>();
            //通风过滤器源项跟踪单 FILTER
            INuclearTrackFilterRepository iNuclearTrackFilterRepository = ServiceLocator.Current.GetInstance<INuclearTrackFilterRepository>();
            //技术废物(>2mSv/h)源项跟踪单 TECH1
            INuclearTrackTechBRepository iNuclearTrackTechBRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechBRepository>();
            //技术废物(<2mSv/h)源项跟踪单 TECH2
            INuclearTrackTechSRepository iNuclearTrackTechSRepository = ServiceLocator.Current.GetInstance<INuclearTrackTechSRepository>();
            //杂项源项跟踪单  SUNDRY
            INuclearTrackSundryRepository iNuclearTrackSundryRepository = ServiceLocator.Current.GetInstance<INuclearTrackSundryRepository>();
            switch (trackType)
            {
                case "SUNDRY":
                    var trackSUNDRY = iNuclearTrackSundryRepository.GetAll().Where(n => n.SundryId == trackId).FirstOrDefault();
                    if (trackSUNDRY != null)
                    {
                        trackSUNDRY.DealStatus = dealStatus;
                        iNuclearTrackSundryRepository.Update(trackSUNDRY);

                    }
                    break;
                case "TECH2":
                    var trackTECH2 = iNuclearTrackTechSRepository.GetAll().Where(n => n.TechSId == trackId).FirstOrDefault();
                    if (trackTECH2 != null)
                    {
                        trackTECH2.DealStatus = dealStatus;
                        iNuclearTrackTechSRepository.Update(trackTECH2);

                    }
                    break;
                case "TECH1":
                    var trackTECH1 = iNuclearTrackTechBRepository.GetAll().Where(n => n.TechBId == trackId).FirstOrDefault();
                    if (trackTECH1 != null)
                    {
                        trackTECH1.DealStatus = dealStatus;
                        iNuclearTrackTechBRepository.Update(trackTECH1);

                    }
                    break;
                case "FILTER":
                    var trackFILTER = iNuclearTrackFilterRepository.GetAll().Where(n => n.FilterId == trackId).FirstOrDefault();
                    if (trackFILTER != null)
                    {
                        trackFILTER.DealStatus = dealStatus;
                        iNuclearTrackFilterRepository.Update(trackFILTER);

                    }
                    break;
                case "SOLVENT":
                    var trackSOLVENT = iNuclearTrackSolventRepository.GetAll().Where(n => n.SolventId == trackId).FirstOrDefault();
                    if (trackSOLVENT != null)
                    {
                        trackSOLVENT.DealStatus = dealStatus;
                        iNuclearTrackSolventRepository.Update(trackSOLVENT);

                    }
                    break;
                case "DEPOSIT":
                    var trackDEPOSIT = iNuclearTrackDepositRepository.GetAll().Where(n => n.DepositId == trackId).FirstOrDefault();
                    if (trackDEPOSIT != null)
                    {
                        trackDEPOSIT.DealStatus = dealStatus;
                        iNuclearTrackDepositRepository.Update(trackDEPOSIT);

                    }
                    break;
                case "ELEMENT":
                    var trackELEMENT = iNuclearTrackElementRepository.GetAll().Where(n => n.ElementId == trackId).FirstOrDefault();
                    if (trackELEMENT != null)
                    {
                        trackELEMENT.DealStatus = dealStatus;
                        iNuclearTrackElementRepository.Update(trackELEMENT);
                    }
                    break;
                case "RESIN":
                    var trackRESIN = iNuclearTrackResinRepository.GetAll().Where(n => n.ResinId == trackId).FirstOrDefault();
                    if (trackRESIN != null)
                    {
                        trackRESIN.DealStatus = dealStatus;
                        iNuclearTrackResinRepository.Update(trackRESIN);
                    }
                    break;
                case "LIQUID":
                    var trackLIQUID = iTrackLiquorRepository.GetAll().Where(n => n.LiquorId == trackId).FirstOrDefault();
                    if (trackLIQUID != null)
                    {
                        trackLIQUID.DealStatus = dealStatus;
                        iTrackLiquorRepository.Update(trackLIQUID);
                    }
                    break;
                default:
                    break;
            }
        }
        public static string GetNameByCode(string code)
        {
            string name = string.Empty;
            switch (code)
            {
                case "MATERIAL":
                    name = "物质";
                    break;
                case "LIQUOR":
                    name = "浓缩液";
                    break;
                case "RESIN":
                    name = "废树脂";
                    break;
                case "ELEMENT":
                    name = "废滤芯";
                    break;
                case "DEPOSIT":
                    name = "淤积物";
                    break;
                case "SOLVENT":
                    name = "废油和溶剂";
                    break;
                case "FILTER":
                    name = "通风过滤器";
                    break;
                case "TECH1":
                    name = "技术废物1";
                    break;
                case "TECH2":
                    name = "技术废物2";
                    break;
                default:
                    break;
            }
            return name;
        }
    }
}