﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   TrackItemVM.cs
 *   描    述   ：   各类源项跟踪单
 *   创 建 者   ：   PXMWSWG[苏武刚]
 *   创建日期   ：   2016-10-3 
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-10-3              1.0.0.0    苏武刚       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.WasteTracking.ViewModels
{
    public class TrackItemVM
    {

       /// <summary>
       /// 类型
       /// </summary>
        public string TrackType { set; get; }

        /// <summary>
        /// 跟踪单ID 
        /// </summary>
        public string TrackId { set; get; }

        /// <summary>
        /// 废物跟踪单号
        /// </summary>
        public string TrackCode { set; get; }

        /// <summary>
        /// 厂房ID
        /// </summary>
        public string LocationId { set; get; }

        /// <summary>
        /// 系统编号
        /// </summary>
        public string SystemCode{ set; get; }

        /// <summary>
        /// 机组状态
        /// </summary>
        public string UnitStatus { set; get; }

        /// <summary>
        /// 大修轮次
        /// </summary>
        public string Cycle { set; get; }

        /// <summary>
        /// 确认日期
        /// </summary>
        public Nullable<DateTime> ConfirmDate { set; get; }

        /// <summary>
        /// 生效日期
        /// </summary>
        public Nullable<DateTime> ControlDate { set; get; }

        /// <summary>
        /// 电站ID
        /// </summary>
        public string StationId { get; set; }

        /// <summary>
        /// 处理状态 0：未处理 1：已处理
        /// </summary>
        public string DealStatus { get; set; }
    }
}