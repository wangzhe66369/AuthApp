﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Core.Common;

namespace RWIS.Presentation.Web.Areas.WasteTracking.ViewModels
{
    public class ImportTrackTechSErr
    {
        /// <summary>
        /// 编号
        /// </summary>
        [ExportAttribute(DisplayName = "单号", Order = 1)]
        public string TechSCode { get; set; }
        /// <summary>
        /// 电站
        /// </summary>
        [ExportAttribute(DisplayName = "电站", Order = 2)]
        public string StationId { get; set; }
        /// <summary>
        /// 大修
        /// </summary>
        [ExportAttribute(DisplayName = "大修Cycle", Order = 3)]
        public string RepairRound { get; set; }
        /// <summary>
        /// 金属桶编号
        /// </summary>
        [ExportAttribute(DisplayName = "208升金属桶编号", Order = 4)]
        public string BucketId { get; set; }
        /// <summary>
        /// 工作申请票号
        /// </summary>
        [ExportAttribute(DisplayName = "工作票号", Order = 5)]
        public string WorkTicket { get; set; }
        /// <summary>
        /// 废物描述
        /// </summary>
        [ExportAttribute(DisplayName = "废物描述", Order = 6)]
        public string Description { get; set; }
        /// <summary>
        /// 废物产生日期
        /// </summary>
        [ExportAttribute(DisplayName = "废物产生日期", Order = 7)]
        public Nullable<System.DateTime> ProductionDate { get; set; }
        /// <summary>
        /// 重量
        /// </summary>
        [ExportAttribute(DisplayName = "重量", Order = 8)]
        public Nullable<decimal> RubbishWeight { get; set; }
        /// <summary>
        /// 最大接触剂量率
        /// </summary>
        [ExportAttribute(DisplayName = "最大剂量率", Order = 9)]
        public Nullable<decimal> SurfaceDose { get; set; }
        /// <summary>
        /// 平均剂量率
        /// </summary>
        [ExportAttribute(DisplayName = "平均剂量率", Order = 10)]
        public Nullable<decimal> EvaDose { get; set; }
        /// <summary>
        /// 废物统计员名称
        /// </summary>
        [ExportAttribute(DisplayName = "统计员", Order = 11)]
        public string StatisticsName { get; set; }
        /// <summary>
        /// 废物统计日期
        /// </summary>
        [ExportAttribute(DisplayName = "统计日期", Order = 12)]
        public Nullable<System.DateTime> StatisticsDate { get; set; }
        /// <summary>
        /// 操作人名称
        /// </summary>
        [ExportAttribute(DisplayName = "操作员", Order = 13)]
        public string ControlName { get; set; }
        /// <summary>
        /// 操作日期
        /// </summary>
        [ExportAttribute(DisplayName = "操作日期", Order = 14)]
        public Nullable<System.DateTime> ControlDate { get; set; }
        /// <summary>
        /// 吸水材料 0：无  1：有
        /// </summary>
        [ExportAttribute(DisplayName = "是否吸水", Order = 15)]
        public string WaterMaterialFlag { get; set; }
        /// <summary>
        /// 吸水材料名称
        /// </summary>
        [ExportAttribute(DisplayName = "吸水材料", Order = 16)]
        public string WaterMaterialName { get; set; }
        /// <summary>
        /// 吸水材料重量
        /// </summary>
        [ExportAttribute(DisplayName = "材料重量", Order = 17)]
        public Nullable<decimal> WaterMaterialWeight { get; set; }
        /// <summary>
        /// 是否可压缩 0：否  1：是
        /// </summary>
        [ExportAttribute(DisplayName = "是否可压缩", Order = 18)]
        public string CompressFlag { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        [ExportAttribute(DisplayName = "备注", Order = 19)]
        public string Remark { get; set; }

        [ExportAttribute(DisplayName = "错误描述", Order = 20)]
        public string Error { get; set; }
    }
}