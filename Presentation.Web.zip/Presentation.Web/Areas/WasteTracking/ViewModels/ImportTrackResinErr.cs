﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Core.Common;

namespace RWIS.Presentation.Web.Areas.WasteTracking.ViewModels
{
    public class ImportTrackResinErr
    {
        [ExportAttribute(DisplayName = "跟踪单号", Order = 1)]
        public string ResinCode { get; set; }
        [ExportAttribute(DisplayName = "系统号", Order = 2)]
        public string SystemCode { get; set; }
        [ExportAttribute(DisplayName = "申请票号", Order = 3)]
        public string WorkTicket { get; set; }
        [ExportAttribute(DisplayName = "运行人员", Order = 4)]
        public string ProcessName { get; set; }
        [ExportAttribute(DisplayName = "运行日期", Order = 5)]
        public Nullable<System.DateTime> ProcessDate { get; set; }
        [ExportAttribute(DisplayName = "更换原因", Order = 6)]
        public string ChangeCause { get; set; }
        [ExportAttribute(DisplayName = "新树脂类型", Order = 7)]
        public string ResinVersionNew { get; set; }
        [ExportAttribute(DisplayName = "新树脂体积", Order = 8)]
        public Nullable<double> ResinBulkNew { get; set; }
        [ExportAttribute(DisplayName = "旧树脂类型", Order = 9)]
        public string ResinVersionOld { get; set; }
        [ExportAttribute(DisplayName = "旧树脂体积", Order = 10)]
        public Nullable<double> ResinBulkOld { get; set; }

        [ExportAttribute(DisplayName = "启动日期", Order = 11)]
        public Nullable<System.DateTime> SaltbedBeginDate { get; set; }

        [ExportAttribute(DisplayName = "停运日期", Order = 12)]
        public Nullable<System.DateTime> SaltbedStopDate { get; set; }
        [ExportAttribute(DisplayName = "化学人员", Order = 13)]
        public string ChemistryName { get; set; }
        [ExportAttribute(DisplayName = "化学日期", Order = 14)]
        public Nullable<System.DateTime> ChemistryDate { get; set; }

        [ExportAttribute(DisplayName = "机组包壳严重破损", Order = 15)]
        public string CladDamage { get; set; }
        [ExportAttribute(DisplayName = "事件单号", Order = 16)]
        public string EventNumber { get; set; }
        [ExportAttribute(DisplayName = "姓名", Order = 17)]
        public string SupportName { get; set; }
        [ExportAttribute(DisplayName = "日期", Order = 18)]
        public Nullable<System.DateTime> SupportDate { get; set; }

        [ExportAttribute(DisplayName = "有无放射性", Order = 19)]
        public string RadioactionFlag { get; set; }
        [ExportAttribute(DisplayName = "剂量率", Order = 20)]
        public Nullable<decimal> RadioactionValue { get; set; }
        [ExportAttribute(DisplayName = "仪表型号", Order = 21)]
        public string MeterVersion { get; set; }
        [ExportAttribute(DisplayName = "测量人员", Order = 22)]
        public string MeasureName { get; set; }
        [ExportAttribute(DisplayName = "测量日期", Order = 23)]
        public Nullable<System.DateTime> MeasureDate { get; set; }
        [ExportAttribute(DisplayName = "传送方向", Order = 24)]
        public string Trans { get; set; }
        [ExportAttribute(DisplayName = "操作人", Order = 25)]
        public string ControlName { get; set; }
        [ExportAttribute(DisplayName = "操作日期", Order = 26)]
        public Nullable<System.DateTime> ControlDate { get; set; }
        [ExportAttribute(DisplayName = "错误描述", Order = 27)]
        public string Error { get; set; }
    }
}