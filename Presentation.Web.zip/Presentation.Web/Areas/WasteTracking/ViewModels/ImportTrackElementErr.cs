﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Core.Common;

namespace RWIS.Presentation.Web.Areas.WasteTracking.ViewModels
{
    public class ImportTrackElementErr
    {
        /// <summary>
        /// 编号
        /// </summary>
        [ExportAttribute(DisplayName = "跟踪单号", Order = 1)]
        public string ElementCode { get; set; }
        /// <summary>
        /// 系统号 
        /// </summary>
        [ExportAttribute(DisplayName = "系统号", Order = 2)]
        public string SystemCode { get; set; }
        /// <summary>
        /// 工作申请票号
        /// </summary>
        [ExportAttribute(DisplayName = "申请票号", Order = 3)]
        public string WorkTicket { get; set; }
        /// <summary>
        /// 过滤器停运日期
        /// </summary>
        [ExportAttribute(DisplayName = "停运日期", Order = 4)]
        public Nullable<System.DateTime> FilterStopDate { get; set; }
        /// <summary>
        /// 滤芯表面接触剂量率
        /// </summary>
        [ExportAttribute(DisplayName = "表面剂量率", Order = 5)]
        public Nullable<decimal> SurfaceTouch { get; set; }
        /// <summary>
        /// 新滤芯规格型号
        /// </summary>
        [ExportAttribute(DisplayName = "新过滤器类型", Order = 6)]
        public string ElementVersionNew { get; set; }
        /// <summary>
        /// 旧滤芯规格型号
        /// </summary>
        [ExportAttribute(DisplayName = "旧过滤器类型", Order = 7)]
        public string ElementVersionOld { get; set; }
       
        /// <summary>
        /// 备注
        /// </summary>
        [ExportAttribute(DisplayName = "备注", Order = 8)]
        public string Remark { get; set; }
        [ExportAttribute(DisplayName = "错误描述", Order = 9)]
        public string Error { get; set; }


    }
}