﻿/********************************************************************************
 *
 *   项目名称   ：   废物管理
 *   文 件 名   ：   WasteTrackingVM.cs
 *   描    述   ：   废物跟踪单VM
 *   创 建 者   ：   PXMWAHY
 *   创建日期   ：   2016-01-08 11:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-01-08 11:00:00    1.0.0.0    PXMWAHY       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;
using System;

namespace RWIS.Presentation.Web.Areas.WasteTracking.ViewModels
{
    /// <summary>
    /// 废物跟踪单VM
    /// </summary>
    public class WasteTrackingVM
    {
        /// <summary>
        /// 浓缩液实体
        /// </summary>
        public TrackLiquor TrackLiquor { get; set; }

        /// <summary>
        /// 废树脂实体
        /// </summary>
        public NuclearTrackResin NuclearTrackResin { get; set; }

        /// <summary>
        /// 废滤芯实体
        /// </summary>
        public NuclearTrackElement NuclearTrackElement { get; set; }

        /// <summary>
        /// 淤积物实体
        /// </summary>
        public NuclearTrackDeposit NuclearTrackDeposit { get; set; }

        /// <summary>
        /// 废油和溶剂实体
        /// </summary>
        public NuclearTrackSolvent NuclearTrackSolvent { get; set; }

        /// <summary>
        /// 通风过滤器列表
        /// </summary>
        public NuclearTrackFilter NuclearTrackFilter { get; set; }

        /// <summary>
        /// 技术废物(>2mSv/h)
        /// </summary>
        public NuclearTrackTechB NuclearTrackTechB { get; set; }

        /// <summary>
        /// 技术废物(<2mSv/h)
        /// </summary>
        public NuclearTrackTechS NuclearTrackTechS { get; set; }
        /// <summary>
        /// 技术废物备份(<2mSv/h)
        /// </summary>
        public NuclearTrackTechSDraft NuclearTrackTechSDraft { get; set; }

        /// <summary>
        /// 杂项
        /// </summary>
        public NuclearTrackSundry NuclearTrackSundry { get; set; }

        /// <summary>
        /// 去污申请单列表
        /// </summary>
        public NuclearTrackDecon NuclearTrackDecon { get; set; }

        /// <summary>
        /// 核素分析单列表
        /// </summary>
        public NuclearNuclide NuclearNuclide { get; set; }

        /// <summary>
        /// 核素分析单样品
        /// </summary>
        public List<NuclearNuclideSample> NuclearNuclideSampleList { get; set; }

        /// <summary>
        /// 核素明细
        /// </summary>
        public List<NuclearSampleDetail> NuclearSampleDetailList { get; set; }

        /// <summary>
        /// 活度计算标准库
        /// </summary>
        public SupportEds SupportEds { get; set; }

        /// <summary>
        /// 设备信息实体
        /// </summary>
        public EquipInfo EquipInfo { get; set; }

        /// <summary>
        /// 设备明细实体
        /// </summary>
        public EquipDetail EquipDetail { get; set; }

        /// <summary>
        /// 工作类型
        /// </summary>
        public List<SelectListItem> WorkTypeList { get; set; }

        /// <summary>
        /// 传送类型
        /// </summary>
        public List<SelectListItem> TransTypeList { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        public List<SelectListItem> StatusList { get; set; }

        /// <summary>
        /// 电站
        /// </summary>
        public List<SelectListItem> StationCodeList { get; set; }

        /// <summary>
        /// 暂存位置
        /// </summary>
        public List<SelectListItem> StoragePositionIdList { get; set; }
        /// <summary>
        /// 处理状态
        /// </summary>
        public List<SelectListItem> DealStatusList { get; set; }
        /// <summary>
        /// 机组状态
        /// </summary>
        public List<SelectListItem> RodiodList { get; set; }

        /// <summary>
        /// 放射性
        /// </summary>
        public List<SelectListItem> FilterFlagYesList { get; set; }

        /// <summary>
        /// 非放射性
        /// </summary>
        public List<SelectListItem> FilterFlagNoList { get; set; }

        /// <summary>
        /// 传送
        /// </summary>
        public List<SelectListItem> TransList { get; set; }

        /// <summary>
        /// 暂存厂房
        /// </summary>
        public List<SelectListItem> FactoryList { get; set; }

        /// <summary>
        /// 暂存铅容器
        /// </summary>
        public List<SelectListItem> LeadContainerList { get; set; }

        /// <summary>
        /// 暂存包装容器
        /// </summary>
        public List<SelectListItem> PackContainerList { get; set; }

        /// <summary>
        /// 装入包装容器
        /// </summary>
        public List<SelectListItem> InputPackContainerList { get; set; }

        /// <summary>
        /// 更换原因
        /// </summary>
        public List<SelectListItem> ChangeFlagList { get; set; }

        /// <summary>
        /// 比活度低于阀值
        /// </summary>
        public List<SelectListItem> SpecificActivityFlagList { get; set; }

        /// <summary>
        /// 是否取样
        /// </summary>
        public List<SelectListItem> SamplingFlagList { get; set; }

        /// <summary>
        /// 是否放射性
        /// </summary>
        public List<SelectListItem> RadioActionFlagList { get; set; }

        /// <summary>
        /// 处理方式
        /// </summary>
        public List<SelectListItem> ProcessModeFlagList { get; set; }

        /// <summary>
        /// 是否吸入新鲜空气
        /// </summary>
        public List<SelectListItem> ClearAirFlagList { get; set; }

        /// <summary>
        /// 过滤器类型
        /// </summary>
        public List<SelectListItem> FilterTypeList { get; set; }

        /// <summary>
        /// 类型 0：受中子辐射被活化（源于堆芯）1：受沾污
        /// </summary>
        public List<SelectListItem> TypeFlagList { get; set; }

        /// <summary>
        /// 废物种类 0：其他 1：纸制品 2：棉织品 3：塑料制品 4：木头
        /// </summary>
        public List<SelectListItem> RubbishKindList { get; set; }
        /// <summary>
        /// 废物种类 0：其他 1：金属 2：湿废物 
        /// </summary>
        public List<SelectListItem> RubbishKindsList { get; set; }

        ///// <summary>
        ///// 废物种类 0：其他 1：金属 2：湿废物
        ///// </summary>
        //public List<SelectListItem> RubbishKindsList { get; set; }

        /// <summary>
        /// 是否可焚烧 0：否 1：是
        /// </summary>
        public List<SelectListItem> BurnFlagList { get; set; }

        /// <summary>
        /// 是否可压缩 0：否 1：是
        /// </summary>
        public List<SelectListItem> CompressFlagList { get; set; }

        /// <summary>
        /// 吸水材料 0：无 1：有
        /// </summary>
        public List<SelectListItem> WaterMaterialFlagList { get; set; }

        /// <summary>
        /// 废物类型(LowLevelL:极低放废物ScrapSteel:废钢铁 Labor：劳保用品 Other:其他)
        /// </summary>
        public List<SelectListItem> WasteTypeList { get; set; }

        /// <summary>
        /// 是否要拆解 0：否 1：是
        /// </summary>
        public List<SelectListItem> DismantleFlagList { get; set; }

        /// <summary>
        /// 是否要冶炼 0：否 1：是
        /// </summary>
        public List<SelectListItem> SmeltFlagList { get; set; }

        /// <summary>
        /// 沾污 0：无 1：有
        /// </summary>
        public List<SelectListItem> SullyFlagList { get; set; }

        /// <summary>
        /// 质量安全 0：QSR 1：QR 2：NQR
        /// </summary>
        public List<SelectListItem> QualityFlagList { get; set; }

        /// <summary>
        /// 污染时温度 1：高于200℃ 0：低于200℃
        /// </summary>
        public List<SelectListItem> PolluteTempFlagList { get; set; }

        /// <summary>
        /// 去污后去向 0：控制区内重新使用 1：控制区外重新使用 2:出厂区
        /// </summary>
        public List<SelectListItem> DeconAfterFlagList { get; set; }

        /// <summary>
        /// 去污时需拆卸 0：否 1：是
        /// </summary>
        public List<SelectListItem> DismountFlagList { get; set; }

        /// <summary>
        /// 废物类型
        /// </summary>
        public List<SelectListItem> NuClearTypeList { get; set; }
        /// <summary>
        /// 废物名称
        /// </summary>
        public string WasteTypeName { get; set; }
        /// <summary>
        /// 电站名称
        /// </summary>
        public string StationCodeName { get; set; }

        /// <summary>
        /// 暂存位置名称
        /// </summary>
        public string StoragePositionName { get; set; }
        /// <summary>
        /// 存储位置名称
        /// </summary>
        public string StoragePosition { get; set; }
        /// <summary>
        /// 暂存铅容器ID名称
        /// </summary>
        public string StorageContainerName { get; set; }

        /// <summary>
        /// 谱类型 
        /// </summary>
        public List<SelectListItem> EdsTypeList { get; set; }
        //倒空
        public List<SelectListItem> IsEmpty { get; set; }

        //当前页面所有操作
        public string OperationList { get; set; }

        public decimal OldVoulumn { get; set; }

        public decimal OldBulk { get; set; }

        public string LiquorCode { get; set; }

        public string NewStoragePositionId { get; set; }
        public string TrackCode { get; set; }
        public string Status { get; set; }
        public string NewIsEmpty { get; set; }
        public string NewSavePosition { get; set; }
        public string BucketId { get; set; }
    }

    public class ElementDetail
    {
        public string Id { set; get; }
        public string Value { set; get; }
        public string BucketCode { set; get; }
    }

    public class NuclearElementDetail
    {
        //public string SampleNum { set; get; }
        //public string StrSamplingDate { set; get; }
        public string Name { set; get; }
        public Nullable<decimal> Value { set; get; }

    }

    public class TempWasteTrackInfo
    {
        /// <summary>
        /// 源项主键ID
        /// </summary>
        public string WasteId { get; set; }
        /// <summary>
        /// 跟踪单号
        /// </summary>
        public string WasteCode { get; set; }
        /// <summary>
        /// 系统号
        /// </summary>
        public string SystemCode { get; set; }
        /// <summary>
        /// 申请票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 操作人
        /// </summary>
        public string ControlName { get; set; }
        /// <summary>
        /// 操作时间
        /// </summary>
        public string ControlDate { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
    public class TempWasteTrackCondition
    {
        public string Factory { get; set; }

        public string Type { get; set; }
    }
}