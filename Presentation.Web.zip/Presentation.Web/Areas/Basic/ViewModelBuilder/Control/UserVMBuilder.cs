﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.ViewModels;
using NET01.Infrastructure.ORG;

namespace RWIS.Presentation.Web.ViewModelBuilder
{
    public class UserVMBuilder
    {
        /// <summary>
        /// 获取用户查询结果
        /// </summary>
        public static UserVM UserVMBuilderList(IOrganizationRepository repository,string keyword, int listNum)
        {
            var userVM = new UserVM
                             {
                                 DeptList = new List<object>(),
                                 ListNum = listNum <= 0 ? 100 : listNum,
                                 RList = new SelectList(new ListDictionary(), "Code", "Name"),
                                 UserList = new List<object>(),
                                 Action = "Search",
                                 Controller = "User",
                                 ChooseNum=1
                             };


             var users= repository.SearchStaff(keyword, listNum <= 0 ? 100 : listNum);
             var items = from item in users
                         select new
                         {
                             Code = item.StaffNo,
                             Name = item.Organzations.Count() == 0 ? item.Name :
                              item.Name + "(" + item.Organzations.LastOrDefault().Name + ")"
                         };
      
            userVM.LList = new SelectList(items, "Code", "Name");
            return userVM;
        }
    }
}