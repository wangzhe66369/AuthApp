﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using RWIS.Domain.Repositories;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.ViewModels;
using NET01.Infrastructure.ORG;
namespace RWIS.Presentation.Web.ViewModelBuilder
{
    public class TreeVMBuilder
    {
        /// <summary>
        /// 获取部门TreeList
        /// </summary>
        public static List<JsonTreeNode> GetOrgTreeList(IOrganizationRepository repository, string orgId, byte state,bool inCludeSelf)
        {
            List<Organization> list = new List<Organization>();
            Organization org= repository.GetOrganization(orgId);
            if (org!=null)
            {
                list.Add(org);
            }
            if(inCludeSelf)
            {
                return BuildTreeNode(list, state);
            }
            return BuildTreeChildNode(list, state);  
        }

        /// <summary>
        /// 建造Tree节点
        /// </summary>
        private static List<JsonTreeNode> BuildTreeNode(List<Organization> list, byte state)
        {
            return list.ConvertAll(x => new JsonTreeNode
            {
                id = x.OrganziationNo,
                text = x.Name,
                value = x.OrganziationNo,
                showcheck = true,
                isexpand = true,
                checkstate = state,
                hasChildren = x.Children != null,
                ChildNodes = x.Children != null ? x.Children.ToList().ConvertAll(y =>
                new JsonTreeNode()
                {
                    id = y.OrganziationNo,
                    text = y.Name,
                    value = y.OrganziationNo,
                    showcheck = true,
                    isexpand = false,
                    checkstate = state,
                    hasChildren = y.Children != null
                }) : null
            });
        }

        /// <summary>
        /// 建造Tree节点包含子节点
        /// </summary>
        private static List<JsonTreeNode> BuildTreeChildNode(List<Organization> list, byte state)
        {
            if (list != null && (list).Count>0)
            {
                return list[0].Children.ToList().ConvertAll(x => new JsonTreeNode
                {
                    id = x.OrganziationNo,
                    text = x.Name,
                    value = x.OrganziationNo,
                    showcheck = true,
                    isexpand = false,
                    checkstate = state,
                    hasChildren = x.Children != null
                });
            }
            return null;
        }
    }
}