﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcContrib.UI.Grid;
using System.Web.Mvc;
using RWIS.Presentation.Web.ViewModels;
using RWIS.Presentation.Web.Core;
using NET01.Infrastructure.Workflow;
using RWIS.Infrastructure.Crosscutting;
using MvcContrib.Sorting;
using NET01.CoreFramework;
using NET01.Presentation.Web.Mvc.JqGrid;
using Microsoft.Practices.ServiceLocation;

namespace RWIS.Presentation.Web.ViewModelBuilder
{
    public class WorkflowTaskVMBuilder
    {

        /// <summary>
        /// 创建待办Json
        /// </summary>
        public static JsonResult BuildProcessingWorkflowTaskJson(
            string taskName, string createName, string instanceType, string currentStep,
            IWorkflowRepository wfRpository,
            string sidx, string sord, int page, int rows
            )
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows };
            IList<ApprovalInstance> data = wfRpository.GetProcessingApprovalInstanceList(AppContext.CurrentUser.UserId,
                AppSetting.Instance.SystemCode, "", taskName ?? String.Empty,
                System.DateTime.MinValue);
            if (!string.IsNullOrEmpty(createName))
            {
                data = data.Where(m => m.CreateUser.Contains(createName.ToUpper()) ||
                    m.CreateUserName.Contains(createName.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(instanceType))
            {
                data = data.Where(m => m.WorkflowDefinition.DisplayName.Contains(instanceType.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(currentStep))
            {
                data = data.Where(m => m.CurrentStateName.Contains(currentStep.ToUpper())).ToList();
            }
            jqGridResponse.TotalRecordsCount = data.Count();
            var pagedViewModel = new PagedViewModel<ApprovalInstance>
            {
                Query = data.AsQueryable(),
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
           .Setup();
            pagedViewModel.PagedList.ToList().ForEach(p => BuildListJson(jqGridResponse, p));

            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 构建网格Json
        /// </summary>
        /// <param name="reportRepository"></param>
        /// <param name="jqGridResponse"></param>
        /// <param name="p"></param>
        private static void BuildListJson(JqGridResponse jqGridResponse, ApprovalInstance p)
        {
            if (p.WorkflowDefinition != null)
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = p.InstanceId,
                    List = new List<object>()
                        {
                            p.InstanceId,
                            p.InstanceType.ToString().Substring(p.InstanceType.LastIndexOf(".") + 1),
                            String.IsNullOrEmpty(p.CurrentState) ? "000" : p.CurrentState,
                            p.WorkflowName,
                            p.InstanceName,
                            null,
                            null,
                            p.WorkflowDefinition.DisplayName,
                            p.CreateUserName,
                            p.CreateDate.ToShortDateString(),
                            p.WorkflowDefinition.GetState(String.IsNullOrEmpty(p.CurrentState) ? "000" : p.CurrentState).DisplayName
                        }
                });
            }

        }
        /// <summary>
        /// 创建已办Json
        /// </summary>
        public static JsonResult BuildProcessedWorkflowTaskJson(
            string taskName, string createName, string instanceType, string currentStep,
            IWorkflowRepository wfRpository,
            string sidx, string sord, int page, int rows
            )
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows };
            IList<ApprovalInstance> data = wfRpository.GetDoneApprovalInstanceList(AppContext.CurrentUser.UserId,
                AppSetting.Instance.SystemCode, "", taskName ?? String.Empty,
                System.DateTime.MinValue);
            if (!string.IsNullOrEmpty(createName))
            {
                data = data.Where(m => m.CreateUser.Contains(createName.ToUpper()) ||
                    m.CreateUserName.Contains(createName.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(instanceType))
            {
                data = data.Where(m => m.WorkflowDefinition.DisplayName.Contains(instanceType.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(currentStep))
            {
                data = data.Where(m => m.CurrentStateName.Contains(currentStep.ToUpper())).ToList();
            }
            jqGridResponse.TotalRecordsCount = data.Count();
            var pagedViewModel = new PagedViewModel<ApprovalInstance>
            {
                Query = data.AsQueryable(),
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
           .Setup();
            pagedViewModel.PagedList.ToList().ForEach(p => BuildProcessedListJson(jqGridResponse, p));

            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 构建网格Json
        /// </summary>
        /// <param name="reportRepository"></param>
        /// <param name="jqGridResponse"></param>
        /// <param name="p"></param>
        private static void BuildProcessedListJson(JqGridResponse jqGridResponse, ApprovalInstance p)
        {

            if (p.WorkflowDefinition != null)
            {
                var record = new JqGridRecord()
                {
                    Id = p.InstanceId,
                    List = new List<object>()
                        {
                            p.InstanceId, 
                            p.InstanceType.ToString().Substring(p.InstanceType.LastIndexOf(".") + 1),
                            p.WorkflowDefinition.GetState("999").Controller+"/"+p.WorkflowDefinition.GetState("999").Action,
                            p.InstanceName,
                            null,
                            null,
                            p.WorkflowDefinition.DisplayName,
                            p.CreateUserName,
                            p.CreateDate.ToShortDateString(),
                            p.WorkflowDefinition.GetState(String.IsNullOrEmpty(p.CurrentState) ? "000" : p.CurrentState).DisplayName
                        }
                };
                jqGridResponse.Records.Add(record);

            }
            else
            {
                var record = new JqGridRecord()
                {
                    Id = p.InstanceId,
                    List = new List<object>()
                        {
                            p.InstanceId, 
                            p.InstanceType.ToString().Substring(p.InstanceType.LastIndexOf(".") + 1),
                           null,
                            p.InstanceName,
                            null,
                            null,
                            null,
                            p.CreateUserName,
                            p.CreateDate.ToShortDateString(),
                            null
                        }
                };
                jqGridResponse.Records.Add(record);

            }

        }
        /// <summary>
        /// 创建流程日志Json
        /// </summary>
        public static JsonResult BuildWorkflowLogJson(
            string instanceId,
            string sidx, string sord, int page, int rows
            )
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows };
            IList<ApprovalStep> data = ServiceLocator.Current.GetInstance<IWorkflowRuntime>()
                .GetService<IWorkflowRepository>().GetApprovalStepList(instanceId);
            jqGridResponse.TotalRecordsCount = data.Count();
            var pagedViewModel = new PagedViewModel<ApprovalStep>
            {
                Query = data.AsQueryable(),
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
           .Setup();
            pagedViewModel.PagedList.ToList().ForEach(p => BuildWorkflowLogListJson(jqGridResponse, p));

            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 构建网格Json
        /// </summary>
        /// <param name="reportRepository"></param>
        /// <param name="jqGridResponse"></param>
        /// <param name="p"></param>
        private static void BuildWorkflowLogListJson(JqGridResponse jqGridResponse, ApprovalStep p)
        {
            if (p != null)
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = p.SetpId,
                    List = new List<object>()
                        {
                            p.SetpId,
                            p.PrevStateName,
                            p.ProcessRemark,
                            p.ProcessUserName,
                            p.ProcessDate.Value.ToString("yyyy-MM-dd")
                        }
                });
            }

        }
    }
}