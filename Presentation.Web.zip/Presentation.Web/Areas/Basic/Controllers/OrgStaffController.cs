﻿using RWIS.Application.Interface;
using Microsoft.Practices.ServiceLocation;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.Basic.Controllers
{
    public class OrgStaffController : CommonControllerBase
    {
        /// <summary>
        /// 根据关键字获取人员机构信息
        /// </summary>
        /// <returns></returns>
        public string GetStaffOrg()
        {
            string result = string.Empty;

            try
            {
                string jsoncallback = HttpContext.Request["callback"];
                string key = HttpContext.Request["keyWord"] ?? string.Empty;
                string wholeMate = HttpContext.Request["wholeMate"];
                string orgId = HttpContext.Request["OrgId"] ?? string.Empty;
                //已选人员工号
                string selectedId = HttpContext.Request["selectedId"] ?? string.Empty;
                string topCountStr = HttpContext.Request["topCount"];

                bool isWholeMate = false;

                bool.TryParse(wholeMate, out isWholeMate);

                key = HttpUtility.UrlDecode(key, System.Text.Encoding.UTF8);

                key = key.ToUpper();

                int topCount = 0;
                bool countFlag = int.TryParse(topCountStr, out topCount);
                if (!countFlag)
                {
                    //默认取前10条数据
                    topCount = 20;
                }
                topCount = topCount > 100 ? 100 : topCount;



                //人员机构基础服务
                IOrgStaffAppService orgStaffAppService = ServiceLocator.Current.GetInstance<IOrgStaffAppService>();

                List<StaffOrg> list = orgStaffAppService.GetStaffListByKey(key, isWholeMate, orgId, topCount);
                List<StaffOrg> selectedList = orgStaffAppService.GetSelectedStaffList(selectedId, orgId);

                result = string.Format("{0}({{data:{1},selectedPerson:{2}}});", jsoncallback, JsonConvert.SerializeObject(list), JsonConvert.SerializeObject(selectedList));

            }
            catch (Exception ex)
            {
                result = ex.ToString();
                this.Log.LogError(ex);
            }
            return result;
        }

    }
}
