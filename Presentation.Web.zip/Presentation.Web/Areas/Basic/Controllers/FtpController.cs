﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   FtpController.cs
 *   描    述   ：   Ftp Controller
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.Core.Ftp;
using System.IO;
using RWIS.Domain.Repositories;
using NET01.Presentation.Web.Mvc.JqGrid;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using NET01.Infrastructure.BasicData.Services;
using RWIS.Presentation.Web.Core;
using CIT.UPC.Domain.Repositories;

namespace RWIS.Presentation.Web.Areas.Basic.Controllers
{
    /// <summary>
    /// FTP控制器
    /// </summary>
    public class FtpController : CommonControllerBase
    {
        public FtpController() { }

        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], formCollection["BusinessType"]);
            }
            return null;
        }

        /// <summary>
        /// 下载文件
        /// </summary>
        /// <param name="fileId">文件唯一编号</param>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }

        /// <summary>
        /// 删除附件
        /// </summary>
        /// <param name="fileId">文件唯一编号</param>
        /// <returns></returns>
        [AcceptVerbs(HttpVerbs.Post)]
        public bool DeleteFile(string fileId, string fileName, string businessType)
        {
            bool bResult;

            try
            {
                IAttachFileRepository AttachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                AttachFileRepository.DeleteById(fileId);
                AttachFileRepository.UnitOfWork.Commit();
                bResult = true;
            }
            catch (Exception)
            {
                bResult = false;
            }
            try
            {
                string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
                FtpFileStore.DeleteFile(fileId + "." + fileTypeStr, businessType);
            }
            catch (Exception)
            {
                bResult = true;
            }
            return bResult;
        }

        /// <summary>
        /// 附件列表
        /// </summary>
        /// <param name="busineessId">业务编号</param>
        /// <param name="businessType">业务类型</param>
        /// <returns></returns>
        //[HttpGet]
        [OutputCache(Duration = 0, VaryByParam = "none")]
        public ActionResult GetAttachListJson(string businessId, string businessType)
        {
            try
            {
                AttachFileService attachFileService = new AttachFileService();
                AttachFile[] attachFiles = attachFileService.GetByBusinessTypeAndId(businessType, businessId);

                var jqGridResponse = new JqGridResponse { JsonRequestBehavior = JsonRequestBehavior.AllowGet };

                attachFiles.ToList().ForEach(p =>
                {
                    jqGridResponse.Records.Add(new JqGridRecord()
                    {
                        Id = p.FileId,
                        List = new List<object>()
                    {
                        p.FileId,
                        p.BusinessType,
                        p.FileName,
                        p.CreateDate.ToString("yyyy-MM-dd HH:mm:ss"),
                        Convert.ToDecimal( p.FileLength/1024).ToString()
                    }
                    });
                });

                return jqGridResponse.ToJsonResult();
            }
            catch (Exception ex)
            {
                this.Log.LogError(ex);
                return Json(ex);
            }
        }

        /// <summary>
        /// 检查文件是否存在
        /// </summary>
        /// <param name="fileId">文件唯一编号</param>
        /// <returns></returns>
        [HttpGet]
        public JsonResult CheckFileIsExists(string fileId)
        {
            try
            {
                AttachFileService attachFileService = new AttachFileService();
                AttachFile attachFile = attachFileService.Get(fileId);
                bool bResult = FtpFileStore.IsExistsFile(attachFile.FileId + "." + attachFile.FileType, attachFile.BusinessType);
                return Json(bResult, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                this.Log.LogError(ex);
                return Json(ex.Message);
            }
        }
    }
}
