﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   UserController.cs
 *   描    述   ：  
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.Pagination;
using RWIS.Domain.Repositories;
using NET01.Infrastructure.ORG;
using RWIS.Presentation.Web.ViewModels;

namespace RWIS.Presentation.Web.Areas.Basic.Controllers
{
    public class OrganziationController : Controller
    {
        public IOrganizationRepository OrganizationRepository { get; set; }

        public OrganziationController(IOrganizationRepository orgRepository)
        {
            this.OrganizationRepository = orgRepository;
        }

        /// <summary>
        /// 查询
        /// </summary>
        [HttpPost]
        public ActionResult SearchUser(string keyword)
        {
            var vm = ViewModelBuilder.UserVMBuilder.UserVMBuilderList(this.OrganizationRepository, keyword, 100);
            return Json(vm, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 初始化组织机构数据
        /// </summary>
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult InitOrg(FormCollection form)
        {
            return GetOrg(form, true);
        }
        /// <summary>
        /// 获取子节点
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        [AcceptVerbs(HttpVerbs.Post)]
        public JsonResult GetOrgChild(FormCollection form)
        {
            return GetOrg(form, false);
        }

        /// <summary>
        /// 获取组织机构数据
        /// </summary>
        /// <param name="form">页面集合</param>
        /// <param name="includeSelf">是否包含自己</param>
        private JsonResult GetOrg(FormCollection form, bool includeSelf)
        {
            string id = form["id"] ?? "00000000";
            byte state = Convert.ToByte(form["checkstate"]);
            var list = ViewModelBuilder.TreeVMBuilder.GetOrgTreeList(this.OrganizationRepository, id, state, includeSelf);
            return Json(list, JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        ///获取机构编码获取机构/部门
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GetSingleOrgByOrgNo(FormCollection form)
        {
            var org = OrganizationRepository.GetOrganization(form["orgno"]);
            return Json(org, JsonRequestBehavior.AllowGet);
        }
    }
}
