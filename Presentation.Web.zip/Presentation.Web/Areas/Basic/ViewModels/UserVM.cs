﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.ViewModels
{
    public class UserVM
    {
        /// <summary>
        /// 查询关键字
        /// </summary>
        public string Keyword { get; set; }

        /// <summary>
        /// 用户列表
        /// </summary>
        public IList<object> UserList { get; set; }

        /// <summary>
        /// 显示记录数
        /// </summary>
        public int ListNum { get; set; }

        /// <summary>
        /// 左边集合
        /// </summary>
        public SelectList LList { get; set; }

        /// <summary>
        /// 右边集合
        /// </summary>
        public SelectList RList { get; set; }

        /// <summary>
        /// 部门集合
        /// </summary>
        public IList<object> DeptList { get; set; }

        /// <summary>
        /// 行为
        /// </summary>
        public string Action { get; set; }
        /// <summary>
        /// 控制
        /// </summary>
        public string Controller { get; set; }

        /// <summary>
        /// 是否选择多个
        /// </summary>
        public int ChooseNum { get; set; }
    }
}