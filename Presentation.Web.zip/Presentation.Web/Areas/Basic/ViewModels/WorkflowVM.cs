﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.Basic.ViewModels
{
    public class WorkflowVM
    {
        /// <summary>
        /// 流程实例ID
        /// </summary>
        public string InstanceId { get; set; }
        /// <summary>
        /// DIV-ID
        /// </summary>
        public string DivId { get; set; }
        /// <summary>
        /// 网格宽度 
        /// </summary>
        public long? GridWidth { get; set; }
    }
}