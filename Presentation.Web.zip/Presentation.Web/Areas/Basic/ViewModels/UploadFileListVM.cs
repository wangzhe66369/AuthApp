﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using NET01.Infrastructure.BasicData.Services;
namespace RWIS.Presentation.Web.ViewModels.Common
{
    public class UploadFileListVM
    {
        public UploadFileListVM()
        {
            this.EnableDownLoad = true;
            this.EnableDelete = false;

        }
        /// <summary>
        /// 是否可以下载
        /// </summary>
        public bool EnableDownLoad { get; set; }
        /// <summary>
        /// 是否可以删除
        /// </summary>
        public bool EnableDelete { get; set; }
        /// <summary>
        /// 业务ID
        /// </summary>
        public string BusinessId { get; set; }
        /// <summary>
        /// 附件类型
        /// </summary>
        public string BusinessType { get; set; }
        /// <summary>
        /// DIV-ID
        /// </summary>
        public string DivId { get; set; }
        /// <summary>
        /// 文件最大值
        /// </summary>
        public long? FileMaxSize { get; set; }
        /// <summary>
        /// 网格样式
        /// </summary>
        public string GridStyle { get; set; }
        /// <summary>
        /// 是否可以新增
        /// </summary>
        public bool EnableAdd { get; set; }
        /// <summary>
        /// 禁用按钮
        /// </summary>
        public string DisableDuringUpload { get; set; }
        /// <summary>
        /// 是否提交到数据库
        /// </summary>
        public bool IsSubmit { get; set; }
        /// <summary>
        /// 是否弹出框
        /// </summary>
        public bool IsDialog { get; set; }

        public IEnumerable<CIT.UPC.Domain.DomainObjects.AttachFile> FileList { get; set; }
    }
}