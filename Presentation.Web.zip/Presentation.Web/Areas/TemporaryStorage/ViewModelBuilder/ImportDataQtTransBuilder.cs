﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using NET01.CoreFramework;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels;
using CIT.Common.Common;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Core.Common;
using System.IO;
using NPOI.HSSF.UserModel;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModelBuilder
{
    public class ImportQtTransDataBuilder
    {
        #region 导入封盖数据
        #region 添加数据

        /// <summary>
        /// 创建封盖数据
        /// </summary>
        /// <param name="bucketCoverVM"></param>
        /// <returns></returns>
        public static string InsertQtTransData(TransportVM transportVM, INuclearQtTransRepository nuclearQtTransRepository)
        {
            INuclearQtTransDetailRepository iNuclearQtTransDetailRepository = ServiceLocator.Current.GetInstance<INuclearQtTransDetailRepository>();
            INuclearQtTransDetailBRepository iNuclearQtTransDetailBRepository = ServiceLocator.Current.GetInstance<INuclearQtTransDetailBRepository>();
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            INuclearWastePackageRepository iNuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
            try
            {
                transportVM.TransModel.QtTransId = Guid.NewGuid().ToString();
                transportVM.TransModel.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                transportVM.TransModel.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                transportVM.TransModel.CreateDate = DateTime.Now.Date;//创建时间
                transportVM.TransModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                transportVM.TransModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                transportVM.TransModel.ConfirmDate = DateTime.Now;
                transportVM.TransModel.Stationcode = AppContext.CurrentUser.ProjectCode;
                var bucketModel = iNuclearBucketRepository.GetBucketInfoModel(transportVM.TransModel.BucketId);
                if (bucketModel != null)
                {
                    bucketModel.XPosition = transportVM.TransModel.QtPositionX;
                    bucketModel.YPosition = transportVM.TransModel.QtPositionY;
                    bucketModel.ZPosition = transportVM.TransModel.QtPositionZ;
                    iNuclearBucketRepository.Update(bucketModel);
                }
                string bucketCode = null;
                NuclearBucket nuclearBucket = iNuclearBucketRepository.Get(transportVM.TransModel.BucketId);
                if (nuclearBucket != null)
                {
                   bucketCode = nuclearBucket.BucketCode;
                }
                string packageCode = iNuclearWastePackageRepository.GetPackageCodebyBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                NuclearWastePackage package = new NuclearWastePackage();
                package.Weight = transportVM.TransModel.BucketWeight;
                iNuclearWastePackageRepository.UpdatePackage(packageCode, AppContext.CurrentUser.ProjectCode, package);
                nuclearQtTransRepository.Create(transportVM.TransModel);
                transportVM.NuclearQtTransDetail.QtTransDetailId = Guid.NewGuid().ToString();
                transportVM.NuclearQtTransDetail.QtTransId = transportVM.TransModel.QtTransId;
                transportVM.NuclearQtTransDetail.Status = "2";
                iNuclearQtTransDetailRepository.Create(transportVM.NuclearQtTransDetail);

                transportVM.NuclearQtTransDetailB.QtTransDetailIdB = Guid.NewGuid().ToString();
                transportVM.NuclearQtTransDetailB.QtTransId = transportVM.TransModel.QtTransId;
                transportVM.NuclearQtTransDetailB.Status = "2";
                iNuclearQtTransDetailBRepository.Create(transportVM.NuclearQtTransDetailB);
                nuclearQtTransRepository.UnitOfWork.Commit();  
                return string.Empty;
            }
            catch
            {
                return "保存失败！";
            }
        }

        #endregion 添加数据

        /// <summary>
        /// 导入封盖数据
        /// </summary>
        /// <param name="ds">封盖数据集合</param>
        public static void ImportNuclearQtTrans(DataSet ds, string strNewImportPath, ApplicationUser currentUser)
        {
            INuclearQtTransRepository iNuclearQtTransRepository = ServiceLocator.Current.GetInstance<INuclearQtTransRepository>();
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicWasteUnitRepository iBasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();

            List<ImportNuclearQtTransErr> nuclearQtTransErrList = new List<ImportNuclearQtTransErr>();
            ImportNuclearQtTransErr nuclearQtTransErr = null;


            //得到电缆列表信息，并新增"错误描述"列
            DataTable dtElectricCable = ds.Tables[0];
            dtElectricCable.Columns.Add("错误描述", typeof(string));

            for (int i = 0; i < dtElectricCable.Rows.Count; i++)
            {
                #region 添加电缆数据
                nuclearQtTransErr = new ImportNuclearQtTransErr();
                DataRow row = dtElectricCable.Rows[i];
                string bucketId = nuclearQtTransErr.BucketId = CommonFunc.ObjectToNullStr(row["桶号"]).Trim();
                string ticketCode = nuclearQtTransErr.TicketCode = CommonFunc.ObjectToNullStr(row["工作票号"]).Trim();
                string bucketTypeId = nuclearQtTransErr.BucketTypeId = CommonFunc.ObjectToNullStr(row["桶的类型"]).Trim();
                string NXQSONE = nuclearQtTransErr.NXQSONE = CommonFunc.ObjectToNullStr(row["NX厂房-QS厂房"]).Trim();
                string fixationDateQS = Convert.ToString(nuclearQtTransErr.FixationDateQS); fixationDateQS = CommonFunc.ObjectToNullStr(row["QS固化时间"]).Trim();
                string transTicketQS = nuclearQtTransErr.TransTicketQS = CommonFunc.ObjectToNullStr(row["QS工作票号"]).Trim();
                string transDateQS = Convert.ToString(nuclearQtTransErr.TransDateQS); transDateQS = CommonFunc.ObjectToNullStr(row["QS转运时间"]).Trim();
                string processNameQS = nuclearQtTransErr.ProcessNameQS = CommonFunc.ObjectToNullStr(row["QS操作人"]).Trim();
                string NXQSTWO = nuclearQtTransErr.NXQSTWO = CommonFunc.ObjectToNullStr(row["NX厂房-QS厂房1"]).Trim();
                string fixationDateQT = Convert.ToString(nuclearQtTransErr.FixationDateQT); fixationDateQT = CommonFunc.ObjectToNullStr(row["QT固化时间"]).Trim();
                string transTicketQT = nuclearQtTransErr.TransTicketQT = CommonFunc.ObjectToNullStr(row["QT工作票号"]).Trim();
                string transDateQT = Convert.ToString(nuclearQtTransErr.TransDateQT); transDateQT = CommonFunc.ObjectToNullStr(row["QT转运时间"]).Trim();
                string processNameQT = nuclearQtTransErr.ProcessNameQT = CommonFunc.ObjectToNullStr(row["QT操作人"]).Trim();
                string fixationDateQSQT = Convert.ToString(nuclearQtTransErr.FixationDateQSQT); fixationDateQSQT = CommonFunc.ObjectToNullStr(row["QSQT封盖时间"]).Trim();
                string transTicketQSQT = nuclearQtTransErr.TransTicketQSQT = CommonFunc.ObjectToNullStr(row["QSQT工作票号"]).Trim();
                string transDateQSQT = Convert.ToString(nuclearQtTransErr.TransDateQSQT); transDateQSQT = CommonFunc.ObjectToNullStr(row["QSQT转运时间"]).Trim();
                string processNameQSQT = nuclearQtTransErr.ProcessNameQSQT = CommonFunc.ObjectToNullStr(row["QSQT操作员"]).Trim();
                string curdleFlag = nuclearQtTransErr.CurdleFlag = CommonFunc.ObjectToNullStr(row["封口凝固状态"]).Trim();
                string waterLeaveFlag = nuclearQtTransErr.WaterLeaveFlag = CommonFunc.ObjectToNullStr(row["遗留水份"]).Trim();
                string flawFlag = nuclearQtTransErr.FlawFlag = CommonFunc.ObjectToNullStr(row["可见缺陷"]).Trim();
                string sullyFlag = nuclearQtTransErr.SullyFlag = CommonFunc.ObjectToNullStr(row["表面沾污"]).Trim();
                string sullyCaseA = nuclearQtTransErr.SullyCaseA = CommonFunc.ObjectToNullStr(row["A字符值"]).Trim();
                string sullyCaseB = nuclearQtTransErr.SullyCaseB = CommonFunc.ObjectToNullStr(row["B字符值"]).Trim();
                string doseEva = Convert.ToString(nuclearQtTransErr.DoseEva); doseEva = CommonFunc.ObjectToNullStr(row["桶表面接触剂量率"]).Trim();
                string doseMeter = Convert.ToString(nuclearQtTransErr.DoseMeter); doseMeter = CommonFunc.ObjectToNullStr(row["距表面1米处剂量率"]).Trim();
                string rubbishFlag = nuclearQtTransErr.RubbishFlag = CommonFunc.ObjectToNullStr(row["废物标记"]).Trim();
                string bucketWeight = Convert.ToString(nuclearQtTransErr.BucketWeight); bucketWeight = CommonFunc.ObjectToNullStr(row["桶的重量"]).Trim();
                string qtPositionX = nuclearQtTransErr.QtPositionX = CommonFunc.ObjectToNullStr(row["QT位置"]).Trim();
                string activity = Convert.ToString(nuclearQtTransErr.Activity); activity = CommonFunc.ObjectToNullStr(row["活度"]).Trim();
                string processName = nuclearQtTransErr.ProcessName = CommonFunc.ObjectToNullStr(row["操作员"]).Trim();
                string processDate = Convert.ToString(nuclearQtTransErr.ProcessDate); processDate = CommonFunc.ObjectToNullStr(row["操作日期"]).Trim();
                string inspectionName = nuclearQtTransErr.InspectionName = CommonFunc.ObjectToNullStr(row["检查人"]).Trim();
                string inspectionDate = Convert.ToString(nuclearQtTransErr.InspectionDate); inspectionDate = CommonFunc.ObjectToNullStr(row["检查日期"]).Trim();
                string remark = nuclearQtTransErr.Remark = CommonFunc.ObjectToNullStr(row["备注"]).Trim();
                string stationcode = nuclearQtTransErr.Stationcode = CommonFunc.ObjectToNullStr(row["贮置电站"]).Trim();


                //桶号
                string bucketCode = string.Empty;
                if (!string.IsNullOrEmpty(bucketId))
                {
                    bucketCode = iNuclearBucketRepository.IsExistWasteBucket(bucketId, AppContext.CurrentUser.ProjectCode).ToString();
                    bool bucketCheck = iNuclearBucketRepository.IsExistByCodeAndStation(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        nuclearQtTransErr.Error += "您填的桶号不存在";
                    }

                    var listBucket = iNuclearBucketRepository.QueryListByCode(bucketId, AppContext.CurrentUser.ProjectCode).ToList();
                    if (listBucket.Count() > 0)
                    {
                        var listQtTrans = iNuclearQtTransRepository.GetModelByBucketId(listBucket[0].BucketId);
                        if (listQtTrans != null)
                        {
                            nuclearQtTransErr.Error += "您填的桶号已经经过封盖";
                        }
                    }
                }
                //桶类型
                string bucketTypeIds = string.Empty;
                if (!string.IsNullOrEmpty(bucketTypeId))
                {
                    List<BasicObject> bucketTypeIdQuery = iBasicObjectRepository.GetAll().Where(d => d.Name == bucketTypeId).AsQueryable().ToList();
                    if (bucketTypeIdQuery != null && bucketTypeIdQuery.Count() > 0)
                    {
                        bucketTypeIds = bucketTypeIdQuery[0].Uuid;
                    }
                    else {
                        nuclearQtTransErr.Error += "系统中不存在该桶类型";
                    }
                }
                //封口凝固状态  
                string curdleFlags = string.Empty;
                if (!string.IsNullOrEmpty(curdleFlag))
                {
                    if (curdleFlag == "好")
                    {
                        curdleFlags = "0";
                    }
                    if (curdleFlag == "不好")
                    {
                        curdleFlags = "1";
                    }
                    if (curdleFlag == "不适用")
                    {
                        curdleFlags = "2";
                    }
                }
                //遗留水分
                string waterLeaveFlags = string.Empty;
                if (!string.IsNullOrEmpty(waterLeaveFlag))
                {
                    if (waterLeaveFlag == "有")
                    {
                        waterLeaveFlags = "0";
                    }
                    if (waterLeaveFlag == "无")
                    {
                        waterLeaveFlags = "1";
                    }
                    if (waterLeaveFlag == "不适用")
                    {
                        waterLeaveFlags = "2";
                    }
                }
                //可见缺陷
                string flawFlags = string.Empty;
                if (!string.IsNullOrEmpty(flawFlag))
                {
                    if (flawFlag == "有")
                    {
                        flawFlags = "0";
                    }
                     if (flawFlag == "无")
                    {
                        flawFlags = "1";
                    }
                     if (flawFlag == "不适用")
                     {
                         flawFlags = "2";
                     }
                }
                //表面沾污
                string sullyFlags = string.Empty;
                if (!string.IsNullOrEmpty(sullyFlag))
                {
                    if (sullyFlag == "有")
                    {
                        sullyFlags = "0";
                    }
                    if (sullyFlag == "无")
                    {
                        sullyFlags = "1";
                    } 
                }
                //废物标记
                string rubbishFlags = string.Empty;
                if (!string.IsNullOrEmpty(sullyFlag))
                {
                    if (rubbishFlag == "有")
                    {
                        rubbishFlags = "0";
                    }
                    if (rubbishFlag == "无")
                    {
                        rubbishFlags = "1";
                    }
                }
                //判断数据是否正确
                if (CommonFunc.IsNotNullString(nuclearQtTransErr.Error))
                {
                    nuclearQtTransErrList.Add(nuclearQtTransErr);
                    continue;
                }
                else
                {
                    NuclearQtTrans nuclearQtTrans = new NuclearQtTrans();
                    NuclearQtTransDetail nuclearQtTransDetail = new NuclearQtTransDetail();
                    NuclearQtTransDetailB nuclearQtTransDetailB = new NuclearQtTransDetailB();
                    nuclearQtTrans.BucketId = bucketCode;
                    nuclearQtTrans.TicketCode = ticketCode;
                    nuclearQtTrans.BucketTypeId = bucketTypeIds;
                    if (fixationDateQS != null && fixationDateQS != "")
                    { 
                        nuclearQtTransDetail.FixationDate = Convert.ToDateTime(fixationDateQS);
                        nuclearQtTransDetail.TransTicket = transTicketQS;
                        if (transDateQS != null && transDateQS != ""){
                            nuclearQtTransDetail.TransDate = Convert.ToDateTime(transDateQS);
                        }else { nuclearQtTransDetail.TransDate = null; }
                        nuclearQtTransDetail.ProcessName = processNameQS;
                    }
                    else 
                    {
                        nuclearQtTransDetail.FixationDate = Convert.ToDateTime(fixationDateQT);
                        nuclearQtTransDetail.TransTicket = transTicketQT;
                        if (transDateQT != null && transDateQT != "")
                        {
                            nuclearQtTransDetail.TransDate = Convert.ToDateTime(transDateQT);
                        }
                        else { nuclearQtTransDetail.TransDate = null; }
                        nuclearQtTransDetail.ProcessName = processNameQT;
                    }

                    if (fixationDateQSQT != null && fixationDateQSQT != "")
                    {
                        nuclearQtTransDetailB.OverDate = Convert.ToDateTime(fixationDateQSQT);
                    }
                    else { nuclearQtTransDetailB.OverDate = null; }
                    nuclearQtTransDetailB.TransTicket = transTicketQSQT;
                    if (transDateQSQT != null && transDateQSQT != "")
                    {
                        nuclearQtTransDetailB.TransDate = Convert.ToDateTime(transDateQSQT);
                    }
                    else { nuclearQtTransDetailB.TransDate = null; }
                    nuclearQtTransDetailB.ProcessName = processNameQSQT;

                    nuclearQtTrans.CurdleFlag = curdleFlags;
                    nuclearQtTrans.WaterLeaveFlag = waterLeaveFlags;
                    nuclearQtTrans.FlawFlag = flawFlags;
                    nuclearQtTrans.SullyFlag = sullyFlags;
                    nuclearQtTrans.SullyCaseA = sullyCaseA;
                    nuclearQtTrans.SullyCaseB = sullyCaseB;

                    if (doseEva != null && doseEva != "")
                    {
                        nuclearQtTrans.DoseEva = Convert.ToDecimal(doseEva);
                    }
                    else { nuclearQtTrans.DoseEva = null; }
                    if (doseMeter != null && doseMeter != "")
                    {
                        nuclearQtTrans.DoseMeter = Convert.ToDecimal(doseMeter);
                    }
                    else { nuclearQtTrans.DoseMeter = null; }

                    nuclearQtTrans.RubbishFlag = rubbishFlags;
                    if (bucketWeight != null && bucketWeight != "")
                    {
                        nuclearQtTrans.BucketWeight = Convert.ToDecimal(bucketWeight);
                    }
                    else { nuclearQtTrans.BucketWeight = null; }
                    //QT位置
                    //if (qtPositionX != null && qtPositionX != "")
                    //{
                    //    nuclearQtTrans.QtPositionX = qtPositionX.Substring(0, 2);
                    //    nuclearQtTrans.QtPositionY = qtPositionX.Substring(3, 4);
                    //    nuclearQtTrans.QtPositionZ = qtPositionX.Substring(6);
                    //}
                    //else {
                    //    nuclearQtTrans.QtPositionX = null;
                    //    nuclearQtTrans.QtPositionY = null;
                    //    nuclearQtTrans.QtPositionZ = null;
                    //}
                    if (activity != null && activity != "")
                    {
                        nuclearQtTrans.Activity = Convert.ToDecimal(activity);
                    }
                    else { nuclearQtTrans.Activity = null; }
                    if (processName != null && processName != "")
                    {
                        nuclearQtTrans.ProcessNo = processName.Substring(1, 7);
                        nuclearQtTrans.ProcessName = processName.Substring(9);
                    }
                    else
                    {
                        nuclearQtTrans.ProcessNo = null;
                        nuclearQtTrans.ProcessName = null;
                    }
                    if (processDate != null && processDate != "")
                    {
                        nuclearQtTrans.ProcessDate = Convert.ToDateTime(processDate);
                    }
                    else { nuclearQtTrans.ProcessDate = null; }
                    if (inspectionName != null && inspectionName != "")
                    {
                        nuclearQtTrans.InspectionNo = inspectionName.Substring(1, 7);
                        nuclearQtTrans.InspectionName = inspectionName.Substring(9);
                    }
                    else
                    {
                        nuclearQtTrans.InspectionNo = null;
                        nuclearQtTrans.InspectionName = null;
                    }
                    if (inspectionDate != null && inspectionDate != "")
                    {
                        nuclearQtTrans.InspectionDate = Convert.ToDateTime(inspectionDate);
                    }
                    else { nuclearQtTrans.InspectionDate = null; }

                    nuclearQtTrans.Remark = remark + "  QT位置：" + qtPositionX;
                    nuclearQtTrans.Status = "2";

                    //添加电缆草稿信息
                    TransportVM vm = new TransportVM();
                    vm.TransModel = nuclearQtTrans;
                    vm.NuclearQtTransDetail = nuclearQtTransDetail;
                    vm.NuclearQtTransDetailB = nuclearQtTransDetailB;
                    string messge = InsertQtTransData(vm, iNuclearQtTransRepository);
                    if (!string.IsNullOrEmpty(messge))
                    {
                        nuclearQtTransErr.Error += messge;
                        nuclearQtTransErrList.Add(nuclearQtTransErr);
                        iNuclearQtTransRepository.UnitOfWork.RollbackChanges();
                        continue;
                    }
                    //else
                    //{
                    //    //添加电缆信息
                    //    NuclearTrackTechS nuclearTrackTechSData = ImportDataBuilder.TransferFromDraft(nuclearTrackTechSs);
                    //    nuclearTrackTechSData.TechSId = Guid.NewGuid().ToString();
                    //    iNuclearTrackTechSRepository.Create(nuclearTrackTechSData);
                    //    iNuclearTrackTechSRepository.UnitOfWork.Commit();

                    //}

                }
                #endregion 添加电缆数据
            }

            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);

            #region 错误文档
            if (nuclearQtTransErrList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (nuclearQtTransErrList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("封盖后贮存数据错误信息");
                    ImportExportHelper.FillSheet<ImportNuclearQtTransErr>(nuclearQtTransErrList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<ImportNuclearQtTransErr>(stream);
            }

            #endregion
        }

        /// <summary>
        /// 检查导入的封盖数据表格列头是否正确
        /// </summary>
        /// <param name="ds">封盖数据数据集</param>
        /// <param name="strNewImportPath">封盖数据数据所在的物理路径</param>
        /// <returns></returns>
        public static string GetImportNuclearQtTransErr(DataSet ds, string strNewImportPath)
        {
            string errMsg = string.Empty;

            //得到电缆列头信息
            DataTable dtElectricCable = ds.Tables[0];
            string columnNames = ",";
            for (int i = 0; i < dtElectricCable.Columns.Count; i++)
            {
                columnNames += dtElectricCable.Columns[i].ColumnName + ",";
            }
            bool isCorrectStyle = true;
            isCorrectStyle = (columnNames.Contains(",桶号,") && columnNames.Contains(",工作票号,") && columnNames.Contains(",桶的类型,") && columnNames.Contains(",NX厂房-QS厂房,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",QS固化时间,") && columnNames.Contains(",QS工作票号,") && columnNames.Contains(",QS转运时间,") && columnNames.Contains(",QS操作人,") && columnNames.Contains(",NX厂房-QS厂房1,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",QT固化时间,") && columnNames.Contains(",QT工作票号,") && columnNames.Contains(",QT转运时间,") && columnNames.Contains(",QT操作人,") && columnNames.Contains(",QSQT封盖时间,") && columnNames.Contains(",QSQT工作票号,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",QSQT转运时间,") && columnNames.Contains(",QSQT操作员,") && columnNames.Contains(",封口凝固状态,") && columnNames.Contains(",遗留水份,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",可见缺陷,") && columnNames.Contains(",表面沾污,") && columnNames.Contains(",A字符值,") && columnNames.Contains(",B字符值,") && columnNames.Contains(",桶表面接触剂量率,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",距表面1米处剂量率,") && columnNames.Contains(",废物标记,") && columnNames.Contains(",桶的重量,") && columnNames.Contains(",QT位置,") && columnNames.Contains(",活度,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",操作员,") && columnNames.Contains(",操作日期,") && columnNames.Contains(",检查人,") && columnNames.Contains(",检查日期,") && columnNames.Contains(",备注,") && columnNames.Contains(",贮置电站,"));
            if (isCorrectStyle == false)
            {
                //删除文件
                if (System.IO.File.Exists(strNewImportPath))
                {
                    System.IO.File.Delete(strNewImportPath);
                }
                errMsg = "封盖后贮存数据模板格式有误,请仔细检查列头！";
            }
            return errMsg;
        }

        #endregion 导入封盖数据
    }
}