﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels;
using RWIS.Presentation.Web.Core.Ftp;
using RWIS.Presentation.Web.Core;
using CIT.UPC.Domain.Repositories;
using CIT.UPC.Domain.DomainObjects;
using Microsoft.Practices.ServiceLocation;
using System.Web;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
namespace RWIS.Presentation.Web.Areas.TemporaryStorage.Controllers
{
    public class StockManageController : Controller
    {
        INuclearTsStockRepository _NuclearTsStockRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        public StockManageController(INuclearTsStockRepository NuclearTsStockRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository)
        {
            this._NuclearTsStockRepository = NuclearTsStockRepository;
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
        }
        /// <summary>
        /// 首页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "盘点管理")]
        public ActionResult Index()
        {
            StockManageVM vm = new StockManageVM();
            vm.OperationList = CommonHelper.GetOperationList("Stock_Manage");
            return View(vm);
        }
        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "盘点管理明细")]
        public ActionResult Detail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            StockManageVM vm = new StockManageVM();
            vm.OperationList = CommonHelper.GetOperationList("Stock_Manage");
            vm.FactoryList = new List<SelectListItem>();
            vm.StockDetailList = new List<StockDetailData>();
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            vm.StockModel = new NuclearTsStock();
            if (!string.IsNullOrEmpty(uid))
            {
                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(uid, "StockManage");
                vm.AttachFiles = (List<AttachFile>)listAttachFile;
                var detailList = _NuclearTsStockRepository.GetStockDetailListById(uid).ToList();
                if (detailList.Count > 0)
                {
                    foreach (NuclearTsStockD detail in detailList)
                    {
                        StockDetailData model = new StockDetailData();
                        model.DetailId = detail.DetailId;
                        model.FactoryId = detail.LocationId;
                        var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId);
                        if (bucketModel != null)
                            model.BucketCode = bucketModel.BucketCode;
                        var basicModel = _BasicObjectRepository.GetBasicById(detail.LocationId);
                        if (basicModel != null)
                            model.FactoryName = basicModel.Name;
                        vm.StockDetailList.Add(model);
                    }

                }
                vm.StockModel = _NuclearTsStockRepository.GetStockModel(uid);
                detailFlag = "edit";
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(StockCondition stockCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var query = _NuclearTsStockRepository.GetStockList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (!string.IsNullOrEmpty(stockCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(stockCondition.StartDate);
                query = query.Where(n => n.StockDate >= sDate).ToList();
            }
            if (!string.IsNullOrEmpty(stockCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(stockCondition.EndDate);
                query = query.Where(n => n.StockDate <= eDate).ToList();
            }
            //query = query.OrderByDescending(n => n.CreateDate).ToList();
            List<StockList> pList = new List<StockList>();
            if (query != null)
            {
                for (int i = 0; i < query.Count; i++)
                {
                    StockList stock = new StockList();
                    stock.StockId = query[i].TsStockId;
                    if (query[i].StockDate != null)
                        stock.StockDate = Convert.ToDateTime(query[i].StockDate.ToString()).ToShortDateString();
                    else
                        stock.StockDate = string.Empty;
                    stock.Remark = query[i].Remark;
                    stock.Status = query[i].Status;
                    stock.Attachment = "";
                    stock.CreateDate = query[i].CreateDate;
                    pList.Add(stock);
                }
            }
            //pList = pList.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<StockList> data = pList.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<StockList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("desc") ? MvcContrib.Sorting.SortDirection.Descending : MvcContrib.Sorting.SortDirection.Ascending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.StockId,
                    List = new List<object>() {
                    d.StockId,
                    d.StockDate,
                    d.Attachment,
                    d.Remark,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "盘点管理添加")]
        public ActionResult AddStock(StockManageVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsStock stock = new NuclearTsStock();
                stock = model.StockModel;
                stock.TsStockId = Guid.NewGuid().ToString();
                stock.CreateUserNo = AppContext.CurrentUser.UserId;
                stock.CreateUserName = AppContext.CurrentUser.UserName;
                stock.CreateDate = DateTime.Now;
                stock.Status = Request.Form["submitType"];
                stock.Stationcode = AppContext.CurrentUser.ProjectCode;

                #region"添加明细"

                List<NuclearTsStockD> detailList = new List<NuclearTsStockD>();
                string[] arrayBucketCode = null;
                string[] arrayFactoryId = null;
                string strBucketCode = Request.Form["hidBucketCode"];
                string strFactoryId = Request.Form["hidFactoryId"];
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayFactoryId = strFactoryId.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearTsStockD detail = new NuclearTsStockD();
                        detail.DetailId = Guid.NewGuid().ToString();
                        detail.TsStockId = stock.TsStockId;
                        detail.LocationId = arrayFactoryId[i];
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        detailList.Add(detail);
                    }
                }
                #endregion

                this.SaveAttachFile(stock.TsStockId, "UploadStock", formCollection);
                if (_NuclearTsStockRepository.AddStock(stock, detailList))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "盘点管理修改及确认")]
        public ActionResult UpdateStock(StockManageVM model, FormCollection formCollection)
        {
            try
            {
                model.StockModel.Status = Request.Form["submitType"];

                #region"添加明细"

                List<NuclearTsStockD> detailList = new List<NuclearTsStockD>();
                string[] arrayBucketCode = null;
                string[] arrayFactoryId = null;
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ", "");
                string strFactoryId = Request.Form["hidFactoryId"];
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayFactoryId = strFactoryId.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearTsStockD detail = new NuclearTsStockD();
                        detail.DetailId = Guid.NewGuid().ToString();
                        detail.TsStockId = model.StockModel.TsStockId;
                        detail.LocationId = arrayFactoryId[i];
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        detailList.Add(detail);
                    }
                }
                #endregion

                this.SaveAttachFile(model.StockModel.TsStockId, "UploadStock", formCollection);

                if (model.StockModel.Status == "2")
                {
                    model.StockModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.StockModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.StockModel.ConfirmDate = DateTime.Now;
                }
                if (_NuclearTsStockRepository.UpdateStock(model.StockModel, detailList))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "盘点管理删除")]
        public ActionResult DeleteStock()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearTsStockRepository.DeleteStock(id))
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmStock(StockManageVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsStock stock = new NuclearTsStock();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    stock = _NuclearTsStockRepository.GetStockModel(uid);
                else
                    stock = _NuclearTsStockRepository.GetStockModel(model.StockModel.TsStockId);
                stock.Status = "2";
                stock.ConfirmUserNo = AppContext.CurrentUser.UserId;
                stock.ConfirmUserName = AppContext.CurrentUser.UserName;
                stock.ConfirmDate = DateTime.Now;

                if (_NuclearTsStockRepository.UpdateStock(stock, null))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 检查桶号是否可用
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckBucketCode()
        {
            string bucketCode = Request["code"];
            bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
            if (!bucketCheck)
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && e.IsOutSend == null).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 根据主键ID获取指定的附件
        /// </summary>
        /// <returns></returns>
        public ActionResult GetAttachById()
        {
            string id = Request["id"];
            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "StockManage");
            var attachList = (List<AttachFile>)listAttachFile;
            if (attachList != null)
            {
                CIT.UPC.Presentation.Web.ViewModels.Common.UploadFileListVM vm = new CIT.UPC.Presentation.Web.ViewModels.Common.UploadFileListVM();
                vm.FileList = attachList;
                vm.EnableDownLoad = true;
                vm.EnableDelete = false;
                System.Text.StringBuilder str = new System.Text.StringBuilder();
                str.Append("<table class='swfuploadfileListTable' cellpadding='0' cellspacing='0' border='0' style='width:100%;' ><thhead><tr><th style='text-align: center;'>文件名</th><th style='text-align: center;'>文件大小(k)</th><th style='width:60px; text-align: center;'>操作</th></tr></thhead>");
                string opHtml;
                string downloadurl = Url.Action("DownFile", "Ftp", new { Area = "Basic" }) + "/?fileId={0}&fileName={1}&businessType={2}";
                foreach (var f in attachList)
                {
                    string dlurl = string.Format(downloadurl, f.FileId, HttpUtility.UrlEncode(f.FileName), f.BusinessType);
                    if (vm.EnableDelete)
                    {
                        opHtml = "<td><a href='javascript:void(0)' onclick='deletefile('" + f.FileId + "','" + f.FileName + "',this)'>删除</a>&nbsp;<a href='" + dlurl + "'>下载</a></td>";
                    }
                    else
                    {
                        opHtml = "<td style='text-align: center;'><a href='" + dlurl + "'>下载</a></td>";
                    }
                    str.Append("<tr><td style='text-align: center;'>" + f.FileName + "</td><td style='text-align: center;'>" + f.FileLength + "</td>" + opHtml + "</tr>");
                }
                str.Append("</table>");
                return Json("{\"result\":true,\"msg\":\"" + str.ToString() + "\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 附件
        /// </summary>
        /// <param name="formCollection"></param>
        /// <returns></returns>

        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], "StockManage");
            }
            return null;
        }
        /// <summary>
        /// 下载文件
        /// 
        /// </summary>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }
    }
}
