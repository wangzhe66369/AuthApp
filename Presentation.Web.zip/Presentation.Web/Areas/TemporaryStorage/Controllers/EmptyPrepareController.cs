﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.Controllers
{
    public class EmptyPrepareController : Controller
    {
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearTsEbPrepareRepository _NuclearTsEbPrepareRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        INuclearTsEbPrepareDetailRepository _NuclearTsEbPrepareDetailRepository;
        public EmptyPrepareController(INuclearTsEbPrepareRepository NuclearTsEbPrepareRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository
            , IMaterialTypeRepository MaterialTypeRepository, INuclearTsEbPrepareDetailRepository NuclearTsEbPrepareDetailRepository)
        {
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NuclearTsEbPrepareRepository = NuclearTsEbPrepareRepository;
            this._MaterialTypeRepository = MaterialTypeRepository;
            this._NuclearTsEbPrepareDetailRepository = NuclearTsEbPrepareDetailRepository;
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "空桶准备记录")]
        public ActionResult Index()
        {
            EmptyPrepareVM vm = new EmptyPrepareVM();
            vm.OperationList = CommonHelper.GetOperationList("Empty_Prepare");
            vm.FactoryList = new List<SelectListItem>();
            vm.FactoryList.Add(new SelectListItem { Text = "请选择", Value = "0" });
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            return View(vm);
        }
        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "空桶准备记录明细")]
        public ActionResult Detail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            EmptyPrepareVM vm = new EmptyPrepareVM();
            vm.OperationList = CommonHelper.GetOperationList("Empty_Prepare");
            vm.FactoryList = new List<SelectListItem>();
            vm.BucketTypeList = new List<SelectListItem>();
            vm.WorkTypeList = new List<SelectListItem>();
            vm.MaterialList = new List<SelectListItem>();
            List<BasicObject> listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryFactory = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            if (queryFactory != null && queryFactory.Count() > 0)
            {
                listBasicObject = queryFactory.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryNuClearType = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            if (queryNuClearType != null && queryNuClearType.Count() > 0)
            {
                listBasicObject = queryNuClearType.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryWorkType = _BasicObjectRepository.GetSubobjectsByCode("WorkType", AppContext.CurrentUser.ProjectCode);
            if (queryWorkType != null && queryWorkType.Count() > 0)
            {
                listBasicObject = queryWorkType.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.WorkTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            var materialList = _MaterialTypeRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.IsBucket == "1").ToList();
            foreach (MaterialType material in materialList)
            {
                vm.MaterialList.Add(new SelectListItem { Text = material.MaterialName, Value = material.MaterialId });
            }
            vm.DetailList = new List<PrepareDetailList>();
            vm.PrepareModel = new NuclearTsEbPrepare();
            if (!string.IsNullOrEmpty(uid))
            {
                var dataList = _NuclearTsEbPrepareRepository.GetDetalListByTsEbPrepareId(uid).ToList();
                if (dataList != null && dataList.Count > 0)
                {
                    foreach (NuclearPrepareDetail detail in dataList)
                    {
                        PrepareDetailList model = new PrepareDetailList();
                        model.DetailId = detail.EbPrepareDetailId;
                        if (!string.IsNullOrEmpty(detail.BucketId))
                        {
                            var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId);
                            if (bucketModel == null) continue;
                            model.BucketCode = bucketModel.BucketCode;
                        }
                        model.WorkTicket = detail.TicketCode;
                        if (detail.WorkDate != null)
                            model.WorkDate = Convert.ToDateTime(detail.WorkDate.ToString()).ToShortDateString();
                        if (!string.IsNullOrEmpty(detail.WorkType))
                            model.WorkType = _BasicObjectRepository.GetBasicById(detail.WorkType).Name;
                        model.WorkTypeId = detail.WorkType;
                        if (!string.IsNullOrEmpty(detail.BucketType))
                            model.BucketType = _BasicObjectRepository.GetBasicById(detail.BucketType).Name;
                        model.BucketTypeId = detail.BucketType;
                        model.MaterialId = detail.MaterialId;
                        var materialModel = _MaterialTypeRepository.GetMaterialModel(detail.MaterialId);
                        if (materialModel != null)
                            model.MaterialName = materialModel.MaterialName;
                        //model.Position = detail.Position;
                        model.ControlName = detail.ControlUserName;
                        model.ControlNo = detail.ControlUserNo;
                        model.Remark = detail.Remark;
                        vm.DetailList.Add(model);
                    }
                }
                vm.PrepareModel = _NuclearTsEbPrepareRepository.GetTsEbPrepareModel(uid);
                detailFlag = "edit";
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(PrepareCondition prepareCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var query = _NuclearTsEbPrepareRepository.GetTsEbPrepareList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();

           
            NuclearBucket nuclearBucket = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == (prepareCondition.BucketCode == null ? prepareCondition.BucketCode : prepareCondition.BucketCode.Trim())).FirstOrDefault();
            if (nuclearBucket != null)
            {
                var queryDetail = _NuclearTsEbPrepareDetailRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.BucketId == nuclearBucket.BucketId).ToList();
                if (queryDetail.Count() > 0)
                {
                    prepareCondition.EbPrepareId = queryDetail[0].EbPrepareId;
                }

            }

            if (prepareCondition.BucketCode != null)
            {
                NuclearBucket nuclearBucketJ = _NuclearBucketRepository.GetAll().Where(d => d.BucketCode == (prepareCondition.BucketCode == null ? prepareCondition.BucketCode : prepareCondition.BucketCode.Trim())).FirstOrDefault();
                if (nuclearBucketJ == null)
                {
                    query = null;
                   
                }
            }


            if (!string.IsNullOrEmpty(prepareCondition.EbPrepareId))
            {
                query = query.Where(n => n.EbPrepareId == prepareCondition.EbPrepareId).ToList();
            }


            if (!string.IsNullOrEmpty(prepareCondition.Year))
            {
                query = query.Where(n => !string.IsNullOrEmpty(n.Year) && n.Year.Contains(prepareCondition.Year)).ToList();
            }
            if (!string.IsNullOrEmpty(prepareCondition.Factory) && prepareCondition.Factory != "0")
                query = query.Where(n => n.Factory == prepareCondition.Factory).ToList();
            if (!string.IsNullOrEmpty(prepareCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(prepareCondition.StartDate);
                query = query.Where(n => n.RecordDate >= sDate).ToList();
            }
            if (!string.IsNullOrEmpty(prepareCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(prepareCondition.EndDate);
                query = query.Where(n => n.RecordDate <= eDate).ToList();
            }
         


            List<PrepareList> pList = new List<PrepareList>();
            if (query != null)
            {
                for (int i = 0; i < query.Count; i++)
                {
                    PrepareList prepare = new PrepareList();
                    prepare.PrepareID = query[i].EbPrepareId;
                    //if (string.IsNullOrEmpty(query[i].Year))
                    //    prepare.Year = "";
                    //else
                    //    prepare.Year = query[i].Year;
                    var factoryModel = _BasicObjectRepository.GetBasicById(query[i].Factory);
                    if (factoryModel != null)
                        prepare.Factory = factoryModel.Name;
                    prepare.RecordName = query[i].RecordName;
                    if (query[i].RecordDate != null)
                        prepare.RecordDate = Convert.ToDateTime(query[i].RecordDate.ToString()).ToShortDateString();
                    prepare.Status = query[i].Status;
                    prepare.CreateDate = query[i].CreateDate;
                    
                    var dataList = _NuclearTsEbPrepareRepository.GetDetalListByTsEbPrepareId(prepare.PrepareID).FirstOrDefault();
                    if (dataList != null)
                    {
                        prepare.WorkTicket = dataList.TicketCode;
                    }
                   
                    pList.Add(prepare);
                }
            }
            if (!string.IsNullOrEmpty(prepareCondition.WorkTicket))
            {

                pList = pList.Where(d => d.WorkTicket == null ? d.WorkTicket == prepareCondition.WorkTicket : d.WorkTicket.ToUpper().Contains(prepareCondition.WorkTicket.Trim().ToUpper())).ToList();
               
            }

            pList = pList.OrderByDescending(n => n.CreateDate).ToList();
            
            IQueryable<PrepareList> data = pList.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<PrepareList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.PrepareID,
                    List = new List<object>() {
                    d.PrepareID,
                    d.Factory,
                    d.WorkTicket,
                    d.RecordName,
                    d.RecordDate,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDetailDataList(PrepareCondition prepareCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            string uid = Request["uid"];
            var query = _NuclearTsEbPrepareRepository.GetDetalListByTsEbPrepareId(uid).Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode);
            IQueryable<PrepareDetailList> data = query.Select(n => new PrepareDetailList
            {
                DetailId = n.EbPrepareDetailId,
                BucketCode = n.BucketId,
                WorkTicket = n.TicketCode,
                WorkDate = n.WorkDate.ToString(),
                WorkType = n.WorkType,
                BucketType = n.BucketType,
                Position = n.Position,
                ControlName = n.ControlUserName,
                Remark = n.Remark
            });
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<PrepareDetailList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DetailId,
                    List = new List<object>() {
                    d.DetailId,
                    _BasicObjectRepository.GetBasicById(d.BucketCode).Name,
                    d.WorkTicket,
                    d.WorkDate,
                    _BasicObjectRepository.GetBasicById(d.WorkType).Name,
                    _BasicObjectRepository.GetBasicById(d.BucketType).Name,
                    d.Position,
                    d.ControlName,
                    d.Remark
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "空桶准备记录添加")]
        public ActionResult AddPrepare(EmptyPrepareVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsEbPrepare prepare = new NuclearTsEbPrepare();
                prepare = model.PrepareModel;
                prepare.EbPrepareId = Guid.NewGuid().ToString();
                prepare.CreateUserNo = AppContext.CurrentUser.UserId;
                prepare.CreateUserName = AppContext.CurrentUser.UserName;
                prepare.CreateDate = DateTime.Now;
                prepare.Status = Request.Form["submitType"];
                prepare.Stationcode = AppContext.CurrentUser.ProjectCode;

                #region"添加明细"

                List<NuclearPrepareDetail> detailList = new List<NuclearPrepareDetail>();
                string[] arrayBucketCode = null;
                string[] arrayWorkTicket = null;
                string[] arrayWorkDate = null;
                string[] arrayWorkType = null;
                string[] arrayBucketType = null;
                //string[] arrayPosition = null;
                string[] arrayMaterial = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"];
                string strWorkTicket = Request.Form["hidWorkTicket"];
                string strWorkDate = Request.Form["hidWorkDate"];
                string strWorkType = Request.Form["hidWorkType"];
                string strBucketType = Request.Form["hidBucketType"];
                //string strPosition = Request.Form["hidPosition"];
                string strMaterial = Request.Form["hidMaterial"];
                string strControlNo = Request.Form["hidControlNo"];
                string strControlName = Request.Form["hidControlName"];
                string strRemark = Request.Form["hidRemark"];
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayWorkTicket = strWorkTicket.Split(new char[] { ',' });
                    arrayWorkDate = strWorkDate.Split(new char[] { ',' });
                    arrayWorkType = strWorkType.Split(new char[] { ',' });
                    arrayBucketType = strBucketType.Split(new char[] { ',' });
                    //arrayPosition = strPosition.Split(new char[] { ',' });
                    arrayMaterial = strMaterial.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearPrepareDetail detail = new NuclearPrepareDetail();
                        detail.EbPrepareDetailId = Guid.NewGuid().ToString();
                        detail.EbPrepareId = prepare.EbPrepareId;
                        var bucketModel = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).FirstOrDefault();

                        if (prepare.Status == "2")
                        {
                            bucketModel.IsPrepare = "1";
                            bucketModel.BucketStatus = "EMPTY";
                            _NuclearBucketRepository.UpdateBucketModel(bucketModel);
                        }
                        detail.BucketId = bucketModel.BucketId;
                        detail.TicketCode = arrayWorkTicket[i];
                        if (!string.IsNullOrEmpty(arrayWorkDate[i]))
                            detail.WorkDate = Convert.ToDateTime(arrayWorkDate[i]);
                        detail.WorkType = arrayWorkType[i];
                        detail.BucketType = arrayBucketType[i];
                        //detail.Position = arrayPosition[i];
                        detail.MaterialId = arrayMaterial[i];
                        detail.Remark = arrayRemark[i];
                        detail.ControlUserNo = arrayControlNo[i];
                        detail.ControlUserName = arrayControlName[i];
                        detail.ControlDate = DateTime.Now;
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }

                }

                #endregion

                if (prepare.Status == "2")
                {
                    prepare.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    prepare.ConfirmUserName = AppContext.CurrentUser.UserName;
                    prepare.ConfirmDate = DateTime.Now;
                }

                if (_NuclearTsEbPrepareRepository.AddPrepare(prepare, detailList))
                {
                    _NuclearTsEbPrepareRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "空桶准备记录修改及确认")]
        public ActionResult UpdatePrepare(EmptyPrepareVM model, FormCollection formCollection)
        {
            try
            {
                string confirmFlag = model.PrepareModel.Status;
                model.PrepareModel.Status = Request.Form["submitType"];

                #region"添加明细"

                List<NuclearPrepareDetail> detailList = new List<NuclearPrepareDetail>();
                string[] arrayBucketCode = null;
                string[] arrayWorkTicket = null;
                string[] arrayWorkDate = null;
                string[] arrayWorkType = null;
                string[] arrayBucketType = null;
                //string[] arrayPosition = null;
                string[] arrayMaterial = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ", "");
                string strWorkTicket = Request.Form["hidWorkTicket"].Replace("\r\n", "").Replace(" ", "");
                string strWorkDate = Request.Form["hidWorkDate"].Replace("\r\n", "").Replace(" ", "");
                string strWorkType = Request.Form["hidWorkType"].Replace("\r\n", "").Replace(" ", "");
                string strBucketType = Request.Form["hidBucketType"].Replace("\r\n", "").Replace(" ", "");
                //string strPosition = Request.Form["hidPosition"].Replace("\r\n", "").Replace(" ", "");
                string strMaterial = Request.Form["hidMaterial"].Replace("\r\n", "").Replace(" ", "");
                string strControlNo = Request.Form["hidControlNo"].Replace("\r\n", "").Replace(" ", "");
                string strControlName = Request.Form["hidControlName"].Replace("\r\n", "").Replace(" ", "");
                string strRemark = Request.Form["hidRemark"].Replace("\r\n", "").Replace(" ", "");
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayWorkTicket = strWorkTicket.Split(new char[] { ',' });
                    arrayWorkDate = strWorkDate.Split(new char[] { ',' });
                    arrayWorkType = strWorkType.Split(new char[] { ',' });
                    arrayBucketType = strBucketType.Split(new char[] { ',' });
                    //arrayPosition = strPosition.Split(new char[] { ',' });
                    arrayMaterial = strMaterial.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearPrepareDetail detail = new NuclearPrepareDetail();
                        detail.EbPrepareDetailId = Guid.NewGuid().ToString();
                        detail.EbPrepareId = model.PrepareModel.EbPrepareId;
                        var bucketModel = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i].Trim(), AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                        if (model.PrepareModel.Status == "2" && confirmFlag != "2")
                        {
                            bucketModel.IsPrepare = "1";
                            bucketModel.BucketStatus = "EMPTY";
                            _NuclearBucketRepository.UpdateBucketModel(bucketModel);
                        }
                        detail.BucketId = bucketModel.BucketId;
                        detail.TicketCode = arrayWorkTicket[i].Trim();
                        if (!string.IsNullOrEmpty(arrayWorkDate[i].Trim()))
                            detail.WorkDate = Convert.ToDateTime(arrayWorkDate[i].Trim());
                        detail.WorkType = arrayWorkType[i].Trim();
                        detail.BucketType = arrayBucketType[i].Trim();
                        //detail.Position = arrayPosition[i].Trim();
                        detail.MaterialId = arrayMaterial[i];
                        detail.Remark = arrayRemark[i].Trim();
                        detail.ControlUserNo = arrayControlNo[i].Trim();
                        detail.ControlUserName = arrayControlName[i].Trim();
                        detail.ControlDate = DateTime.Now;
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }
                //页面传过来桶号
                string []arrBucketCode = strBucketCode.TrimEnd(',').Split(new char[] { ',' });
                //页面传过来桶号
                string[] arrBucketCodeArr = null;
                List<string> arrBucketList = new List<string>();
                IQueryable<NuclearPrepareDetail> nuclearPrepareDetailList = _NuclearTsEbPrepareDetailRepository.GetAll().Where(d => d.EbPrepareId == model.PrepareModel.EbPrepareId).AsQueryable();
                IQueryable<NuclearBucket> nuclearBucketList = _NuclearBucketRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
                nuclearBucketList = (from i in nuclearBucketList
                                       join s in nuclearPrepareDetailList
                                       on i.BucketId equals s.BucketId
                                       select i).Distinct();
                foreach (var item in nuclearBucketList)
                {
                    arrBucketList.Add(item.BucketCode);
                }
                arrBucketCodeArr = arrBucketList.ToArray();
                string[] sameArr = arrBucketCodeArr.Intersect(arrBucketCode).ToArray();
                string[] difArr = arrBucketCodeArr.Except(sameArr).ToArray();
                foreach (var item in difArr)
                {
                      var bucketModel = _NuclearBucketRepository.QueryListByCode(item, AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                      bucketModel.BucketStatus = "DRAINEMPTY";
                      _NuclearBucketRepository.UpdateBucketModel(bucketModel);
                }

                #endregion

                if (model.PrepareModel.Status == "2")
                {
                    model.PrepareModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.PrepareModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.PrepareModel.ConfirmDate = DateTime.Now;
                }
                if (_NuclearTsEbPrepareRepository.UpdatePrepare(model.PrepareModel, detailList))
                {
                    _NuclearTsEbPrepareRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "空桶准备记录删除")]
        public ActionResult DeletePrepare()
        {
            try
            {
                string id = Request["id"];
                var prepareModel = _NuclearTsEbPrepareRepository.Get(id);
                if (prepareModel != null)
                {
                    _NuclearTsEbPrepareRepository.Delete(prepareModel);
                    var list = _NuclearTsEbPrepareDetailRepository.GetAll().AsQueryable().Where(n => n.EbPrepareId == id);

                    foreach (NuclearPrepareDetail model in list)
                    {
                        _NuclearTsEbPrepareDetailRepository.Delete(model);
                        NuclearBucket bucket = _NuclearBucketRepository.Get(model.BucketId);
                        if (bucket != null)
                        {
                            if (bucket.BucketStatus != "EMPTY")
                            {
                                return Json("{\"result\":true,\"msg\":\"本批准备的桶中,有部分废物桶已经到了其他工序,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                            }
                        }
                    }

                    foreach (NuclearPrepareDetail model in list)
                    {
                        _NuclearTsEbPrepareDetailRepository.Delete(model);
                        NuclearBucket bucket = _NuclearBucketRepository.Get(model.BucketId);
                        if (bucket != null)
                        {
                            if (bucket.BucketStatus == "EMPTY")
                            {
                                bucket.BucketStatus = "DRAINEMPTY";
                                _NuclearBucketRepository.Update(bucket);
                            }
                        }
                    }

                    _NuclearTsEbPrepareRepository.UnitOfWork.Commit();
                }
                return Json("{\"result\":false,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmPrepare(EmptyPrepareVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsEbPrepare prepare = new NuclearTsEbPrepare();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    prepare = _NuclearTsEbPrepareRepository.GetTsEbPrepareModel(uid);
                else
                    prepare = _NuclearTsEbPrepareRepository.GetTsEbPrepareModel(model.PrepareModel.EbPrepareId);
                prepare.Status = "2";
                prepare.ConfirmUserNo = AppContext.CurrentUser.UserId;
                prepare.ConfirmUserName = AppContext.CurrentUser.UserName;
                prepare.ConfirmDate = DateTime.Now;

                if (_NuclearTsEbPrepareRepository.UpdatePrepare(prepare, null))
                {
                    _NuclearTsEbPrepareRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 检查桶号是否可用
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckBucketCode(string strCodeFrom, string strCodeTo,string bucketCode, string factoryId)
        {
            
                int startBucketCode = Convert.ToInt32(strCodeFrom);
                int endBucketCode = Convert.ToInt32(strCodeTo);
                string newBucketCode = string.Empty;
                for (int i = startBucketCode; i <= endBucketCode; i++)
                {
                    newBucketCode = newBucketCode + bucketCode + i.ToString().PadLeft(strCodeTo.Length, '0') + ",";
                }
                if (newBucketCode.Length > 0) newBucketCode = newBucketCode.TrimEnd(',');
                string[] arrayCode = newBucketCode.Split(new char[] { ',' });
                string nExistFactory = string.Empty;
                string nExistBucket = string.Empty;
                string nMassage = string.Empty;
                string nAllCode = string.Empty;
                try
                {
                if (arrayCode != null && arrayCode.Length > 0)
                {
                    foreach (string code in arrayCode)
                    {
                        if (string.IsNullOrEmpty(code)) continue;
                        string bucketCheck = _NuclearBucketRepository.IsExistEmptyWasteBucket(code, AppContext.CurrentUser.ProjectCode);
                        if (string.IsNullOrEmpty(bucketCheck))
                        {
                            nExistBucket += code + ",";
                        }
                        else
                        {
                            string existFactory = _NuclearBucketRepository.IsExistByFactory(code, AppContext.CurrentUser.ProjectCode, factoryId);
                            if (string.IsNullOrEmpty(existFactory))
                            {
                                nExistFactory += code + ",";
                            }

                        }
                    }
                }
                nExistFactory = nExistFactory.TrimEnd(new char[] { ',' });
                nExistBucket = nExistBucket.TrimEnd(new char[] { ',' });
                if (!string.IsNullOrEmpty(nExistBucket))
                {
                    nAllCode += nExistBucket + ",";
                    nMassage += "您填的桶" + nExistBucket + "不存在或者没有经过材料消耗已经经过了空桶准备。";
                }
                if (!string.IsNullOrEmpty(nExistFactory))
                {
                    nAllCode += nExistFactory + ",";
                    nMassage += "您填的桶" + nExistFactory + "不在所选厂房内。";
                }
                nAllCode = nAllCode.TrimEnd(new char[] { ',' });
                return Json("{\"result\":true,\"msg\":\"" + nMassage + "\",\"code\":\"" + nAllCode + "\",\"bucketCodes\":\"" + newBucketCode + "\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                nMassage = "提交失败，请检查桶号信息是否正确！";
                return Json("{\"result\":true,\"msg\":\"" + nMassage + "\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode=AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            IQueryable<NuclearBucket> iqueryBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsOutSend == "0" || e.IsOutSend == null));
            if (iqueryBucket.Count() > 0)
            {
                list = iqueryBucket.ToList();
            }
            //list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsOutSend == "0" || e.IsOutSend == null)).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 自动填充——废物跟踪单
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetTrackDataList(string keyword)
        {
            List<TrackItemVM> list = TrackItemBuilder.GetAllTrackList(keyword, AppContext.CurrentUser.ProjectCode).AsQueryable().ToList();//.Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count > 0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].TrackCode;
                    autoComplete.Code = list[i].TrackId;
                    autoCompleteList.Add(autoComplete);
                }

            }

            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
