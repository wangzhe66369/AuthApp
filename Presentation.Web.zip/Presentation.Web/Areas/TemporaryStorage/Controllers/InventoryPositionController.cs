﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
namespace RWIS.Presentation.Web.Areas.TemporaryStorage.Controllers
{
    public class InventoryPositionController : Controller
    {
        INuclearQtTransRepository _NuclearQtTransRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        INuclearCoverMetalRepository _NuclearCoverMetalRepository;
        INuclearCoverMixRepository _NuclearCoverMixRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        public InventoryPositionController(INuclearQtTransRepository NuclearQtTransRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IMaterialTypeRepository MaterialTypeRepository
            , IBasicObjectRepository BasicObjectRepository
            , INuclearTempstockRepository NuclearTempstockRepository
            , INuclearCoverMetalRepository NuclearCoverMetalRepository
            , INuclearCoverMixRepository NuclearCoverMixRepository
            , INuclearWastePackageRepository NuclearWastePackageRepository)
        {
            this._NuclearQtTransRepository = NuclearQtTransRepository;
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._MaterialTypeRepository = MaterialTypeRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NuclearTempstockRepository = NuclearTempstockRepository;
            this._NuclearCoverMetalRepository = NuclearCoverMetalRepository;
            this._NuclearCoverMixRepository = NuclearCoverMixRepository;
            this._NuclearWastePackageRepository = NuclearWastePackageRepository;
        }
        /// <summary>
        /// 库存信息列表
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "暂存库存")]
        public ActionResult Index()
        {
            InventoryPositionVM vm = new InventoryPositionVM();
            vm.FactoryList = new List<FactoryInfo>();
            vm.BucketTypeList = new List<BucketTypeInfo>();
            vm.Header = new List<string>();
            vm.Header.Add("厂房");
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            var listTempStock = _NuclearTempstockRepository.QueryList(AppContext.CurrentUser.ProjectCode).ToList();

            foreach (BasicObject basic in listBasicObject)
            {
                FactoryInfo info = new FactoryInfo();
                info.FactoryId = basic.Uuid;
                info.FactoryName = basic.Name;
                vm.FactoryList.Add(info);
            }
            MaterialTypeCondition condition = new MaterialTypeCondition();
            IQueryable<MaterialType> query = _MaterialTypeRepository.QueryList(condition).Where(x => x.Stationcode.ToUpper().Trim() == AppContext.CurrentUser.ProjectCode.ToUpper().Trim());
            List<MaterialType> listMaterial = new List<MaterialType>();
            if (query != null && query.Count() > 0)
            {
                listMaterial = query.ToList();
            }
            List<string> listWaste = new List<string>() { "浓缩液", "废树脂", "废滤芯", "淤积物", "废油和溶剂", "通风过滤器", "技术废物1", "技术废物2" };
            List<string> listWasteAbb = new List<string>() { "LIQUOR", "RESIN", "ELEMENT", "DEPOSIT", "SOLVENT", "FILTER", "TECH1", "TECH2" };
            if (listMaterial != null && listMaterial.Count > 0)
            {
                for (int k = 0; k < vm.FactoryList.Count; k++)
                {
                    foreach (MaterialType material in listMaterial)
                    {
                        if (k == 0)
                            vm.Header.Add(material.MaterialName);
                        BucketTypeInfo info = new BucketTypeInfo();
                        info.MaterialId = material.MaterialId;
                        info.BucketName = material.MaterialName;
                        info.FactoryId = vm.FactoryList[k].FactoryId;
                        info.Type = "0";
                        var listStock = listTempStock.Where(n => n.MaterialId == material.MaterialId && n.LocationId == vm.FactoryList[k].FactoryId && n.StockType == "MATERIAL").ToList();
                        if (listStock.Count > 0)
                        {
                            decimal? sumAmount = listStock.Sum(n => n.Amount);
                            decimal? sumCoverAmount = listStock.Sum(n => n.CoverAmount);
                            info.Amount = sumAmount == null ? 0 : sumAmount;
                            info.CoverAmount = sumCoverAmount == null ? 0 : sumCoverAmount;
                        }
                        else
                        {
                            info.Amount = 0;
                            info.CoverAmount = 0;
                        }
                        vm.BucketTypeList.Add(info);
                    }
                    for (int i = 0; i < listWaste.Count; i++)
                    {
                        if (k == 0)
                            vm.Header.Add(listWaste[i]);
                        BucketTypeInfo info = new BucketTypeInfo();
                        info.MaterialId = "0";
                        info.BucketName = listWaste[i];
                        info.FactoryId = vm.FactoryList[k].FactoryId;
                        info.Type = listWasteAbb[i];
                        var listStock = listTempStock.Where(n => n.StockType == listWasteAbb[i] && n.LocationId == vm.FactoryList[k].FactoryId && n.StockType != "MATERIAL").ToList();
                        if (listStock.Count > 0)
                        {
                            decimal? quantity = listStock.Sum(n => n.Amount) + listStock.Sum(n => n.CoverAmount);
                            info.Quantity = quantity == null ? 0 : quantity;
                        }
                        else
                        {
                            info.Quantity = 0;
                        }
                        vm.BucketTypeList.Add(info);
                    }
                }

            }
            return View(vm);
        }
        /// <summary>
        /// 定位图
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "暂存库存定位图")]
        public ActionResult PositionImg()
        {
            InventoryPositionVM vm = new InventoryPositionVM();
            //vm.TransList = new List<NuclearQtTrans>();
            vm.PointList = new List<ExistPointData>();
            string factoryId = Request["factory"];
            ViewBag.FactoryId = factoryId;
            string strPointX = string.Empty;
            string strPointY = string.Empty;
            var bucketList = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.LocationId == factoryId && !string.IsNullOrEmpty(n.XPosition) && !string.IsNullOrEmpty(n.YPosition) && n.ZPosition == "1");
            var packageList = _NuclearWastePackageRepository.GetBuildPackageList(AppContext.CurrentUser.ProjectCode);

            var exist =from b in bucketList
                           join p in packageList on b.BucketId equals p.BucketId into pEmpt
                           from p in pEmpt.DefaultIfEmpty()
                           select new
            {
                b.BucketId,
                b.BucketCode,
                p.PackageCode,
                b.XPosition,
                b.YPosition,
                b.ZPosition
            };
            //var existList = bucketList.Join(packageList, a => a.BucketId, b => b.BucketId, (a, b) => new
            //{
            //    a.BucketId,
            //    a.BucketCode,
            //    b.PackageCode,
            //    a.XPosition,
            //    a.YPosition,
            //    a.ZPosition
            //}).ToList();
            if (exist != null && exist.Count() > 0)
            {
                var existList = exist.ToList();
                for (int i = 0; i < existList.Count(); i++)
                {
                    ExistPointData data = new ExistPointData();
                    data.BucketId = existList[i].BucketId;
                    data.BucketCode = existList[i].BucketCode;
                    data.PackageCode = existList[i].PackageCode;
                    if (!string.IsNullOrEmpty(existList[i].XPosition))
                    {
                        if (existList[i].XPosition.Contains(","))
                        {
                            string pointX = string.Empty;
                            string pointY = string.Empty;
                            string[] strX = existList[i].XPosition.Split(new char[] { ',' });
                            string[] strY = existList[i].YPosition.Split(new char[] { ',' });
                            int minX = Convert.ToInt32(strX[0]);
                            int maxX = Convert.ToInt32(strX[1]);
                            int minY = Convert.ToInt32(strY[0]);
                            int maxY = Convert.ToInt32(strY[1]);
                            for (int m = 0; m <= maxY - minY; m++)
                            {
                                for (int n = 0; n <= maxX - minX; n++)
                                {
                                    pointX += (minX + n).ToString() + ",";
                                    pointY += (minY + m).ToString() + ",";
                                }
                            }
                            data.PointX = pointX.TrimEnd(new char[] { ',' });
                            data.PointY = pointY.TrimEnd(new char[] { ',' });
                        }
                        else
                        {
                            data.PointX = existList[i].XPosition;
                            data.PointY = existList[i].YPosition;
                        }
                        data.PointZ = existList[i].ZPosition;
                    }
                    vm.PointList.Add(data);
                }
            }

            #region"已注释"

            //var listTrans = _NuclearQtTransRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            //var listMetal = _NuclearCoverMetalRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            //var listMix = _NuclearCoverMixRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            //for (int i = 0; i < listTrans.Count; i++)
            //{
            //    ExistPointData data = new ExistPointData();
            //    data.BucketId = listTrans[i].BucketId;
            //    var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(listTrans[i].BucketId);
            //    if (bucketModel != null)
            //        data.BucketCode = bucketModel.BucketCode;
            //    data.PointX = listTrans[i].QtPositionX;
            //    data.PointY = listTrans[i].QtPositionY;
            //    vm.PointList.Add(data);
            //}
            //for (int i = 0; i < listMetal.Count; i++)
            //{
            //    ExistPointData data = new ExistPointData();
            //    data.BucketId = listMetal[i].BucketId;
            //    var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(listMetal[i].BucketId);
            //    if (bucketModel != null)
            //        data.BucketCode = bucketModel.BucketCode;
            //    data.PointX = listMetal[i].PositionX;
            //    data.PointY = listMetal[i].PositionY;
            //    vm.PointList.Add(data);
            //}
            //for (int i = 0; i < listMix.Count; i++)
            //{
            //    ExistPointData data = new ExistPointData();
            //    data.BucketId = listMix[i].BucketId;
            //    var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(listMix[i].BucketId);
            //    if (bucketModel != null)
            //        data.BucketCode = bucketModel.BucketCode;
            //    data.PointX = listMix[i].PositionX;
            //    data.PointY = listMix[i].PositionY;
            //    vm.PointList.Add(data);
            //}

            #endregion

            return View(vm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult TsRbInfo()
        {
            return View();
        }
        /// <summary>
        /// 根据层数获取坐标
        /// </summary>
        /// <returns></returns>
        public ActionResult GetPointByZ()
        {
            string pointZ = Request["pointZ"];
            string factoryId = Request["factory"];
            string strPointX = string.Empty;
            string strPointY = string.Empty;
            string strBucketId = string.Empty;
            string strBucketCode = string.Empty;
            string strPackageCode = string.Empty;
            var bucketList = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.LocationId == factoryId && !string.IsNullOrEmpty(n.XPosition) && !string.IsNullOrEmpty(n.YPosition) && n.ZPosition == pointZ).ToList();
            var packageList = _NuclearWastePackageRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (bucketList.Count > 0)
            {
                for (int i = 0; i < bucketList.Count; i++)
                {
                    if (bucketList[i].XPosition.Contains(","))
                    {
                        string[] strX = bucketList[i].XPosition.Split(new char[] { ',' });
                        string[] strY = bucketList[i].YPosition.Split(new char[] { ',' });
                        int minX = Convert.ToInt32(strX[0]);
                        int maxX = Convert.ToInt32(strX[1]);
                        int minY = Convert.ToInt32(strY[0]);
                        int maxY = Convert.ToInt32(strY[1]);
                        for (int m = 0; m <= maxY - minY; m++)
                        {
                            for (int n = 0; n <= maxX - minX; n++)
                            {
                                strPointX += (minX + n).ToString() + ",";
                                strPointY += (minY + m).ToString() + ",";
                                strBucketId += bucketList[i].BucketId + ",";
                                strBucketCode += bucketList[i].BucketCode + ",";
                                var pList = packageList.Where(p => p.BucketId == bucketList[i].BucketId).ToList();
                                if (pList.Count > 0)
                                    strPackageCode += pList[0].PackageCode + ",";
                                else
                                    strPackageCode += "" + ",";
                            }
                        }
                    }
                    else
                    {
                        strPointX += bucketList[i].XPosition + ",";
                        strPointY += bucketList[i].YPosition + ",";
                        strBucketId += bucketList[i].BucketId + ",";
                        strBucketCode += bucketList[i].BucketCode + ",";
                        var pList = packageList.Where(p => p.BucketId == bucketList[i].BucketId).ToList();
                        if (pList.Count > 0)
                            strPackageCode += pList[0].PackageCode + ",";
                        else
                            strPackageCode += "" + ",";

                    }

                }
                string result = string.Empty;
                if (strPointX != string.Empty && strPointY != string.Empty)
                    result = strPointX.TrimEnd(new char[] { ',' }) + "=" + strPointY.TrimEnd(new char[] { ',' }) + "=" + strBucketId.TrimEnd(new char[] { ',' }) + "=" + strBucketCode.TrimEnd(new char[] { ',' }) + "=" + strPackageCode.TrimEnd(new char[] { ',' });
                return Json("{\"result\":true,\"msg\":\"" + result + "\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"\"}", JsonRequestBehavior.AllowGet);
        }
    }
}
