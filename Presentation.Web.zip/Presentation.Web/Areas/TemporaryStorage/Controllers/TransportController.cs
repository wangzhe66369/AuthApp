﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModelBuilder;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using System.Web;
using System.Data;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using OMP.Domain.DomainObjects;
using OMP.Domain.Repositories;
using MvcContrib.Sorting;


namespace RWIS.Presentation.Web.Areas.TemporaryStorage.Controllers
{
    public class TransportController : Controller
    {
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        INuclearCoverMetalRepository _NuclearCoverMetalRepository;
        INuclearCoverMixRepository _NuclearCoverMixRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        INuclearTsGoodsRepository _NuclearTsGoodsRepository;
        INuclearFcTransRepository _NuclearFcTransRepository;
        INuclearQtTransRepository _NuclearQtTransRepository;
        IQtTranTicketRepository _QtTranTicketRepository;
        public TransportController(
              INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository
            , INuclearTempstockRepository NuclearTempstockRepository
            , INuclearCoverMetalRepository NuclearCoverMetalRepository
            , INuclearCoverMixRepository NuclearCoverMixRepository           
            , INuclearWastePackageRepository NuclearWastePackageRepository
            , INuclearTsGoodsRepository NuclearTsGoodsRepository
            , INuclearFcTransRepository NuclearFcTransRepository
            , INuclearQtTransRepository NuclearQtTransRepository
            , IQtTranTicketRepository _QtTranTicketRepository
            )
        {
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NuclearTempstockRepository = NuclearTempstockRepository;
            this._NuclearCoverMetalRepository = NuclearCoverMetalRepository;
            this._NuclearCoverMixRepository = NuclearCoverMixRepository;
            this._NuclearWastePackageRepository = NuclearWastePackageRepository;
            this._NuclearTsGoodsRepository = NuclearTsGoodsRepository;
            this._NuclearFcTransRepository = NuclearFcTransRepository;
            this._NuclearQtTransRepository = NuclearQtTransRepository;
            this._QtTranTicketRepository = _QtTranTicketRepository;
        }
        #region Qt贮存单

        public ActionResult IndexQt()
        {
            QtTranTicketVM vm = new QtTranTicketVM();
            //vm.OperationList = CommonHelper.GetOperationList("Transport");

            return View(vm);
        }
        public ActionResult EditQt(string id)
        {
            QtTranTicketVM vm = new QtTranTicketVM();
            //vm.OperationList = CommonHelper.GetOperationList("Transport");
            if (string.IsNullOrEmpty(id))
            {
                vm.QtTranTicket = new QtTranTicket();
            }
            else
            {
                vm.QtTranTicket = _QtTranTicketRepository.Get(id);
            }

            return View(vm);
        }
        /// <summary>
        /// 初始化查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetTransList(string packageCode, string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<QtTranTicket> data = this._QtTranTicketRepository.QueryList(packageCode).Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).OrderBy("CreateDate", SortDirection.Descending);
            var pagedViewModel = new PagedViewModel<QtTranTicket>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.Id,
                    List = new List<object>() {
                    d.Id,
                    d.PackeageCode,
                    d.WorcktCode,
                    d.TranDate.HasValue?d.TranDate.ToShortDate():"",
                    d.StartX + "-" +d.StartY +"-"+d.StartZ,
                    d.EndX + "-" +d.EndY +"-"+d.EndZ,
                    d.Status
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }


        public JsonResult SaveDraft(QtTranTicketVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {

                NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == model.QtTranTicket.PackeageCode).FirstOrDefault();
                if (nuclearWastePackage == null)
                {
                    return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                //新增保存
                if (string.IsNullOrEmpty(model.QtTranTicket.Id))
                {
                    model.QtTranTicket.Id = Guid.NewGuid().ToString();
                    model.QtTranTicket.Status = "0";
                    model.QtTranTicket.CreateDate = DateTime.Now;
                    model.QtTranTicket.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.QtTranTicket.CreateUserName = AppContext.CurrentUser.UserName;
                    model.QtTranTicket.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._QtTranTicketRepository.Create(model.QtTranTicket);
                    this._QtTranTicketRepository.UnitOfWork.Commit();
                }//修改保存
                else
                {
                    model.QtTranTicket = _QtTranTicketRepository.Get(model.QtTranTicket.Id);
                    UpdateModel(model);
                    model.QtTranTicket.Status = "0";
                    this._QtTranTicketRepository.Update(model.QtTranTicket);
                    this._QtTranTicketRepository.UnitOfWork.Commit();
                }

                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        public JsonResult CommitMaterial(QtTranTicketVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try
            {
                NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == model.QtTranTicket.PackeageCode).FirstOrDefault();
                if (nuclearWastePackage == null)
                {
                    return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                //新增提交
                if (string.IsNullOrEmpty(model.QtTranTicket.Id))
                {
                    model.QtTranTicket.Id = Guid.NewGuid().ToString();
                    model.QtTranTicket.Status = "1";
                    model.QtTranTicket.CreateDate = DateTime.Now;
                    model.QtTranTicket.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.QtTranTicket.CreateUserName = AppContext.CurrentUser.UserName;
                    model.QtTranTicket.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._QtTranTicketRepository.Create(model.QtTranTicket);
                    this._QtTranTicketRepository.UnitOfWork.Commit();
                }//修改提交
                else
                {
                    model.QtTranTicket = _QtTranTicketRepository.Get(model.QtTranTicket.Id);
                    UpdateModel(model);
                    model.QtTranTicket.Status = "1";
                    this._QtTranTicketRepository.Update(model.QtTranTicket);
                    this._QtTranTicketRepository.UnitOfWork.Commit();
                }

                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        public JsonResult ConfirmMaterial(QtTranTicketVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return Json("{\"result\":false,\"msg\":\"未验证。\"}", JsonRequestBehavior.AllowGet);
            }

            try

            {
                NuclearWastePackage nuclearWastePackage = _NuclearWastePackageRepository.GetAll().Where(d => d.PackageCode == model.QtTranTicket.PackeageCode).FirstOrDefault();
                if (nuclearWastePackage == null)
                {
                    return Json("{\"result\":false,\"msg\":\"废物货包不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                //新增确认
                if (string.IsNullOrEmpty(model.QtTranTicket.Id))
                {
                    model.QtTranTicket.Id = Guid.NewGuid().ToString();
                    model.QtTranTicket.Status = "2";
                    model.QtTranTicket.CreateDate = DateTime.Now;
                    model.QtTranTicket.CreateUserNo = AppContext.CurrentUser.UserId;
                    model.QtTranTicket.CreateUserName = AppContext.CurrentUser.UserName;
                    model.QtTranTicket.Stationcode = AppContext.CurrentUser.ProjectCode;
                    model.QtTranTicket.ConfirmDate = DateTime.Now;
                    model.QtTranTicket.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.QtTranTicket.ConfirmUserName = AppContext.CurrentUser.UserName;
                    this._QtTranTicketRepository.Create(model.QtTranTicket);
                    this._QtTranTicketRepository.UnitOfWork.Commit();
                }//修改确认
                else
                {
                    model.QtTranTicket = _QtTranTicketRepository.Get(model.QtTranTicket.Id);
                    UpdateModel(model);
                    model.QtTranTicket.Status = "2";
                    model.QtTranTicket.ConfirmDate = DateTime.Now;
                    model.QtTranTicket.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.QtTranTicket.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.QtTranTicket.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._QtTranTicketRepository.Update(model.QtTranTicket);
                    this._QtTranTicketRepository.UnitOfWork.Commit();
                }

                return Json("{\"result\":true,\"msg\":\"确认成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确认失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult DeleteQt(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._QtTranTicketRepository.DeleteById(idVal);
                    }
                    this._QtTranTicketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }

        #endregion


        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "封盖后贮存")]
        public ActionResult Index()
        {
            TransportVM vm = new TransportVM();
            vm.OperationList = CommonHelper.GetOperationList("Transport");
            return View(vm);
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "转运")]
        public ActionResult IndexFactory()
        {
            TransportVM vm = new TransportVM();
            vm.OperationList = CommonHelper.GetOperationList("Transport");
            return View(vm);
        }
        /// <summary>
        /// 选择定位
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "选择定位")]
        public ActionResult Position(string factory)
        {
            TransportVM vm = new TransportVM();
            vm.PointList = new List<PointData>();
            var QTList = _NuclearQtTransRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            var FcList = _NuclearFcTransRepository.GetDetailQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.FactoryId == factory).ToList();
            var MetalList = _NuclearCoverMetalRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            var MixList = _NuclearCoverMixRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            var bucketList = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(d => d.LocationId == factory).ToList();
            var packageList = _NuclearWastePackageRepository.GetAll().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            for (int i = 1; i < 6; i++)
            {
                string a = i.ToString();
                string pointX = string.Empty;
                string pointY = string.Empty;
                string bucketCode = string.Empty;
                string packageCode = string.Empty;
                var qt = bucketList.Where(n => n.ZPosition == a).ToList();
                //var qt = QTList.Where(n => n.QtPositionZ == a).ToList();
                for (int k = 0; k < qt.Count; k++)
                {
                    if (string.IsNullOrEmpty(qt[k].XPosition)) continue;

                    if (qt[k].XPosition.Contains(","))
                    {
                        string[] strX = qt[k].XPosition.Split(new char[] { ',' });
                        string[] strY = qt[k].YPosition.Split(new char[] { ',' });
                        int minX = Convert.ToInt32(strX[0]);
                        int maxX = Convert.ToInt32(strX[1]);
                        int minY = Convert.ToInt32(strY[0]);
                        int maxY = Convert.ToInt32(strY[1]);
                        for (int m = 0; m <= maxY - minY; m++)
                        {
                            for (int n = 0; n <= maxX - minX; n++)
                            {
                                pointX += (minX + n).ToString() + ",";
                                pointY += (minY + m).ToString() + ",";
                                var bList = bucketList.Where(p => p.BucketId == qt[k].BucketId).ToList();
                                if (bList.Count > 0)
                                    bucketCode += bList[0].BucketCode + ",";
                                else
                                    bucketCode += "" + ",";
                                var pList = packageList.Where(p => p.BucketId == qt[k].BucketId).ToList();
                                if (pList.Count > 0)
                                    packageCode += pList[0].PackageCode + ",";
                                else
                                    packageCode += "" + ",";
                            }
                        }
                    }
                    else
                    {
                        pointX += qt[k].XPosition + ",";
                        pointY += qt[k].YPosition + ",";
                        var bList = bucketList.Where(p => p.BucketId == qt[k].BucketId).ToList();
                        if (bList.Count > 0)
                            bucketCode += bList[0].BucketCode + ",";
                        else
                            bucketCode += "" + ",";
                        var pList = packageList.Where(p => p.BucketId == qt[k].BucketId).ToList();
                        if (pList.Count > 0)
                            packageCode += pList[0].PackageCode + ",";
                        else
                            packageCode += "" + ",";
                    }
                }
                var fc = bucketList.Where(n => n.ZPosition == a).ToList();
                //var fc = FcList.Where(n => n.PositionZ == a).ToList();
                for (int k = 0; k < fc.Count; k++)
                {
                    if (string.IsNullOrEmpty(fc[k].XPosition)) continue;
                    if (fc[k].XPosition.Contains(","))
                    {
                        string[] strX = fc[k].XPosition.Split(new char[] { ',' });
                        string[] strY = fc[k].YPosition.Split(new char[] { ',' });
                        int minX = Convert.ToInt32(strX[0]);
                        int maxX = Convert.ToInt32(strX[1]);
                        int minY = Convert.ToInt32(strY[0]);
                        int maxY = Convert.ToInt32(strY[1]);
                        for (int m = 0; m <= maxY - minY; m++)
                        {
                            for (int n = 0; n <= maxX - minX; n++)
                            {
                                pointX += (minX + n).ToString() + ",";
                                pointY += (minY + m).ToString() + ",";
                                var bList = bucketList.Where(p => p.BucketId == fc[k].BucketId).ToList();
                                if (bList.Count > 0)
                                    bucketCode += bList[0].BucketCode + ",";
                                else
                                    bucketCode += "" + ",";
                                var pList = packageList.Where(p => p.BucketId == fc[k].BucketId).ToList();
                                if (pList.Count > 0)
                                    packageCode += pList[0].PackageCode + ",";
                                else
                                    packageCode += "" + ",";
                            }
                        }
                    }
                    else
                    {
                        pointX += fc[k].XPosition + ",";
                        pointY += fc[k].YPosition + ",";
                        var bList = bucketList.Where(p => p.BucketId == fc[k].BucketId).ToList();
                        if (bList.Count > 0)
                            bucketCode += bList[0].BucketCode + ",";
                        else
                            bucketCode += "" + ",";
                        var pList = packageList.Where(p => p.BucketId == fc[k].BucketId).ToList();
                        if (pList.Count > 0)
                            packageCode += pList[0].PackageCode + ",";
                        else
                            packageCode += "" + ",";
                    }
                }
                //var metal = MetalList.Where(n => n.PositionZ == a).ToList();
                var metal = bucketList.Where(n => n.ZPosition == a).ToList();
                for (int k = 0; k < metal.Count; k++)
                {
                    if (string.IsNullOrEmpty(metal[k].XPosition)) continue;
                    if (metal[k].XPosition.Contains(","))
                    {
                        string[] strX = metal[k].XPosition.Split(new char[] { ',' });
                        string[] strY = metal[k].YPosition.Split(new char[] { ',' });
                        int minX = Convert.ToInt32(strX[0]);
                        int maxX = Convert.ToInt32(strX[1]);
                        int minY = Convert.ToInt32(strY[0]);
                        int maxY = Convert.ToInt32(strY[1]);
                        for (int m = 0; m <= maxY - minY; m++)
                        {
                            for (int n = 0; n <= maxX - minX; n++)
                            {
                                pointX += (minX + n).ToString() + ",";
                                pointY += (minY + m).ToString() + ",";
                                var bList = bucketList.Where(p => p.BucketId == metal[k].BucketId).ToList();
                                if (bList.Count > 0)
                                    bucketCode += bList[0].BucketCode + ",";
                                else
                                    bucketCode += "" + ",";
                                var pList = packageList.Where(p => p.BucketId == metal[k].BucketId).ToList();
                                if (pList.Count > 0)
                                    packageCode += pList[0].PackageCode + ",";
                                else
                                    packageCode += "" + ",";
                            }
                        }
                    }
                    else
                    {
                        pointX += metal[k].XPosition + ",";
                        pointY += metal[k].YPosition + ",";
                        var bList = bucketList.Where(p => p.BucketId == metal[k].BucketId).ToList();
                        if (bList.Count > 0)
                            bucketCode += bList[0].BucketCode + ",";
                        else
                            bucketCode += "" + ",";
                        var pList = packageList.Where(p => p.BucketId == metal[k].BucketId).ToList();
                        if (pList.Count > 0)
                            packageCode += pList[0].PackageCode + ",";
                        else
                            packageCode += "" + ",";
                    }
                }
                //var mix = MixList.Where(n => n.PositionZ == a).ToList();
                var mix = bucketList.Where(n => n.ZPosition == a).ToList();
                
                for (int k = 0; k < mix.Count; k++)
                {
                    if (string.IsNullOrEmpty(mix[k].XPosition)) continue;
                    if (mix[k].XPosition.Contains(","))
                    {
                        string[] strX = mix[k].XPosition.Split(new char[] { ',' });
                        string[] strY = mix[k].YPosition.Split(new char[] { ',' });
                        int minX = Convert.ToInt32(strX[0]);
                        int maxX = Convert.ToInt32(strX[1]);
                        int minY = Convert.ToInt32(strY[0]);
                        int maxY = Convert.ToInt32(strY[1]);
                        for (int m = 0; m <= maxY - minY; m++)
                        {
                            for (int n = 0; n <= maxX - minX; n++)
                            {
                                pointX += (minX + n).ToString() + ",";
                                pointY += (minY + m).ToString() + ",";
                                var bList = bucketList.Where(p => p.BucketId == mix[k].BucketId).ToList();
                                if (bList.Count > 0)
                                    bucketCode += bList[0].BucketCode + ",";
                                else
                                    bucketCode += "" + ",";
                                var pList = packageList.Where(p => p.BucketId == mix[k].BucketId).ToList();
                                if (pList.Count > 0)
                                    packageCode += pList[0].PackageCode + ",";
                                else
                                    packageCode += "" + ",";
                            }
                        }
                    }
                    else
                    {
                        pointX += mix[k].XPosition + ",";
                        pointY += mix[k].YPosition + ",";
                        var bList = bucketList.Where(p => p.BucketId == mix[k].BucketId).ToList();
                        if (bList.Count > 0)
                            bucketCode += bList[0].BucketCode + ",";
                        else
                            bucketCode += "" + ",";
                        var pList = packageList.Where(p => p.BucketId == mix[k].BucketId).ToList();
                        if (pList.Count > 0)
                            packageCode += pList[0].PackageCode + ",";
                        else
                            packageCode += "" + ",";
                    }
                }
                pointX = pointX.TrimEnd(new char[] { ',' });
                pointY = pointY.TrimEnd(new char[] { ',' });
                PointData point = new PointData();
                point.PointX = pointX;
                point.PointY = pointY;
                point.PointZ = a;
                point.BucketCode = bucketCode;
                point.PackageCode = packageCode;
                vm.PointList.Add(point);
            }
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(QTTransCondition transCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            string stationCode=AppContext.CurrentUser.ProjectCode;
            var queryQtTrans = _NuclearQtTransRepository.GetQueryList().Where(n => n.Stationcode == stationCode).ToList();
            if (!string.IsNullOrEmpty(transCondition.TicketCode))
            {
                queryQtTrans = queryQtTrans.Where(n => n.TicketCode.ToUpper().Contains(transCondition.TicketCode)).ToList();
            }
            if (!string.IsNullOrEmpty(transCondition.BucketCode))
            {
                var listBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.BucketCode.ToUpper().Contains(transCondition.BucketCode.ToUpper())).ToList();
                List<string> listId = new List<string>();
                for (int i = 0; i < listBucket.Count; i++)
                {
                    listId.Add(listBucket[i].BucketId);
                }
                queryQtTrans = queryQtTrans.Where(n => listId.Contains(n.BucketId)).ToList();
            }
            if (!string.IsNullOrEmpty(transCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(transCondition.StartDate);
                queryQtTrans = queryQtTrans.Where(n => n.ProcessDate >= sDate).ToList();
            }
            if (!string.IsNullOrEmpty(transCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(transCondition.EndDate);
                queryQtTrans = queryQtTrans.Where(n => n.ProcessDate <= eDate).ToList();
            }
            List<QTTransList> pList = new List<QTTransList>();
            if (queryQtTrans != null)
            {
                for (int i = 0; i < queryQtTrans.Count; i++)
                {
                    var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(queryQtTrans[i].BucketId);
                    var basicObject = _BasicObjectRepository.GetAll().Where(d => d.Uuid == queryQtTrans[i].SavePosition).FirstOrDefault();
                    if (bucketModel == null) continue;
                    QTTransList trans = new QTTransList();
                    trans.TransId = queryQtTrans[i].QtTransId;
                    trans.TransType = "0";
                    trans.TransTypeName = "封盖后贮存";
                    trans.TicketCode = queryQtTrans[i].TicketCode;
                    trans.BucketCode = bucketModel.BucketCode;
                    if (queryQtTrans[i].ProcessDate != null)
                        trans.TransDate = Convert.ToDateTime(queryQtTrans[i].ProcessDate.ToString()).ToShortDateString();
                    trans.Status = queryQtTrans[i].Status;
                    trans.CreateDate = queryQtTrans[i].CreateDate;
                    trans.DoseEva = queryQtTrans[i].DoseEva;
                    trans.DoseMeter = queryQtTrans[i].DoseMeter;
                    trans.BucketWeight = queryQtTrans[i].BucketWeight;
                    if (basicObject != null)
                    {
                        trans.SavePosition = basicObject.Name;
                    }
                    
                    trans.Activity = queryQtTrans[i].Activity;
                    trans.ProcessName = string.IsNullOrEmpty(queryQtTrans[i].ProcessName) ? "" : "[" + queryQtTrans[i].ProcessNo + "]" + queryQtTrans[i].ProcessName;
                    trans.Station=AppContext.CurrentUser.ProjectCode;
                    trans.SlectA = queryQtTrans[i].SlectA;
                      trans.QtPositionX = queryQtTrans[i].QtPositionX;
                     trans.QtPositionY = queryQtTrans[i].QtPositionY;
                     trans.QtPositionZ = queryQtTrans[i].QtPositionZ;
                     trans.BucketId = queryQtTrans[i].BucketId;
                    pList.Add(trans);
                }
            }
            pList = pList.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<QTTransList> data = pList.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<QTTransList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.TransId,
                    List = new List<object>() {
                    d.TransId,
                    d.BucketId,
                    d.TransType,
                    d.TransTypeName,
                    d.BucketCode,
                    d.TicketCode,
                    d.DoseEva ,
                    d.DoseMeter,
                    d.BucketWeight,
                     d.Station=="FCGNP"?d.SlectA +" " +d.QtPositionX+"-"+d.QtPositionY+"-"+d.QtPositionZ:"",
                    d.Activity,
                    d.ProcessName,
                   // d.BucketCode,
                    d.TransDate,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataListFactory(QTTransCondition transCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var queryFcTrans = _NuclearFcTransRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode);
            if (!string.IsNullOrEmpty(transCondition.TicketCode))
            {
                queryFcTrans = queryFcTrans.Where(n => n.WorkTicket.ToUpper().Contains(transCondition.TicketCode));
            }
            if (!string.IsNullOrEmpty(transCondition.BucketCode))
            {
                var listBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.BucketCode.ToUpper().Contains(transCondition.BucketCode.ToUpper())).ToList();
                List<string> listId = new List<string>();
                for (int i = 0; i < listBucket.Count; i++)
                {
                    listId.Add(listBucket[i].BucketId);
                }
                var queryFcTransDetail = _NuclearFcTransRepository.GetDetailQueryList().Where(n => listId.Contains(n.BucketId)).ToList();
                if (queryFcTransDetail != null && queryFcTransDetail.Count > 0)
                {
                    List<string> listFcTransId = queryFcTransDetail.Select(n => n.FcTransId).ToList();
                    queryFcTrans = queryFcTrans.Where(n => listFcTransId.Contains(n.FcTransId));
                }
            }
            if (!string.IsNullOrEmpty(transCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(transCondition.StartDate);
                queryFcTrans = queryFcTrans.Where(n => n.ProcessDate >= sDate);
            }
            if (!string.IsNullOrEmpty(transCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(transCondition.EndDate);
                queryFcTrans = queryFcTrans.Where(n => n.ProcessDate <= eDate);
            }
            List<QTTransList> pList = new List<QTTransList>();
            if (queryFcTrans != null)
            {
                if (queryFcTrans.Count() > 0)
                {
                    List<NuclearFcTrans> queryFcTransList = queryFcTrans.ToList();
                    for (int i = 0; i < queryFcTransList.Count; i++)
                    {
                        //var bucketModel = _NuclearBucketRepository.GetBucketInfoModel("");
                        //if (bucketModel == null) continue;
                        QTTransList trans = new QTTransList();
                        trans.TransId = queryFcTransList[i].FcTransId;
                        trans.TransType = "1";
                        trans.TransTypeName = "厂房间废物桶转运";
                        trans.TicketCode = queryFcTransList[i].WorkTicket;

                        IQueryable<NuclearFcTransDetail> queryFcTransDetail = _NuclearFcTransRepository.GetDetailListById(queryFcTransList[i].FcTransId);
                        IQueryable<NuclearBucket> queryBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode);

                        queryBucket = from f in queryBucket
                                      join s in queryFcTransDetail
                                             on f.BucketId equals s.BucketId
                                      select f;
                        if (queryBucket.Count() > 0)
                        {
                            foreach (var item in queryBucket)
                            {
                                trans.BucketCode = trans.BucketCode + item.BucketCode + ",";
                            }

                        }


                        if (queryFcTransList[i].ProcessDate != null)
                            trans.TransDate = Convert.ToDateTime(queryFcTransList[i].ProcessDate.ToString()).ToShortDateString();
                        trans.Status = queryFcTransList[i].Status;
                        trans.CreateDate = queryFcTransList[i].CreateDate;
                        BasicObject basicObjectFrom = _BasicObjectRepository.Get(queryFcTransList[i].FactoryFrom);
                        if (basicObjectFrom != null)
                        {
                            trans.FactoryFrom = basicObjectFrom.Name;
                        }
                        BasicObject basicObjectTo = _BasicObjectRepository.Get(queryFcTransList[i].FactoryTo);
                        if (basicObjectTo != null)
                        {
                            trans.FactoryTo = basicObjectTo.Name;
                        }

                        pList.Add(trans);
                    }
                }
               
            }
            pList = pList.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<QTTransList> data = pList.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<QTTransList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.TransId,
                    List = new List<object>() {
                    d.TransId,
                    d.TransType,
                    d.TransTypeName,
                    d.TicketCode,
                    d.BucketCode,
                    d.FactoryFrom,
                    d.FactoryTo,
                    d.TransDate,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        #region"废物货包转运及QT贮存移动单"

        /// <summary>
        /// 废物货包转运及QT贮存移动单
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废物货包转运及QT贮存移动单")]
        public ActionResult QTTransfer()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            string bucketCode = string.Empty;
           // string trackCode = string.Empty;
            TransportVM vm = new TransportVM();
            vm.OperationList = CommonHelper.GetOperationList("QT_Transfer");
            vm.FactoryList = new List<SelectListItem>();
            vm.BucketTypeList = new List<SelectListItem>();
            vm.SavePositionList = new List<SelectListItem>();
            vm.TransModel = new NuclearQtTrans();
            vm.DetailList = new List<DetailList>();
            vm.DetailBList = new List<DetailBList>();
            vm.PointList = new List<PointData>();



            //IQueryable<NuclearTsGoodsDetail> nuclearTsGoodsDetail=_NuclearTsGoodsRepository.GetDetalList();
            //IQueryable<NuclearQtTransDetail> nuclearQtTransDetail = _NuclearQtTransRepository.GetDetail();
            //IQueryable<NuclearFcTransDetail> nuclearFcTransDetail = _NuclearFcTransRepository.GetDetailQueryList();
            //if (nuclearTsGoodsDetail.Count() > 0)
            //{
            //    if (nuclearTsGoodsDetail.ToList()[0].Weight != null)
            //    {
            //        vm.TransModel.BucketWeight = nuclearTsGoodsDetail.ToList()[0].Weight;
            //    }
            //}
            //if (nuclearQtTransDetail.Count() > 0)
            //{
            //    if (nuclearQtTransDetail.ToList()[0]. != null)
            //    {
            //        vm.TransModel.BucketWeight = nuclearQtTransDetail.ToList()[0].Weight;
            //    }
            //}
            //if (nuclearFcTransDetail.Count() > 0)
            //{
            //     if (nuclearFcTransDetail.ToList()[0].BucketWeight != null)
            //    {
            //        vm.TransModel.BucketWeight = nuclearFcTransDetail.ToList()[0].BucketWeight;
            //    }
            //}



            List<BasicObject> listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryFactory = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            if (queryFactory != null && queryFactory.Count() > 0)
            {
                listBasicObject = queryFactory.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryBucket = _BasicObjectRepository.GetSubobjectsByCode("Bucket", AppContext.CurrentUser.ProjectCode);
            if (queryBucket != null && queryBucket.Count() > 0)
            {
                listBasicObject = queryBucket.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }

            IQueryable<BasicObject> querySavePosition = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);

            if (querySavePosition != null && querySavePosition.Count() > 0)
            {
                listBasicObject = querySavePosition.Where(d=>d.Name.ToUpper().Contains("QT")).ToList();
                foreach (BasicObject basic in listBasicObject)
                {
                    vm.SavePositionList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
                }
            }
           


            if (!string.IsNullOrEmpty(uid))
            {
                var dataList = _NuclearQtTransRepository.GetDetailById(uid).ToList();
                var dataListB = _NuclearQtTransRepository.GetDetailBById(uid).ToList();
                if (dataList != null && dataList.Count > 0)
                {
                    foreach (NuclearQtTransDetail detail in dataList)
                    {
                        DetailList model = new DetailList();
                        model.DetailId = detail.QtTransDetailId;
                        model.FactoryFromId = detail.FactoryFromId;
                        model.FactoryToId = detail.FactoryToId;
                        model.QtFactoryId = detail.QtFactoryId;
                        var factoryFrom = _BasicObjectRepository.GetBasicById(detail.FactoryFromId);
                        if (factoryFrom != null)
                            model.FactoryFrom = factoryFrom.Name;
                        var factoryTo = _BasicObjectRepository.GetBasicById(detail.FactoryToId);
                        if (factoryTo != null)
                            model.FactoryTo = factoryTo.Name;
                        var qtFactory = _BasicObjectRepository.GetBasicById(detail.QtFactoryId);
                        if (qtFactory != null)
                            model.QtFactory = qtFactory.Name;
                        else
                            model.QtFactory = string.Empty;


                        if (detail.FixationDate != null)
                            model.FixationDate = Convert.ToDateTime(detail.FixationDate.ToString()).ToShortDateString();
                        if (detail.TransDate != null)
                            model.TransDate = Convert.ToDateTime(detail.TransDate.ToString()).ToShortDateString();
                        model.TransTicket = detail.TransTicket;
                        model.ControlNo = detail.ProcessNo;
                        model.ControlName = detail.ProcessName;
                        vm.DetailList.Add(model);
                    }
                }
                if (dataListB != null && dataListB.Count > 0)
                {
                    foreach (NuclearQtTransDetailB detail in dataListB)
                    {
                        DetailBList model = new DetailBList();
                        model.DetailBId = detail.QtTransDetailIdB;
                        model.FactoryFromId = detail.FactoryFromId;
                        model.FactoryToId = detail.FactoryToId;
                        model.QtFactoryId = detail.QtFactoryId;
                        var factoryFrom = _BasicObjectRepository.GetBasicById(detail.FactoryFromId);
                        if (factoryFrom != null)
                            model.FactoryFrom = factoryFrom.Name;
                        var factoryTo = _BasicObjectRepository.GetBasicById(detail.FactoryToId);
                        if (factoryTo != null)
                            model.FactoryTo = factoryTo.Name;
                        var qtFactory = _BasicObjectRepository.GetBasicById(detail.QtFactoryId);
                        if (qtFactory != null)
                            model.QtFactory = qtFactory.Name;
                        else
                            model.QtFactory = string.Empty;
                        model.OverDate = detail.OverDate.HasValue?detail.OverDate.Value.ToString("yyyy-MM-dd"):string.Empty;
                        model.TransDate = detail.TransDate.HasValue ? detail.TransDate.Value.ToString("yyyy-MM-dd") : string.Empty;
                        model.TransTicket = detail.TransTicket;
                        model.ControlNo = detail.ProcessNo;
                        model.ControlName = detail.ProcessName;
                        vm.DetailBList.Add(model);
                    }
                }
                vm.TransModel = _NuclearQtTransRepository.GetModelById(uid);
                detailFlag = "edit";
                var transModel = _NuclearQtTransRepository.GetModelById(uid);
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(transModel.BucketId);
                if (bucketModel != null)
                    bucketCode = bucketModel.BucketCode;
                //var trackModel = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == transModel.TrackId).ToList();
                //if (trackModel != null && trackModel.Count > 0)
                //    trackCode = trackModel[0].TrackCode;
                ViewBag.BucketCode = bucketCode;
                //ViewBag.TrackCode = trackCode;
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            ViewBag.ViewStatus = Request["status"];
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            #region"position"

            //var QTList = _NuclearQtTransRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            //var MetalList = _NuclearCoverMetalRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            //var MixList = _NuclearCoverMixRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            //for (int i = 1; i < 6; i++)
            //{
            //    string a = i.ToString();
            //    string pointX = string.Empty;
            //    string pointY = string.Empty;
            //    var qt = QTList.Where(n => n.QtPositionZ == a).ToList();
            //    for (int k = 0; k < qt.Count; k++)
            //    {
            //        if (string.IsNullOrEmpty(qt[k].QtPositionX)) continue;
            //        if (qt[k].QtPositionX.Contains(","))
            //        {
            //            string[] strX = qt[k].QtPositionX.Split(new char[] { ',' });
            //            string[] strY = qt[k].QtPositionY.Split(new char[] { ',' });
            //            int minX = Convert.ToInt32(strX[0]);
            //            int maxX = Convert.ToInt32(strX[1]);
            //            int minY = Convert.ToInt32(strY[0]);
            //            int maxY = Convert.ToInt32(strY[1]);
            //            for (int m = 0; m <= maxY - minY; m++)
            //            {
            //                for (int n = 0; n <= maxX - minX; n++)
            //                {
            //                    pointX += (minX + n).ToString() + ",";
            //                    pointY += (minY + m).ToString() + ",";
            //                }
            //            }
            //        }
            //        else
            //        {
            //            pointX += qt[k].QtPositionX + ",";
            //            pointY += qt[k].QtPositionY + ",";
            //        }
            //    }
            //    var metal = MetalList.Where(n => n.PositionZ == a).ToList();
            //    for (int k = 0; k < metal.Count; k++)
            //    {
            //        if (string.IsNullOrEmpty(metal[k].PositionX)) continue;
            //        if (metal[k].PositionX.Contains(","))
            //        {
            //            string[] strX = metal[k].PositionX.Split(new char[] { ',' });
            //            string[] strY = metal[k].PositionY.Split(new char[] { ',' });
            //            int minX = Convert.ToInt32(strX[0]);
            //            int maxX = Convert.ToInt32(strX[1]);
            //            int minY = Convert.ToInt32(strY[0]);
            //            int maxY = Convert.ToInt32(strY[1]);
            //            for (int m = 0; m <= maxY - minY; m++)
            //            {
            //                for (int n = 0; n <= maxX - minX; n++)
            //                {
            //                    pointX += (minX + n).ToString() + ",";
            //                    pointY += (minY + m).ToString() + ",";
            //                }
            //            }
            //        }
            //        else
            //        {
            //            pointX += metal[k].PositionX + ",";
            //            pointY += metal[k].PositionY + ",";
            //        }
            //    }
            //    var mix = MixList.Where(n => n.PositionZ == a).ToList();
            //    for (int k = 0; k < mix.Count; k++)
            //    {
            //        if (string.IsNullOrEmpty(mix[k].PositionX)) continue;
            //        if (mix[k].PositionX.Contains(","))
            //        {
            //            string[] strX = mix[k].PositionX.Split(new char[] { ',' });
            //            string[] strY = mix[k].PositionY.Split(new char[] { ',' });
            //            int minX = Convert.ToInt32(strX[0]);
            //            int maxX = Convert.ToInt32(strX[1]);
            //            int minY = Convert.ToInt32(strY[0]);
            //            int maxY = Convert.ToInt32(strY[1]);
            //            for (int m = 0; m <= maxY - minY; m++)
            //            {
            //                for (int n = 0; n <= maxX - minX; n++)
            //                {
            //                    pointX += (minX + n).ToString() + ",";
            //                    pointY += (minY + m).ToString() + ",";
            //                }
            //            }
            //        }
            //        else
            //        {
            //            pointX += mix[k].PositionX + ",";
            //            pointY += mix[k].PositionY + ",";
            //        }
            //    }
            //    pointX = pointX.TrimEnd(new char[] { ',' });
            //    pointY = pointY.TrimEnd(new char[] { ',' });
            //    PointData point = new PointData();
            //    point.PointX = pointX;
            //    point.PointY = pointY;
            //    point.PointZ = a;
            //    vm.PointList.Add(point);
            //}

            #endregion

            return View(vm);
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物货包转运及QT贮存移动单添加")]
        public ActionResult AddTrans(TransportVM model, FormCollection formCollection)
        {
            try
            {
                //if (!ModelState.IsValid)
                //{
                //    return Json("{\"result\":false,\"msg\":\"未通过验证。\"}", JsonRequestBehavior.AllowGet);
                //}
                string bucketCode = Request.Form["txtBucketCode"];
                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                var listTrans = _NuclearQtTransRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listTrans != null)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号已经经过封盖。\"}", JsonRequestBehavior.AllowGet);
                }
                //string trackCode = Request.Form["txtTrackCode"];
                //var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).ToList();
                //if (trackList.Count == 0)
                //{
                //    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在。\"}", JsonRequestBehavior.AllowGet);
                //}
                //string tId = trackList[0].TrackId;
                //var transList = _NuclearQtTransRepository.GetQueryList().Where(n => n.TrackId == tId).ToList();
                //if (transList.Count > 0)
                //{
                //    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号已经经过处理。\"}", JsonRequestBehavior.AllowGet);
                //}
                NuclearQtTrans trans = new NuclearQtTrans();
                trans = model.TransModel;
                trans.QtTransId = Guid.NewGuid().ToString();
                trans.BucketId = listBucket[0].BucketId;
                //trans.TrackId = trackList[0].TrackId;
                if (AppContext.CurrentUser.ProjectCode != "FCGNP")
                {
                    trans.QtPositionX = Request.Form["pointX"];
                    trans.QtPositionY = Request.Form["pointY"];
                    trans.QtPositionZ = Request.Form["pointZ"];
                }
                trans.CreateUserNo = AppContext.CurrentUser.UserId;
                trans.CreateUserName = AppContext.CurrentUser.UserName;
                trans.CreateDate = DateTime.Now;
                trans.Status = Request.Form["submitType"];
                trans.Stationcode = AppContext.CurrentUser.ProjectCode;



                #region"添加明细"

                List<NuclearQtTransDetail> detailList = new List<NuclearQtTransDetail>();
                string[] arrayFactoryFrom = null;
                string[] arrayFactoryTo = null;
                string[] arrayFixationDate = null;
                string[] arrayTransDate = null;
                string[] arrayTransTicket = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayQtFactory = null;
                string strFactoryFrom = Request.Form["hidFactoryFrom"];
                string strFactoryTo = Request.Form["hidFactoryTo"];
                string strFixationDate = Request.Form["hidFixationDate"];
                string strTransDate = Request.Form["hidTransDate"];
                string strTransTicket = Request.Form["hidTransTicket"];
                string strstrControlNo = Request.Form["hidControlNo"];
                string strstrControlName = Request.Form["hidControlName"];
                string strQtFactory = Request.Form["hidQtFactory"];
                if (!string.IsNullOrEmpty(strFactoryFrom))
                {
                    arrayFactoryFrom = strFactoryFrom.Split(new char[] { ',' });
                    arrayFactoryTo = strFactoryTo.Split(new char[] { ',' });
                    arrayFixationDate = strFixationDate.Split(new char[] { ',' });
                    arrayTransDate = strTransDate.Split(new char[] { ',' });
                    arrayTransTicket = strTransTicket.Split(new char[] { ',' });
                    arrayControlNo = strstrControlNo.Split(new char[] { ',' });
                    arrayControlName = strstrControlName.Split(new char[] { ',' });
                    arrayQtFactory = strQtFactory.Split(new char[] { ',' });
                }
                if (arrayFactoryFrom != null)
                {
                    for (int i = 0; i < arrayFactoryFrom.Length - 1; i++)
                    {
                        NuclearQtTransDetail detail = new NuclearQtTransDetail();
                        detail.QtTransDetailId = Guid.NewGuid().ToString();
                        detail.QtTransId = trans.QtTransId;
                        detail.FactoryFromId = arrayFactoryFrom[i];
                        detail.FactoryToId = arrayFactoryTo[i];
                        detail.QtFactoryId = arrayQtFactory[i];
                        if (!string.IsNullOrEmpty(arrayFixationDate[i]))
                            detail.FixationDate = Convert.ToDateTime(arrayFixationDate[i]);
                        if (!string.IsNullOrEmpty(arrayTransDate[i]))
                            detail.TransDate = Convert.ToDateTime(arrayTransDate[i]);
                        detail.TransTicket = arrayTransTicket[i];
                        detail.ProcessNo = arrayControlNo[i];
                        detail.ProcessName = arrayControlName[i];
                        detail.ProcessDate = DateTime.Now;
                        detailList.Add(detail);
                    }
                }
                List<NuclearQtTransDetailB> detailListB = new List<NuclearQtTransDetailB>();
                string[] arrayFactoryFromB = null;
                string[] arrayFactoryToB = null;
                string[] arrayOverDateB = null;
                string[] arrayTransDateB = null;
                string[] arrayTransTicketB = null;
                string[] arrayControlNoB = null;
                string[] arrayControlNameB = null;
                string[] arrayQtFactoryB = null;
                string strFactoryFromB = Request.Form["hidFactoryFromB"];
                string strFactoryToB = Request.Form["hidFactoryToB"];
                string strOverDateB = Request.Form["hidOverDateB"];
                string strTransDateB = Request.Form["hidTransDateB"];
                string strTransTicketB = Request.Form["hidTransTicketB"];
                string strstrControlNoB = Request.Form["hidControlNoB"];
                string strstrControlNameB = Request.Form["hidControlNameB"];
                string strQtFactoryB = Request.Form["hidQtFactoryB"];
                if (!string.IsNullOrEmpty(strFactoryFrom))
                {
                    arrayFactoryFromB = strFactoryFromB.Split(new char[] { ',' });
                    arrayFactoryToB = strFactoryToB.Split(new char[] { ',' });
                    arrayOverDateB = strOverDateB.Split(new char[] { ',' });
                    arrayTransDateB = strTransDateB.Split(new char[] { ',' });
                    arrayTransTicketB = strTransTicketB.Split(new char[] { ',' });
                    arrayControlNoB = strstrControlNoB.Split(new char[] { ',' });
                    arrayControlNameB = strstrControlNameB.Split(new char[] { ',' });
                    arrayQtFactoryB = strQtFactoryB.Split(new char[] { ',' });
                }
                if (arrayFactoryFromB != null)
                {
                    for (int i = 0; i < arrayFactoryFromB.Length - 1; i++)
                    {
                        NuclearQtTransDetailB detailB = new NuclearQtTransDetailB();
                        detailB.QtTransDetailIdB = Guid.NewGuid().ToString();
                        detailB.QtTransId = trans.QtTransId;
                        detailB.FactoryFromId = arrayFactoryFromB[i];
                        detailB.FactoryToId = arrayFactoryToB[i];
                        detailB.QtFactoryId = arrayQtFactoryB[i];
                        if (!string.IsNullOrEmpty(arrayOverDateB[i]))
                            detailB.OverDate = Convert.ToDateTime(arrayOverDateB[i]);
                        if (!string.IsNullOrEmpty(arrayTransDateB[i]))
                            detailB.TransDate = Convert.ToDateTime(arrayTransDateB[i]);
                        detailB.TransTicket = arrayTransTicketB[i];
                        detailB.ProcessNo = arrayControlNoB[i];
                        detailB.ProcessName = arrayControlNameB[i];
                        detailB.ProcessDate = DateTime.Now;
                        detailListB.Add(detailB);
                    }
                }

                #endregion

                if (model.TransModel.Status == "2")
                {

                    #region 生成废物包
                    IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.QueryListByCode(bucketCode,AppContext.CurrentUser.ProjectCode);
                    IQueryable<NuclearWastePackage> nuclearWastePackage = _NuclearWastePackageRepository.GetAll().AsQueryable();
                    nuclearWastePackage = from b in nuclearBucket
                                          join p in nuclearWastePackage
                                          on b.BucketId equals p.BucketId
                                          select p;

                    if (nuclearWastePackage.Count() == 0)
                    {
                        if (nuclearBucket.Count() > 0)
                        {
                            string packageCodeCreate = _NuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                            NuclearWastePackage packageCreate = new NuclearWastePackage();
                            packageCreate.PackageId = Guid.NewGuid().ToString();
                            packageCreate.PackageCode = packageCodeCreate;
                            packageCreate.BucketId = nuclearBucket.ToList()[0].BucketId;
                            packageCreate.ConfirmUserNo = AppContext.CurrentUser.UserId;
                            packageCreate.ConfirmUserName = AppContext.CurrentUser.UserName;
                            packageCreate.ConfirmDate = DateTime.Now;
                            packageCreate.Stationcode = AppContext.CurrentUser.ProjectCode;
                            _NuclearWastePackageRepository.Create(packageCreate);
                        }

                    }
                    #endregion


                    trans.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    trans.ConfirmUserName = AppContext.CurrentUser.UserName;
                    trans.ConfirmDate = DateTime.Now;
                    var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(trans.BucketId);
                    if (bucketModel != null)
                    {
                        bucketModel.XPosition = trans.QtPositionX;
                        bucketModel.YPosition = trans.QtPositionY;
                        bucketModel.ZPosition = trans.QtPositionZ;
                        _NuclearBucketRepository.Update(bucketModel);
                    }
                    //if (trackList.Count > 0)
                    //{
                    //    string trackType = TrackItemBuilder.GetNameByCode(trackList[0].TrackType);
                    //    _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, trackType, trackType + "400L金属桶", null);
                    //   _NuclearBucketRepository.UnitOfWork.Commit();
                    //}
                    string packageCode = _NuclearWastePackageRepository.GetPackageCodebyBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                    NuclearWastePackage package = new NuclearWastePackage();
                    package.Weight = trans.BucketWeight;
                    _NuclearWastePackageRepository.UpdatePackage(packageCode, AppContext.CurrentUser.ProjectCode, package);


                }

                if (_NuclearQtTransRepository.AddTrans(trans, detailList, detailListB))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物货包转运及QT贮存移动单修改及确认")]
        public ActionResult UpdateTrans(TransportVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                string hideCode = Request.Form["hidBucketCode"];
                if (bucketCode != hideCode)
                {
                    bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                    var listCoverMetal = _NuclearQtTransRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listCoverMetal == null)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号已经存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.TransModel.BucketId = listBucket[0].BucketId;
                }
                //string trackCode = Request.Form["txtTrackCode"];
                //string hideTrack = Request.Form["hidTrackCode"];
                //var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).ToList();
                //if (trackCode != hideTrack)
                //{
                //    if (trackList.Count == 0)
                //    {
                //        return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在。\"}", JsonRequestBehavior.AllowGet);
                //    }
                //    string tId = trackList[0].TrackId;
                //    var solutionList = _NuclearQtTransRepository.GetQueryList().Where(n => n.TrackId == tId).ToList();
                //    if (solutionList.Count > 0)
                //    {
                //        return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号已经存在。\"}", JsonRequestBehavior.AllowGet);
                //    }
                //    model.TransModel.TrackId = trackList[0].TrackId;
                //}
                string confirmFlag = model.TransModel.Status;
                model.TransModel.Status = Request.Form["submitType"];
                if (AppContext.CurrentUser.ProjectCode != "FCGNP")
                {
                    model.TransModel.QtPositionX = Request.Form["pointX"];
                    model.TransModel.QtPositionY = Request.Form["pointY"];
                    model.TransModel.QtPositionZ = Request.Form["pointZ"];
                }



                #region"添加明细"

                List<NuclearQtTransDetail> detailList = new List<NuclearQtTransDetail>();
                string[] arrayFactoryFrom = null;
                string[] arrayFactoryTo = null;
                string[] arrayFixationDate = null;
                string[] arrayTransDate = null;
                string[] arrayTransTicket = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayQtFactory = null;

                string strFactoryFrom = Request.Form["hidFactoryFrom"].Replace("\r\n", "").Replace(" ", "");
                string strFactoryTo = Request.Form["hidFactoryTo"].Replace("\r\n", "").Replace(" ", "");
                string strFixationDate = Request.Form["hidFixationDate"].Replace("\r\n", "").Replace(" ", "");
                string strTransDate = Request.Form["hidTransDate"].Replace("\r\n", "").Replace(" ", "");
                string strTransTicket = Request.Form["hidTransTicket"].Replace("\r\n", "").Replace(" ", "");
                string strstrControlNo = Request.Form["hidControlNo"].Replace("\r\n", "").Replace(" ", "");
                string strstrControlName = Request.Form["hidControlName"].Replace("\r\n", "").Replace(" ", "");
                string strQtFactory = Request.Form["hidQtFactory"].Replace("\r\n", "").Replace(" ", "");
                if (!string.IsNullOrEmpty(strFactoryFrom))
                {
                    arrayFactoryFrom = strFactoryFrom.Split(new char[] { ',' });
                    arrayFactoryTo = strFactoryTo.Split(new char[] { ',' });
                    arrayFixationDate = strFixationDate.Split(new char[] { ',' });
                    arrayTransDate = strTransDate.Split(new char[] { ',' });
                    arrayTransTicket = strTransTicket.Split(new char[] { ',' });
                    arrayControlNo = strstrControlNo.Split(new char[] { ',' });
                    arrayControlName = strstrControlName.Split(new char[] { ',' });
                    arrayQtFactory = strQtFactory.Split(new char[] { ',' });
                }
                if (arrayFactoryFrom != null)
                {
                    for (int i = 0; i < arrayFactoryFrom.Length - 1; i++)
                    {
                        NuclearQtTransDetail detail = new NuclearQtTransDetail();
                        detail.QtTransDetailId = Guid.NewGuid().ToString();
                        detail.QtTransId = model.TransModel.QtTransId;
                        detail.FactoryFromId = arrayFactoryFrom[i];
                        detail.FactoryToId = arrayFactoryTo[i];
                        detail.QtFactoryId = arrayQtFactory[i];
                        if (!string.IsNullOrEmpty(arrayFixationDate[i]))
                            detail.FixationDate = Convert.ToDateTime(arrayFixationDate[i]);
                        if (!string.IsNullOrEmpty(arrayTransDate[i]))
                            detail.TransDate = Convert.ToDateTime(arrayTransDate[i]);
                        detail.TransTicket = arrayTransTicket[i];
                        detail.ProcessNo = arrayControlNo[i];
                        detail.ProcessName = arrayControlName[i];
                        detail.ProcessDate = DateTime.Now;
                        detailList.Add(detail);
                    }
                }
                List<NuclearQtTransDetailB> detailListB = new List<NuclearQtTransDetailB>();
                string[] arrayFactoryFromB = null;
                string[] arrayFactoryToB = null;
                string[] arrayOverDateB = null;
                string[] arrayTransDateB = null;
                string[] arrayTransTicketB = null;
                string[] arrayControlNoB = null;
                string[] arrayControlNameB = null;
                string[] arrayQtFactoryB = null;
                string strFactoryFromB = Request.Form["hidFactoryFromB"].Replace("\r\n", "").Replace(" ", "");
                string strFactoryToB = Request.Form["hidFactoryToB"].Replace("\r\n", "").Replace(" ", "");
                string strOverDateB = Request.Form["hidOverDateB"].Replace("\r\n", "").Replace(" ", "");
                string strTransDateB = Request.Form["hidTransDateB"].Replace("\r\n", "").Replace(" ", "");
                string strTransTicketB = Request.Form["hidTransTicketB"].Replace("\r\n", "").Replace(" ", "");
                string strstrControlNoB = Request.Form["hidControlNoB"].Replace("\r\n", "").Replace(" ", "");
                string strstrControlNameB = Request.Form["hidControlNameB"].Replace("\r\n", "").Replace(" ", "");
                string strstrQtFactoryB = Request.Form["hidQtFactoryB"].Replace("\r\n", "").Replace(" ", "");
                if (!string.IsNullOrEmpty(strFactoryFrom))
                {
                    arrayFactoryFromB = strFactoryFromB.Split(new char[] { ',' });
                    arrayFactoryToB = strFactoryToB.Split(new char[] { ',' });
                    arrayOverDateB = strOverDateB.Split(new char[] { ',' });
                    arrayTransDateB = strTransDateB.Split(new char[] { ',' });
                    arrayTransTicketB = strTransTicketB.Split(new char[] { ',' });
                    arrayControlNoB = strstrControlNoB.Split(new char[] { ',' });
                    arrayControlNameB = strstrControlNameB.Split(new char[] { ',' });
                    arrayQtFactoryB = strstrQtFactoryB.Split(new char[] { ',' });
                }
                if (arrayFactoryFromB != null)
                {
                    for (int i = 0; i < arrayFactoryFromB.Length - 1; i++)
                    {
                        NuclearQtTransDetailB detailB = new NuclearQtTransDetailB();
                        detailB.QtTransDetailIdB = Guid.NewGuid().ToString();
                        detailB.QtTransId = model.TransModel.QtTransId;
                        detailB.FactoryFromId = arrayFactoryFromB[i];
                        detailB.FactoryToId = arrayFactoryToB[i];
                        detailB.QtFactoryId = arrayQtFactoryB[i];
                        if (!string.IsNullOrEmpty(arrayOverDateB[i]))
                            detailB.OverDate = Convert.ToDateTime(arrayOverDateB[i]);
                        if (!string.IsNullOrEmpty(arrayTransDateB[i]))
                            detailB.TransDate = Convert.ToDateTime(arrayTransDateB[i]);
                        detailB.TransTicket = arrayTransTicketB[i];
                        detailB.ProcessNo = arrayControlNoB[i];
                        detailB.ProcessName = arrayControlNameB[i];
                        detailB.ProcessDate = DateTime.Now;
                        detailListB.Add(detailB);
                    }
                }

                #endregion

                if (model.TransModel.Status == "2")
                {
                    model.TransModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.TransModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.TransModel.ConfirmDate = DateTime.Now;
                    if (confirmFlag != "2")
                    {

                        #region 生成废物包
                        IQueryable<NuclearBucket> nuclearBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                        IQueryable<NuclearWastePackage> nuclearWastePackage = _NuclearWastePackageRepository.GetAll().AsQueryable();
                        nuclearWastePackage = from b in nuclearBucket
                                              join p in nuclearWastePackage
                                              on b.BucketId equals p.BucketId
                                              select p;

                        if (nuclearWastePackage.Count() == 0)
                        {
                            if (nuclearBucket.Count() > 0)
                            {
                                string packageCodeCreate = _NuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                                NuclearWastePackage packageCreate = new NuclearWastePackage();
                                packageCreate.PackageId = Guid.NewGuid().ToString();
                                packageCreate.PackageCode = packageCodeCreate;
                                packageCreate.BucketId = nuclearBucket.ToList()[0].BucketId;
                                packageCreate.ConfirmUserNo = AppContext.CurrentUser.UserId;
                                packageCreate.ConfirmUserName = AppContext.CurrentUser.UserName;
                                packageCreate.ConfirmDate = DateTime.Now;
                                packageCreate.Stationcode = AppContext.CurrentUser.ProjectCode;
                                _NuclearWastePackageRepository.Create(packageCreate);
                            }

                        }
                        #endregion



                        var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(model.TransModel.BucketId);
                        if (bucketModel != null)
                        {
                            bucketModel.XPosition = model.TransModel.QtPositionX;
                            bucketModel.YPosition = model.TransModel.QtPositionY;
                            bucketModel.ZPosition = model.TransModel.QtPositionZ;
                            _NuclearBucketRepository.Update(bucketModel);
                        }
                        //if (trackList.Count > 0)
                        //{
                        //    string trackType = TrackItemBuilder.GetNameByCode(trackList[0].TrackType);
                        //    _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, trackType, trackType + "400L金属桶", null);
                        //_NuclearBucketRepository.UnitOfWork.Commit();
                        //}
                        string packageCode = _NuclearWastePackageRepository.GetPackageCodebyBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                        NuclearWastePackage package = new NuclearWastePackage();
                        package.Weight = model.TransModel.BucketWeight;
                        _NuclearWastePackageRepository.UpdatePackage(packageCode, AppContext.CurrentUser.ProjectCode, package);
                    }
                }
                if (_NuclearQtTransRepository.UpdateTrans(model.TransModel, detailList, detailListB))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废物货包转运及QT贮存移动单删除")]
        public ActionResult DeleteTrans()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearQtTransRepository.DeleteTrans(id))
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmGoodsIn(TransportVM model, FormCollection formCollection)
        {
            try
            {
                NuclearQtTrans trans = new NuclearQtTrans();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    trans = _NuclearQtTransRepository.GetModelById(uid);
                else
                    trans = _NuclearQtTransRepository.GetModelById(model.TransModel.QtTransId);
                trans.Status = "2";
                trans.ConfirmUserNo = AppContext.CurrentUser.UserId;
                trans.ConfirmUserName = AppContext.CurrentUser.UserName;
                trans.ConfirmDate = DateTime.Now;

                if (_NuclearQtTransRepository.UpdateTrans(trans, null, null))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }

        #endregion

        #region"厂房间废物桶转运"

        /// <summary>
        /// 厂房间废物桶转运
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "厂房间废物桶转运")]
        public ActionResult FactoryTransfer()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            TransportVM vm = new TransportVM();
            vm.OperationList = CommonHelper.GetOperationList("Factory_Transfer");
            vm.FactoryList = new List<SelectListItem>();
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            vm.FcTransDetailList = new List<FcTransDetailList>();
            vm.FcTransModel = new NuclearFcTrans();
            if (!string.IsNullOrEmpty(uid))
            {
                var dataList = _NuclearFcTransRepository.GetDetailListById(uid).ToList();
                if (dataList != null && dataList.Count > 0)
                {
                    foreach (NuclearFcTransDetail detail in dataList)
                    {
                        FcTransDetailList model = new FcTransDetailList();
                        model.DetailId = detail.FcDetailId;
                        model.BucketId = detail.BucketId;
                        if (!string.IsNullOrEmpty(detail.BucketId))
                        {
                            var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId);
                            if (bucketModel == null) continue;
                            model.BucketCode = bucketModel.BucketCode;
                        }
                        model.BucketWeight = detail.BucketWeight.ToString();
                        var factory = _BasicObjectRepository.GetBasicById(detail.FactoryId);
                        if (factory != null)
                            model.FactoryName = factory.Name;
                        model.FactoryId = detail.FactoryId;
                        model.BucketFlaw = detail.BucketFlaw;
                        model.BucketSully = detail.BucketSully;
                        model.RadioAction = detail.RadioactionFlag;
                        model.DoseRound = detail.DoseRound.ToString();
                        model.DoseTop = detail.DoseTop.ToString();
                        model.DoseMeter = detail.DoseMeter.ToString();
                        model.Inside = detail.GoodsInside;
                        model.Remark = detail.Remark;
                        model.PositionX = detail.PositionX;
                        model.PositionY = detail.PositionY;
                        model.PositionZ = detail.PositionZ;
                        vm.FcTransDetailList.Add(model);
                    }
                }
              
                vm.FcTransModel = _NuclearFcTransRepository.GetModelById(uid);
             
                detailFlag = "edit";
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            ViewBag.ViewStatus = Request["status"];
            return View(vm);
        }

        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "厂房间废物桶转运添加")]
        public ActionResult AddFcTrans(TransportVM model, FormCollection formCollection)
        {
            try
            {
                NuclearFcTrans trans = new NuclearFcTrans();
                trans = model.FcTransModel;
                trans.FcTransId = Guid.NewGuid().ToString();
                trans.CreateUserNo = AppContext.CurrentUser.UserId;
                trans.CreateUserName = AppContext.CurrentUser.UserName;
                trans.CreateDate = DateTime.Now;
                trans.Status = Request.Form["submitType"];
                trans.Stationcode = AppContext.CurrentUser.ProjectCode;

                #region"添加明细"

                List<NuclearFcTransDetail> detailList = new List<NuclearFcTransDetail>();
                string[] arrayBucketCode = null;
                string[] arrayBucketWeight = null;
                string[] arrayFactoryId = null;
                string[] arrayBucketFlaw = null;
                string[] arrayBucketSully = null;
                string[] arrayRadioAction = null;
                string[] arrayDoseRound = null;
                string[] arrayDoseTop = null;
                string[] arrayDoseMeter = null;
                string[] arrayInside = null;
                string[] arrayRemark = null;
                string[] arrayPositionX = null;
                string[] arrayPositionY = null;
                string[] arrayPositionZ = null;
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ", "");
                string strBucketWeight = Request.Form["hidBucketWeight"].Replace("\r\n", "").Replace(" ", "");
                string strFactoryId = Request.Form["hidFactoryId"].Replace("\r\n", "").Replace(" ", "");
                string strBucketFlaw = Request.Form["hidBucketFlaw"].Replace("\r\n", "").Replace(" ", "");
                string strBucketSully = Request.Form["hidBucketSully"].Replace("\r\n", "").Replace(" ", "");
                string strRadioAction = Request.Form["hidRadioAction"].Replace("\r\n", "").Replace(" ", "");
                string strDoseRound = Request.Form["hidDoseRound"].Replace("\r\n", "").Replace(" ", "");
                string strDoseTop = Request.Form["hidDoseTop"].Replace("\r\n", "").Replace(" ", "");
                string strDoseMeter = Request.Form["hidDoseMeter"].Replace("\r\n", "").Replace(" ", "");
                string strInside = Request.Form["hidInside"].Replace("\r\n", "").Replace(" ", "");
                string strRemark = Request.Form["hidRemark"].Replace("\r\n", "").Replace(" ", "");
                string strPositionX = Request.Form["hidPositionX"].Replace("\r\n", "").Replace(" ", "");
                string strPositionY = Request.Form["hidPositionY"].Replace("\r\n", "").Replace(" ", "");
                string strPositionZ = Request.Form["hidPositionZ"].Replace("\r\n", "").Replace(" ", "");
                
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayBucketWeight = strBucketWeight.Split(new char[] { ',' });
                    arrayFactoryId = strFactoryId.Split(new char[] { ',' });
                    arrayBucketFlaw = strBucketFlaw.Split(new char[] { ',' });
                    arrayBucketSully = strBucketSully.Split(new char[] { ',' });
                    arrayRadioAction = strRadioAction.Split(new char[] { ',' });
                    arrayDoseRound = strDoseRound.Split(new char[] { ',' });
                    arrayDoseTop = strDoseTop.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayInside = strInside.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                    arrayPositionX = strPositionX.Split(new char[] { '.' });
                    arrayPositionY = strPositionY.Split(new char[] { '.' });
                    arrayPositionZ = strPositionZ.Split(new char[] { '.' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearFcTransDetail detail = new NuclearFcTransDetail();
                        detail.FcDetailId = Guid.NewGuid().ToString();
                        detail.FcTransId = trans.FcTransId;
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        if (trans.Status == "2")
                        {
                            _NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], trans.FactoryFrom, AppContext.CurrentUser.ProjectCode, 0, -1);
                            _NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], trans.FactoryTo, AppContext.CurrentUser.ProjectCode, 0, 1);
                        }
                        detail.BucketFlaw = arrayBucketFlaw[i];
                        detail.BucketSully = arrayBucketSully[i];
                        detail.GoodsInside = arrayInside[i];
                        if (!string.IsNullOrEmpty(arrayDoseRound[i]))
                            detail.DoseRound = Convert.ToDecimal(arrayDoseRound[i]);
                        if (!string.IsNullOrEmpty(arrayDoseTop[i]))
                            detail.DoseTop = Convert.ToDecimal(arrayDoseTop[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMeter[i]))
                            detail.DoseMeter = Convert.ToDecimal(arrayDoseMeter[i]);
                        if (!string.IsNullOrEmpty(arrayBucketWeight[i]))
                            detail.BucketWeight = Convert.ToDecimal(arrayBucketWeight[i]);
                        detail.Remark = arrayRemark[i];

                        detail.RadioactionFlag = arrayRadioAction[i];
                        detail.FactoryId = arrayFactoryId[i];

                        detail.PositionX = arrayPositionX[i];
                        detail.PositionY = arrayPositionY[i];
                        detail.PositionZ = arrayPositionZ[i];
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                if (_NuclearFcTransRepository.AddFcTrans(trans, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "厂房间废物桶转运修改及确认")]
        public ActionResult UpdateFcTrans(TransportVM model, FormCollection formCollection)
        {
            try
            {
                model.FcTransModel.Status = Request.Form["submitType"];

                #region"添加明细"

                List<NuclearFcTransDetail> detailList = new List<NuclearFcTransDetail>();
                string[] arrayBucketCode = null;
                string[] arrayBucketWeight = null;
                string[] arrayFactoryId = null;
                string[] arrayBucketFlaw = null;
                string[] arrayBucketSully = null;
                string[] arrayRadioAction = null;
                string[] arrayDoseRound = null;
                string[] arrayDoseTop = null;
                string[] arrayDoseMeter = null;
                string[] arrayInside = null;
                string[] arrayRemark = null;
                string[] arrayPositionX = null;
                string[] arrayPositionY = null;
                string[] arrayPositionZ = null;
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ", "");
                string strBucketWeight = Request.Form["hidBucketWeight"].Replace("\r\n", "").Replace(" ", "");
                string strFactoryId = Request.Form["hidFactoryId"].Replace("\r\n", "").Replace(" ", "");
                string strBucketFlaw = Request.Form["hidBucketFlaw"].Replace("\r\n", "").Replace(" ", "");
                string strBucketSully = Request.Form["hidBucketSully"].Replace("\r\n", "").Replace(" ", "");
                string strRadioAction = Request.Form["hidRadioAction"].Replace("\r\n", "").Replace(" ", "");
                string strDoseRound = Request.Form["hidDoseRound"].Replace("\r\n", "").Replace(" ", "");
                string strDoseTop = Request.Form["hidDoseTop"].Replace("\r\n", "").Replace(" ", "");
                string strDoseMeter = Request.Form["hidDoseMeter"].Replace("\r\n", "").Replace(" ", "");
                string strInside = Request.Form["hidInside"].Replace("\r\n", "").Replace(" ", "");
                string strRemark = Request.Form["hidRemark"].Replace("\r\n", "").Replace(" ", "");
                string strPositionX = Request.Form["hidPositionX"].Replace("\r\n", "").Replace(" ", "");
                string strPositionY = Request.Form["hidPositionY"].Replace("\r\n", "").Replace(" ", "");
                string strPositionZ = Request.Form["hidPositionZ"].Replace("\r\n", "").Replace(" ", "");
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayBucketWeight = strBucketWeight.Split(new char[] { ',' });
                    arrayFactoryId = strFactoryId.Split(new char[] { ',' });
                    arrayBucketFlaw = strBucketFlaw.Split(new char[] { ',' });
                    arrayBucketSully = strBucketSully.Split(new char[] { ',' });
                    arrayRadioAction = strRadioAction.Split(new char[] { ',' });
                    arrayDoseRound = strDoseRound.Split(new char[] { ',' });
                    arrayDoseTop = strDoseTop.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayInside = strInside.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                    arrayPositionX = strPositionX.Split(new char[] { '.' });
                    arrayPositionY = strPositionY.Split(new char[] { '.' });
                    arrayPositionZ = strPositionZ.Split(new char[] { '.' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearFcTransDetail detail = new NuclearFcTransDetail();
                        detail.FcDetailId = Guid.NewGuid().ToString();
                        detail.FcTransId = model.FcTransModel.FcTransId;
                        var bucketModel = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList();
                        detail.BucketId = bucketModel[0].BucketId;
                        if (model.FcTransModel.Status == "2")
                        {
                            _NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], model.FcTransModel.FactoryFrom, AppContext.CurrentUser.ProjectCode, 0, -1);
                            //将桶的位置从出库改为入库
                            var bucketModelUpdate = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                            bucketModelUpdate.LocationId = model.FcTransModel.FactoryTo;
                            bucketModelUpdate.XPosition = arrayPositionX[i];
                            bucketModelUpdate.YPosition = arrayPositionY[i];
                            bucketModelUpdate.ZPosition = arrayPositionZ[i];
                            _NuclearBucketRepository.Update(bucketModelUpdate);
                            _NuclearBucketRepository.UnitOfWork.Commit();
                            _NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], model.FcTransModel.FactoryTo, AppContext.CurrentUser.ProjectCode, 0, 1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel[0].MaterialId, model.FcTransModel.FactoryFrom, AppContext.CurrentUser.ProjectCode, -1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel[0].MaterialId, model.FcTransModel.FactoryTo, AppContext.CurrentUser.ProjectCode, 1);
                            //_NuclearTempstockRepository.UnitOfWork.Commit();
                        }
                        detail.BucketFlaw = arrayBucketFlaw[i];
                        detail.BucketSully = arrayBucketSully[i];
                        detail.GoodsInside = arrayInside[i];
                        if (!string.IsNullOrEmpty(arrayDoseRound[i]))
                            detail.DoseRound = Convert.ToDecimal(arrayDoseRound[i]);
                        if (!string.IsNullOrEmpty(arrayDoseTop[i]))
                            detail.DoseTop = Convert.ToDecimal(arrayDoseTop[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMeter[i]))
                            detail.DoseMeter = Convert.ToDecimal(arrayDoseMeter[i]);
                        if (!string.IsNullOrEmpty(arrayBucketWeight[i]))
                            detail.BucketWeight = Convert.ToDecimal(arrayBucketWeight[i]);

                        detail.RadioactionFlag = arrayRadioAction[i];
                        detail.FactoryId = arrayFactoryId[i];

                        detail.Remark = arrayRemark[i];
                        detail.PositionX = arrayPositionX[i];
                        detail.PositionY = arrayPositionY[i];
                        detail.PositionZ = arrayPositionZ[i];
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                if (model.FcTransModel.Status == "2")
                {
                    model.FcTransModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.FcTransModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.FcTransModel.ConfirmDate = DateTime.Now;
                }
                if (_NuclearFcTransRepository.UpdateFcTrans(model.FcTransModel, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "厂房间废物桶转运删除")]
        public ActionResult DeleteFcTrans()
        {
            try
            {
                string id = Request["id"];
                NuclearFcTrans nuclearFcTrans = _NuclearFcTransRepository.Get(id);
                if (_NuclearFcTransRepository.DeleteFcTrans(id))
                {
                    IQueryable<NuclearFcTransDetail> nuclearFcTransDetail = _NuclearFcTransRepository.GetDetailListById(id);
                    if (nuclearFcTransDetail.Count() > 0)
                    {
                        foreach (var item in nuclearFcTransDetail)
                        {
                            NuclearBucket nuclearBucket = _NuclearBucketRepository.Get(item.BucketId);
                            nuclearBucket.XPosition = string.Empty;
                            nuclearBucket.XPosition = string.Empty;
                            nuclearBucket.XPosition = string.Empty;
                            nuclearBucket.LocationId = nuclearFcTrans.FactoryFrom;
                            this._NuclearBucketRepository.Update(nuclearBucket);
                        }
                    }
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else{
                 return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
 
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmFcTrans(TransportVM model, FormCollection formCollection)
        {
            try
            {
                NuclearFcTrans trans = new NuclearFcTrans();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    trans = _NuclearFcTransRepository.GetModelById(uid);
                else
                    trans = _NuclearFcTransRepository.GetModelById(model.FcTransModel.FcTransId);
                trans.Status = "2";
                trans.ConfirmUserNo = AppContext.CurrentUser.UserId;
                trans.ConfirmUserName = AppContext.CurrentUser.UserName;
                trans.ConfirmDate = DateTime.Now;

                if (_NuclearFcTransRepository.UpdateFcTrans(trans, null))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 检查桶号是否可用
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckBucketCode()
        {
            string bucketCode = Request["code"];
            string factoryId = Request["factory"];
            bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
            if (!bucketCheck)
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
            }
            string existFactory = _NuclearBucketRepository.IsExistByFactory(bucketCode, AppContext.CurrentUser.ProjectCode, factoryId);
            if (string.IsNullOrEmpty(existFactory))
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶不在所选厂房内。\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && e.IsOutSend == null).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 自动填充——废物跟踪单
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetTrackDataList(string keyword)
        {
            List<TrackItemVM> list = TrackItemBuilder.GetAllTrackList(keyword, AppContext.CurrentUser.ProjectCode).AsQueryable().ToList();//.Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count > 0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].TrackCode;
                    autoComplete.Code = list[i].TrackId;
                    autoCompleteList.Add(autoComplete);
                }

            }

            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        #endregion

        /// <summary>
        /// 导入历史数据页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Import()
        {
            return View();
        }

        #region 导入历史数据
        /// <summary>
        /// 导入封盖数据
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult Import(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的历史数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    //string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    //if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    //{
                    //    //删除文件
                    //    if (System.IO.File.Exists(strNewImportPath))
                    //    {
                    //        System.IO.File.Delete(strNewImportPath);
                    //    }
                    //    jsonResult = JsonResultHelper.JsonResult(false, "历史数据必须是EXCEL格式!");
                    //    jsonResult.ContentType = "text/html";
                    //    return jsonResult;
                    //}
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);
                        if (ds.Tables.Count < 1)
                        {
                            //删除文件
                            if (System.IO.File.Exists(strNewImportPath))
                            {
                                System.IO.File.Delete(strNewImportPath);
                            }
                            jsonResult = JsonResultHelper.JsonResult(false, "历史数据格式错误!");
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //判断EXCEL格式是否正确
                        string checkColumns = ImportQtTransDataBuilder.GetImportNuclearQtTransErr(ds, strNewImportPath);
                        if (!string.IsNullOrEmpty(checkColumns))
                        {
                            jsonResult = JsonResultHelper.JsonResult(false, checkColumns);
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //导入数据
                        if (ds != null && ds.Tables.Count == 1)
                        {
                            ImportQtTransDataBuilder.ImportNuclearQtTrans(ds, strNewImportPath, AppContext.CurrentUser);
                        }
                    }
                }
                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }
        #endregion
    }
}
