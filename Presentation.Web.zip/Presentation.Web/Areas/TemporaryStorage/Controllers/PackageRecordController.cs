﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels;
using RWIS.Presentation.Web.Core.Ftp;
using RWIS.Presentation.Web.Core;
using CIT.UPC.Domain.Repositories;
using CIT.UPC.Domain.DomainObjects;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.Controllers
{
    public class PackageRecordController : Controller
    {
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearTsGoodsInRepository _NuclearTsGoodsInRepository;
        INuclearTsGoodsOutRepository _NuclearTsGoodsOutRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        public PackageRecordController(INuclearTsGoodsInRepository NuclearTsGoodsInRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository
            , INuclearTsGoodsOutRepository NuclearTsGoodsOutRepository
            , INuclearTempstockRepository NuclearTempstockRepository)
        {
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NuclearTsGoodsInRepository = NuclearTsGoodsInRepository;
            this._NuclearTsGoodsOutRepository = NuclearTsGoodsOutRepository;
            this._NuclearTempstockRepository = NuclearTempstockRepository;
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "厂房废物货包记录")]
        public ActionResult Index()
        {
            PackageRecordVM vm = new PackageRecordVM();
            vm.OperationList = CommonHelper.GetOperationList("Package_Record");
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(PackageCondition packageCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var queryIn = _NuclearTsGoodsInRepository.QueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            var queryOut = _NuclearTsGoodsOutRepository.QueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (!string.IsNullOrEmpty(packageCondition.TicketCode))
            {
                queryIn = queryIn.Where(n => n.TicketCode.ToUpper().Contains(packageCondition.TicketCode.ToUpper())).ToList();
                queryOut = queryOut.Where(n => n.TicketCode.ToUpper().Contains(packageCondition.TicketCode.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(packageCondition.Batch))
            {
                queryIn = queryIn.Where(n => n.Batch.ToUpper().Contains(packageCondition.Batch.ToUpper())).ToList();
                queryOut = queryOut.Where(n => n.Batch.ToUpper().Contains(packageCondition.Batch.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(packageCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(packageCondition.StartDate);
                queryIn = queryIn.Where(n => n.CreateDate >= sDate).ToList();
                queryOut = queryOut.Where(n => n.CreateDate >= sDate).ToList();
            }
            if (!string.IsNullOrEmpty(packageCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(packageCondition.EndDate);
                queryIn = queryIn.Where(n => n.CreateDate <= eDate).ToList();
                queryOut = queryOut.Where(n => n.CreateDate <= eDate).ToList();
            }
            List<PackageList> pList = new List<PackageList>();
            if (queryIn != null)
            {
                for (int i = 0; i < queryIn.Count; i++)
                {
                    PackageList package = new PackageList();
                    package.PackageId = queryIn[i].GoodsInId;
                    package.ControlType = "0";
                    package.TicketCode = queryIn[i].TicketCode;
                    package.Batch = queryIn[i].Batch;
                    package.RecordName = queryIn[i].ConfirmUserName;
                    if (queryIn[i].CreateDate != null)
                        package.RecordDate = Convert.ToDateTime(queryIn[i].CreateDate.ToString()).ToShortDateString();
                    package.Reason = "入库";
                    package.Status = queryIn[i].Status;
                    package.CreateDate = queryIn[i].CreateDate;
                    pList.Add(package);
                }
            }
            if (queryOut != null)
            {
                for (int i = 0; i < queryOut.Count; i++)
                {
                    PackageList package = new PackageList();
                    package.PackageId = queryOut[i].GoodsOutId;
                    package.ControlType = "1";
                    package.TicketCode = queryOut[i].TicketCode;
                    package.Batch = queryOut[i].Batch;
                    package.RecordName = queryOut[i].CreateUserName;
                    if (queryOut[i].CreateDate != null)
                        package.RecordDate = Convert.ToDateTime(queryOut[i].CreateDate.ToString()).ToShortDateString();
                    package.Reason = "出库";
                    package.Status = queryOut[i].Status;
                    package.CreateDate = queryOut[i].CreateDate;
                    pList.Add(package);
                }
            }
            pList = pList.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<PackageList> data = pList.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<PackageList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.PackageId,
                    List = new List<object>() {
                    d.PackageId,
                    d.ControlType,
                    d.TicketCode,
                    d.Batch,
                    d.Reason,
                    d.RecordName,
                    d.RecordDate,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        #region"入库"

        /// <summary>
        /// 入库明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "入库记录")]
        public ActionResult RecordIn()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            PackageRecordVM vm = new PackageRecordVM();
            vm.OperationList = CommonHelper.GetOperationList("Record_In");
            vm.FactoryFromList = new List<SelectListItem>();
            vm.FactoryToList = new List<SelectListItem>();

            List<BasicObject> listBasicObjectFrom = new List<BasicObject>();
            IQueryable<BasicObject> queryFrom = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition", AppContext.CurrentUser.ProjectCode);
            if (queryFrom != null && queryFrom.Count() > 0)
            {
                listBasicObjectFrom = queryFrom.ToList();
            }
            foreach (BasicObject basic in listBasicObjectFrom)
            {
                vm.FactoryFromList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }

            List<BasicObject> listBasicObjectTo = new List<BasicObject>();
            IQueryable<BasicObject> queryTo = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            if (queryTo != null && queryTo.Count() > 0)
            {
                listBasicObjectTo = queryTo.ToList();
            }
             foreach (BasicObject basic in listBasicObjectTo)
            {
                vm.FactoryToList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
     
            vm.DetailList = new List<PackageDetailList>();
            vm.GoodsInModel = new NuclearTsGoodsIn();
            if (!string.IsNullOrEmpty(uid))
            {
                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listRecordInRp = _attachFileRepository.GetAttachFileBy(uid, "RecordInRp");
                vm.RecordInRpAttachFiles = (List<AttachFile>)listRecordInRp;
                IList<AttachFile> listRecordInSite = _attachFileRepository.GetAttachFileBy(uid, "RecordInSite");
                vm.RecordInSiteAttachFiles = (List<AttachFile>)listRecordInRp;
                IList<AttachFile> listRecordInService = _attachFileRepository.GetAttachFileBy(uid, "RecordInService");
                vm.RecordInServiceAttachFiles = (List<AttachFile>)listRecordInRp;

                var dataList = _NuclearTsGoodsInRepository.QueryDetailList(uid).ToList();
                if (dataList != null && dataList.Count > 0)
                {
                    foreach (NuclearGoodsInDetail detail in dataList)
                    {
                        PackageDetailList model = new PackageDetailList();
                        model.DetailId = detail.GoodsInDetailId;
                        if (!string.IsNullOrEmpty(detail.BucketId))
                        {
                            var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId);
                            if (bucketModel == null) continue;
                            model.BucketCode = bucketModel.BucketCode;
                        }
                        model.PackageCode = detail.GoodsCode;
                        model.ContentGoods = detail.ContentGoods;
                        model.DoseSurface = detail.DoseSurface.ToString();
                        model.DoseMeter = detail.DoseMeter.ToString();
                        model.PolluteA = detail.PolluteA.ToString();
                        model.PolluteB = detail.PolluteB.ToString();
                        model.Facade = detail.GoodsFacade;
                        model.DoseMeter = detail.DoseMeter.ToString();
                        model.ControlName = detail.ProcessName;
                        model.ControlNo = detail.ProcessNo;
                        if (detail.ProcessDate != null)
                            model.ControlDate = Convert.ToDateTime(detail.ProcessDate.ToString()).ToShortDateString();
                        model.Position = detail.Position;
                        model.Remark = detail.Remark;
                        vm.DetailList.Add(model);
                    }
                }
                vm.GoodsInModel = _NuclearTsGoodsInRepository.GetModelById(uid);
                detailFlag = "edit";
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            return View(vm);
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "入库记录添加")]
        public ActionResult AddGoodsIn(PackageRecordVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsGoodsIn goods = new NuclearTsGoodsIn();
                goods = model.GoodsInModel;
                goods.GoodsInId = Guid.NewGuid().ToString();
                goods.CreateUserNo = AppContext.CurrentUser.UserId;
                goods.CreateUserName = AppContext.CurrentUser.UserName;
                goods.CreateDate = DateTime.Now;
                goods.Status = Request.Form["submitType"];
                goods.Stationcode = AppContext.CurrentUser.ProjectCode;

                #region"添加明细"

                List<NuclearGoodsInDetail> detailList = new List<NuclearGoodsInDetail>();
                string[] arrayBucketCode = null;
                string[] arrayPackageCode = null;
                string[] arrayContentGoods = null;
                string[] arrayDoseSurface = null;
                string[] arrayDoseMeter = null;
                string[] arrayPolluteA = null;
                string[] arrayPolluteB = null;
                string[] arrayFacade = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayControlDate = null;
                string[] arrayPosition = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"];
                string strPackageCode = Request.Form["hidPackageCode"];
                string strContentGoods = Request.Form["hidContentGoods"];
                string strDoseSurface = Request.Form["hidDoseSurface"];
                string strDoseMeter = Request.Form["hidDoseMeter"];
                string strPolluteA = Request.Form["hidPolluteA"];
                string strPolluteB = Request.Form["hidPolluteB"];
                string strFacade = Request.Form["hidFacade"];
                string strControlNo = Request.Form["hidControlNo"];
                string strControlName = Request.Form["hidControlName"];
                string strControlDate = Request.Form["hidControlDate"];
                string strPosition = Request.Form["hidPosition"];
                string strRemark = Request.Form["hidRemark"];
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayPackageCode = strPackageCode.Split(new char[] { ',' });
                    arrayContentGoods = strContentGoods.Split(new char[] { ',' });
                    arrayDoseSurface = strDoseSurface.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayPolluteA = strPolluteA.Split(new char[] { ',' });
                    arrayPolluteB = strPolluteB.Split(new char[] { ',' });
                    arrayFacade = strFacade.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayControlDate = strControlDate.Split(new char[] { ',' });
                    arrayPosition = strPosition.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearGoodsInDetail detail = new NuclearGoodsInDetail();
                        detail.GoodsInDetailId = Guid.NewGuid().ToString();
                        detail.GoodsInId = goods.GoodsInId;
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        if (goods.Status == "2")
                        {
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], goods.TransFromId, AppContext.CurrentUser.ProjectCode, 0, -1);
                            _NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], goods.TransToId, AppContext.CurrentUser.ProjectCode, 0, 1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel[0].MaterialId, model.GoodsInModel.TransFromId, AppContext.CurrentUser.ProjectCode, -1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel[0].MaterialId, model.GoodsInModel.TransToId, AppContext.CurrentUser.ProjectCode, 1);
                            //_NuclearTempstockRepository.UnitOfWork.Commit();
                            _NuclearBucketRepository.UpdateBucketOutSendFlag(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode, "0");
                            //_NuclearBucketRepository.UnitOfWork.Commit();
                        }
                        detail.GoodsCode = arrayPackageCode[i];
                        detail.ContentGoods = arrayContentGoods[i];
                        if (!string.IsNullOrEmpty(arrayDoseSurface[i]))
                            detail.DoseSurface = Convert.ToDecimal(arrayDoseSurface[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMeter[i]))
                            detail.DoseMeter = Convert.ToDecimal(arrayDoseMeter[i]);
                        if (!string.IsNullOrEmpty(arrayPolluteA[i]))
                            detail.PolluteA = Convert.ToDecimal(arrayPolluteA[i]);
                        if (!string.IsNullOrEmpty(arrayPolluteB[i]))
                            detail.PolluteB = Convert.ToDecimal(arrayPolluteB[i]);
                        detail.Position = arrayPosition[i];
                        detail.Remark = arrayRemark[i];
                        detail.ProcessNo = arrayControlNo[i];
                        detail.ProcessName = arrayControlName[i];
                        if (!string.IsNullOrEmpty(arrayControlDate[i]))
                            detail.ProcessDate = Convert.ToDateTime(arrayControlDate[i]);
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                this.SaveAttachFile(goods.GoodsInId, "UploadRecordInRp", formCollection);
                this.SaveAttachFile(goods.GoodsInId, "UploadRecordInSite", formCollection);
                this.SaveAttachFile(goods.GoodsInId, "UploadRecordInService", formCollection);

                if (goods.Status == "2")
                {
                    goods.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    goods.ConfirmUserName = AppContext.CurrentUser.UserName;
                    goods.ConfirmDate = DateTime.Now;
                }

                if (_NuclearTsGoodsInRepository.AddGoodsIn(goods, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "入库记录修改及确认")]
        public ActionResult UpdateGoodsIn(PackageRecordVM model, FormCollection formCollection)
        {
            try
            {
                string confirmFlag = model.GoodsInModel.Status;
                model.GoodsInModel.Status = Request.Form["submitType"];

                #region"添加明细"

                List<NuclearGoodsInDetail> detailList = new List<NuclearGoodsInDetail>();
                string[] arrayBucketCode = null;
                string[] arrayPackageCode = null;
                string[] arrayContentGoods = null;
                string[] arrayDoseSurface = null;
                string[] arrayDoseMeter = null;
                string[] arrayPolluteA = null;
                string[] arrayPolluteB = null;
                string[] arrayFacade = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayControlDate = null;
                string[] arrayPosition = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ", "");
                string strPackageCode = Request.Form["hidPackageCode"].Replace("\r\n", "").Replace(" ", "");
                string strContentGoods = Request.Form["hidContentGoods"].Replace("\r\n", "").Replace(" ", "");
                string strDoseSurface = Request.Form["hidDoseSurface"].Replace("\r\n", "").Replace(" ", "");
                string strDoseMeter = Request.Form["hidDoseMeter"].Replace("\r\n", "").Replace(" ", "");
                string strPolluteA = Request.Form["hidPolluteA"].Replace("\r\n", "").Replace(" ", "");
                string strPolluteB = Request.Form["hidPolluteB"].Replace("\r\n", "").Replace(" ", "");
                string strFacade = Request.Form["hidFacade"].Replace("\r\n", "").Replace(" ", "");
                string strControlNo = Request.Form["hidControlNo"].Replace("\r\n", "").Replace(" ", "");
                string strControlName = Request.Form["hidControlName"].Replace("\r\n", "").Replace(" ", "");
                string strControlDate = Request.Form["hidControlDate"].Replace("\r\n", "").Replace(" ", "");
                string strPosition = Request.Form["hidPosition"].Replace("\r\n", "").Replace(" ", "");
                string strRemark = Request.Form["hidRemark"].Replace("\r\n", "").Replace(" ", "");
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayPackageCode = strPackageCode.Split(new char[] { ',' });
                    arrayContentGoods = strContentGoods.Split(new char[] { ',' });
                    arrayDoseSurface = strDoseSurface.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayPolluteA = strPolluteA.Split(new char[] { ',' });
                    arrayPolluteB = strPolluteB.Split(new char[] { ',' });
                    arrayFacade = strFacade.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayControlDate = strControlDate.Split(new char[] { ',' });
                    arrayPosition = strPosition.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearGoodsInDetail detail = new NuclearGoodsInDetail();
                        detail.GoodsInDetailId = Guid.NewGuid().ToString();
                        detail.GoodsInId = model.GoodsInModel.GoodsInId;
                        var bucketModel = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList();
                        detail.BucketId = bucketModel[0].BucketId;
                        if (model.GoodsInModel.Status == "2" && confirmFlag != "2")
                        {
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], model.GoodsInModel.TransFromId, AppContext.CurrentUser.ProjectCode, 0, -1);
                            _NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], model.GoodsInModel.TransToId, AppContext.CurrentUser.ProjectCode, 0, 1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel[0].MaterialId, model.GoodsInModel.TransFromId, AppContext.CurrentUser.ProjectCode, -1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel[0].MaterialId, model.GoodsInModel.TransToId, AppContext.CurrentUser.ProjectCode, 1);
                            //_NuclearTempstockRepository.UnitOfWork.Commit();
                            _NuclearBucketRepository.UpdateBucketOutSendFlag(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode, "0");
                            //_NuclearBucketRepository.UnitOfWork.Commit();
                        }
                        detail.GoodsCode = arrayPackageCode[i];
                        detail.ContentGoods = arrayContentGoods[i];
                        if (!string.IsNullOrEmpty(arrayDoseSurface[i]))
                            detail.DoseSurface = Convert.ToDecimal(arrayDoseSurface[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMeter[i]))
                            detail.DoseMeter = Convert.ToDecimal(arrayDoseMeter[i]);
                        if (!string.IsNullOrEmpty(arrayPolluteA[i]))
                            detail.PolluteA = Convert.ToDecimal(arrayPolluteA[i]);
                        if (!string.IsNullOrEmpty(arrayPolluteB[i]))
                            detail.PolluteB = Convert.ToDecimal(arrayPolluteB[i]);
                        detail.Position = arrayPosition[i];
                        detail.Remark = arrayRemark[i];
                        detail.ProcessNo = arrayControlNo[i];
                        detail.ProcessName = arrayControlName[i];
                        if (!string.IsNullOrEmpty(arrayControlDate[i]))
                            detail.ProcessDate = Convert.ToDateTime(arrayControlDate[i]);
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                this.SaveAttachFile(model.GoodsInModel.GoodsInId, "UploadRecordInRp", formCollection);
                this.SaveAttachFile(model.GoodsInModel.GoodsInId, "UploadRecordInSite", formCollection);
                this.SaveAttachFile(model.GoodsInModel.GoodsInId, "UploadRecordInService", formCollection);

                if (model.GoodsInModel.Status == "2")
                {
                    model.GoodsInModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.GoodsInModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.GoodsInModel.ConfirmDate = DateTime.Now;
                }
                if (_NuclearTsGoodsInRepository.UpdateGoodsIn(model.GoodsInModel, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmGoodsIn(PackageRecordVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsGoodsIn goods = new NuclearTsGoodsIn();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    goods = _NuclearTsGoodsInRepository.GetModelById(uid);
                else
                    goods = _NuclearTsGoodsInRepository.GetModelById(model.GoodsInModel.GoodsInId);
                goods.Status = "2";
                goods.ConfirmUserNo = AppContext.CurrentUser.UserId;
                goods.ConfirmUserName = AppContext.CurrentUser.UserName;
                goods.ConfirmDate = DateTime.Now;

                if (_NuclearTsGoodsInRepository.UpdateGoodsIn(goods, null))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }

        #endregion

        #region"出库"

        /// <summary>
        /// 出库明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "出库记录")]
        public ActionResult RecordOut()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            PackageRecordVM vm = new PackageRecordVM();
            vm.OperationList = CommonHelper.GetOperationList("Record_Out");
            vm.FactoryFromList = new List<SelectListItem>();
            vm.FactoryToList = new List<SelectListItem>();
            List<BasicObject> listBasicObjectFrom = new List<BasicObject>();
            IQueryable<BasicObject> queryFrom = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            if (queryFrom != null && queryFrom.Count() > 0)
            {
                listBasicObjectFrom = queryFrom.ToList();
            }
            foreach (BasicObject basic in listBasicObjectFrom)
            {
                vm.FactoryFromList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
                vm.FactoryToList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            List<BasicObject> listBasicObjectTo = new List<BasicObject>();
            IQueryable<BasicObject> queryTo = _BasicObjectRepository.GetSubobjectsByCode("DispitePosition", AppContext.CurrentUser.ProjectCode);
            if (queryTo != null && queryTo.Count() > 0)
            {
                listBasicObjectTo = queryTo.ToList();
            }
            foreach (BasicObject basic in listBasicObjectTo)
            {
                vm.FactoryFromList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
                vm.FactoryToList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            vm.DetailList = new List<PackageDetailList>();
            vm.GoodsOutModel = new NuclearTsGoodsOut();
            if (!string.IsNullOrEmpty(uid))
            {
                IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
                IList<AttachFile> listRecordOutRp = _attachFileRepository.GetAttachFileBy(uid, "RecordOutRp");
                vm.RecordOutRpAttachFiles = (List<AttachFile>)listRecordOutRp;
                IList<AttachFile> listRecordOutSite = _attachFileRepository.GetAttachFileBy(uid, "RecordOutSite");
                vm.RecordOutSiteAttachFiles = (List<AttachFile>)listRecordOutRp;
                IList<AttachFile> listRecordOutService = _attachFileRepository.GetAttachFileBy(uid, "RecordOutService");
                vm.RecordOutServiceAttachFiles = (List<AttachFile>)listRecordOutRp;

                var dataList = _NuclearTsGoodsOutRepository.QueryDetailList(uid).ToList();
                if (dataList != null && dataList.Count > 0)
                {
                    foreach (NuclearGoodsOutDetail detail in dataList)
                    {
                        PackageDetailList model = new PackageDetailList();
                        model.DetailId = detail.GoodsOutDetailId;
                        if (!string.IsNullOrEmpty(detail.BucketId))
                        {
                            var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId);
                            if (bucketModel == null) continue;
                            model.BucketCode = bucketModel.BucketCode;
                        }
                        model.PackageCode = detail.GoodsCode;
                        model.ContentGoods = detail.ContentGoods;
                        model.DoseSurface = detail.DoseSurface.ToString();
                        model.DoseMeter = detail.DoseMeter.ToString();
                        model.PolluteA = detail.PolluteA.ToString();
                        model.PolluteB = detail.PolluteB.ToString();
                        model.Facade = detail.GoodsFacade;
                        model.DoseMeter = detail.DoseMeter.ToString();
                        model.ControlName = detail.ProcessName;
                        model.ControlNo = detail.ProcessNo;
                        if (detail.ProcessDate != null)
                            model.ControlDate = Convert.ToDateTime(detail.ProcessDate.ToString()).ToShortDateString();
                        model.Remark = detail.Remark;
                        vm.DetailList.Add(model);
                    }
                }
                vm.GoodsOutModel = _NuclearTsGoodsOutRepository.GetModelById(uid);
                detailFlag = "edit";
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            return View(vm);
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "出库记录添加")]
        public ActionResult AddGoodsOut(PackageRecordVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsGoodsOut goods = new NuclearTsGoodsOut();
                goods = model.GoodsOutModel;
                goods.GoodsOutId = Guid.NewGuid().ToString();
                goods.CreateUserNo = AppContext.CurrentUser.UserId;
                goods.CreateUserName = AppContext.CurrentUser.UserName;
                goods.CreateDate = DateTime.Now;
                goods.Status = Request.Form["submitType"];
                goods.Stationcode = AppContext.CurrentUser.ProjectCode;

                #region"添加明细"

                List<NuclearGoodsOutDetail> detailList = new List<NuclearGoodsOutDetail>();
                string[] arrayBucketCode = null;
                string[] arrayPackageCode = null;
                string[] arrayContentGoods = null;
                string[] arrayDoseSurface = null;
                string[] arrayDoseMeter = null;
                string[] arrayPolluteA = null;
                string[] arrayPolluteB = null;
                string[] arrayFacade = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayControlDate = null;
                string[] arrayPosition = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"];
                string strPackageCode = Request.Form["hidPackageCode"];
                string strContentGoods = Request.Form["hidContentGoods"];
                string strDoseSurface = Request.Form["hidDoseSurface"];
                string strDoseMeter = Request.Form["hidDoseMeter"];
                string strPolluteA = Request.Form["hidPolluteA"];
                string strPolluteB = Request.Form["hidPolluteB"];
                string strFacade = Request.Form["hidFacade"];
                string strControlNo = Request.Form["hidControlNo"];
                string strControlName = Request.Form["hidControlName"];
                string strControlDate = Request.Form["hidControlDate"];
                string strPosition = Request.Form["hidPosition"];
                string strRemark = Request.Form["hidRemark"];
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayPackageCode = strPackageCode.Split(new char[] { ',' });
                    arrayContentGoods = strContentGoods.Split(new char[] { ',' });
                    arrayDoseSurface = strDoseSurface.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayPolluteA = strPolluteA.Split(new char[] { ',' });
                    arrayPolluteB = strPolluteB.Split(new char[] { ',' });
                    arrayFacade = strFacade.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayControlDate = strControlDate.Split(new char[] { ',' });
                    arrayPosition = strPosition.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearGoodsOutDetail detail = new NuclearGoodsOutDetail();
                        detail.GoodsOutDetailId = Guid.NewGuid().ToString();
                        detail.GoodsOutId = goods.GoodsOutId;
                        var bucketModel = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                        detail.BucketId = bucketModel.BucketId;
                        if (goods.Status == "2")
                        {
                            _NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], goods.TransFromId, AppContext.CurrentUser.ProjectCode, 0, -1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], goods.TransToId, AppContext.CurrentUser.ProjectCode, 0, 1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel[0].MaterialId, model.GoodsOutModel.TransFromId, AppContext.CurrentUser.ProjectCode, -1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel[0].MaterialId, model.GoodsOutModel.TransToId, AppContext.CurrentUser.ProjectCode, 1);
                            //_NuclearTempstockRepository.UnitOfWork.Commit();
                            _NuclearBucketRepository.UpdateBucketOutSendFlag(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode, "1");
                        }
                        detail.GoodsCode = arrayPackageCode[i];
                        detail.ContentGoods = arrayContentGoods[i];
                        if (!string.IsNullOrEmpty(arrayDoseSurface[i]))
                            detail.DoseSurface = Convert.ToDecimal(arrayDoseSurface[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMeter[i]))
                            detail.DoseMeter = Convert.ToDecimal(arrayDoseMeter[i]);
                        if (!string.IsNullOrEmpty(arrayPolluteA[i]))
                            detail.PolluteA = Convert.ToDecimal(arrayPolluteA[i]);
                        if (!string.IsNullOrEmpty(arrayPolluteB[i]))
                            detail.PolluteB = Convert.ToDecimal(arrayPolluteB[i]);
                        //detail.Position = arrayPosition[i];
                        detail.Remark = arrayRemark[i];
                        detail.ProcessNo = arrayControlNo[i];
                        detail.ProcessName = arrayControlName[i];
                        if (!string.IsNullOrEmpty(arrayControlDate[i]))
                            detail.ProcessDate = Convert.ToDateTime(arrayControlDate[i]);
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                this.SaveAttachFile(goods.GoodsOutId, "UploadRecordOutRp", formCollection);
                this.SaveAttachFile(goods.GoodsOutId, "UploadRecordOutSite", formCollection);
                this.SaveAttachFile(goods.GoodsOutId, "UploadRecordOutService", formCollection);

                if (goods.Status == "2")
                {
                    goods.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    goods.ConfirmUserName = AppContext.CurrentUser.UserName;
                    goods.ConfirmDate = DateTime.Now;
                }

                if (_NuclearTsGoodsOutRepository.AddGoodsOut(goods, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "出库记录修改及确认")]
        public ActionResult UpdateGoodsOut(PackageRecordVM model, FormCollection formCollection)
        {
            try
            {
                string confirmFlag = model.GoodsOutModel.Status;
                model.GoodsOutModel.Status = Request.Form["submitType"];

                #region"添加明细"

                List<NuclearGoodsOutDetail> detailList = new List<NuclearGoodsOutDetail>();
                string[] arrayBucketCode = null;
                string[] arrayPackageCode = null;
                string[] arrayContentGoods = null;
                string[] arrayDoseSurface = null;
                string[] arrayDoseMeter = null;
                string[] arrayPolluteA = null;
                string[] arrayPolluteB = null;
                string[] arrayFacade = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayControlDate = null;
                string[] arrayPosition = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ", "");
                string strPackageCode = Request.Form["hidPackageCode"].Replace("\r\n", "").Replace(" ", "");
                string strContentGoods = Request.Form["hidContentGoods"].Replace("\r\n", "").Replace(" ", "");
                string strDoseSurface = Request.Form["hidDoseSurface"].Replace("\r\n", "").Replace(" ", "");
                string strDoseMeter = Request.Form["hidDoseMeter"].Replace("\r\n", "").Replace(" ", "");
                string strPolluteA = Request.Form["hidPolluteA"].Replace("\r\n", "").Replace(" ", "");
                string strPolluteB = Request.Form["hidPolluteB"].Replace("\r\n", "").Replace(" ", "");
                string strFacade = Request.Form["hidFacade"].Replace("\r\n", "").Replace(" ", "");
                string strControlNo = Request.Form["hidControlNo"].Replace("\r\n", "").Replace(" ", "");
                string strControlName = Request.Form["hidControlName"].Replace("\r\n", "").Replace(" ", "");
                string strControlDate = Request.Form["hidControlDate"].Replace("\r\n", "").Replace(" ", "");
                string strPosition = Request.Form["hidPosition"].Replace("\r\n", "").Replace(" ", "");
                string strRemark = Request.Form["hidRemark"].Replace("\r\n", "").Replace(" ", "");
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayPackageCode = strPackageCode.Split(new char[] { ',' });
                    arrayContentGoods = strContentGoods.Split(new char[] { ',' });
                    arrayDoseSurface = strDoseSurface.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayPolluteA = strPolluteA.Split(new char[] { ',' });
                    arrayPolluteB = strPolluteB.Split(new char[] { ',' });
                    arrayFacade = strFacade.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayControlDate = strControlDate.Split(new char[] { ',' });
                    arrayPosition = strPosition.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearGoodsOutDetail detail = new NuclearGoodsOutDetail();
                        detail.GoodsOutDetailId = Guid.NewGuid().ToString();
                        detail.GoodsOutId = model.GoodsOutModel.GoodsOutId;
                        var bucketModel = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                        detail.BucketId = bucketModel.BucketId;
                        if (model.GoodsOutModel.Status == "2" && confirmFlag != "2")
                        {
                            _NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], model.GoodsOutModel.TransFromId, AppContext.CurrentUser.ProjectCode, 0, -1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(arrayBucketCode[i], model.GoodsOutModel.TransToId, AppContext.CurrentUser.ProjectCode, 0, 1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel[0].MaterialId, model.GoodsOutModel.TransFromId, AppContext.CurrentUser.ProjectCode, -1);
                            //_NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel[0].MaterialId, model.GoodsOutModel.TransToId, AppContext.CurrentUser.ProjectCode, 1);
                            //_NuclearTempstockRepository.UnitOfWork.Commit();
                            _NuclearBucketRepository.UpdateBucketOutSendFlag(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode, "1");
                            //_NuclearBucketRepository.UnitOfWork.Commit();
                        }
                        detail.GoodsCode = arrayPackageCode[i];
                        detail.ContentGoods = arrayContentGoods[i];
                        if (!string.IsNullOrEmpty(arrayDoseSurface[i]))
                            detail.DoseSurface = Convert.ToDecimal(arrayDoseSurface[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMeter[i]))
                            detail.DoseMeter = Convert.ToDecimal(arrayDoseMeter[i]);
                        if (!string.IsNullOrEmpty(arrayPolluteA[i]))
                            detail.PolluteA = Convert.ToDecimal(arrayPolluteA[i]);
                        if (!string.IsNullOrEmpty(arrayPolluteB[i]))
                            detail.PolluteB = Convert.ToDecimal(arrayPolluteB[i]);
                        //detail.Position = arrayPosition[i];
                        detail.Remark = arrayRemark[i];
                        detail.ProcessNo = arrayControlNo[i];
                        detail.ProcessName = arrayControlName[i];
                        if (!string.IsNullOrEmpty(arrayControlDate[i]))
                            detail.ProcessDate = Convert.ToDateTime(arrayControlDate[i]);
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                this.SaveAttachFile(model.GoodsOutModel.GoodsOutId, "UploadRecordOutRp", formCollection);
                this.SaveAttachFile(model.GoodsOutModel.GoodsOutId, "UploadRecordOutSite", formCollection);
                this.SaveAttachFile(model.GoodsOutModel.GoodsOutId, "UploadRecordOutService", formCollection);

                if (model.GoodsOutModel.Status == "2")
                {
                    model.GoodsOutModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.GoodsOutModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.GoodsOutModel.ConfirmDate = DateTime.Now;
                }
                if (_NuclearTsGoodsOutRepository.UpdateGoodsOut(model.GoodsOutModel, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmGoodsOut(PackageRecordVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsGoodsOut goods = new NuclearTsGoodsOut();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    goods = _NuclearTsGoodsOutRepository.GetModelById(uid);
                else
                    goods = _NuclearTsGoodsOutRepository.GetModelById(model.GoodsInModel.GoodsInId);
                goods.Status = "2";
                goods.ConfirmUserNo = AppContext.CurrentUser.UserId;
                goods.ConfirmUserName = AppContext.CurrentUser.UserName;
                goods.ConfirmDate = DateTime.Now;

                if (_NuclearTsGoodsOutRepository.UpdateGoodsOut(goods, null))
                {
                    _NuclearTsGoodsOutRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }

        #endregion

        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "厂房废物货包记录删除")]
        public ActionResult DeleteGoods()
        {
            try
            {
                string id = Request["id"];
                string type = Request["type"];
                bool flag = false;
                if (type == "0")
                    flag = _NuclearTsGoodsInRepository.DeleteGoodsIn(id);
                if (type == "1")
                    flag = _NuclearTsGoodsOutRepository.DeleteGoodsOut(id);
                if (flag)
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 检查桶号是否可用
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckBucketCode()
        {
            string bucketCode = Request["code"];
            string factoryId = Request["factory"];
            string projectCode = AppContext.CurrentUser.ProjectCode;
            bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
            if (!bucketCheck)
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
            }
            string existFactory = _NuclearBucketRepository.IsExistByFactory(bucketCode, projectCode, factoryId);
            if (string.IsNullOrEmpty(existFactory))
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶不在所选厂房内。\"}", JsonRequestBehavior.AllowGet);
            }
            var bucketModel = _NuclearBucketRepository.QueryListByCode(bucketCode, projectCode).FirstOrDefault();
            if (bucketModel.BucketStatus != "COVER" && bucketModel.BucketStatus != "FILL")
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶没经过固定或者封盖。\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"\"}", JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 入库-自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetInputBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            IQueryable<NuclearBucket> iqueryNuclearBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && e.IsOutSend=="1");
            if (iqueryNuclearBucket.Count() > 0)
            {
                list = iqueryNuclearBucket.ToList();
            }

            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 出库-自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            IQueryable<NuclearBucket> iqueryNuclearBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsOutSend == "" || e.IsOutSend =="0" || e.IsOutSend == null));
            if (iqueryNuclearBucket.Count() > 0)
            {
                list = iqueryNuclearBucket.ToList();
            }
           
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 附件
        /// </summary>
        /// <param name="formCollection"></param>
        /// <returns></returns>

        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], "StockManage");
            }
            return null;
        }
        /// <summary>
        /// 下载文件
        /// 
        /// </summary>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }
    }
}
