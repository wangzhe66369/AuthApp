﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.Controllers
{
    public class EmptyTransController : Controller
    {
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearTsEbTransRepository _NuclearTsEbTransRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        public EmptyTransController(INuclearTsEbTransRepository NuclearTsEbTransRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository
            , INuclearTempstockRepository NuclearTempstockRepository)
        {
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NuclearTsEbTransRepository = NuclearTsEbTransRepository;
            this._NuclearTempstockRepository = NuclearTempstockRepository;
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "空桶运输记录")]
        public ActionResult Index()
        {
            EmptyTransVM vm = new EmptyTransVM();
            vm.OperationList = CommonHelper.GetOperationList("Empty_Trans");
            vm.FactoryList = new List<SelectListItem>();
            vm.FactoryList.Add(new SelectListItem { Text = "请选择", Value = "0" });
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            return View(vm);
        }
        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "空桶运输记录明细")]
        public ActionResult Detail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            EmptyTransVM vm = new EmptyTransVM();
            vm.OperationList = CommonHelper.GetOperationList("Empty_Trans");
            vm.FactoryList = new List<SelectListItem>();
            vm.BucketTypeList = new List<SelectListItem>();
            vm.WorkTypeList = new List<SelectListItem>();
            List<BasicObject> listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryFactory = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            if (queryFactory != null && queryFactory.Count() > 0)
            {
                listBasicObject = queryFactory.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryBucket = _BasicObjectRepository.GetSubobjectsByCode("Bucket", AppContext.CurrentUser.ProjectCode);
            if (queryBucket != null && queryBucket.Count() > 0)
            {
                listBasicObject = queryBucket.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryWorkType = _BasicObjectRepository.GetSubobjectsByCode("WorkType", AppContext.CurrentUser.ProjectCode);
            if (queryWorkType != null && queryWorkType.Count() > 0)
            {
                listBasicObject = queryWorkType.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.WorkTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            vm.DetailList = new List<TransDetailList>();
            vm.TransModel = new NuclearTsEbTrans();
            if (!string.IsNullOrEmpty(uid))
            {
                var dataList = _NuclearTsEbTransRepository.GetDetalListByTsEbTransId(uid).ToList();
                if (dataList != null && dataList.Count > 0)
                {
                    foreach (NuclearEbTransDetail detail in dataList)
                    {
                        TransDetailList model = new TransDetailList();
                        model.DetailId = detail.EbTransDetailId;
                        if (!string.IsNullOrEmpty(detail.BucketId))
                        {
                            var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId);
                            if (bucketModel == null) continue;
                            model.BucketCode = bucketModel.BucketCode;
                        }
                        model.WorkTicket = detail.TicketCode;
                        if (detail.WorkDate != null)
                            model.WorkDate = Convert.ToDateTime(detail.WorkDate.ToString()).ToShortDateString();
                        if (!string.IsNullOrEmpty(detail.WorkType))
                            model.WorkType = _BasicObjectRepository.GetBasicById(detail.WorkType).Name;
                        model.WorkTypeId = detail.WorkType;
                        if (!string.IsNullOrEmpty(detail.BucketType))
                            model.BucketType = _BasicObjectRepository.GetBasicById(detail.BucketType).Name;
                        model.BucketTypeId = detail.BucketType;
                        model.Position = detail.Position;
                        model.ControlName = detail.ControlUserName;
                        model.ControlNo = detail.ControlUserNo;
                        model.Remark = detail.Remark;
                        vm.DetailList.Add(model);
                    }
                }
                vm.TransModel = _NuclearTsEbTransRepository.GetTsEbTransModel(uid);
                detailFlag = "edit";
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(TransCondition transCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var query = _NuclearTsEbTransRepository.GetTsEbTransList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (!string.IsNullOrEmpty(transCondition.FactoryFrom) && transCondition.FactoryFrom != "0")
                query = query.Where(n => n.FactoryFrom == transCondition.FactoryFrom).ToList();
            if (!string.IsNullOrEmpty(transCondition.FactoryTo) && transCondition.FactoryTo != "0")
                query = query.Where(n => n.FactoryTo == transCondition.FactoryTo).ToList();
            if (!string.IsNullOrEmpty(transCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(transCondition.StartDate);
                query = query.Where(n => n.RecordDate >= sDate).ToList();
            }
            if (!string.IsNullOrEmpty(transCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(transCondition.EndDate);
                query = query.Where(n => n.RecordDate <= eDate).ToList();
            }

            //query = query.OrderByDescending(n => n.CreateDate).ToList();
            List<TransList> pList = new List<TransList>();
            if (query != null)
            {
                for (int i = 0; i < query.Count; i++)
                {
                    if (!string.IsNullOrEmpty(transCondition.BucketCode))
                    {
                        var qDetail = _NuclearTsEbTransRepository.GetDetalListByTsEbTransId(query[i].EbTransId).Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode);
                        var qBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.BucketCode.Contains(transCondition.BucketCode));
                        if (qDetail.ToList().Count > 0 && qBucket.ToList().Count > 0)
                        {
                            var detailList = qDetail.Join(qBucket, a => a.BucketId, b => b.BucketId, (a, b) => new { a.BucketId }).ToList();
                            if (detailList.Count == 0) continue;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    TransList prepare = new TransList();
                    prepare.TransID = query[i].EbTransId;
                    //if (string.IsNullOrEmpty(query[i].Year))
                    //    prepare.Year = "";
                    //else
                    //    prepare.Year = query[i].Year;
                    prepare.FactoryFrom = query[i].FactoryFrom;
                    prepare.FactoryTo = query[i].FactoryTo;
                    prepare.RecordName = query[i].RecordName;
                    if (query[i].RecordDate != null)
                        prepare.RecordDate = Convert.ToDateTime(query[i].RecordDate.ToString()).ToShortDateString();
                    prepare.Status = query[i].Status;
                    prepare.CreateDate = query[i].CreateDate;
                    var dataList = _NuclearTsEbTransRepository.GetDetalListByTsEbTransId(prepare.TransID).FirstOrDefault();
                    if (dataList != null)
                    {
                        prepare.WorkTicket = dataList.TicketCode;
                    }
                    pList.Add(prepare);
                }
            }
            if (!string.IsNullOrEmpty(transCondition.WorkTicket))
            {

                pList = pList.Where(d => d.WorkTicket == null ? d.WorkTicket == transCondition.WorkTicket : d.WorkTicket.ToUpper().Contains(transCondition.WorkTicket.Trim().ToUpper())).ToList();

            }

            pList = pList.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<TransList> data = pList.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<TransList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.TransID,
                    List = new List<object>() {
                    d.TransID,
                    _BasicObjectRepository.GetBasicById(d.FactoryFrom).Name,
                    d.WorkTicket,
                    _BasicObjectRepository.GetBasicById(d.FactoryTo).Name,
                    d.RecordName,
                    d.RecordDate,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "空桶运输记录添加")]
        public ActionResult AddTrans(EmptyTransVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsEbTrans trans = new NuclearTsEbTrans();
                trans = model.TransModel;
                trans.EbTransId = Guid.NewGuid().ToString();
                trans.CreateUserNo = AppContext.CurrentUser.UserId;
                trans.CreateUserName = AppContext.CurrentUser.UserName;
                trans.CreateDate = DateTime.Now;
                trans.Status = Request.Form["submitType"];
                trans.Stationcode = AppContext.CurrentUser.ProjectCode;

                #region"添加明细"

                List<NuclearEbTransDetail> detailList = new List<NuclearEbTransDetail>();
                string[] arrayBucketCode = null;
                string[] arrayWorkTicket = null;
                string[] arrayWorkDate = null;
                string[] arrayWorkType = null;
                string[] arrayBucketType = null;
                string[] arrayPosition = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"];
                string strWorkTicket = Request.Form["hidWorkTicket"];
                string strWorkDate = Request.Form["hidWorkDate"];
                string strWorkType = Request.Form["hidWorkType"];
                string strBucketType = Request.Form["hidBucketType"];
                string strPosition = Request.Form["hidPosition"];
                string strControlNo = Request.Form["hidControlNo"];
                string strControlName = Request.Form["hidControlName"];
                string strRemark = Request.Form["hidRemark"];
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayWorkTicket = strWorkTicket.Split(new char[] { ',' });
                    arrayWorkDate = strWorkDate.Split(new char[] { ',' });
                    arrayWorkType = strWorkType.Split(new char[] { ',' });
                    arrayBucketType = strBucketType.Split(new char[] { ',' });
                    arrayPosition = strPosition.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearEbTransDetail detail = new NuclearEbTransDetail();
                        detail.EbTransDetailId = Guid.NewGuid().ToString();
                        detail.EbTransId = trans.EbTransId;
                        var bucketModel = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i].Trim(), AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                        if (trans.Status == "2")
                        {
                            _NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel.MaterialId, trans.FactoryFrom, AppContext.CurrentUser.ProjectCode, -1);
                            _NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel.MaterialId, trans.FactoryTo, AppContext.CurrentUser.ProjectCode, 1);
                            //_NuclearTempstockRepository.UnitOfWork.Commit();
                            _NuclearBucketRepository.UpdateBucketPosition(bucketModel.BucketCode, AppContext.CurrentUser.ProjectCode, trans.FactoryTo);
                            //_NuclearBucketRepository.UnitOfWork.Commit();
                            //bucketModel.LocationId = model.TransModel.FactoryTo;
                            //_NuclearBucketRepository.UpdateBucketModel(bucketModel);
                        }
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        detail.TicketCode = arrayWorkTicket[i];
                        if (!string.IsNullOrEmpty(arrayWorkDate[i]))
                            detail.WorkDate = Convert.ToDateTime(arrayWorkDate[i]);
                        detail.WorkType = arrayWorkType[i];
                        detail.BucketType = arrayBucketType[i];
                        detail.Position = arrayPosition[i];
                        detail.Remark = arrayRemark[i];
                        detail.ControlUserNo = arrayControlNo[i];
                        detail.ControlUserName = arrayControlName[i];
                        detail.ControlDate = DateTime.Now;
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                if (trans.Status == "2")
                {
                    trans.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    trans.ConfirmUserName = AppContext.CurrentUser.UserName;
                    trans.ConfirmDate = DateTime.Now;
                }

                if (_NuclearTsEbTransRepository.AddTrans(trans, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "空桶运输记录修改及确认")]
        public ActionResult UpdateTrans(EmptyTransVM model, FormCollection formCollection)
        {
            try
            {
                string confirmFlag = model.TransModel.Status;
                model.TransModel.Status = Request.Form["submitType"];

                #region"添加明细"

                List<NuclearEbTransDetail> detailList = new List<NuclearEbTransDetail>();
                string[] arrayBucketCode = null;
                string[] arrayWorkTicket = null;
                string[] arrayWorkDate = null;
                string[] arrayWorkType = null;
                string[] arrayBucketType = null;
                string[] arrayPosition = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ", "");
                string strWorkTicket = Request.Form["hidWorkTicket"].Replace("\r\n", "").Replace(" ", "");
                string strWorkDate = Request.Form["hidWorkDate"].Replace("\r\n", "").Replace(" ", "");
                string strWorkType = Request.Form["hidWorkType"].Replace("\r\n", "").Replace(" ", "");
                string strBucketType = Request.Form["hidBucketType"].Replace("\r\n", "").Replace(" ", "");
                string strPosition = Request.Form["hidPosition"].Replace("\r\n", "").Replace(" ", "");
                string strControlNo = Request.Form["hidControlNo"].Replace("\r\n", "").Replace(" ", "");
                string strControlName = Request.Form["hidControlName"].Replace("\r\n", "").Replace(" ", "");
                string strRemark = Request.Form["hidRemark"].Replace("\r\n", "").Replace(" ", "");
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayWorkTicket = strWorkTicket.Split(new char[] { ',' });
                    arrayWorkDate = strWorkDate.Split(new char[] { ',' });
                    arrayWorkType = strWorkType.Split(new char[] { ',' });
                    arrayBucketType = strBucketType.Split(new char[] { ',' });
                    arrayPosition = strPosition.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearEbTransDetail detail = new NuclearEbTransDetail();
                        detail.EbTransDetailId = Guid.NewGuid().ToString();
                        detail.EbTransId = model.TransModel.EbTransId;
                        var bucketModel = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i].Trim(), AppContext.CurrentUser.ProjectCode).FirstOrDefault();
                        if (model.TransModel.Status == "2" && confirmFlag != "2")
                        {
                            _NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel.MaterialId, model.TransModel.FactoryFrom, AppContext.CurrentUser.ProjectCode, -1);
                            _NuclearTempstockRepository.MergeMaterialTmpStock(bucketModel.MaterialId, model.TransModel.FactoryTo, AppContext.CurrentUser.ProjectCode, 1);
                            //_NuclearTempstockRepository.UnitOfWork.Commit();
                            _NuclearBucketRepository.UpdateBucketPosition(bucketModel.BucketCode, AppContext.CurrentUser.ProjectCode, model.TransModel.FactoryTo);
                            //_NuclearBucketRepository.UnitOfWork.Commit();
                            //bucketModel.LocationId = model.TransModel.FactoryTo;
                            //_NuclearBucketRepository.UpdateBucketModel(bucketModel);
                        }
                        detail.BucketId = bucketModel.BucketId;
                        detail.TicketCode = arrayWorkTicket[i].Trim();
                        if (!string.IsNullOrEmpty(arrayWorkDate[i].Trim()))
                            detail.WorkDate = Convert.ToDateTime(arrayWorkDate[i].Trim());
                        detail.WorkType = arrayWorkType[i].Trim();
                        detail.BucketType = arrayBucketType[i].Trim();
                        detail.Position = arrayPosition[i].Trim();
                        detail.Remark = arrayRemark[i].Trim();
                        detail.ControlUserNo = arrayControlNo[i].Trim();
                        detail.ControlUserName = arrayControlName[i].Trim();
                        detail.ControlDate = DateTime.Now;
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                if (model.TransModel.Status == "2")
                {
                    model.TransModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.TransModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.TransModel.ConfirmDate = DateTime.Now;
                }
                if (_NuclearTsEbTransRepository.UpdateTrans(model.TransModel, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "空桶运输记录删除")]
        public ActionResult DeleteTrans()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearTsEbTransRepository.DeleteTrans(id))
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmTrans(EmptyTransVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsEbTrans trans = new NuclearTsEbTrans();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    trans = _NuclearTsEbTransRepository.GetTsEbTransModel(uid);
                else
                    trans = _NuclearTsEbTransRepository.GetTsEbTransModel(model.TransModel.EbTransId);
                trans.Status = "2";
                trans.ConfirmUserNo = AppContext.CurrentUser.UserId;
                trans.ConfirmUserName = AppContext.CurrentUser.UserName;
                trans.ConfirmDate = DateTime.Now;

                if (_NuclearTsEbTransRepository.UpdateTrans(trans, null))
                {
                    _NuclearTsEbTransRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 检查桶号是否可用
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckBucketCode()
        {
            string bucketCode = Request["code"].TrimEnd(new char[] { ',' });
            string factoryId = Request["factory"];
            string[] arrayCode = bucketCode.Split(new char[] { ',' });
            string nExistCode = string.Empty;
            string nExistFactory = string.Empty;
            string nMassage = string.Empty;
            string nAllCode = string.Empty;
            if (arrayCode != null && arrayCode.Length > 0)
            {
                foreach (string code in arrayCode)
                {
                    if (string.IsNullOrEmpty(code)) continue;
                    bool isExist = _NuclearBucketRepository.IsExist(code, AppContext.CurrentUser.ProjectCode, "EMPTY");
                    if (!isExist)
                    {
                        nExistCode += code + ",";
                    }
                    else
                    {
                        string existFactory = _NuclearBucketRepository.IsExistByFactory(code, AppContext.CurrentUser.ProjectCode, factoryId);
                        if (string.IsNullOrEmpty(existFactory))
                        {
                            nExistFactory += code + ",";
                        }
                    }
                }
            }
            nExistCode = nExistCode.TrimEnd(new char[] { ',' });
            nExistFactory = nExistFactory.TrimEnd(new char[] { ',' });
            if (!string.IsNullOrEmpty(nExistCode))
            {
                nAllCode += nExistCode + ",";
                nMassage += "您填的桶" + nExistCode + "不是空桶准备状态。";
            }
            if (!string.IsNullOrEmpty(nExistFactory))
            {
                nAllCode += nExistFactory + ",";
                nMassage += "您填的桶" + nExistFactory + "不在所选厂房内。";
            }
            nAllCode = nAllCode.TrimEnd(new char[] { ',' });
            return Json("{\"result\":true,\"msg\":\"" + nMassage + "\",\"code\":\"" + nAllCode + "\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode.ToUpper().Trim() && (e.IsOutSend == "" || e.IsOutSend == "0" || e.IsOutSend == null) && e.BucketStatus == "EMPTY").ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
