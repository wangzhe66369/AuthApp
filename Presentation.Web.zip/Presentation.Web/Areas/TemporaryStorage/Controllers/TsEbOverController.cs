﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.Controllers
{
    public class TsEbOverController : Controller
    {
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearTsEbOverRepository _NuclearTsEbOverRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        public TsEbOverController(INuclearTsEbOverRepository NuclearTsEbOverRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository
            , INuclearWastePackageRepository NuclearWastePackageRepository)
        {
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NuclearTsEbOverRepository = NuclearTsEbOverRepository;
            this._NuclearWastePackageRepository = NuclearWastePackageRepository;
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "水泥桶封盖记录")]
        public ActionResult Index()
        {
            TsEbOverVM vm = new TsEbOverVM();
            vm.OperationList = CommonHelper.GetOperationList("Ts_Ebover");
            vm.FactoryList = new List<SelectListItem>();
            vm.FactoryList.Add(new SelectListItem { Text = "请选择", Value = "0" });
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            return View(vm);
        }
        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "水泥桶封盖记录明细")]
        public ActionResult Detail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            TsEbOverVM vm = new TsEbOverVM();
            vm.OperationList = CommonHelper.GetOperationList("Ts_Ebover");
            vm.FactoryList = new List<SelectListItem>();
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            vm.DetailList = new List<OverDetailList>();
            vm.OverModel = new NuclearTsEbOver();
            if (!string.IsNullOrEmpty(uid))
            {
                var dataList = _NuclearTsEbOverRepository.GetDetalListByTsEbOverId(uid).ToList();
                if (dataList != null && dataList.Count > 0)
                {
                    foreach (NuclearOverDetail detail in dataList)
                    {
                        OverDetailList model = new OverDetailList();
                        model.DetailId = detail.OverDetailId;
                        if (!string.IsNullOrEmpty(detail.BucketId))
                        {
                            var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId);
                            if (bucketModel == null) continue;
                            model.BucketCode = bucketModel.BucketCode;
                        }
                        model.BucketWeight = detail.BucketWeight.ToString();
                        model.Ponding = detail.Ponding;
                        model.CurdleState = detail.CurdleState;
                        model.OverSpace = detail.OverSpace.ToString();
                        model.Weight = detail.Weight.ToString();
                        model.DoseRound = detail.DoseRound.ToString();
                        model.DoseTopA = detail.DoseTopA.ToString();
                        model.DoseTopB = detail.DoseTopB.ToString();
                        model.DoseMeter = detail.DoseMeter.ToString();
                        model.ControlName = detail.ControlName;
                        model.ControlNo = detail.ControlNo;
                        if (detail.ControlDate != null)
                            model.ControlDate = Convert.ToDateTime(detail.ControlDate.ToString()).ToShortDateString();
                        model.Remark = detail.Remark;
                        vm.DetailList.Add(model);
                    }
                }
                vm.OverModel = _NuclearTsEbOverRepository.GetTsEbOverModel(uid);
                detailFlag = "edit";
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(OverCondition overCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var query = _NuclearTsEbOverRepository.GetTsEbOverList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode);
            if (!string.IsNullOrEmpty(overCondition.Year))
            {
                query = query.Where(n => !string.IsNullOrEmpty(n.Year) && n.Year.Contains(overCondition.Year));
            }
            if (!string.IsNullOrEmpty(overCondition.Factory) && overCondition.Factory != "0")
                query = query.Where(n => n.Factory == overCondition.Factory);
            if (!string.IsNullOrEmpty(overCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(overCondition.StartDate);
                query = query.Where(n => n.RecordDate >= sDate);
            }
            if (!string.IsNullOrEmpty(overCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(overCondition.EndDate);
                query = query.Where(n => n.RecordDate <= eDate);
            }
            //query = query.OrderByDescending(n => n.CreateDate).ToList();
             if (!string.IsNullOrEmpty(overCondition.BucketCode))
            {

                var nuclearOverDetail = _NuclearTsEbOverRepository.GetTsEbOverDetailList(overCondition.BucketCode).GroupBy(a=>a.EbOverId).Select(g => new {EbOverId=g.Key});
              
                                      
                query = from o in query
                        join d in nuclearOverDetail
                        on o.EbOverId equals d.EbOverId
                        select o;
                                
                
            }
            
            List<OverList> pList = new List<OverList>();
            if (query != null)
            {
                for (int i = 0; i < query.Count(); i++)
                {
                    OverList over = new OverList();
                    over.OverID = query.ToList()[i].EbOverId;
                    if (string.IsNullOrEmpty(query.ToList()[i].Year))
                        over.Year = "";
                    else
                        over.Year = query.ToList()[i].Year;
                    over.Factory = query.ToList()[i].Factory;
                    over.RecordName = query.ToList()[i].RecordName;
                    if (query.ToList()[i].RecordDate != null)
                        over.RecordDate = Convert.ToDateTime(query.ToList()[i].RecordDate.ToString()).ToShortDateString();
                    over.Status = query.ToList()[i].Status;
                    over.CreateDate = query.ToList()[i].CreateDate;
                    pList.Add(over);
                }
            }
            pList = pList.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<OverList> data = pList.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<OverList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.OverID,
                    List = new List<object>() {
                    d.OverID,
                    d.Year,
                    _BasicObjectRepository.GetBasicById(d.Factory).Name,
                    d.RecordName,
                    d.RecordDate,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "水泥桶封盖记录添加")]
        public ActionResult AddOver(TsEbOverVM model, FormCollection formCollection)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return Json("{\"result\":false,\"msg\":\"未通过验证。\"}", JsonRequestBehavior.AllowGet);
                }
                NuclearTsEbOver over = new NuclearTsEbOver();
                over = model.OverModel;
                over.EbOverId = Guid.NewGuid().ToString();
                over.CreateUserNo = AppContext.CurrentUser.UserId;
                over.CreateUserName = AppContext.CurrentUser.UserName;
                over.CreateDate = DateTime.Now;
                over.Status = Request.Form["submitType"];
                over.Stationcode = AppContext.CurrentUser.ProjectCode;

                #region"添加明细"

                List<NuclearOverDetail> detailList = new List<NuclearOverDetail>();
                string[] arrayBucketCode = null;
                string[] arrayBucketWeight = null;
                string[] arrayPonding = null;
                string[] arrayCurdleState = null;
                string[] arrayOverSpace = null;
                string[] arrayWeight = null;
                string[] arrayDoseRound = null;
                string[] arrayDoseTopA = null;
                string[] arrayDoseTopB = null;
                string[] arrayDoseMeter = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayControlDate = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"];
                string strBucketWeight = Request.Form["hidBucketWeight"];
                string strPonding = Request.Form["hidPonding"];
                string strCurdleState = Request.Form["hidCurdleState"];
                string strOverSpace = Request.Form["hidOverSpace"];
                string strWeight = Request.Form["hidWeight"];
                string strDoseRound = Request.Form["hidDoseRound"];
                string strDoseTopA = Request.Form["hidDoseTopA"];
                string strDoseTopB = Request.Form["hidDoseTopB"];
                string strDoseMeter = Request.Form["hidDoseMeter"];
                string strControlNo = Request.Form["hidControlNo"];
                string strControlName = Request.Form["hidControlName"];
                string strControlDate = Request.Form["hidControlDate"];
                string strRemark = Request.Form["hidRemark"];
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayBucketWeight = strBucketWeight.Split(new char[] { ',' });
                    arrayPonding = strPonding.Split(new char[] { ',' });
                    arrayCurdleState = strCurdleState.Split(new char[] { ',' });
                    arrayOverSpace = strOverSpace.Split(new char[] { ',' });
                    arrayWeight = strWeight.Split(new char[] { ',' });
                    arrayDoseRound = strDoseRound.Split(new char[] { ',' });
                    arrayDoseTopA = strDoseTopA.Split(new char[] { ',' });
                    arrayDoseTopB = strDoseTopB.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayControlDate = strControlDate.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        if (over.Status == "2")
                        {
                            string packageCode = _NuclearWastePackageRepository.GetPackageCodebyBucketCode(arrayBucketCode[i].Trim(), AppContext.CurrentUser.ProjectCode);
                            NuclearWastePackage package = new NuclearWastePackage();
                            if (!string.IsNullOrEmpty(arrayBucketWeight[i].Trim()))
                                package.Weight = Convert.ToDecimal(arrayBucketWeight[i].Trim());
                            _NuclearWastePackageRepository.UpdatePackage(packageCode, AppContext.CurrentUser.ProjectCode, package);
                            //_NuclearWastePackageRepository.UnitOfWork.Commit();
                        }
                        NuclearOverDetail detail = new NuclearOverDetail();
                        detail.OverDetailId = Guid.NewGuid().ToString();
                        detail.EbOverId = over.EbOverId;
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        if (!string.IsNullOrEmpty(arrayBucketWeight[i]))
                            detail.BucketWeight = Convert.ToDecimal(arrayBucketWeight[i]);
                        detail.Ponding = arrayPonding[i];
                        detail.CurdleState = arrayCurdleState[i];
                        if (!string.IsNullOrEmpty(arrayOverSpace[i]))
                            detail.OverSpace = Convert.ToDecimal(arrayOverSpace[i]);
                        if (!string.IsNullOrEmpty(arrayWeight[i]))
                            detail.Weight = arrayWeight[i];
                        if (!string.IsNullOrEmpty(arrayDoseRound[i]))
                            detail.DoseRound = Convert.ToDecimal(arrayDoseRound[i]);
                        if (!string.IsNullOrEmpty(arrayDoseTopA[i]))
                            detail.DoseTopA = Convert.ToDecimal(arrayDoseTopA[i]);
                        if (!string.IsNullOrEmpty(arrayDoseTopB[i]))
                            detail.DoseTopB = Convert.ToDecimal(arrayDoseTopB[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMeter[i]))
                            detail.DoseMeter = Convert.ToDecimal(arrayDoseMeter[i]);
                        detail.Remark = arrayRemark[i];
                        detail.ControlNo = arrayControlNo[i];
                        detail.ControlName = arrayControlName[i];
                        detail.ControlDate = DateTime.Now;
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        if (!string.IsNullOrEmpty(arrayControlDate[i]))
                            detail.CreateDate = Convert.ToDateTime(arrayControlDate[i]);
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                if (over.Status == "2")
                {
                    over.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    over.ConfirmUserName = AppContext.CurrentUser.UserName;
                    over.ConfirmDate = DateTime.Now;
                }

                if (_NuclearTsEbOverRepository.AddOver(over, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "水泥桶封盖记录修改及确认")]
        public ActionResult UpdateOver(TsEbOverVM model, FormCollection formCollection)
        {
            try
            {
                string confirmFlag = model.OverModel.Status;
                model.OverModel.Status = Request.Form["submitType"];

                #region"添加明细"

                List<NuclearOverDetail> detailList = new List<NuclearOverDetail>();
                string[] arrayBucketCode = null;
                string[] arrayBucketWeight = null;
                string[] arrayPonding = null;
                string[] arrayCurdleState = null;
                string[] arrayOverSpace = null;
                string[] arrayWeight = null;
                string[] arrayDoseRound = null;
                string[] arrayDoseTopA = null;
                string[] arrayDoseTopB = null;
                string[] arrayDoseMeter = null;
                string[] arrayControlNo = null;
                string[] arrayControlName = null;
                string[] arrayControlDate = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ", "");
                string strBucketWeight = Request.Form["hidBucketWeight"].Replace("\r\n", "").Replace(" ", "");
                string strPonding = Request.Form["hidPonding"].Replace("\r\n", "").Replace(" ", "");
                string strCurdleState = Request.Form["hidCurdleState"].Replace("\r\n", "").Replace(" ", "");
                string strOverSpace = Request.Form["hidOverSpace"].Replace("\r\n", "").Replace(" ", "");
                string strWeight = Request.Form["hidWeight"].Replace("\r\n", "").Replace(" ", "");
                string strDoseRound = Request.Form["hidDoseRound"].Replace("\r\n", "").Replace(" ", "");
                string strDoseTopA = Request.Form["hidDoseTopA"].Replace("\r\n", "").Replace(" ", "");
                string strDoseTopB = Request.Form["hidDoseTopB"].Replace("\r\n", "").Replace(" ", "");
                string strDoseMeter = Request.Form["hidDoseMeter"].Replace("\r\n", "").Replace(" ", "");
                string strControlNo = Request.Form["hidControlNo"].Replace("\r\n", "").Replace(" ", "");
                string strControlName = Request.Form["hidControlName"].Replace("\r\n", "").Replace(" ", "");
                string strControlDate = Request.Form["hidControlDate"].Replace("\r\n", "").Replace(" ", "");
                string strRemark = Request.Form["hidRemark"].Replace("\r\n", "").Replace(" ", "");
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayBucketWeight = strBucketWeight.Split(new char[] { ',' });
                    arrayPonding = strPonding.Split(new char[] { ',' });
                    arrayCurdleState = strCurdleState.Split(new char[] { ',' });
                    arrayOverSpace = strOverSpace.Split(new char[] { ',' });
                    arrayWeight = strWeight.Split(new char[] { ',' });
                    arrayDoseRound = strDoseRound.Split(new char[] { ',' });
                    arrayDoseTopA = strDoseTopA.Split(new char[] { ',' });
                    arrayDoseTopB = strDoseTopB.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayControlDate = strControlDate.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        if (model.OverModel.Status == "2" && confirmFlag != "2")
                        {
                            string packageCode = _NuclearWastePackageRepository.GetPackageCodebyBucketCode(arrayBucketCode[i].Trim(), AppContext.CurrentUser.ProjectCode);
                            NuclearWastePackage package = new NuclearWastePackage();
                            if (!string.IsNullOrEmpty(arrayBucketWeight[i].Trim()))
                                package.Weight = Convert.ToDecimal(arrayBucketWeight[i].Trim());
                            _NuclearWastePackageRepository.UpdatePackage(packageCode, AppContext.CurrentUser.ProjectCode, package);
                            //_NuclearWastePackageRepository.UnitOfWork.Commit();
                        }
                        NuclearOverDetail detail = new NuclearOverDetail();
                        detail.OverDetailId = Guid.NewGuid().ToString();
                        detail.EbOverId = model.OverModel.EbOverId;
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i].Trim(), AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        if (!string.IsNullOrEmpty(arrayBucketWeight[i].Trim()))
                            detail.BucketWeight = Convert.ToDecimal(arrayBucketWeight[i].Trim());
                        detail.Ponding = arrayPonding[i].Trim();
                        detail.CurdleState = arrayCurdleState[i].Trim();
                        if (!string.IsNullOrEmpty(arrayOverSpace[i].Trim()))
                            detail.OverSpace = Convert.ToDecimal(arrayOverSpace[i].Trim());
                        if (!string.IsNullOrEmpty(arrayWeight[i].Trim()))
                            detail.Weight = arrayWeight[i].Trim();
                        if (!string.IsNullOrEmpty(arrayDoseRound[i].Trim()))
                            detail.DoseRound = Convert.ToDecimal(arrayDoseRound[i].Trim());
                        if (!string.IsNullOrEmpty(arrayDoseTopA[i].Trim()))
                            detail.DoseTopA = Convert.ToDecimal(arrayDoseTopA[i].Trim());
                        if (!string.IsNullOrEmpty(arrayDoseTopB[i].Trim()))
                            detail.DoseTopB = Convert.ToDecimal(arrayDoseTopB[i].Trim());
                        if (!string.IsNullOrEmpty(arrayDoseMeter[i].Trim()))
                            detail.DoseMeter = Convert.ToDecimal(arrayDoseMeter[i].Trim());
                        detail.Remark = arrayRemark[i].Trim();
                        detail.ControlNo = arrayControlNo[i].Trim();
                        detail.ControlName = arrayControlName[i].Trim();
                        if (!string.IsNullOrEmpty(arrayControlDate[i]))
                            detail.CreateDate = Convert.ToDateTime(arrayControlDate[i]);
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                if (model.OverModel.Status == "2")
                {
                    model.OverModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.OverModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.OverModel.ConfirmDate = DateTime.Now;
                }
                if (_NuclearTsEbOverRepository.UpdateOver(model.OverModel, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "水泥桶封盖记录删除")]
        public ActionResult DeleteOver()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearTsEbOverRepository.DeleteOver(id))
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmOver(TsEbOverVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsEbOver over = new NuclearTsEbOver();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    over = _NuclearTsEbOverRepository.GetTsEbOverModel(uid);
                else
                    over = _NuclearTsEbOverRepository.GetTsEbOverModel(model.OverModel.EbOverId);
                over.Status = "2";
                over.ConfirmUserNo = AppContext.CurrentUser.UserId;
                over.ConfirmUserName = AppContext.CurrentUser.UserName;
                over.ConfirmDate = DateTime.Now;

                if (_NuclearTsEbOverRepository.UpdateOver(over, null))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 检查桶号是否可用
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckBucketCode()
        {
            string bucketCode = Request["code"];
            string factoryId = Request["factory"];
            bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
            if (!bucketCheck)
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
            }
            string existFactory = _NuclearBucketRepository.IsExistByFactory(bucketCode, AppContext.CurrentUser.ProjectCode, factoryId);
            if (string.IsNullOrEmpty(existFactory))
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶不在所选厂房内。\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && e.IsOutSend == null).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
