﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.Controllers
{
    public class TsRbTransController : Controller
    {
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearTsRbTransRepository _NuclearTsRbTransRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        public TsRbTransController(INuclearTsRbTransRepository NuclearTsRbTransRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository
            , INuclearTempstockRepository NuclearTempstockRepository)
        {
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NuclearTsRbTransRepository = NuclearTsRbTransRepository;
            this._NuclearTempstockRepository = NuclearTempstockRepository;
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "源项废物运输记录")]
        public ActionResult Index()
        {
            TsRbTransVM vm = new TsRbTransVM();
            vm.OperationList = CommonHelper.GetOperationList("Ts_Rb_Trans");
            vm.FactoryList = new List<SelectListItem>();
            vm.FactoryList.Add(new SelectListItem { Text = "请选择", Value = "0" });
            vm.RubbishTypeList = new List<SelectListItem>();
            vm.RubbishTypeList.Add(new SelectListItem { Text = "请选择", Value = "0" });
            List<BasicObject> listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryFactory = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            if (queryFactory != null && queryFactory.Count() > 0)
            {
                listBasicObject = queryFactory.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryNuClearType = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            if (queryNuClearType != null && queryNuClearType.Count() > 0)
            {
                listBasicObject = queryNuClearType.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.RubbishTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            return View(vm);
        }
        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "源项废物运输记录明细")]
        public ActionResult Detail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            TsRbTransVM vm = new TsRbTransVM();
            vm.OperationList = CommonHelper.GetOperationList("Ts_Rb_Trans");
            vm.FactoryList = new List<SelectListItem>();
            vm.RubbishTypeList = new List<SelectListItem>();
            List<BasicObject> listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryFactory = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode);
            if (queryFactory != null && queryFactory.Count() > 0)
            {
                listBasicObject = queryFactory.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryNuClearType = _BasicObjectRepository.GetSubobjectsByCode("NuClearType",AppContext.CurrentUser.ProjectCode);
            if (queryNuClearType != null && queryNuClearType.Count() > 0)
            {
                listBasicObject = queryNuClearType.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.RubbishTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            vm.DetailList = new List<TsRbTransDetailList>();
            vm.TsRbTransModel = new NuclearTsRbTrans();
            if (!string.IsNullOrEmpty(uid))
            {
                var dataList = _NuclearTsRbTransRepository.GetDetalListByTsRbTransId(uid).ToList();
                if (dataList != null && dataList.Count > 0)
                {
                    foreach (NuclearRbTransDetail detail in dataList)
                    {
                        TsRbTransDetailList model = new TsRbTransDetailList();
                        model.RbTransDetailId = detail.RbTransDetailId;
                        if (!string.IsNullOrEmpty(detail.BucketId))
                        {
                            var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId);
                            if (bucketModel == null) continue;
                            model.BucketCode = bucketModel.BucketCode;
                        }
                        string tId = detail.OrderCode;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack != null && listTrack.Count > 0)
                            model.OrderCode = listTrack[0].TrackCode;
                        model.RubbishTypeName = _BasicObjectRepository.GetBasicById(detail.RubbishType).Name;
                        model.RubbishTypeId = detail.RubbishType;
                        model.RubbishName = detail.RubbishName;
                        model.OrderCode = detail.OrderCode;
                        if (detail.WorkDate != null)
                            model.WorkDate = Convert.ToDateTime(detail.WorkDate.ToString()).ToShortDateString();
                        model.PositionOldId = detail.PositionOldId;
                        model.PositionNewId = detail.PositionNewId;
                        var oldFactory = _BasicObjectRepository.GetBasicById(detail.PositionOldId);
                        if (oldFactory != null)
                            model.PositionOld = oldFactory.Name;
                        var newFactory = _BasicObjectRepository.GetBasicById(detail.PositionNewId);
                        if (newFactory != null)
                            model.PositionNew = newFactory.Name;
                        model.ControlName = detail.ControlUserName;
                        model.ControlNo = detail.ControlUserNo;
                        if (detail.ControlDate != null)
                            model.ControlDate = Convert.ToDateTime(detail.ControlDate.ToString()).ToShortDateString();
                        model.Remark = detail.Remark;
                        vm.DetailList.Add(model);
                    }
                }
                vm.TsRbTransModel = _NuclearTsRbTransRepository.GetTsRbTransModel(uid);
                detailFlag = "edit";
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(TsRbTransCondition transCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var query = _NuclearTsRbTransRepository.GetTsRbTransList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (!string.IsNullOrEmpty(transCondition.Year))
            {
                query = query.Where(n => !string.IsNullOrEmpty(n.Year) && n.Year.Contains(transCondition.Year)).ToList();
            }
            if (!string.IsNullOrEmpty(transCondition.Factory) && transCondition.Factory != "0")
                query = query.Where(n => n.Factory == transCondition.Factory).ToList();
            if (!string.IsNullOrEmpty(transCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(transCondition.StartDate);
                query = query.Where(n => n.RecordDate >= sDate).ToList();
            }
            if (!string.IsNullOrEmpty(transCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(transCondition.EndDate);
                query = query.Where(n => n.RecordDate <= eDate).ToList();
            }
            //query = query.OrderByDescending(n => n.CreateDate).ToList();
            List<TsRbTransList> pList = new List<TsRbTransList>();
            if (query != null)
            {
                for (int i = 0; i < query.Count; i++)
                {
                    TsRbTransList trans = new TsRbTransList();
                    trans.TransID = query[i].RbTransId;
                    if (string.IsNullOrEmpty(query[i].Year))
                        trans.Year = "";
                    else
                        trans.Year = query[i].Year;
                    var factoryModel = _BasicObjectRepository.GetBasicById(query[i].Factory);
                    if (factoryModel != null)
                        trans.Factory = factoryModel.Name;
                    trans.RecordName = query[i].RecordName;
                    if (query[i].RecordDate != null)
                        trans.RecordDate = Convert.ToDateTime(query[i].RecordDate.ToString()).ToShortDateString();
                    trans.Status = query[i].Status;
                    trans.CreateDate = query[i].CreateDate;
                    pList.Add(trans);
                }
            }
            pList = pList.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<TsRbTransList> data = pList.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<TsRbTransList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.TransID,
                    List = new List<object>() {
                    d.TransID,
                    d.Year,
                    d.Factory,
                    d.RecordName,
                    d.RecordDate,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "源项废物运输记录添加")]
        public ActionResult AddTrans(TsRbTransVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsRbTrans trans = new NuclearTsRbTrans();
                trans = model.TsRbTransModel;
                trans.RbTransId = Guid.NewGuid().ToString();
                trans.CreateUserNo = AppContext.CurrentUser.UserId;
                trans.CreateUserName = AppContext.CurrentUser.UserName;
                trans.CreateDate = DateTime.Now;
                trans.Status = Request.Form["submitType"];
                trans.Stationcode = AppContext.CurrentUser.ProjectCode;

                #region"添加明细"

                List<NuclearRbTransDetail> detailList = new List<NuclearRbTransDetail>();
                string[] arrayRubbishType = null;
                string[] arrayRubbishName = null;
                string[] arrayOrderCode = null;
                string[] arrayWorkDate = null;
                string[] arrayPositionOld = null;
                string[] arrayPositionNew = null;
                string[] arrayBucketCode = null;
                string[] arrayControlName = null;
                string[] arrayControlNo = null;
                string[] arrayControlDate = null;
                string[] arrayRemark = null;
                string strRubbishType = Request.Form["hidRubbishType"];
                string strRubbishName = Request.Form["hidRubbishName"];
                string strOrderCode = Request.Form["hidOrderCode"];
                string strWorkDate = Request.Form["hidWorkDate"];
                string strPositionOld = Request.Form["hidPositionOld"];
                string strPositionNew = Request.Form["hidPositionNew"];
                string strBucketCode = Request.Form["hidBucketCode"];
                string strControlNo = Request.Form["hidControlNo"];
                string strControlName = Request.Form["hidControlName"];
                string strControlDate = Request.Form["hidControlDate"];
                string strRemark = Request.Form["hidRemark"];
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayRubbishType = strRubbishType.Split(new char[] { ',' });
                    arrayRubbishName = strRubbishName.Split(new char[] { ',' });
                    arrayOrderCode = strOrderCode.Split(new char[] { ',' });
                    arrayWorkDate = strWorkDate.Split(new char[] { ',' });
                    arrayPositionOld = strPositionOld.Split(new char[] { ',' });
                    arrayPositionNew = strPositionNew.Split(new char[] { ',' });
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayControlDate = strControlDate.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearRbTransDetail detail = new NuclearRbTransDetail();
                        detail.RbTransDetailId = Guid.NewGuid().ToString();
                        detail.RbTransId = trans.RbTransId;
                        if (!string.IsNullOrEmpty(arrayBucketCode[i]))
                            detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(arrayOrderCode[i], AppContext.CurrentUser.ProjectCode).ToList();
                        if (trans.Status == "2")
                        {
                            if (listTrack != null && listTrack.Count > 0)
                            {
                                detail.OrderCode = listTrack[0].TrackId;
                                string trackType = TrackItemBuilder.GetNameByCode(listTrack[0].TrackType);
                                TrackItemBuilder.UpdateTrackByType(trackType, listTrack[0].TrackId, detail.BucketId, arrayPositionNew[i]);
                                if (!string.IsNullOrEmpty(arrayBucketCode[i]))
                                {
                                    _NuclearBucketRepository.UpdateBucketWasteType(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode, trackType, trackType + "源项废物", null);
                                }
                            }
                        }
                        if (listTrack != null && listTrack.Count > 0)
                            detail.OrderCode = listTrack[0].TrackId;
                        detail.RubbishType = arrayRubbishType[i];
                        detail.RubbishName = arrayRubbishName[i];
                        detail.OrderCode = arrayOrderCode[i];
                        if (!string.IsNullOrEmpty(arrayWorkDate[i]))
                            detail.WorkDate = Convert.ToDateTime(arrayWorkDate[i]);
                        detail.PositionOldId = arrayPositionOld[i];
                        detail.PositionNewId = arrayPositionNew[i];
                        detail.Remark = arrayRemark[i];
                        detail.ControlUserNo = arrayControlNo[i];
                        detail.ControlUserName = arrayControlName[i];
                        if (!string.IsNullOrEmpty(arrayControlDate[i]))
                            detail.ControlDate = Convert.ToDateTime(arrayControlDate[i]);
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                if (trans.Status == "2")
                {
                    trans.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    trans.ConfirmUserName = AppContext.CurrentUser.UserName;
                    trans.ConfirmDate = DateTime.Now;
                }

                if (_NuclearTsRbTransRepository.AddTrans(trans, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "源项废物运输记录修改及确认")]
        public ActionResult UpdateTrans(TsRbTransVM model, FormCollection formCollection)
        {
            try
            {
                string confirmFlag = model.TsRbTransModel.Status;
                model.TsRbTransModel.Status = Request.Form["submitType"];

                #region"添加明细"

                List<NuclearRbTransDetail> detailList = new List<NuclearRbTransDetail>();
                string[] arrayRubbishType = null;
                string[] arrayRubbishName = null;
                string[] arrayOrderCode = null;
                string[] arrayWorkDate = null;
                string[] arrayPositionOld = null;
                string[] arrayPositionNew = null;
                string[] arrayBucketCode = null;
                string[] arrayControlName = null;
                string[] arrayControlNo = null;
                string[] arrayControlDate = null;
                string[] arrayRemark = null;
                string strRubbishType = Request.Form["hidRubbishType"].Replace("\r\n", "").Replace(" ", "");
                string strRubbishName = Request.Form["hidRubbishName"].Replace("\r\n", "").Replace(" ", "");
                string strOrderCode = Request.Form["hidOrderCode"].Replace("\r\n", "").Replace(" ", "");
                string strWorkDate = Request.Form["hidWorkDate"].Replace("\r\n", "").Replace(" ", "");
                string strPositionOld = Request.Form["hidPositionOld"].Replace("\r\n", "").Replace(" ", "");
                string strPositionNew = Request.Form["hidPositionNew"].Replace("\r\n", "").Replace(" ", "");
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ", "");
                string strControlNo = Request.Form["hidControlNo"].Replace("\r\n", "").Replace(" ", "");
                string strControlName = Request.Form["hidControlName"].Replace("\r\n", "").Replace(" ", "");
                string strControlDate = Request.Form["hidControlDate"].Replace("\r\n", "").Replace(" ", "");
                string strRemark = Request.Form["hidRemark"].Replace("\r\n", "").Replace(" ", "");
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayRubbishType = strRubbishType.Split(new char[] { ',' });
                    arrayRubbishName = strRubbishName.Split(new char[] { ',' });
                    arrayOrderCode = strOrderCode.Split(new char[] { ',' });
                    arrayWorkDate = strWorkDate.Split(new char[] { ',' });
                    arrayPositionOld = strPositionOld.Split(new char[] { ',' });
                    arrayPositionNew = strPositionNew.Split(new char[] { ',' });
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayControlNo = strControlNo.Split(new char[] { ',' });
                    arrayControlName = strControlName.Split(new char[] { ',' });
                    arrayControlDate = strControlDate.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearRbTransDetail detail = new NuclearRbTransDetail();
                        detail.RbTransDetailId = Guid.NewGuid().ToString();
                        detail.RbTransId = model.TsRbTransModel.RbTransId;
                        if (!string.IsNullOrEmpty(arrayBucketCode[i]))
                            detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        if (model.TsRbTransModel.Status == "2" && confirmFlag != "2")
                        {
                            var listTrack = TrackItemBuilder.GetAllTrackList(arrayOrderCode[i], AppContext.CurrentUser.ProjectCode).ToList();
                            if (listTrack != null && listTrack.Count > 0)
                            {
                                detail.OrderCode = listTrack[0].TrackId;
                                string trackType = TrackItemBuilder.GetNameByCode(listTrack[0].TrackType);
                                TrackItemBuilder.UpdateTrackByType(trackType, listTrack[0].TrackId, detail.BucketId, arrayPositionNew[i]);
                                if (!string.IsNullOrEmpty(arrayBucketCode[i]))
                                {
                                    _NuclearBucketRepository.UpdateBucketWasteType(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode, trackType, trackType + "源项废物", null);

                                }
                            }
                        }
                        detail.RubbishType = arrayRubbishType[i];
                        detail.RubbishName = arrayRubbishName[i];
                        detail.OrderCode = arrayOrderCode[i];
                        if (!string.IsNullOrEmpty(arrayWorkDate[i]))
                            detail.WorkDate = Convert.ToDateTime(arrayWorkDate[i]);
                        detail.PositionOldId = arrayPositionOld[i];
                        detail.PositionNewId = arrayPositionNew[i];
                        detail.Remark = arrayRemark[i];
                        detail.ControlUserNo = arrayControlNo[i];
                        detail.ControlUserName = arrayControlName[i];
                        if (!string.IsNullOrEmpty(arrayControlDate[i]))
                            detail.ControlDate = Convert.ToDateTime(arrayControlDate[i]);
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.CreateDate = DateTime.Now;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                if (model.TsRbTransModel.Status == "2")
                {
                    model.TsRbTransModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.TsRbTransModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.TsRbTransModel.ConfirmDate = DateTime.Now;
                }
                if (_NuclearTsRbTransRepository.UpdateTrans(model.TsRbTransModel, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "源项废物运输记录删除")]
        public ActionResult DeleteTrans()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearTsRbTransRepository.DeleteTrans(id))
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmTrans(TsRbTransVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsRbTrans trans = new NuclearTsRbTrans();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    trans = _NuclearTsRbTransRepository.GetTsRbTransModel(uid);
                else
                    trans = _NuclearTsRbTransRepository.GetTsRbTransModel(model.TsRbTransModel.RbTransId);
                trans.Status = "2";
                trans.ConfirmUserNo = AppContext.CurrentUser.UserId;
                trans.ConfirmUserName = AppContext.CurrentUser.UserName;
                trans.ConfirmDate = DateTime.Now;

                if (_NuclearTsRbTransRepository.UpdateTrans(trans, null))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 检查桶号是否可用
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckBucketCode()
        {
            string bucketCode = Request["code"];
            string trackCode = Request["trackCode"];
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(trackCode))
            {
                var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (trackList.Count == 0)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(factoryId))
                    trackList = trackList.Where(n => n.LocationId == factoryId).ToList();
                if (trackList.Count == 0)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不在所选原始厂房中。\"}", JsonRequestBehavior.AllowGet);
                }
                string tId = trackList[0].TrackId;
                var fixList = _NuclearTsRbTransRepository.GetDetalListByTrackId(tId).ToList();
                if (fixList.Count > 0)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号已经存在。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            return Json("{\"result\":true,\"msg\":\"\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsOutSend == "0" || e.IsOutSend == null)).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 自动填充——废物跟踪单
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetTrackDataList(string keyword)
        {
            List<TrackItemVM> list = TrackItemBuilder.GetAllTrackList(keyword, AppContext.CurrentUser.ProjectCode).AsQueryable().ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            List<string> fixTrack = new List<string>();
            _NuclearTsRbTransRepository.GetDetailList().ToList().ForEach(n => {
                fixTrack.Add(n.OrderCode);
            });
            if (fixTrack.Count > 0)
                list = list.Where(n => !fixTrack.Contains(n.TrackId)).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count > 0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].TrackCode;
                    autoComplete.Code = list[i].TrackId;
                    autoCompleteList.Add(autoComplete);
                }

            }

            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
