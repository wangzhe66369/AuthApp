﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.Controllers
{
    public class GoodsCheckController : Controller
    {
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearTsGoodsRepository _NuclearTsGoodsRepository;
        public GoodsCheckController(INuclearTsGoodsRepository NuclearTsGoodsRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository)
        {
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NuclearTsGoodsRepository = NuclearTsGoodsRepository;
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "货包检查")]
        public ActionResult Index()
        {
            GoodsCheckVM vm = new GoodsCheckVM();
            vm.OperationList = CommonHelper.GetOperationList("Goods_Check");
            vm.FactoryList = new List<SelectListItem>();
            vm.FactoryList.Add(new SelectListItem { Text = "请选择", Value = "0" });
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            return View(vm);
        }
        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "货包检查明细")]
        public ActionResult Detail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            GoodsCheckVM vm = new GoodsCheckVM();
            vm.OperationList = CommonHelper.GetOperationList("Goods_Check");
            vm.FactoryList = new List<SelectListItem>();
            List<BasicObject> listBasicObject = new List<BasicObject>();
            listBasicObject = _BasicObjectRepository.GetSubobjectsByCode("Factory", AppContext.CurrentUser.ProjectCode).ToList();
            foreach (BasicObject basic in listBasicObject)
            {
                vm.FactoryList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            vm.DetailList = new List<GoodsDetailList>();
            vm.GoodsModel = new NuclearTsGoods();
            if (!string.IsNullOrEmpty(uid))
            {
                var dataList = _NuclearTsGoodsRepository.GetDetalListByTsGoodsId(uid).ToList();
                if (dataList != null && dataList.Count > 0)
                {
                    foreach (NuclearTsGoodsDetail detail in dataList)
                    {
                        GoodsDetailList model = new GoodsDetailList();
                        model.DetailId = detail.TsGoodsDetailId;
                        if (!string.IsNullOrEmpty(detail.BucketId))
                        {
                            var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId);
                            if (bucketModel == null) continue;
                            model.BucketCode = bucketModel.BucketCode;
                        }
                        model.BucketSide = detail.BucketSide;
                        model.BucketTop = detail.BucketTop;
                        model.BucketBottom = detail.BucketBottom;
                        model.Weight = detail.Weight.ToString();
                        model.DoseEva = detail.DoseEva.ToString();
                        model.DoseMeter = detail.DoseMeter.ToString();
                        model.DoseMax = detail.DoseMax.ToString();
                        model.Remark = detail.Remark;
                        vm.DetailList.Add(model);
                    }
                }
                vm.GoodsModel = _NuclearTsGoodsRepository.GetTsGoodsModel(uid);
                detailFlag = "edit";
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(GoodsCondition goodsCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var query = _NuclearTsGoodsRepository.GetTsGoodsList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (!string.IsNullOrEmpty(goodsCondition.Year))
            {
                query = query.Where(n => !string.IsNullOrEmpty(n.Year) && n.Year.Contains(goodsCondition.Year)).ToList();
            }
            if (!string.IsNullOrEmpty(goodsCondition.Factory) && goodsCondition.Factory != "0")
                query = query.Where(n => n.Factory == goodsCondition.Factory).ToList();
            if (!string.IsNullOrEmpty(goodsCondition.StartDate) && !string.IsNullOrEmpty(goodsCondition.EndDate))
            {
                DateTime sDate = Convert.ToDateTime(goodsCondition.StartDate);
                DateTime eDate = Convert.ToDateTime(goodsCondition.EndDate);
                query = query.Where(n => n.InspectionDate >= sDate && n.InspectionDate <= eDate).ToList();
            }
            //query = query.OrderByDescending(n => n.CreateDate).ToList();
            List<GoodsList> pList = new List<GoodsList>();
            if (query != null)
            {
                for (int i = 0; i < query.Count; i++)
                {
                    GoodsList goods = new GoodsList();
                    goods.GoodsID = query[i].TsGoodsId;
                    if (string.IsNullOrEmpty(query[i].Year))
                        goods.Year = "";
                    else
                        goods.Year = query[i].Year;
                    goods.Factory = query[i].Factory;
                    goods.TicketCode = query[i].TicketCode;
                    goods.RecordName = query[i].InspectionName;
                    if (query[i].InspectionDate != null)
                        goods.RecordDate = Convert.ToDateTime(query[i].InspectionDate.ToString()).ToShortDateString();
                    goods.Status = query[i].Status;
                    goods.CreateDate = query[i].CreateDate;
                    pList.Add(goods);
                }
            }
            pList = pList.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<GoodsList> data = pList.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<GoodsList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.GoodsID,
                    List = new List<object>() {
                    d.GoodsID,
                    d.Year,
                    _BasicObjectRepository.GetBasicById(d.Factory).Name,
                    d.TicketCode,
                    d.RecordName,
                    d.RecordDate,
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "货包检查添加")]
        public ActionResult AddGoods(GoodsCheckVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsGoods goods = new NuclearTsGoods();
                goods = model.GoodsModel;
                goods.TsGoodsId = Guid.NewGuid().ToString();
                goods.CreateUserNo = AppContext.CurrentUser.UserId;
                goods.CreateUserName = AppContext.CurrentUser.UserName;
                goods.CreateDate = DateTime.Now;
                goods.Status = Request.Form["submitType"];
                goods.Stationcode = AppContext.CurrentUser.ProjectCode;

                #region"添加明细"

                List<NuclearTsGoodsDetail> detailList = new List<NuclearTsGoodsDetail>();
                string[] arrayBucketCode = null;
                string[] arrayBucketSide = null;
                string[] arrayBucketTop = null;
                string[] arrayBucketBottom = null;
                string[] arrayDoseEva = null;
                string[] arrayDoseMeter = null;
                string[] arrayDoseMax = null;
                string[] arrayWeight = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"];
                string strBucketSide = Request.Form["hidBucketSide"];
                string strBucketTop = Request.Form["hidBucketTop"];
                string strBucketBottom = Request.Form["hidBucketBottom"];
                string strDoseEva = Request.Form["hidDoseEva"];
                string strDoseMeter = Request.Form["hidDoseMeter"];
                string strDoseMax = Request.Form["hidDoseMax"];
                string strWeight = Request.Form["hidWeight"];
                string strRemark = Request.Form["hidRemark"];
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayBucketSide = strBucketSide.Split(new char[] { ',' });
                    arrayBucketTop = strBucketTop.Split(new char[] { ',' });
                    arrayBucketBottom = strBucketBottom.Split(new char[] { ',' });
                    arrayWeight = strWeight.Split(new char[] { ',' });
                    arrayDoseEva = strDoseEva.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayDoseMax = strDoseMax.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearTsGoodsDetail detail = new NuclearTsGoodsDetail();
                        detail.TsGoodsDetailId = Guid.NewGuid().ToString();
                        detail.TsGoodsId = goods.TsGoodsId;
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        detail.BucketSide = arrayBucketSide[i];
                        detail.BucketTop = arrayBucketTop[i];
                        detail.BucketBottom = arrayBucketBottom[i];
                        if (!string.IsNullOrEmpty(arrayDoseEva[i]))
                            detail.DoseEva = Convert.ToDecimal(arrayDoseEva[i]);
                        if (!string.IsNullOrEmpty(arrayWeight[i]))
                            detail.Weight = Convert.ToDecimal(arrayWeight[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMeter[i]))
                            detail.DoseMeter = Convert.ToDecimal(arrayDoseMeter[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMax[i]))
                            detail.DoseMax = Convert.ToDecimal(arrayDoseMax[i]);
                        detail.Remark = arrayRemark[i];
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                if (goods.Status == "2")
                {
                    goods.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    goods.ConfirmUserName = AppContext.CurrentUser.UserName;
                    goods.ConfirmDate = DateTime.Now;
                }

                if (_NuclearTsGoodsRepository.AddGoods(goods, detailList))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "货包检查修改及确认")]
        public ActionResult UpdateGoods(GoodsCheckVM model, FormCollection formCollection)
        {
            try
            {
                model.GoodsModel.Status = Request.Form["submitType"];

                #region"添加明细"

                List<NuclearTsGoodsDetail> detailList = new List<NuclearTsGoodsDetail>();
                string[] arrayBucketCode = null;
                string[] arrayBucketSide = null;
                string[] arrayBucketTop = null;
                string[] arrayBucketBottom = null;
                string[] arrayDoseEva = null;
                string[] arrayDoseMeter = null;
                string[] arrayDoseMax = null;
                string[] arrayWeight = null;
                string[] arrayRemark = null;
                string strBucketCode = Request.Form["hidBucketCode"].Replace("\r\n", "").Replace(" ","");
                string strBucketSide = Request.Form["hidBucketSide"].Replace("\r\n", "").Replace(" ", "");
                string strBucketTop = Request.Form["hidBucketTop"].Replace("\r\n", "").Replace(" ", "");
                string strBucketBottom = Request.Form["hidBucketBottom"].Replace("\r\n", "").Replace(" ", "");
                string strDoseEva = Request.Form["hidDoseEva"].Replace("\r\n", "").Replace(" ", "");
                string strDoseMeter = Request.Form["hidDoseMeter"].Replace("\r\n", "").Replace(" ", "");
                string strDoseMax = Request.Form["hidDoseMax"].Replace("\r\n", "").Replace(" ", "");
                string strWeight = Request.Form["hidWeight"].Replace("\r\n", "").Replace(" ", "");
                string strRemark = Request.Form["hidRemark"].Replace("\r\n", "").Replace(" ", "");
                if (!string.IsNullOrEmpty(strBucketCode))
                {
                    arrayBucketCode = strBucketCode.Split(new char[] { ',' });
                    arrayBucketSide = strBucketSide.Split(new char[] { ',' });
                    arrayBucketTop = strBucketTop.Split(new char[] { ',' });
                    arrayBucketBottom = strBucketBottom.Split(new char[] { ',' });
                    arrayWeight = strWeight.Split(new char[] { ',' });
                    arrayDoseEva = strDoseEva.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayDoseMax = strDoseMax.Split(new char[] { ',' });
                    arrayDoseMeter = strDoseMeter.Split(new char[] { ',' });
                    arrayRemark = strRemark.Split(new char[] { ',' });
                }
                if (arrayBucketCode != null)
                {
                    for (int i = 0; i < arrayBucketCode.Length - 1; i++)
                    {
                        NuclearTsGoodsDetail detail = new NuclearTsGoodsDetail();
                        detail.TsGoodsDetailId = Guid.NewGuid().ToString();
                        detail.TsGoodsId = model.GoodsModel.TsGoodsId;
                        detail.BucketId = _NuclearBucketRepository.QueryListByCode(arrayBucketCode[i], AppContext.CurrentUser.ProjectCode).ToList()[0].BucketId;
                        detail.BucketSide = arrayBucketSide[i];
                        detail.BucketTop = arrayBucketTop[i];
                        detail.BucketBottom = arrayBucketBottom[i];
                        if (!string.IsNullOrEmpty(arrayDoseEva[i]))
                            detail.DoseEva = Convert.ToDecimal(arrayDoseEva[i]);
                        if (!string.IsNullOrEmpty(arrayWeight[i]))
                            detail.Weight = Convert.ToDecimal(arrayWeight[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMeter[i]))
                            detail.DoseMeter = Convert.ToDecimal(arrayDoseMeter[i]);
                        if (!string.IsNullOrEmpty(arrayDoseMax[i]))
                            detail.DoseMax = Convert.ToDecimal(arrayDoseMax[i]);
                        detail.Remark = arrayRemark[i];
                        detail.CreateUserNo = AppContext.CurrentUser.UserId;
                        detail.CreateUserName = AppContext.CurrentUser.UserName;
                        detail.Status = Request.Form["submitType"];
                        detail.Stationcode = AppContext.CurrentUser.ProjectCode;
                        detailList.Add(detail);
                    }
                }

                #endregion

                if (model.GoodsModel.Status == "2")
                {
                    model.GoodsModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.GoodsModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.GoodsModel.ConfirmDate = DateTime.Now;
                }
                if (_NuclearTsGoodsRepository.UpdateGoods(model.GoodsModel, detailList))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "货包检查删除")]
        public ActionResult DeleteGoods()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearTsGoodsRepository.DeleteGoods(id))
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmGoods(GoodsCheckVM model, FormCollection formCollection)
        {
            try
            {
                NuclearTsGoods goods = new NuclearTsGoods();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    goods = _NuclearTsGoodsRepository.GetTsGoodsModel(uid);
                else
                    goods = _NuclearTsGoodsRepository.GetTsGoodsModel(model.GoodsModel.TsGoodsId);
                goods.Status = "2";
                goods.ConfirmUserNo = AppContext.CurrentUser.UserId;
                goods.ConfirmUserName = AppContext.CurrentUser.UserName;
                goods.ConfirmDate = DateTime.Now;

                if (_NuclearTsGoodsRepository.UpdateGoods(goods, null))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 检查桶号是否可用
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckBucketCode()
        {
            string bucketCode = Request["code"];
            string factoryId = Request["factory"];
            bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
            if (!bucketCheck)
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
            }
            string existFactory = _NuclearBucketRepository.IsExistByFactory(bucketCode, AppContext.CurrentUser.ProjectCode, factoryId);
            if (string.IsNullOrEmpty(existFactory))
            {
                return Json("{\"result\":false,\"msg\":\"您填的桶不在所选厂房内。\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && e.IsOutSend == null).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
