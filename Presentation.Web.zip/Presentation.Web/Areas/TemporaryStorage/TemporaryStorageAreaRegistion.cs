﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage
{
    public class TemporaryStorageAreaRegistion:AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "TemporaryStorage";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "TemporaryStorage_default",
                "TemporaryStorage/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}