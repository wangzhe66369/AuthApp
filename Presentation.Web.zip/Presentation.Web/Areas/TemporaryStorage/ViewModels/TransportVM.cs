﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels
{
    public class TransportVM
    {

        /// <summary>
        /// 存储位置列表
        /// </summary>
        public List<SelectListItem> SavePositionList { get; set; }
        /// <summary>
        /// 桶类型列表
        /// </summary>
        public List<SelectListItem> BucketTypeList { get; set; }
        /// <summary>
        /// 厂房列表
        /// </summary>
        public List<SelectListItem> FactoryList { get; set; }
        /// <summary>
        /// 单条信息
        /// </summary>
        public NuclearQtTrans TransModel { get; set; }
        /// <summary>
        /// 明细信息
        /// </summary>
        public NuclearQtTransDetail NuclearQtTransDetail { get; set; }
        /// <summary>
        /// 明细信息B
        /// </summary>
        public NuclearQtTransDetailB NuclearQtTransDetailB { get; set; }
        /// <summary>
        /// 明细信息列表
        /// </summary>
        public List<DetailList> DetailList { get; set; }
        /// <summary>
        /// 明细信息列表
        /// </summary>
        public List<DetailBList> DetailBList { get; set; }
        /// <summary>
        /// 厂房间废物桶转运单条信息
        /// </summary>
        public NuclearFcTrans FcTransModel { get; set; }
        /// <summary>
        /// 厂房间废物桶转运明细列表
        /// </summary>
        public List<FcTransDetailList> FcTransDetailList { get; set; }
        /// <summary>
        /// 坐标集合
        /// </summary>
        public List<PointData> PointList { get; set; }
        /// <summary>
        /// 已被占用位置的X坐标
        /// </summary>
        public string ExistPointX { get; set; }
        /// <summary>
        /// 已被占用位置的Y坐标
        /// </summary>
        public string ExistPointY { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 检索条件
    /// </summary>
    public class QTTransCondition
    {
        /// <summary>
        /// 工作票号
        /// </summary>
        public string TicketCode { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 转运时间(起)
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 转运时间(止)
        /// </summary>
        public string EndDate { get; set; }
    }
    /// <summary>
    /// 明细列表
    /// </summary>
    public class QTTransList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string TransId { get; set; }
        /// <summary>
        /// 类型（0：QT贮存移动单   1：厂房间废物桶转运）
        /// </summary>
        public string TransType { get; set; }
        /// <summary>
        /// 类型名称
        /// </summary>
        public string TransTypeName { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string TicketCode { get; set; }

        /// <summary>
        /// 桶表面平均接触剂量率
        /// </summary>
        public Nullable<decimal> DoseEva { get; set; }

        /// <summary>
        /// 距桶1米处剂量率
        /// </summary>
        public Nullable<decimal> DoseMeter { get; set; }

        /// <summary>
        /// 桶重量
        /// </summary>
        public Nullable<decimal> BucketWeight { get; set; }

        /// <summary>
        /// 贮存位置
        /// </summary>
        public string SavePosition { get; set; }

        /// <summary>
        /// 活度
        /// </summary>
        public Nullable<decimal> Activity { get; set; }

        /// <summary>
        /// 操作员
        /// </summary>
        public string ProcessName { get; set; }

        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 转运时间
        /// </summary>
        public string TransDate { get; set; }
        /// <summary>
        /// 是否确认
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// 厂房（起）
        /// </summary>
        public string FactoryFrom { get; set; }
        /// <summary>
        /// 厂房（止）
        /// </summary>
        public string FactoryTo { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Station { get; set; }

        public string SlectA { get; set; }

        public string QtPositionX { get; set; }

        public string QtPositionY { get; set; }

        public string QtPositionZ { get; set; }
        public string BucketId { get; set; }
    }
    /// <summary>
    /// 明细列表
    /// </summary>
    public class DetailList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string DetailId { get; set; }
        /// <summary>
        /// 厂房（起）
        /// </summary>
        public string FactoryFrom { get; set; }
        /// <summary>
        /// 厂房（起）
        /// </summary>
        public string FactoryFromId { get; set; }
        /// <summary>
        /// 厂房（止）
        /// </summary>
        public string FactoryTo { get; set; }
        /// <summary>
        /// 厂房（止）
        /// </summary>
        public string FactoryToId { get; set; }
        /// <summary>
        /// 固化/固定时间
        /// </summary>
        public string FixationDate { get; set; }
        /// <summary>
        /// 转运时间
        /// </summary>
        public string TransDate { get; set; }
        /// <summary>
        /// 转运票号
        /// </summary>
        public string TransTicket { get; set; }
        /// <summary>
        /// 操作人No
        /// </summary>
        public string ControlNo { get; set; }
        /// <summary>
        /// 操作人Name
        /// </summary>
        public string ControlName { get; set; }
        /// <summary>
        /// Qt位置ID
        /// </summary>
        public string QtFactoryId { get; set; }
        /// <summary>
        /// Qt位置
        /// </summary>
        public string QtFactory { get; set; }
    }
    /// <summary>
    /// 明细列表
    /// </summary>
    public class DetailBList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string DetailBId { get; set; }
        /// <summary>
        /// 厂房（起）
        /// </summary>
        public string FactoryFrom { get; set; }
        /// <summary>
        /// 厂房（起）
        /// </summary>
        public string FactoryFromId { get; set; }
        /// <summary>
        /// 厂房（止）
        /// </summary>
        public string FactoryTo { get; set; }
        /// <summary>
        /// 厂房（止）
        /// </summary>
        public string FactoryToId { get; set; }
        /// <summary>
        /// 封盖时间
        /// </summary>
        public string OverDate { get; set; }
        /// <summary>
        /// 转运时间
        /// </summary>
        public string TransDate { get; set; }
        /// <summary>
        /// 转运票号
        /// </summary>
        public string TransTicket { get; set; }
        /// <summary>
        /// 操作人No
        /// </summary>
        public string ControlNo { get; set; }
        /// <summary>
        /// 操作人Name
        /// </summary>
        public string ControlName { get; set; }

        /// <summary>
        /// Qt位置ID
        /// </summary>
        public string QtFactoryId { get; set; }
        /// <summary>
        /// Qt位置
        /// </summary>
        public string QtFactory { get; set; }
    }
    /// <summary>
    /// 厂房间废物桶转运明细
    /// </summary>
    public class FcTransDetailList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string DetailId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 桶重
        /// </summary>
        public string BucketWeight { get; set; }
        /// <summary>
        /// 位置
        /// </summary>
        public string FactoryName { get; set; }
        /// <summary>
        /// 位置ID
        /// </summary>
        public string FactoryId { get; set; }
        /// <summary>
        /// 缺陷	
        /// </summary>
        public string BucketFlaw { get; set; }
        /// <summary>
        /// 沾污
        /// </summary>
        public string BucketSully { get; set; }
        /// <summary>
        /// 放射性标识
        /// </summary>
        public string RadioAction { get; set; }
        /// <summary>
        /// 桶周围剂量率（mSv/h)
        /// </summary>
        public string DoseRound { get; set; }
        /// <summary>
        /// 上部剂量率（mSv/h)
        /// </summary>
        public string DoseTop { get; set; }
        /// <summary>
        /// 1M远处剂量率（mSv/h)
        /// </summary>
        public string DoseMeter { get; set; }
        /// <summary>
        /// 内装物
        /// </summary>
        public string Inside { get; set; }
        /// <summary>
        /// X坐标
        /// </summary>
        public string PositionX { get; set; }
        /// <summary>
        /// Y坐标
        /// </summary>
        public string PositionY { get; set; }
        /// <summary>
        /// Z坐标
        /// </summary>
        public string PositionZ { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }

        public string BucketId { get; set; }
    }
    /// <summary>
    /// 坐标集合
    /// </summary>
    public class PointData
    {
        /// <summary>
        /// 桶主键ID
        /// </summary>
        public string BucketId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 废物货包号
        /// </summary>
        public string PackageCode { get; set; }
        /// <summary>
        /// X坐标
        /// </summary>
        public string PointX { get; set; }
        /// <summary>
        /// Y坐标
        /// </summary>
        public string PointY { get; set; }
        /// <summary>
        /// Z坐标
        /// </summary>
        public string PointZ { get; set; }
    }
}