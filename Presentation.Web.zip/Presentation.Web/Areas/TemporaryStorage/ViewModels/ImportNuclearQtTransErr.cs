﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Core.Common;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels
{
    public class ImportNuclearQtTransErr
    {
        [ExportAttribute(DisplayName = "桶号", Order = 1)]
        public string BucketId { get; set; }
        [ExportAttribute(DisplayName = "工作票号", Order = 2)]
        public string TicketCode { get; set; }
        [ExportAttribute(DisplayName = "桶的类型", Order = 3)]
        public string BucketTypeId { get; set; }
        [ExportAttribute(DisplayName = "NX厂房-QS厂房", Order = 4)]
        public string NXQSONE { get; set; }
        [ExportAttribute(DisplayName = "QS固化时间", Order = 5)]
        public Nullable<System.DateTime> FixationDateQS { get; set; }
        [ExportAttribute(DisplayName = "QS工作票号", Order = 6)]
        public string TransTicketQS { get; set; }
        [ExportAttribute(DisplayName = "QS转运时间", Order = 7)]
        public Nullable<System.DateTime> TransDateQS { get; set; }
        [ExportAttribute(DisplayName = "QS操作人", Order = 8)]
        public string ProcessNameQS { get; set; }
        [ExportAttribute(DisplayName = "NX厂房-QS厂房1", Order = 9)]
        public string NXQSTWO { get; set; }
        [ExportAttribute(DisplayName = "QT固化时间", Order = 10)]
        public Nullable<System.DateTime> FixationDateQT { get; set; }
        [ExportAttribute(DisplayName = "QT工作票号", Order = 11)]
        public string TransTicketQT { get; set; }
        [ExportAttribute(DisplayName = "QT转运时间", Order = 12)]
        public Nullable<System.DateTime> TransDateQT { get; set; }
        [ExportAttribute(DisplayName = "QT操作人", Order = 13)]
        public string ProcessNameQT { get; set; }

        [ExportAttribute(DisplayName = "QSQT封盖时间", Order = 14)]
        public Nullable<System.DateTime> FixationDateQSQT { get; set; }
        [ExportAttribute(DisplayName = "QSQT工作票号", Order = 15)]
        public string TransTicketQSQT { get; set; }
        [ExportAttribute(DisplayName = "QSQT转运时间", Order = 16)]
        public Nullable<System.DateTime> TransDateQSQT { get; set; }
        [ExportAttribute(DisplayName = "QSQT操作员", Order = 17)]
        public string ProcessNameQSQT { get; set; }

        [ExportAttribute(DisplayName = "封口凝固状态", Order = 18)]
        public string CurdleFlag { get; set; }
        [ExportAttribute(DisplayName = "遗留水分", Order = 19)]
        public string WaterLeaveFlag { get; set; }
        [ExportAttribute(DisplayName = "可见缺陷", Order = 20)]
        public string FlawFlag { get; set; }
        [ExportAttribute(DisplayName = "表面沾污", Order = 21)]
        public string SullyFlag { get; set; }
        [ExportAttribute(DisplayName = "A字符值", Order = 22)]
        public string SullyCaseA { get; set; }
        [ExportAttribute(DisplayName = "B字符值", Order = 23)]
        public string SullyCaseB { get; set; }
        [ExportAttribute(DisplayName = "桶表面接触剂量率", Order = 24)]
        public Nullable<decimal> DoseEva { get; set; }
        [ExportAttribute(DisplayName = "距表面1米处剂量率", Order = 25)]
        public Nullable<decimal> DoseMeter { get; set; }
        [ExportAttribute(DisplayName = "废物标记", Order = 26)]
        public string RubbishFlag { get; set; }
        [ExportAttribute(DisplayName = "桶重量", Order = 27)]
        public Nullable<decimal> BucketWeight { get; set; }
        [ExportAttribute(DisplayName = "QT位置", Order = 28)]
        public string QtPositionX { get; set; }
        [ExportAttribute(DisplayName = "活度", Order = 29)]
        public Nullable<decimal> Activity { get; set; }
        [ExportAttribute(DisplayName = "操作员", Order = 30)]
        public string ProcessName { get; set; }
        [ExportAttribute(DisplayName = "操作日期", Order = 31)]
        public Nullable<System.DateTime> ProcessDate { get; set; }
        [ExportAttribute(DisplayName = "检查人", Order = 32)]
        public string InspectionName { get; set; }
        [ExportAttribute(DisplayName = "检查日期", Order = 33)]
        public Nullable<System.DateTime> InspectionDate { get; set; }
        [ExportAttribute(DisplayName = "备注", Order = 34)]
        public string Remark { get; set; }
        [ExportAttribute(DisplayName = "贮置电站", Order = 35)]
        public string Stationcode { get; set; }
        [ExportAttribute(DisplayName = "错误描述", Order = 36)]
        public string Error { get; set; }
    }
}