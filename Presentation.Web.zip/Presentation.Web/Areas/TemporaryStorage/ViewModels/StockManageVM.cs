﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels
{
    public class StockManageVM
    {
        /// <summary>
        /// 获取指定信息
        /// </summary>
        public NuclearTsStock StockModel { get; set; }
        /// <summary>
        /// 厂房列表
        /// </summary>
        public List<SelectListItem> FactoryList { get; set; }
        /// <summary>
        /// 明细信息列表
        /// </summary>
        public List<StockDetailData> StockDetailList { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> AttachFiles { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 检索条件
    /// </summary>
    public class StockCondition
    {
        /// <summary>
        /// 盘点时间(起)
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 盘点时间(止)
        /// </summary>
        public string EndDate { get; set; }
    }
    public class StockList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string StockId { get; set; }
        /// <summary>
        /// 盘点时间
        /// </summary>
        public string StockDate { get; set; }
        /// <summary>
        /// 附件
        /// </summary>
        public string Attachment { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
        /// <summary>
        /// 确认状态
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
    /// <summary>
    /// 明细信息
    /// </summary>
    public class StockDetailData
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string DetailId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 厂房ID
        /// </summary>
        public string FactoryId { get; set; }
        /// <summary>
        /// 厂房名称
        /// </summary>
        public string FactoryName { get; set; }
    }
}