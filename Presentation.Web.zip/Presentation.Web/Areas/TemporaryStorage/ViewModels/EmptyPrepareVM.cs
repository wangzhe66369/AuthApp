﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels
{
    public class EmptyPrepareVM
    {
        /// <summary>
        /// 工作类型下拉列表
        /// </summary>
        public List<SelectListItem> WorkTypeList { get; set; }
        /// <summary>
        /// 桶类型下拉列表
        /// </summary>
        public List<SelectListItem> BucketTypeList { get; set; }
        /// <summary>
        /// 厂房下拉列表
        /// </summary>
        public List<SelectListItem> FactoryList { get; set; }
        /// <summary>
        /// 内容材料名称下拉列表
        /// </summary>
        public List<SelectListItem> MaterialList { get; set; }
        /// <summary>
        /// 明细信息列表
        /// </summary>
        public List<PrepareDetailList> DetailList { get; set; }
        /// <summary>
        /// 指定信息
        /// </summary>
        public NuclearTsEbPrepare PrepareModel { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 检索条件
    /// </summary>
    public class PrepareCondition
    {
        /// <summary>
        /// 年份
        /// </summary>
        public string Year { get; set; }
        /// <summary>
        /// 厂房
        /// </summary>
        public string Factory { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 记录时间(起)
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 记录时间(止)
        /// </summary>
        public string EndDate { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 桶准备ID
        /// </summary>
        public string EbPrepareId { get; set; }
    }
    /// <summary>
    /// 空桶准备记录数据列表
    /// </summary>
    public class PrepareList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string PrepareID { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 厂房
        /// </summary>
        public string Factory { get; set; }
        /// <summary>
        /// 记录人
        /// </summary>
        public string RecordName { get; set; }
        /// <summary>
        /// 记录时间
        /// </summary>
        public string RecordDate { get; set; }
        /// <summary>
        /// 是否确认
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
    /// <summary>
    /// 空桶准备记录明细数据列表
    /// </summary>
    public class PrepareDetailList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string DetailId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 工作日期
        /// </summary>
        public string WorkDate { get; set; }
        /// <summary>
        /// 工作类型
        /// </summary>
        public string WorkType { get; set; }
        /// <summary>
        /// 工作类型主键ID
        /// </summary>
        public string WorkTypeId { get; set; }
        /// <summary>
        /// 桶类型 
        /// </summary>
        public string BucketType { get; set; }
        /// <summary>
        /// 桶类型主键ID
        /// </summary>
        public string BucketTypeId { get; set; }
        /// <summary>
        /// 位置
        /// </summary>
        public string Position { get; set; }
        /// <summary>
        /// 操作员
        /// </summary>
        public string ControlName { get; set; }
        /// <summary>
        /// 操作员工号
        /// </summary>
        public string ControlNo{ get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
        /// <summary>
        /// 内容材料名称
        /// </summary>
        public string MaterialName { get; set; }
        /// <summary>
        /// 内容材料名称ID
        /// </summary>
        public string MaterialId { get; set; }
    }
}