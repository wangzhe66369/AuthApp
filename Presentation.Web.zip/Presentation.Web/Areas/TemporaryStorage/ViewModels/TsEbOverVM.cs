﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels
{
    public class TsEbOverVM
    {
        /// <summary>
        /// 厂房下拉列表
        /// </summary>
        public List<SelectListItem> FactoryList { get; set; }
        /// <summary>
        /// 指定信息
        /// </summary>
        public NuclearTsEbOver OverModel { get; set; }
        /// <summary>
        /// 明细信息列表
        /// </summary>
        public List<OverDetailList> DetailList { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 检索条件
    /// </summary>
    public class OverCondition
    {
        /// <summary>
        /// 年份
        /// </summary>
        public string Year { get; set; }
        /// <summary>
        /// 厂房
        /// </summary>
        public string Factory { get; set; }
        /// <summary>
        /// 记录时间(起)
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 记录时间(止)
        /// </summary>
        public string EndDate { get; set; }
        public string BucketCode { get; set; }
    }
    /// <summary>
    /// 空桶准备记录数据列表
    /// </summary>
    public class OverList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string OverID { get; set; }
        /// <summary>
        /// 年份
        /// </summary>
        public string Year { get; set; }
        /// <summary>
        /// 厂房
        /// </summary>
        public string Factory { get; set; }
        /// <summary>
        /// 记录人
        /// </summary>
        public string RecordName { get; set; }
        /// <summary>
        /// 记录时间
        /// </summary>
        public string RecordDate { get; set; }
        /// <summary>
        /// 是否确认
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
    /// <summary>
    /// 空桶准备记录明细数据列表
    /// </summary>
    public class OverDetailList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string DetailId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 桶重
        /// </summary>
        public string BucketWeight { get; set; }
        /// <summary>
        /// 表面积水
        /// </summary>
        public string Ponding { get; set; }
        /// <summary>
        /// 凝固状态
        /// </summary>
        public string CurdleState { get; set; }
        /// <summary>
        /// 封盖空间(cm)
        /// </summary>
        public string OverSpace { get; set; }
        /// <summary>
        /// 屏蔽重量/厚度(kg/mm)
        /// </summary>
        public string Weight { get; set; }
        /// <summary>
        /// 同周围平均剂量率（mSv/h）
        /// </summary>
        public string DoseRound { get; set; }
        /// <summary>
        /// 封盖前上部剂量率（mSv/h）
        /// </summary>
        public string DoseTopA { get; set; }
        /// <summary>
        /// 封盖后上部剂量率(mSv/h)
        /// </summary>
        public string DoseTopB { get; set; }
        /// <summary>
        /// 1米远处剂量率(mSv/h)
        /// </summary>
        public string DoseMeter { get; set; }
        /// <summary>
        /// 操作员
        /// </summary>
        public string ControlName { get; set; }
        /// <summary>
        /// 操作员工号
        /// </summary>
        public string ControlNo { get; set; }
        /// <summary>
        /// 操作时间
        /// </summary>
        public string ControlDate { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}