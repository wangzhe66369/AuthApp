﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels
{
    public class PackageRecordVM
    {
        /// <summary>
        /// 厂房下拉列表
        /// </summary>
        public List<SelectListItem> FactoryFromList { get; set; }
        /// <summary>
        /// 厂房下拉列表
        /// </summary>
        public List<SelectListItem> FactoryToList { get; set; }
        /// <summary>
        /// 入库model信息
        /// </summary>
        public NuclearTsGoodsIn GoodsInModel { get; set; }
        /// <summary>
        /// 出库model信息
        /// </summary>
        public NuclearTsGoodsOut GoodsOutModel { get; set; }
        /// <summary>
        /// 明细列表
        /// </summary>
        public List<PackageDetailList> DetailList { get; set; }
        /// <summary>
        /// 入库RP附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> RecordInRpAttachFiles { get; set; }
        /// <summary>
        /// 入库北龙处置厂附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> RecordInSiteAttachFiles { get; set; }
        /// <summary>
        /// 入库服务处负责人附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> RecordInServiceAttachFiles { get; set; }
        /// <summary>
        /// 出库RP附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> RecordOutRpAttachFiles { get; set; }
        /// <summary>
        /// 出库北龙处置厂附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> RecordOutSiteAttachFiles { get; set; }
        /// <summary>
        /// 出库服务处负责人附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> RecordOutServiceAttachFiles { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 检索条件
    /// </summary>
    public class PackageCondition
    {
        /// <summary>
        /// 工作票号
        /// </summary>
        public string TicketCode { get; set; }
        /// <summary>
        /// 批次
        /// </summary>
        public string Batch { get; set; }
        /// <summary>
        /// 出入库时间(起)
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 出入库时间止)
        /// </summary>
        public string EndDate { get; set; }
    }
    /// <summary>
    /// 数据列表
    /// </summary>
    public class PackageList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string PackageId { get; set; }
        /// <summary>
        /// 数据类型（0：入库   1：出库）
        /// </summary>
        public string ControlType { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string TicketCode { get; set; }
        /// <summary>
        /// 批次
        /// </summary>
        public string Batch { get; set; }
        /// <summary>
        /// 出入库原因
        /// </summary>
        public string Reason { get; set; }
        /// <summary>
        /// 记录人
        /// </summary>
        public string RecordName { get; set; }
        /// <summary>
        /// 时间
        /// </summary>
        public string RecordDate { get; set; }
        /// <summary>
        /// 是否确认
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }

    public class PackageDetailList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string DetailId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 货包号
        /// </summary>
        public string PackageCode { get; set; }
        /// <summary>
        /// 内容物
        /// </summary>
        public string ContentGoods { get; set; }
        /// <summary>
        /// 表面接触剂量率（mSv/h）
        /// </summary>
        public string DoseSurface { get; set; }
        /// <summary>
        /// 1米远处剂量率(mSv/h)
        /// </summary>
        public string DoseMeter { get; set; }
        /// <summary>
        /// a污染情况(Bq/cm2)
        /// </summary>
        public string PolluteA { get; set; }
        /// <summary>
        /// B污染情况(Bq/cm2)
        /// </summary>
        public string PolluteB { get; set; }
        /// <summary>
        /// 货包外观情况
        /// </summary>
        public string Facade { get; set; }
        /// <summary>
        /// 操作人
        /// </summary>
        public string ControlName { get; set; }
        /// <summary>
        /// 操作人ID
        /// </summary>
        public string ControlNo { get; set; }
        /// <summary>
        /// 日期
        /// </summary>
        public string ControlDate { get; set; }
        /// <summary>
        /// 位置
        /// </summary>
        public string Position { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}