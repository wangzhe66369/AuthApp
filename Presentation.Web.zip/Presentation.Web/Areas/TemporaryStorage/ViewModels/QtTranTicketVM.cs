﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OMP.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels
{
    public class QtTranTicketVM
    {
        public QtTranTicket QtTranTicket { get; set; }
    }
}