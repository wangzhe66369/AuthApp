﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels
{
    public class InventoryPositionVM
    {
        /// <summary>
        /// QT移动单数据
        /// </summary>
        public List<NuclearQtTrans> TransList { get; set; }
        /// <summary>
        /// 厂房列表
        /// </summary>
        public List<FactoryInfo> FactoryList { get; set; }
        /// <summary>
        /// 桶信息列表
        /// </summary>
        public List<BucketTypeInfo> BucketTypeList { get; set; }
        /// <summary>
        /// 表头
        /// </summary>
        public List<string> Header { get; set; }
        /// <summary>
        /// 已被占用的坐标信息列表
        /// </summary>
        public List<ExistPointData> PointList { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 厂房信息
    /// </summary>
    public class FactoryInfo
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string FactoryId { get; set; }
        /// <summary>
        /// 名称
        /// </summary>
        public string FactoryName { get; set; }
    }
    /// <summary>
    /// 桶类型及材料信息
    /// </summary>
    public class BucketTypeInfo
    {
        /// <summary>
        /// 对应的材料主键ID
        /// </summary>
        public string MaterialId { get; set; }
        /// <summary>
        /// 名称
        /// </summary>
        public string BucketName { get; set; }
        /// <summary>
        /// 厂房ID
        /// </summary>
        public string FactoryId { get; set; }
        /// <summary>
        /// 类型（0：桶类型  其他为废物类型（缩写））
        /// </summary>
        public string Type { get; set; }
        /// <summary>
        /// 未封盖数量
        /// </summary>
        public decimal? Amount { get; set; }
        /// <summary>
        /// 已封盖数量
        /// </summary>
        public decimal? CoverAmount { get; set; }
        /// <summary>
        /// 废物类型数量
        /// </summary>
        public decimal? Quantity { get; set; }
    }
    /// <summary>
    /// 已被占用的坐标信息
    /// </summary>
    public class ExistPointData
    {
        /// <summary>
        /// 桶主键ID
        /// </summary>
        public string BucketId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 废物货包号
        /// </summary>
        public string PackageCode { get; set; }
        /// <summary>
        /// X坐标
        /// </summary>
        public string PointX { get; set; }
        /// <summary>
        /// Y坐标
        /// </summary>
        public string PointY { get; set; }
        /// <summary>
        /// Z坐标
        /// </summary>
        public string PointZ { get; set; }
    }
    /// <summary>
    /// 5层坐标集合（只有5条数据）
    /// </summary>
    public class PointDataImg
    {
        /// <summary>
        /// X坐标
        /// </summary>
        public string PointX { get; set; }
        /// <summary>
        /// Y坐标
        /// </summary>
        public string PointY { get; set; }
        /// <summary>
        /// Z坐标
        /// </summary>
        public string PointZ { get; set; }
    }
}