﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;


namespace RWIS.Presentation.Web.Areas.TemporaryStorage.ViewModels
{
    public class TsRbTransVM
    {
        /// <summary>
        /// 厂房下拉列表
        /// </summary>
        public List<SelectListItem> FactoryList { get; set; }
        /// <summary>
        /// 废物类型下拉列表
        /// </summary>
        public List<SelectListItem> RubbishTypeList { get; set; }
        /// <summary>
        /// 指定信息
        /// </summary>
        public NuclearTsRbTrans TsRbTransModel { get; set; }
        /// <summary>
        /// 明细信息列表
        /// </summary>
        public List<TsRbTransDetailList> DetailList { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 检索条件
    /// </summary>
    public class TsRbTransCondition
    {
        /// <summary>
        /// 年份
        /// </summary>
        public string Year { get; set; }
        /// <summary>
        /// 厂房
        /// </summary>
        public string Factory { get; set; }
        /// <summary>
        /// 记录时间(起)
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 记录时间(止)
        /// </summary>
        public string EndDate { get; set; }
    }
    /// <summary>
    /// 空桶准备记录数据列表
    /// </summary>
    public class TsRbTransList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string TransID { get; set; }
        /// <summary>
        /// 年份
        /// </summary>
        public string Year { get; set; }
        /// <summary>
        /// 厂房
        /// </summary>
        public string Factory { get; set; }
        /// <summary>
        /// 记录人
        /// </summary>
        public string RecordName { get; set; }
        /// <summary>
        /// 记录时间
        /// </summary>
        public string RecordDate { get; set; }
        /// <summary>
        /// 是否确认
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
    /// <summary>
    /// 源项废物运输记录明细数据列表
    /// </summary>
    public class TsRbTransDetailList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string RbTransDetailId { get; set; }
        /// <summary>
        /// 废物类型        
        /// </summary>
        public string RubbishTypeName { get; set; }
        /// <summary>
        /// 废物类型ID        
        /// </summary>
        public string RubbishTypeId { get; set; }
        /// <summary>
        /// 废物名称
        /// </summary>
        public string RubbishName { get; set; }
        /// <summary>
        /// 跟踪单号
        /// </summary>
        public string OrderCode { get; set; }
        /// <summary>
        /// 跟踪单类项
        /// </summary>
        public string OrderType { get; set; }
        /// <summary>
        /// 工作日期
        /// </summary>
        public string WorkDate { get; set; }
        /// <summary>
        /// 原存放位置
        /// </summary>
        public string PositionOld { get; set; }
        /// <summary>
        /// 原存放位置ID
        /// </summary>
        public string PositionOldId { get; set; }
        /// <summary>
        /// 现存放位置
        /// </summary>
        public string PositionNew { get; set; }
        /// <summary>
        /// 现存放位置ID
        /// </summary>
        public string PositionNewId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 操作员
        /// </summary>
        public string ControlName { get; set; }
        /// <summary>
        /// 操作员ID
        /// </summary>
        public string ControlNo { get; set; }
        /// <summary>
        /// 操作时间
        /// </summary>
        public string ControlDate { get; set; }
        /// <summary>
        /// 备注
        /// </summary>
        public string Remark { get; set; }
    }
}