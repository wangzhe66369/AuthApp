﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Core.Common;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels
{
    public class ImportNuclearCoverMixErr
    {
        [ExportAttribute(DisplayName = "桶号", Order = 1)]
        public string BucketId { get; set; }
        [ExportAttribute(DisplayName = "工作票号", Order = 2)]
        public string WorkTicket { get; set; }
        [ExportAttribute(DisplayName = "表面积水", Order = 3)]
        public string PondingFlag { get; set; }
        [ExportAttribute(DisplayName = "凝固状态", Order = 4)]
        public string CurdleFlag { get; set; }
        [ExportAttribute(DisplayName = "屏蔽材料", Order = 5)]
        public string Texture { get; set; }
        [ExportAttribute(DisplayName = "屏蔽厚度", Order = 6)]
        public Nullable<decimal> CurdlePly { get; set; }
        [ExportAttribute(DisplayName = "屏蔽重量", Order = 7)]
        public Nullable<decimal> CurdleWeight { get; set; }
        [ExportAttribute(DisplayName = "预留封盖空间", Order = 8)]
        public string OverSpace { get; set; }
        [ExportAttribute(DisplayName = "水泥重量", Order = 9)]
        public Nullable<decimal> Cement { get; set; }
        [ExportAttribute(DisplayName = "沙子重量", Order = 10)]
        public Nullable<decimal> Sand { get; set; }
        [ExportAttribute(DisplayName = "石块重量", Order = 11)]
        public Nullable<decimal> Stone { get; set; }
        [ExportAttribute(DisplayName = "加水量", Order = 12)]
        public Nullable<decimal> Water { get; set; }
        [ExportAttribute(DisplayName = "增塑剂量", Order = 13)]
        public Nullable<decimal> Additive { get; set; }
        [ExportAttribute(DisplayName = "搅拌时间", Order = 14)]
        public Nullable<decimal> ShakeTime { get; set; }
        [ExportAttribute(DisplayName = "水泥是否有效", Order = 15)]
        public string CementFlag { get; set; }
        [ExportAttribute(DisplayName = "封盖后上部平均剂量率", Order = 16)]
        public Nullable<decimal> DoseEva { get; set; }
        [ExportAttribute(DisplayName = "盖顶高差", Order = 17)]
        public Nullable<decimal> OverHeight { get; set; }
        [ExportAttribute(DisplayName = "QS位置", Order = 18)]
        public string PositionX { get; set; }
        public string PositionY { get; set; }
        public string PositionZ { get; set; }
        [ExportAttribute(DisplayName = "操作员", Order = 19)]
        public string ControlName { get; set; }
        [ExportAttribute(DisplayName = "操作日期", Order = 20)]
        public Nullable<System.DateTime> ControlDate { get; set; }
        [ExportAttribute(DisplayName = "检查员", Order = 21)]
        public string CheckName { get; set; }
        [ExportAttribute(DisplayName = "检查日期", Order = 22)]
        public Nullable<System.DateTime> CheckDate { get; set; }
        [ExportAttribute(DisplayName = "备注", Order = 23)]
        public string Remark { get; set; }
        [ExportAttribute(DisplayName = "封盖电站", Order = 24)]
        public string Stationcode { get; set; }
        [ExportAttribute(DisplayName = "错误描述", Order = 25)]
        public string Error { get; set; }
    }
}