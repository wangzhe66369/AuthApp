﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Core.Common;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels
{
    public class ImportNuclearCoverMetalErr
    {
        [ExportAttribute(DisplayName = "桶号", Order = 1)]
        public string BucketId { get; set; }
        [ExportAttribute(DisplayName = "工作票号", Order = 2)]
        public string WorkTicket { get; set; }
        [ExportAttribute(DisplayName = "桶体高度", Order = 3)]
        public string BucketHight { get; set; }
        [ExportAttribute(DisplayName = "桶体是否可用", Order = 4)]
        public string BucketUseFlag { get; set; }
        [ExportAttribute(DisplayName = "桶体检查人", Order = 5)]
        public string BucketCheckName { get; set; }
        [ExportAttribute(DisplayName = "桶体检查日期", Order = 6)]
        public Nullable<System.DateTime> BucketCheckDate { get; set; }
        [ExportAttribute(DisplayName = "废物来源", Order = 7)]
        public string WasteSource { get; set; }
        [ExportAttribute(DisplayName = "水泥重量", Order = 8)]
        public Nullable<decimal> Cement { get; set; }
        [ExportAttribute(DisplayName = "沙子重量", Order = 9)]
        public Nullable<decimal> Sand { get; set; }
        [ExportAttribute(DisplayName = "石块重量", Order = 10)]
        public Nullable<decimal> Stone { get; set; }
        [ExportAttribute(DisplayName = "加水量", Order = 11)]
        public Nullable<decimal> Water { get; set; }
        [ExportAttribute(DisplayName = "增塑剂量", Order = 12)]
        public Nullable<decimal> Additive { get; set; }
        [ExportAttribute(DisplayName = "搅拌时间", Order = 13)]
        public Nullable<decimal> ShakeTime { get; set; }
        [ExportAttribute(DisplayName = "平均接触剂量率", Order = 14)]
        public Nullable<decimal> DoseEva { get; set; }
        [ExportAttribute(DisplayName = "最大接触剂量率", Order = 15)]
        public Nullable<decimal> DoseMax { get; set; }
        [ExportAttribute(DisplayName = "QS厂房存储位置", Order = 16)]
        public string SavePosition { get; set; }
        [ExportAttribute(DisplayName = "操作员", Order = 17)]
        public string ControlSName { get; set; }
        [ExportAttribute(DisplayName = "操作日期", Order = 18)]
        public Nullable<System.DateTime> ControlSDate { get; set; }
        [ExportAttribute(DisplayName = "检查人", Order = 19)]
        public string CheckSName { get; set; }
        [ExportAttribute(DisplayName = "检查日期", Order = 20)]
        public Nullable<System.DateTime> CheckSDate { get; set; }
        [ExportAttribute(DisplayName = "备注", Order = 21)]
        public string Remark { get; set; }
        [ExportAttribute(DisplayName = "封盖电站", Order = 22)]
        public string Stationcode { get; set; }
        [ExportAttribute(DisplayName = "错误描述", Order = 23)]
        public string Error { get; set; }
    }
}