﻿/********************************************************************************
 *
 *   项目名称   ：   废物处理
 *   文 件 名   ：   CementSolidifyVM.cs
 *   描    述   ：   水泥固化
 *   创 建 者   ：   乔春明
 *   员 工 号   ：   137005
 *   创建日期   ：   2016-09-19 9:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-19 9:00:00    1.0.0.0    乔春明       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels
{
    public class CementSolidifyVM
    {
        public CementSolidifyCondition Condition { get; set; }
        /// <summary>
        /// 浓缩液装桶固化400l金属桶实体数据
        /// </summary>
        public NuclearBucketSolution BucketSolutionModel { get; set; }
        /// <summary>
        /// 固化桶类型列表
        /// </summary>
        public List<SelectListItem> BucketTypeList { get; set; }
        /// <summary>
        /// 桶状态列表
        /// </summary>
        public List<SelectListItem> BucketStatusList { get; set; }
        /// <summary>
        /// 废树脂装桶固化400l金属桶
        /// </summary>
        public NuclearBucketResin BucketResinModel { get; set; }
        /// <summary>
        /// 干湿料制备及废树脂装桶固化
        /// </summary>
        public NuclearBucketRSolidify BucketRSolidifyModel { get; set; }
        /// <summary>
        /// 干湿料制备及浓缩液装桶固化
        /// </summary>
        public NuclearBucketSSolidify BucketSSolidifyModel { get; set; }
        /// <summary>
        /// 水泥固化明细
        /// </summary>
        public List<CementSolidifyDetailList> SolidifyDetailList { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }

        /// <summary>
        /// 废树脂固化明细
        /// </summary>
        public List<GiftDetailList> GiftDetailList { get; set; }
    }
    /// <summary>
    /// 水泥固化检索条件
    /// </summary>
    public class CementSolidifyCondition
    {
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 检查日期（起）
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 检查日期（止）
        /// </summary>
        public string EndDate { get; set; }
    }
    /// <summary>
    /// 水泥固化列表
    /// </summary>
    public class CementSolidifyList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string SolidifyId { get; set; }
        /// <summary>
        /// 控制操作的类型（1：浓缩液  2：废树脂  3：干湿料制备及废树脂  4：干湿料制备及浓缩液）
        /// </summary>
        public string ControlType { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 废物类型
        /// </summary>
        public string WasteType { get; set; }
        /// <summary>
        /// 废物跟踪单号
        /// </summary>
        public string TrackCode { get; set; }
        /// <summary>
        /// 桶周围平均剂量率
        /// </summary>
        public decimal? MeteringAve { get; set; }
        /// <summary>
        /// 固化体上部剂量率
        /// </summary>
        public decimal? MeteringTop { get; set; }
        /// <summary>
        /// 桶周围最大剂量率
        /// </summary>
        public decimal? MeteringMax { get; set; }
        /// <summary>
        /// 处理工艺
        /// </summary>
        public string SolidifyType { get; set; }
        /// <summary>
        /// 操作人
        /// </summary>
        public string CheckPersonName { get; set; }
        /// <summary>
        /// 是否确认
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 有无不符合项
        /// </summary>
        public string Comformance { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
    public class CementSolidifyDetailList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string DetailId { get; set; }
        /// <summary>
        /// 关联的主表ID
        /// </summary>
        public string SolidifyId { get; set; }
        /// <summary>
        /// 桶编号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 信息类型
        /// </summary>
        public string SolidifyType { get; set; }
    }
}

public class GiftDetailList
{
    /// <summary>
    /// 主键ID
    /// </summary>
    public string TrackId { get; set; }
    /// <summary>
    /// 跟踪单号
    /// </summary>
    public string TrackCode { get; set; }
    /// <summary>
    /// 废物类型英文缩写
    /// </summary>
    public string TrackType { get; set; }
}