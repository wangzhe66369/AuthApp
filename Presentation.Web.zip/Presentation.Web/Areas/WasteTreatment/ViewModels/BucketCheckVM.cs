﻿/********************************************************************************
 *
 *   项目名称   ：   废物处理
 *   文 件 名   ：   BucketCheckVM.cs
 *   描    述   ：   桶检查
 *   创 建 者   ：   乔春明
 *   员 工 号   ：   137005
 *   创建日期   ：   2016-09-19 9:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-19 9:00:00    1.0.0.0    乔春明       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels
{
    public class BucketCheckVM
    {
        /// <summary>
        /// 桶检查实体数据
        /// </summary>
        public NuclearBucketCheck BucketCheckModel { get; set; }
        /// <summary>
        /// 电站列表
        /// </summary>
        public List<SelectListItem> StationList { get; set; }
        /// <summary>
        /// 桶类型列表
        /// </summary>
        public List<SelectListItem> BucketTypeList { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 桶检查检索条件
    /// </summary>
    public class BucketCheckCondition
    {
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 检查日期（起）
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 检查日期（止）
        /// </summary>
        public string EndDate { get; set; }
    }
    /// <summary>
    /// 桶检查列表
    /// </summary>
    public class BucketCheckList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string CheckId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 周围屏蔽厚度
        /// </summary>
        public decimal? ShieldPlyRound { get; set; }
        /// <summary>
        /// 电站ID
        /// </summary>
        public string StationId { get; set; }
        /// <summary>
        /// 电站
        /// </summary>
        public string StationName { get; set; }
        /// <summary>
        /// 石灰重量
        /// </summary>
        public decimal? Weight { get; set; }
        /// <summary>
        /// 附加屏蔽层
        /// </summary>
        public string Shield { get; set; }
        /// <summary>
        /// 提前加入石灰
        /// </summary>
        public string Lime { get; set; }
        /// <summary>
        /// 检查人
        /// </summary>
        public string CheckPersonName { get; set; }
        /// <summary>
        /// 是否确认
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 有无不符合项
        /// </summary>
        public string Comformance { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
}