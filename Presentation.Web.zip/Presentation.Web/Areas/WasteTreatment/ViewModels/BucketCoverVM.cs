﻿/********************************************************************************
 *
 *   项目名称   ：   废物处理
 *   文 件 名   ：   BucketCoverVM.cs
 *   描    述   ：   封盖
 *   创 建 者   ：   乔春明
 *   员 工 号   ：   137005
 *   创建日期   ：   2016-09-28 9:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-28 9:00:00    1.0.0.0    乔春明       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels
{
    public class BucketCoverVM
    {
        /// <summary>
        /// 湿混料制备及400L金属桶装桶封盖实体数据
        /// </summary>
        public NuclearCoverMetal CoverMetalModel { get; set; }
        /// <summary>
        /// 湿混料制备及封盖实体数据
        /// </summary>
        public NuclearCoverMix CoverMixModel { get; set; }
        /// <summary>
        /// 桶状态列表
        /// </summary>
        public List<SelectListItem> BucketStatusList { get; set; }
        /// <summary>
        /// 废物信息明细
        /// </summary>
        public List<CoverDetailDataList> CoverDetailList { get; set; }
        /// <summary>
        /// 坐标集合
        /// </summary>
        public List<PointData> PointList { get; set; }
        /// <summary>
        /// 已被占用位置的X坐标
        /// </summary>
        public string ExistPointX { get; set; }
        /// <summary>
        /// 已被占用位置的Y坐标
        /// </summary>
        public string ExistPointY { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 封盖检索条件
    /// </summary>
    public class CoverCondition
    {
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 检查日期（起）
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 检查日期（止）
        /// </summary>
        public string EndDate { get; set; }
    }
    /// <summary>
    /// 400L金属桶超压及封盖
    /// </summary>
    public class CoverList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string CoverId { get; set; }
        /// <summary>
        /// 控制操作的类型（1：湿混料制备及400L金属桶装桶封盖  2：废树脂）
        /// </summary>
        public string ControlType { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 处理工艺
        /// </summary>
        public string CoverType { get; set; }
        /// <summary>
        /// 检查人
        /// </summary>
        public string CheckPersonName { get; set; }
        /// <summary>
        /// 是否确认
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 有无不符合项
        /// </summary>
        public string Comformance { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// 208L桶号
        /// </summary>
        public string BucketCodeL { get; set; }
        /// <summary>
        /// 平均剂量率
        /// </summary>
        public decimal? DoseEva { get; set; }
        /// <summary>
        /// 最大剂量率
        /// </summary>
        public decimal? DoseMax { get; set; }
        /// <summary>
        /// 1米处剂量率
        /// </summary>
        public decimal? DoseMeter { get; set; }
    }
    /// <summary>
    /// 湿混料制备及封盖
    /// </summary>
    public class CoverMList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string CoverId { get; set; }
        /// <summary>
        /// 控制操作的类型（1：湿混料制备及400L金属桶装桶封盖  2：废树脂）
        /// </summary>
        public string ControlType { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 处理工艺
        /// </summary>
        public string CoverType { get; set; }
        /// <summary>
        /// 检查人
        /// </summary>
        public string CheckPersonName { get; set; }
        /// <summary>
        /// 是否确认
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 有无不符合项
        /// </summary>
        public string Comformance { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// 屏蔽材料
        /// </summary>
        public string MaterialFlag { get; set; }
        /// <summary>
        /// 屏蔽重量
        /// </summary>
        public decimal? CurdleWeight { get; set; }
        /// <summary>
        /// 预留封盖空间
        /// </summary>
        public string OverSpace { get; set; }
        /// <summary>
        /// 上部平均剂量率
        /// </summary>
        public decimal? DoseEva { get; set; }
        /// <summary>
        /// 1米处剂量率
        /// </summary>
        public decimal? DoseMeter { get; set; }
    }
    public class CoverDetailDataList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string DetailId { get; set; }
        /// <summary>
        /// 关联的主表ID
        /// </summary>
        public string CoverId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 打包时间
        /// </summary>
        public string BucketDate { get; set; }

        /// <summary>
        /// 废物跟踪单编号
        /// </summary>
        public string TrackCode { get; set; }

        /// <summary>
        /// 废物描述
        /// </summary>
        public string WasteDescription { get; set; }
        /// <summary>
        /// 高度
        /// </summary>
        public string Height { get; set; }
        /// <summary>
        /// 重量
        /// </summary>
        public string Weight { get; set; }
        /// <summary>
        /// 剂量率
        /// </summary>
        public string DoseRate { get; set; }
    }
    /// <summary>
    /// 坐标集合
    /// </summary>
    public class PointData
    {
        /// <summary>
        /// X坐标
        /// </summary>
        public string PointX { get; set; }
        /// <summary>
        /// Y坐标
        /// </summary>
        public string PointY { get; set; }
        /// <summary>
        /// Z坐标
        /// </summary>
        public string PointZ { get; set; }
    }
}