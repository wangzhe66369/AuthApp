﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels
{
    public class TrackAndDateVM
    {
        /// <summary>
        /// 桶ID
        /// </summary>
        public string BucketId { get; set; }

        /// <summary>
        /// 废物跟踪单编号
        /// </summary>
        public string TrackCode { get; set; }

        /// <summary>
        /// 打包时间 
        /// </summary>
        public Nullable<System.DateTime> DateTimePage { get; set; }
    }
}