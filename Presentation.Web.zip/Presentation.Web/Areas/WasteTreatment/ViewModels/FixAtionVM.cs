﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels
{
    public class FixAtionVM
    {
        /// <summary>
        /// 固定详细信息
        /// </summary>
        public NuclearFixation FixAtionModel { get; set; }
        /// <summary>
        /// 明细信息
        /// </summary>
        public List<FixAtionDetailList> FixAtionDetailList { get; set; }
        /// <summary>
        /// 桶类型列表
        /// </summary>
        public List<SelectListItem> BucketTypeList { get; set; }
        /// <summary>
        /// 桶状态列表
        /// </summary>
        public List<SelectListItem> BucketStatusList { get; set; }
        /// <summary>
        /// 废物类型列表
        /// </summary>
        public List<SelectListItem> WasteTypeList { get; set; }
        /// <summary>
        /// 当前页面所有操作
        /// </summary>
        public string OperationList { get; set; }
    }
    /// <summary>
    /// 检索条件
    /// </summary>
    public class FixAtionCondition
    {
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 检查日期（起）
        /// </summary>
        public string StartDate { get; set; }
        /// <summary>
        /// 检查日期（止）
        /// </summary>
        public string EndDate { get; set; }
    }
    /// <summary>
    /// 数据列表
    /// </summary>
    public class FixAtionList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string FixAtionId { get; set; }
        /// <summary>
        /// 桶号
        /// </summary>
        public string BucketCode { get; set; }
        /// <summary>
        /// 工作票号
        /// </summary>
        public string WorkTicket { get; set; }
        /// <summary>
        /// 废物类型
        /// </summary>
        public string WasteType { get; set; }
        /// <summary>
        /// 桶周围平均剂量率
        /// </summary>
        public decimal? MeteringAve { get; set; }
        /// <summary>
        /// 固化体上部剂量率
        /// </summary>
        public decimal? MeteringTop { get; set; }
        /// <summary>
        /// 桶周围最大剂量率
        /// </summary>
        public decimal? MeteringMax { get; set; }
        /// <summary>
        /// 废物跟踪单号
        /// </summary>
        public string TrackCode { get; set; }
        /// <summary>
        /// 操作人
        /// </summary>
        public string ControlPersonName { get; set; }
        /// <summary>
        /// 是否确认
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 有无不符合项
        /// </summary>
        public string Comformance { get; set; }
        /// <summary>
        /// 提交时间
        /// </summary>
        public DateTime? CreateDate { get; set; }
    }
    /// <summary>
    /// 废物跟踪单列表
    /// </summary>
    public class FixAtionDetailList
    {
        /// <summary>
        /// 主键ID
        /// </summary>
        public string TrackId { get; set; }
        /// <summary>
        /// 跟踪单号
        /// </summary>
        public string TrackCode { get; set; }
        /// <summary>
        /// 系统号
        /// </summary>
        public string SystemCode { get; set; }
        /// <summary>
        /// 旧过滤器尺寸
        /// </summary>
        public string ElementVersionOld { get; set; }
        /// <summary>
        /// 废物类型英文缩写
        /// </summary>
        public string TrackType { get; set; }
    }
}