﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Core.Common;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels
{
    public class NuclearBucketRSolidifyErr
    {
        [ExportAttribute(DisplayName = "桶号", Order = 1)]
        public string BucketCode { get; set; }
        [ExportAttribute(DisplayName = "工作票号", Order = 2)]
        public string WorkTicket { get; set; }
        [ExportAttribute(DisplayName = "废物跟踪单编号", Order = 3)]
        public string TrackCode { get; set; }
        [ExportAttribute(DisplayName = "水泥数量", Order = 4)]
        public string cementQuantity { get; set; }
        [ExportAttribute(DisplayName = "沙子数量", Order = 5)]
        public string sandQuantity { get; set; }
        [ExportAttribute(DisplayName = "搅拌时间", Order = 6)]
        public string ShakeTime { get; set; }
        [ExportAttribute(DisplayName = "添加剂", Order = 7)]
        public string Additive { get; set; }
        [ExportAttribute(DisplayName = "水泥是否有效", Order = 8)]
        public string CementFlag { get; set; }
        [ExportAttribute(DisplayName = "固化TES值", Order = 9)]
        public string TesBa { get; set; }
        [ExportAttribute(DisplayName = "固化补充水量", Order = 10)]
        public string Water { get; set; }
        [ExportAttribute(DisplayName = "固化总搅拌时间", Order = 11)]
        public string ShakeTimeM { get; set; }
        [ExportAttribute(DisplayName = "固化桶周围平均剂量率", Order = 12)]
        public string MeteringAve { get; set; }
        [ExportAttribute(DisplayName = "固化体上部剂量率", Order = 13)]
        public string MeteringTop { get; set; }
        [ExportAttribute(DisplayName = "固化桶周围最大剂量率", Order = 14)]
        public string MeteringMax { get; set; }
        [ExportAttribute(DisplayName = "搅拌桨", Order = 15)]
        public string shakeFlag { get; set; }
        [ExportAttribute(DisplayName = "操作员", Order = 16)]
        public string ControlPersonName { get; set; }
        [ExportAttribute(DisplayName = "操作日期", Order = 17)]
        public string ControlDate { get; set; }
        [ExportAttribute(DisplayName = "检查人", Order = 18)]
        public string CheckPersonName { get; set; }
        [ExportAttribute(DisplayName = "检查日期", Order = 19)]
        public string CheckDate { get; set; }
        [ExportAttribute(DisplayName = "备注", Order = 20)]
        public string Remark { get; set; }
        [ExportAttribute(DisplayName = "错误描述", Order = 21)]
        public string Error { get; set; }
    }
}