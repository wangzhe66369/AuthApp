﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Core.Common;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels
{
    public class NuclearFixationErr
    {
        [ExportAttribute(DisplayName = "桶号", Order = 1)]
        public string bucketCode { get; set; }
        [ExportAttribute(DisplayName = "工作票号", Order = 2)]
        public string OrderCode { get; set; }
        [ExportAttribute(DisplayName = "桶的类型", Order = 3)]
        public string BucketTypeName { get; set; }
        [ExportAttribute(DisplayName = "废物跟踪单编号", Order = 4)]
        public string trackCode { get; set; }
        [ExportAttribute(DisplayName = "水泥数量", Order = 5)]
        public string Cement { get; set; }
        [ExportAttribute(DisplayName = "沙子数量", Order = 6)]
        public string Sand { get; set; }
        [ExportAttribute(DisplayName = "骨料数量", Order = 7)]
        public string Meterial { get; set; }
        [ExportAttribute(DisplayName = "补充水数量", Order = 8)]
        public string Water { get; set; }
        [ExportAttribute(DisplayName = "添加剂数量", Order = 9)]
        public string Additive { get; set; }
        [ExportAttribute(DisplayName = "搅拌时间", Order = 10)]
        public string ShakeTime { get; set; }
        [ExportAttribute(DisplayName = "水泥是否有效", Order = 11)]
        public string CementFlag { get; set; }
        [ExportAttribute(DisplayName = "废物来源", Order = 12)]
        public string WasteSourse { get; set; }
        [ExportAttribute(DisplayName = "废物类型", Order = 13)]
        public string WasteTypeName { get; set; }
        [ExportAttribute(DisplayName = "废物装桶位置", Order = 14)]
        public string WastePosition { get; set; }
        [ExportAttribute(DisplayName = "操作振动时间", Order = 15)]
        public string WaterShakeTime { get; set; }
        [ExportAttribute(DisplayName = "操作压缩时间", Order = 16)]
        public string ReduceTime { get; set; }
        [ExportAttribute(DisplayName = "固化体及封盖状态", Order = 17)]
        public string OverStatus { get; set; }
        [ExportAttribute(DisplayName = "桶周围平均剂量率", Order = 18)]
        public string MeteringAve { get; set; }
        [ExportAttribute(DisplayName = "固化体上部剂量率", Order = 19)]
        public string MeteringTop { get; set; }
        [ExportAttribute(DisplayName = "桶周围最大剂量率", Order = 20)]
        public string MeteringMax { get; set; }
        [ExportAttribute(DisplayName = "操作员", Order = 21)]
        public string MaterialControlName { get; set; }
        [ExportAttribute(DisplayName = "操作日期", Order = 22)]
        public string MaterialControlDate { get; set; }
        [ExportAttribute(DisplayName = "检查人", Order = 23)]
        public string MaterialCheckName { get; set; }
        [ExportAttribute(DisplayName = "检查日期", Order = 24)]
        public string MaterialCheckDate { get; set; }
        [ExportAttribute(DisplayName = "备注", Order = 25)]
        public string Remark { get; set; }
        [ExportAttribute(DisplayName = "错误描述", Order = 26)]
        public string Error { get; set; }
    }
}