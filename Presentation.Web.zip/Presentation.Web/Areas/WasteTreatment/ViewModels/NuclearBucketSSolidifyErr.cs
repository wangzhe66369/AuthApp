﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.Core.Common;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels
{
    public class NuclearBucketSSolidifyErr
    {
        [ExportAttribute(DisplayName = "桶号", Order = 1)]
        public string BucketCode { get; set; }
        [ExportAttribute(DisplayName = "工作票号", Order = 2)]
        public string WorkTicket { get; set; }
        [ExportAttribute(DisplayName = "废物类型", Order = 3)]
        public string WasteType { get; set; }
        [ExportAttribute(DisplayName = "废物跟踪单编号", Order = 4)]
        public string TrackCode { get; set; }
         [ExportAttribute(DisplayName = "浓缩液水泥数量", Order = 5)]
        public string CementSQuantity { get; set; }
         [ExportAttribute(DisplayName = "浓缩液沙子数量", Order = 6)]
        public string SandSQuantity { get; set; }
         [ExportAttribute(DisplayName = "浓缩液搅拌时间", Order = 7)]
        public string ShakeSTime { get; set; }
         [ExportAttribute(DisplayName = "淤泥物水泥数量", Order = 8)]
        public string CementWQuantity { get; set; }
         [ExportAttribute(DisplayName = "淤泥物沙子数量", Order = 9)]
        public string SandWQuantity { get; set; }
         [ExportAttribute(DisplayName = "淤泥物搅拌时间", Order = 10)]
        public string ShakeWTime { get; set; }
         [ExportAttribute(DisplayName = "水泥是否有效", Order = 11)]
        public string cementFlag { get; set; }
         [ExportAttribute(DisplayName = "固化浓缩液TES", Order = 12)]
        public string TesBaA { get; set; }
         [ExportAttribute(DisplayName = "固化浓缩液补水量", Order = 13)]
        public string WaterA { get; set; }
         [ExportAttribute(DisplayName = "固化浓缩液总搅拌时间", Order = 14)]
        public string ShakeTimeMA { get; set; }
         [ExportAttribute(DisplayName = "固化桶周围平均剂量率", Order = 15)]
        public string MeteringAveA { get; set; }
         [ExportAttribute(DisplayName = "浓缩液固化体上部剂量率", Order = 16)]
        public string MeteringTopA { get; set; }
         [ExportAttribute(DisplayName = "浓缩液固化周围最大剂量率", Order = 17)]
        public string MeteringMaxA { get; set; }
         [ExportAttribute(DisplayName = "固化淤泥物TES", Order = 18)]
        public string TesBaB { get; set; }
         [ExportAttribute(DisplayName = "固化淤泥物补水量", Order = 19)]
        public string WaterB { get; set; }
         [ExportAttribute(DisplayName = "固化淤泥物补水量总搅拌时间", Order = 20)]
        public string ShakeTimeMB { get; set; }
         [ExportAttribute(DisplayName = "淤泥物固化体周围平均剂量率", Order = 21)]
        public string meteringAveB { get; set; }
         [ExportAttribute(DisplayName = "淤泥物固化体上部剂量率", Order = 22)]
        public string meteringTopB { get; set; }
         [ExportAttribute(DisplayName = "淤泥物固化体周围最大剂量率", Order = 23)]
        public string meteringMaxB { get; set; }
         [ExportAttribute(DisplayName = "搅拌桨", Order = 24)]
        public string shakeFlag { get; set; }
         [ExportAttribute(DisplayName = "操作员", Order = 25)]
        public string controlPersonName { get; set; }
         [ExportAttribute(DisplayName = "操作日期", Order = 26)]
        public string controlDate { get; set; }
         [ExportAttribute(DisplayName = "检查人", Order = 27)]
        public string checkPersonName { get; set; }
         [ExportAttribute(DisplayName = "检查日期", Order = 28)]
        public string checkDate { get; set; }
         [ExportAttribute(DisplayName = "备注", Order = 29)]
         public string remark { get; set; }
         [ExportAttribute(DisplayName = "错误描述", Order = 30)]
         public string Error { get; set; }
    }
}