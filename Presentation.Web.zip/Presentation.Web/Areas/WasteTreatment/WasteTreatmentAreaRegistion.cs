﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.WasteTreatment
{
    public class WasteTreatmentAreaRegistion:AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "WasteTreatment";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "WasteTreatment_default",
                "WasteTreatment/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}