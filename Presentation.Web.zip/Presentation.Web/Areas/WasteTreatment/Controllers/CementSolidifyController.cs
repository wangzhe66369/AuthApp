﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.EquipManage.ViewModels;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using System.Web;
using System.Data;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModelBuilder;
using Newtonsoft.Json;



namespace RWIS.Presentation.Web.Areas.WasteTreatment.Controllers
{
    /// <summary>
    /// 水泥固化
    /// </summary>
    public class CementSolidifyController : Controller
    {
        INuclearBucketSolutionRepository _NuclearBucketSolutionRepository;
        INuclearBucketResinRepository _NuclearBucketResinRepository;
        INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository;
        INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository;
        INuclearBucketSolidifyDetailRepository _NuclearBucketSSolidifyDetailRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INonComformanceRepository _NonComformanceRepository;
        INuclearGiftDetailRepository _NuclearGiftDetailRepository;
        public CementSolidifyController(INuclearBucketSolutionRepository NuclearBucketSolutionRepository
            , INuclearBucketResinRepository NuclearBucketResinRepository
            , INuclearBucketRSolidifyRepository NuclearBucketRSolidifyRepository
            , INuclearBucketSSolidifyRepository NuclearBucketSSolidifyRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository
            , INonComformanceRepository NonComformanceRepository
            , INuclearBucketSolidifyDetailRepository NuclearBucketSSolidifyDetailRepository
            , INuclearBucketSolidifyDetailRepository NuclearBucketSolidifyDetailRepository
            , INuclearGiftDetailRepository NuclearGiftDetailRepository)
        {
            this._NuclearBucketSolutionRepository = NuclearBucketSolutionRepository;
            this._NuclearBucketResinRepository = NuclearBucketResinRepository;
            this._NuclearBucketRSolidifyRepository = NuclearBucketRSolidifyRepository;
            this._NuclearBucketSSolidifyRepository = NuclearBucketSSolidifyRepository;
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NonComformanceRepository = NonComformanceRepository;
            this._NuclearBucketSSolidifyDetailRepository = NuclearBucketSolidifyDetailRepository;
            this._NuclearGiftDetailRepository = NuclearGiftDetailRepository;
        }


        
        /// <summary>
        /// 浓缩液固化
        /// </summary>
        /// <returns></returns>
        public ActionResult ImportSSolidify()
        {
            return View();
        }

        /// <summary>
        /// 导入浓缩液固化
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult ImportSSolidify(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的电缆数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    {
                        //删除文件
                        if (System.IO.File.Exists(strNewImportPath))
                        {
                            System.IO.File.Delete(strNewImportPath);
                        }
                        jsonResult = JsonResultHelper.JsonResult(false, "数据必须是EXCEL格式!");
                        jsonResult.ContentType = "text/html";
                        return jsonResult;
                    }
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);

                         TableBuilder.ImportSSolidify(ds, strNewImportPath);
                        //if (mes == "NoTrack")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "废物跟踪单号不存在！");
                        //}
                        //if (mes == "NoBucketCode")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "桶号不存在！");
                        //}

                    }
                }

                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }



        /// <summary>
        /// 
        /// 废树脂固化
        /// </summary>
        /// <returns></returns>
        public ActionResult ImportSolidify()
        {
            return View();
        }

        /// <summary>
        /// 导入废树脂固化
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult ImportSolidify(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的电缆数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    {
                        //删除文件
                        if (System.IO.File.Exists(strNewImportPath))
                        {
                            System.IO.File.Delete(strNewImportPath);
                        }
                        jsonResult = JsonResultHelper.JsonResult(false, "数据必须是EXCEL格式!");
                        jsonResult.ContentType = "text/html";
                        return jsonResult;
                    }
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);

                          TableBuilder.ImportSolidify(ds, strNewImportPath);
                        //if (mes == "NoBucket")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "您填的桶号不存在！");
                        //}
                        //if (mes == "NoPREPARE")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "您填的桶未经过检查或者不是空桶！");
                        //}
                        //if (mes == "NoSolution")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "您填的桶号已经填充过！");
                        //}
                        //if (mes == "NoTrack")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "您填的废物跟踪单号不存在！");
                        //}
                        //if (mes == "solutionList")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "您填的废物跟踪单已经经过处理！");
                        //}
                        //if (mes == "isJudge")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "导入没有保存成功！");
                        //}

                    }
                }

                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }
        /// <summary>
        /// 
        /// 废树脂装桶固化
        /// </summary>
        /// <returns></returns>
        public ActionResult ImportResin()
        {
            return View();
        }

        /// <summary>
        /// 导入废树脂装桶固化
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult ImportResin(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的废树脂装桶固化文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    {
                        //删除文件
                        if (System.IO.File.Exists(strNewImportPath))
                        {
                            System.IO.File.Delete(strNewImportPath);
                        }
                        jsonResult = JsonResultHelper.JsonResult(false, "数据必须是EXCEL格式!");
                        jsonResult.ContentType = "text/html";
                        return jsonResult;
                    }
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);

                        TableBuilder.ImportResin(ds, strNewImportPath);
                        //if (mes == "NoBucket")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "您填的桶号不存在！");
                        //}
                        //if (mes == "NoPREPARE")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "您填的桶未经过检查或者不是空桶！");
                        //}
                        //if (mes == "NoSolution")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "您填的桶号已经填充过！");
                        //}
                        //if (mes == "NoTrack")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "您填的废物跟踪单号不存在！");
                        //}
                        //if (mes == "solutionList")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "您填的废物跟踪单已经经过处理！");
                        //}
                        //if (mes == "isJudge")
                        //{
                        //    return JsonResultHelper.JsonResult(true, "导入没有保存成功！");
                        //}

                    }
                }

                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }

        /// <summary>
        /// 浓缩液装桶固化
        /// </summary>
        /// <returns></returns>
        public ActionResult Import()
        {
            return View();
        }

        /// <summary>
        /// 导入浓缩液装桶固化
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult Import(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的电缆数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    {
                        //删除文件
                        if (System.IO.File.Exists(strNewImportPath))
                        {
                            System.IO.File.Delete(strNewImportPath);
                        }
                        jsonResult = JsonResultHelper.JsonResult(false, "数据必须是EXCEL格式!");
                        jsonResult.ContentType = "text/html";
                        return jsonResult;
                    }
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);
                       TableBuilder.ImportSolution(ds, strNewImportPath);
                       //if (mes == "NoBucket")
                       //{
                       //    return JsonResultHelper.JsonResult(true, "您填的桶号不存在！");
                       //}
                       //if (mes == "NoPREPARE")
                       //{
                       //    return JsonResultHelper.JsonResult(true, "您填的桶未经过检查或者不是空桶！");
                       //}
                       //if (mes == "NoSolution")
                       //{
                       //    return JsonResultHelper.JsonResult(true, "您填的桶号已经填充过！");
                       //}
                       //if (mes == "NoTrack")
                       //{
                       //    return JsonResultHelper.JsonResult(true, "您填的废物跟踪单号不存在！");
                       //}
                       //if (mes == "solutionList")
                       //{
                       //    return JsonResultHelper.JsonResult(true, "您填的废物跟踪单已经经过处理！");
                       //}
                       //if (mes == "isJudge")
                       //{
                       //    return JsonResultHelper.JsonResult(true, "导入没有保存成功！");
                       //}

                    }
                }

                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }
       

        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "水泥固化")]
        public ActionResult Index()
        {
            CementSolidifyVM vm = new CementSolidifyVM();
            vm.OperationList = CommonHelper.GetOperationList("Cement_Solidify");
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(CementSolidifyVM cementSolidifyVm, string sord, int page, int rows, string sidx)
        {
            CementSolidifyCondition cementSolidifyCondition = cementSolidifyVm.Condition;
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var querySolution = _NuclearBucketSolutionRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            var queryResin = _NuclearBucketResinRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            var queryRSolidify = _NuclearBucketRSolidifyRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            var querySSolidify = _NuclearBucketSSolidifyRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (cementSolidifyCondition!=null &&!string.IsNullOrEmpty(cementSolidifyCondition.BucketCode))
            {
                var listBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.BucketCode.ToUpper().Contains(cementSolidifyCondition.BucketCode.ToUpper())).ToList();
                List<string> listId = new List<string>();
                for (int i = 0; i < listBucket.Count; i++)
                {
                    listId.Add(listBucket[i].BucketId);
                }
                querySolution = querySolution.Where(n => listId.Contains(n.BucketId)).ToList();
                queryResin = queryResin.Where(n => listId.Contains(n.BucketId)).ToList();
                queryRSolidify = queryRSolidify.Where(n => listId.Contains(n.BucketId)).ToList();
                querySSolidify = querySSolidify.Where(n => listId.Contains(n.BucketId)).ToList();
            }
            if (cementSolidifyCondition!=null && !string.IsNullOrEmpty(cementSolidifyCondition.WorkTicket))
            {
                querySolution = querySolution.Where(n => n.WorkTicket.ToUpper().Contains(cementSolidifyCondition.WorkTicket.ToUpper())).ToList();
                queryResin = queryResin.Where(n => n.WorkTicket.ToUpper().Contains(cementSolidifyCondition.WorkTicket.ToUpper())).ToList();
                queryRSolidify = queryRSolidify.Where(n => n.WorkTicket.ToUpper().Contains(cementSolidifyCondition.WorkTicket.ToUpper())).ToList();
                querySSolidify = querySSolidify.Where(n => n.WorkTicket.ToUpper().Contains(cementSolidifyCondition.WorkTicket.ToUpper())).ToList();
            }
            if (cementSolidifyCondition != null && !string.IsNullOrEmpty(cementSolidifyCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(cementSolidifyCondition.StartDate);
                querySolution = querySolution.Where(n => n.CheckDate >= sDate).ToList();
                queryResin = queryResin.Where(n => n.CheckDate >= sDate).ToList();
                queryRSolidify = queryRSolidify.Where(n => n.CheckDate >= sDate).ToList();
                querySSolidify = querySSolidify.Where(n => n.CheckDate >= sDate).ToList();
            }
            if (cementSolidifyCondition != null && !string.IsNullOrEmpty(cementSolidifyCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(cementSolidifyCondition.EndDate);
                querySolution = querySolution.Where(n => n.CheckDate <= eDate).ToList();
                queryResin = queryResin.Where(n => n.CheckDate <= eDate).ToList();
                queryRSolidify = queryRSolidify.Where(n => n.CheckDate <= eDate).ToList();
                querySSolidify = querySSolidify.Where(n => n.CheckDate <= eDate).ToList();
            }
            List<CementSolidifyList> listData = new List<CementSolidifyList>();
            foreach (NuclearBucketSolution solution in querySolution)
            {
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(solution.BucketId);
                if (bucketModel == null) continue;
                CementSolidifyList solidify = new CementSolidifyList();
                solidify.SolidifyId = solution.SolutionId;
                solidify.ControlType = "1";
                solidify.BucketCode = bucketModel.BucketCode;
                solidify.WorkTicket = solution.WorkTicket;
                solidify.WasteType = "浓缩液";
                solidify.CreateDate = solution.CreateDate;
                solidify.MeteringAve = solution.MeteringAve;
                solidify.MeteringTop = solution.MeteringTop;
                solidify.MeteringMax = solution.MeteringMax;
                if (!string.IsNullOrEmpty(solution.TrackId))
                {
                    var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(n => n.TrackId == solution.TrackId).ToList();
                    if (listTrack.Count > 0)
                    {
                        solidify.TrackCode = listTrack[0].TrackCode;
                    }
                }

                solidify.SolidifyType = "浓缩液装桶固化400l金属桶";
                solidify.CheckPersonName = solution.ControlPersonName;
                solidify.Status = solution.Status;
                solidify.Comformance = _NonComformanceRepository.GetListByBucketCode(solidify.BucketCode).ToList().Count > 0 ? "有" : "无";
                listData.Add(solidify);
            }
            foreach (NuclearBucketResin resin in queryResin)
            {
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(resin.BucketId);
                if (bucketModel == null) continue;
                CementSolidifyList solidify = new CementSolidifyList();
                solidify.SolidifyId = resin.ResinId;
                solidify.ControlType = "2";
                solidify.BucketCode = bucketModel.BucketCode;
                solidify.WorkTicket = resin.WorkTicket;
                solidify.WasteType = "废树脂";
                solidify.CreateDate = resin.CreateDate;
                solidify.MeteringAve = resin.MeteringAve;
                solidify.MeteringTop = resin.MeteringTop;
                solidify.MeteringMax = resin.MeteringMax;
                if (!string.IsNullOrEmpty(resin.TrackId))
                {
                    var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(n => n.TrackId == resin.TrackId).ToList();
                    if (listTrack.Count > 0)
                    {
                        solidify.TrackCode = listTrack[0].TrackCode;
                    }
                }
                solidify.SolidifyType = "废树脂装桶固化400l金属桶";
                solidify.CheckPersonName = resin.ControlPersonName;
                solidify.Status = resin.Status;
                solidify.Comformance = _NonComformanceRepository.GetListByBucketCode(solidify.BucketCode).ToList().Count > 0 ? "有" : "无";
                listData.Add(solidify);
            }
            foreach (NuclearBucketRSolidify Rsolidify in queryRSolidify)
            {
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(Rsolidify.BucketId);
                if (bucketModel == null) continue;
                CementSolidifyList solidify = new CementSolidifyList();
                solidify.SolidifyId = Rsolidify.SolidifyRId;
                solidify.ControlType = "3";
                solidify.BucketCode = bucketModel.BucketCode;
                solidify.WorkTicket = Rsolidify.WorkTicket;
                solidify.WasteType = "干湿料制备及废树脂";
                solidify.CreateDate = Rsolidify.CreateDate;
                solidify.MeteringAve = Rsolidify.MeteringAve;
                solidify.MeteringTop = Rsolidify.MeteringTop;
                solidify.MeteringMax = Rsolidify.MeteringMax;
                if (!string.IsNullOrEmpty(Rsolidify.TrackId))
                {
                    var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(n => n.TrackId == Rsolidify.TrackId).ToList();
                    if (listTrack.Count > 0)
                    {
                        solidify.TrackCode = listTrack[0].TrackCode;
                    }
                }
                solidify.SolidifyType = "干湿料制备及废树脂装桶固化";
                solidify.CheckPersonName = Rsolidify.ControlPersonName;
                solidify.Status = Rsolidify.Status;
                solidify.Comformance = _NonComformanceRepository.GetListByBucketCode(solidify.BucketCode).ToList().Count > 0 ? "有" : "无";
                listData.Add(solidify);
            }
            foreach (NuclearBucketSSolidify Ssolidify in querySSolidify)
            {
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(Ssolidify.BucketId);
                if (bucketModel == null) continue;
                CementSolidifyList solidify = new CementSolidifyList();
                solidify.SolidifyId = Ssolidify.SolidifySIdd;
                solidify.ControlType = "4";
                solidify.BucketCode = bucketModel.BucketCode;
                solidify.WorkTicket = Ssolidify.WorkTicket;
                solidify.WasteType = "干湿料制备及浓缩液";
                solidify.CreateDate = Ssolidify.CreateDate;
                solidify.MeteringAve = Ssolidify.MeteringAveA;
                solidify.MeteringTop = Ssolidify.MeteringTopA;
                solidify.MeteringMax = Ssolidify.MeteringMaxA;
                if (!string.IsNullOrEmpty(Ssolidify.TrackId))
                {
                    var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(n => n.TrackId == Ssolidify.TrackId).ToList();
                    if (listTrack.Count > 0)
                    {
                        solidify.TrackCode = listTrack[0].TrackCode;
                    }
                }
                solidify.SolidifyType = "干湿料制备及浓缩液装桶固化";
                solidify.CheckPersonName = Ssolidify.ControlPersonName;
                solidify.Status = Ssolidify.Status;
                solidify.Comformance = _NonComformanceRepository.GetListByBucketCode(solidify.BucketCode).ToList().Count > 0 ? "有" : "无";
                listData.Add(solidify);
            }
            listData = listData.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<CementSolidifyList> data = listData.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<CementSolidifyList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.SolidifyId,
                    List = new List<object>() {
                    d.SolidifyId,
                    d.ControlType,
                    d.BucketCode,
                    d.WorkTicket,
                    d.WasteType,
                    d.TrackCode,
                    d.MeteringAve,
                    d.MeteringTop,
                    d.MeteringMax,
                    d.SolidifyType,             
                    d.CheckPersonName,
                    d.Status,
                    d.Comformance
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "水泥固化删除")]
        public ActionResult DeleteSolidify()
        {
            try
            {
                string id = Request["id"];
                string type = Request["type"];
                bool flag = false;
                string trackId = string.Empty;
                string trackType = string.Empty;
                if (type == "1")
                {
                    NuclearBucketSolution model = _NuclearBucketSolutionRepository.Get(id);
                    if (model != null)
                    {
                        trackId = model.TrackId;
                        trackType = model.TrackType;
                        NuclearBucket bucket = _NuclearBucketRepository.Get(model.BucketId);
                        if (bucket.BucketStatus == "FILL")
                        {
                            _NuclearBucketRepository.UpdateBucketWasteType(bucket.BucketCode, AppContext.CurrentUser.ProjectCode, "","","PREPARE");
                        }
                        else
                        {
                            return Json("{\"result\":false,\"msg\":\"该环节所使用的废物桶已经到了其他工序阶段,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }

                    flag = _NuclearBucketSolutionRepository.DeleteBucketSolution(id);
                    TrackItemBuilder.UpdateTrackDealStatus(trackType, trackId,"0");
                    _NuclearBucketSolutionRepository.UnitOfWork.Commit();
                }
                if (type == "2")
                {
                    NuclearBucketResin model = _NuclearBucketResinRepository.Get(id);
                    if (model != null)
                    {
                        NuclearBucket bucket = _NuclearBucketRepository.Get(model.BucketId);
                        if (bucket.BucketStatus == "FILL")
                        {
                            _NuclearBucketRepository.UpdateBucketWasteType(bucket.BucketCode, AppContext.CurrentUser.ProjectCode, "", "", "PREPARE");
                        }
                        else
                        {
                            return Json("{\"result\":false,\"msg\":\"该环节所使用的废物桶已经到了其他工序阶段,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }

                    //删除数据
                    flag = _NuclearBucketResinRepository.DeleteBucketResin(id);
                    
                    //更新废物跟踪单状态
                    string giftId=model.ResinId;
                    IQueryable<NuclearGiftDetail> query = _NuclearGiftDetailRepository.GetAll().AsQueryable().Where(c => c.GiftId == giftId);
                    foreach (var item in query)
                    {
                        TrackItemBuilder.UpdateTrackDealStatus(item.TrackType, item.TrackId, "0");
                    }

                    //提交数据
                    _NuclearBucketResinRepository.UnitOfWork.Commit();
                }
                if (type == "3")
                {
                    NuclearBucketRSolidify model = _NuclearBucketRSolidifyRepository.Get(id);
                    if (model != null)
                    {
                        trackId = model.TrackId;
                        trackType = model.TrackType;
                        NuclearBucket bucket = _NuclearBucketRepository.Get(model.BucketId);
                        if (bucket.BucketStatus == "FILL")
                        {
                            _NuclearBucketRepository.UpdateBucketWasteType(bucket.BucketCode, AppContext.CurrentUser.ProjectCode, "", "", "PREPARE");
                        }
                        else
                        {
                            return Json("{\"result\":false,\"msg\":\"该环节所使用的废物桶已经到了其他工序阶段,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }

                    //删除数据
                    flag = _NuclearBucketRSolidifyRepository.DeleteBucketRSolidify(id);

                    //更新废物跟踪单状态
                    string giftId = model.SolidifyRId;
                    IQueryable<NuclearGiftDetail> query = _NuclearGiftDetailRepository.GetAll().AsQueryable().Where(c => c.GiftId == giftId);
                    foreach (var item in query)
                    {
                        TrackItemBuilder.UpdateTrackDealStatus(item.TrackType, item.TrackId, "0");
                    }
                    
                    //提交
                    _NuclearBucketRSolidifyRepository.UnitOfWork.Commit();
                }
                if (type == "4")
                {
                    NuclearBucketSSolidify model = _NuclearBucketSSolidifyRepository.Get(id);
                    if (model != null)
                    {
                        trackId = model.TrackId;
                        trackType = model.TrackType;
                        NuclearBucket bucket = _NuclearBucketRepository.Get(model.BucketId);
                        if (bucket.BucketStatus == "FILL")
                        {
                            _NuclearBucketRepository.UpdateBucketWasteType(bucket.BucketCode, AppContext.CurrentUser.ProjectCode, "", "", "PREPARE");
                        }
                        else
                        {
                            return Json("{\"result\":false,\"msg\":\"该环节所使用的废物桶已经到了其他工序阶段,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }

                    flag = _NuclearBucketSSolidifyRepository.DeleteBucketSSolidify(id);
                    TrackItemBuilder.UpdateTrackDealStatus(trackType, trackId, "0");
                    _NuclearBucketSSolidifyRepository.UnitOfWork.Commit();
                }
                if (flag)
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }


        #region"浓缩液装桶固化400l金属桶"

        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "浓缩液装桶固化400l金属桶")]
        public ActionResult BucketSolutionDetail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            string bucketCode = string.Empty;
            string trackCode = string.Empty;
            CementSolidifyVM vm = new CementSolidifyVM();
            vm.OperationList = CommonHelper.GetOperationList("Bucket_Solution_Detail");
            vm.BucketSolutionModel = new NuclearBucketSolution();
            vm.BucketTypeList = new List<SelectListItem>();
            vm.BucketStatusList = new List<SelectListItem>();
            vm.SolidifyDetailList = new List<CementSolidifyDetailList>();
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            List<BasicObject> listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryBucketSolidify = _BasicObjectRepository.GetSubobjectsByCode("BucketSolidify", AppContext.CurrentUser.ProjectCode);
            if (queryBucketSolidify != null && queryBucketSolidify.Count() > 0)
            {
                listBasicObject = queryBucketSolidify.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            NuclearBucketSolution model = new NuclearBucketSolution();
            //如果是点击修改进入此页面
            if (!string.IsNullOrEmpty(uid))
            {
                model = _NuclearBucketSolutionRepository.GetBucketSolutionModel(uid);
                vm.BucketSolutionModel = model;
                var detailList = _NuclearBucketSolutionRepository.GetDetailBySolidifyId(uid, "1").ToList();
                List<CementSolidifyDetailList> cementList = new List<CementSolidifyDetailList>();
                if (detailList != null && detailList.Count > 0)
                {
                    foreach (NuclearSolidifyDetail detail in detailList)
                    {
                        CementSolidifyDetailList cement = new CementSolidifyDetailList();
                        cement.DetailId = detail.DetailId;
                        cement.SolidifyId = detail.SolidifyId;
                        cement.SolidifyType = detail.SolidifyType;
                        cement.BucketCode = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId).BucketCode;
                        cementList.Add(cement);
                    }
                }
                vm.SolidifyDetailList = cementList;
                detailFlag = "edit";
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(model.BucketId);
                if (bucketModel != null)
                    bucketCode = bucketModel.BucketCode;
                var trackModel = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == model.TrackId).ToList();
                if (trackModel != null && trackModel.Count > 0)
                    trackCode = trackModel[0].TrackCode;
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.BucketCode = bucketCode;
            ViewBag.TrackCode = trackCode;
            ViewBag.ViewType = Request["type"];
            ViewBag.ViewStatus = Request["status"];
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);
        }

        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "浓缩液装桶固化400l金属桶添加")]
        public ActionResult AddBucketSolution(CementSolidifyVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号未经过检查或者已经经过填充。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucketSolution = _NuclearBucketSolutionRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listBucketSolution != null)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号已经填充过。\"}", JsonRequestBehavior.AllowGet);
                }
                string trackCode = Request.Form["txtTrackCode"];
                var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (trackList.Count == 0)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                string tId = trackList[0].TrackId;
                var solutionList = _NuclearBucketSolutionRepository.GetQueryList().Where(n => n.TrackId == tId).ToList();
                //if (solutionList.Count > 0)
                //{
                //    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单已经经过处理。\"}", JsonRequestBehavior.AllowGet);
                //}
                string allCode = Request.Form["hidAddBucketCode"];
                string[] arrayCode = null;
                string[] arrayBucketId = null;
                string wCode = string.Empty;
                string sCode = string.Empty;
                string strBucketId = string.Empty;
                if (!string.IsNullOrEmpty(allCode))
                {
                    arrayCode = allCode.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                if (arrayCode != null)
                {
                    foreach (string code in arrayCode)
                    {
                        bool wFlag = _NuclearBucketRepository.IsDrain(code, AppContext.CurrentUser.ProjectCode);
                        if (!wFlag)
                        {
                            wCode += code + ",";
                        }
                        var bucketList = _NuclearBucketRepository.QueryListByCode(code, AppContext.CurrentUser.ProjectCode).ToList();
                        if (bucketList != null && bucketList.Count > 0)
                        {
                            strBucketId += bucketList[0].BucketId + ",";
                            var sList = _NuclearBucketSolutionRepository.GetDetailByBucketId(bucketList[0].BucketId, "1").ToList();
                            if (sList != null && sList.Count > 0)
                            {
                                sCode += code + ",";
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(wCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号:" + wCode.Trim(new char[] { ',' }) + "不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(sCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号:" + sCode.Trim(new char[] { ',' }) + "已经存在。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(strBucketId))
                {
                    arrayBucketId = strBucketId.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                NuclearBucketSolution solution = new NuclearBucketSolution();
                solution = model.BucketSolutionModel;
                solution.SolutionId = Guid.NewGuid().ToString();
                solution.TrackId = trackList[0].TrackId;
                solution.BucketId = listBucket[0].BucketId;
                solution.CreateUserNo = AppContext.CurrentUser.UserId;
                solution.CreateUserName = AppContext.CurrentUser.UserName;
                solution.CreateDate = DateTime.Now;
                solution.Status = Request.Form["submitType"];
                solution.Stationcode = AppContext.CurrentUser.ProjectCode;
                List<NuclearSolidifyDetail> detailList = new List<NuclearSolidifyDetail>();
                if (arrayCode != null)
                {
                    for (int i = 0; i < arrayCode.Length; i++)
                    {
                        NuclearSolidifyDetail detail = new NuclearSolidifyDetail();
                        detail.DetailId = Guid.NewGuid().ToString();
                        detail.SolidifyId = solution.SolutionId;
                        detail.SolidifyType = "1";
                        detail.BucketId = arrayBucketId[i];
                        detailList.Add(detail);
                    }
                }
                if (solution.Status == "2")
                {
                    solution.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    solution.ConfirmUserName = AppContext.CurrentUser.UserName;
                    solution.ConfirmDate = DateTime.Now;
                    if (trackList.Count > 0)
                    {
                        var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(solution.BucketId);
                        modelBucket.StationId = trackList[0].StationId;
                        _NuclearBucketRepository.Update(modelBucket);
                        string trackType = TrackItemBuilder.GetNameByCode(trackList[0].TrackType);
                        _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, trackType, "浓缩液装桶固化", "FILL");
                        TrackItemBuilder.UpdateTrackDealStatus(trackList[0].TrackType, trackList[0].TrackId, "1");
                        if (trackList[0].TrackType == "ELEMENT" || trackList[0].TrackType == "TECH2" || trackList[0].TrackType == "SUNDRY")
                        {
                            TrackItemBuilder.UpdateTrackDealStatus(trackList[0].TrackType, trackList[0].TrackId, "1");
                        }
                    }
                }
                if (_NuclearBucketSolutionRepository.AddBucketSolution(solution, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "浓缩液装桶固化400l金属桶修改及确认")]
        public ActionResult UpdateBucketSolution(CementSolidifyVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                string hideCode = Request.Form["hidBucketCode"];
                if (bucketCode != hideCode)
                {
                    bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                    if (listBucket[0].BucketStatus != "PREPARE")
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号未经过检查或者已经经过填充。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucketSolution = _NuclearBucketSolutionRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listBucketSolution != null)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号已经填充过。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.BucketSolutionModel.BucketId = listBucket[0].BucketId;
                }
                string trackCode = Request.Form["txtTrackCode"];
                string hideTrack = Request.Form["hidTrackCode"];
                var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (trackCode != hideTrack)
                {
                    if (trackList.Count == 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    string tId = trackList[0].TrackId;
                    var solutionList = _NuclearBucketSolutionRepository.GetQueryList().Where(n => n.TrackId == tId).ToList();
                    //if (solutionList.Count > 0)
                    //{
                    //    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号已经存在。\"}", JsonRequestBehavior.AllowGet);
                    //}
                }
                model.BucketSolutionModel.TrackId = trackList[0].TrackId;
                model.BucketSolutionModel.TrackType = trackList[0].TrackType;
                string allCode = Request.Form["hidAddBucketCode"];
                string[] arrayCode = null;
                string[] arrayBucketId = null;
                string wCode = string.Empty;
                string sCode = string.Empty;
                string strBucketId = string.Empty;
                if (!string.IsNullOrEmpty(allCode))
                {
                    arrayCode = allCode.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                if (arrayCode != null)
                {
                    foreach (string code in arrayCode)
                    {
                        bool wFlag = _NuclearBucketRepository.IsDrain(code, AppContext.CurrentUser.ProjectCode);
                        if (!wFlag)
                        {
                            wCode += code + ",";
                        }
                        var bucketList = _NuclearBucketRepository.QueryListByCode(code, AppContext.CurrentUser.ProjectCode).ToList();
                        if (bucketList != null && bucketList.Count > 0)
                        {
                            strBucketId += bucketList[0].BucketId + ",";
                            var sList = _NuclearBucketSolutionRepository.GetDetailByBucketId(bucketList[0].BucketId, "1").Where(n => n.SolidifyId != model.BucketSolutionModel.SolutionId).ToList();
                            if (sList != null && sList.Count > 0)
                            {
                                sCode += code + ",";
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(wCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号:" + wCode.Trim(new char[] { ',' }) + "不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(sCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号:" + sCode.Trim(new char[] { ',' }) + "已经存在。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(strBucketId))
                {
                    arrayBucketId = strBucketId.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                List<NuclearSolidifyDetail> detailList = new List<NuclearSolidifyDetail>();
                if (arrayCode != null)
                {
                    for (int i = 0; i < arrayCode.Length; i++)
                    {
                        NuclearSolidifyDetail detail = new NuclearSolidifyDetail();
                        detail.DetailId = Guid.NewGuid().ToString();
                        detail.SolidifyId = model.BucketSolutionModel.SolutionId;
                        detail.SolidifyType = "1";
                        detail.BucketId = arrayBucketId[i];
                        detailList.Add(detail);
                    }
                }
                string confirmFlag = model.BucketSolutionModel.Status;
                model.BucketSolutionModel.Status = Request.Form["submitType"];
                if (model.BucketSolutionModel.Status == "2")
                {
                    model.BucketSolutionModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.BucketSolutionModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.BucketSolutionModel.ConfirmDate = DateTime.Now;
    
                    if (confirmFlag != "2")
                    {
                        if (trackList.Count > 0)
                        {
                            var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(model.BucketSolutionModel.BucketId);
                            modelBucket.StationId = trackList[0].StationId;
                            _NuclearBucketRepository.Update(modelBucket);

                            string trackType = TrackItemBuilder.GetNameByCode(trackList[0].TrackType);
                            _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, trackType, "浓缩液装桶固化", "FILL");
                            if (trackList[0].TrackType == "ELEMENT" || trackList[0].TrackType == "TECH2" || trackList[0].TrackType == "SUNDRY")
                            {
                                TrackItemBuilder.UpdateTrackDealStatus(trackList[0].TrackType, trackList[0].TrackId, "1");
                            }
                       
                        }
                    }
                }
                if (_NuclearBucketSolutionRepository.UpdateBucketSolution(model.BucketSolutionModel, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        public ActionResult DeleteBucketSolution()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearBucketSolutionRepository.DeleteBucketSolution(id))
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #endregion

        #region"废树脂装桶固化400l金属桶"

        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "废树脂装桶固化400l金属桶")]
        public ActionResult BucketResinDetail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            string bucketCode = string.Empty;
            string trackCode = string.Empty;
            CementSolidifyVM vm = new CementSolidifyVM();
            vm.OperationList = CommonHelper.GetOperationList("Bucket_Resin_Detail");
            vm.BucketResinModel = new NuclearBucketResin();
            vm.BucketTypeList = new List<SelectListItem>();
            vm.BucketStatusList = new List<SelectListItem>();
            vm.SolidifyDetailList = new List<CementSolidifyDetailList>();
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            List<BasicObject> listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryBucketSolidify = _BasicObjectRepository.GetSubobjectsByCode("BucketSolidify", AppContext.CurrentUser.ProjectCode);
            if (queryBucketSolidify != null && queryBucketSolidify.Count() > 0)
            {
                listBasicObject = queryBucketSolidify.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            NuclearBucketResin model = new NuclearBucketResin();
            //如果是点击修改进入此页面
            if (!string.IsNullOrEmpty(uid))
            {
     
                model = _NuclearBucketResinRepository.GetBucketResinModel(uid);
                vm.BucketResinModel = model;
                var detailList = _NuclearBucketSolutionRepository.GetDetailBySolidifyId(uid, "2").ToList();
                List<CementSolidifyDetailList> cementList = new List<CementSolidifyDetailList>();
                if (detailList != null && detailList.Count > 0)
                {
                    foreach (NuclearSolidifyDetail detail in detailList)
                    {
                        CementSolidifyDetailList cement = new CementSolidifyDetailList();
                        cement.DetailId = detail.DetailId;
                        cement.SolidifyId = detail.SolidifyId;
                        cement.SolidifyType = detail.SolidifyType;
                        cement.BucketCode = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId).BucketCode;
                        cementList.Add(cement);
                    }
                }
                vm.SolidifyDetailList = cementList;
                detailFlag = "edit";
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(model.BucketId);
                if (bucketModel != null)
                    bucketCode = bucketModel.BucketCode;
                var trackModel = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == model.TrackId).ToList();
                if (trackModel != null && trackModel.Count > 0)
                    trackCode = trackModel[0].TrackCode;

                //废物跟踪单列表
                List<NuclearGiftDetail> giftDetailList = _NuclearGiftDetailRepository.GetAll().AsQueryable().Where(c => c.GiftId == uid).ToList();
                if (giftDetailList != null && giftDetailList.Count > 0)
                {
                    vm.GiftDetailList = new List<GiftDetailList>();
                    for (int i = 0; i < giftDetailList.Count; i++)
                    {
                        string tId = giftDetailList[i].TrackId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        GiftDetailList detail = new GiftDetailList();
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.GiftDetailList.Add(detail);
                    }
                }
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.BucketCode = bucketCode;
            ViewBag.TrackCode = trackCode;
            ViewBag.ViewType = Request["type"];
            ViewBag.ViewStatus = Request["status"];
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);
        }

        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废树脂装桶固化400l金属桶添加")]
        public ActionResult AddBucketResin(CementSolidifyVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号未经过检查或者已经经过填充。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucketResin = _NuclearBucketResinRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listBucketResin != null)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号已经填充过。\"}", JsonRequestBehavior.AllowGet);
                }
                string trackCode = Request.Form["txtTrackCode"];
                var trackList = TrackItemBuilder.GetTrackList(AppContext.CurrentUser.ProjectCode).Where(c => (c.DealStatus == "0" || c.DealStatus == null) && c.TrackType.ToUpper() == "RESIN").AsQueryable().ToList();
               
                NuclearBucketResin resin = new NuclearBucketResin();
                resin = model.BucketResinModel;
                resin.ResinId = Guid.NewGuid().ToString();
                resin.BucketId = listBucket[0].BucketId;
                //resin.TrackId = trackList[0].TrackId;
                resin.CreateUserNo = AppContext.CurrentUser.UserId;
                resin.CreateUserName = AppContext.CurrentUser.UserName;
                resin.CreateDate = DateTime.Now;
                resin.Status = Request.Form["submitType"];
                resin.Stationcode = AppContext.CurrentUser.ProjectCode;
       

                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //判断废物跟踪单是否存在
                if (trackArray != null && trackArray.Length > 0 && trackList!=null)
                {
                    for (int i = 0; i < trackArray.Length; i++)
                    {
                        string trackId = trackArray[i];
                        var list = trackList.Where(c => c.TrackId == trackId).ToList();
                        if (list == null || list.Count == 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在或者已经处理过\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                }

                //更新
                if (resin.Status == "2")
                {
                    //更新废物跟踪单
                    string trackStation = string.Empty;
                    if (trackArray != null && trackArray.Length > 0)
                    {
                        for (int i = 0; i < trackArray.Length; i++)
                        {
                            string trackId = trackArray[i];
                            if (!string.IsNullOrEmpty(trackId))
                            {
                                var trackModel = trackList.Where(n => n.TrackId == trackId).ToList();
                                if (trackModel.Count > 0)
                                {
                                    trackStation = trackModel[0].StationId;
                                    string trackType = trackModel[0].TrackType;
                                    //if (trackType == "ELEMENT" || trackType == "TECH2" || trackType == "SUNDRY")
                                    //{
                                    //    TrackItemBuilder.UpdateTrackDealStatus(trackModel[0].TrackType, trackModel[0].TrackId, "1");
                                    //}
                                }
                            }
                        }
                    }

                    //修改主单信息
                    resin.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    resin.ConfirmUserName = AppContext.CurrentUser.UserName;
                    resin.ConfirmDate = DateTime.Now;
                    if (trackList.Count > 0)
                    {
                        var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(resin.BucketId);
                        modelBucket.StationId = trackStation;
                        _NuclearBucketRepository.Update(modelBucket);
                        string trackType = TrackItemBuilder.GetNameByCode(trackList[0].TrackType);
                        _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, "废树脂", "废树脂固化", "FILL");
                    }
                }

                //提交
                if (_NuclearBucketResinRepository.AddBucketResin(resin, trackArray))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "废树脂装桶固化400l金属桶修改及确认")]
        public ActionResult UpdateBucketResin(CementSolidifyVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                string hideCode = Request.Form["hidBucketCode"];
                if (bucketCode != hideCode)
                {
                    bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                    if (listBucket[0].BucketStatus != "PREPARE")
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号未经过检查或者已经经过填充。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucketResin = _NuclearBucketResinRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listBucketResin != null)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号已经填充过。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.BucketResinModel.BucketId = listBucket[0].BucketId;
                }
                string trackCode = Request.Form["txtTrackCode"];
                string hideTrack = Request.Form["hidTrackCode"];
                var trackList = TrackItemBuilder.GetTrackList(AppContext.CurrentUser.ProjectCode).Where(c=>c.TrackType.ToUpper()=="RESIN" ).ToList();

                model.BucketResinModel.Status = Request.Form["submitType"];
                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });

                //判断废物跟踪单是否存在
                if (trackArray != null && trackArray.Length > 0 && trackList!=null)
                {
                    for (int i = 0; i < trackArray.Length; i++)
                    {
                        string trackId = trackArray[i];
                        var list = trackList.Where(c => c.TrackId == trackId).ToList();
                        if (list == null || list.Count == 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在或者已经处理过\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                }

                //更新
                if (model.BucketResinModel.Status == "2")
                {
                    //更新废物跟踪单
                    string giftId = model.BucketResinModel.ResinId;
                    IQueryable<NuclearGiftDetail> iqueryGiftDetail = _NuclearGiftDetailRepository.GetAll().AsQueryable().Where(c => c.GiftId == giftId);
                    if (iqueryGiftDetail != null && iqueryGiftDetail.Count() > 0)
                    {
                        foreach (var item in iqueryGiftDetail)
                        {
                           // TrackItemBuilder.UpdateTrackDealStatus(item.TrackType, item.TrackId, "0");
                        }
                    }
                    string trackStation = string.Empty;
                    if (trackArray != null && trackArray.Length > 0)
                    {
                        for (int i = 0; i < trackArray.Length; i++)
                        {
                            string trackId = trackArray[i];
                            if (!string.IsNullOrEmpty(trackId))
                            {
                                var trackModel = trackList.Where(n => n.TrackId == trackId).ToList();
                                if (trackModel.Count > 0)
                                {
                                    trackStation = trackModel[0].StationId;
                                    string trackType = trackModel[0].TrackType;
                                    if (trackType == "ELEMENT" || trackType == "TECH2" || trackType == "SUNDRY")
                                    {
                                        TrackItemBuilder.UpdateTrackDealStatus(trackModel[0].TrackType, trackModel[0].TrackId, "1");
                                    }
                                }
                            }
                        }
                    }

                    //修改主单信息
                    model.BucketResinModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.BucketResinModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.BucketResinModel.ConfirmDate = DateTime.Now;

                    //修改桶信息
                    var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(model.BucketResinModel.BucketId);
                    modelBucket.StationId = trackStation;
                    _NuclearBucketRepository.Update(modelBucket);
                    _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, "废树脂", "废树脂固化", "FILL");
                }

                //提交
                if (_NuclearBucketResinRepository.UpdateBucketResin(model.BucketResinModel, trackArray))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        public ActionResult DeleteBucketResin()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearBucketResinRepository.DeleteBucketResin(id))
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #endregion

        #region"干湿料制备及废树脂装桶固化"

        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "干湿料制备及废树脂装桶固化")]
        public ActionResult BucketRSolidifyDetail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            string bucketCode = string.Empty;
            string trackCode = string.Empty;
            CementSolidifyVM vm = new CementSolidifyVM();
            vm.OperationList = CommonHelper.GetOperationList("Bucket_R_Solidify_Detail");
            vm.BucketRSolidifyModel = new NuclearBucketRSolidify();
            vm.BucketStatusList = new List<SelectListItem>();
            vm.SolidifyDetailList = new List<CementSolidifyDetailList>();
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            NuclearBucketRSolidify model = new NuclearBucketRSolidify();
            //如果是点击修改进入此页面
            if (!string.IsNullOrEmpty(uid))
            {
                model = _NuclearBucketRSolidifyRepository.GetBucketRSolidifyModel(uid);
                vm.BucketRSolidifyModel = model;
                var detailList = _NuclearBucketSolutionRepository.GetDetailBySolidifyId(uid, "3").ToList();
                List<CementSolidifyDetailList> cementList = new List<CementSolidifyDetailList>();
                if (detailList != null && detailList.Count > 0)
                {
                    foreach (NuclearSolidifyDetail detail in detailList)
                    {
                        CementSolidifyDetailList cement = new CementSolidifyDetailList();
                        cement.DetailId = detail.DetailId;
                        cement.SolidifyId = detail.SolidifyId;
                        cement.SolidifyType = detail.SolidifyType;
                        cement.BucketCode = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId).BucketCode;
                        cementList.Add(cement);
                    }
                }
                vm.SolidifyDetailList = cementList;
                detailFlag = "edit";
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(model.BucketId);
                if (bucketModel != null)
                    bucketCode = bucketModel.BucketCode;
                var trackModel = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == model.TrackId).ToList();
                if (trackModel != null && trackModel.Count > 0)
                    trackCode = trackModel[0].TrackCode;

                //废物跟踪单列表
                List<NuclearGiftDetail> giftDetailList = _NuclearGiftDetailRepository.GetAll().AsQueryable().Where(c => c.GiftId == uid).ToList();
                if (giftDetailList != null && giftDetailList.Count > 0)
                {
                    vm.GiftDetailList = new List<GiftDetailList>();
                    for (int i = 0; i < giftDetailList.Count; i++)
                    {
                        string tId = giftDetailList[i].TrackId;
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        GiftDetailList detail = new GiftDetailList();
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.GiftDetailList.Add(detail);
                    }
                }
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.BucketCode = bucketCode;
            ViewBag.TrackCode = trackCode;
            ViewBag.ViewType = Request["type"];
            ViewBag.ViewStatus = Request["status"];
            return View(vm);
        }

        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "干湿料制备及废树脂装桶固化添加")]
        public ActionResult AddBucketRSolidify(CementSolidifyVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶未经过检查或者不是空桶。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucketRSolidify = _NuclearBucketRSolidifyRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listBucketRSolidify != null)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号已经填充过。\"}", JsonRequestBehavior.AllowGet);
                }
                string trackCode = Request.Form["txtTrackCode"];
                //var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).Where(c=>c.TrackType=="RESIN" && c.DealStatus=="0").ToList();
                var trackList = TrackItemBuilder.GetTrackList(AppContext.CurrentUser.ProjectCode).Where(c => (c.DealStatus == "0" || c.DealStatus == null) && c.TrackType.ToUpper() == "RESIN").AsQueryable().ToList();
                NuclearBucketRSolidify RSolidify = new NuclearBucketRSolidify();
                RSolidify = model.BucketRSolidifyModel;
                RSolidify.SolidifyRId = Guid.NewGuid().ToString();
                RSolidify.BucketId = listBucket[0].BucketId;
                //RSolidify.TrackId = trackList[0].TrackId;
                RSolidify.CreateUserNo = AppContext.CurrentUser.UserId;
                RSolidify.CreateUserName = AppContext.CurrentUser.UserName;
                RSolidify.CreateDate = DateTime.Now;
                RSolidify.Status = Request.Form["submitType"];
                RSolidify.Stationcode = AppContext.CurrentUser.ProjectCode;
         
                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                //判断废物跟踪单是否存在
                if (trackArray != null && trackArray.Length > 0 && trackList != null)
                {
                    for (int i = 0; i < trackArray.Length; i++)
                    {
                        string trackId = trackArray[i];
                        var list = trackList.Where(c => c.TrackId == trackId).ToList();
                        if (list == null || list.Count == 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在或者已经处理过\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                }

                //更新
                if (RSolidify.Status == "2")
                {
                    //更新废物跟踪单
                    string trackStation = string.Empty;
                    if (trackArray != null && trackArray.Length > 0)
                    {
                        for (int i = 0; i < trackArray.Length; i++)
                        {
                            string trackId = trackArray[i];
                            if (!string.IsNullOrEmpty(trackId))
                            {
                                var trackModel = trackList.Where(n => n.TrackId == trackId).ToList();
                                if (trackModel.Count > 0)
                                {
                                    trackStation = trackModel[0].StationId;
                                    //TrackItemBuilder.UpdateTrackDealStatus(trackModel[0].TrackType, trackModel[0].TrackId, "1");
                                }
                            }
                        }
                    }

                    //修改主单信息
                    RSolidify.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    RSolidify.ConfirmUserName = AppContext.CurrentUser.UserName;
                    RSolidify.ConfirmDate = DateTime.Now;

                    //更新桶信息
                    if (trackList.Count > 0)
                    {
                        var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(RSolidify.BucketId);
                        modelBucket.StationId = trackStation;
                        _NuclearBucketRepository.Update(modelBucket);
                        _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, "废树脂", "干湿料制备及废树脂装桶固化", "FILL");
                    }
                }

                //提交
                if (_NuclearBucketRSolidifyRepository.AddBucketRSolidify(RSolidify, trackArray))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "干湿料制备及废树脂装桶固化修改及确认")]
        public ActionResult UpdateBucketRSolidify(CementSolidifyVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                string hideCode = Request.Form["hidBucketCode"];
                if (bucketCode != hideCode)
                {
                    bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                    if (listBucket[0].BucketStatus != "PREPARE")
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶未经过检查或者不是空桶。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucketRSolidify = _NuclearBucketRSolidifyRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listBucketRSolidify != null)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号已经填充过。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.BucketRSolidifyModel.BucketId = listBucket[0].BucketId;
                }
                string trackCode = Request.Form["txtTrackCode"];
                string hideTrack = Request.Form["hidTrackCode"];
                var trackList = TrackItemBuilder.GetTrackList( AppContext.CurrentUser.ProjectCode).Where(c=>c.TrackType=="RESIN").ToList();
                if (trackCode != hideTrack)
                {
                    if (trackList.Count == 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    string tId = trackList[0].TrackId;
                    var solutionList = _NuclearBucketRSolidifyRepository.GetQueryList().Where(n => n.TrackId == tId).ToList();
                    if (solutionList.Count > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号已经存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                }
  
                model.BucketRSolidifyModel.Status = Request.Form["submitType"];
                string[] trackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });

                //判断废物跟踪单是否存在
                if (trackArray != null && trackArray.Length > 0 && trackList != null)
                {
                    for (int i = 0; i < trackArray.Length; i++)
                    {
                        string trackId = trackArray[i];
                        var list = trackList.Where(c => c.TrackId == trackId).ToList();
                        if (list == null || list.Count == 0)
                        {
                            return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在或者已经处理过\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                }
                //更新
                if (model.BucketRSolidifyModel.Status == "2")
                {
                    //更新废物跟踪单
                    string giftId = model.BucketRSolidifyModel.SolidifyRId;
                    IQueryable<NuclearGiftDetail> iqueryGiftDetail = _NuclearGiftDetailRepository.GetAll().AsQueryable().Where(c => c.GiftId == giftId);
                    if (iqueryGiftDetail != null && iqueryGiftDetail.Count() > 0)
                    {
                        foreach (var item in iqueryGiftDetail)
                        {
                           // TrackItemBuilder.UpdateTrackDealStatus(item.TrackType, item.TrackId, "0");
                        }
                    }
                    string trackStation = string.Empty;
                    if (trackArray != null && trackArray.Length > 0)
                    {
                        for (int i = 0; i < trackArray.Length; i++)
                        {
                            string trackId = trackArray[i];
                            if (!string.IsNullOrEmpty(trackId))
                            {
                                var trackModel = trackList.Where(n => n.TrackId == trackId).ToList();
                                if (trackModel.Count > 0)
                                {
                                    trackStation = trackModel[0].StationId;
                                   // TrackItemBuilder.UpdateTrackDealStatus(trackModel[0].TrackType, trackModel[0].TrackId, "1");
                                }
                            }
                        }
                    }

                    //修改主单
                    model.BucketRSolidifyModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.BucketRSolidifyModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.BucketRSolidifyModel.ConfirmDate = DateTime.Now;

                    //修改桶信息
                    var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(model.BucketRSolidifyModel.BucketId);
                    modelBucket.StationId = trackStation;
                    _NuclearBucketRepository.Update(modelBucket);
                    _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, "废树脂", "干湿料制备及废树脂装桶固化", "FILL");

          
                }

                //提交
                if (_NuclearBucketRSolidifyRepository.UpdateBucketRSolidify(model.BucketRSolidifyModel, trackArray))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        public ActionResult DeleteBucketRSolidify()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearBucketRSolidifyRepository.DeleteBucketRSolidify(id))
                {
                    _NuclearBucketRSolidifyRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #endregion

        #region"干湿料制备及浓缩液装桶固化"

        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "干湿料制备及浓缩液装桶固化")]
        public ActionResult BucketSSolidifyDetail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            string bucketCode = string.Empty;
            string trackCode = string.Empty;
            CementSolidifyVM vm = new CementSolidifyVM();
            vm.OperationList = CommonHelper.GetOperationList("Bucket_S_Solidify_Detail");
            vm.BucketSSolidifyModel = new NuclearBucketSSolidify();
            vm.BucketStatusList = new List<SelectListItem>();
            vm.SolidifyDetailList = new List<CementSolidifyDetailList>();
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            NuclearBucketSSolidify model = new NuclearBucketSSolidify();
            //如果是点击修改进入此页面
            if (!string.IsNullOrEmpty(uid))
            {
                model = _NuclearBucketSSolidifyRepository.GetBucketSSolidifyModel(uid);
                vm.BucketSSolidifyModel = model;
                var detailList = _NuclearBucketSolutionRepository.GetDetailBySolidifyId(uid, "4").ToList();
                List<CementSolidifyDetailList> cementList = new List<CementSolidifyDetailList>();
                if (detailList != null && detailList.Count > 0)
                {
                    foreach (NuclearSolidifyDetail detail in detailList)
                    {
                        CementSolidifyDetailList cement = new CementSolidifyDetailList();
                        cement.DetailId = detail.DetailId;
                        cement.SolidifyId = detail.SolidifyId;
                        cement.SolidifyType = detail.SolidifyType;
                        cement.BucketCode = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId).BucketCode;
                        cementList.Add(cement);
                    }
                }
                vm.SolidifyDetailList = cementList;
                detailFlag = "edit";
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(model.BucketId);
                if (bucketModel != null)
                    bucketCode = bucketModel.BucketCode;
                var trackModel = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == model.TrackId).ToList();
                if (trackModel != null && trackModel.Count > 0)
                    trackCode = trackModel[0].TrackCode;
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.BucketCode = bucketCode;
            ViewBag.TrackCode = trackCode;
            ViewBag.ViewType = Request["type"];
            ViewBag.ViewStatus = Request["status"];
            return View(vm);
        }

        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "干湿料制备及浓缩液装桶固化添加")]
        public ActionResult AddBucketSSolidify(CementSolidifyVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶未经过检查或者不是空桶。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucketSSolidify = _NuclearBucketSSolidifyRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listBucketSSolidify != null)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号已经填充过。\"}", JsonRequestBehavior.AllowGet);
                }
                string trackCode = Request.Form["txtTrackCode"];
                var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (trackList.Count == 0)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                string tId = trackList[0].TrackId;
                //var solutionList = _NuclearBucketSSolidifyRepository.GetQueryList().Where(n => n.TrackId == tId).ToList();
                //if (solutionList.Count > 0)
                //{
                //    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号已经存在。\"}", JsonRequestBehavior.AllowGet);
                //}
                string allCode = Request.Form["hidAddBucketCode"];
                string[] arrayCode = null;
                string[] arrayBucketId = null;
                string wCode = string.Empty;
                string sCode = string.Empty;
                string strBucketId = string.Empty;
                if (!string.IsNullOrEmpty(allCode))
                {
                    arrayCode = allCode.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                if (arrayCode != null)
                {
                    foreach (string code in arrayCode)
                    {
                        bool wFlag = _NuclearBucketRepository.IsDrain(code, AppContext.CurrentUser.ProjectCode);
                        if (!wFlag)
                        {
                            wCode += code + ",";
                        }
                        var bucketList = _NuclearBucketRepository.QueryListByCode(code, AppContext.CurrentUser.ProjectCode).ToList();
                        if (bucketList != null && bucketList.Count > 0)
                        {
                            strBucketId += bucketList[0].BucketId + ",";
                            var sList = _NuclearBucketSolutionRepository.GetDetailByBucketId(bucketList[0].BucketId, "4").ToList();
                            if (sList != null && sList.Count > 0)
                            {
                                sCode += code + ",";
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(wCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号:" + wCode.Trim(new char[] { ',' }) + "不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(sCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号:" + sCode.Trim(new char[] { ',' }) + "已经存在。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(strBucketId))
                {
                    arrayBucketId = strBucketId.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                NuclearBucketSSolidify SSolidify = new NuclearBucketSSolidify();
                SSolidify = model.BucketSSolidifyModel;
                SSolidify.SolidifySIdd = Guid.NewGuid().ToString();
                SSolidify.BucketId = listBucket[0].BucketId;
                SSolidify.TrackId = trackList[0].TrackId;
                SSolidify.CreateUserNo = AppContext.CurrentUser.UserId;
                SSolidify.CreateUserName = AppContext.CurrentUser.UserName;
                SSolidify.CreateDate = DateTime.Now;
                SSolidify.Status = Request.Form["submitType"];
                SSolidify.Stationcode = AppContext.CurrentUser.ProjectCode;
                List<NuclearSolidifyDetail> detailList = new List<NuclearSolidifyDetail>();
                if (arrayCode != null)
                {
                    for (int i = 0; i < arrayCode.Length; i++)
                    {
                        NuclearSolidifyDetail detail = new NuclearSolidifyDetail();
                        detail.DetailId = Guid.NewGuid().ToString();
                        detail.SolidifyId = SSolidify.SolidifySIdd;
                        detail.SolidifyType = "1";
                        detail.BucketId = arrayBucketId[i];
                        detailList.Add(detail);
                    }
                }
                if (SSolidify.Status == "2")
                {
                    SSolidify.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    SSolidify.ConfirmUserName = AppContext.CurrentUser.UserName;
                    SSolidify.ConfirmDate = DateTime.Now;
   
                    if (trackList.Count > 0)
                    {
                        var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(SSolidify.BucketId);
                        modelBucket.StationId = trackList[0].StationId;
                        _NuclearBucketRepository.Update(modelBucket);
                        _NuclearBucketRepository.UnitOfWork.Commit();
                        string trackType = TrackItemBuilder.GetNameByCode(trackList[0].TrackType);
                        _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, trackType, "干湿料制备及浓废树脂固化", "FILL");
                        if (trackList[0].TrackType == "ELEMENT" || trackList[0].TrackType == "TECH2" || trackList[0].TrackType == "SUNDRY")
                        {
                            TrackItemBuilder.UpdateTrackDealStatus(trackList[0].TrackType, trackList[0].TrackId, "1");
                        }
                    }
                }
                if (_NuclearBucketSSolidifyRepository.AddBucketSSolidify(SSolidify, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "干湿料制备及浓缩液装桶固化修改及确认")]
        public ActionResult UpdateBucketSSolidify(CementSolidifyVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                string hideCode = Request.Form["hidBucketCode"];
                if (bucketCode != hideCode)
                {
                    bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                    if (listBucket[0].BucketStatus != "PREPARE")
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶未经过检查或者不是空桶。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucketSSolidify = _NuclearBucketSSolidifyRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listBucketSSolidify != null)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号已经填充过。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.BucketSSolidifyModel.BucketId = listBucket[0].BucketId;
                }
                string trackCode = Request.Form["txtTrackCode"];
                string hideTrack = Request.Form["hidTrackCode"];
                var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (trackCode != hideTrack)
                {
                    if (trackList.Count == 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    string tId = trackList[0].TrackId;
                    //var solutionList = _NuclearBucketSSolidifyRepository.GetQueryList().Where(n => n.TrackId == tId).ToList();
                    //if (solutionList.Count > 0)
                    //{
                    //    return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号已经存在。\"}", JsonRequestBehavior.AllowGet);
                    //}
                   
                }
                model.BucketSSolidifyModel.TrackId = trackList[0].TrackId;
                model.BucketSSolidifyModel.TrackType = trackList[0].TrackType;
                string allCode = Request.Form["hidAddBucketCode"];
                string allDate = Request.Form["hidAddBucketDate"];
                string[] arrayCode = null;
                string[] arrayDate = null;
                string[] arrayBucketId = null;
                string wCode = string.Empty;
                string sCode = string.Empty;
                string strBucketId = string.Empty;
                if (!string.IsNullOrEmpty(allCode))
                {
                    arrayCode = allCode.Trim(new char[] { ',' }).Split(new char[] { ',' });
                    arrayDate = allDate.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                if (arrayCode != null)
                {
                    foreach (string code in arrayCode)
                    {
                        bool wFlag = _NuclearBucketRepository.IsDrain(code, AppContext.CurrentUser.ProjectCode);
                        if (!wFlag)
                        {
                            wCode += code + ",";
                        }
                        var bucketList = _NuclearBucketRepository.QueryListByCode(code, AppContext.CurrentUser.ProjectCode).ToList();
                        if (bucketList != null && bucketList.Count > 0)
                        {
                            strBucketId += bucketList[0].BucketId + ",";
                            var sList = _NuclearBucketSolutionRepository.GetDetailByBucketId(bucketList[0].BucketId, "4").Where(n => n.SolidifyId != model.BucketSSolidifyModel.SolidifySIdd).ToList();
                            if (sList != null && sList.Count > 0)
                            {
                                sCode += code + ",";
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(wCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号:" + wCode.Trim(new char[] { ',' }) + "不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(sCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号:" + sCode.Trim(new char[] { ',' }) + "已经存在。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(strBucketId))
                {
                    arrayBucketId = strBucketId.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                List<NuclearSolidifyDetail> detailList = new List<NuclearSolidifyDetail>();
                if (arrayCode != null)
                {
                    for (int i = 0; i < arrayCode.Length; i++)
                    {
                        NuclearSolidifyDetail detail = new NuclearSolidifyDetail();
                        detail.DetailId = Guid.NewGuid().ToString();
                        detail.SolidifyId = model.BucketSSolidifyModel.SolidifySIdd;
                        detail.SolidifyType = "4";
                        detail.BucketId = arrayBucketId[i];
                        detailList.Add(detail);
                    }
                }
                string confirmFlag = model.BucketSSolidifyModel.Status;
                model.BucketSSolidifyModel.Status = Request.Form["submitType"];
                if (model.BucketSSolidifyModel.Status == "2")
                {
                    model.BucketSSolidifyModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.BucketSSolidifyModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.BucketSSolidifyModel.ConfirmDate = DateTime.Now;
         
                    if (confirmFlag != "2")
                    {
                        if (trackList.Count > 0)
                        {
                            var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(model.BucketSSolidifyModel.BucketId);
                            modelBucket.StationId = trackList[0].StationId;
                            _NuclearBucketRepository.Update(modelBucket);
                       
                            string trackType = TrackItemBuilder.GetNameByCode(trackList[0].TrackType);
                            _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, trackType, "干湿料制备及浓废树脂固化", "FILL");
                            if (trackList[0].TrackType == "ELEMENT" || trackList[0].TrackType == "TECH2" || trackList[0].TrackType == "SUNDRY")
                            {
                                TrackItemBuilder.UpdateTrackDealStatus(trackList[0].TrackType, trackList[0].TrackId, "1");
                            }
                        }
                        
                    }
                }
                if (_NuclearBucketSSolidifyRepository.UpdateBucketSSolidify(model.BucketSSolidifyModel, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        public ActionResult DeleteBucketSSolidify()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearBucketSSolidifyRepository.DeleteBucketSSolidify(id))
                {
                    _NuclearBucketSSolidifyRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

  
        #endregion

        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            IQueryable<NuclearBucket> query = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsCompress == null || e.IsCompress == "" || e.IsCompress == "0") && (e.IsOutSend == "" || e.IsOutSend == null) && e.BucketStatus == "PREPARE");
            if (query != null && query.Count() > 0)
            {
                list = query.ToList();
            }
            
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 自动填充——废物跟踪单
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetTrackDataList(string keyword)
        {
            //IQueryable<TrackItemVM> iqueryTrackItem = TrackItemBuilder.GetAllTrackList("DIOI20170001", "CC");
            List<TrackItemVM> list = TrackItemBuilder.GetAllTrackList(keyword, AppContext.CurrentUser.ProjectCode).Where(c => c.DealStatus == "0" || c.DealStatus == null).AsQueryable().ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count > 0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].TrackCode;
                    autoComplete.Code = list[i].TrackId;
                    autoCompleteList.Add(autoComplete);
                }

            }

            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 自动填充——废树脂废物跟踪单
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetResinTrackDataList(string keyword)
        {
            List<TrackItemVM> list = TrackItemBuilder.GetAllTrackList(keyword, AppContext.CurrentUser.ProjectCode).Where(c => (c.DealStatus == "0" || c.DealStatus ==null)&& c.TrackType.ToUpper() == "RESIN").AsQueryable().ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count > 0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].TrackCode;
                    autoComplete.Code = list[i].TrackId;
                    autoCompleteList.Add(autoComplete);
                }

            }

            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }



        /// <summary>
        /// 检查废物跟踪单号
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckTrack()
        {
            string trackCode = Request["code"];
            var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).Where(c => c.DealStatus==null || c.DealStatus == "0").ToList();
            if (trackList.Count == 0)
            {
                return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在或者已经处理。\"}", JsonRequestBehavior.AllowGet);
            }
            return Json("{\"result\":true,\"msg\":\"" + trackList[0].TrackId + "\"}", JsonRequestBehavior.AllowGet);
        }
    }
}
