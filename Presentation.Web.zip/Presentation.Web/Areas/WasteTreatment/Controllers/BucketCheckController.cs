﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.EquipManage.ViewModels;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.Controllers
{
    /// <summary>
    /// 桶检查
    /// </summary>
    public class BucketCheckController : Controller
    {
        INuclearBucketCheckRepository _NuclearBucketCheckRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        INonComformanceRepository _NonComformanceRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        public BucketCheckController(INuclearBucketCheckRepository NuclearBucketCheckRepository
            , IBasicObjectRepository BasicObjectRepository
            , INuclearBucketRepository NuclearBucketRepository
            , INonComformanceRepository NonComformanceRepository
            , IBasicWasteUnitRepository BasicWasteUnitRepository)
        {
            this._NuclearBucketCheckRepository = NuclearBucketCheckRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._NonComformanceRepository = NonComformanceRepository;
            this._BasicWasteUnitRepository = BasicWasteUnitRepository;
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "桶检查")]
        public ActionResult Index()
        {
            BucketCheckVM vm = new BucketCheckVM();
         
            vm.OperationList = CommonHelper.GetOperationList("Bucket_Check");
            return View(vm);
        }
        /// <summary>
        /// 桶检查明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "桶检查明细")]
        public ActionResult Detail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            string bucketCode = string.Empty;
            BucketCheckVM vm = new BucketCheckVM();
            vm.OperationList = CommonHelper.GetOperationList("Bucket_Check");
            vm.BucketCheckModel = new NuclearBucketCheck();
            vm.BucketTypeList = new List<SelectListItem>();
            vm.StationList = new List<SelectListItem>();
            List<BasicObject> listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryBucket= _BasicObjectRepository.GetSubobjectsByCode("Bucket", AppContext.CurrentUser.ProjectCode);
            if (queryBucket != null && queryBucket.Count() > 0)
            {
                listBasicObject = queryBucket.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }

            vm.StationList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
            }
            foreach (var item in stationList)
            {
                vm.StationList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
            }

            NuclearBucketCheck model = new NuclearBucketCheck();
            //如果是点击修改进入此页面
            if (uid != "0")
            {
                model = _NuclearBucketCheckRepository.GetBucketCheckModel(uid);
                vm.BucketCheckModel = model;
                detailFlag = "edit";
                bucketCode = _NuclearBucketRepository.GetBucketInfoModel(model.BucketId).BucketCode;
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.BucketCode = bucketCode;
            ViewBag.ViewType = Request["type"];

            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(BucketCheckCondition bucketCheckCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var query = _NuclearBucketCheckRepository.GetBucketCheckList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
            if (!string.IsNullOrEmpty(bucketCheckCondition.BucketCode))
            {
                var listBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.BucketCode.ToUpper().Contains(bucketCheckCondition.BucketCode.ToUpper())).ToList();
                List<string> listId = new List<string>();
                for (int i = 0; i < listBucket.Count; i++)
                {
                    listId.Add(listBucket[i].BucketId);
                }
                query = query.Where(n => listId.Contains(n.BucketId));
            }
            if (!string.IsNullOrEmpty(bucketCheckCondition.WorkTicket))
                query = query.Where(n => n.WorkTicket.ToUpper().Contains(bucketCheckCondition.WorkTicket.ToUpper()));
            if (!string.IsNullOrEmpty(bucketCheckCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(bucketCheckCondition.StartDate);
                query = query.Where(n => n.CheckDate >= sDate);
            }
            if (!string.IsNullOrEmpty(bucketCheckCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(bucketCheckCondition.EndDate);
                query = query.Where(n => n.CheckDate <= eDate);
            }

            IQueryable<BucketCheckList> data = query.Select(n => new BucketCheckList
            {
                CheckId = n.CheckId,
                BucketCode = n.BucketId,
                WorkTicket = n.WorkTicket,
                StationName = n.Stationcode,
                Shield = n.Shield == "1" ? "是" : "否",
                ShieldPlyRound = n.ShieldPlyRound,
                Lime = n.Lime == "1" ? "是" : "否",
                Weight = n.Weight,
                CheckPersonName = n.CheckPersonName,
                CreateDate = n.CreateDate,
                Status = n.Status,
                StationId = n.StationId
            });

            var listData = data.ToList();
            List<BucketCheckList> listNew = new List<BucketCheckList>();
            if (listData != null && listData.Count > 0)
            {
                foreach (BucketCheckList bc in listData)
                {
                    var checkModel = _NuclearBucketRepository.GetBucketInfoModel(bc.BucketCode);
                    if (checkModel != null)
                    {
                        listNew.Add(bc);
                    }
                }
            }
            listNew = listNew.OrderByDescending(n => n.CreateDate).ToList();
            data = listNew.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<BucketCheckList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.CheckId,
                    List = new List<object>() {
                    d.CheckId,
                    _NuclearBucketRepository.GetBucketInfoModel(d.BucketCode).BucketCode,
                    d.WorkTicket,
                    _BasicWasteUnitRepository.GetNameById(d.StationId),
                    d.Shield,  
                    d.ShieldPlyRound,
                    d.Lime,          
                    d.Weight,
                    d.CheckPersonName,
                    d.Status,
                    _NonComformanceRepository.GetListByBucketCode(d.BucketCode).ToList().Count>0?"有":"无"
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 添加桶检查信息
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "桶检查添加")]
        public ActionResult AddBucketCheck(BucketCheckVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (string.IsNullOrEmpty(listBucket[0].BucketStatus))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶没有经过空桶准备。\"}", JsonRequestBehavior.AllowGet);
                }
                NuclearBucketCheck nuclearBucketCheck = _NuclearBucketCheckRepository.GetAll().Where(d => d.BucketId == listBucket[0].BucketId).FirstOrDefault();
                if (nuclearBucketCheck != null)
                {
                    return Json("{\"result\":false,\"msg\":\"桶号已经经过桶检查。\"}", JsonRequestBehavior.AllowGet);
                }
                NuclearBucketCheck check = new NuclearBucketCheck();
                check = model.BucketCheckModel;
                check.CheckId = Guid.NewGuid().ToString();
                check.CreateUserNo = AppContext.CurrentUser.UserId;
                check.CreateUserName = AppContext.CurrentUser.UserName;
                check.CreateDate = DateTime.Now;
                check.Status = Request.Form["submitType"];
                check.BucketId = listBucket[0].BucketId;
                check.Stationcode = AppContext.CurrentUser.ProjectCode;
                string eval = Request.Form["ckbGeneralEval"];
                if (eval == "1")
                    check.GeneralEval = "1";
                else
                    check.GeneralEval = "0";
                if (check.Status == "2")
                {
                    check.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    check.ConfirmUserName = AppContext.CurrentUser.UserName;
                    check.ConfirmDate = DateTime.Now;
                    var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(check.BucketId);
                    if (check.GeneralEval == "1")
                    {
                        modelBucket.BucketStatus = "PREPARE";
                    }
                    else
                    {
                        modelBucket.BucketStatus = "UNPREPARE";
                    }
                    _NuclearBucketRepository.Update(modelBucket);
                }
                if (_NuclearBucketCheckRepository.AddBucketCheck(check))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 检查桶是否经过了准备
        /// </summary>
        /// <param name="bucketCode"></param>
        /// <returns></returns>
        public ActionResult CheckIsPrepare(string bucketCode)
        {
            var list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().ToUpper() == bucketCode.Trim().ToUpper() && e.Stationcode.ToUpper().Trim() == AppContext.CurrentUser.ProjectCode.ToUpper().Trim() && e.IsDrain == "1" && e.IsOutSend!="1" && e.IsCompress!="1" && e.BucketStatus == "PREPARE").ToList();
            if (list.Count > 0)
            {
                return Json("{\"result\":true,\"msg\":\"PREPARE\"}", JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("{\"result\":true,\"msg\":\"EMPTY\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "桶检查修改及确认")]
        public ActionResult UpdateBucketCheck(BucketCheckVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                string hideCode = Request.Form["hidBucketCode"];
                if (bucketCode != hideCode)
                {
                    bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                    if (string.IsNullOrEmpty(listBucket[0].BucketStatus))
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶没有经过空桶准备。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucketCheck = _NuclearBucketCheckRepository.GetBucketCheckByBucketId(listBucket[0].BucketId).ToList();
                    if (listBucketCheck != null && listBucketCheck.Count > 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号已经存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.BucketCheckModel.BucketId = listBucket[0].BucketId;

              
                }
                string eval = Request.Form["ckbGeneralEval"];
                if (eval == "1")
                    model.BucketCheckModel.GeneralEval = "1";
                else
                    model.BucketCheckModel.GeneralEval = "0";
                string confirmFlag = model.BucketCheckModel.Status;
                model.BucketCheckModel.Status = Request.Form["submitType"];
                if (model.BucketCheckModel.Status == "2")
                {
                    model.BucketCheckModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.BucketCheckModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.BucketCheckModel.ConfirmDate = DateTime.Now;
                    var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(model.BucketCheckModel.BucketId);
                    modelBucket.BucketStatus = "PREPARE";
                    _NuclearBucketRepository.Update(modelBucket);
                }
                if (_NuclearBucketCheckRepository.UpdateBucketCheck(model.BucketCheckModel))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "桶检查删除")]
        public ActionResult DeleteBucketCheck()
        {
            try
            {
                string id = Request["id"].Trim(new char[] { ',' });
                string[] idList = id.Split(new char[] { ',' });

                foreach (var checkId in idList)
                {
                    NuclearBucketCheck bucketCheck = _NuclearBucketCheckRepository.Get(checkId);
                    if (bucketCheck != null)
                    {
                        NuclearBucket bucket = _NuclearBucketRepository.Get(bucketCheck.BucketId);
                        if (bucket.BucketStatus != "PREPARE")
                        {
                            return Json("{\"result\":true,\"msg\":\"本批检查的桶中,有部分废物桶已经到了其他工序,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }
                }

                foreach (var checkId in idList)
                {
                    NuclearBucketCheck bucketCheck = _NuclearBucketCheckRepository.Get(checkId);
                    if (bucketCheck != null)
                    {
                        NuclearBucket bucket = _NuclearBucketRepository.Get(bucketCheck.BucketId);
                        if (bucket.BucketStatus == "PREPARE")
                        {
                            _NuclearBucketRepository.UpdateBucketStatus(bucket.BucketCode, AppContext.CurrentUser.ProjectCode, "DRAINEMPTY");
                        }
                        _NuclearBucketCheckRepository.Delete(bucketCheck);
                    }
                }
                _NuclearBucketCheckRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
 
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmBucketCheck(BucketCheckVM model, FormCollection formCollection)
        {
            try
            {
                NuclearBucketCheck check = new NuclearBucketCheck();
                string uid = Request["BucketCheckId"];
                if (!string.IsNullOrEmpty(uid))
                    check = _NuclearBucketCheckRepository.GetBucketCheckModel(uid);
                else
                    check = _NuclearBucketCheckRepository.GetBucketCheckModel(model.BucketCheckModel.CheckId);
                check.Status = "2";
                check.ConfirmUserNo = AppContext.CurrentUser.UserId;
                check.ConfirmUserName = AppContext.CurrentUser.UserName;
                check.ConfirmDate = DateTime.Now;
                var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(check.BucketId);
                modelBucket.BucketStatus = "PREPARE";
                _NuclearBucketRepository.Update(modelBucket);
                _NuclearBucketRepository.UnitOfWork.Commit();
                if (_NuclearBucketCheckRepository.UpdateBucketCheck(check))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && e.IsOutSend == null && (e.BucketStatus == "EMPTY" || e.BucketStatus=="PREPARE")).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
