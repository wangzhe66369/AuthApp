﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.EquipManage.ViewModels;
using RWIS.Domain.DomainObjects.View;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Areas.WasteTracking.ViewModels;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using System.Web;
using System.Data;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModelBuilder;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.Controllers
{
    public class FixAtionController : Controller
    {
        IBasicObjectRepository _BasicObjectRepository;
        INonComformanceRepository _NonComformanceRepository;
        INuclearFixationRepository _NuclearFixationRepository;
        INuclearFixationDetailRepository _NuclearFixationDetailRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        INuclearTrackElementRepository _NuclearTrackElementRepository;
        public FixAtionController(IBasicObjectRepository BasicObjectRepository
            , INonComformanceRepository NonComformanceRepository
            , INuclearFixationRepository NuclearFixationRepository
            , INuclearBucketRepository NuclearBucketRepository
            , INuclearWastePackageRepository NuclearWastePackageRepository
            ,INuclearFixationDetailRepository NuclearFixationDetailRepository
             , INuclearTrackElementRepository _NuclearTrackElementRepository
            )
        {
            this._BasicObjectRepository = BasicObjectRepository;
            this._NonComformanceRepository = NonComformanceRepository;
            this._NuclearFixationRepository = NuclearFixationRepository;
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._NuclearWastePackageRepository = NuclearWastePackageRepository;
            this._NuclearFixationDetailRepository = NuclearFixationDetailRepository;
            this._NuclearTrackElementRepository = _NuclearTrackElementRepository;
        }

        /// <summary>
        /// 浓缩液固化
        /// </summary>
        /// <returns></returns>
        public ActionResult Import()
        {
            return View();
        }

        /// <summary>
        /// 导入浓缩液固化
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult Import(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的电缆数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    {
                        //删除文件
                        if (System.IO.File.Exists(strNewImportPath))
                        {
                            System.IO.File.Delete(strNewImportPath);
                        }
                        jsonResult = JsonResultHelper.JsonResult(false, "数据必须是EXCEL格式!");
                        jsonResult.ContentType = "text/html";
                        return jsonResult;
                    }
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);
                        TableBuilder.ImportFix(ds, strNewImportPath);
                        
                    }
                }

                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }

        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "固定")]
        public ActionResult Index()
        {
            FixAtionVM vm = new FixAtionVM();
            vm.OperationList = CommonHelper.GetOperationList("Fix_Ation");
            return View(vm);
        }
        /// <summary>
        /// 明细页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "固定明细")]
        public ActionResult Detail()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            string bucketCode = string.Empty;
            FixAtionVM vm = new FixAtionVM();
            vm.OperationList = CommonHelper.GetOperationList("Fix_Ation");
            vm.FixAtionModel = new NuclearFixation();
            vm.FixAtionDetailList = new List<FixAtionDetailList>();
            vm.BucketTypeList = new List<SelectListItem>();
            vm.WasteTypeList = new List<SelectListItem>();
            vm.BucketStatusList = new List<SelectListItem>();
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            List<BasicObject> listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryBucket = _BasicObjectRepository.GetSubobjectsByCode("Bucket", AppContext.CurrentUser.ProjectCode);
            if (queryBucket != null && queryBucket.Count() > 0)
            {
                listBasicObject = queryBucket.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            listBasicObject = new List<BasicObject>();
            IQueryable<BasicObject> queryNuClearType = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            if (queryNuClearType != null && queryNuClearType.Count() > 0)
            {
                listBasicObject = queryNuClearType.ToList();
            }
            foreach (BasicObject basic in listBasicObject)
            {
                vm.WasteTypeList.Add(new SelectListItem { Text = basic.Name, Value = basic.Uuid });
            }
            NuclearFixation fixModel = new NuclearFixation();
            List<NuclearFixationDetail> detailList = new List<NuclearFixationDetail>();
            //如果是点击修改进入此页面
            if (uid != "0")
            {
                fixModel = _NuclearFixationRepository.GetFixAtionById(uid);
                vm.FixAtionModel = fixModel;
                bucketCode = _NuclearBucketRepository.GetBucketInfoModel(fixModel.BucketId).BucketCode;
                detailList = _NuclearFixationRepository.GetFixAtionDetailById(uid).ToList();
                if (detailList != null && detailList.Count > 0)
                {
                    for (int i = 0; i < detailList.Count; i++)
                    {
                        string tId = detailList[i].TrackId;
                        NuclearTrackElement nuclearTrackElement = _NuclearTrackElementRepository.Get(tId);
                        var listTrack = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode).Where(t => t.TrackId == tId).ToList();
                        if (listTrack == null || listTrack.Count == 0) continue;
                        FixAtionDetailList detail = new FixAtionDetailList();
                        if (nuclearTrackElement != null)
                        {
                            detail.SystemCode = nuclearTrackElement.SystemCode;
                            detail.ElementVersionOld = nuclearTrackElement.ElementVersionOld;
                        }
                        detail.TrackId = listTrack[0].TrackId;
                        detail.TrackCode = listTrack[0].TrackCode;
                        detail.TrackType = listTrack[0].TrackType;
                        vm.FixAtionDetailList.Add(detail);
                    }
                }
                detailFlag = "edit";
            }
            ViewBag.BucketCode = bucketCode;
            ViewBag.DetailFlag = detailFlag;
            ViewBag.ViewType = Request["type"];
            ViewBag.ViewStatus = Request["status"];
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(FixAtionCondition fixationCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var query = _NuclearFixationRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable();
            if (!string.IsNullOrEmpty(fixationCondition.BucketCode))
            {
                var listBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.BucketCode.ToUpper().Contains(fixationCondition.BucketCode.ToUpper())).ToList();
                List<string> listId = new List<string>();
                for (int i = 0; i < listBucket.Count; i++)
                {
                    listId.Add(listBucket[i].BucketId);
                }
                query = query.Where(n => listId.Contains(n.BucketId));
            }
            if (!string.IsNullOrEmpty(fixationCondition.WorkTicket))
                query = query.Where(n => n.OrderCode.ToUpper().Contains(fixationCondition.WorkTicket.ToUpper()));
            if (!string.IsNullOrEmpty(fixationCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(fixationCondition.StartDate);
                query = query.Where(n => n.CheckDate >= sDate);
            }
            if (!string.IsNullOrEmpty(fixationCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(fixationCondition.EndDate);
                query = query.Where(n => n.CheckDate <= eDate);
            }
            var TrackQuery = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode);
            var queryList = query.ToList();
            List<FixAtionList> list = new List<FixAtionList>();
            for (int i = 0; i < queryList.Count; i++)
            {
                string strCode = string.Empty;
                var DetailQuery = _NuclearFixationRepository.GetFixAtionDetailById(queryList[i].FixationId);
                if (DetailQuery.ToList().Count > 0 && TrackQuery.ToList().Count > 0)
                {
                    var TrackCodeList = TrackQuery.Join(DetailQuery, a => a.TrackId, b => b.TrackId, (a, b) => new { a.TrackCode }).ToList();
                    
                    foreach (var code in TrackCodeList)
                    {
                        strCode += code.TrackCode + ",";
                    }
                    if (!string.IsNullOrEmpty(strCode))
                        strCode = strCode.TrimEnd(new char[] { ',' });
                }
                FixAtionList model = new FixAtionList();
                model.FixAtionId = queryList[i].FixationId;
                model.BucketCode = queryList[i].BucketId;
                model.WorkTicket = queryList[i].OrderCode;
                model.WasteType = queryList[i].WasteTypeId;
                model.TrackCode = strCode;
                model.MeteringAve = queryList[i].MeteringAve;
                model.MeteringTop = queryList[i].MeteringTop;
                model.MeteringMax = queryList[i].MeteringMax;
                model.ControlPersonName = queryList[i].ControlPersonName;
                model.CreateDate = queryList[i].CreateDate;
                model.Status = queryList[i].Status;
                list.Add(model);
            }

            try
            {
                IQueryable<FixAtionList> data = list.AsQueryable();
                var listData = data.ToList();
                List<FixAtionList> listNew = new List<FixAtionList>();
                if (listData != null && listData.Count > 0)
                {
                    foreach (FixAtionList fa in listData)
                    {
                        var checkModel = _NuclearBucketRepository.GetBucketInfoModel(fa.BucketCode);
                        if (checkModel != null)
                        {
                            listNew.Add(fa);
                        }
                    }
                }
                listNew = listNew.OrderByDescending(n => n.CreateDate).ToList();
                data = listNew.AsQueryable();
                //绑定前台JqGrid参数
                var pagedViewModel = new PagedViewModel<FixAtionList>
                {
                    Query = data,
                    GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                    DefaultSortColumn = sidx,
                    Page = page,
                    PageSize = rows,
                }
                .Setup();
                //计算记录数
                jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
                //生成前台json字符串
                pagedViewModel.PagedList.ToList().ForEach(d =>
                {
                    jqGridResponse.Records.Add(new JqGridRecord()
                    {
                        Id = d.FixAtionId,
                        List = new List<object>() {
                    d.FixAtionId,
                    _NuclearBucketRepository.GetBucketInfoModel(d.BucketCode)==null?null:_NuclearBucketRepository.GetBucketInfoModel(d.BucketCode).BucketCode,
                    d.WorkTicket,
                    _BasicObjectRepository.GetBasicById(d.WasteType)==null?null:_BasicObjectRepository.GetBasicById(d.WasteType).Name,
                    d.TrackCode,
                    d.MeteringAve,
                    d.MeteringTop,
                    d.MeteringMax,
                    d.ControlPersonName,
                    d.Status,  
                    _NonComformanceRepository.GetListByBucketCode(d.BucketCode)==null?"无":(_NonComformanceRepository.GetListByBucketCode(d.BucketCode).ToList().Count>0?"有":"无")
                    }
                    });
                });
            }
            catch (Exception)
            {
                
                throw;
            }
           
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 添加信息
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "固定添加")]
        public ActionResult AddFixAtion(FixAtionVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                string wasteType = Request.Form["hidWasteType"];
                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                var listBucketCheck = _NuclearFixationRepository.GetFixAtionByBucketId(listBucket[0].BucketId).ToList();
                if (listBucketCheck != null && listBucketCheck.Count != 0)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号已经经过固定环节。\"}", JsonRequestBehavior.AllowGet);
                }
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号未经过检查或者已经经过填充。\"}", JsonRequestBehavior.AllowGet);
                }
                NuclearFixation fix = new NuclearFixation();
                fix = model.FixAtionModel;
                fix.FixationId = Guid.NewGuid().ToString();
                fix.CreateUserNo = AppContext.CurrentUser.UserId;
                fix.CreateUserName = AppContext.CurrentUser.UserName;
                fix.CreateDate = DateTime.Now;
                fix.Status = Request.Form["submitType"];
                fix.WaterShakeFlag = Request.Form["ckbShakeFlag"];
                fix.ReduceFlag = Request.Form["ckbReduceFlag"];
                fix.BucketId = listBucket[0].BucketId;
                fix.Stationcode = AppContext.CurrentUser.ProjectCode;
                string[] TrackArray = null;
                TrackArray = Request.Form["hidTrackId"].Trim(new char[] { ',' }).Split(new char[] { ',' });
                if (fix.Status == "2")
                {
                    string trackStation = string.Empty;
                    var trackList = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode);
                    if (TrackArray != null && TrackArray.Length > 0)
                    {
                        for (int i = 0; i < TrackArray.Length; i++)
                        {
                            string trackId = TrackArray[i];
                            var trackModel = trackList.Where(n => n.TrackId == trackId).ToList();
                            if (trackModel.Count > 0)
                            {
                                trackStation = trackModel[0].StationId;
                                if (trackModel[0].TrackType == "ELEMENT" || trackModel[0].TrackType == "TECH2" || trackModel[0].TrackType == "SUNDRY")
                                {
                                    TrackItemBuilder.UpdateTrackDealStatus(trackModel[0].TrackType, trackModel[0].TrackId, "1");
                                }
                            }
                        }
                    }
                    if (!string.IsNullOrEmpty(trackStation))
                    {
                        var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(fix.BucketId);
                        modelBucket.StationId = trackStation;
                        _NuclearBucketRepository.Update(modelBucket);
                    }
                    fix.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    fix.ConfirmUserName = AppContext.CurrentUser.UserName;
                    fix.ConfirmDate = DateTime.Now;

                    _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, wasteType, wasteType + "固定", "FILL");
                    string packageCode = _NuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                    var wasteList = _NuclearWastePackageRepository.GetAll().Where(n => n.BucketId == fix.BucketId && n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                    if (wasteList.Count == 0)
                    {
                        NuclearWastePackage package = new NuclearWastePackage();
                        package.PackageId = Guid.NewGuid().ToString();
                        package.PackageCode = packageCode;
                        package.BucketId = fix.BucketId;
                        package.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        package.ConfirmUserName = AppContext.CurrentUser.UserName;
                        package.ConfirmDate = DateTime.Now;
                        package.Stationcode = AppContext.CurrentUser.ProjectCode;
                        _NuclearWastePackageRepository.Create(package);

                    }
                }
                if (_NuclearFixationRepository.AddFixAtion(fix, TrackArray))
                {
                    _NuclearFixationRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "固定修改及确认")]
        public ActionResult UpdateFixAtion(FixAtionVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                string hideCode = Request.Form["hidBucketCode"];
                string wasteType = Request.Form["hidWasteType"];
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (bucketCode != hideCode)
                {
                    bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }

                    if (listBucket[0].BucketStatus != "PREPARE")
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号未经过检查或者已经经过填充。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listBucketCheck = _NuclearFixationRepository.GetFixAtionByBucketId(listBucket[0].BucketId).ToList();
                    if (listBucketCheck != null || listBucketCheck.Count != 0)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号已经存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.FixAtionModel.BucketId = listBucket[0].BucketId;
                }
                model.FixAtionModel.WaterShakeFlag = Request.Form["ckbShakeFlag"];
                model.FixAtionModel.ReduceFlag = Request.Form["ckbReduceFlag"];
                string confirmFlag = model.FixAtionModel.Status;
                model.FixAtionModel.Status = Request.Form["submitType"];
                string[] TrackArray = null;
                TrackArray = Request.Form["hidTrackId"].Replace("\r\n", "").Replace(" ", "").Trim(new char[] { ',' }).Split(new char[] { ',' });
                if (model.FixAtionModel.Status == "2")
                {
                    model.FixAtionModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.FixAtionModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.FixAtionModel.ConfirmDate = DateTime.Now;

                    string trackStation = string.Empty;
                    var trackList = TrackItemBuilder.GetAllTrackList(string.Empty, AppContext.CurrentUser.ProjectCode);
                    if (TrackArray != null && TrackArray.Length > 0)
                    {
                        for (int i = 0; i < TrackArray.Length; i++)
                        {
                            string trackId = TrackArray[i];
                            var trackModel = trackList.Where(n => n.TrackId == trackId).AsQueryable();
                            if (trackModel.Count() > 0)
                            {
                                List<TrackItemVM> list = trackModel.ToList();
                                trackStation = list[0].StationId;
                                if (list[0].TrackType == "ELEMENT" || list[0].TrackType == "TECH2" || list[0].TrackType == "SUNDRY")
                                {
                                    TrackItemBuilder.UpdateTrackDealStatus(list[0].TrackType, list[0].TrackId, "1");
                                }
                            }
                        }
                    }
                    if (!string.IsNullOrEmpty(trackStation))
                    {
                        var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(model.FixAtionModel.BucketId);
                        modelBucket.StationId = trackStation;
                        _NuclearBucketRepository.Update(modelBucket);
                    }

                    if (confirmFlag != "2")
                    {
                        _NuclearBucketRepository.UpdateBucketWasteType(bucketCode, AppContext.CurrentUser.ProjectCode, wasteType, wasteType + "固定", "FILL");
                        string packageCode = _NuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                        var wasteList = _NuclearWastePackageRepository.GetAll().Where(n => n.BucketId == model.FixAtionModel.BucketId && n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                        if (wasteList.Count == 0)
                        {
                            NuclearWastePackage package = new NuclearWastePackage();
                            package.PackageId = Guid.NewGuid().ToString();
                            package.PackageCode = packageCode;
                            package.BucketId = model.FixAtionModel.BucketId;
                            package.ConfirmUserNo = AppContext.CurrentUser.UserId;
                            package.ConfirmUserName = AppContext.CurrentUser.UserName;
                            package.ConfirmDate = DateTime.Now;
                            package.Stationcode = AppContext.CurrentUser.ProjectCode;
                            _NuclearWastePackageRepository.Create(package);

                        }
                    }
                }
                if (_NuclearFixationRepository.UpdateFixAtion(model.FixAtionModel, TrackArray))
                {
                    _NuclearFixationRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "固定删除")]
        public ActionResult DeleteFixAtion()
        {
            try
            {
                string id = Request["id"];
                NuclearFixation model = _NuclearFixationRepository.Get(id);
                if (model != null)
                {
                    //修改桶状态
                    NuclearBucket bucket = _NuclearBucketRepository.Get(model.BucketId);
                    if (bucket != null && bucket.BucketStatus == "FILL")
                    {
                        _NuclearBucketRepository.UpdateBucketWasteType(bucket.BucketCode, AppContext.CurrentUser.ProjectCode, string.Empty, string.Empty, "EMPTY");
                    }
                    //else
                    //{
                    //    return Json("{\"result\":true,\"msg\":\"该环节所使用的废物桶已经到了其他工序阶段,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                    //}

                    //删除主表数据
                    _NuclearFixationRepository.Delete(model);

                    //删除明细信息
                    IQueryable<NuclearFixationDetail> list= _NuclearFixationDetailRepository.GetAll().AsQueryable().Where(n => n.FixationId == model.FixationId);
                    foreach (NuclearFixationDetail detail in list)
                    {
                        if (detail != null)
                        {
                            _NuclearFixationDetailRepository.Delete(detail);
                        }
                    }
                    _NuclearFixationDetailRepository.UnitOfWork.Commit();
                }
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmFixAtion(FixAtionVM model, FormCollection formCollection)
        {
            try
            {
                NuclearFixation fix = new NuclearFixation();
                string uid = Request["id"];
                if (!string.IsNullOrEmpty(uid))
                    fix = _NuclearFixationRepository.GetFixAtionById(uid);
                else
                    fix = _NuclearFixationRepository.GetFixAtionById(model.FixAtionModel.FixationId);
                fix.Status = "2";
                fix.ConfirmUserNo = AppContext.CurrentUser.UserId;
                fix.ConfirmUserName = AppContext.CurrentUser.UserName;
                fix.ConfirmDate = DateTime.Now;
                var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(fix.BucketId);
                modelBucket.BucketStatus = "FILL";
                _NuclearBucketRepository.Update(modelBucket);
                if (_NuclearFixationRepository.UpdateFixAtion(fix, null))
                {
                    _NuclearFixationRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 检查废物跟踪单号
        /// </summary>
        /// <returns></returns>
        public ActionResult CheckTrack()
        {
            string trackCode = Request["code"];
            var trackList = TrackItemBuilder.GetAllTrackList(trackCode, AppContext.CurrentUser.ProjectCode).Where(c=>c.DealStatus==null || c.DealStatus=="0").ToList();
            if (trackList.Count == 0)
            {
                return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号不存在或者已经处理。\"}", JsonRequestBehavior.AllowGet);
            }
            string tId = trackList[0].TrackId;
            string systemCode = trackList[0].SystemCode;
            NuclearTrackElement nuclearTrackElement = _NuclearTrackElementRepository.Get(tId);
            string elementVersionOld = string.Empty;
            if (nuclearTrackElement != null)
            {
               elementVersionOld = nuclearTrackElement.ElementVersionOld;
            }
            
            var fixList = _NuclearFixationRepository.GetFixAtionDetailByTrackId(tId).ToList();
            if (fixList.Count > 0)
            {
                return Json("{\"result\":false,\"msg\":\"您填的废物跟踪单号已经存在。\"}", JsonRequestBehavior.AllowGet);
            }

            return Json(new { result = true, msg = trackList[0].TrackId, systemCode = systemCode, elementVersionOld = elementVersionOld }, JsonRequestBehavior.AllowGet);

            //return Json("{\"result\":true,\"msg\":\"" + trackList[0].TrackId + "\"}", JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsCompress == "" || e.IsCompress == "0") && (e.IsOutSend == "" || e.IsOutSend == null) && e.BucketStatus == "PREPARE").ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 自动填充——废物跟踪单
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetTrackDataList(string keyword)
        {
            List<TrackItemVM> list = TrackItemBuilder.GetAllTrackList(keyword, AppContext.CurrentUser.ProjectCode).AsQueryable().Where(c => c.DealStatus == "0" || c.DealStatus==null).ToList();//.Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count > 0)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].TrackCode;
                    autoComplete.Code = list[i].TrackId;
                    autoCompleteList.Add(autoComplete);
                }

            }

            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
