﻿using System.Collections.Generic;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.EquipManage.ViewModels;
using NET01.Presentation.Web.Mvc.JqGrid;
using System.Linq;
using RWIS.Domain.DomainObjects;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using System;
using RWIS.Infrastructure.Data.Repositories;
using RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;
using System.Web;
using System.Data;
using RWIS.Presentation.Web.Areas.WasteTreatment.ViewModelBuilder;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.Controllers
{
     
    public class BucketCoverController : Controller
    {
        INuclearBucketSolutionRepository _NuclearBucketSolutionRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INonComformanceRepository _NonComformanceRepository;
        INuclearCoverMetalRepository _NuclearCoverMetalRepository;
        INuclearCoverMixRepository _NuclearCoverMixRepository;
        INuclearWastePackageRepository _NuclearWastePackageRepository;
        INuclearTempstockRepository _NuclearTempstockRepository;
        INuclearQtTransRepository _NuclearQtTransRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        INuclearSolidifyDetailRepository _NuclearSolidifyDetailRepository;
        INuclearTrackTechSRepository _NuclearTrackTechSRepository;
        INuclearTrackSundryRepository _NuclearTrackSundryRepository;
        INuclearTrackFilterRepository _NuclearTrackFilterRepository;
        INuclearTrackElementRepository _NuclearTrackElementRepository;
        INuclearBucketResinRepository _NuclearBucketResinRepository;
        INuclearBucketRSolidifyRepository _NuclearBucketRSolidifyRepository;
        INuclearBucketSSolidifyRepository _NuclearBucketSSolidifyRepository;
        public BucketCoverController(INuclearBucketSolutionRepository NuclearBucketSolutionRepository
            , INuclearBucketRepository NuclearBucketRepository
            , IBasicObjectRepository BasicObjectRepository
            , INonComformanceRepository NonComformanceRepository
            , INuclearCoverMetalRepository NuclearCoverMetalRepository
            , INuclearCoverMixRepository NuclearCoverMixRepository
            , INuclearWastePackageRepository NuclearWastePackageRepository
            , INuclearTempstockRepository NuclearTempstockRepository
            , INuclearQtTransRepository NuclearQtTransRepository
            , IMaterialTypeRepository MaterialTypeRepository
            , INuclearSolidifyDetailRepository NuclearSolidifyDetailRepository
            ,INuclearTrackTechSRepository NuclearTrackTechSRepository
            ,INuclearTrackSundryRepository NuclearTrackSundryRepository
            ,INuclearTrackFilterRepository NuclearTrackFilterRepository
            ,INuclearTrackElementRepository NuclearTrackElementRepository
            , INuclearBucketResinRepository NuclearBucketResinRepository
            , INuclearBucketRSolidifyRepository NuclearBucketRSolidifyRepository
            , INuclearBucketSSolidifyRepository NuclearBucketSSolidifyRepository
            )
        {
            this._NuclearBucketSolutionRepository = NuclearBucketSolutionRepository;
            this._NuclearBucketRepository = NuclearBucketRepository;
            this._BasicObjectRepository = BasicObjectRepository;
            this._NonComformanceRepository = NonComformanceRepository;
            this._NuclearCoverMetalRepository = NuclearCoverMetalRepository;
            this._NuclearCoverMixRepository = NuclearCoverMixRepository;
            this._NuclearWastePackageRepository = NuclearWastePackageRepository;
            this._NuclearTempstockRepository = NuclearTempstockRepository;
            this._NuclearQtTransRepository = NuclearQtTransRepository;
            this._MaterialTypeRepository = MaterialTypeRepository;
            this._NuclearSolidifyDetailRepository = NuclearSolidifyDetailRepository;
            this._NuclearTrackTechSRepository = NuclearTrackTechSRepository;
            this._NuclearTrackSundryRepository = NuclearTrackSundryRepository;
            this._NuclearTrackFilterRepository = NuclearTrackFilterRepository;
            this._NuclearTrackElementRepository = NuclearTrackElementRepository;
            this._NuclearBucketResinRepository = NuclearBucketResinRepository;
            this._NuclearBucketRSolidifyRepository = NuclearBucketRSolidifyRepository;
            this._NuclearBucketSSolidifyRepository = NuclearBucketSSolidifyRepository;
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "400L金属桶超压及封盖")]
        public ActionResult Index()
        {
            BucketCoverVM vm = new BucketCoverVM();
            vm.OperationList = CommonHelper.GetOperationList("Bucket_Cover");
            return View(vm);
        }
        /// <summary>
        /// 列表页
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "湿混料制备及封盖")]
        public ActionResult IndexM()
        {
            BucketCoverVM vm = new BucketCoverVM();
            vm.OperationList = CommonHelper.GetOperationList("Bucket_CoverM");
            return View(vm);
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataList(CoverCondition coverCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var queryMetal = _NuclearCoverMetalRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (!string.IsNullOrEmpty(coverCondition.BucketCode))
            {
                var listBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.BucketCode.ToUpper().Contains(coverCondition.BucketCode.ToUpper())).ToList();
                List<string> listId = new List<string>();
                for (int i = 0; i < listBucket.Count; i++)
                {
                    listId.Add(listBucket[i].BucketId.ToUpper());
                }
                queryMetal = queryMetal.Where(n => listId.Contains(n.BucketId.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(coverCondition.WorkTicket))
            {
                queryMetal = queryMetal.Where(n => n.WorkTicket.ToUpper().Contains(coverCondition.WorkTicket.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(coverCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(coverCondition.StartDate);
                queryMetal = queryMetal.Where(n => n.CheckDate >= sDate).ToList();
            }
            if (!string.IsNullOrEmpty(coverCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(coverCondition.EndDate);
                queryMetal = queryMetal.Where(n => n.CheckDate <= eDate).ToList();
            }
            var queryBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode);
            List<CoverList> listData = new List<CoverList>();
            foreach (NuclearCoverMetal metal in queryMetal)
            {
                string strBucketCode = string.Empty;
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(metal.BucketId);
                if (bucketModel == null) continue;
                var queryDetail = _NuclearCoverMetalRepository.GetDetailByCoverId(metal.MetalId);
                if (queryDetail.ToList().Count > 0 && queryBucket.ToList().Count > 0)
                {
                    var BucketCodeList = queryBucket.Join(queryDetail, a => a.BucketId, b => b.BucketId, (a, b) => new { a.BucketCode }).ToList();
                    foreach (var code in BucketCodeList)
                    {
                        strBucketCode += code.BucketCode + ",";
                    }
                    if (!string.IsNullOrEmpty(strBucketCode))
                        strBucketCode = strBucketCode.TrimEnd(new char[] { ',' });
                }
                CoverList cover = new CoverList();
                cover.CoverId = metal.MetalId;
                cover.ControlType = "1";
                cover.BucketCode = bucketModel.BucketCode;
                cover.WorkTicket = metal.WorkTicket;
                cover.CoverType = "湿混料制备及400L金属桶装桶封盖";
                cover.CheckPersonName = metal.CheckName;
                cover.Status = metal.Status;
                cover.CreateDate = metal.CreateDate;
                cover.Comformance = _NonComformanceRepository.GetListByBucketCode(metal.BucketId).ToList().Count > 0 ? "有" : "无";
                cover.BucketCodeL = strBucketCode;
                cover.DoseEva = metal.DoseEva;
                cover.DoseMax = metal.DoseMax;
                cover.DoseMeter = metal.DoseMeter;
                listData.Add(cover);
            }
            listData = listData.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<CoverList> data = listData.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<CoverList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.CoverId,
                    List = new List<object>() {
                    d.CoverId,
                    d.ControlType,
                    d.BucketCode,
                    d.WorkTicket,
                    d.BucketCodeL,
                    d.DoseEva,
                    d.DoseMax,
                    d.DoseMeter,
                    d.CoverType,             
                    d.CheckPersonName,
                    d.Status,
                    d.Comformance
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 查询列表
        /// </summary>
        /// <param name="equipInfoCondition">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public JsonResult GetDataListM(CoverCondition coverCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            var queryMix = _NuclearCoverMixRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            if (!string.IsNullOrEmpty(coverCondition.BucketCode))
            {
                var listBucket = _NuclearBucketRepository.GetBucketInfoList(AppContext.CurrentUser.ProjectCode).Where(n => n.BucketCode.ToUpper().Contains(coverCondition.BucketCode.ToUpper())).ToList();
                List<string> listId = new List<string>();
                for (int i = 0; i < listBucket.Count; i++)
                {
                    listId.Add(listBucket[i].BucketId.ToUpper());
                }
                queryMix = queryMix.Where(n => listId.Contains(n.BucketId.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(coverCondition.WorkTicket))
            {
                queryMix = queryMix.Where(n => n.WorkTicket.ToUpper().Contains(coverCondition.WorkTicket.ToUpper())).ToList();
            }
            if (!string.IsNullOrEmpty(coverCondition.StartDate))
            {
                DateTime sDate = Convert.ToDateTime(coverCondition.StartDate);
                queryMix = queryMix.Where(n => n.CheckDate >= sDate).ToList();
            }
            if (!string.IsNullOrEmpty(coverCondition.EndDate))
            {
                DateTime eDate = Convert.ToDateTime(coverCondition.EndDate);
                queryMix = queryMix.Where(n => n.CheckDate <= eDate).ToList();
            }
            List<CoverMList> listData = new List<CoverMList>();
            foreach (NuclearCoverMix mix in queryMix)
            {
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(mix.BucketId);
                if (bucketModel == null) continue;
                CoverMList cover = new CoverMList();
                cover.CoverId = mix.MixId;
                cover.ControlType = "2";
                cover.BucketCode = bucketModel.BucketCode;
                cover.WorkTicket = mix.WorkTicket;
                cover.CoverType = "湿混料制备及封盖";
                cover.CheckPersonName = mix.CheckName;
                cover.Status = mix.Status;
                cover.CreateDate = mix.CreateDate;
                cover.Comformance = _NonComformanceRepository.GetListByBucketCode(mix.BucketId).ToList().Count > 0 ? "有" : "无";
                cover.MaterialFlag = mix.MaterialFlag == "1" ? "有" : "无";
                cover.CurdleWeight = mix.CurdleWeight;
                cover.OverSpace = mix.OverSpace;
                cover.DoseEva = mix.DoseEva;
                cover.DoseMeter = mix.DoseMeter;
                listData.Add(cover);
            }
            listData = listData.OrderByDescending(n => n.CreateDate).ToList();
            IQueryable<CoverMList> data = listData.AsQueryable();
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<CoverMList>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.CoverId,
                    List = new List<object>() {
                    d.CoverId,
                    d.ControlType,
                    d.BucketCode,
                    d.WorkTicket,
                    d.MaterialFlag,
                    d.CurdleWeight,
                    d.OverSpace,
                    d.DoseEva,
                    d.DoseMeter,
                    d.CoverType,             
                    d.CheckPersonName,
                    d.Status,
                    d.Comformance
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "封盖删除")]
        public ActionResult DeleteCover()
        {
            try
            {
                string id = Request["id"];
                string type = Request["type"];
                if (type == "1")
                {
                    var list = _NuclearSolidifyDetailRepository.GetAll().AsQueryable().Where(n => n.SolidifyId == id && n.SolidifyType == "5");
                    if (list != null)
                    {
                        foreach (NuclearSolidifyDetail detail in list)
                        {
                            NuclearBucket bucket = _NuclearBucketRepository.Get(detail.BucketId);
                            if (bucket!=null && bucket.BucketStatus != "FILL")
                            {
                                return Json("{\"result\":false,\"msg\":\"该环节所使用的压缩桶已经到了其他工序阶段,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                            }
                        }

                        foreach (NuclearSolidifyDetail detail in list)
                        {
                            if (detail != null)
                            {
                                NuclearBucket bucket = _NuclearBucketRepository.Get(detail.BucketId);
                                bucket.BucketStatus = "PREPARE";
                                bucket.IsCompress = "0";
                                _NuclearBucketRepository.Update(bucket);
                                _NuclearSolidifyDetailRepository.Delete(detail);
                            }
                        }
                    }

                    //处理桶信息
                    NuclearCoverMetal model = _NuclearCoverMetalRepository.Get(id);
                    NuclearBucket newBucket = _NuclearBucketRepository.Get(model.BucketId);
                    IQueryable<NuclearWastePackage> wastePackageList=_NuclearWastePackageRepository.GetAll().AsQueryable().Where(c => c.BucketId == model.BucketId);
                    if (newBucket != null && wastePackageList != null && wastePackageList.Count()>0)
                    {
                        if (!string.IsNullOrEmpty(wastePackageList.ToList()[0].Status))
                        {
                            return Json("{\"result\":false,\"msg\":\"该环节所使用的废物桶已经到了其他工序阶段,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                        }
                    }

                    //删除封盖信息并提交
                    _NuclearCoverMetalRepository.Delete(model);
                    _NuclearCoverMetalRepository.UnitOfWork.Commit();
                }
                if (type == "2")
                {
                    NuclearCoverMix model = _NuclearCoverMixRepository.Get(id);
                    if (model != null)
                    {
                        NuclearBucket bucket = _NuclearBucketRepository.Get(model.BucketId);
                        IQueryable<NuclearWastePackage> wastePackageList = _NuclearWastePackageRepository.GetAll().AsQueryable().Where(c => c.BucketId == model.BucketId);
                        if (bucket != null && wastePackageList != null && wastePackageList.Count() > 0)
                        {
                            if (!string.IsNullOrEmpty(wastePackageList.ToList()[0].Status))
                            {
                                return Json("{\"result\":false,\"msg\":\"该环节所使用的废物桶已经到了其他工序阶段,不能删除,请核对。\"}", JsonRequestBehavior.AllowGet);
                            }
                        }
                        else
                        {
                            _NuclearBucketRepository.UpdateBucketWasteType(bucket.BucketCode, AppContext.CurrentUser.ProjectCode, "", "", "FILL");
                            _NuclearCoverMixRepository.Delete(model);
                            _NuclearCoverMixRepository.UnitOfWork.Commit();
                        }
                    }
                }
                return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);

            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmCover(BucketCoverVM model, FormCollection formCollection)
        {
            try
            {
                string id = Request["id"];
                string type = Request["type"];
                if (type == "1")
                {
                    NuclearCoverMetal metal = new NuclearCoverMetal();
                    if (!string.IsNullOrEmpty(id))
                        metal = _NuclearCoverMetalRepository.GetModelById(id);
                    else
                        metal = _NuclearCoverMetalRepository.GetModelById(model.CoverMetalModel.MetalId);
                    metal.Status = "2";
                    metal.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    metal.ConfirmUserName = AppContext.CurrentUser.UserName;
                    metal.ConfirmDate = DateTime.Now;
                    if (_NuclearCoverMetalRepository.UpdateCoverMetal(metal, null))
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    else
                        return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
                if (type == "2")
                {
                    NuclearCoverMix mix = new NuclearCoverMix();
                    if (!string.IsNullOrEmpty(id))
                        mix = _NuclearCoverMixRepository.GetModelById(id);
                    else
                        mix = _NuclearCoverMixRepository.GetModelById(model.CoverMixModel.MixId);
                    mix.Status = "2";
                    mix.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    mix.ConfirmUserName = AppContext.CurrentUser.UserName;
                    mix.ConfirmDate = DateTime.Now;
                    if (_NuclearCoverMixRepository.UpdateCoverMix(mix))
                        return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                    else
                        return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
                }
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }

        #region"湿混料制备及400L金属桶装桶封盖"

        /// <summary>
        /// 湿混料制备及400L金属桶装桶封盖
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "湿混料制备及400L金属桶装桶封盖")]
        public ActionResult CoverMetal()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            string bucketCode = string.Empty;
            BucketCoverVM vm = new BucketCoverVM();
            vm.PointList = new List<PointData>();
            vm.OperationList = CommonHelper.GetOperationList("Bucket_Cover");
            vm.BucketStatusList = new List<SelectListItem>();
            vm.CoverMetalModel = new NuclearCoverMetal();
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            string dateTimePage = string.Empty;
            NuclearCoverMetal model = new NuclearCoverMetal();
            if (!string.IsNullOrEmpty(uid))
            {
                model = _NuclearCoverMetalRepository.GetModelById(uid);
                vm.CoverMetalModel = model;
                detailFlag = "edit";
                var detailList = _NuclearCoverMetalRepository.GetDetailByCoverId(model.MetalId).ToList();
                List<CoverDetailDataList> coverList = new List<CoverDetailDataList>();
                if (detailList != null && detailList.Count > 0)
                {
                    foreach (NuclearCoverDetail detail in detailList)
                    {
                        CoverDetailDataList cover = new CoverDetailDataList();
                        cover.DetailId = detail.DetailId;
                        cover.CoverId = detail.CoverId;
                        if (AppContext.CurrentUser.ProjectCode != "FCGNP")
                        {
                            cover.BucketCode = _NuclearBucketRepository.GetBucketInfoModel(detail.BucketId).BucketCode;
                            cover.BucketDate = detail.BucketDate.ToString();
                            cover.TrackCode = GetTrackCodeList(cover.BucketCode, out dateTimePage);

                        }
                        else

                        { 
                        
                        cover.WasteDescription = detail.WasteDescription;
                        cover.Height = detail.Height.ToString();
                        cover.Weight = detail.Weight.ToString();
                        cover.DoseRate = detail.DoseRate.ToString();
                        }
                      




                        coverList.Add(cover);
                    }
                }
                vm.CoverDetailList = coverList;
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(model.BucketId);
                if (bucketModel != null)
                    bucketCode = bucketModel.BucketCode;
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.BucketCode = bucketCode;
            ViewBag.ViewType = Request["type"];
            ViewBag.ViewStatus = Request["status"];
            ViewBag.ProjectCode = AppContext.CurrentUser.ProjectCode;
            return View(vm);
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "湿混料制备及400L金属桶装桶封盖添加")]
        public ActionResult AddCoverMetal(BucketCoverVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                var listCoverMetal = _NuclearCoverMetalRepository.GetModelByBucketId(listBucket[0].BucketId);
                if (listCoverMetal != null)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号已经超压。\"}", JsonRequestBehavior.AllowGet);
                }
                if (listBucket[0].BucketStatus != "PREPARE")
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号没经过检查或者已经经过填充。\"}", JsonRequestBehavior.AllowGet);
                }

                string allCode = Request.Form["hidAddBucketCode"];
                string allDate = Request.Form["hidAddBucketDate"];
                string[] arrayCode = null;
                string[] arrayDate = null;
                string[] arrayBucketId = null;
                string wCode = string.Empty;
                string sCode = string.Empty;
                string strBucketId = string.Empty;
                if (!string.IsNullOrEmpty(allCode))
                {
                    arrayCode = allCode.Trim(new char[] { ',' }).Split(new char[] { ',' });
                    arrayDate = allDate.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                if (arrayCode != null)
                {
                    foreach (string code in arrayCode)
                    {
                        bool wFlag = _NuclearBucketRepository.IsDrain(code, AppContext.CurrentUser.ProjectCode);
                        if (!wFlag)
                        {
                            wCode += code + ",";
                        }
                        var bucketList = _NuclearBucketRepository.QueryListByCode(code, AppContext.CurrentUser.ProjectCode).ToList();
                        if (bucketList != null && bucketList.Count > 0)
                        {
                            strBucketId += bucketList[0].BucketId + ",";
                            var sList = _NuclearCoverMetalRepository.GetDetailByBucketId(bucketList[0].BucketId).ToList();
                            if (sList != null && sList.Count > 0)
                            {
                                sCode += code + ",";
                            }
                        }
                    }
                }

                if (!string.IsNullOrEmpty(sCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号:" + sCode.Trim(new char[] { ',' }) + "已经经过压缩打包。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(strBucketId))
                {
                    arrayBucketId = strBucketId.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                NuclearCoverMetal metal = new NuclearCoverMetal();
                metal = model.CoverMetalModel;
                metal.MetalId = Guid.NewGuid().ToString();
                metal.BucketId = listBucket[0].BucketId;
                metal.PositionX = Request.Form["pointX"];
                metal.PositionY = Request.Form["pointY"];
                metal.PositionZ = Request.Form["pointZ"];
                metal.CreateUserNo = AppContext.CurrentUser.UserId;
                metal.CreateUserName = AppContext.CurrentUser.UserName;
                metal.CreateDate = DateTime.Now;
                metal.Status = Request.Form["submitType"];
                metal.Stationcode = AppContext.CurrentUser.ProjectCode;
                List<NuclearCoverDetail> detailList = new List<NuclearCoverDetail>();
                string valAll = Request.Form["hidValAll"];
                string[] valAllArr = null;
                string[] valAllEveryArr = null;
                if (AppContext.CurrentUser.ProjectCode == "FCGNP")
                {
                    valAllArr = valAll.Trim().TrimEnd(new char[] { ';' }).TrimStart(new char[] { ';' }).Split(new char[] { ';' });
                    foreach (var item in valAllArr)
                    {
                        valAllEveryArr = item.TrimEnd(new char[] { ',' }).Split(new char[] { ',' });

                        NuclearCoverDetail detail = new NuclearCoverDetail();
                        detail.DetailId = Guid.NewGuid().ToString();
                        detail.CoverId = model.CoverMetalModel.MetalId;
                        detail.WasteDescription = valAllEveryArr[0];
                        detail.Height = Convert.ToDecimal(valAllEveryArr[1]);
                        detail.Weight = Convert.ToDecimal(valAllEveryArr[2]);
                        detail.DoseRate = Convert.ToDecimal(valAllEveryArr[3]);

                        detailList.Add(detail);


                    }
                }
                else
                {
                    if (arrayCode != null)
                    {
                        for (int i = 0; i < arrayCode.Length; i++)
                        {
                            NuclearCoverDetail detail = new NuclearCoverDetail();
                            detail.DetailId = Guid.NewGuid().ToString();
                            detail.CoverId = metal.MetalId;
                            detail.BucketId = arrayBucketId[i];
                            if (!string.IsNullOrEmpty(arrayDate[i]))
                                detail.BucketDate = Convert.ToDateTime(arrayDate[i]);
                            detailList.Add(detail);

                        }
                    }
                
                }
               
                if (metal.Status == "2")
                {
                    var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(metal.BucketId);
                    if (bucketModel != null)
                    {
                        bucketModel.XPosition = metal.PositionX;
                        bucketModel.YPosition = metal.PositionY;
                        bucketModel.ZPosition = metal.PositionZ;
                        _NuclearBucketRepository.Update(bucketModel);
                    }
                    metal.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    metal.ConfirmUserName = AppContext.CurrentUser.UserName;
                    metal.ConfirmDate = DateTime.Now;

                    //更新桶信息
                    _NuclearBucketRepository.UpdateBucketCoverMethod(bucketCode, AppContext.CurrentUser.ProjectCode, "超压", "FILL");
                    if (arrayCode != null)
                    {
                        for (int i = 0; i < arrayCode.Length; i++)
                        {
                            NuclearBucket bucket = _NuclearBucketRepository.Get(arrayBucketId[i]);
                            if (bucket != null)
                            {
                                bucket.BucketStatus = "FILL";
                                bucket.CoverDate = DateTime.Now;
                                bucket.CoverMethod = "被压缩";
                                bucket.DealMethodStatus = "S_METEL_FILL";
                                bucket.IsCompress = "1";
                                this._NuclearBucketRepository.UpdateBucketModel(bucket);
                            }
                        }
                    }
               
                    string codeExist = _NuclearWastePackageRepository.GetPackageCodebyBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(codeExist))
                    {
                        string packageCode = _NuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                        var wasteList = _NuclearWastePackageRepository.GetAll().Where(n => n.BucketId == metal.BucketId && n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                        if (wasteList.Count == 0)
                        {
                            NuclearWastePackage package = new NuclearWastePackage();
                            package.PackageId = Guid.NewGuid().ToString();
                            package.PackageCode = packageCode;
                            package.BucketId = metal.BucketId;
                            package.XPosition = metal.PositionX;
                            package.YPosition = metal.PositionY;
                            package.ZPosition = metal.PositionZ;
                            package.ConfirmUserNo = AppContext.CurrentUser.UserId;
                            package.ConfirmUserName = AppContext.CurrentUser.UserName;
                            package.Stationcode = AppContext.CurrentUser.ProjectCode;
                            package.ConfirmDate = DateTime.Now;
                            var materialModel = _MaterialTypeRepository.GetMaterialModel(listBucket[0].MaterialId);
                            if (materialModel != null)
                            {
                                double? mHeight = materialModel.Height == null ? 0 : materialModel.Height;
                                double? mDia = materialModel.Diamerter == null ? 0 : materialModel.Diamerter;
                                package.Volumn = Convert.ToDecimal(mDia/100 * mDia/100 * mHeight/100 * 3.14);
                            }

                            _NuclearWastePackageRepository.Create(package);
                        }
                    }
                    else
                    {
                        NuclearWastePackage package = new NuclearWastePackage();
                        package = _NuclearWastePackageRepository.GetAll().Where(n => n.PackageCode == codeExist).FirstOrDefault();
                        package.XPosition = metal.PositionX;
                        package.YPosition = metal.PositionY;
                        package.ZPosition = metal.PositionZ;
                        _NuclearWastePackageRepository.UpdatePackage(codeExist, AppContext.CurrentUser.ProjectCode, package);
                    }
                    _NuclearTempstockRepository.MergeMaterialTmpStock(bucketCode, listBucket[0].LocationId, AppContext.CurrentUser.ProjectCode, -1, 1);
                }
                if (_NuclearCoverMetalRepository.AddCoverMetal(metal, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "湿混料制备及400L金属桶装桶封盖修改及确认")]
        public ActionResult UpdateCoverMetal(BucketCoverVM model, FormCollection formCollection)
        {
            try
            {
               
                string bucketCode = Request.Form["txtBucketCode"];
                string hideCode = Request.Form["hidBucketCode"];
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (bucketCode != hideCode)
                {
                    bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }
                    var listCoverMetal = _NuclearCoverMetalRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listCoverMetal != null)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号已经超压。\"}", JsonRequestBehavior.AllowGet);
                    }
                    if (listBucket[0].BucketStatus != "PREPARE")
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号没经过检查或者已经经过填充。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.CoverMetalModel.BucketId = listBucket[0].BucketId;
                }
                string allCode = Request.Form["hidAddBucketCode"];
                string allDate = Request.Form["hidAddBucketDate"];
                string[] arrayCode = null;
                string[] arrayDate = null;
                string[] arrayBucketId = null;
                string wCode = string.Empty;
                string sCode = string.Empty;
                string strBucketId = string.Empty;
                if (!string.IsNullOrEmpty(allCode))
                {
                    arrayCode = allCode.Trim(new char[] { ',' }).Split(new char[] { ',' });
                    arrayDate = allDate.Trim(new char[] { ',' }).Split(new char[] { ',' });
                    int rrayCount = arrayCode.Distinct().Count();
                    int rrayLength = arrayCode.Length;

                    if (rrayCount != rrayLength)
                    {
                        return Json("{\"result\":false,\"msg\":\"桶号重复。\"}", JsonRequestBehavior.AllowGet);
                    }

                }
                if (arrayCode != null)
                {
                    foreach (string code in arrayCode)
                    {
                        bool wFlag = _NuclearBucketRepository.IsDrain(code, AppContext.CurrentUser.ProjectCode);
                        if (!wFlag)
                        {
                            wCode += code + ",";
                        }
                        var bucketList = _NuclearBucketRepository.QueryListByCode(code, AppContext.CurrentUser.ProjectCode).ToList();
                        if (bucketList != null && bucketList.Count > 0)
                        {
                            strBucketId += bucketList[0].BucketId + ",";
                            var sList = _NuclearCoverMetalRepository.GetDetailByBucketId(bucketList[0].BucketId).Where(n => n.CoverId != model.CoverMetalModel.MetalId).ToList();
                            if (sList != null && sList.Count > 0)
                            {
                                sCode += code + ",";
                            }
                        }
                    }
                }

                if (!string.IsNullOrEmpty(sCode))
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号:" + sCode.Trim(new char[] { ',' }) + "已经经过压缩打包。\"}", JsonRequestBehavior.AllowGet);
                }
                if (!string.IsNullOrEmpty(strBucketId))
                {
                    arrayBucketId = strBucketId.Trim(new char[] { ',' }).Split(new char[] { ',' });
                }
                string valAll = Request.Form["hidValAll"];
                string[] valAllArr = null;
                string[] valAllEveryArr = null;
                List<NuclearCoverDetail> detailList = new List<NuclearCoverDetail>();
                if (AppContext.CurrentUser.ProjectCode == "FCGNP")
                {
                    valAllArr = valAll.Trim().TrimEnd(new char[] { ';' }).TrimStart(new char[] { ';' }).Split(new char[] { ';' });
                    foreach (var item in valAllArr)
                    {
                        valAllEveryArr= item.TrimEnd(new char[] { ',' }).Split(new char[] { ',' });

                        NuclearCoverDetail detail = new NuclearCoverDetail();
                        detail.DetailId = Guid.NewGuid().ToString();
                        detail.CoverId = model.CoverMetalModel.MetalId;
                        detail.WasteDescription = valAllEveryArr[0];
                        detail.Height = Convert.ToDecimal(valAllEveryArr[1]);
                        detail.Weight = Convert.ToDecimal(valAllEveryArr[2]);
                        detail.DoseRate = Convert.ToDecimal(valAllEveryArr[3]);
                      
                        detailList.Add(detail);
                       
                        
                    }
                }
                else {
                    if (arrayCode != null)
                    {
                        for (int i = 0; i < arrayCode.Length; i++)
                        {
                            NuclearCoverDetail detail = new NuclearCoverDetail();
                            detail.DetailId = Guid.NewGuid().ToString();
                            detail.CoverId = model.CoverMetalModel.MetalId;
                            if (arrayBucketId != null)
                            {
                                detail.BucketId = arrayBucketId[i];
                            }

                            if (!string.IsNullOrEmpty(arrayDate[i].Trim()))
                                detail.BucketDate = Convert.ToDateTime(arrayDate[i].Trim());
                            detailList.Add(detail);

                            //更新桶信息
                            NuclearBucket bucket = _NuclearBucketRepository.Get(arrayBucketId[i]);
                            if (bucket != null)
                            {
                                bucket.BucketStatus = "FILL";
                                bucket.CoverDate = DateTime.Now;
                                bucket.CoverMethod = "超压";
                                bucket.DealMethodStatus = "S_METEL_FILL";
                                bucket.IsCompress = "1";
                                this._NuclearBucketRepository.UpdateBucketModel(bucket);
                            }
                        }
                    }
                
                }
                
                string confirmFlag = model.CoverMetalModel.Status;
                model.CoverMetalModel.Status = Request.Form["submitType"];
                model.CoverMetalModel.PositionX = Request.Form["pointX"];
                model.CoverMetalModel.PositionY = Request.Form["pointY"];
                model.CoverMetalModel.PositionZ = Request.Form["pointZ"];
                if (model.CoverMetalModel.Status == "2" && confirmFlag != "2")
                {
                    var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(model.CoverMetalModel.BucketId);
                    if (bucketModel != null)
                    {
                        bucketModel.XPosition = model.CoverMetalModel.PositionX;
                        bucketModel.YPosition = model.CoverMetalModel.PositionY;
                        bucketModel.ZPosition = model.CoverMetalModel.PositionZ;
                        _NuclearBucketRepository.Update(bucketModel);
                    }
                    model.CoverMetalModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.CoverMetalModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.CoverMetalModel.ConfirmDate = DateTime.Now;
                    _NuclearBucketRepository.UpdateBucketCoverMethod(bucketCode, AppContext.CurrentUser.ProjectCode, "超压", "FILL");
                    if (arrayCode != null)
                    {
                        for (int i = 0; i < arrayCode.Length; i++)
                        {
                            _NuclearBucketRepository.UpdateBucketCoverMethod(arrayCode[i], AppContext.CurrentUser.ProjectCode, "被压缩", "FILL");
                        }
                    }
                    string codeExist = _NuclearWastePackageRepository.GetPackageCodebyBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(codeExist))
                    {
                        string packageCode = _NuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                        var wasteList = _NuclearWastePackageRepository.GetAll().Where(n => n.BucketId == model.CoverMetalModel.BucketId && n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                        if (wasteList.Count == 0)
                        {
                            NuclearWastePackage package = new NuclearWastePackage();
                            package.PackageId = Guid.NewGuid().ToString();
                            package.PackageCode = packageCode;
                            package.BucketId = model.CoverMetalModel.BucketId;
                            package.XPosition = model.CoverMetalModel.PositionX;
                            package.YPosition = model.CoverMetalModel.PositionY;
                            package.ZPosition = model.CoverMetalModel.PositionZ;
                            package.ConfirmUserNo = AppContext.CurrentUser.UserId;
                            package.ConfirmUserName = AppContext.CurrentUser.UserName;
                            package.Stationcode = AppContext.CurrentUser.ProjectCode;
                            package.ConfirmDate = DateTime.Now;
                            var materialModel = _MaterialTypeRepository.GetMaterialModel(listBucket[0].MaterialId);
                            if (materialModel != null)
                            {
                                double? mHeight = materialModel.Height == null ? 0 : materialModel.Height;
                                double? mDia = materialModel.Diamerter == null ? 0 : materialModel.Diamerter;
                                package.Volumn = Convert.ToDecimal(mDia/100 * mDia/100 * mHeight/100 * 3.14);
                            }
                            _NuclearWastePackageRepository.Create(package);
                        }
                    }
                    else
                    {
                        NuclearWastePackage package = new NuclearWastePackage();
                        package = _NuclearWastePackageRepository.GetAll().Where(n => n.PackageCode == codeExist).FirstOrDefault();
                        package.XPosition = model.CoverMetalModel.PositionX;
                        package.YPosition = model.CoverMetalModel.PositionY;
                        package.ZPosition = model.CoverMetalModel.PositionZ;
                        _NuclearWastePackageRepository.UpdatePackage(codeExist, AppContext.CurrentUser.ProjectCode, package);
                    }
                    _NuclearTempstockRepository.MergeMaterialTmpStock(bucketCode, listBucket[0].LocationId, AppContext.CurrentUser.ProjectCode, -1, 1);
                }
                if (_NuclearCoverMetalRepository.UpdateCoverMetal(model.CoverMetalModel, detailList))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        public ActionResult DeleteCoverMetal()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearCoverMetalRepository.DeleteCoverMetal(id))
                {
                    NuclearCoverMetal model=_NuclearCoverMetalRepository.Get(id);
                    if (model != null)
                    {
                        NuclearBucket bucket = _NuclearBucketRepository.Get(model.BucketId);
                        if (bucket != null)
                        {
                            bucket.BucketStatus = "PREPARE";
                            bucket.CoverMethod = string.Empty;
                            if (!string.IsNullOrEmpty(bucket.XPosition))
                            {
                                bucket.XPosition = string.Empty;
                                bucket.YPosition = string.Empty;
                                bucket.ZPosition = string.Empty;
                                _NuclearBucketRepository.Update(bucket);
                                _NuclearBucketRepository.UnitOfWork.Commit();
                            }
                        }
                    }
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmCoverMetal(BucketCoverVM model, FormCollection formCollection)
        {
            try
            {
                NuclearCoverMetal metal = new NuclearCoverMetal();
                metal = _NuclearCoverMetalRepository.GetModelById(model.CoverMetalModel.MetalId);
                metal.Status = "2";
                metal.ConfirmUserNo = AppContext.CurrentUser.UserId;
                metal.ConfirmUserName = AppContext.CurrentUser.UserName;
                metal.ConfirmDate = DateTime.Now;
                var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(metal.BucketId);
                modelBucket.BucketStatus = "FILL";
                _NuclearBucketRepository.Update(modelBucket);
                _NuclearBucketRepository.UnitOfWork.Commit();
                if (_NuclearCoverMetalRepository.UpdateCoverMetal(metal, null))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }

        #endregion

        #region"湿混料制备及封盖"

        /// <summary>
        /// 湿混料制备及封盖
        /// </summary>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "湿混料制备及封盖")]
        public ActionResult CoverMix()
        {
            string uid = Request["uid"];
            string detailFlag = "add";
            string bucketCode = string.Empty;
            BucketCoverVM vm = new BucketCoverVM();
            vm.PointList = new List<PointData>();
            vm.OperationList = CommonHelper.GetOperationList("Cover_Mix");
            vm.BucketStatusList = new List<SelectListItem>();
            vm.CoverMixModel = new NuclearCoverMix();
            vm.BucketStatusList.Add(new SelectListItem { Text = "封盖", Value = "COVER" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "填充", Value = "FILL" });
            vm.BucketStatusList.Add(new SelectListItem { Text = "准备", Value = "PREPARE" });
            NuclearCoverMix model = new NuclearCoverMix();
            if (!string.IsNullOrEmpty(uid))
            {
                model = _NuclearCoverMixRepository.GetModelById(uid);
                vm.CoverMixModel = model;
                detailFlag = "edit";
                var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(model.BucketId);
                if (bucketModel != null)
                    bucketCode = bucketModel.BucketCode;
            }
            ViewBag.DetailFlag = detailFlag;
            ViewBag.BucketCode = bucketCode;
            ViewBag.ViewType = Request["type"];
            ViewBag.ViewStatus = Request["status"];

            #region"position"

            //var QTList = _NuclearQtTransRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            //var MetalList = _NuclearCoverMetalRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            //var MixList = _NuclearCoverMixRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
            //for (int i = 1; i < 6; i++)
            //{
            //    string a = i.ToString();
            //    string pointX = string.Empty;
            //    string pointY = string.Empty;
            //    var qt = QTList.Where(n => n.QtPositionZ == a).ToList();
            //    for (int k = 0; k < qt.Count; k++)
            //    {
            //        if (string.IsNullOrEmpty(qt[k].QtPositionX)) continue;
            //        if (qt[k].QtPositionX.Contains(","))
            //        {
            //            string[] strX = qt[k].QtPositionX.Split(new char[] { ',' });
            //            string[] strY = qt[k].QtPositionY.Split(new char[] { ',' });
            //            int minX = Convert.ToInt32(strX[0]);
            //            int maxX = Convert.ToInt32(strX[1]);
            //            int minY = Convert.ToInt32(strY[0]);
            //            int maxY = Convert.ToInt32(strY[1]);
            //            for (int m = 0; m <= maxY - minY; m++)
            //            {
            //                for (int n = 0; n <= maxX - minX; n++)
            //                {
            //                    pointX += (minX + n).ToString() + ",";
            //                    pointY += (minY + m).ToString() + ",";
            //                }
            //            }
            //        }
            //        else
            //        {
            //            pointX += qt[k].QtPositionX + ",";
            //            pointY += qt[k].QtPositionY + ",";
            //        }
            //    }
            //    var metal = MetalList.Where(n => n.PositionZ == a).ToList();
            //    for (int k = 0; k < metal.Count; k++)
            //    {
            //        if (string.IsNullOrEmpty(metal[k].PositionX)) continue;
            //        if (metal[k].PositionX.Contains(","))
            //        {
            //            string[] strX = metal[k].PositionX.Split(new char[] { ',' });
            //            string[] strY = metal[k].PositionY.Split(new char[] { ',' });
            //            int minX = Convert.ToInt32(strX[0]);
            //            int maxX = Convert.ToInt32(strX[1]);
            //            int minY = Convert.ToInt32(strY[0]);
            //            int maxY = Convert.ToInt32(strY[1]);
            //            for (int m = 0; m <= maxY - minY; m++)
            //            {
            //                for (int n = 0; n <= maxX - minX; n++)
            //                {
            //                    pointX += (minX + n).ToString() + ",";
            //                    pointY += (minY + m).ToString() + ",";
            //                }
            //            }
            //        }
            //        else
            //        {
            //            pointX += metal[k].PositionX + ",";
            //            pointY += metal[k].PositionY + ",";
            //        }
            //    }
            //    var mix = MixList.Where(n => n.PositionZ == a).ToList();
            //    for (int k = 0; k < mix.Count; k++)
            //    {
            //        if (string.IsNullOrEmpty(mix[k].PositionX)) continue;
            //        if (mix[k].PositionX.Contains(","))
            //        {
            //            string[] strX = mix[k].PositionX.Split(new char[] { ',' });
            //            string[] strY = mix[k].PositionY.Split(new char[] { ',' });
            //            int minX = Convert.ToInt32(strX[0]);
            //            int maxX = Convert.ToInt32(strX[1]);
            //            int minY = Convert.ToInt32(strY[0]);
            //            int maxY = Convert.ToInt32(strY[1]);
            //            for (int m = 0; m <= maxY - minY; m++)
            //            {
            //                for (int n = 0; n <= maxX - minX; n++)
            //                {
            //                    pointX += (minX + n).ToString() + ",";
            //                    pointY += (minY + m).ToString() + ",";
            //                }
            //            }
            //        }
            //        else
            //        {
            //            pointX += mix[k].PositionX + ",";
            //            pointY += mix[k].PositionY + ",";
            //        }
            //    }
            //    pointX = pointX.TrimEnd(new char[] { ',' });
            //    pointY = pointY.TrimEnd(new char[] { ',' });
            //    PointData point = new PointData();
            //    point.PointX = pointX;
            //    point.PointY = pointY;
            //    point.PointZ = a;
            //    vm.PointList.Add(point);
            //}

            #endregion

            return View(vm);
        }
        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "湿混料制备及封盖添加")]
        public ActionResult AddCoverMix(BucketCoverVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                if (!bucketCheck)
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                }
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                var listCoverMix = _NuclearCoverMixRepository.GetModelByBucketId(listBucket[0].BucketId);
                //if (listCoverMix != null)
                //{
                //    return Json("{\"result\":false,\"msg\":\"您填的桶号已经封盖。\"}", JsonRequestBehavior.AllowGet);
                //}

                if (listBucket[0].BucketStatus != "PREPARE" && listBucket[0].BucketStatus != "FILL")
                {
                    return Json("{\"result\":false,\"msg\":\"您填的桶没经过检查或者已经封盖。\"}", JsonRequestBehavior.AllowGet);
                }

                NuclearCoverMix mix = new NuclearCoverMix();
                mix = model.CoverMixModel;
                mix.MixId = Guid.NewGuid().ToString();
                mix.BucketId = listBucket[0].BucketId;
                mix.PositionX = Request.Form["pointX"];
                mix.PositionY = Request.Form["pointY"];
                mix.PositionZ = Request.Form["pointZ"];
                mix.CreateUserNo = AppContext.CurrentUser.UserId;
                mix.CreateUserName = AppContext.CurrentUser.UserName;
                mix.CreateDate = DateTime.Now;
                mix.Status = Request.Form["submitType"];
                mix.Stationcode = AppContext.CurrentUser.ProjectCode;
                if (mix.Status == "2")
                {
                    var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(mix.BucketId);
                    if (bucketModel != null)
                    {
                        bucketModel.XPosition = mix.PositionX;
                        bucketModel.YPosition = mix.PositionY;
                        bucketModel.ZPosition = mix.PositionZ;
                        _NuclearBucketRepository.Update(bucketModel);
                        //_NuclearBucketRepository.UnitOfWork.Commit();
                    }
                    mix.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    mix.ConfirmUserName = AppContext.CurrentUser.UserName;
                    mix.ConfirmDate = DateTime.Now;
                    _NuclearBucketRepository.UpdateBucketCoverMethod(bucketCode, AppContext.CurrentUser.ProjectCode, "湿混料制备及封盖", "COVER");
                    string codeExist = _NuclearWastePackageRepository.GetPackageCodebyBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(codeExist))
                    {
                        string packageCode = _NuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                        var wasteList = _NuclearWastePackageRepository.GetAll().Where(n => n.BucketId == mix.BucketId && n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                        if (wasteList.Count == 0)
                        {
                            NuclearWastePackage package = new NuclearWastePackage();
                            package.PackageId = Guid.NewGuid().ToString();
                            package.PackageCode = packageCode;
                            package.BucketId = mix.BucketId;
                            package.XPosition = mix.PositionX;
                            package.YPosition = mix.PositionY;
                            package.ZPosition = mix.PositionZ;
                            package.ConfirmUserNo = AppContext.CurrentUser.UserId;
                            package.ConfirmUserName = AppContext.CurrentUser.UserName;
                            package.ConfirmDate = DateTime.Now;
                            package.Stationcode = AppContext.CurrentUser.ProjectCode;
                            var materialModel = _MaterialTypeRepository.GetMaterialModel(listBucket[0].MaterialId);
                            if (materialModel != null)
                            {
                                decimal? mHeight = Convert.ToDecimal(materialModel.Height == null ? 0 : materialModel.Height);
                                decimal? mDia = Convert.ToDecimal(materialModel.Diamerter == null ? 0 : materialModel.Diamerter);
                                decimal? mPly = 0;
                                decimal? mSpace = 0;
                                if (model.CoverMixModel.CurdlePly != null)
                                    mPly = model.CoverMixModel.CurdlePly;
                                if (!string.IsNullOrEmpty(model.CoverMixModel.OverSpace))
                                    mSpace = Convert.ToDecimal(model.CoverMixModel.OverSpace);
                                package.Volumn = Convert.ToDecimal((mDia/100 - mPly/100) * (mDia/100 - mPly/100) * (mHeight/100 - mSpace/100) * Convert.ToDecimal(3.14));
                            }
                            _NuclearWastePackageRepository.Create(package);
                        }
                    }
                    else
                    {
                        NuclearWastePackage package = new NuclearWastePackage();
                        package = _NuclearWastePackageRepository.GetAll().Where(n => n.PackageCode == codeExist).FirstOrDefault();
                        package.XPosition = mix.PositionX;
                        package.YPosition = mix.PositionY;
                        package.ZPosition = mix.PositionZ;
                        _NuclearWastePackageRepository.UpdatePackage(codeExist, AppContext.CurrentUser.ProjectCode, package);
                    }
                    _NuclearTempstockRepository.MergeMaterialTmpStock(bucketCode, listBucket[0].LocationId, AppContext.CurrentUser.ProjectCode, 0, 1);
                }
                if (_NuclearCoverMixRepository.AddCoverMix(mix))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "湿混料制备及封盖修改及确认")]
        public ActionResult UpdateCoverMix(BucketCoverVM model, FormCollection formCollection)
        {
            try
            {
                string bucketCode = Request.Form["txtBucketCode"];
                string hideCode = Request.Form["hidBucketCode"];
                var listBucket = _NuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                if (bucketCode != hideCode)
                {
                    bool bucketCheck = _NuclearBucketRepository.IsExistByCodeAndStation(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号不存在。\"}", JsonRequestBehavior.AllowGet);
                    }

                    var listCoverMix = _NuclearCoverMixRepository.GetModelByBucketId(listBucket[0].BucketId);
                    if (listCoverMix != null)
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号已经封盖。\"}", JsonRequestBehavior.AllowGet);
                    }

                    if (listBucket[0].BucketStatus != "PREPARE" && listBucket[0].BucketStatus != "FILL")
                    {
                        return Json("{\"result\":false,\"msg\":\"您填的桶号没经过检查或者填充。\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.CoverMixModel.BucketId = listBucket[0].BucketId;
                }
                string confirmFlag = model.CoverMixModel.Status;
                model.CoverMixModel.Status = Request.Form["submitType"];
                model.CoverMixModel.PositionX = Request.Form["pointX"];
                model.CoverMixModel.PositionY = Request.Form["pointY"];
                model.CoverMixModel.PositionZ = Request.Form["pointZ"];
                if (model.CoverMixModel.Status == "2" && confirmFlag != "2")
                {
                    var bucketModel = _NuclearBucketRepository.GetBucketInfoModel(model.CoverMixModel.BucketId);
                    if (bucketModel != null)
                    {
                        bucketModel.XPosition = model.CoverMixModel.PositionX;
                        bucketModel.YPosition = model.CoverMixModel.PositionY;
                        bucketModel.ZPosition = model.CoverMixModel.PositionZ;
                        _NuclearBucketRepository.Update(bucketModel);
                    }
                    model.CoverMixModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                    model.CoverMixModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                    model.CoverMixModel.ConfirmDate = DateTime.Now;
                    _NuclearBucketRepository.UpdateBucketCoverMethod(bucketCode, AppContext.CurrentUser.ProjectCode, "湿混料制备及封盖", "COVER");
                    string codeExist = _NuclearWastePackageRepository.GetPackageCodebyBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(codeExist))
                    {
                        string packageCode = _NuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                        var wasteList = _NuclearWastePackageRepository.GetAll().Where(n => n.BucketId == model.CoverMixModel.BucketId && n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                        if (wasteList.Count == 0)
                        {
                            NuclearWastePackage package = new NuclearWastePackage();
                            package.PackageId = Guid.NewGuid().ToString();
                            package.PackageCode = packageCode;
                            package.BucketId = model.CoverMixModel.BucketId;
                            package.XPosition = model.CoverMixModel.PositionX;
                            package.YPosition = model.CoverMixModel.PositionY;
                            package.ZPosition = model.CoverMixModel.PositionZ;
                            package.ConfirmUserNo = AppContext.CurrentUser.UserId;
                            package.ConfirmUserName = AppContext.CurrentUser.UserName;
                            package.ConfirmDate = DateTime.Now;
                            package.Stationcode = AppContext.CurrentUser.ProjectCode;
                            var materialModel = _MaterialTypeRepository.GetMaterialModel(listBucket[0].MaterialId);
                            if (materialModel != null)
                            {
                                decimal? mHeight = Convert.ToDecimal(materialModel.Height == null ? 0 : materialModel.Height);
                                decimal? mDia = Convert.ToDecimal(materialModel.Diamerter == null ? 0 : materialModel.Diamerter);
                                decimal? mPly = 0;
                                decimal? mSpace = 0;
                                if (model.CoverMixModel.CurdlePly != null)
                                    mPly = model.CoverMixModel.CurdlePly;
                                if (!string.IsNullOrEmpty(model.CoverMixModel.OverSpace))
                                    mSpace = Convert.ToDecimal(model.CoverMixModel.OverSpace);
                                package.Volumn = Convert.ToDecimal((mDia/100 - mPly/100) * (mDia/100 - mPly/100) * (mHeight/100 - mSpace/100) * Convert.ToDecimal(3.14));
                            }
                            _NuclearWastePackageRepository.Create(package);
                        }
                    }
                    else
                    {
                        NuclearWastePackage package = new NuclearWastePackage();
                        package = _NuclearWastePackageRepository.GetAll().Where(n => n.PackageCode == codeExist).FirstOrDefault();
                        package.XPosition = model.CoverMixModel.PositionX;
                        package.YPosition = model.CoverMixModel.PositionY;
                        package.ZPosition = model.CoverMixModel.PositionZ;
                        _NuclearWastePackageRepository.UpdatePackage(codeExist, AppContext.CurrentUser.ProjectCode, package);
                    }
                    _NuclearTempstockRepository.MergeMaterialTmpStock(bucketCode, listBucket[0].LocationId, AppContext.CurrentUser.ProjectCode, 0, 1);
                }
                if (_NuclearCoverMixRepository.UpdateCoverMix(model.CoverMixModel))
                {
                    _NuclearBucketRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <returns></returns>
        public ActionResult DeleteCoverMix()
        {
            try
            {
                string id = Request["id"];
                if (_NuclearCoverMixRepository.DeleteCoverMix(id))
                {
                    NuclearCoverMix model = _NuclearCoverMixRepository.Get(id);
                    if (model != null)
                    {
                        NuclearBucket bucket = _NuclearBucketRepository.Get(model.BucketId);
                        if (bucket != null)
                        {
                            if (!string.IsNullOrEmpty(bucket.XPosition))
                            {
                                bucket.XPosition = string.Empty;
                                bucket.YPosition = string.Empty;
                                bucket.ZPosition = string.Empty;
                                _NuclearBucketRepository.Update(bucket);
                                _NuclearBucketRepository.UnitOfWork.Commit();
                            }
                        }
                    }
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }
        /// <summary>
        /// 确认
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        public ActionResult ConfirmCoverMix(BucketCoverVM model, FormCollection formCollection)
        {
            try
            {
                NuclearCoverMix mix = new NuclearCoverMix();
                mix = _NuclearCoverMixRepository.GetModelById(model.CoverMixModel.MixId);
                mix.Status = "2";
                mix.ConfirmUserNo = AppContext.CurrentUser.UserId;
                mix.ConfirmUserName = AppContext.CurrentUser.UserName;
                mix.ConfirmDate = DateTime.Now;
                var modelBucket = _NuclearBucketRepository.GetBucketInfoModel(mix.BucketId);
                modelBucket.BucketStatus = "COVER";
                _NuclearBucketRepository.Update(modelBucket);
                _NuclearBucketRepository.UnitOfWork.Commit();
                if (_NuclearCoverMixRepository.UpdateCoverMix(mix))
                    return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
                else
                    return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }

        }

        #endregion

        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetBucketDataList(string keyword)
        {
            //数据源
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            List<NuclearBucket> list = new List<NuclearBucket>();
            list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsCompress == "" || e.IsCompress == "0") && (e.IsOutSend == "" || e.IsOutSend == null) && (e.BucketStatus == "FILL")).ToList();
            string factoryId = Request["factory"];
            if (!string.IsNullOrEmpty(factoryId))
                list = list.Where(n => n.LocationId == factoryId).ToList();
            list = list.Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 自动填充超压桶桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetCompressBucketDataList(string keyword)
        {
            //数据源
           
                string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
                IQueryable<MaterialType> iqueryMaterialType = _MaterialTypeRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.MaterialName.ToUpper().Trim().Contains("208L"));
                var iqueryBucket = _NuclearBucketRepository.GetAll().AsQueryable().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode.ToUpper().Trim() == stationCode && e.IsDrain == "1" && (e.IsCompress == null || e.IsCompress == "" || e.IsCompress == "0") && (e.IsOutSend == "" || e.IsOutSend == null) && e.BucketStatus == "PREPARE");
                List<NuclearBucket> list = new List<NuclearBucket>();
                list = (from m in iqueryMaterialType
                        join b in iqueryBucket on m.MaterialId equals b.MaterialId
                        select b).ToList();
                string factoryId = Request["factory"];
                if (!string.IsNullOrEmpty(factoryId))
                    list = list.Where(n => n.LocationId == factoryId).ToList();
                list = list.Take(10).ToList();
                List<AutoComplete> autoCompleteList = new List<AutoComplete>();
                for (int i = 0; i < list.Count; i++)
                {
                    AutoComplete autoComplete = new AutoComplete();
                    autoComplete.Name = list[i].BucketCode;
                    autoComplete.Code = list[i].BucketId;
                    autoCompleteList.Add(autoComplete);
                }
                var resultObj = new
                {
                    autoCompleteList
                };
                return Json(resultObj, JsonRequestBehavior.AllowGet);
          
           
        }

        private string GetTrackCodeList(string code, out string dateTimePage)
        {
            string stationCode = AppContext.CurrentUser.ProjectCode;
            string bucketId = _NuclearBucketRepository.GetIdByCode(code, stationCode);
            string trackCode = string.Empty;
            string trackId = string.Empty;

            //var querySolution = _NuclearBucketSolutionRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.BucketId == bucketId).ToList();
            //var queryResin = _NuclearBucketResinRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.BucketId == bucketId).ToList();
            //var queryRSolidify = _NuclearBucketRSolidifyRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.BucketId == bucketId).ToList();
            //var querySSolidify = _NuclearBucketSSolidifyRepository.GetQueryList().Where(n => n.Stationcode == AppContext.CurrentUser.ProjectCode && n.BucketId == bucketId).ToList();
           
            //if (querySolution.Count() > 0)
            //{
            //    trackId = querySolution[0].TrackId;
            //    dateTimePage = querySolution[0].CheckDate.Value.ToString("yyyy-MM-dd");
            //}
            //if (queryResin.Count() > 0)
            //{
            //    trackId = queryResin[0].TrackId;
            //    dateTimePage = queryResin[0].CheckDate.Value.ToString("yyyy-MM-dd");
            //}
            //if (queryRSolidify.Count() > 0)
            //{
            //    trackId = queryRSolidify[0].TrackId;
            //    dateTimePage = queryRSolidify[0].CheckDate.Value.ToString("yyyy-MM-dd");
            //}
            //if (querySSolidify.Count() > 0)
            //{
            //    trackId = querySSolidify[0].TrackId;
            //    dateTimePage = querySSolidify[0].CheckDate.Value.ToString("yyyy-MM-dd");
            //}

            //var trackCodeList =RWIS.Presentation.Web.Areas.WasteTracking.ViewModelBuilder.TrackItemBuilder.GetAllTrackList(trackId);
            //if (trackCodeList.Count() > 0)
            //{
            //    trackCode = trackCodeList.ToList()[0].TrackCode;
                
            //}

            dateTimePage = string.Empty;
            IQueryable<NuclearTrackTechS> iqueryTrackTechS = this._NuclearTrackTechSRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.BucketId == bucketId);
            IQueryable<NuclearTrackSundry> iquerySundry = this._NuclearTrackSundryRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.StorageContainerId == bucketId);
            //IQueryable<NuclearTrackFilter> iqueryTrackFilter = this._NuclearTrackFilterRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && c.StorageContainerId == bucketId);
            IQueryable<NuclearTrackElement> iqueryTrackElement = this._NuclearTrackElementRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode && (c.ContainerId == bucketId || c.InputContainerId == bucketId));
            if (iqueryTrackTechS.Count() > 0)
            {
                trackCode += iqueryTrackTechS.ToList()[0].TechSCode;
                dateTimePage = iqueryTrackTechS.ToList()[0].ControlDate.Value.ToString("yyyy-MM-dd");
            }
            if (iquerySundry.Count() > 0)
            {
                trackCode += iquerySundry.ToList()[0].SundryCode;
                dateTimePage = iquerySundry.ToList()[0].ControlDate.Value.ToString("yyyy-MM-dd");
            }
            //if (iqueryTrackFilter.Count() > 0)
            //{
            //    trackCode += iqueryTrackFilter.ToList()[0].FilterCode;
            //}
            if (iqueryTrackElement.Count() > 0)
            {
                trackCode += iqueryTrackElement.ToList()[0].ElementCode;
                dateTimePage = iqueryTrackElement.ToList()[0].InputContainerControlDate.Value.ToString("yyyy-MM-dd");
            }
            return trackCode;
        }
        /// <summary>
        /// 根据桶号得到废物跟踪单号
        /// </summary>
        /// <param name="code">桶号</param>
        /// <returns></returns>
        public JsonResult GetTrackCode(string code)
        {
            string dateTimePage = string.Empty;
            IQueryable<MaterialType> iqueryMaterialType = _MaterialTypeRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == AppContext.CurrentUser.ProjectCode && c.MaterialName.ToUpper().Trim().Contains("208L"));
            if (iqueryMaterialType.Count() == 0)
            {
                return Json("{\"result\":false,\"msg\":\"请输入208L桶。\"}", JsonRequestBehavior.AllowGet);
            }
            string trackCode = GetTrackCodeList(code, out dateTimePage);
            return Json("{\"result\":true,\"msg\":\"" + trackCode + "\",\"dateTimePage\":\"" + dateTimePage + "\"}", JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 导入历史数据页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Import()
        {
            return View();
        }
        /// <summary>
        /// 导入超压历史数据页面
        /// </summary>
        /// <returns></returns>
        public ActionResult ImportMetal()
        {
            return View();
        }
        #region 导入历史数据
        /// <summary>
        /// 导入封盖数据
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult Import(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的历史数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    //string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    //if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    //{
                    //    //删除文件
                    //    if (System.IO.File.Exists(strNewImportPath))
                    //    {
                    //        System.IO.File.Delete(strNewImportPath);
                    //    }
                    //    jsonResult = JsonResultHelper.JsonResult(false, "历史数据必须是EXCEL格式!");
                    //    jsonResult.ContentType = "text/html";
                    //    return jsonResult;
                    //}
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);
                        if (ds.Tables.Count < 1)
                        {
                            //删除文件
                            if (System.IO.File.Exists(strNewImportPath))
                            {
                                System.IO.File.Delete(strNewImportPath);
                            }
                            jsonResult = JsonResultHelper.JsonResult(false, "历史数据格式错误!");
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //判断EXCEL格式是否正确
                        string checkColumns = ImportDataBuilder.GetImportNuclearCoverMixErr(ds, strNewImportPath);
                        if (!string.IsNullOrEmpty(checkColumns))
                        {
                            jsonResult = JsonResultHelper.JsonResult(false, checkColumns);
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //导入数据
                        if (ds != null && ds.Tables.Count == 1)
                        {
                            ImportDataBuilder.ImportNuclearCoverMix(ds, strNewImportPath, AppContext.CurrentUser);
                        }
                    }
                }
                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }
        #endregion
        #region 导入历史数据
        /// <summary>
        /// 导入封盖数据
        /// </summary>
        /// <param name="collection">当前页面窗体</param>
        [HttpPost]
        public ActionResult ImportMetal(FormCollection collection)
        {

            JsonResult jsonResult = new JsonResult();
            HttpFileCollectionBase files = Request.Files;
            string strNewImportPath = UploadHelper.SaveFile(files);
            try
            {

                if (string.IsNullOrEmpty(strNewImportPath))
                {
                    //删除文件
                    if (System.IO.File.Exists(strNewImportPath))
                    {
                        System.IO.File.Delete(strNewImportPath);
                    }
                    jsonResult = JsonResultHelper.JsonResult(false, "请选择要导入的历史数据文件!");
                    jsonResult.ContentType = "text/html";
                    return jsonResult;
                }
                if (files.Count > 0)
                {

                    //string extendName = strNewImportPath.Substring(strNewImportPath.LastIndexOf('.')).ToUpper();
                    //if (!extendName.Contains("XLS") && !extendName.Contains("XLSX"))
                    //{
                    //    //删除文件
                    //    if (System.IO.File.Exists(strNewImportPath))
                    //    {
                    //        System.IO.File.Delete(strNewImportPath);
                    //    }
                    //    jsonResult = JsonResultHelper.JsonResult(false, "历史数据必须是EXCEL格式!");
                    //    jsonResult.ContentType = "text/html";
                    //    return jsonResult;
                    //}
                    if (!string.IsNullOrEmpty(strNewImportPath))
                    {
                        //得到导入的列表信息
                        strNewImportPath = strNewImportPath.TrimEnd(';');
                        DataSet ds = ImportExportHelper.ExcelToData(strNewImportPath);
                        if (ds.Tables.Count < 1)
                        {
                            //删除文件
                            if (System.IO.File.Exists(strNewImportPath))
                            {
                                System.IO.File.Delete(strNewImportPath);
                            }
                            jsonResult = JsonResultHelper.JsonResult(false, "历史数据格式错误!");
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //判断EXCEL格式是否正确
                        string checkColumns = ImportDataBuilder.GetImportNuclearCoverMetalErr(ds, strNewImportPath);
                        if (!string.IsNullOrEmpty(checkColumns))
                        {
                            jsonResult = JsonResultHelper.JsonResult(false, checkColumns);
                            jsonResult.ContentType = "text/html";
                            return jsonResult;
                        }

                        //导入数据
                        if (ds != null && ds.Tables.Count == 1)
                        {
                            ImportDataBuilder.ImportNuclearCoverMetal(ds, strNewImportPath, AppContext.CurrentUser);
                        }
                    }
                }
                jsonResult = JsonResultHelper.JsonResult(true, "导入完成！");
            }
            catch (Exception ce)
            {
                jsonResult = JsonResultHelper.JsonResult(true, "导入失败！" + ce.Message);
            }
            //删除文件
            if (System.IO.File.Exists(strNewImportPath))
            {
                System.IO.File.Delete(strNewImportPath);
            }
            jsonResult.ContentType = "text/html";
            return jsonResult;
        }
        #endregion
    }
}
