﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using NET01.CoreFramework;
using Microsoft.Practices.ServiceLocation;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Areas.WasteTreatment.ViewModels;
using CIT.Common.Common;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Core.Common;
using System.IO;
using NPOI.HSSF.UserModel;

namespace RWIS.Presentation.Web.Areas.WasteTreatment.ViewModelBuilder
{
    public class ImportDataBuilder
    {
        #region 导入封盖数据
        #region 添加数据

        /// <summary>
        /// 创建封盖数据
        /// </summary>
        /// <param name="bucketCoverVM"></param>
        /// <returns></returns>
        public static string InsertCoverMixData(BucketCoverVM bucketCoverVM, INuclearCoverMixRepository nuclearCoverMixRepository)
        {
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            INuclearWastePackageRepository iNuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
            IMaterialTypeRepository iMaterialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
            INuclearTempstockRepository iNuclearTempstockRepository = ServiceLocator.Current.GetInstance<INuclearTempstockRepository>();
            try
            {
                //string guid = wasteTrackingVM.NuclearTrackTechS.TechSId;
                bucketCoverVM.CoverMixModel.MixId = Guid.NewGuid().ToString();
                bucketCoverVM.CoverMixModel.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                bucketCoverVM.CoverMixModel.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                bucketCoverVM.CoverMixModel.CreateDate = DateTime.Now.Date;//创建时间
                bucketCoverVM.CoverMixModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                bucketCoverVM.CoverMixModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                bucketCoverVM.CoverMixModel.ConfirmDate = DateTime.Now;
                bucketCoverVM.CoverMixModel.Stationcode = AppContext.CurrentUser.ProjectCode;
                var modelBucket = iNuclearBucketRepository.GetBucketInfoModel(bucketCoverVM.CoverMixModel.BucketId);
                modelBucket.BucketStatus = "COVER";
                iNuclearBucketRepository.Update(modelBucket);
                if (bucketCoverVM.CoverMixModel.Status == "2")
                {
                    var bucketModel = iNuclearBucketRepository.GetBucketInfoModel(bucketCoverVM.CoverMixModel.BucketId);
                    if (bucketModel != null)
                    {
                        bucketModel.XPosition = bucketCoverVM.CoverMixModel.PositionX;
                        bucketModel.YPosition = bucketCoverVM.CoverMixModel.PositionY;
                        bucketModel.ZPosition = bucketCoverVM.CoverMixModel.PositionZ;
                        iNuclearBucketRepository.Update(bucketModel);
                        //_NuclearBucketRepository.UnitOfWork.Commit();
                    }
                    //string bucketCode = iNuclearBucketRepository.IsExistWasteBucket(bucketCoverVM.CoverMixModel.BucketId, AppContext.CurrentUser.ProjectCode).ToString();
                    NuclearBucket nuclearBucket = iNuclearBucketRepository.Get(bucketCoverVM.CoverMixModel.BucketId);
                    string bucketCode = nuclearBucket.BucketCode;
                    var listBucket = iNuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                    iNuclearBucketRepository.UpdateBucketCoverMethod(bucketCode, AppContext.CurrentUser.ProjectCode, "湿混料制备及封盖", "COVER");
                    string codeExist = iNuclearWastePackageRepository.GetPackageCodebyBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(codeExist))
                    {
                        //string packageCode = iNuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                        //var wasteList = iNuclearWastePackageRepository.GetAll().Where(n => n.BucketId == bucketCoverVM.CoverMixModel.BucketId && n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                        //if (wasteList.Count == 0)
                        //{
                        //    NuclearWastePackage package = new NuclearWastePackage();
                        //    package.PackageId = Guid.NewGuid().ToString();
                        //    package.PackageCode = packageCode;
                        //    package.BucketId = bucketCoverVM.CoverMixModel.BucketId;
                        //    package.XPosition = bucketCoverVM.CoverMixModel.PositionX;
                        //    package.YPosition = bucketCoverVM.CoverMixModel.PositionY;
                        //    package.ZPosition = bucketCoverVM.CoverMixModel.PositionZ;
                        //    package.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        //    package.ConfirmUserName = AppContext.CurrentUser.UserName;
                        //    package.ConfirmDate = DateTime.Now;
                        //    package.Stationcode = AppContext.CurrentUser.ProjectCode;
                        //    var materialModel = iMaterialTypeRepository.GetMaterialModel(listBucket[0].MaterialId);
                        //    if (materialModel != null)
                        //    {
                        //        decimal? mHeight = Convert.ToDecimal(materialModel.Height == null ? 0 : materialModel.Height);
                        //        decimal? mDia = Convert.ToDecimal(materialModel.Diamerter == null ? 0 : materialModel.Diamerter);
                        //        decimal? mPly = 0;
                        //        decimal? mSpace = 0;
                        //        if (bucketCoverVM.CoverMixModel.CurdlePly != null)
                        //            mPly = bucketCoverVM.CoverMixModel.CurdlePly;
                        //        if (!string.IsNullOrEmpty(bucketCoverVM.CoverMixModel.OverSpace))
                        //            mSpace = Convert.ToDecimal(bucketCoverVM.CoverMixModel.OverSpace);
                        //        package.Volumn = Convert.ToDecimal((mDia/100 - mPly/100) * (mDia/100 - mPly/100) * (mHeight/100 - mSpace/100) * Convert.ToDecimal(3.14));
                        //    }
                        //    iNuclearWastePackageRepository.Create(package);
                        //}
                    }
                    else
                    {
                        NuclearWastePackage package = new NuclearWastePackage();
                        package = iNuclearWastePackageRepository.GetAll().Where(n => n.PackageCode == codeExist).FirstOrDefault();
                        package.XPosition = bucketCoverVM.CoverMixModel.PositionX;
                        package.YPosition = bucketCoverVM.CoverMixModel.PositionY;
                        package.ZPosition = bucketCoverVM.CoverMixModel.PositionZ;
                        iNuclearWastePackageRepository.UpdatePackage(codeExist, AppContext.CurrentUser.ProjectCode, package);
                    }
                    iNuclearTempstockRepository.MergeMaterialTmpStock(bucketCode, listBucket[0].LocationId, AppContext.CurrentUser.ProjectCode, 0, 1);
                    //新增电缆信息
                    nuclearCoverMixRepository.Create(bucketCoverVM.CoverMixModel);
                    nuclearCoverMixRepository.UnitOfWork.Commit();  
                }
                return string.Empty;
            }
            catch
            {
                return "保存失败！";
            }
        }

        #endregion 添加数据

        /// <summary>
        /// 导入封盖数据
        /// </summary>
        /// <param name="ds">封盖数据集合</param>
        public static void ImportNuclearCoverMix(DataSet ds, string strNewImportPath, ApplicationUser currentUser)
        {
            INuclearCoverMixRepository iNuclearCoverMixRepository = ServiceLocator.Current.GetInstance<INuclearCoverMixRepository>();
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicWasteUnitRepository iBasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();

            List<ImportNuclearCoverMixErr> nuclearCoverMixErrList = new List<ImportNuclearCoverMixErr>();
            ImportNuclearCoverMixErr nuclearCoverMixErr = null;


            //得到电缆列表信息，并新增"错误描述"列
            DataTable dtElectricCable = ds.Tables[0];
            dtElectricCable.Columns.Add("错误描述", typeof(string));

            for (int i = 0; i < dtElectricCable.Rows.Count; i++)
            {
                nuclearCoverMixErr = new ImportNuclearCoverMixErr();
                DataRow row = dtElectricCable.Rows[i];
                string bucketId = nuclearCoverMixErr.BucketId = CommonFunc.ObjectToNullStr(row["桶号"]).Trim();
                string workTicket = nuclearCoverMixErr.WorkTicket = CommonFunc.ObjectToNullStr(row["工作票号"]).Trim();
                string pondingFlag = nuclearCoverMixErr.PondingFlag = CommonFunc.ObjectToNullStr(row["表面积水"]).Trim();
                string curdleFlag = nuclearCoverMixErr.CurdleFlag = CommonFunc.ObjectToNullStr(row["凝固状态"]).Trim();
                string texture = nuclearCoverMixErr.Texture = CommonFunc.ObjectToNullStr(row["屏蔽材料"]).Trim();
                string curdlePly = Convert.ToString(nuclearCoverMixErr.CurdlePly); curdlePly = CommonFunc.ObjectToNullStr(row["屏蔽厚度"]).Trim();
                string curdleWeight = Convert.ToString(nuclearCoverMixErr.CurdleWeight); curdleWeight = CommonFunc.ObjectToNullStr(row["屏蔽重量"]).Trim();
                string overSpace = nuclearCoverMixErr.OverSpace = CommonFunc.ObjectToNullStr(row["预留封盖空间"]).Trim();
                string cement = Convert.ToString(nuclearCoverMixErr.Cement); cement = CommonFunc.ObjectToNullStr(row["水泥重量"]).Trim();
                string sand = Convert.ToString(nuclearCoverMixErr.Sand); sand = CommonFunc.ObjectToNullStr(row["沙子重量"]).Trim();
                string stone = Convert.ToString(nuclearCoverMixErr.Stone); stone = CommonFunc.ObjectToNullStr(row["石块重量"]).Trim();
                string water = Convert.ToString(nuclearCoverMixErr.Water); water = CommonFunc.ObjectToNullStr(row["加水量"]).Trim();
                string additive = Convert.ToString(nuclearCoverMixErr.Additive); additive = CommonFunc.ObjectToNullStr(row["增塑剂量"]).Trim();
                string shakeTime = Convert.ToString(nuclearCoverMixErr.ShakeTime); shakeTime = CommonFunc.ObjectToNullStr(row["搅拌时间"]).Trim();
                string cementFlag = nuclearCoverMixErr.CementFlag = CommonFunc.ObjectToNullStr(row["水泥是否有效"]).Trim();
                string doseEva = Convert.ToString(nuclearCoverMixErr.DoseEva); doseEva = CommonFunc.ObjectToNullStr(row["封盖后上部平均剂量率"]).Trim();
                string overHeight = Convert.ToString(nuclearCoverMixErr.OverHeight); overHeight = CommonFunc.ObjectToNullStr(row["盖顶高差"]).Trim();

                string positionX = nuclearCoverMixErr.PositionX = CommonFunc.ObjectToNullStr(row["QS位置"]).Trim();

                string controlName = nuclearCoverMixErr.ControlName = CommonFunc.ObjectToNullStr(row["操作员"]).Trim();
                string controlDate = Convert.ToString(nuclearCoverMixErr.ControlDate); controlDate = CommonFunc.ObjectToNullStr(row["操作日期"]).Trim();
                string checkName = nuclearCoverMixErr.CheckName = CommonFunc.ObjectToNullStr(row["检查人"]).Trim();
                string checkDate = Convert.ToString(nuclearCoverMixErr.CheckDate); controlDate = CommonFunc.ObjectToNullStr(row["检查日期"]).Trim();
                string remark = nuclearCoverMixErr.Remark = CommonFunc.ObjectToNullStr(row["备注"]).Trim();
                string stationcode = nuclearCoverMixErr.Stationcode = CommonFunc.ObjectToNullStr(row["封盖电站"]).Trim();
                

                //桶号
                string bucketCode = string.Empty;
                if (!string.IsNullOrEmpty(bucketId))
                {
                    bucketCode = iNuclearBucketRepository.IsExistWasteBucket(bucketId, AppContext.CurrentUser.ProjectCode).ToString();
                    bool bucketCheck = iNuclearBucketRepository.IsExistByCodeAndStation(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        nuclearCoverMixErr.Error += "您填的桶号不存在";
                    }
                    var listBucket = iNuclearBucketRepository.QueryListByCode(bucketId, AppContext.CurrentUser.ProjectCode).ToList();
                    if (listBucket.Count() > 0)
                    {
                        var listCoverMix = iNuclearCoverMixRepository.GetModelByBucketId(listBucket[0].BucketId);
                        if (listCoverMix != null)
                        {
                            nuclearCoverMixErr.Error += "您填的桶号已经封盖";
                        }

                        if (listBucket[0].BucketStatus != "PREPARE" && listBucket[0].BucketStatus != "FILL")
                        {
                            nuclearCoverMixErr.Error += "您填的桶没经过检查或者已经封盖";
                        }
                    }
                }
                //表面积水  
                string pondingFlags = string.Empty;
                if (!string.IsNullOrEmpty(pondingFlag))
                {
                    if (pondingFlag == "N")
                    {
                        pondingFlags = "0";
                    }
                    if (pondingFlag == "Y")
                    {
                        pondingFlags = "1";
                    }
                }
                //凝固状态
                string curdleFlags = string.Empty;
                if (!string.IsNullOrEmpty(curdleFlag))
                {
                    if (curdleFlag == "N")
                    {
                        curdleFlags = "0";
                    }
                    if (curdleFlag == "Y")
                    {
                        curdleFlags = "1";
                    }
                }
                //水泥是否有效
                string cementFlags = string.Empty;
                if (!string.IsNullOrEmpty(curdleFlag))
                {
                    if (curdleFlag == "N")
                    {
                        cementFlags = "0";
                    }
                    else if (curdleFlag == "Y")
                    {
                        cementFlags = "1";
                    }
                    else {
                        cementFlags = null;
                    }
                }
                //判断数据是否正确
                if (CommonFunc.IsNotNullString(nuclearCoverMixErr.Error))
                {
                    nuclearCoverMixErrList.Add(nuclearCoverMixErr);
                    continue;
                }
                else
                {
                    NuclearCoverMix nuclearCoverMix = new NuclearCoverMix();
                    nuclearCoverMix.BucketId = bucketCode;
                    nuclearCoverMix.WorkTicket = workTicket;
                    nuclearCoverMix.PondingFlag = pondingFlags;
                    nuclearCoverMix.CurdleFlag = curdleFlags;
                    nuclearCoverMix.Texture = texture;
                    if (curdlePly != null && curdlePly != "")
                    {
                        nuclearCoverMix.CurdlePly = Convert.ToDecimal(curdlePly);
                    }
                    else
                    {
                        nuclearCoverMix.CurdlePly = null;
                    }
                    if (curdleWeight != null && curdleWeight != "")
                    {
                        nuclearCoverMix.CurdleWeight = Convert.ToDecimal(curdleWeight);
                    }
                    else
                    {
                        nuclearCoverMix.CurdleWeight = null;
                    }
                    nuclearCoverMix.OverSpace = overSpace;
                    if (cement != null && cement != "")
                    {
                        nuclearCoverMix.Cement = Convert.ToDecimal(cement);
                    }
                    else
                    {
                        nuclearCoverMix.Cement = null;
                    }
                    if (sand != null && sand != "")
                    {
                        nuclearCoverMix.Sand = Convert.ToDecimal(sand);
                    }
                    else
                    {
                        nuclearCoverMix.Sand = null;
                    }
                    if (stone != null && stone != "")
                    {
                        nuclearCoverMix.Stone = Convert.ToDecimal(stone);
                    }
                    else
                    {
                        nuclearCoverMix.Stone = null;
                    }
                    if (water != null && water != "")
                    {
                        nuclearCoverMix.Water = Convert.ToDecimal(water);
                    }
                    else
                    {
                        nuclearCoverMix.Water = null;
                    }
                    if (additive != null && additive != "")
                    {
                        nuclearCoverMix.Additive = Convert.ToDecimal(additive);
                    }
                    else
                    {
                        nuclearCoverMix.Additive = null;
                    }
                    if (shakeTime != null && shakeTime != "")
                    {
                        nuclearCoverMix.ShakeTime = Convert.ToDecimal(shakeTime);
                    }
                    else
                    {
                        nuclearCoverMix.ShakeTime = null;
                    }
                    nuclearCoverMix.CementFlag = cementFlags;
                    if (doseEva != null && doseEva != "")
                    {
                        nuclearCoverMix.DoseEva = Convert.ToDecimal(doseEva);
                    }
                    else
                    {
                        nuclearCoverMix.DoseEva = null;
                    }
                    if (overHeight != null && overHeight != "")
                    {
                        nuclearCoverMix.OverHeight = Convert.ToDecimal(overHeight);
                    }
                    else
                    {
                        nuclearCoverMix.OverHeight = null;
                    }
                    if (controlName != null && controlName != "")
                    {
                        nuclearCoverMix.ControlNo = controlName.Substring(1, 7);
                        nuclearCoverMix.ControlName = controlName.Substring(9);
                    }
                    else {
                        nuclearCoverMix.ControlNo = null;
                        nuclearCoverMix.ControlName = null;
                    }
                    if (controlDate != null && controlDate != "")
                    {
                        nuclearCoverMix.ControlDate = Convert.ToDateTime(controlDate);
                    }
                    else
                    {
                        nuclearCoverMix.ControlDate = null;
                    }
                    if (checkName != null && checkName != "")
                    {
                        nuclearCoverMix.CheckNo = checkName.Substring(1, 7);
                        nuclearCoverMix.CheckName = checkName.Substring(9);
                    }
                    else {
                        nuclearCoverMix.CheckNo = null;
                        nuclearCoverMix.CheckName = null;
                    }
                    if (checkDate != null && checkDate != "")
                    {
                        nuclearCoverMix.CheckDate = Convert.ToDateTime(checkDate);
                    }
                    else
                    {
                        nuclearCoverMix.CheckDate = null;
                    }
                    nuclearCoverMix.Remark = remark + "  QS位置："+positionX;
                    //nuclearCoverMix.Stationcode = stationcode;
                    nuclearCoverMix.Status = "2";

                    //添加电缆草稿信息
                    BucketCoverVM vm = new BucketCoverVM();
                    vm.CoverMixModel = nuclearCoverMix;
                    string messge = InsertCoverMixData(vm, iNuclearCoverMixRepository);
                    if (!string.IsNullOrEmpty(messge))
                    {
                        nuclearCoverMixErr.Error += messge;
                        nuclearCoverMixErrList.Add(nuclearCoverMixErr);
                        iNuclearCoverMixRepository.UnitOfWork.RollbackChanges();
                        continue;
                    }
                    //else
                    //{
                    //    //添加电缆信息
                    //    NuclearTrackTechS nuclearTrackTechSData = ImportDataBuilder.TransferFromDraft(nuclearTrackTechSs);
                    //    nuclearTrackTechSData.TechSId = Guid.NewGuid().ToString();
                    //    iNuclearTrackTechSRepository.Create(nuclearTrackTechSData);
                    //    iNuclearTrackTechSRepository.UnitOfWork.Commit();

                    //}

                }
            }

            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);

            #region 错误文档
            if (nuclearCoverMixErrList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (nuclearCoverMixErrList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("封盖数据错误信息");
                    ImportExportHelper.FillSheet<ImportNuclearCoverMixErr>(nuclearCoverMixErrList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<ImportNuclearCoverMixErr>(stream);
            }

            #endregion
        }

        /// <summary>
        /// 检查导入的封盖数据表格列头是否正确
        /// </summary>
        /// <param name="ds">封盖数据数据集</param>
        /// <param name="strNewImportPath">封盖数据数据所在的物理路径</param>
        /// <returns></returns>
        public static string GetImportNuclearCoverMixErr(DataSet ds, string strNewImportPath)
        {
            string errMsg = string.Empty;

            //得到电缆列头信息
            DataTable dtElectricCable = ds.Tables[0];
            string columnNames = ",";
            for (int i = 0; i < dtElectricCable.Columns.Count; i++)
            {
                columnNames += dtElectricCable.Columns[i].ColumnName + ",";
            }
            bool isCorrectStyle = true;
            isCorrectStyle = (columnNames.Contains(",桶号,") && columnNames.Contains(",工作票号,") && columnNames.Contains(",表面积水,") && columnNames.Contains(",凝固状态,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",屏蔽材料,") && columnNames.Contains(",屏蔽厚度,") && columnNames.Contains(",屏蔽重量,") && columnNames.Contains(",预留封盖空间,") && columnNames.Contains(",水泥重量,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",沙子重量,") && columnNames.Contains(",石块重量,") && columnNames.Contains(",加水量,") && columnNames.Contains(",增塑剂量,") && columnNames.Contains(",搅拌时间,") && columnNames.Contains(",水泥是否有效,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",封盖后上部平均剂量率,") && columnNames.Contains(",盖顶高差,") && columnNames.Contains(",QS位置,") && columnNames.Contains(",操作员,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",操作日期,") && columnNames.Contains(",检查人,") && columnNames.Contains(",检查日期,") && columnNames.Contains(",备注,") && columnNames.Contains(",封盖电站,"));
            if (isCorrectStyle == false)
            {
                //删除文件
                if (System.IO.File.Exists(strNewImportPath))
                {
                    System.IO.File.Delete(strNewImportPath);
                }
                errMsg = "封盖数据模板格式有误,请仔细检查列头！";
            }
            return errMsg;
        }

        #endregion 导入封盖数据

        #region 导入超压数据
        #region 添加数据

        /// <summary>
        /// 创建超压数据
        /// </summary>
        /// <param name="bucketCoverVM"></param>
        /// <returns></returns>
        public static string InsertCoverMetalData(BucketCoverVM bucketCoverVM, INuclearCoverMetalRepository nuclearCoverMetalRepository)
        {
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            INuclearWastePackageRepository iNuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
            IMaterialTypeRepository iMaterialTypeRepository = ServiceLocator.Current.GetInstance<IMaterialTypeRepository>();
            INuclearTempstockRepository iNuclearTempstockRepository = ServiceLocator.Current.GetInstance<INuclearTempstockRepository>();
            try
            {
                bucketCoverVM.CoverMetalModel.MetalId = Guid.NewGuid().ToString();
                bucketCoverVM.CoverMetalModel.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                bucketCoverVM.CoverMetalModel.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                bucketCoverVM.CoverMetalModel.CreateDate = DateTime.Now.Date;//创建时间
                bucketCoverVM.CoverMetalModel.ConfirmUserNo = AppContext.CurrentUser.UserId;
                bucketCoverVM.CoverMetalModel.ConfirmUserName = AppContext.CurrentUser.UserName;
                bucketCoverVM.CoverMetalModel.ConfirmDate = DateTime.Now;
                bucketCoverVM.CoverMetalModel.Stationcode = AppContext.CurrentUser.ProjectCode;
                var modelBucket = iNuclearBucketRepository.GetBucketInfoModel(bucketCoverVM.CoverMetalModel.BucketId);
                //modelBucket.BucketStatus = "COVER";
                //iNuclearBucketRepository.Update(modelBucket);
                if (bucketCoverVM.CoverMetalModel.Status == "2")
                {
                    var bucketModel = iNuclearBucketRepository.GetBucketInfoModel(bucketCoverVM.CoverMetalModel.BucketId);
                    if (bucketModel != null)
                    {
                        bucketModel.XPosition = bucketCoverVM.CoverMetalModel.PositionX;
                        bucketModel.YPosition = bucketCoverVM.CoverMetalModel.PositionY;
                        bucketModel.ZPosition = bucketCoverVM.CoverMetalModel.PositionZ;
                        iNuclearBucketRepository.Update(bucketModel);
                        //_NuclearBucketRepository.UnitOfWork.Commit();
                    }
                    //string bucketCode = iNuclearBucketRepository.IsExistWasteBucket(bucketCoverVM.CoverMixModel.BucketId, AppContext.CurrentUser.ProjectCode).ToString();
                    NuclearBucket nuclearBucket = iNuclearBucketRepository.Get(bucketCoverVM.CoverMetalModel.BucketId);
                    string bucketCode = nuclearBucket.BucketCode;
                    var listBucket = iNuclearBucketRepository.QueryListByCode(bucketCode, AppContext.CurrentUser.ProjectCode).ToList();
                    iNuclearBucketRepository.UpdateBucketCoverMethod(bucketCode, AppContext.CurrentUser.ProjectCode, "湿混料制备及400L金属桶装桶封盖", "COVER");
                    string codeExist = iNuclearWastePackageRepository.GetPackageCodebyBucketCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                    if (string.IsNullOrEmpty(codeExist))
                    {
                        //string packageCode = iNuclearWastePackageRepository.BuildPackageCode(bucketCode, AppContext.CurrentUser.ProjectCode);
                        //var wasteList = iNuclearWastePackageRepository.GetAll().Where(n => n.BucketId == bucketCoverVM.CoverMetalModel.BucketId && n.Stationcode == AppContext.CurrentUser.ProjectCode).ToList();
                        //if (wasteList.Count == 0)
                        //{
                        //    NuclearWastePackage package = new NuclearWastePackage();
                        //    package.PackageId = Guid.NewGuid().ToString();
                        //    package.PackageCode = packageCode;
                        //    package.BucketId = bucketCoverVM.CoverMetalModel.BucketId;
                        //    package.XPosition = bucketCoverVM.CoverMetalModel.PositionX;
                        //    package.YPosition = bucketCoverVM.CoverMetalModel.PositionY;
                        //    package.ZPosition = bucketCoverVM.CoverMetalModel.PositionZ;
                        //    package.ConfirmUserNo = AppContext.CurrentUser.UserId;
                        //    package.ConfirmUserName = AppContext.CurrentUser.UserName;
                        //    package.ConfirmDate = DateTime.Now;
                        //    package.Stationcode = AppContext.CurrentUser.ProjectCode;
                        //    var materialModel = iMaterialTypeRepository.GetMaterialModel(listBucket[0].MaterialId);
                        //    if (materialModel != null)
                        //    {
                        //        double? mHeight = materialModel.Height == null ? 0 : materialModel.Height;
                        //        double? mDia = materialModel.Diamerter == null ? 0 : materialModel.Diamerter;
                        //        package.Volumn = Convert.ToDecimal(mDia/100 * mDia/100 * mHeight/100 * 3.14);
                        //    }
                        //    iNuclearWastePackageRepository.Create(package);
                        //}
                    }
                    else
                    {
                        NuclearWastePackage package = new NuclearWastePackage();
                        package = iNuclearWastePackageRepository.GetAll().Where(n => n.PackageCode == codeExist).FirstOrDefault();
                        package.XPosition = bucketCoverVM.CoverMetalModel.PositionX;
                        package.YPosition = bucketCoverVM.CoverMetalModel.PositionY;
                        package.ZPosition = bucketCoverVM.CoverMetalModel.PositionZ;
                        iNuclearWastePackageRepository.UpdatePackage(codeExist, AppContext.CurrentUser.ProjectCode, package);
                    }
                    iNuclearTempstockRepository.MergeMaterialTmpStock(bucketCode, listBucket[0].LocationId, AppContext.CurrentUser.ProjectCode, -1, 1);
                    //新增电缆信息
                    nuclearCoverMetalRepository.Create(bucketCoverVM.CoverMetalModel);
                    nuclearCoverMetalRepository.UnitOfWork.Commit();
                }
                return string.Empty;
            }
            catch
            {
                return "保存失败！";
            }
        }

        #endregion 添加数据

        /// <summary>
        /// 导入封盖数据
        /// </summary>
        /// <param name="ds">封盖数据集合</param>
        public static void ImportNuclearCoverMetal(DataSet ds, string strNewImportPath, ApplicationUser currentUser)
        {
            INuclearCoverMetalRepository iNuclearCoverMetalRepository = ServiceLocator.Current.GetInstance<INuclearCoverMetalRepository>();
            IBasicObjectRepository iBasicObjectRepository = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            INuclearBucketRepository iNuclearBucketRepository = ServiceLocator.Current.GetInstance<INuclearBucketRepository>();
            IBasicWasteUnitRepository iBasicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();

            List<ImportNuclearCoverMetalErr> nuclearCoverMetalErrList = new List<ImportNuclearCoverMetalErr>();
            ImportNuclearCoverMetalErr nuclearCoverMetalErr = null;


            //得到电缆列表信息，并新增"错误描述"列
            DataTable dtElectricCable = ds.Tables[0];
            dtElectricCable.Columns.Add("错误描述", typeof(string));

            for (int i = 0; i < dtElectricCable.Rows.Count; i++)
            {
 
                nuclearCoverMetalErr = new ImportNuclearCoverMetalErr();
                DataRow row = dtElectricCable.Rows[i];
                string bucketId = nuclearCoverMetalErr.BucketId = CommonFunc.ObjectToNullStr(row["桶号"]).Trim();
                string workTicket = nuclearCoverMetalErr.WorkTicket = CommonFunc.ObjectToNullStr(row["工作票号"]).Trim();
                string bucketHight = nuclearCoverMetalErr.BucketHight = CommonFunc.ObjectToNullStr(row["桶体高度"]).Trim();
                string bucketUseFlag = nuclearCoverMetalErr.BucketUseFlag = CommonFunc.ObjectToNullStr(row["桶体是否可用"]).Trim();
                string bucketCheckName = nuclearCoverMetalErr.BucketCheckName = CommonFunc.ObjectToNullStr(row["桶体检查人"]).Trim();
                string bucketCheckDate = Convert.ToString(nuclearCoverMetalErr.BucketCheckDate); bucketCheckDate = CommonFunc.ObjectToNullStr(row["桶体检查日期"]).Trim();
                string wasteSource = nuclearCoverMetalErr.WasteSource = CommonFunc.ObjectToNullStr(row["废物来源"]).Trim();
                string cement = Convert.ToString(nuclearCoverMetalErr.Cement); cement = CommonFunc.ObjectToNullStr(row["水泥重量"]).Trim();
                string sand = Convert.ToString(nuclearCoverMetalErr.Sand); sand = CommonFunc.ObjectToNullStr(row["沙子重量"]).Trim();
                string stone = Convert.ToString(nuclearCoverMetalErr.Stone); stone = CommonFunc.ObjectToNullStr(row["石块重量"]).Trim();
                string water = Convert.ToString(nuclearCoverMetalErr.Water); water = CommonFunc.ObjectToNullStr(row["加水量"]).Trim();
                string additive = Convert.ToString(nuclearCoverMetalErr.Additive); additive = CommonFunc.ObjectToNullStr(row["增塑剂量"]).Trim();
                string shakeTime = Convert.ToString(nuclearCoverMetalErr.ShakeTime); shakeTime = CommonFunc.ObjectToNullStr(row["搅拌时间"]).Trim();
                string doseEva = Convert.ToString(nuclearCoverMetalErr.DoseEva); doseEva = CommonFunc.ObjectToNullStr(row["平均接触剂量率"]).Trim();
                string doseMax = Convert.ToString(nuclearCoverMetalErr.DoseMax); doseMax = CommonFunc.ObjectToNullStr(row["最大接触剂量率"]).Trim();
                string savePosition = nuclearCoverMetalErr.SavePosition = CommonFunc.ObjectToNullStr(row["QS厂房存储位置"]).Trim();        
                string controlSName = nuclearCoverMetalErr.ControlSName = CommonFunc.ObjectToNullStr(row["操作员"]).Trim();
                string controlSDate = Convert.ToString(nuclearCoverMetalErr.ControlSDate); controlSDate = CommonFunc.ObjectToNullStr(row["操作日期"]).Trim();
                string checkSName = nuclearCoverMetalErr.CheckSName = CommonFunc.ObjectToNullStr(row["检查人"]).Trim();
                string checkSDate = Convert.ToString(nuclearCoverMetalErr.CheckSDate); checkSDate = CommonFunc.ObjectToNullStr(row["检查日期"]).Trim();
                string remark = nuclearCoverMetalErr.Remark = CommonFunc.ObjectToNullStr(row["备注"]).Trim();
                string stationcode = nuclearCoverMetalErr.Stationcode = CommonFunc.ObjectToNullStr(row["封盖电站"]).Trim();


                //桶号
                string bucketCode = string.Empty;
                if (!string.IsNullOrEmpty(bucketId))
                {
                    bucketCode = iNuclearBucketRepository.IsExistWasteBucket(bucketId, AppContext.CurrentUser.ProjectCode).ToString();
                    bool bucketCheck = iNuclearBucketRepository.IsExistByCodeAndStation(bucketId, AppContext.CurrentUser.ProjectCode);
                    if (!bucketCheck)
                    {
                        nuclearCoverMetalErr.Error += "您填的桶号不存在";
                    }
                    var listBucket = iNuclearBucketRepository.QueryListByCode(bucketId, AppContext.CurrentUser.ProjectCode).ToList();
                    if (listBucket.Count() > 0)
                    {
                        var listCoverMix = iNuclearCoverMetalRepository.GetModelByBucketId(listBucket[0].BucketId);
                        if (listCoverMix != null)
                        {
                            nuclearCoverMetalErr.Error += "您填的桶号已经封盖";
                        }

                        if (listBucket[0].BucketStatus != "PREPARE" && listBucket[0].BucketStatus != "FILL")
                        {
                            nuclearCoverMetalErr.Error += "您填的桶没经过检查或者已经封盖";
                        }
                    }
                }
                
               
                //判断数据是否正确
                if (CommonFunc.IsNotNullString(nuclearCoverMetalErr.Error))
                {
                    nuclearCoverMetalErrList.Add(nuclearCoverMetalErr);
                    continue;
                }
                else
                {
                    NuclearCoverMetal nuclearCoverMetal = new NuclearCoverMetal();
                    nuclearCoverMetal.BucketId = bucketCode;
                    nuclearCoverMetal.WorkTicket = workTicket;
                    
                    if (cement != null && cement != "")
                    {
                        nuclearCoverMetal.Cement = Convert.ToDecimal(cement);
                    }
                    else
                    {
                        nuclearCoverMetal.Cement = null;
                    }
                    if (sand != null && sand != "")
                    {
                        nuclearCoverMetal.Sand = Convert.ToDecimal(sand);
                    }
                    else
                    {
                        nuclearCoverMetal.Sand = null;
                    }
                    if (stone != null && stone != "")
                    {
                        nuclearCoverMetal.Stone = Convert.ToDecimal(stone);
                    }
                    else
                    {
                        nuclearCoverMetal.Stone = null;
                    }
                    if (water != null && water != "")
                    {
                        nuclearCoverMetal.Water = Convert.ToDecimal(water);
                    }
                    else
                    {
                        nuclearCoverMetal.Water = null;
                    }
                    if (additive != null && additive != "")
                    {
                        nuclearCoverMetal.Additive = Convert.ToDecimal(additive);
                    }
                    else
                    {
                        nuclearCoverMetal.Additive = null;
                    }
                    if (shakeTime != null && shakeTime != "")
                    {
                        nuclearCoverMetal.ShakeTime = Convert.ToDecimal(shakeTime);
                    }
                    else
                    {
                        nuclearCoverMetal.ShakeTime = null;
                    }
                    
                    if (doseEva != null && doseEva != "")
                    {
                        nuclearCoverMetal.DoseEva = Convert.ToDecimal(doseEva);
                    }
                    else
                    {
                        nuclearCoverMetal.DoseEva = null;
                    }
                    if (doseMax != null && doseMax != "")
                    {
                        nuclearCoverMetal.DoseMax = Convert.ToDecimal(doseMax);
                    }
                    else
                    {
                        nuclearCoverMetal.DoseMax = null;
                    }
                    if (controlSName != null && controlSName != "")
                    {
                        nuclearCoverMetal.ControlSNo = controlSName.Substring(1, 7);
                        nuclearCoverMetal.ControlSName = controlSName.Substring(9);
                    }
                    else
                    {
                        nuclearCoverMetal.ControlSNo = null;
                        nuclearCoverMetal.ControlSName = null;
                    }
                    if (controlSDate != null && controlSDate != "")
                    {
                        nuclearCoverMetal.ControlSDate = Convert.ToDateTime(controlSDate);
                    }
                    else
                    {
                        nuclearCoverMetal.ControlSDate = null;
                    }
                    if (checkSName != null && checkSName != "")
                    {
                        nuclearCoverMetal.CheckSNo = checkSName.Substring(1, 7);
                        nuclearCoverMetal.CheckSName = checkSName.Substring(9);
                    }
                    else
                    {
                        nuclearCoverMetal.CheckSNo = null;
                        nuclearCoverMetal.CheckSName = null;
                    }
                    if (checkSDate != null && checkSDate != "")
                    {
                        nuclearCoverMetal.CheckSDate = Convert.ToDateTime(checkSDate);
                    }
                    else
                    {
                        nuclearCoverMetal.CheckSDate = null;
                    }
                    nuclearCoverMetal.Remark = remark;
                    nuclearCoverMetal.Status = "2";

                    //添加电缆草稿信息
                    BucketCoverVM vm = new BucketCoverVM();
                    vm.CoverMetalModel = nuclearCoverMetal;
                    string messge = InsertCoverMetalData(vm, iNuclearCoverMetalRepository);
                    if (!string.IsNullOrEmpty(messge))
                    {
                        nuclearCoverMetalErr.Error += messge;
                        nuclearCoverMetalErrList.Add(nuclearCoverMetalErr);
                        iNuclearCoverMetalRepository.UnitOfWork.RollbackChanges();
                        continue;
                    }
                    //else
                    //{
                    //    //添加电缆信息
                    //    NuclearTrackTechS nuclearTrackTechSData = ImportDataBuilder.TransferFromDraft(nuclearTrackTechSs);
                    //    nuclearTrackTechSData.TechSId = Guid.NewGuid().ToString();
                    //    iNuclearTrackTechSRepository.Create(nuclearTrackTechSData);
                    //    iNuclearTrackTechSRepository.UnitOfWork.Commit();

                    //}

                }
                
            }

            //导出错误信息
            UploadHelper.DeleteFile(strNewImportPath);

            #region 错误文档
            if (nuclearCoverMetalErrList.Count() > 0)
            {
                MemoryStream stream = new MemoryStream();
                HSSFWorkbook workBook = new HSSFWorkbook();
                if (nuclearCoverMetalErrList.Count() > 0)
                {
                    HSSFSheet sheet1 = (HSSFSheet)workBook.CreateSheet("超压数据错误信息");
                    ImportExportHelper.FillSheet<ImportNuclearCoverMetalErr>(nuclearCoverMetalErrList, workBook, sheet1);
                }
                workBook.Write(stream);
                ImportExportHelper.Export<ImportNuclearCoverMetalErr>(stream);
            }

            #endregion
        }

        /// <summary>
        /// 检查导入的封盖数据表格列头是否正确
        /// </summary>
        /// <param name="ds">封盖数据数据集</param>
        /// <param name="strNewImportPath">封盖数据数据所在的物理路径</param>
        /// <returns></returns>
        public static string GetImportNuclearCoverMetalErr(DataSet ds, string strNewImportPath)
        {
            string errMsg = string.Empty;

            //得到电缆列头信息
            DataTable dtElectricCable = ds.Tables[0];
            string columnNames = ",";
            for (int i = 0; i < dtElectricCable.Columns.Count; i++)
            {
                columnNames += dtElectricCable.Columns[i].ColumnName + ",";
            }
            bool isCorrectStyle = true;
            isCorrectStyle = (columnNames.Contains(",桶号,") && columnNames.Contains(",工作票号,") && columnNames.Contains(",桶体高度,") && columnNames.Contains(",桶体是否可用,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",桶体检查人,") && columnNames.Contains(",桶体检查日期,") && columnNames.Contains(",废物来源,") && columnNames.Contains(",水泥重量,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",沙子重量,") && columnNames.Contains(",石块重量,") && columnNames.Contains(",加水量,") && columnNames.Contains(",增塑剂量,") && columnNames.Contains(",搅拌时间,") && columnNames.Contains(",平均接触剂量率,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",最大接触剂量率,") && columnNames.Contains(",QS厂房存储位置,") && columnNames.Contains(",操作员,"));
            isCorrectStyle = isCorrectStyle && (columnNames.Contains(",操作日期,") && columnNames.Contains(",检查人,") && columnNames.Contains(",检查日期,") && columnNames.Contains(",备注,") && columnNames.Contains(",封盖电站,"));
            if (isCorrectStyle == false)
            {
                //删除文件
                if (System.IO.File.Exists(strNewImportPath))
                {
                    System.IO.File.Delete(strNewImportPath);
                }
                errMsg = "超压数据模板格式有误,请仔细检查列头！";
            }
            return errMsg;
        }

        #endregion 导入封盖数据

    }
}