﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.QueryStatistic.ViemModelBuilder
{
    public class WasteStatisticVM
    {
        /// <summary>
        /// 废物包接收总活度
        /// </summary>
        public Nullable<decimal> TotalActivity { get; set; }
        /// <summary>
        /// 废物货包总体积
        /// </summary>
        public Nullable<double> TotalVolumn { get; set; }
        /// <summary>
        /// 接收废物包数量
        /// </summary>
        public int TotalCount { get; set; }
        /// <summary>
        /// 材料规格
        /// </summary>
        public List<string> PackcodeList { get; set; }
        /// <summary>
        /// 包装类型list
        /// </summary>
        public List<MaterialSpec> MaterialSpecList { get; set; }
        // <summary>
        /// 废物类型list
        /// </summary>
        public List<string> listWaste { get; set; }
        /// 废物类型list
        /// </summary>
        public List<WasteType> WasteTypeList { get; set; }
        /// 统计废物类型list
        /// </summary>
        public List<SumWasteType> SumWasteTypeList { get; set; }

        /// <summary>
        /// 非标准包装list
        /// </summary>
        public List<SumWasteType> SumNoStandardPackList { get; set; }
        /// <summary>
        /// 非标准包装材料list
        /// </summary>
        public List<MaterialTypeName> MaterialTypeNameList { get; set; }

        /// <summary>
        /// 各个电站废物包list
        /// </summary>
        public List<PackageBasicWasteUnit> BasicWasteUnitList { get; set; }
     
    }
    /// <summary>
    /// 桶类型及材料信息
    /// </summary>
    public class MaterialSpec
    {
        /// <summary>
        /// 桶规格主键
        /// </summary>
        public string MaterialSpecID { get; set; }
        /// <summary>
        /// 桶规格名称
        /// </summary>
        public string MaterialSpecName { get; set; }
       
    }
    /// <summary>
    /// 废物类型
    /// </summary>
    public class WasteType
    {
        /// <summary>
        /// 废物主键
        /// </summary>
        public string WasteTypeID { get; set; }
        /// <summary>
        /// 废物类型名称
        /// </summary>
        public string WasteTypeName { get; set; }

    }
    /// <summary>
    /// 非标准包装材料
    /// </summary>
    public class MaterialTypeName
    {
        /// <summary>
        /// 非标准包装材料主键
        /// </summary>
        public string MaterialNameID { get; set; }
        /// <summary>
        ///非标准包装材料名称
        /// </summary>
        public string MaterialName { get; set; }

    }
    /// <summary>
    /// 统计废物类型
    /// </summary>
    public class SumWasteType
    {
        /// <summary>
        /// 废物包接收总活度
        /// </summary>
        public Nullable<decimal> ActivityWasteType { get; set; }
        /// <summary>
        /// 废物货包总体积
        /// </summary>
        public Nullable<double> VolumnWasteType { get; set; }
        /// <summary>
        /// 接收废物包数量
        /// </summary>
        public int CountByWasteType { get; set; }

    }

    /// <summary>
    /// 各电站废物包统计
    /// </summary>
    public class PackageBasicWasteUnit
    {
        /// <summary>
        /// 单位名称
        /// </summary>
        public string UnitName { get; set; }
        /// <summary>
        /// 简码
        /// </summary>
        public string SimpleCode { get; set; }
        /// <summary>
        /// 接收废物包数量
        /// </summary>
        public int WastePackageCount { get; set; }

    }
}