﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.QueryStatistic.ViemModelBuilder
{
    public class IntegratedQueryCondition
    {
        /// <summary>
        /// 桶编号
        /// </summary>
        public string BucketCode { get; set; }

        /// <summary>
        /// 审查状态 
        /// </summary>
        public string ApproveStatus { get; set; }
        public List<SelectListItem> ApproveStatusList { get; set; }

        /// <summary>
        /// 处置场
        /// </summary>
        public string DispitePosition { get; set; }
        public List<SelectListItem> DispitePositionList { get; set; }

        /// <summary>
        /// 废物类型 
        /// </summary>
        public string WasteType { get; set; }
        public List<SelectListItem> WasteTypeList { get; set; }

        /// <summary>
        /// 总活度
        /// </summary>
        public Nullable<decimal> TotalActivityFrom { get; set; }

        /// <summary>
        /// 总活度
        /// </summary>
        public Nullable<decimal> TotalActivityTo { get; set; }

        /// <summary>
        /// 废物货包编码
        /// </summary>
        public string PackageCode { get; set; }

        /// <summary>
        /// 运输状态
        /// </summary>
        public string TransportStatus { get; set; }
        public List<SelectListItem> TransportStatusList { get; set; }

        /// <summary>
        /// 单元名称 
        /// </summary>
        public string UnitId { get; set; }
        public string UnitName { get; set; }
        public List<SelectListItem> UnitNameList { get; set; }

        /// <summary>
        /// 表面接触剂量率信息 
        /// </summary>
        public Nullable<decimal> DoseSurfaceFrom { get; set; }

        /// <summary>
        /// 表面接触剂量率信息 
        /// </summary>
        public Nullable<decimal> DoseSurfaceTo { get; set; }

        /// <summary>
        /// 处置认定书编号     
        /// </summary>
        public string OrderCode { get; set; }

        /// <summary>
        /// 电站 
        /// </summary>
        public string StationCode { get; set; }
        public List<SelectListItem> StationCodeList { get; set; }

        /// <summary>
        /// 接收状态
        /// </summary>
        public string ReceptionStatus { get; set; }
        public List<SelectListItem> ReceptionStatusList { get; set; }

        /// <summary>
        /// 废物货包类型 
        /// </summary>
        public string PackageType { get; set; }
        public List<SelectListItem> PackageTypeList { get; set; }

        /// <summary>
        /// 1m远剂量率
        /// </summary>
        public Nullable<decimal> DoseMeterFrom { get; set; }

        /// <summary>
        /// 1m远剂量率
        /// </summary>
        public Nullable<decimal> DoseMeterTo { get; set; }
    }
}