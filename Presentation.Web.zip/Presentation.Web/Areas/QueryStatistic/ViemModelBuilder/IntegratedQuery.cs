﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.QueryStatistic.ViemModelBuilder
{
    public class IntegratedQuery
    {
        public string PackageId { get; set; }

        public string BucketCode { get; set; }

        public string PackageCode { get; set; }

        public Nullable<decimal> Weight { get; set; }

        public string MaterialName { get; set; }

        public Nullable<decimal> Volumn { get; set; }

        public Nullable<decimal> TotalActivity { get; set; }

        public string DealMethod { get; set; }

        public Nullable<decimal> DoseSurface { get; set; }

        public string CheckResult { get; set; }

        public string Location { get; set; }

        public string ApproveStatus { get; set; }


        public string DispitePosition { get; set; }

        public string WasteType { get; set; }

        public string TransportStatus { get; set; }

        public string UnitName { get; set; }

        public string OrderCode { get; set; }

        public string StationCode { get; set; }

        public string ReceptionStatus { get; set; }

        public string PackageType { get; set; }

        public Nullable<decimal> DoseMeter { get; set; }
    }
}