﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using Microsoft.Practices.ServiceLocation;
using RWIS.Infrastructure.Data.Repositories;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Areas.QueryStatistic.ViewModels;
namespace RWIS.Presentation.Web.Areas.QueryStatistic.ViemModelBuilder
{
    public class ActivityReportBuilder
    {
        /// <summary>
        /// 得到放射性特性评估验算的所有核素信息
        /// </summary>
        /// <returns></returns>
        public static IQueryable<ActivityReportVM> GetActivityReport(ActivityReportCondition condition)
        {
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();

            //处置申请仓储
            INuclearProcessApplyRepository nuclearProcessApplyRepository = ServiceLocator.Current.GetInstance<INuclearProcessApplyRepository>();
            IQueryable<NuclearProcessApply> iqueryNuclearProcessApply = nuclearProcessApplyRepository.GetAll().AsQueryable().Where(c => c.Stationcode.ToUpper().Trim() == stationCode);

            //废物货包仓储
            INuclearWastePackageRepository nuclearWastePackageRepository = ServiceLocator.Current.GetInstance<INuclearWastePackageRepository>();
            IQueryable<NuclearWastePackage> iqueryNuclearWastePackage = nuclearWastePackageRepository.GetAll().AsQueryable().Where(c=>c.Stationcode.ToUpper().Trim() == stationCode);

            //废物货包审核仓储
            IDispsiteCheckRepository dispsiteCheckRepository = ServiceLocator.Current.GetInstance<IDispsiteCheckRepository>();
            IQueryable<DispsiteCheck> iqueryDispsiteCheck = dispsiteCheckRepository.GetAll().AsQueryable();

            //废物货包明细审核仓储
            IDispsiteCheckDetailRepository dispsiteCheckDetailRepository = ServiceLocator.Current.GetInstance<IDispsiteCheckDetailRepository>();
            IQueryable<DispsiteCheckDetail> iqueryDispsiteCheckDetail = dispsiteCheckDetailRepository.GetAll().AsQueryable();

            //放射性验算评估仓储
            IDispsiteEvalRepository dispsiteEvalRepository = ServiceLocator.Current.GetInstance<IDispsiteEvalRepository>();
            IQueryable<DispsiteEval> iqueryDispsiteEval = dispsiteEvalRepository.GetAll().AsQueryable().Where(c => c.StationCode.ToUpper().Trim() == stationCode);
            
            //放射性验算评估明细仓储
            IDispsiteEvalDetailRepository dispsiteEvalDetailRepository = ServiceLocator.Current.GetInstance<IDispsiteEvalDetailRepository>();
            IQueryable<DispiteEvalDetail> iqueryDispiteEvalDetail = dispsiteEvalDetailRepository.GetAll().AsQueryable().Where(c => c.StationCode.ToUpper().Trim() == stationCode);

            //废物货包定位信息
            INuclearRubLocationRepository nuclearRubLocationRepository = ServiceLocator.Current.GetInstance<INuclearRubLocationRepository>();
            IQueryable<NuclearRubLocation> iqueryNuclearRubLocation = nuclearRubLocationRepository.GetAll().AsQueryable().Where(c=>c.Stationcode.ToUpper().Trim()==stationCode);

            //核素信息
            INuclearElementRepository nuclearElementRepository = ServiceLocator.Current.GetInstance<INuclearElementRepository>();
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable().Where(c => c.ElementType.ToUpper().Trim() == "LICENCE" && c.ElementName != "α>5 A" && c.Status == "1");
            
            //联合查询
            var query = from d in iqueryDispiteEvalDetail
                        join e in iqueryDispsiteEval on d.EvalId equals e.EvalId into eEmpt
                        from e in eEmpt.DefaultIfEmpty()
                        join cd in iqueryDispsiteCheckDetail on e.CheckDetailId equals cd.DetailId into cdEmpt
                        from cd in cdEmpt.DefaultIfEmpty()
                        join c in iqueryDispsiteCheck on cd.CheckId equals c.CheckId into cEmpt
                        from c in cEmpt.DefaultIfEmpty()
                        join p in iqueryNuclearProcessApply on c.ProcessApplyId equals p.ProcessApplyId into pEmpt
                        from p in pEmpt.DefaultIfEmpty()
                        join wp in iqueryNuclearWastePackage on e.BucketId equals wp.BucketId into wpEmpt
                        from wp in wpEmpt.DefaultIfEmpty()
                        join r in iqueryNuclearRubLocation on wp.PackageId equals r.PackageId into rEmpt
                        from r in rEmpt.DefaultIfEmpty()
                        join n in iqueryNuclearElement on d.ElementId equals n.ElementId 
                        select new ActivityReportVM
                        {
                            DispsiteEval = e,
                            ElementId = d.ElementId,
                            ElementName = n.ElementName,
                            OriginalWasteActivity = d.OriginalWasteActivity,
                            DispSitePositonId = p.StoragePositionId,
                            DispSiteUnitId = r.LocationId,
                            HalfLife=n.HalfLife
                        };

            if (!string.IsNullOrEmpty(condition.DispSitePositonId))
            {
                query = query.Where(c => c.DispSitePositonId == condition.DispSitePositonId);
            }
            if (!string.IsNullOrEmpty(condition.DispSiteUnitId))
            {
                query = query.Where(c => c.DispSitePositonId == condition.DispSiteUnitId);
            }
            return query;
        }
    }
}