﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using Microsoft.Practices.ServiceLocation;
using RWIS.Infrastructure.Data.Repositories;
using NET01.CoreFramework;

namespace RWIS.Presentation.Web.Areas.QueryStatistic.ViemModelBuilder
{
    public class IntegratedQueryBuilder
    {
        public static IQueryable<IntegratedQueryView> BuilderIntegratedQuery(IntegratedQueryCondition integratedQueryCondition)
        {

            IIntegratedQueryViewRepository iIntegratedQueryViewRepository = ServiceLocator.Current.GetInstance<IIntegratedQueryViewRepository>();
            IQueryable<IntegratedQueryView> nuclearWastePackage = iIntegratedQueryViewRepository.GetAll().AsQueryable();

            var query = nuclearWastePackage;
            //桶号
            if (!string.IsNullOrEmpty(integratedQueryCondition.BucketCode))
            {
                query = query.Where(c => c.BucketCode.Trim().ToUpper().Contains(integratedQueryCondition.BucketCode.Trim().ToUpper()));
            }

            //废物货包号
            if (!string.IsNullOrEmpty(integratedQueryCondition.PackageCode))
            {
                query = query.Where(c => c.PackageCode.Trim().ToUpper().Contains(integratedQueryCondition.PackageCode.Trim().ToUpper()));
            }

            //审查状态
            if (integratedQueryCondition.ApproveStatus != "-1" && (integratedQueryCondition.ApproveStatus.ToUpper() == "UNCHECKED" || integratedQueryCondition.ApproveStatus.ToUpper() == "CHECKED"))
            {
                query = query.Where(c => c.ApproveStatus.Trim().ToUpper() == integratedQueryCondition.ApproveStatus.Trim().ToUpper());
            }
            else if (integratedQueryCondition.ApproveStatus.ToUpper() == "APPLIED")
            {
                query = query.Where(c => !string.IsNullOrEmpty(c.ApproveStatus) && c.ApproveStatus.ToUpper() != "UNCHECKED" && c.ApproveStatus.ToUpper() != "CHECKED");
            }

            //废物类项
            if (!string.IsNullOrEmpty(integratedQueryCondition.WasteType))
            {
                query = query.Where(c => c.WasteType.Trim().ToUpper() == integratedQueryCondition.WasteType.Trim().ToUpper());
            }

            //总活度
            if (integratedQueryCondition.TotalActivityFrom!=null)
            {

                query = query.Where(c => Convert.ToDecimal(c.TotalActivity) >=  integratedQueryCondition.TotalActivityFrom);
            }

            if (integratedQueryCondition.TotalActivityTo != null)
            {
                query = query.Where(c =>  Convert.ToDecimal(c.TotalActivity) < integratedQueryCondition.TotalActivityTo);
            }

            //运输状态
            if (!string.IsNullOrEmpty(integratedQueryCondition.TransportStatus))
            {
                query = query.Where(c => c.TransportStatus.Trim().ToUpper() == integratedQueryCondition.TransportStatus.Trim().ToUpper());
            }

            //单元名称
            if (!string.IsNullOrEmpty(integratedQueryCondition.UnitId))
            {
                query = query.Where(c => c.UnitId.Trim().ToUpper() == integratedQueryCondition.UnitId.Trim().ToUpper());
            }

            //表面接触剂量率
            if (integratedQueryCondition.DoseSurfaceFrom != null)
            {
                query = query.Where(c => c.DoseSurface >= integratedQueryCondition.DoseSurfaceFrom);
            }

            if (integratedQueryCondition.DoseSurfaceTo != null)
            {
                query = query.Where(c => c.DoseSurface < integratedQueryCondition.DoseSurfaceTo);
            }

            //认证书编号
            if (!string.IsNullOrEmpty(integratedQueryCondition.OrderCode))
            {
                query = query.Where(c => c.OrderCode.Trim().ToUpper().Contains(integratedQueryCondition.OrderCode.Trim().ToUpper()));
            }

            //电站编号
            if (!string.IsNullOrEmpty(integratedQueryCondition.StationCode))
            {
                query = query.Where(c => c.StationCode.Trim().ToUpper() == integratedQueryCondition.StationCode.Trim().ToUpper());
            }

            //接收状态
            if (!string.IsNullOrEmpty(integratedQueryCondition.ReceptionStatus))
            {
                query = query.Where(c => c.ReceptionStatus.Trim().ToUpper() == integratedQueryCondition.ReceptionStatus.Trim().ToUpper());
            }

            //废物货包类项
            if (!string.IsNullOrEmpty(integratedQueryCondition.PackageType))
            {
                query = query.Where(c => c.PackageType.Trim().ToUpper() == integratedQueryCondition.PackageType.Trim().ToUpper());
            }
            //1米远剂量率
            if (integratedQueryCondition.DoseMeterFrom != null)
            {
                query = query.Where(c => c.DoseMeter >= integratedQueryCondition.DoseMeterFrom);
            }

            if (integratedQueryCondition.DoseSurfaceTo != null)
            {
                query = query.Where(c => c.DoseMeter < integratedQueryCondition.DoseMeterTo);
            }
            string projectCode=AppContext.CurrentUser.ProjectCode;
            query = query.Where(c => c.ProjectCode.ToUpper().Trim() == projectCode.ToUpper());
            return query;
        }
    }
}