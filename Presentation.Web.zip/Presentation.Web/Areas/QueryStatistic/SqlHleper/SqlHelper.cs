﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using RWIS.Domain.DomainObjects;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;

namespace RWIS.Presentation.Web.Areas.QueryStatistic.SqlHleper
{
    public class SqlHelper
    {
        static string connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        private string _connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        private string _EcpconnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["EcpConnectionString"].ConnectionString;
       /// <summary>
       /// sqlServer
       /// </summary>
       /// <returns></returns>
        public static IQueryable<WasteStatistic> ReaderList()
        {
            List<WasteStatistic> list = new List<WasteStatistic>();
            using (SqlConnection conn = new SqlConnection(connStr))
            {//连接后能自动的释放资源
                conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {

                    cmd.CommandText ="select count(rd.package_id) packageCount,"+
                                    "sum(e.total_activity) as totalActivity,"+
                                    "sum(m.diamerter / 2 * m.diamerter / 2 * m.height) as totalVolumn"+
                                      "from RWIS_NUCLEAR_RUB_RECEPTION_D RD"+
                                     "inner join RWIS_NUCLEAR_RUB_RECEPTION R"+
                                        "on rd.recept_id = r.recept_id"+
                                     "inner join rwis_nuclear_bucket b"+
                                        "on rd.bucket_id = b.bucket_id"+
                                     "inner join RWIS_BASIC_MATERIAL m"+
                                        "on b.material_id = m.material_id"+
                                     "inner join RWIS_NUCLEAR_APPLY_DETAIL d"+
                                        "on rd.bucket_id = d.bucket_id"+
                                     "inner join RWIS_DISPSITE_CHECK_DETAIL c"+
                                        "on d.apply_detail_id = c.apply_detail_id"+
                                      "left join RWIS_DISPSITE_EVAL e"+
                                        "on c.detail_id = e.check_detail_id"+
                                     "where r.status = '2'";
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            //WasteStatistic wasteStatistic = new WasteStatistic();
                            //wasteStatistic.PackageCount = reader.GetOrdinal("packageCount");

                            //wasteStatistic.TotalActivity = reader.GetDecimal(reader.GetOrdinal("totalActivity"));
                            //wasteStatistic.TotalVolumn = reader.GetDecimal(reader.GetOrdinal("totalVolumn"));
                            //list.Add(wasteStatistic);
                        }

                    }

                }
            }
            return list.AsQueryable();

        }
        /// <summary>
        /// sql oracle
        /// </summary>
        /// <returns></returns>
        public static IQueryable<WasteStatistic> ReaderListOracle()
        {
            List<WasteStatistic> list = new List<WasteStatistic>();
            using (OracleConnection conn = new OracleConnection(connStr))
            {//连接后能自动的释放资源
                conn.Open();
                using (OracleCommand cmd = conn.CreateCommand())
                {

                    //cmd.CommandText = "select count(rd.package_id) packageCount," +
                    //                "sum(e.total_activity) as totalActivity," +
                    //                "sum(m.diamerter / 2 * m.diamerter / 2 * m.height) as totalVolumn" +
                    //                  "from RWIS_NUCLEAR_RUB_RECEPTION_D RD" +
                    //                 "inner join RWIS_NUCLEAR_RUB_RECEPTION R" +
                    //                    "on rd.recept_id = r.recept_id" +
                    //                 "inner join rwis_nuclear_bucket b" +
                    //                    "on rd.bucket_id = b.bucket_id" +
                    //                 "inner join RWIS_BASIC_MATERIAL m" +
                    //                    "on b.material_id = m.material_id" +
                    //                 "inner join RWIS_NUCLEAR_APPLY_DETAIL d" +
                    //                    "on rd.bucket_id = d.bucket_id" +
                    //                 "inner join RWIS_DISPSITE_CHECK_DETAIL c" +
                    //                    "on d.apply_detail_id = c.apply_detail_id" +
                    //                  "left join RWIS_DISPSITE_EVAL e" +
                    //                    "on c.detail_id = e.check_detail_id" +
                    //                 "where r.status = '2'";
                    cmd.CommandText = "select count(rd.package_id) packageCount, sum(e.total_activity) as totalActivity, sum(m.diamerter / 2 * m.diamerter / 2 * m.height) as totalVolumn from RWIS_NUCLEAR_RUB_RECEPTION_D RD inner join RWIS_NUCLEAR_RUB_RECEPTION R on rd.recept_id = r.recept_id inner join rwis_nuclear_bucket b on rd.bucket_id = b.bucket_id  inner join RWIS_BASIC_MATERIAL m on b.material_id = m.material_id inner join RWIS_NUCLEAR_APPLY_DETAIL d on rd.bucket_id = d.bucket_id inner join RWIS_DISPSITE_CHECK_DETAIL c on d.apply_detail_id = c.apply_detail_id left join RWIS_DISPSITE_EVAL e on c.detail_id = e.check_detail_id where r.status = '2'";
                    using (OracleDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            WasteStatistic wasteStatistic = new WasteStatistic();
                            wasteStatistic.PackageCount = reader["packageCount"].ToString();

                            wasteStatistic.TotalActivity = reader["totalActivity"].ToString();
                            wasteStatistic.TotalVolumn = reader["totalVolumn"].ToString();
                            list.Add(wasteStatistic);
                        }

                    }

                }
            }
            return list.AsQueryable();

        }
    }
}