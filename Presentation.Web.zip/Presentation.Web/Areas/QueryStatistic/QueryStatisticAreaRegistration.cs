﻿using System.Web.Mvc;

namespace RWIS.Presentation.Web.Areas.QueryStatistic
{
    public class QueryStatisticAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "QueryStatistic";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "QueryStatistic_default",
                "QueryStatistic/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
