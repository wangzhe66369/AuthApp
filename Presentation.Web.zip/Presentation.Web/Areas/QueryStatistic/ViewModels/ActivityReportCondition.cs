﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.Areas.QueryStatistic.ViewModels
{
    public class ActivityReportCondition
    {
        /// <summary>
        ///  截至日期
        /// </summary>
        public string StartDate { set; get; }

        /// <summary>
        /// 预期日期
        /// </summary>
        public string EndDate { set; get; }

        /// <summary>
        /// 处置场ID
        /// </summary>
        public string DispSitePositonId { set; get; }

        /// <summary>
        /// 处置单元ID
        /// </summary>
        public string DispSiteUnitId { set; get; }
    }
}