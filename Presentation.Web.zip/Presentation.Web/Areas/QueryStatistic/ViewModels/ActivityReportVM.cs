﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.QueryStatistic.ViewModels
{
    public class ActivityReportVM
    {
        /// <summary>
        /// 截至日期 
        /// </summary>
        public string StartDate { set; get; }

        /// <summary>
        /// 预期日期 
        /// </summary>
        public string EndDate { set; get; }

        /// <summary>
        /// 处置场
        /// </summary>
        public string DispsitePosition { set; get; }

        /// <summary>
        /// 处置场列表
        /// </summary>
        public List<SelectListItem> DispsitePositionList { set; get; }

        /// <summary>
        /// 处置单元
        /// </summary>
        public string DispsiteUnit { set; get; }

        /// <summary>
        /// 处置单元列表
        /// </summary>
        public List<SelectListItem> DispsiteUnitList { set; get; }

        /// <summary>
        /// 放射性特性评估验算表单
        /// </summary>
        public DispsiteEval DispsiteEval { set; get; }

        /// <summary>
        /// 核素ID
        /// </summary>
        public string ElementId { set; get; }

        /// <summary>
        /// 核素名称
        /// </summary>
        public string ElementName { set; get; }

        /// <summary>
        /// 半衰期
        /// </summary>
        public Nullable<decimal> HalfLife { set; get; }

        /// <summary>
        /// 审查日废物活度
        /// </summary>
        public string CheckDateActivity { set; get; }

        /// <summary>
        /// 原始废物活度
        /// </summary>
        public string OriginalWasteActivity { set; get; }

        /// <summary>
        /// 处置场ID
        /// </summary>
        public string DispSitePositonId { set; get; }

        /// <summary>
        /// 处置单元ID
        /// </summary>
        public string DispSiteUnitId { set; get; }
    }
}