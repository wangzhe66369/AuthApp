﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Presentation.Web.Areas.QueryStatistic.ViemModelBuilder;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Core;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Areas.MaterialManage.ViewModels;
using RWIS.Presentation.Web.Areas.QueryStatistic.ViewModels;
namespace RWIS.Presentation.Web.Areas.QueryStatistic.Controllers
{
    public class ActivityReportController : Controller
    {
        INuclearElementRepository nuclearElementRepository;
        IDispsiteEvalRepository dispsiteEvalRepository;
        IDispiteEvalDetailRepository dispiteEvalDetailRepository;
        IBasicObjectRepository basicObjectRepository;
        IActivityCountViewRepository activityCountViewRepository;
        public static string point=string.Empty;
        public ActivityReportController(
            INuclearElementRepository _nuclearElementRepository, 
            IDispsiteEvalRepository _dispsiteEvalRepository, 
            IDispiteEvalDetailRepository _dispiteEvalDetailRepository,
            IBasicObjectRepository _basicObjectRepository,
            IActivityCountViewRepository _activityCountViewRepository
            )
        {
            this.nuclearElementRepository = _nuclearElementRepository;
            this.dispsiteEvalRepository = _dispsiteEvalRepository;
            this.dispiteEvalDetailRepository = _dispiteEvalDetailRepository;
            this.basicObjectRepository = _basicObjectRepository;
            this.activityCountViewRepository = _activityCountViewRepository;
        }
        
        /// <summary>
        /// 活度报表页面
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            ActivityReportVM vm = new ActivityReportVM();

            //截至日期
            vm.StartDate = DateTime.Now.ToString("yyyy-MM-dd");

            //预测日期
            vm.EndDate = DateTime.Now.AddYears(5).ToString("yyyy-MM-dd");

            //处置场
            vm.DispsitePositionList = new List<SelectListItem>();
            vm.DispsitePositionList.Add(new SelectListItem { Text = "请选择", Value = ""});
            IQueryable<BasicObject> iqueryDispsitePosition = basicObjectRepository.GetSubobjectsByCode("DispitePosition", AppContext.CurrentUser.ProjectCode);
            if (iqueryDispsitePosition != null)
            {
                foreach (var item in iqueryDispsitePosition)
                {
                       vm.DispsitePositionList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }

            //处置单元
            vm.DispsiteUnitList = new List<SelectListItem>();
            vm.DispsiteUnitList.Add(new SelectListItem { Text = "请选择", Value = "" });
            IQueryable<BasicObject> iqueryDispsiteUnit = basicObjectRepository.GetSubobjectsByCode("UnitCode", AppContext.CurrentUser.ProjectCode);
            if (iqueryDispsiteUnit != null)
            {
                foreach (var item in iqueryDispsiteUnit)
                {
                    vm.DispsiteUnitList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
                }
            }
            return View(vm);
        }

        public JsonResult GetYPoint()
        {
            return Json("{\"result\":true,\"msg\":\"" + point + "\"}", JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 获得列的json对象
        /// </summary>
        /// <returns></returns>
        public JsonResult GetNuclearElementListJSON()
        {
            //从数据库得到核素信息
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable().Where(c => c.ElementType.ToUpper().Trim() == "LICENCE" && c.ElementName != "α>5 A" && c.Status=="1");
            List<NuclearElement> nuclearElementList = new List<NuclearElement>();
            if (iqueryNuclearElement != null && iqueryNuclearElement.Count() > 0)
            {
                nuclearElementList = iqueryNuclearElement.ToList();
            }

            //行ColNames  list
            List<string> listColNs = new List<string>();

            //行ColModels list
            List<MaterialStockDetailVM> listColMs = new List<MaterialStockDetailVM>();
            //表头
            listColNs.Add("日期");
            listColNs.Add("废物总活度(GBq)");

            //列
            for (int i = 0; i < 2; i++)
            {
                MaterialStockDetailVM model = new MaterialStockDetailVM();
                model.name = "name";
                model.index = "name";
                model.align = "center";
                listColMs.Add(model);

            }
            foreach (var nuclearElement in nuclearElementList)
            {
                MaterialStockDetailVM model = new MaterialStockDetailVM();
                model.name = nuclearElement.ElementName + "(GBq)";
                model.index = nuclearElement.ElementName;
                model.align = "center";

                listColNs.Add(nuclearElement.ElementName);
                listColMs.Add(model);
            }
            var resultObj = new
            {
                ColNs = listColNs,
                ColMs = listColMs
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        /// 初始查询
        /// </summary>
        /// <param name="materialInputCondition"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetNuclearElementList(ActivityReportCondition condition)
        {
            //从数据库得到核素信息
            IQueryable<NuclearElement> iqueryNuclearElement = nuclearElementRepository.GetAll().AsQueryable().Where(c => c.ElementType.ToUpper().Trim() == "LICENCE" && c.ElementName != "α>5 A" && c.Status == "1");
            List<NuclearElement> nuclearElementList = iqueryNuclearElement.ToList();

            //所有活度计算单信息
            string stationCode = AppContext.CurrentUser.ProjectCode.ToUpper().Trim();
            IQueryable<ActivityCountView> iqueryActivityCountView = activityCountViewRepository.GetAll().AsQueryable().Where(c => c.StationCode.ToUpper().Trim() == stationCode);
            List<ActivityCountView> activityList = new List<ActivityCountView>();
            if (iqueryActivityCountView != null && iqueryActivityCountView.Count() > 0)
            {
                activityList = iqueryActivityCountView.ToList();
            }

            //所有的放射性特性评估验算明细
            IQueryable<ActivityReportVM> iqueryActivityReport = ActivityReportBuilder.GetActivityReport(condition);
            List<ActivityReportVM> activityReportList = new List<ActivityReportVM>();
            if (iqueryActivityReport != null && iqueryActivityReport.Count() > 0)
            {
                activityReportList = iqueryActivityReport.ToList();
            }

            //放射性评估时间差
            DateTime startDate = Convert.ToDateTime(condition.StartDate);
            DateTime endDate = Convert.ToDateTime(condition.EndDate); 
            int minusYear = endDate.Year - startDate.Year;

            //定义所有核素活度数据的字典
            Dictionary<DateTime, string> dic = new Dictionary<DateTime, string>();
            var jqGridResponse = new JqGridResponse { JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            //循环年份
         
            for (int i = 0; i <= minusYear; i++)
            {
                List<ActivityReportVM> newActivityReportList = new List<ActivityReportVM>();
                DateTime calDate = Convert.ToDateTime(condition.StartDate).AddYears(i);
                foreach (var item in activityReportList)
                {
                    ActivityReportVM newItem = new ActivityReportVM();
                    newItem.DispsiteEval = item.DispsiteEval;
                    newItem.ElementId = item.ElementId;
                    newItem.ElementName = item.ElementName;
                    newItem.HalfLife = item.HalfLife;
                    newItem.OriginalWasteActivity = item.OriginalWasteActivity;
                    newItem.DispSitePositonId = item.DispSitePositonId;
                    newItem.DispSiteUnitId = item.DispSiteUnitId;
                    newItem.CheckDateActivity = GetCheckDateActivity(calDate, item, newItem.OriginalWasteActivity);
                    newActivityReportList.Add(newItem);
                }

                //计算一年中各个核素的综合
                Dictionary<string, string> dicActivity = new Dictionary<string, string>();
                string[] arrTotalActivity = new string[nuclearElementList.Count+2];
                arrTotalActivity[0] = calDate.ToString("yyyy-MM-dd");
                arrTotalActivity[1] = "0";
                string totalCheckDateActivity="0";
                for(int j=0;j<nuclearElementList.Count ;j++)
                {
                    string checkDateActivity = "0";
                    if (!dicActivity.Keys.Contains(nuclearElementList[j].ElementId))
                    {
                        checkDateActivity = GetTotalCheckDateActivity(newActivityReportList, nuclearElementList[j].ElementId);
                        arrTotalActivity[j+2] = checkDateActivity;
                        dicActivity.Add(nuclearElementList[j].ElementId, checkDateActivity);
                        totalCheckDateActivity = (double.Parse(totalCheckDateActivity.ToString()) + double.Parse(checkDateActivity.ToString())).ToString();
                    }
                }
                arrTotalActivity[1] = totalCheckDateActivity;
                if (!point.Contains(DateTime.Now.AddYears(i).ToString("yyyy-MM-dd") + "," + arrTotalActivity[1]))
                {
                    point += DateTime.Now.AddYears(i).ToString("yyyy-MM-dd") + "," + arrTotalActivity[1] + ";";
                }
                //逐年输出
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = 1,
                    List = new List<object>(arrTotalActivity)
                });
            }
            if (point.Length > 0) point = point.TrimEnd(';');
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 根据核素ID得到所有的核素活度总和
        /// </summary>
        /// <param name="newActivityReportList"></param>
        /// <param name="elementId"></param>
        /// <returns></returns>
        string GetTotalCheckDateActivity(List<ActivityReportVM> newActivityReportList, string elementId)
        {
            string totalCheckDateActivity = "0";
            List<ActivityReportVM> list= newActivityReportList.Where(c=>c.ElementId==elementId).ToList();
            if (list != null && list.Count > 0)
            {
                foreach (var item in list)
                {
                    totalCheckDateActivity = (double.Parse(totalCheckDateActivity) + double.Parse(item.CheckDateActivity)).ToString();
                }
            }
            return totalCheckDateActivity;
        }
        /// <summary>
        /// 根据原废物活度得到审查日废物活度
        /// </summary>
        /// <param name="checkDate">放射性检查评估日期</param>
        /// <param name="originalWasteActivity">原始废物活度</param>
        /// <returns></returns>
        string GetCheckDateActivity(DateTime checkDate, ActivityReportVM vm, string originalWasteActivity)
        {
            originalWasteActivity = string.IsNullOrEmpty(originalWasteActivity) ? "0" : originalWasteActivity;
            string checkDateActivity = string.Empty;
            string wasteType = string.Empty;
            double minusDays = 0;
            double minusWasteProduceDays = 0;
            try
            {
                minusDays = (checkDate - Convert.ToDateTime(vm.DispsiteEval.ActivityGiftDate.ToString())).TotalDays;
                minusWasteProduceDays = (Convert.ToDateTime(vm.DispsiteEval.ActivityGiftDate.ToString()) - Convert.ToDateTime(vm.DispsiteEval.ActivityProduceDate.ToString())).TotalDays;
            }
            catch
            {
                minusDays = 0;
                minusWasteProduceDays = 0;
            }

            if (vm.DispsiteEval != null)
            {
                BasicObject basicObject = basicObjectRepository.Get(vm.DispsiteEval.WasteTypeId);
                if (basicObject != null)
                {
                    wasteType = basicObject.Name;
                }
            }

            //得到审查日废物活度
            try
            {
                if (minusWasteProduceDays > 31)
                {
                    checkDateActivity = (float.Parse(originalWasteActivity) * Math.Exp((-0.693 * (minusDays + minusWasteProduceDays) / float.Parse(vm.HalfLife.ToString())))).ToString();
                }
                else
                {
                    checkDateActivity = (float.Parse(originalWasteActivity) * Math.Exp((-0.693 * minusDays / float.Parse(vm.HalfLife.ToString())))).ToString();
                }
            }
            catch
            { }
            return checkDateActivity;
        }
    }
}
