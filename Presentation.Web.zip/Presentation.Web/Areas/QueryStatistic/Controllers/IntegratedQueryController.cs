﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Presentation.Web.Areas.QueryStatistic.ViemModelBuilder;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using RWIS.Domain.DomainObjects;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Core;
using NET01.CoreFramework;

namespace RWIS.Presentation.Web.Areas.QueryStatistic.Controllers
{
    public class IntegratedQueryController : Controller
    {
        //
        // GET: /QueryStatistic/IntegratedQuery/
        #region 页面初始化
        IBasicObjectRepository _iBasicObjectRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        CommonHelper commonHelper = new CommonHelper();
        public IntegratedQueryController(IBasicObjectRepository _iBasicObjectRepository, IBasicWasteUnitRepository _BasicWasteUnitRepository,IMaterialTypeRepository _MaterialTypeRepository)
        {
            this._iBasicObjectRepository = _iBasicObjectRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
        }

        public ActionResult Index()
        {
            IntegratedQueryCondition integratedQueryCondition = new IntegratedQueryCondition();

            //加载电站
            integratedQueryCondition.StationCodeList = new List<SelectListItem>();
            integratedQueryCondition.StationCodeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            IQueryable<BasicWasteUnit> QueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (QueryStationList.Count() > 0)
            {
                stationList = QueryStationList.ToList();
            }
            foreach (var item in stationList)
            {
                integratedQueryCondition.StationCodeList.Add(new SelectListItem { Text = item.UnitName, Value = item.SimpleCode });
            }

           //审查状态
            integratedQueryCondition.ApproveStatusList = new List<SelectListItem>();
            integratedQueryCondition.ApproveStatusList.Add(new SelectListItem { Text = "请选择", Value = "-1", Selected = true });
            integratedQueryCondition.ApproveStatusList.Add(new SelectListItem { Text = "未审核", Value = "UnChecked" });
            integratedQueryCondition.ApproveStatusList.Add(new SelectListItem { Text = "已审核", Value = "Checked" });
            integratedQueryCondition.ApproveStatusList.Add(new SelectListItem { Text = "已审查", Value = "Applied" });

            //运输状态
            //BasicObject basicObject = this.iBasicObjectRepository.GetFiltered(b => b.Code.ToUpper() == "NuClearType".ToUpper()).FirstOrDefault();
            //List<BasicObject> basicObjectList = this.iBasicObjectRepository.GetFiltered(b => b.ParentUuid == basicObject.Uuid).ToList();
            //integratedQueryCondition.TransportStatusList = commonHelper.GetSelectItem(basicObjectList);

            //接收状态
            integratedQueryCondition.ReceptionStatusList = new List<SelectListItem>();
            integratedQueryCondition.ReceptionStatusList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            integratedQueryCondition.ReceptionStatusList.Add(new SelectListItem { Text = "接收", Value = "1" });
            integratedQueryCondition.ReceptionStatusList.Add(new SelectListItem { Text = "退回", Value = "0" });

            //处置场
            integratedQueryCondition.DispitePositionList = commonHelper.GetSelectItemUuIdByStrName("DispitePosition");

            //单元名称
            integratedQueryCondition.UnitNameList = commonHelper.GetSelectItemUuIdByStrName("UnitCode");

            //废物货包类项
            integratedQueryCondition.PackageTypeList = new List<SelectListItem>();
            IQueryable<MaterialType> iqueryMaterialType = _MaterialTypeRepository.GetAll().Where(d => d.Stationcode == AppContext.CurrentUser.ProjectCode).Where(d => d.Status == "2").AsQueryable();
            integratedQueryCondition.PackageTypeList.Add(new SelectListItem { Text = "请选择", Value = "", Selected = true });
            if (iqueryMaterialType != null && iqueryMaterialType.Count() > 0)
            {
                foreach (var item in iqueryMaterialType)
                {
                     integratedQueryCondition.PackageTypeList.Add(new SelectListItem { Text = item.MaterialName, Value = item.MaterialId });
                }
            }

            //废物类项
            integratedQueryCondition.WasteTypeList = commonHelper.GetSelectItemUuIdByStrName("NuClearType");

            return View(integratedQueryCondition);
        }
        #endregion

        #region 获取信息

        public JsonResult GetIntegratedQueryJson(IntegratedQueryCondition integratedQueryCondition, string sidx, string sord, int page, int rows)
        {
            try
            {
                IQueryable<IntegratedQueryView> integratedQueryList = IntegratedQueryBuilder.BuilderIntegratedQuery(integratedQueryCondition);

                //定义JqGiid类
                var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

                var pagedViewModel = new PagedViewModel<IntegratedQueryView>
                {
                    Query = integratedQueryList,
                    GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                    DefaultSortColumn = sidx,
                    Page = page,
                    PageSize = rows,
                }
            .Setup();

                jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

                if (integratedQueryList != null && integratedQueryList.Count() > 0)
                {
                    pagedViewModel.PagedList.ToList().ForEach(d =>
                    {
                        jqGridResponse.Records.Add(new JqGridRecord()
                        {
                            Id = d.PackageId,
                            List = new List<object>() 
                            {
                                d.PackageId,
                                d.BucketCode,
                                d.PackageCode,
                                d.Weight,
                                d.MaterialName,
                                d.Volumn,
                                d.WasteType,
                                d.TotalActivity,
                                d.DealMethod,
                                d.DoseSurface,
                                d.ReceptionStatus=="1"?"已接收":"未接收",
                                d.Location,
                            }
                        });
                    });
                }

                return jqGridResponse.ToJsonResult();
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
