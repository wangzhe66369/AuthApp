﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using NET01.CoreFramework;
using RWIS.Domain.DomainObjects.View;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.QueryStatistic.SqlHleper;
using System;
using RWIS.Presentation.Web.Areas.QueryStatistic.ViemModelBuilder;


namespace RWIS.Presentation.Web.Areas.QueryStatistic.Controllers
{
    public class WasteStatisticController : Controller
    {
        INuclearRubReceptionRepository _NuclearRubReceptionRepository;
        IBasicObjectRepository _BasicObjectRepository;
        IMaterialTypeRepository _MaterialTypeRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        public WasteStatisticController(INuclearRubReceptionRepository _NuclearRubReceptionRepository, IBasicObjectRepository _BasicObjectRepository,IMaterialTypeRepository _MaterialTypeRepository, IBasicWasteUnitRepository _BasicWasteUnitRepository)
        {
            this._NuclearRubReceptionRepository = _NuclearRubReceptionRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._MaterialTypeRepository = _MaterialTypeRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
           
        }
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 初始化查询
        /// </summary>
        /// <param name="materialName"></param>
        /// <param name="sord"></param>
        /// <param name="page"></param>
        /// <param name="rows"></param>
        /// <param name="sidx"></param>
        /// <returns></returns>
        public ActionResult GetList(string startApplyDate, string startEndDate, string sord, int page, int rows, string sidx)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };

            IQueryable<WasteStatisticView> data = this._NuclearRubReceptionRepository.QueryWasteStatistic(startApplyDate, startEndDate,"","");

            var pagedViewModel = new PagedViewModel<WasteStatisticView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();

            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;

            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    
                    List = new List<object>() {                      
                        d.TotalActivity,
                        d.TotalVolumn,
                        d.TotalCount
                    }
                });
            });

            return jqGridResponse.ToJsonResult();
        }
        /// <summary>
        /// 查看页面
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult DetailView(string startApplyDate, string startEndDate)
        {
            WasteStatisticVM vm = new WasteStatisticVM();
            vm.PackcodeList = new List<string>();
            vm.MaterialSpecList = new List<MaterialSpec>();
            //标准包包装类型
            IQueryable<BasicObject> query = _BasicObjectRepository.GetSubobjectsByCode("BucketSpec",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> bucketSpecList = new List<BasicObject>();
            if (query != null && query.Count() > 0)
            {
                bucketSpecList = query.ToList();
            }
            if (bucketSpecList.Count() > 0)
            {
                foreach (var item in bucketSpecList)
                {
                    MaterialSpec spec = new MaterialSpec();
                    spec.MaterialSpecID = item.Uuid;
                    spec.MaterialSpecName = item.Name;
                    vm.MaterialSpecList.Add(spec);
                }

            }
            foreach (var item in vm.MaterialSpecList)
            {

                WasteStatisticView wasteStatisticView = this._NuclearRubReceptionRepository.StandardPackSpec(startApplyDate, startEndDate).Where(d => d.SpecId == item.MaterialSpecID).FirstOrDefault();
                if (wasteStatisticView!=null)
                {
                    vm.PackcodeList.Add(wasteStatisticView.PackageCountBySpec.ToString());
                }
                else
                {
                    vm.PackcodeList.Add("");
                }

            }



            //标准包废物类型
            vm.WasteTypeList = new List<WasteType>();
            vm.SumWasteTypeList = new List<SumWasteType>();
            IQueryable<BasicObject> query1 = _BasicObjectRepository.GetSubobjectsByCode("NuClearType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> nuClearTypeList = new List<BasicObject>();
            if (query1 != null && query1.Count() > 0)
            {
                nuClearTypeList = query1.ToList();
            }
            if (nuClearTypeList.Count() > 0)
            {
                foreach (var item in nuClearTypeList)
                {
                    WasteType wasteType = new WasteType();
                    wasteType.WasteTypeID = item.Uuid;
                    wasteType.WasteTypeName = item.Name;
                    vm.WasteTypeList.Add(wasteType);
                }

            }
            decimal? allActivityWasteType = 0;
            decimal? allCountByWasteType = 0;
            double? allVolumnWasteType = 0;
            foreach (var item in vm.WasteTypeList)
            {
                SumWasteType sumWasteType = new SumWasteType();
                WasteStatisticView wasteStatisticView = this._NuclearRubReceptionRepository.QueryWasteStatistic(startApplyDate, startEndDate, item.WasteTypeName, "WasteType").FirstOrDefault();
                if (wasteStatisticView != null)
                {
                    sumWasteType.ActivityWasteType = wasteStatisticView.TotalActivity;
                    sumWasteType.CountByWasteType = wasteStatisticView.TotalCount;
                    sumWasteType.VolumnWasteType = wasteStatisticView.TotalVolumn;
                    vm.SumWasteTypeList.Add(sumWasteType);
                    allActivityWasteType += wasteStatisticView.TotalActivity;
                    allCountByWasteType += wasteStatisticView.TotalCount;
                    allVolumnWasteType += wasteStatisticView.TotalVolumn;
                }
                else
                {
                    vm.SumWasteTypeList.Add(sumWasteType);
                }

            }
            ViewBag.allActivityWasteType = allActivityWasteType;
            ViewBag.allCountByWasteType = allCountByWasteType;
            ViewBag.allVolumnWasteType = allVolumnWasteType;


            //非标准包装废物
            decimal? allActivityStandard = 0;
            decimal? allCountByStandard = 0;
            double? allVolumnStandard = 0;
            vm.MaterialTypeNameList = new List<MaterialTypeName>();
            vm.SumNoStandardPackList = new List<SumWasteType>();
            List<MaterialType> materialTypeNameList = _MaterialTypeRepository.GetAll().Where(d=>d.IsBucket=="1"&&d.IsStandardPack=="0"&&d.Status=="2").ToList();
            if (materialTypeNameList.Count() > 0)
            {
                foreach (var item in materialTypeNameList)
                {
                    MaterialTypeName materialTypeName = new MaterialTypeName();
                    materialTypeName.MaterialNameID = item.MaterialId;
                    materialTypeName.MaterialName = item.MaterialName;
                    vm.MaterialTypeNameList.Add(materialTypeName);

                    SumWasteType sumWasteType = new SumWasteType();
                    WasteStatisticView wasteStatisticView = this._NuclearRubReceptionRepository.QueryWasteStatistic(startApplyDate, startEndDate, item.MaterialId, "MaterialId").FirstOrDefault();
                    if (wasteStatisticView != null)
                    {
                        sumWasteType.ActivityWasteType = wasteStatisticView.TotalActivity;
                        sumWasteType.CountByWasteType = wasteStatisticView.TotalCount;
                        sumWasteType.VolumnWasteType = wasteStatisticView.TotalVolumn;
                        vm.SumNoStandardPackList.Add(sumWasteType);
                        allActivityStandard += wasteStatisticView.TotalActivity;
                        allCountByStandard += wasteStatisticView.TotalCount;
                        allVolumnStandard += wasteStatisticView.TotalVolumn;
                    }
                    else
                    {
                        vm.SumNoStandardPackList.Add(sumWasteType);
                    }
                }

            }
            ViewBag.allActivityStandard = allActivityStandard;
            ViewBag.allCountByStandard = allCountByStandard;
            ViewBag.allVolumnStandard = allVolumnStandard;


            //各个电站废物包
            vm.BasicWasteUnitList = new List<PackageBasicWasteUnit>();
            List<BasicWasteUnit> basicWasteUnitList= _BasicWasteUnitRepository.GetAll().Where(d => d.SimpleCode != null || d.SimpleCode != "").ToList();
            if (basicWasteUnitList.Count() > 0)
            {
                foreach (var item in basicWasteUnitList)
                {
                    PackageBasicWasteUnit packageBasicWasteUnit = new PackageBasicWasteUnit();
                    packageBasicWasteUnit.SimpleCode = item.SimpleCode;
                    packageBasicWasteUnit.UnitName = item.UnitName;
                  
                    WasteStatisticView wasteStatisticView = this._NuclearRubReceptionRepository.QueryWasteStatistic(startApplyDate, startEndDate, item.SimpleCode, "BasicWasteUnit").FirstOrDefault();
                    if (wasteStatisticView != null)
                    {
                        packageBasicWasteUnit.WastePackageCount = wasteStatisticView.TotalCount;
                    }
                    else
                    {
                        packageBasicWasteUnit.WastePackageCount = 0;
                    }
                    vm.BasicWasteUnitList.Add(packageBasicWasteUnit);

                }

            }

            WasteStatisticView data = this._NuclearRubReceptionRepository.QueryWasteStatistic(startApplyDate, startEndDate, "", "").FirstOrDefault();
            if (data != null)
            {
                vm.TotalActivity = data.TotalActivity;
                vm.TotalCount = data.TotalCount;
                vm.TotalVolumn = data.TotalVolumn;
            }
            return View(vm);


        }
    }
}
