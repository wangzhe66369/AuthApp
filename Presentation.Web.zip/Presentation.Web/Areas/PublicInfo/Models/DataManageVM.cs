﻿/********************************************************************************
 *
 *   项目名称   ：   核电废物信息系统
 *   文 件 名   ：   DataManageVM.cs
 *   描    述   ：   DataManageVM
 *   创 建 者   ：   郑浩宇 
 *   创建日期   ：   2016-09-13 12:01:45
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-13 12:01:45    1.0.0.0    郑浩宇       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.PublicInfo.Models
{   //资料管理VM
    public class DataManageVM
    {

        /// <summary>
        /// 资料管理实体
        /// </summary>
        public DataManage DataManage { get; set; }

        /// <summary>
        /// 文件类型id
        /// </summary>
        public List<SelectListItem> FifleTypeIdList { get; set; }

        /// <summary>
        /// 文件类型
        /// </summary>
        public string FifleTypeName { get; set; }

        /// <summary>
        /// 文件类型
        /// </summary>
        public List<SelectListItem> FifleType { get; set; }
        
        /// <summary>
        /// 上传附件
        /// </summary>
        public List<CIT.UPC.Domain.DomainObjects.AttachFile> UploadFile { get; set; }

        /// <summary>
        /// 权限验证
        /// </summary>
        public string OperationList { get; set; }
    }
}
