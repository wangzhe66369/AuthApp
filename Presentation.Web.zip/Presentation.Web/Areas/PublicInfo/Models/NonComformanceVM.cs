﻿/********************************************************************************
 *
 *   项目名称   ：   核电废物信息系统
 *   文 件 名   ：   NonComformanceVM.cs
 *   描    述   ：   NonComformanceVM
 *   创 建 者   ：   郑浩宇 
 *   创建日期   ：   2016-09-13 12:01:45
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-13 12:01:45    1.0.0.0    郑浩宇       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.DomainObjects;

namespace RWIS.Presentation.Web.Areas.PublicInfo.Models
{   //不符合项管理VM
    public class NonComformanceVM
    {

        /// <summary>
        /// 不符合项管理实体
        /// </summary>
        public NonComformance NonComformance { get; set; }

        /// <summary>
        /// 电站列表
        /// </summary>
        public List<SelectListItem> StationMarkList { get; set; }

        /// <summary>
        /// 电站列表
        /// </summary>
        public string StationMarkName { get; set; }

        /// <summary>
        /// 桶类型列表
        /// </summary>
        public List<SelectListItem> BucketTypeList { get; set; }

        /// <summary>
        /// 桶类型名称
        /// </summary>
        public string BucketTypeName { get; set; }

        /// <summary>
        /// 措施id
        /// </summary>
        public List<SelectListItem> StepId { get; set; }

        /// <summary>
        /// 措施
        /// </summary>
        public string StepName { get; set; }

        /// <summary>
        /// 措施列表
        /// </summary>
        public List<SelectListItem> StepList { get; set; }

        /// <summary>
        /// 方案性质id
        /// </summary>
        public List<SelectListItem> SchemeNatureId { get; set; }

        /// <summary>
        /// 方案性质
        /// </summary>
        public string SchemeNatureName { get; set; }

        /// <summary>
        /// 状态 
        /// </summary>
        public List<SelectListItem> StatusList { get; set; }


        /// <summary>
        /// 方案性质列表
        /// </summary>
        public List<SelectListItem> SchemeNatureList { get; set; }

        /// <summary>
        /// 不符合项描述:水泥桶废物货包id
        /// </summary>
        public List<SelectListItem> CementWasteDescId { get; set; }

        /// <summary>
        /// 不符合项描述:水泥桶废物货包
        /// </summary>
        public string CementWasteDescName { get; set; }

        /// <summary>
        /// 不符合项描述:水泥桶废物货包列表
        /// </summary>
        public List<SelectListItem> CementWasteDescList { get; set; }

        /// <summary>
        /// 不符合项描述:金属桶废物货包id
        /// </summary>
        public List<SelectListItem> MetalWasteDescId { get; set; }

        /// <summary>
        /// 不符合项描述:金属桶废物货包
        /// </summary>
        public string MetalWasteDescName { get; set; }

        /// <summary>
        /// 不符合项描述:金属桶废物货包列表
        /// </summary>
        public List<SelectListItem> MetalWasteDescList { get; set; }

        /// <summary>
        /// 权限控制
        /// </summary>
        public string OperationList { get; set; }
    }
}
