﻿/********************************************************************************
 *
 *   项目名称   ：   核电废物信息系统
 *   文 件 名   ：   NonComformanceController.cs
 *   描    述   ：   NonComformanceController
 *   创 建 者   ：   郑浩宇 
 *   创建日期   ：   2016-09-13 12:01:45
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-13 12:01:45    1.0.0.0    郑浩宇       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.PublicInfo.Models;
using RWIS.Domain.DomainObjects.View.PublicInfo;
using NET01.Presentation.Web.Mvc.JqGrid;
using MvcContrib.UI.Grid;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Core;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.PublicInfo.Controllers
{
    public class NonComformanceController : Controller
    {
        INonComformanceRepository _NonComformanceRepository;
        IBasicObjectRepository _BasicObjectRepository;
        INuclearBucketRepository _NuclearBucketRepository;
        IBasicWasteUnitRepository _BasicWasteUnitRepository;
        public NonComformanceController(INonComformanceRepository _NonComformanceRepository, 
            IBasicObjectRepository _BasicObjectRepository,
           INuclearBucketRepository _NuclearBucketRepository, IBasicWasteUnitRepository _BasicWasteUnitRepository)
        {
            this._NonComformanceRepository = _NonComformanceRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
            this._NuclearBucketRepository = _NuclearBucketRepository;
            this._BasicWasteUnitRepository = _BasicWasteUnitRepository;
        }

        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "不符合项管理")]
        public ActionResult Index()
        {
             NonComformanceVM vm = new NonComformanceVM();
             vm.OperationList = CommonHelper.GetOperationList("NonComformance_Manage");//权限控制

            //加载桶类型列表
             vm.BucketTypeList = new List<SelectListItem>();
             IQueryable<BasicObject> bucketTypeListQuery = _BasicObjectRepository.GetSubobjectsByCode("Bucket",AppContext.CurrentUser.ProjectCode);
             List<BasicObject> bucketTypeList = new List<BasicObject>();
             if (bucketTypeListQuery!=null && bucketTypeListQuery.Count() > 0)
            {
                bucketTypeList = bucketTypeListQuery.ToList();
            }
            foreach (var item in bucketTypeList)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            return View(vm);
        }

        public ActionResult Add()
        {
            ViewBag.ViewStatus = Request["status"];
            NonComformanceVM vm = new NonComformanceVM();
            vm.OperationList = CommonHelper.GetOperationList("NonComformance_Manage");//权限控制

            //加载电站列表
            vm.StationMarkList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> iqueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (iqueryStationList.Count() > 0)
            {
                stationList = iqueryStationList.ToList();
            }
            foreach (var item in stationList)
            {
                vm.StationMarkList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
            }
            //加载桶类型列表
            vm.BucketTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> bucketTypeListQuery = _BasicObjectRepository.GetSubobjectsByCode("Bucket",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> bucketTypeList = new List<BasicObject>();
            if (bucketTypeListQuery!=null && bucketTypeListQuery.Count() > 0)
            {
                bucketTypeList = bucketTypeListQuery.ToList();
            }
            foreach (var item in bucketTypeList)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }         

            //加载措施列表
            vm.StepList = new List<SelectListItem>();
            IQueryable<BasicObject> stepListQuery = _BasicObjectRepository.GetSubobjectsByCode("Step",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> stepList = new List<BasicObject>();
            if (stepListQuery!=null && stepListQuery.Count() > 0)
            {
                stepList = stepListQuery.ToList();
            }
            foreach (var item in stepList)
            {
                vm.StepList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载方案性质列表
            vm.SchemeNatureList = new List<SelectListItem>();
            IQueryable<BasicObject> schemeNatureListQuery = _BasicObjectRepository.GetSubobjectsByCode("SchemeNature",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> schemeNatureList = new List<BasicObject>();
            if (schemeNatureListQuery!=null && schemeNatureListQuery.Count() > 0)
            {
                schemeNatureList = schemeNatureListQuery.ToList();
            }
            foreach (var item in schemeNatureList)
            {
                vm.SchemeNatureList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载不符合项描述:水泥桶废物货包列表
            vm.CementWasteDescList = new List<SelectListItem>();
            IQueryable<BasicObject> cementWasteDescListQuery = _BasicObjectRepository.GetSubobjectsByCode("CementWasteDesc",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> cementWasteDescList = new List<BasicObject>();
            if (cementWasteDescListQuery!=null && cementWasteDescListQuery.Count() > 0)
            {
                cementWasteDescList = cementWasteDescListQuery.ToList();
            }
            foreach (var item in cementWasteDescList)
            {
                vm.CementWasteDescList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载不符合项描述:金属桶废物货包列表
            vm.MetalWasteDescList = new List<SelectListItem>();
            IQueryable<BasicObject> metalWasteDescListQuery = _BasicObjectRepository.GetSubobjectsByCode("MetalWasteDesc",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> metalWasteDescList = new List<BasicObject>();
            if (metalWasteDescListQuery!=null && metalWasteDescListQuery.Count() > 0)
            {
                metalWasteDescList = metalWasteDescListQuery.ToList();
            }
            foreach (var item in metalWasteDescList)
            {
                vm.MetalWasteDescList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            return View(vm);
        }

       new public ActionResult View(string id)
        {

            NonComformance model = _NonComformanceRepository.Get(id);
            NonComformanceVM vm = new NonComformanceVM();
            vm.NonComformance = model;
            BasicObject BasicObject = new BasicObject();



           //电站信息 
            BasicWasteUnit basicWasteUnit = _BasicWasteUnitRepository.Get(model.StationMark);
            if (basicWasteUnit != null)
            { vm.StationMarkName = basicWasteUnit.UnitName; }

           //桶类型 
            BasicObject basicObjectBucketType = _BasicObjectRepository.Get(model.BucketType);
            if (basicObjectBucketType != null)
            {
                vm.BucketTypeName = basicObjectBucketType.Name;
            }

            //加载措施列表
            vm.StepList = new List<SelectListItem>();
            IQueryable<BasicObject> stepListQuery = _BasicObjectRepository.GetSubobjectsByCode("Step",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> stepList = new List<BasicObject>();
            if (stepListQuery!=null && stepListQuery.Count() > 0)
            {
                stepList = stepListQuery.ToList();
            }
            foreach (var item in stepList)
            {
                vm.StepList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载方案性质列表
            vm.SchemeNatureList = new List<SelectListItem>();
            IQueryable<BasicObject> schemeNatureListQuery = _BasicObjectRepository.GetSubobjectsByCode("SchemeNature",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> schemeNatureList = new List<BasicObject>();
            if (schemeNatureListQuery!=null && schemeNatureListQuery.Count() > 0)
            {
                schemeNatureList = schemeNatureListQuery.ToList();
            }
            foreach (var item in schemeNatureList)
            {
                vm.SchemeNatureList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载不符合项描述:水泥桶废物货包列表
            vm.CementWasteDescList = new List<SelectListItem>();
            IQueryable<BasicObject> cementWasteDescListQuery = _BasicObjectRepository.GetSubobjectsByCode("CementWasteDesc",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> cementWasteDescList = new List<BasicObject>();
            if (cementWasteDescListQuery!=null && cementWasteDescListQuery.Count() > 0)
            {
                cementWasteDescList = cementWasteDescListQuery.ToList();
            }
            foreach (var item in cementWasteDescList)
            {
                vm.CementWasteDescList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载不符合项描述:金属桶废物货包列表
            vm.MetalWasteDescList = new List<SelectListItem>();
            IQueryable<BasicObject> metalWasteDescListQuery = _BasicObjectRepository.GetSubobjectsByCode("MetalWasteDesc",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> metalWasteDescList = new List<BasicObject>();
            if (metalWasteDescListQuery!=null && metalWasteDescListQuery.Count() > 0)
            {
                metalWasteDescList = metalWasteDescListQuery.ToList();
            }
            foreach (var item in metalWasteDescList)
            {
                vm.MetalWasteDescList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            NuclearBucket Buc = _NuclearBucketRepository.Get(model.BucketId);
            if (Buc!=null)
            {
                string bucketCode = Buc.BucketCode;
                model.BucketId = bucketCode;
            }
            else
            {
                model.BucketId = null;
            }
           
            return View("View", vm);            
        }

        [HttpGet]
        public ActionResult Commit(string id)
        {
            NonComformanceVM vm = new NonComformanceVM();
            NonComformance model = _NonComformanceRepository.Get(id);
            vm.NonComformance = model;
            return View("Commit", vm);
        }

        [HttpGet]
        public ActionResult Confirm(string id)
        {
            NonComformanceVM vm = new NonComformanceVM();
            NonComformance model = _NonComformanceRepository.Get(id);
            vm.NonComformance = model;
            return View("Confirm", vm);
        }

        [HttpGet]
        public ActionResult Edit(string id)
        {
            NonComformanceVM vm = new NonComformanceVM();

            vm.OperationList = CommonHelper.GetOperationList("NonComformance_Manage");//权限控制

            NonComformance model = _NonComformanceRepository.Get(id);
            vm.NonComformance = model;

            //加载电站列表
            vm.StationMarkList = new List<SelectListItem>();
            IQueryable<BasicWasteUnit> iqueryStationList = _BasicWasteUnitRepository.QueryStationList(AppContext.CurrentUser.ProjectCode);
            List<BasicWasteUnit> stationList = new List<BasicWasteUnit>();
            if (iqueryStationList.Count() > 0)
            {
                stationList = iqueryStationList.ToList();
            }
            foreach (var item in stationList)
            {
                vm.StationMarkList.Add(new SelectListItem { Text = item.UnitName, Value = item.UnitId });
            }
            //加载文件类型
            vm.BucketTypeList = new List<SelectListItem>();
            IQueryable<BasicObject> bucketTypeListQuery = _BasicObjectRepository.GetSubobjectsByCode("Bucket",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> bucketTypeList = new List<BasicObject>();
            if (bucketTypeListQuery!=null && bucketTypeListQuery.Count() > 0)
            {
                bucketTypeList = bucketTypeListQuery.ToList();
            }
            foreach (var item in bucketTypeList)
            {
                vm.BucketTypeList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载措施列表
            vm.StepList = new List<SelectListItem>();
            IQueryable<BasicObject> stepListQuery = _BasicObjectRepository.GetSubobjectsByCode("Step",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> stepList = new List<BasicObject>();
            if (stepListQuery!=null && stepListQuery.Count() > 0)
            {
                stepList = stepListQuery.ToList();
            }
            foreach (var item in stepList)
            {
                vm.StepList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载方案性质列表
            vm.SchemeNatureList = new List<SelectListItem>();
            IQueryable<BasicObject> schemeNatureListQuery = _BasicObjectRepository.GetSubobjectsByCode("SchemeNature",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> schemeNatureList = new List<BasicObject>();
            if (schemeNatureListQuery!=null && schemeNatureListQuery.Count() > 0)
            {
                schemeNatureList = schemeNatureListQuery.ToList();
            }
            foreach (var item in schemeNatureList)
            {
                vm.SchemeNatureList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载不符合项描述:水泥桶废物货包列表
            vm.CementWasteDescList = new List<SelectListItem>();
            IQueryable<BasicObject> cementWasteDescListQuery = _BasicObjectRepository.GetSubobjectsByCode("CementWasteDesc",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> cementWasteDescList = new List<BasicObject>();
            if (cementWasteDescListQuery!=null && cementWasteDescListQuery.Count() > 0)
            {
                cementWasteDescList = cementWasteDescListQuery.ToList();
            }
            foreach (var item in cementWasteDescList)
            {
                vm.CementWasteDescList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }

            //加载不符合项描述:金属桶废物货包列表
            vm.MetalWasteDescList = new List<SelectListItem>();
            IQueryable<BasicObject> metalWasteDescListQuery = _BasicObjectRepository.GetSubobjectsByCode("MetalWasteDesc",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> metalWasteDescList = new List<BasicObject>();
            if (metalWasteDescListQuery!=null && metalWasteDescListQuery.Count() > 0)
            {
                metalWasteDescList = metalWasteDescListQuery.ToList();
            }
            foreach (var item in metalWasteDescList)
            {
                vm.MetalWasteDescList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }                                 

            NuclearBucket Buc = _NuclearBucketRepository.Get(model.BucketId);
            if (Buc != null)
            {
                string bucketCode = Buc.BucketCode;
                model.BucketId = bucketCode;
            }
            else 
            {
                model.BucketId = null;
            }
            return View("Edit", vm);
        }

        /// <summary>
        /// 查询不符合项管理列表
        /// </summary>
        /// <param name="">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetNonComformanceList(NonComformanceCondition NonComformanceCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<NonComformanceView> data = this._NonComformanceRepository.QueryList(NonComformanceCondition);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<NonComformanceView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.NonComformanceId,
                    List = new List<object>() {
                    d.NonComformanceId,
                    d.NcrCode,
                    d.BucketCode,
                    d.BucketTypeName,
                    d.SupplyCompany,    
                     d.Inside,
                    d.QuestionDesc, 
                    d.Status
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }
       
        /// <summary>
        /// 编辑
        /// </summary>
        /// <param name="model"></param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(NonComformanceVM model, FormCollection formCollection)
        {
            //判断桶包是否存在 
            string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NonComformance.BucketId, AppContext.CurrentUser.ProjectCode);
            if (string.IsNullOrEmpty(bucketId))
            {
                return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
            }
            model.NonComformance.BucketId = bucketId;
            try
            {
                model.NonComformance.Step = Request.Form["hidStep"].Trim(new char[] { ',' });
                model.NonComformance.SchemeNature = Request.Form["hidSchemeNature"].Trim(new char[] { ',' });
                model.NonComformance.CementWasteDesc = Request.Form["hidCementWasteDesc"].Trim(new char[] { ',' });
                model.NonComformance.MetalWasteDesc = Request.Form["hidMetalWasteDesc"].Trim(new char[] { ',' });                
                model.NonComformance.Status = "0";//状态
                this._NonComformanceRepository.Update(model.NonComformance);//提交数据库
                this._NonComformanceRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }       

        /// <summary>
        /// 保存新增的不符合项
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Save(NonComformanceVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return JsonResultHelper.JsonResult(false, "未通过验证");
            }    
            try
            {
                //判断桶号是否存在 
                string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NonComformance.BucketId, AppContext.CurrentUser.ProjectCode);
                if (string.IsNullOrEmpty(bucketId))
                {
                    return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                }
                model.NonComformance.BucketId = bucketId;
                model.NonComformance.Step = Request.Form["hidStep"].Trim(new char[] { ',' });
                model.NonComformance.SchemeNature = Request.Form["hidSchemeNature"].Trim(new char[] { ',' });
                model.NonComformance.CementWasteDesc = Request.Form["hidCementWasteDesc"].Trim(new char[] { ',' });
                model.NonComformance.MetalWasteDesc = Request.Form["hidMetalWasteDesc"].Trim(new char[] { ',' });
                model.NonComformance.NonComformanceId = Guid.NewGuid().ToString();
                model.NonComformance.Status = "0";//状态
                //model.NonComformance.NonComformanceId = Guid.NewGuid().ToString();
                model.NonComformance.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                model.NonComformance.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                model.NonComformance.CreateDate = DateTime.Now;//创建时间
                model.NonComformance.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                this._NonComformanceRepository.Create(model.NonComformance);//提交数据库
                this._NonComformanceRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交新增的不符合项
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Submit(NonComformanceVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return JsonResultHelper.JsonResult(false, "未通过验证");
            }
            //判断桶号是否存在 
            string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NonComformance.BucketId, AppContext.CurrentUser.ProjectCode);

            if (string.IsNullOrEmpty(bucketId))
            {
                return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
            }
            model.NonComformance.BucketId = bucketId;
            
             try
            {
                if (model.NonComformance.NonComformanceId != null)
                {
                model.NonComformance.Step = Request.Form["hidStep"].Trim(new char[] { ',' });
                model.NonComformance.SchemeNature = Request.Form["hidSchemeNature"].Trim(new char[] { ',' });
                model.NonComformance.CementWasteDesc = Request.Form["hidCementWasteDesc"].Trim(new char[] { ',' });
                model.NonComformance.MetalWasteDesc = Request.Form["hidMetalWasteDesc"].Trim(new char[] { ',' });
                model.NonComformance.Status = "1";//状态               
                model.NonComformance.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                model.NonComformance.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                model.NonComformance.CreateDate = DateTime.Now;//创建时间
                model.NonComformance.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                this._NonComformanceRepository.Update(model.NonComformance);//提交数据库
                this._NonComformanceRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else if (model.NonComformance.NonComformanceId == null)
                {
                model.NonComformance.NonComformanceId = Guid.NewGuid().ToString();
                model.NonComformance.Status = "1";//状态 
                model.NonComformance.Step = Request.Form["hidStep"].Trim(new char[] { ',' });
                model.NonComformance.SchemeNature = Request.Form["hidSchemeNature"].Trim(new char[] { ',' });
                model.NonComformance.CementWasteDesc = Request.Form["hidCementWasteDesc"].Trim(new char[] { ',' });
                model.NonComformance.MetalWasteDesc = Request.Form["hidMetalWasteDesc"].Trim(new char[] { ',' });
                model.NonComformance.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                model.NonComformance.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                model.NonComformance.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                model.NonComformance.CreateDate = DateTime.Now;//创建时间
                this._NonComformanceRepository.Create(model.NonComformance);//提交数据库
                this._NonComformanceRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }           
        }

        /// <summary>
        /// 确认新增的不符合项
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "不符合项管理确认")]
        public JsonResult Confirm(NonComformanceVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return JsonResultHelper.JsonResult(false, "未通过验证");
            }

            //判断桶号是否存在 
            string bucketId = this._NuclearBucketRepository.IsExistWasteBucket(model.NonComformance.BucketId, AppContext.CurrentUser.ProjectCode);
                
            try
            {
                if (model.NonComformance.NonComformanceId != null)
                {
                    //更新不符合项信息
                    model.NonComformance = _NonComformanceRepository.Get(model.NonComformance.NonComformanceId);
                    UpdateModel(model);
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.NonComformance.BucketId = bucketId;
                    model.NonComformance.Status = "2";//状态
                    model.NonComformance.Step = Request.Form["hidStep"].Trim(new char[] { ',' });
                    model.NonComformance.SchemeNature = Request.Form["hidSchemeNature"].Trim(new char[] { ',' });
                    model.NonComformance.CementWasteDesc = Request.Form["hidCementWasteDesc"].Trim(new char[] { ',' });
                    model.NonComformance.MetalWasteDesc = Request.Form["hidMetalWasteDesc"].Trim(new char[] { ',' });             
                    model.NonComformance.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NonComformance.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NonComformance.ConfirmDate = DateTime.Now.Date;//确认时间
                    this._NonComformanceRepository.Update(model.NonComformance);//提交数据库
                    this._NonComformanceRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);
                    }
                else if (model.NonComformance.NonComformanceId == null)
                {
                    if (string.IsNullOrEmpty(bucketId))
                    {
                        return Json("{\"result\":false,\"msg\":\"桶号不存在!\"}", JsonRequestBehavior.AllowGet);
                    }
                    model.NonComformance.BucketId = bucketId;
                    model.NonComformance.NonComformanceId = Guid.NewGuid().ToString();
                    model.NonComformance.Status = "2";//状态
                    model.NonComformance.Step = Request.Form["hidStep"].Trim(new char[] { ',' });
                    model.NonComformance.SchemeNature = Request.Form["hidSchemeNature"].Trim(new char[] { ',' });
                    model.NonComformance.CementWasteDesc = Request.Form["hidCementWasteDesc"].Trim(new char[] { ',' });
                    model.NonComformance.MetalWasteDesc = Request.Form["hidMetalWasteDesc"].Trim(new char[] { ',' });
                    model.NonComformance.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.NonComformance.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.NonComformance.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    model.NonComformance.CreateDate = DateTime.Now;//创建时间
                    model.NonComformance.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.NonComformance.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.NonComformance.ConfirmDate = DateTime.Now.Date;//确认时间
                    this._NonComformanceRepository.Create(model.NonComformance);//提交数据库
                    this._NonComformanceRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"确定成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"确定失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"确定失败。\"}", JsonRequestBehavior.AllowGet);
            }           
        }

        /// <summary>
        /// 删除不符合项信息
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._NonComformanceRepository.DeleteById(idVal);
                    }
                    this._NonComformanceRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 自动填充——桶号
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public JsonResult GetDataList(string keyword)
        {
            //数据源
            List<NuclearBucket> list = _NuclearBucketRepository.GetAll().Where(e => e.BucketCode.ToUpper().Trim().Contains(keyword.ToUpper().Trim()) && e.Stationcode == AppContext.CurrentUser.ProjectCode).AsQueryable().Take(10).ToList();
            List<AutoComplete> autoCompleteList = new List<AutoComplete>();
            if (list.Count>0)
            {
                 for (int i = 0; i < list.Count; i++)
            {
                AutoComplete autoComplete = new AutoComplete();
                autoComplete.Name = list[i].BucketCode;
                autoComplete.Code = list[i].BucketId;
                autoCompleteList.Add(autoComplete);
            }
            }           
            var resultObj = new
            {
                autoCompleteList
            };
            return Json(resultObj, JsonRequestBehavior.AllowGet);
        }
    }
}
