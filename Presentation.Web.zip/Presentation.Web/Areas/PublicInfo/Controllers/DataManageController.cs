﻿/********************************************************************************
 *
 *   项目名称   ：   核电废物信息系统
 *   文 件 名   ：   DataManageController.cs
 *   描    述   ：   DataManageController
 *   创 建 者   ：   郑浩宇 
 *   创建日期   ：   2016-09-13 12:01:45
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2016-09-13 12:01:45    1.0.0.0    郑浩宇       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RWIS.Domain.Repositories;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Areas.PublicInfo.Models;
using MvcContrib.UI.Grid;
using NET01.Presentation.Web.Mvc.JqGrid;
using NET01.CoreFramework;
using RWIS.Domain.DomainObjects.View;
using RWIUS.Domain.DomainObjects.View.PublicInfo;
using RWIS.Presentation.Web.Core.Ftp;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Core;
using CIT.UPC.Domain.Repositories;
using CIT.UPC.Domain.DomainObjects;
using RWIS.Presentation.Web.Core.Filter;
using CIT.UBA.StatServices;

namespace RWIS.Presentation.Web.Areas.PublicInfo.Controllers
{
    public class DataManageController : Controller
    {
        IDataManageRepository _DataManageRepository;
        IBasicObjectRepository _BasicObjectRepository;

        public DataManageController(IDataManageRepository _DataManageRepository, IBasicObjectRepository _BasicObjectRepository)
        {
            this._DataManageRepository = _DataManageRepository;
            this._BasicObjectRepository = _BasicObjectRepository;
        }

        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "资料管理")]
        public ActionResult Index()
        {
            DataManageVM vm = new DataManageVM();
            vm.OperationList = CommonHelper.GetOperationList("Data_Manage");//权限控制

            //加载文件类型
            vm.FifleTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> fifleTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("FifleType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> fifleTypeIdList = new List<BasicObject>();
            if (fifleTypeIdQuery != null && fifleTypeIdQuery.Count() > 0)
            {
                fifleTypeIdList = fifleTypeIdQuery.ToList();
            }
            foreach (var item in fifleTypeIdList)
            {
                vm.FifleTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }
            return View(vm);
        }

        public ActionResult Add(string id)
        {
            DataManageVM vm = new DataManageVM();
            vm.OperationList = CommonHelper.GetOperationList("Data_Manage");//权限控制

            //加载文件类型
            vm.FifleTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> fifleTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("FifleType", AppContext.CurrentUser.ProjectCode);
            List<BasicObject> fifleTypeIdList = new List<BasicObject>();
            if (fifleTypeIdQuery != null && fifleTypeIdQuery.Count() > 0)
            {
                fifleTypeIdList = fifleTypeIdQuery.ToList();
            }
            foreach (var item in fifleTypeIdList)
            {
                vm.FifleTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });

            }           
            return View(vm);
        }

       new public ActionResult View(string id)
        {
            DataManageVM vm = new DataManageVM();
            DataManage model = _DataManageRepository.Get(id);
            vm.DataManage = model;
            BasicObject BasicObject = new BasicObject();
            BasicObject basicObjectFifleType = _BasicObjectRepository.Get(model.FifleTypeId);
            vm.FifleTypeName = basicObjectFifleType.Name;
            return View(vm);
        }

        [HttpGet]
        public ActionResult Edit(string id)
        {
            DataManageVM vm = new DataManageVM();
            vm.OperationList = CommonHelper.GetOperationList("Data_Manage");//权限控制           
            DataManage model = _DataManageRepository.Get(id);
            vm.DataManage = model;

            IAttachFileRepository _attachFileRepository = ServiceLocator.Current.GetInstance<IAttachFileRepository>();
            IList<AttachFile> listAttachFile = _attachFileRepository.GetAttachFileBy(id, "DataManageUpload");
            vm.UploadFile = (List<AttachFile>)listAttachFile;
            ViewBag.BusinessType = "DataManageUpload";

            //加载文件类型
            vm.FifleTypeIdList = new List<SelectListItem>();
            IQueryable<BasicObject> fifleTypeIdQuery = _BasicObjectRepository.GetSubobjectsByCode("FifleType",AppContext.CurrentUser.ProjectCode);
            List<BasicObject> fifleTypeIdList = new List<BasicObject>();
            if (fifleTypeIdQuery!=null && fifleTypeIdQuery.Count() > 0)
            {
                fifleTypeIdList = fifleTypeIdQuery.ToList();
            }
            foreach (var item in fifleTypeIdList)
            {
                vm.FifleTypeIdList.Add(new SelectListItem { Text = item.Name, Value = item.Uuid });
            }            
            return View("Edit", vm);
        }

        [HttpGet]
        public ActionResult Commit(string id)
        {
            DataManageVM vm = new DataManageVM();
            DataManage model = _DataManageRepository.Get(id);
            vm.DataManage = model;
            return View("Commit", vm);
        }

        [HttpGet]
        public ActionResult Confirm(string id)
        {
            DataManageVM vm = new DataManageVM();
            DataManage model = _DataManageRepository.Get(id);
            vm.DataManage = model;
            return View("Confirm", vm);
        }


        /// <summary>
        /// 查询资料管理列表
        /// </summary>
        /// <param name="">查询条件对象</param>
        /// <param name="sord">排序方式</param>
        /// <param name="page">当前页</param>
        /// <param name="rows">每页记录数</param>
        /// <param name="sidx">排序列</param>
        /// <returns></returns>
        public ActionResult GetDataManageList(DataManageCondition dataManageCondition, string sord, int page, int rows, string sidx)
        {
            //定义JqGiid类
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            //获取数据
            IQueryable<DataManageView> data = this._DataManageRepository.QueryList(dataManageCondition);
            //绑定前台JqGrid参数
            var pagedViewModel = new PagedViewModel<DataManageView>
            {
                Query = data,
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? MvcContrib.Sorting.SortDirection.Ascending : MvcContrib.Sorting.SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
            .Setup();
            //计算记录数
            jqGridResponse.TotalRecordsCount = pagedViewModel.PagedList.TotalItems;
            //生成前台json字符串
            pagedViewModel.PagedList.ToList().ForEach(d =>
            {
                jqGridResponse.Records.Add(new JqGridRecord()
                {
                    Id = d.DataManageId,
                    List = new List<object>() {
                    d.DataManageId,
                    d.FileTitle,
                    //d.FifleTypeId,
                    d.FifleType,
                    d.Status,
                   "["+d.UploadUserNo+"]"+d.UploadUserName,    
                    d.UploadDate.HasValue?d.UploadDate.Value.ToString("yyyy-MM-dd"):string.Empty 
                    }
                });
            });
            //返回json数据
            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 保存新增资料管理
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Save(DataManageVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return JsonResultHelper.JsonResult(false, "未通过验证");
            }

            //更新资料管理
            model.DataManage = _DataManageRepository.Get(model.DataManage.DataManageId);
            UpdateModel(model);
            try
            {
                if (model.DataManage.DataManageId != null)
                {

                    model.DataManage.Status = "0";//状态
                    //model.DataManage.DataManageId = Guid.NewGuid().ToString();
                    model.DataManage.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.DataManage.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.DataManage.CreateDate = DateTime.Now;//创建时间
                    model.DataManage.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._DataManageRepository.Update(model.DataManage);//提交数据库
                    this.SaveAttachFile(model.DataManage.DataManageId, "UploadOther", formCollection);
                    this._DataManageRepository.UnitOfWork.Commit();
                    this.SaveAttachFile(model.DataManage.DataManageId, "DataManageUpload", formCollection);

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else if (model.DataManage.DataManageId == null)
                {
                    model.DataManage.DataManageId = Guid.NewGuid().ToString();
                    model.DataManage.Status = "0";//状态
                    //model.DataManage.DataManageId = Guid.NewGuid().ToString();
                    model.DataManage.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.DataManage.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.DataManage.CreateDate = DateTime.Now;//创建时间
                    model.DataManage.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._DataManageRepository.Create(model.DataManage);//提交数据库
                    this.SaveAttachFile(model.DataManage.DataManageId, "UploadOther", formCollection);
                    this._DataManageRepository.UnitOfWork.Commit();
                    this.SaveAttachFile(model.DataManage.DataManageId, "DataManageUpload", formCollection);

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 提交新增资料管理
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Submit(DataManageVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return JsonResultHelper.JsonResult(false, "未通过验证");
            }

            //更新资料管理
            model.DataManage = _DataManageRepository.Get(model.DataManage.DataManageId);
            UpdateModel(model);
            try
            {
                if (model.DataManage.DataManageId != null)
                {

                    model.DataManage.Status = "1";//状态
                    //model.DataManage.DataManageId = Guid.NewGuid().ToString();
                    model.DataManage.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.DataManage.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.DataManage.CreateDate = DateTime.Now;//创建时间
                    model.DataManage.Stationcode = AppContext.CurrentUser.ProjectCode;
                    this._DataManageRepository.Update(model.DataManage);//提交数据库
                    this.SaveAttachFile(model.DataManage.DataManageId, "UploadOther", formCollection);
                    this._DataManageRepository.UnitOfWork.Commit();
                    this.SaveAttachFile(model.DataManage.DataManageId, "DataManageUpload", formCollection);

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else if (model.DataManage.DataManageId == null)
                {
                    model.DataManage.DataManageId = Guid.NewGuid().ToString();
                    model.DataManage.Status = "1";//状态
                    //model.DataManage.DataManageId = Guid.NewGuid().ToString();
                    model.DataManage.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.DataManage.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.DataManage.CreateDate = DateTime.Now;//创建时间
                    model.DataManage.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    this._DataManageRepository.Create(model.DataManage);//提交数据库
                    this.SaveAttachFile(model.DataManage.DataManageId, "UploadOther", formCollection);
                    this._DataManageRepository.UnitOfWork.Commit();
                    this.SaveAttachFile(model.DataManage.DataManageId, "DataManageUpload", formCollection);

                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确定新增资料管理
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        [UbaFilter(OperateType = OperateType.Button, OperateDescription = "资料管理确认")]
        public JsonResult Confirm(DataManageVM model, FormCollection formCollection)
        {
            if (!ModelState.IsValid)
            {
                return JsonResultHelper.JsonResult(false, "未通过验证");
            }

            //更新资料管理
            model.DataManage = _DataManageRepository.Get(model.DataManage.DataManageId);
            UpdateModel(model);
            try
            {
                if (model.DataManage.DataManageId != null)
                {

                    model.DataManage.Status = "2";//状态
                    model.DataManage.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    model.DataManage.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.DataManage.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.DataManage.ConfirmDate = DateTime.Now;//确认时间
                    this._DataManageRepository.Update(model.DataManage);//提交数据库
                    this.SaveAttachFile(model.DataManage.DataManageId, "UploadOther", formCollection);
                    this._DataManageRepository.UnitOfWork.Commit();
                    this.SaveAttachFile(model.DataManage.DataManageId, "DataManageUpload", formCollection);
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else if (model.DataManage.DataManageId == null)
                {
                    model.DataManage.DataManageId = Guid.NewGuid().ToString();
                    model.DataManage.Status = "2";//状态
                    model.DataManage.CreateUserNo = AppContext.CurrentUser.UserId;//创建人员工号
                    model.DataManage.CreateUserName = AppContext.CurrentUser.UserName;//创建人名称
                    model.DataManage.CreateDate = DateTime.Now;//创建时间
                    model.DataManage.Stationcode = AppContext.CurrentUser.ProjectCode;//创建人电站
                    model.DataManage.ConfirmUserNo = AppContext.CurrentUser.UserId;//确认人员工号
                    model.DataManage.ConfirmUserName = AppContext.CurrentUser.UserName;//确认人名称
                    model.DataManage.ConfirmDate = DateTime.Now;//确认时间
                    this._DataManageRepository.Create(model.DataManage);//提交数据库
                    this.SaveAttachFile(model.DataManage.DataManageId, "UploadOther", formCollection);
                    this._DataManageRepository.UnitOfWork.Commit();
                    this.SaveAttachFile(model.DataManage.DataManageId, "DataManageUpload", formCollection);
                    return Json("{\"result\":true,\"msg\":\"提交成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"提交失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 删除设备状态信息
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(string id)
        {
            try
            {
                if (!string.IsNullOrEmpty(id))
                {
                    string[] idArr = id.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string idVal in idArr)
                    {
                        this._DataManageRepository.DeleteById(idVal);
                    }
                    this._DataManageRepository.UnitOfWork.Commit();
                    return Json("{\"result\":true,\"msg\":\"删除成功。\"}", JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json("{\"result\":false,\"msg\":\"编号为空，删除失败。\"}", JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"删除失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 修改资料信息
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(DataManageVM model, FormCollection formCollection)
        {
            try
            {
                model.DataManage.Status = "0";//状态
                this._DataManageRepository.Update(model.DataManage);//提交数据库
                this._DataManageRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// 确认资料信息
        /// </summary>
        /// <param name="model">model</param>
        /// <param name="formCollection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult ConfirmEI(DataManageVM model, FormCollection formCollection)
        {
            try
            {
                model.DataManage.Status = "2";//状态
                this._DataManageRepository.Update(model.DataManage);//提交数据库
                this._DataManageRepository.UnitOfWork.Commit();
                return Json("{\"result\":true,\"msg\":\"保存成功。\"}", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("{\"result\":false,\"msg\":\"保存失败。\"}", JsonRequestBehavior.AllowGet);
            }
        }

        #region 附件上传
        [AcceptVerbs(HttpVerbs.Post)]
        public Guid? AsyncUpload(FormCollection formCollection)
        {
            if ((Request.Files).Count > 0)
            {
                return FtpFileStore.SaveUploadedFile(Request.Files[0], "DataManageUpload");
            }
            return null;
        }
        /// <summary>
        /// 下载文件
        /// 
        /// </summary>
        public FileResult DownFile(string fileId, string fileName, string businessType)
        {
            string fileTypeStr = fileName.Substring(fileName.LastIndexOf('.') + 1);
            string savefileName = fileId + "." + fileTypeStr;
            return File(FtpFileStore.DownFile(savefileName, businessType),
                fileTypeStr.FileGetMIMEType(), @Server.UrlEncode(savefileName));
        }
        #endregion

         
    }
}
