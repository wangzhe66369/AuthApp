﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using RWIS.Presentation.Web.ViewModels.PscViewModels;

namespace RWIS.Presentation.Web.ViewModelBuilder.PscVMBuilder
{
    public class WorkflowLogVMBuilder
    {
        public static WorkflowLogVM BuidWorkflowLog(string procInstId, string actId)
        {
            WorkflowLogVM workflowVM = new WorkflowLogVM();
            workflowVM.WorkflowLogList = PSCWorkflowTaskVMBuilder.GetProcessTraceList(procInstId, "", "", 1, 10);
            workflowVM.ProcInstID = procInstId;
            workflowVM.ActID = actId;
            return workflowVM;
        }
    }
}