﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   DelegateVMBuilder.cs
 *   描    述   ：   流程委托ViewModelBuilder
 *   创 建 者   ：   PCITABC 
 *   创建日期   ：   2013-08-08 10:17:15
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2013-08-08 10:17:15    1.0.0.0     PCITABC       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.ViewModels.PscViewModels;
//using NET01.Infrastructure.CommonService.Repositories;
//using NET01.Infrastructure.CommonService.Domain;
using NET01.Infrastructure.Workflow.PSC.PSCService;

namespace RWIS.Presentation.Web.ViewModelBuilder.PscVMBuilder
{
    public class DelegateVMBuilder
    {
        /// <summary>
        /// 构建委托ViewModel
        /// </summary>
        /// <returns></returns>
        public static DelegateVM BuilderDelegateModel()
        {
            DelegateVM delVM = new DelegateVM();
            delVM.WorkFlowType = new List<SelectListItem>();
            List<SelectListItem> _enableTypeList = new List<SelectListItem>()
            { 
                new SelectListItem{Value = "",Text = "--全部--"},
                new SelectListItem{ Value = "1",Text = "可用"},
                new SelectListItem{ Value = "0",Text = "不可用"}
            };
            //IBasicObjectRepository workFlowType = ServiceLocator.Current.GetInstance<IBasicObjectRepository>();
            //List<BasicObject> workFlowTypeList = workFlowType.GetBasicObjectsByType("WfType","").ToList();
            //delVM.WorkFlowType.Add(new SelectListItem { Value = "", Text = "--全部--", Selected=true });
            //foreach (BasicObject typeInfo in workFlowTypeList)
            //{
            //    delVM.WorkFlowType.Add(new SelectListItem { Value = typeInfo.Name, Text = typeInfo.Name });
            //}

            //IWfCfgProcsetRepository wfCfgProcset = ServiceLocator.Current.GetInstance<IWfCfgProcsetRepository>();
            delVM.ProcSetList = CIT.App.Lib.Uwf.Client.Factory.ServiceFactory.Instance.WorkflowConfig.GetProcSetListByAppCode(UWFCommon.AppCode);
            delVM.EnableType = _enableTypeList;
            return delVM;
        }
    }
}