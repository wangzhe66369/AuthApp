﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NET01.Infrastructure.Workflow;
using NET01.CoreFramework;
using MvcContrib.UI.Grid;
using MvcContrib.Sorting;
using NET01.Infrastructure.Workflow.PSC.PSCService;
using NET01.Presentation.Web.Mvc.JqGrid;
using CIT.PSC.Service.Entity.DTO;
using CIT.PSC.Service.Entity.BizObj;
using CIT.PSC.Service.Entity.Enum;
using CIT.PSC.Client.Service;
using CIT.PSC.Service.Entity.Query.Info;
using CIT.PSC.Service.Entity.Query;
using CIT.PSC.Service.Entity.Query.Result;
using CIT.PSC.Service.Entity.DTO.Query.Filter;
using CIT.PSC.Service.Entity.DTO.Query.Result;
using CIT.PSC.Service.Entity.DTO.Query.Info;
using CIT.PSC.Service.Entity.Query.Filter;
using CIT.PSC.Service.Entity.Query.Field;
using RWIS.Domain.Repositories;
using Microsoft.Practices.ServiceLocation;
using RWIS.Infrastructure.Data.UnitOfWork;


namespace RWIS.Presentation.Web.ViewModelBuilder.PscVMBuilder
{
    public class PSCWorkflowTaskVMBuilder
    {

        /// <summary>
        /// 创建待办Json
        /// </summary>
        public static JsonResult BuildProcessingWorkflowTaskJson(
            string taskName,
            string sidx, string sord, int page, int rows
            )
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows };

            ServiceFactory factory = UWFCommon.GetServiceFactory();
            WorkListItems service = factory.WorkListItems;
            service.ReqCondition = UWFCommon.GetServiceRequestCondition(AppContext.CurrentUser.UserId, AppContext.CurrentUser.UserName);
            string impersonateUser = AppContext.CurrentUser.UserId;
            string user = AppContext.CurrentUser.UserId;
            if (!string.IsNullOrEmpty(user))
            {
                impersonateUser = user;
            }
            ToDoTaskQuery query = new CIT.PSC.Service.Entity.Query.Info.ToDoTaskQuery();
            
            query.WorkListItemType = 1; //待办
            query.App = UWFCommon.AppCode;
            query.ImpersonateUser = impersonateUser;
            QueryPaging pageSetting = new QueryPaging();
            pageSetting.PageSize = 5000;
            pageSetting.StartPage = page;

            query.PageSetting = pageSetting;

            ToDoTaskFilter f0 = new ToDoTaskFilter { Field = ToDoTaskField.ProcessFullName };
            if (query.Conditions.Count > 0)
            {
                f0.Logical = QueryLogical.And;
            }
            f0.Operatoer = QueryOperator.Like;
            f0.Value = "%RWIS\\%";
            query.Conditions.Add(f0);

            ToDoTaskResult result = service.GetWorkListItems(query);

            IList<ToDoTask> data = result.ToDoTasks.Where(p => string.IsNullOrEmpty(taskName) || p.Folio.Contains(taskName)).ToList();
            List<ProcessingInfo> sortData = new List<ProcessingInfo>();

            foreach (ToDoTask temp in data)
            {
                ProcessingInfo info = new ProcessingInfo();
                info.ActivityID = temp.ActivityID;
                info.ActivityName = temp.ActivityName;
                info.ProcessName = temp.ProcessName;
                info.ProcessStartTime = Convert.ToDateTime(temp.ProcessStartTime);
                info.ProcGuid = temp.ProcGuid;
                info.ProcID = temp.ProcID;
                info.ProcInstID = temp.ProcInstID;
                info.SN = temp.SN;
                info.Folio = temp.Folio;
                info.StartUserCN = temp.StartUserCN;
                info.Title = string.IsNullOrEmpty(temp.AppTaskTitle) ? temp.Folio : temp.AppTaskTitle;
                info.ProcessFullName = temp.ProcessFullName;
                info.FormId = temp.FormInstID;
                sortData.Add(info);
            }

            sortData.OrderBy("ProcessStartTime", SortDirection.Descending);

            jqGridResponse.TotalRecordsCount = data.Count();
            var pagedViewModel = new PagedViewModel<ProcessingInfo>
            {
                Query = sortData.AsQueryable(),
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
           .Setup();
            pagedViewModel.PagedList.ToList().ForEach(p => BuildListJson(jqGridResponse, p));

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 构建网格Json
        /// </summary>
        /// <param name="reportRepository"></param>
        /// <param name="jqGridResponse"></param>
        /// <param name="p"></param>
        private static void BuildListJson(JqGridResponse jqGridResponse, ToDoTask p)
        {

        }

        /// <summary>
        /// 构建网格Json
        /// </summary>
        /// <param name="reportRepository"></param>
        /// <param name="jqGridResponse"></param>
        /// <param name="p"></param>
        private static void BuildListJson(JqGridResponse jqGridResponse, ProcessingInfo p)
        {
            jqGridResponse.Records.Add(new JqGridRecord()
            {
                Id = p.ProcGuid,
                List = new List<object>()
                        {
                            p.ProcGuid, 
                            null, //查看流程
                            string.IsNullOrEmpty(p.Folio)?p.ProcessName:p.Folio,
                            p.ProcessName,
                            p.StartUserCN,
                            p.ProcessStartTime.Value.ToString(),
                            p.ActivityName,
                            p.ProcInstID,
                            p.ProcID,
                            p.ActivityID,
                            p.SN,
                            p.ProcessFullName,
                            p.FormId,
                        }
            });
        }

        /// <summary>
        /// 创建已办Json
        /// </summary>
        public static JsonResult BuildProcessedWorkflowTaskJson(
            string taskName,
            string sidx, string sord, int page, int rows
            )
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows };

            DoneTaskQuery query = new DoneTaskQuery();
            QueryPaging pageSetting = new QueryPaging();
            pageSetting.PageSize = 5000;
            pageSetting.StartPage = page;

            query.PageSetting = pageSetting;

            query.OrderBys.Add(CIT.PSC.Service.Entity.Query.Field.DoneTaskField.EndTime);
            query.Direction = QueryDirection.DESC;
            query.App = UWFCommon.AppCode;
            query.ImpersonateUser = AppContext.CurrentUser.UserId;
            query.SqlWhereData = "";


            DoneTaskFilter f0 = new DoneTaskFilter { Field = DoneTaskField.ProcessFullName };
            if (query.Conditions.Count > 0)
            {
                f0.Logical = QueryLogical.And;
            }
            f0.Operatoer = QueryOperator.Like;
            f0.Value = "%RWIS\\%";
            query.Conditions.Add(f0);

            WorkListItems service = UWFCommon.GetServiceFactory().WorkListItems;
            service.ReqCondition = UWFCommon.GetServiceRequestCondition(AppContext.CurrentUser.UserId, AppContext.CurrentUser.UserName);

            List<ProcessLogFilter> filters = new List<ProcessLogFilter>();


            DoneTaskResult Results = service.GetWorkListItemLogs(query);

            IList<DoneTask> data = Results.DoneTasks.Where(p => string.IsNullOrEmpty(taskName) || p.Folio.Contains(taskName)).ToList();
            List<ProcessedInfo> sortData = new List<ProcessedInfo>();

            foreach (DoneTask temp in data)
            {
                ProcessedInfo info = new ProcessedInfo();
                info.ProcGuid = temp.ProcGuid;
                info.Folio = temp.Folio;
                info.Title = string.IsNullOrEmpty(temp.Folio) ? temp.AppTaskTitle : temp.Folio;
                info.ProcessName = temp.ProcessName;
                info.StartCNUser = temp.StartCNUser;
                info.StartTime = Convert.ToDateTime(temp.StartTime);
                info.ActName = temp.ActName;
                info.ProcInstID = temp.ProcInstID;
                info.ProcID = temp.ProcID;
                info.ActInstDestID = temp.ActInstDestID;
                info.ProcessFullName = temp.ProcessFullName;
                info.FormId = temp.FromNO;
                sortData.Add(info);
            }

            sortData.OrderBy("StartTime", SortDirection.Descending);

            jqGridResponse.TotalRecordsCount = data.Count();
            var pagedViewModel = new PagedViewModel<ProcessedInfo>
            {
                Query = sortData.AsQueryable(),
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
           .Setup();
            pagedViewModel.PagedList.ToList().ForEach(p => BuildProcessedListJson(jqGridResponse, p));

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 构建网格Json
        /// </summary>
        /// <param name="reportRepository"></param>
        /// <param name="jqGridResponse"></param>
        /// <param name="p"></param>
        private static void BuildProcessedListJson(JqGridResponse jqGridResponse, DoneTask p)
        {


        }

        /// <summary>
        /// 构建网格Json
        /// </summary>
        /// <param name="reportRepository"></param>
        /// <param name="jqGridResponse"></param>
        /// <param name="p"></param>
        private static void BuildProcessedListJson(JqGridResponse jqGridResponse, ProcessedInfo p)
        {
            var record = new JqGridRecord()
            {
                Id = p.ActInstDestID,
                List = new List<object>()
                        {
                            p.ProcGuid, 
                            null, //查看流程
                            p.Folio.ToString(),
                            p.ProcessName,
                            p.StartCNUser,//p.StartCNUser,
                            p.StartTime.HasValue?p.StartTime.Value.ToString():string.Empty,
                            p.ActName,
                            p.ProcInstID,
                            p.ProcID,
                            p.ActInstDestID,
                            p.ProcessFullName,
                            p.FormId,
                        }
            };
            jqGridResponse.Records.Add(record);

        }

        #region 待阅
        /// <summary>
        /// 构建待阅Json
        /// </summary>
        public static JsonResult BuildReadingWorkflowTaskJson(string taskName, string sidx, string sord, int page, int rows)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows };

            ServiceFactory factory = UWFCommon.GetServiceFactory();
            WorkListItems service = factory.WorkListItems;
            service.ReqCondition = UWFCommon.GetServiceRequestCondition(AppContext.CurrentUser.UserId, AppContext.CurrentUser.UserName);

            string impersonateUser = AppContext.CurrentUser.UserId;
            string user = AppContext.CurrentUser.UserId;
            if (!string.IsNullOrEmpty(user))
            {
                impersonateUser = user;
            }
            ToDoTaskQuery query = new CIT.PSC.Service.Entity.Query.Info.ToDoTaskQuery();
            query.WorkListItemType = 3; //待阅
            query.App = UWFCommon.AppCode;
            query.ImpersonateUser = impersonateUser;
            QueryPaging pageSetting = new QueryPaging();
            pageSetting.PageSize = 5000;
            pageSetting.StartPage = page;

            query.PageSetting = pageSetting;
            ToDoTaskResult result;
            result = service.GetCopySendItemsList(query);

            IList<ToDoTask> data = result.ToDoTasks.Where(p => string.IsNullOrEmpty(taskName) || p.Folio.Contains(taskName)).ToList();

            //foreach (ToDoTask task in result.ToDoTasks)
            //{
            //    ApprovalInstance inst = new ApprovalInstance();
            //    inst.CreateDate = Convert.ToDateTime(task.TaskStartTime);
            //    inst.CreateUser = task.StartUser;
            //    inst.CreateUserName = task.StartUserCN;
            //    inst.CurrentState = task.ActivityID;
            //    inst.CurrentStateName = task.ActivityName;
            //    inst.InstanceId = task.ProcGuid;
            //    inst.InstanceName = task.Folio;
            //    inst.InstanceType = task.Folio;
            //    inst.IsLock = false;
            //    inst.LatestProcessDate = task.LastDueTime;
            //    inst.SubSystemCode = "EMP";
            //    inst.WorkflowName = task.SN;
            //    if (string.IsNullOrEmpty(taskName) || !string.IsNullOrEmpty(taskName) && inst.InstanceName.Contains(taskName))
            //    {
            //        data.Add(inst);
            //    }
            //}

            jqGridResponse.TotalRecordsCount = data.Count();
            var pagedViewModel = new PagedViewModel<ToDoTask>
            {
                Query = data.AsQueryable(),
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
           .Setup();
            pagedViewModel.PagedList.ToList().ForEach(p => BuildListJson(jqGridResponse, p));

            return jqGridResponse.ToJsonResult();
        }
        #endregion

        #region 已阅
        /// <summary>
        /// 构建已阅Json
        /// </summary>
        public static JsonResult BuildReadWorkflowTaskJson(string taskName, string sidx, string sord, int page, int rows)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows };

            DoneTaskQuery query = new DoneTaskQuery();
            QueryPaging pageSetting = new QueryPaging();
            pageSetting.PageSize = 5000;
            pageSetting.StartPage = page;
            query.PageSetting = pageSetting;
            query.App = UWFCommon.AppCode;
            string impersonateUser = AppContext.CurrentUser.UserId;
            query.ImpersonateUser = impersonateUser;
            query.SqlWhereData = "";

            ServiceFactory factory = UWFCommon.GetServiceFactory();
            WorkListItems service = factory.WorkListItems;
            service.ReqCondition = UWFCommon.GetServiceRequestCondition(AppContext.CurrentUser.UserId, AppContext.CurrentUser.UserName);
            DoneTaskResult result = service.GetCopySendItemLogs(query);
            //Label3.Text = string.Format("待阅已办列表:{0}", query.PageSetting.TotalCount.ToString());

            IList<DoneTask> data = result.DoneTasks.Where(p => string.IsNullOrEmpty(taskName) || p.Folio.Contains(taskName)).ToList();

            //foreach (DoneTask task in result.DoneTasks)
            //{
            //    ApprovalInstance inst = new ApprovalInstance();
            //    inst.CreateDate = Convert.ToDateTime(task.StartTime);
            //    inst.CreateUser = task.StartUser;
            //    inst.CreateUserName = task.StartCNUser;
            //    inst.CurrentState = task.ActInstDestID;
            //    inst.CurrentStateName = task.ActName;
            //    inst.InstanceId = task.ProcGuid;
            //    inst.InstanceName = task.Folio;
            //    inst.InstanceType = task.Folio;
            //    inst.IsLock = false;
            //    inst.LatestProcessDate = Convert.ToDateTime(task.FinishDate);
            //    inst.SubSystemCode = "EMP";
            //    inst.WorkflowName = task.ProcessName;
            //    if (string.IsNullOrEmpty(taskName) || !string.IsNullOrEmpty(taskName) && inst.InstanceName.Contains(taskName))
            //    {
            //        data.Add(inst);
            //    }
            //}

            jqGridResponse.TotalRecordsCount = data.Count();
            var pagedViewModel = new PagedViewModel<DoneTask>
            {
                Query = data.AsQueryable(),
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
           .Setup();
            pagedViewModel.PagedList.ToList().ForEach(p => BuildProcessedListJson(jqGridResponse, p));

            return jqGridResponse.ToJsonResult();
        }
        #endregion

        #region 委托
        /// <summary>
        /// 构建委托Json
        /// </summary>
        public static JsonResult BuildDelegateTaskJson(string delType, string userInfo, string flowType, string status, string startTime, string endTime, string sidx, string sord, int page, int rows)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows };
            ServiceFactory factory = UWFCommon.GetServiceFactory();
            CIT.PSC.Client.Service.ProcTemplate service = factory.ProcTemplate;
            service.ReqCondition = UWFCommon.GetServiceRequestCondition();
            DelegateSettingResult ret = service.GetDelegateSettingResult(GetQueryInfo(page, rows, delType));
            jqGridResponse.TotalRecordsCount = ret.Paging.TotalCount;
            DateTime sTime = DateTime.MinValue;
            DateTime eTime = DateTime.MaxValue;
            if (!string.IsNullOrEmpty(startTime))
                sTime = DateTime.Parse(startTime);
            if (!string.IsNullOrEmpty(endTime))
                eTime = DateTime.Parse(endTime);
            IList<DelegateSetting> data = new List<DelegateSetting>();
            bool isEnabled = false;
            if (!string.IsNullOrEmpty(status))
                isEnabled = status == "1" ? true : false;
            if (delType == "from") //委托列表按照受托人查找，反之按照委托人查找
            {
                data = ret.Lists.Where(p => p.StartTime >= sTime && p.EndTime <= eTime && (p.ToUser.Contains(userInfo) || p.ToUserName.Contains(userInfo)) && (p.IsEnabled == isEnabled || string.IsNullOrEmpty(status)) && (p.ProcessName.Equals(flowType) || string.IsNullOrEmpty(flowType))).ToList();
            }
            else
            {
                data = ret.Lists.Where(p => p.StartTime >= sTime && p.EndTime <= eTime && (p.FromUser.Contains(userInfo) || p.FromUserName.Contains(userInfo)) && (p.IsEnabled == isEnabled || string.IsNullOrEmpty(status)) && (p.ProcessName.Equals(flowType) || string.IsNullOrEmpty(flowType))).ToList();
            }
            var pagedViewModel = new PagedViewModel<DelegateSetting>
            {
                Query = data.AsQueryable(),
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
           .Setup();
            pagedViewModel.PagedList.ToList().ForEach(p => BuildDelegateListJson(jqGridResponse, p));

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 构建委托网格Json
        /// </summary>
        private static void BuildDelegateListJson(JqGridResponse jqGridResponse, DelegateSetting p)
        {
            var record = new JqGridRecord()
            {
                Id = p.ID,
                List = new List<object>()
                        {
                            p.ID,
                            p.FromUserName,
                            p.ToUserName,
                            p.ProcessName,
                            p.StartTime.ToString("yyyy-MM-dd"),
                            p.EndTime.ToString("yyyy-MM-dd"),
                            p.IsEnabled ? "可用" : "不可用",
                            p.FromUser,
                            p.ToUser,
                            p.ProcessFullName
                        }
            };
            jqGridResponse.Records.Add(record);
        }

        /// <summary>
        /// 获取查询条件
        /// </summary>
        /// <returns></returns>
        private static DelegateSettingQuery GetQueryInfo(int page, int rows, string delType)
        {
            DelegateSettingQuery query = new DelegateSettingQuery();
            //分页信息
            query.PageSetting = new QueryPaging();
            query.PageSetting.PageSize = rows;
            query.PageSetting.StartPage = page; //查询信息
            DelegateSettingFilter filter = new DelegateSettingFilter();
            filter.Field = DelegateSettingField.AppCode;
            filter.Logical = QueryLogical.And;
            filter.Operatoer = QueryOperator.Equal;
            filter.Value = UWFCommon.AppCode;
            query.Conditions.Add(filter);
            DelegateSettingFilter filterUser = new DelegateSettingFilter();
            filterUser.Logical = QueryLogical.And;
            filterUser.Operatoer = QueryOperator.Equal;
            if (delType == "from") //委托人为当前登录人过滤
            {
                filterUser.Field = DelegateSettingField.FromUser;
            }
            else //受托人为当前登录人过滤
            {
                filterUser.Field = DelegateSettingField.ToUser;
            }
            filterUser.Value = AppContext.CurrentUser.UserId;
            query.Conditions.Add(filterUser);
            return query;
        }
        #endregion

        #region 流程日志
        /// <summary>
        /// 获取流程日志列表JSON数据
        /// </summary>
        /// <param name="procInstId">流程实例ID</param>
        /// <param name="actId">环节ID</param>
        /// <param name="approveUser">处理人</param>
        /// <param name="page">页号</param>
        /// <param name="rows">页面大小</param>
        public static JsonResult GetProcessTrace(string procInstId, string actId, string approveUser, string sidx, string sord, int page, int rows)
        {
            var jqGridResponse = new JqGridResponse { PageIndex = page, PageSize = rows };

            IList<ProcessTrace> data = GetProcessTraceList(procInstId, actId, approveUser, page, rows);

            var pagedViewModel = new PagedViewModel<ProcessTrace>
            {
                Query = data.AsQueryable(),
                GridSortOptions = new GridSortOptions() { Column = sidx, Direction = sord.Equals("asc") ? SortDirection.Ascending : SortDirection.Descending },
                DefaultSortColumn = sidx,
                Page = page,
                PageSize = rows,
            }
           .Setup();
            pagedViewModel.PagedList.ToList().ForEach(p => BuildWorkflowLotListJson(jqGridResponse, p));

            return jqGridResponse.ToJsonResult();
        }

        /// <summary>
        /// 获取流程日志列表
        /// </summary>
        public static IList<ProcessTrace> GetProcessTraceList(string procInstId, string actId, string approveUser, int page, int rows)
        {
            ProcessLogQuery pscQuery = new ProcessLogQuery();
            if (!string.IsNullOrEmpty(procInstId))
            {
                pscQuery.ProcInstID = procInstId;
            }
            List<ProcessLogFilter> filters = new List<ProcessLogFilter>();
            if (!string.IsNullOrEmpty(actId))
            {
                //处理步骤
                ProcessLogFilter actNameFilter = new ProcessLogFilter { Field = ProcessLogField.ActID };
                if (filters.Count > 0)
                {
                    actNameFilter.Logical = QueryLogical.And;
                }
                actNameFilter.Operatoer = QueryOperator.Equal;
                actNameFilter.Value = actId;
                filters.Add(actNameFilter);
            }
            if (!string.IsNullOrEmpty(approveUser))
            {
                //处理人
                ProcessLogFilter approveUserFilter = new ProcessLogFilter { Field = ProcessLogField.ApproverAccount };
                if (filters.Count > 0)
                {
                    approveUserFilter.Logical = QueryLogical.And;
                }
                approveUserFilter.Operatoer = QueryOperator.Like;
                approveUserFilter.Value = "%" + approveUser + "%";
                filters.Add(approveUserFilter);
            }
            pscQuery.Conditions = filters;

            pscQuery.PageSetting = new QueryPaging { PageSize = 5000, StartPage = page };

            ServiceFactory factory = UWFCommon.GetServiceFactory();
            CIT.PSC.Client.Service.WorkListItems _service = factory.WorkListItems;
            _service.ReqCondition = UWFCommon.GetServiceRequestCondition();

            ProcessTraceResult pscResult = _service.GetWorkListItemTrace(pscQuery);
            IList<ProcessTrace> data = pscResult.ProcessTraces;
            return data;
        }

        /// <summary>
        /// 构建委托网格Json
        /// </summary>
        private static void BuildWorkflowLotListJson(JqGridResponse jqGridResponse, ProcessTrace p)
        {
            var record = new JqGridRecord()
            {
                Id = p.ProcessLogDTO.ProcessLogID,
                List = new List<object>()
                        {
                            p.ProcessLogDTO.ProcessLogID,
                            p.ProcessLogDTO.ActName,
                            p.ProcessLogDTO.ApproverChsName,
                            p.ProcessLogDTO.StartDate == DateTime.MinValue ? "" : p.ProcessLogDTO.StartDate.ToString("yyyy-MM-dd"), 
                            p.ProcessLogDTO.FinishDate == DateTime.MinValue ? "" : p.ProcessLogDTO.FinishDate.ToString("yyyy-MM-dd"),
                            p.NextActInfo.Count > 0 ? p.NextActInfo.FirstOrDefault().NextActivityName : "",
                            p.NextActInfo.Count > 0 ? p.NextActInfo.FirstOrDefault().NextUserChsName : "",
                            p.ProcessLogDTO.OperationType,
                            p.ProcessLogDTO.Comment,
                            p.ProcessLogDTO.StartDate,
                            p.ProcessLogDTO.IsDelegated,
                            p.ProcessLogDTO.ActID,
                            p.ProcessLogDTO.ActInstDestID,
                            p.ProcessLogDTO.Action,
                            p.ProcessLogDTO.ApproverAccount
                        }
            };
            jqGridResponse.Records.Add(record);
        }
        #endregion
    }

    //代办排序类
    public class ProcessingInfo
    {
        public string ProcGuid;
        public string Title;
        public string Folio;
        public string ProcessName { get; set; }
        public string StartUserCN { get; set; }
        public Nullable<DateTime> ProcessStartTime { get; set; }
        public string ActivityName;
        public string ProcInstID;
        public string ProcID;
        public string ActivityID;
        public string SN;

        /// <summary>
        /// 表单编号
        /// </summary>
        public string FormId;

        /// <summary>
        /// 流程分类全称
        /// </summary>
        public string ProcessFullName { get; set; }

    }

    //已办排序类
    public class ProcessedInfo
    {
        public string ProcGuid;
        public string Folio;
        public string Title;
        public string ProcessName { get; set; }
        public string StartCNUser { get; set; }
        public Nullable<DateTime> StartTime { get; set; }
        public string ActName;
        public string ProcInstID;
        public string ProcID;
        public string ActInstDestID;
        /// <summary>
        /// 流程分类全称
        /// </summary>
        public string ProcessFullName { get; set; }

        /// <summary>
        /// 表单编号
        /// </summary>
        public string FormId;
    }
}