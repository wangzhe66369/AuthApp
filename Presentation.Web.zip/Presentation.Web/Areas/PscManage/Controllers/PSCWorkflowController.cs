﻿/********************************************************************************
 *
 *   项目名称   ：   多基地工程技术服务设计管理系统（EMP）
 *   文 件 名   ：   PSCWorkflowController.cs
 *   描    述   ：   PSC业务流程相关内容Controller
 *   创 建 者   ：   [PCITABC]
 *   创建日期   ：   2013-07-29 10:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2013-07-29 10:00:00    1.0.0.0    [PCITABC]       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcContrib.UI.Grid;
using CIT.UBA.StatServices;
using NET01.Infrastructure.Workflow;
using NET01.CoreFramework;
using CIT.PSC.Service.Entity.BizObj;
using CIT.PSC.Service.Entity.Enum;
using NET01.Infrastructure.Workflow.PSC.PSCService;
using Microsoft.Practices.ServiceLocation;
using System.IO;
using CIT.PSC.Client.Service;
using CIT.PSC.Service.Entity.DTO;
using System.Text;
using CIT.PSC.Service.Entity.DTO.Query.Info;
using CIT.PSC.Service.Entity.DTO.Query.Result;
using CIT.PSC.Service.Entity.Query;
using CIT.PSC.Service.Entity.DTO.Query.Filter;
using CIT.PSC.Service.Entity.Query.Field;
using System.Configuration;
using RWIS.Presentation.Web.Core.Filter;
using RWIS.Presentation.Web.ViewModelBuilder.PscVMBuilder;
using RWIS.Presentation.Web.ViewModels.PscViewModels;

using RWIS.Presentation.Web;
using RWIS.Presentation.Web.Core;

namespace RWIS.Presentation.Web.Areas.PscManage.Controllers
{
    /// <summary>
    /// PSC业务流程相关内容Controller
    /// </summary>
    [LoginRequired]
    public class PSCWorkflowController : Controller
    {
    //    private CIT.PSC.Client.Service.ProcTemplate procTemplateService = null;
    //    private string ascKey = String.Empty;
    //    public PSCWorkflowController()
    //    {
    //        ServiceFactory factory = UWFCommon.GetServiceFactory();
    //        this.procTemplateService = factory.ProcTemplate;
    //        this.procTemplateService.ReqCondition = UWFCommon.GetServiceRequestCondition();
    //        this.ascKey = ConfigurationManager.AppSettings["ASCKey"].ToString();
    //    }
    //    [UbaFilter(OperateType = OperateType.Page, OperateDescription = "待办任务")]
    //    [OutputCache(Duration = 0, VaryByParam = "none")]
    //    public ActionResult ProcessingTask(string taskName, GridSortOptions gridSortOptions, int? page = 1)
    //    {
    //        return View();
    //    }
    //    [UbaFilter(OperateType = OperateType.Button, OperateDescription = "已办任务")]
    //    [OutputCache(Duration = 0, VaryByParam = "none")]
    //    public ActionResult ProcessedTask(string taskName, GridSortOptions gridSortOptions, int? page = 1)
    //    {
    //        return View();
    //    }

    //    [UbaFilter(OperateType = OperateType.Page, OperateDescription = "待阅任务")]
    //    [OutputCache(Duration = 0, VaryByParam = "none")]
    //    public ActionResult ReadingTask(string taskName, GridSortOptions gridSortOptions, int? page = 1)
    //    {
    //        return View();
    //    }
    //    [UbaFilter(OperateType = OperateType.Button, OperateDescription = "已阅任务")]
    //    [OutputCache(Duration = 0, VaryByParam = "none")]
    //    public ActionResult ReadTask(string taskName, GridSortOptions gridSortOptions, int? page = 1)
    //    {
    //        return View();
    //    }

    //    /// <summary>
    //    /// 待办网格Json
    //    /// </summary>
    //    [HttpGet]
    //    public ActionResult GetJsonProcessingTask(string taskName, string sidx, string sord, int page, int rows)
    //    {
    //        return PSCWorkflowTaskVMBuilder.BuildProcessingWorkflowTaskJson(taskName, sidx, sord, page, rows);
    //    }
    //    [OutputCache(Duration = 0, VaryByParam = "none")]

    //    /// <summary>
    //    /// 已办Json
    //    /// </summary>
    //    [HttpGet]
    //    public ActionResult GetJsonProcessedTask(string taskName, string sidx, string sord, int page, int rows)
    //    {
    //        return PSCWorkflowTaskVMBuilder.BuildProcessedWorkflowTaskJson(taskName, sidx, sord, page, rows);
    //    }

    //    /// <summary>
    //    /// 获取待阅JSON
    //    /// </summary>
    //    [HttpGet]
    //    public ActionResult GetJsonReadingTask(string taskName, string sidx, string sord, int page, int rows)
    //    {
    //        return PSCWorkflowTaskVMBuilder.BuildReadingWorkflowTaskJson(taskName, sidx, sord, page, rows);
    //    }

    //    /// <summary>
    //    /// 获取已阅JSON
    //    /// </summary>
    //    [HttpGet]
    //    public ActionResult GetJsonReadTask(string taskName, string sidx, string sord, int page, int rows)
    //    {
    //        return PSCWorkflowTaskVMBuilder.BuildReadWorkflowTaskJson(taskName, sidx, sord, page, rows);
    //    }

    //    [OutputCache(Duration = 0, VaryByParam = "none")]
    //    public void WorkflowImage()
    //    {
    //        string instanceId = Request.QueryString["InstanceId"];
    //        string workflowType = Request.QueryString["WorkflowType"];
    //        if ((!String.IsNullOrEmpty(instanceId)) || (!String.IsNullOrEmpty(workflowType)))
    //        {

    //        }
    //    }

    //    #region 流程日志
    //    [UbaFilter(OperateType = OperateType.Page, OperateDescription = "流程日志")]
    //    [OutputCache(Duration = 0, VaryByParam = "none")]
    //    public ActionResult WorkflowLog(string procInstId, string actId, GridSortOptions gridSortOptions, int? page = 1)
    //    {
    //        IList<SelectListItem> actList = new List<SelectListItem>();
    //        actList.Insert(0, new SelectListItem { Text = "--请选择--", Value = "" });
    //        //IWfCfgActRepository actRepository = ServiceLocator.Current.GetInstance<IWfCfgActRepository>();
    //        var procID = CIT.App.Lib.Uwf.Client.Factory.ServiceFactory.Instance.WorkflowConfig.GetActById(actId).ProcId;
    //        var list = CIT.App.Lib.Uwf.Client.Factory.ServiceFactory.Instance.WorkflowConfig.GetActListByProcId(procID).Where(p => !string.IsNullOrEmpty(p.ActMetadata) && !p.ActMetadata.Equals("END")).OrderBy(p => p.ActMetadata);
    //        foreach (var act in list)
    //        {
    //            actList.Add(new SelectListItem { Text = act.ActName, Value = act.ActId.ToString() });
    //        }
    //        ViewBag.ActList = actList;
    //        ViewBag.ProcInstID = procInstId;
    //        return View();
    //    }

    //    /// <summary>
    //    /// 获取流程日志JSON
    //    /// </summary>
    //    [HttpGet]
    //    public ActionResult GetWorkflowLog(string procInstId, string actId, string approveUser, string sidx, string sord, int page, int rows)
    //    {
    //        return PSCWorkflowTaskVMBuilder.GetProcessTrace(procInstId, actId, approveUser, sidx, sord, page, rows);
    //    }
    //    #endregion

    //    #region 委托工作相关
    //    /// <summary>
    //    /// 委托列表进入
    //    /// </summary>
    //    public ActionResult DelegateTask()
    //    {
    //        DelegateVM delVM = DelegateVMBuilder.BuilderDelegateModel();

    //        return View(delVM);
    //    }

    //    /// <summary>
    //    /// 新增委托进入
    //    /// </summary>
    //    /// <returns></returns>
    //    public ActionResult DelegateTaskAdd(string delId)
    //    {
    //        ViewBag.DelID = delId;
    //        return View();
    //    }

    //    /// <summary>
    //    /// 获取委托列表JSON
    //    /// </summary>
    //    [HttpGet]
    //    public ActionResult GetJsonDelegateTask(string delType, string userInfo, string flowType, string status, string startTime, string endTime, string sidx, string sord, int page, int rows)
    //    {
    //        return PSCWorkflowTaskVMBuilder.BuildDelegateTaskJson(delType, userInfo, flowType, status, startTime, endTime, sidx, sord, page, rows);
    //    }

    //    /// <summary>
    //    /// 编辑（启用/禁用）委托信息
    //    /// </summary>
    //    /// <param name="delId">委托ID</param>
    //    /// <param name="editType">编辑类型（启用/禁用）</param>
    //    /// <returns>是否成功</returns>
    //    public bool EditDelegate(string delId, string editType)
    //    {
    //        DelegateSetting Entity = procTemplateService.GetDelegateSetting(Convert.ToInt32(delId));
    //        Entity.LastModifyUser = AppContext.CurrentUser.UserId;
    //        Entity.LastModifyUserName = AppContext.CurrentUser.UserName;
    //        Entity.LastModifyDate = System.DateTime.Now;
    //        bool isSuccess = false;
    //        if (editType.Equals("free"))//启用
    //        {

    //            Entity.IsEnabled = true;
    //        }
    //        else //禁用
    //        {
    //            Entity.IsEnabled = false;
    //        }
    //        try
    //        {
    //            procTemplateService.UpdateDelegateSetting(Entity);
    //            isSuccess = true;
    //        }
    //        catch
    //        {
    //            throw new Exception("更新失败");
    //        }
    //        return isSuccess;
    //    }

    //    /// <summary>
    //    /// 根据委托ID删除该条记录
    //    /// </summary>
    //    /// <param name="delId">委托ID</param>
    //    /// <returns>是否删除成功</returns>
    //    public bool DelDelegate(string delId)
    //    {
    //        bool isSuccess = false;
    //        int delID = 0;
    //        if (!int.TryParse(delId, out delID))
    //        {
    //            throw new Exception("传入错误的ID");
    //        }
    //        else if (delID <= 0)
    //        {
    //            throw new Exception("传入错误的ID");
    //        }
    //        try
    //        {
    //            procTemplateService.DelDelegateSetting(delID);
    //            isSuccess = true;
    //        }
    //        catch
    //        {
    //            throw new Exception("更新失败");
    //        }
    //        return isSuccess;
    //    }

    //    /// <summary>
    //    /// 保存委托数据
    //    /// </summary>
    //    /// <param name="procNames">流程集全名字符串，默认','分割</param>
    //    /// <param name="toUserNo">受托人工号字符串</param>
    //    /// <param name="toUserName">受托人姓名字符串</param>
    //    /// <param name="startTime">开始时间</param>
    //    /// <param name="endTime">结束时间</param>
    //    /// <returns></returns>
    //    [HttpPost]
    //    public ActionResult SaveDelegateData(string procNames, string procSetDesc, string toUserNo, string toUserName, string startTime, string endTime, string delId)
    //    {
    //        try
    //        {
    //            string[] arrToUser = toUserNo.TrimEnd(',').Split(',');
    //            string[] arrToUserName = toUserName.TrimEnd(',').Split(',');
    //            string[] arrProcess = procNames.TrimEnd(',').Split(',');
    //            string[] arrStartTime = startTime.TrimEnd(',').Split(',');
    //            string[] arrEndTime = endTime.TrimEnd(',').Split(',');
    //            string[] arrProcSetDesc = procSetDesc.TrimEnd(',').Split(',');

    //            if (string.IsNullOrEmpty(delId)) //新增
    //            {
    //                if (arrToUser.Length == arrToUserName.Length)
    //                {
    //                    List<DelegateSetting> list = new List<DelegateSetting>();
    //                    for (int i = 0; i < arrToUser.Length; i++)
    //                    {
    //                        DelegateSetting Entity = new DelegateSetting();
    //                        if (!string.IsNullOrEmpty(arrToUser[i]))
    //                        {
    //                            Entity.ToUser = arrToUser[i];
    //                            Entity.ToUserName = arrToUserName[i];
    //                            Entity.ProcessFullName = arrProcess[i];
    //                            Entity.StartTime = string.IsNullOrEmpty(arrStartTime[i]) ? DateTime.Now : DateTime.Parse(arrStartTime[i]);
    //                            Entity.EndTime = string.IsNullOrEmpty(arrEndTime[i]) ? DateTime.Now.AddYears(50) : DateTime.Parse(arrEndTime[i]);
    //                            Entity.FromUser = AppContext.CurrentUser.UserId;
    //                            Entity.FromUserName = AppContext.CurrentUser.UserName;
    //                            Entity.LastModifyUser = AppContext.CurrentUser.UserId;
    //                            Entity.LastModifyUserName = AppContext.CurrentUser.UserName;
    //                            Entity.LastModifyDate = System.DateTime.Now;
    //                            Entity.CreateTime = DateTime.Now;
    //                            Entity.CreateUser = AppContext.CurrentUser.UserId;
    //                            Entity.CreateUserName = AppContext.CurrentUser.UserName;
    //                            Entity.Comment = "委托";
    //                            Entity.IsEnabled = true;
    //                            Entity.IsRedirect = false;
    //                            Entity.ProcessName = arrProcSetDesc[i];
    //                            Entity.AppCode = UWFCommon.AppCode;
    //                            list.Add(Entity);
    //                        }
    //                    }
    //                    if (list.Count > 0)
    //                    {
    //                        procTemplateService.InsertDelegateSetting(list);
    //                    }
    //                }
    //            }
    //            else  //修改
    //            {
    //                DelegateSetting Entity = procTemplateService.GetDelegateSetting(Convert.ToInt32(delId));
    //                if (!string.IsNullOrEmpty(toUserNo))
    //                    Entity.ToUser = toUserNo;
    //                if (!string.IsNullOrEmpty(toUserName))
    //                    Entity.ToUserName = toUserName;
    //                Entity.LastModifyUser = AppContext.CurrentUser.UserId;
    //                Entity.LastModifyUserName = AppContext.CurrentUser.UserName;
    //                Entity.LastModifyDate = System.DateTime.Now;
    //                Entity.StartTime = string.IsNullOrEmpty(startTime) ? DateTime.Now : DateTime.Parse(startTime);
    //                Entity.EndTime = string.IsNullOrEmpty(endTime) ? DateTime.MaxValue : DateTime.Parse(endTime);
    //                procTemplateService.UpdateDelegateSetting(Entity);
    //            }
    //            return null;
    //        }
    //        catch (Exception e)
    //        {
    //            return Json(e.Message);
    //        }
    //    }
    //    #endregion

    //    /// <summary>
    //    /// 处理任务
    //    /// </summary>
    //    public ActionResult DealWithTask(string instanceId, string workflowType, string workflowName, string currentState, string procInstId, string actId, string sn, string procId, string formId)
    //    {

    //        if (string.IsNullOrEmpty(currentState))
    //        {
    //            currentState = "000";
    //        }

    //        else if (Request.Url != null && !string.IsNullOrEmpty(currentState))
    //        {
    //            var curState = currentState.Split('_')[0];
    //            return Redirect(GetUrlByBusinessType(workflowType) + curState + "?instanceId=" + instanceId
    //                + "&actMeta=" + curState
    //                + "&sN=" + sn
    //                + "&procInstId=" + procInstId
    //                + "&currentActId=" + actId
    //                + "&procId=" + procId
    //                + "&instanceName="
    //                + workflowName
    //                + "&formId=" + formId);
    //        }

    //        return null;
    //    }

    //    /// <summary>
    //    /// 查看任务
    //    /// </summary>
    //    public ActionResult DealWithTaskView(string instanceId, string workflowType, string workflowName, string currentState, string procInstId, string procId, string formId)
    //    {


    //        if (string.IsNullOrEmpty(currentState))
    //        {
    //            currentState = "000";
    //        }

    //        else if (Request.Url != null && !string.IsNullOrEmpty(currentState))
    //        {
    //            return Redirect(GetViewUrlByBusinessType(workflowType) + "?instanceId=" + instanceId + "&procId=" + procId + "&procInstId=" + procInstId + "&formId=" + formId);
    //        }

    //        return null;
    //    }


    //    /// <summary>
    //    /// 跳转到流程发起页面
    //    /// </summary>
    //    /// <param name="workflowType">流程类型</param>
    //    public ActionResult GoStartWorkflowPage(string workflowType)
    //    {
    //        return Redirect(GetUrlByBusinessType(workflowType) + "010");
    //    }


    //    /// <summary>
    //    /// 阅知任务
    //    /// </summary>
    //    public ActionResult ReadTaskInfo(string instanceId, string workflowType, string workflowName, string currentState, string procInstId, string actId, string sn)
    //    {

    //        if (string.IsNullOrEmpty(currentState))
    //        {
    //            currentState = "000";
    //        }

    //        else if (Request.Url != null && !string.IsNullOrEmpty(currentState))
    //        {
    //            var curState = currentState.Split('_')[0];
    //            return Redirect(GetUrlByBusinessType(workflowType) + curState + "?instanceId=" + instanceId + "&procInstId=" + procInstId + "&optionType=read&actId=" + actId + "&sn=" + sn);
    //        }

    //        return null;
    //    }

    //    /// <summary>
    //    /// 根据流程类型获取要跳转的URL
    //    /// </summary>
    //    /// <param name="workflowType"></param>
    //    /// <returns></returns>
    //    private string GetUrlByBusinessType(string workflowType)
    //    {
    //        string url = String.Empty;
    //        switch (workflowType)
    //        {
    //            case WorkflowTypeList.CashBonusTask_FullName:
    //                url += "~/BonusMgr/CashBonus";
    //                break;
    //        }
    //        url += "/Flow";
    //        return url;
    //    }

    //    /// <summary>
    //    /// 根据流程类型获取要跳转的查看URL
    //    /// </summary>
    //    /// <param name="workflowType"></param>
    //    /// <returns></returns>
    //    private string GetViewUrlByBusinessType(string workflowType)
    //    {
    //        string url = String.Empty;
    //        switch (workflowType)
    //        {
    //            case WorkflowTypeList.CashBonusTask_FullName:
    //                url += "~/BonusMgr/CashBonus";
    //                break;
    //        }
    //        url += "/Flow999/";
    //        return url;
    //    }

    //    /// <summary>
    //    /// 流程图输出
    //    /// </summary>
    //    [HttpGet]
    //    [OutputCache(Duration = 0, VaryByParam = "none")]
    //    public PartialViewResult WorkflowImage(string imgUrl)
    //    {
    //        if (!string.IsNullOrEmpty(imgUrl))
    //        {
    //            string filename = Server.MapPath("~/Content/PSCWorkflow/") + imgUrl;
    //            FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
    //            byte[] mydata = new byte[fs.Length];
    //            int Length = Convert.ToInt32(fs.Length);
    //            fs.Read(mydata, 0, Length);
    //            fs.Close();
    //            this.Response.OutputStream.Write(mydata, 0, Length);
    //            this.Response.Flush();
    //            //输出后删除本地文件
    //            System.IO.File.Delete(filename);
    //            this.Response.End();
    //        }
    //        return PartialView();
    //    }

    //    /// <summary>
    //    /// 根据实例编号流程版本号显示流程图
    //    /// </summary>
    //    /// <param name="procInstId">流程实例编号</param>
    //    /// <param name="procId">流程版本号</param>
    //    public ActionResult FlowView(string procInstId, string procId)
    //    {
    //        int id = 0;
    //        if (!int.TryParse(procInstId, out id))
    //        {
    //            throw new Exception("传入错误的ID");
    //        }
    //        else if (id <= 0)
    //        {
    //            throw new Exception("传入错误的ID");
    //        }

    //        ServiceFactory factory = UWFCommon.GetServiceFactory();
    //        CIT.PSC.Client.Service.ProcInstState service = factory.ProcInstState;
    //        service.ReqCondition = UWFCommon.GetServiceRequestCondition();

    //        try
    //        {
    //            service.OnViewFlow(AppContext.CurrentUser.UserId, id.ToString());
    //        }
    //        catch
    //        {
    //            return null;
    //        }

    //        string strViewXML = "";
    //        string sViewFlowImageFolder = "~/Content/PSCWorkflow/";

    //        ViewBag.ProcInstId = id;
    //        string fullPath = null;
    //        fullPath = Server.MapPath(sViewFlowImageFolder);

    //        strViewXML = service.GetFlowViewXmlString(id);
    //        FlowViewStateInfo info = service.GetFlowViewStateInfoByProcInstID(id);
    //        IProcessImageView vcp = new ProcessImageView();

    //        strViewXML = vcp.ClearLoopLine(strViewXML);

    //        strViewXML = vcp.HideLine(strViewXML, info.HiddenLineID);
    //        strViewXML = vcp.ChangeFlowViewState(strViewXML, info);

    //        string actID_010 = null;

    //        strViewXML = vcp.RemoveStartAct(strViewXML, out actID_010);

    //        ViewBag.ActID010 = actID_010;
    //        ViewBag.ProcID = procId;

    //        string sImageName = null;
    //        sImageName = vcp.ViewImageName(strViewXML, id, fullPath);

    //        ViewBag.ImgUrl = sImageName;

    //        ViewBag.JS = vcp.GetReturnJS().ToString();

    //        return View();
    //    }

    //    /// <summary>
    //    /// 根据版本号查看流程图（主要用于没有发起流程的流程图查看）
    //    /// </summary>
    //    /// <param name="procId">流程版本号</param>
    //    public ActionResult ProcSetFlowView(string procId)
    //    {
    //        int id = 0;
    //        if (!int.TryParse(procId, out id))
    //        {
    //            throw new Exception("传入错误的ID");
    //        }
    //        else if (id <= 0)
    //        {
    //            throw new Exception("传入错误的ID");
    //        }

    //        ServiceFactory factory = UWFCommon.GetServiceFactory();
    //        CIT.PSC.Client.Service.ProcInstState service = factory.ProcInstState;
    //        service.ReqCondition = UWFCommon.GetServiceRequestCondition();

    //        try
    //        {
    //            service.OnViewFlow(null, id.ToString());
    //        }
    //        catch
    //        {
    //            return null;
    //        }

    //        string strViewXML = "";
    //        string sViewFlowImageFolder = "~/Content/PSCWorkflow/";

    //        string fullPath = null;
    //        fullPath = Server.MapPath(sViewFlowImageFolder);

    //        strViewXML = service.GetProcSetFlowViewXmlString(id);

    //        List<string> hideLinesID = service.GetFlowViewHideLinesByProcID(id);

    //        IProcessImageView vcp = new ProcessImageView();

    //        strViewXML = vcp.ProcVerViewImgRemoveStartAndLoopLine(strViewXML);

    //        strViewXML = vcp.HideLine(strViewXML, hideLinesID);

    //        string sImageName = null;
    //        sImageName = vcp.ViewImageName(strViewXML, id, fullPath);

    //        ViewBag.ImgUrl = sImageName;
    //        ViewBag.ProcID = procId;
    //        ViewBag.JS = vcp.GetReturnJS().ToString();
    //        return View();
    //    }

    //    /// <summary>
    //    /// 根据版本号、流程实例编号以及环节编号
    //    /// 显示该环节的处理步骤
    //    /// </summary>
    //    /// <param name="procId">流程版本号</param>
    //    /// <param name="procInstId">流程实例编号</param>
    //    /// <param name="actId">环节编号</param>
    //    public string GetWorkItem(string procId, string procInstId, string actId)
    //    {
    //        AscBimsServices.BIMS_WebServiceSoapClient client = new AscBimsServices.BIMS_WebServiceSoapClient();

    //        ServiceFactory factory = UWFCommon.GetServiceFactory();
    //        CIT.PSC.Client.Service.WorkListItems service = factory.WorkListItems;
    //        service.ReqCondition = UWFCommon.GetServiceRequestCondition();
    //        ProcessLogQuery query = new ProcessLogQuery();
    //        QueryPaging queryPaging = new CIT.PSC.Service.Entity.Query.QueryPaging();
    //        queryPaging.PageSize = 10;
    //        queryPaging.StartPage = 1;
    //        query.PageSetting = queryPaging;
    //        query.ProcInstID = procInstId;

    //        ProcessLogFilter filter = new ProcessLogFilter();
    //        filter.Field = ProcessLogField.ActID;
    //        filter.Operatoer = QueryOperator.Equal;
    //        filter.Value = actId;

    //        query.Conditions.Add(filter);

    //        ProcessTraceResult Results = service.GetWorkListItemTrace(query);

    //        //根据流程实例和环节ID获取审批记录
    //        List<ProcessTrace> list = Results.ProcessTraces;

    //        StringBuilder sTb = new StringBuilder();

    //        if (list != null && list.Count > 0)
    //        {
    //            foreach (ProcessTrace log in list)
    //            {
    //                sTb.Append("<tr style='font-size:12px'>");
    //                if (log.ProcessLogDTO.ApproverAccount.StartsWith("K2"))
    //                {
    //                    string[] arr = log.ProcessLogDTO.ApproverAccount.Split('\\');
    //                    sTb.Append("<td>" + client.StaffSByStaffNO(arr[1], ascKey).STAFF_NAME + "[" + arr[1] + "]</td>");
    //                }
    //                else
    //                {
    //                    //sTb.Append("<td>" + client.StaffSByStaffNO(log.ProcessLogDTO.ApproverAccount, ascKey).STAFF_NAME + "[" + log.ProcessLogDTO.ApproverAccount + "]</td>");
    //                    sTb.Append("<td>" + log.ProcessLogDTO.ApproverChsName + "[" + log.ProcessLogDTO.ApproverAccount + "]</td>");
    //                }

    //                sTb.Append("<td>" + log.ProcessLogDTO.StartDate + "</td>");
    //                sTb.Append("<td>" + log.ProcessLogDTO.FinishDate + "</td>");

    //                //处理下一环节信息
    //                StringBuilder sb = new StringBuilder();
    //                sb.Append("");
    //                if (log.NextActInfo != null && log.NextActInfo.Count > 0)
    //                {
    //                    sb.Append("<table class='processLogTable' cellpadding='2' cellspacing='0' style='font-size:12px;border-collapse:collapse' width=100% height=100%>");
    //                    foreach (NextActivityInfo nat in log.NextActInfo)
    //                    {
    //                        sb.Append("<tr>");
    //                        sb.Append("<td>" + nat.NextActivityName + "</td>");
    //                        sb.Append("</tr>");
    //                    }
    //                    sb.Append("</table>");
    //                }
    //                sTb.Append("<td>" + sb.ToString() + "</td>");

    //                //处理任务状态
    //                sTb.Append("<td>" + this.GetStatusByAction(log.ProcessLogDTO.Finished, log.ProcessLogDTO.Action, log.ProcessLogDTO.HasRead, log.ProcessLogDTO.OperationType) + "</td>");
    //                sTb.Append("<td>" + log.ProcessLogDTO.Comment + "</td>");
    //                sTb.Append("</tr>");
    //            }

    //            if (Results.Paging.TotalCount > query.PageSetting.PageSize)
    //            {
    //                sTb.Append("<tr style='font-size:12px'>");
    //                sTb.Append("<td colspan=6>");
    //                sTb.Append("记录总数为:" + Results.Paging.TotalCount.ToString() + "行,目前显示前:" + query.PageSetting.PageSize + "行" + "详细请点击:" + "<a href='DoneTaskLogList.aspx?ProcInstID=" + procInstId + "&ProcID=" + procId + "' target=_blank>办文跟踪</a>");
    //                sTb.Append("</td>");
    //                sTb.Append("</tr>");
    //            }

    //            sTb.Insert(0, "<table class='processLogTable' style='font-size:12px;border-collapse:collapse;border-color:#999999' cellpadding='2' cellspacing='0' border='1'>" +
    //                                        "<tr><td align='center' style=display:block>审批人</td><td align='center' style=display:block>接收时间</td><td align='center' style=display:block>处理时间</td><td align='center' style=display:block>业务流向</td><td align='center' style=display:block>状态</td><td align='center' style=display:block>审批意见</td></tr>");

    //            sTb.Append("</table>");

    //            return sTb.ToString();
    //        }

    //        return null;
    //    }

    //    /// <summary>
    //    /// 获取流程状态
    //    /// </summary>
    //    /// <param name="finished"></param>
    //    /// <param name="action"></param>
    //    /// <param name="hasRead"></param>
    //    /// <param name="optType"></param>
    //    /// <returns></returns>
    //    private string GetStatusByAction(int finished, int action, int hasRead, int optType)
    //    {
    //        string returnStatus = string.Empty;

    //        if (finished == 1 || action == SubmitActionType.SubmitEnd.Value)
    //        {
    //            switch (action)
    //            {
    //                case SubmitActionType.ROLLBACKGOBACK: returnStatus = "退回"; break;
    //                case SubmitActionType.WITHDRAW: returnStatus = "撤回"; break;
    //                case SubmitActionType.SUBMITEND: returnStatus = "新收到"; break;
    //                case SubmitActionType.AUTOEND: returnStatus = "自动完成"; break;
    //                default: returnStatus = "已办理"; break;
    //            }
    //        }
    //        else
    //        {
    //            if (hasRead == 1)
    //            {
    //                returnStatus = "已阅读";
    //            }
    //            else
    //            {
    //                switch (optType)
    //                {
    //                    case OperationType.GOBACK:
    //                        {
    //                            returnStatus = "被退回";
    //                        } break;
    //                    case OperationType.READGOBACK:
    //                        {
    //                            returnStatus = "被退回";
    //                        } break;
    //                    case OperationType.READGOBACKMERGETASK:
    //                        {
    //                            returnStatus = "被退回";
    //                        } break;
    //                    case OperationType.GOBACKMERGETASK:
    //                        {
    //                            returnStatus = "被退回";
    //                        } break;
    //                    case OperationType.WITHDRAW:
    //                        {
    //                            returnStatus = "已阅读";
    //                        } break;
    //                    case OperationType.WITHDRAWMERGETASK:
    //                        {
    //                            returnStatus = "已阅读";
    //                        } break;
    //                    default:
    //                        {
    //                            returnStatus = "新收到";
    //                        } break;
    //                }
    //            }
    //        }

    //        return returnStatus;
    //    }
    }
}
