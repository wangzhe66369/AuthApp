﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWIS.Presentation.Web.ViewModels.PscViewModels
{
    public class PscWorkflowVM
    {
        public string InstanceId { get; set; }


        public string InstanceName { get; set; }

        public string ProcId { get; set; }

        public string ProcInstId { get; set; }

        public string OptionType { get; set; }

        public string ActMeta { get; set; }

        public string ActName { get; set; }

        public string SN { get; set; }

        public string CurrentActId { get; set; }

        public string FormId { get; set; }

    }
}