﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NET01.Infrastructure.Workflow;
using NET01.Presentation.Web.Mvc.JqGrid;

namespace RWIS.Presentation.Web.ViewModels.PscViewModels
{
    public class PSCWorkflowTaskVM
    {
        /// <summary>
        /// 任务名称
        /// </summary>
        public string TaskName { get; set; }

        /// <summary>
        /// 审批件
        /// </summary>
        public PagedViewModel<ApprovalInstance> PagedViewModel { get; set; }
    }
}