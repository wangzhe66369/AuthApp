﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NET01.CoreFramework;
using CIT.App.Lib.Uwf.Model;

namespace RWIS.Presentation.Web.ViewModels.PscViewModels
{
    public class DealWithVM
    {
        /// <summary>
        /// 当前环节信息
        /// </summary>
       // public WfCfgAct CurActInfo { get; set; }

        /// <summary>
        /// 处理人姓名[工号]
        /// </summary>
        public string NextFormatPerson
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(NextPersonNos) && !string.IsNullOrWhiteSpace(NextPersonNames))
                {
                    return string.Format("{0}[{1}]", NextPersonNames, NextPersonNos);
                }
                else
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// 下一步办理人工号
        /// </summary>
        public string NextPersonNos { get; set; }

        /// <summary>
        /// 下一步办理人姓名
        /// </summary>
        public string NextPersonNames { get; set; }

        /// <summary>
        /// 抄送人工号
        /// </summary>
        public string CopyPersonNos { get; set; }

        /// <summary>
        /// 抄送人姓名
        /// </summary>
        public string CopyPersonNames { get; set; }

        /// <summary>
        /// 下一步处理人
        /// </summary>
        public List<UWFUser> NextPersons
        {
            get
            {
                if (string.IsNullOrEmpty(this.NextPersonNos))
                {
                    return null;
                }
                string[] userNos = this.NextPersonNos.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                string[] userNames = this.NextPersonNames.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);


                if (userNos.Length > 0)
                {
                    if (userNos.Length < userNames.Length)
                    {
                        throw new ArgumentNullException("下一步处理人用户工号与用户姓名字符串不匹配");
                    }
                    List<UWFUser> users = new List<UWFUser>();
                    for (int i = 0; i < userNos.Length; i++)
                    {
                        string userNo = userNos[i];
                        string userName = userNames[i];
                        UWFUser user = new UWFUser();
                        user.UserId = userNo;
                        user.UserName = userName;
                        users.Add(user);
                    }
                    return users;
                }
                else
                {
                    return null;
                }
            }
        }


        /// <summary>
        /// 抄送人
        /// </summary>
        public List<UWFUser> CopyPersons
        {
            get
            {
                if (string.IsNullOrEmpty(this.CopyPersonNos))
                {
                    return null;
                }
                string[] userNos = this.CopyPersonNos.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                string[] userNames = this.CopyPersonNames.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);


                if (userNos.Length > 0)
                {
                    if (userNos.Length < userNames.Length)
                    {
                        throw new ArgumentNullException("抄送人用户工号与用户姓名字符串不匹配");
                    }
                    List<UWFUser> users = new List<UWFUser>();
                    for (int i = 0; i < userNos.Length; i++)
                    {
                        string userNo = userNos[i];
                        string userName = userNames[i];
                        UWFUser user = new UWFUser();
                        user.UserId = userNo;
                        user.UserName = userName;
                        users.Add(user);
                    }
                    return users;
                }
                else
                {
                    return null;
                }
            }
        }


        /// <summary>
        /// 目标列表
        /// </summary>
        //public IList<WfCfgAct> TargetActList { get; set; }

        /// <summary>
        /// 环节出线列表
        /// </summary>
        //public IList<WfCfgLine> LineList { get; set; }

        /// <summary>
        /// 发起或提交时传递的ControllorName
        /// </summary>
        public string ControllorName { get; set; }

        /// <summary>
        /// 发起或提交时传递的ActionName
        /// </summary>
        public string ActionName { get; set; }

        /// <summary>
        /// 发起或提交时传递的AreaName
        /// </summary>
        public string AreaName { get; set; }

        /// <summary>
        /// 流程实例ID
        /// </summary>
        public string ProcInstId { get; set; }

        /// <summary>
        /// PSC传过来的流程序列号，用于流程审批实例的初始化
        /// </summary>
        public String SN { get; set; }
    }
}