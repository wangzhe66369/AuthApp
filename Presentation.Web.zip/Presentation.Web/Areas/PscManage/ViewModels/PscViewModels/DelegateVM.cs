﻿/********************************************************************************
 *
 *   项目名称   ：   RWIS
 *   文 件 名   ：   DelegateVM.cs
 *   描    述   ：   流程委托ViewModel
 *   创 建 者   ：   PCITABC 
 *   创建日期   ：   2013-07-19 10:17:15
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2013-07-19 10:17:15    1.0.0.0     PCITABC       初版　 
 *    
 *
 *   
 *******************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RWIS.Presentation.Web.ViewModels.PscViewModels
{
    /// <summary>
    /// 委托ViewModel
    /// </summary>
    public class DelegateVM
    {
        /// <summary>
        /// 使用状态数据源
        /// </summary>
        public List<SelectListItem> EnableType { get; set; }
        /// <summary>
        /// 流程类型数据源
        /// </summary>
        public List<SelectListItem> WorkFlowType { get; set; }
        /// <summary>
        /// 流程集列表
        /// </summary>
        public List<CIT.App.Lib.Uwf.Model.ProcsetCfg> ProcSetList { get; set; }
    }
}