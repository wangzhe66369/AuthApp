﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CIT.PSC.Service.Entity.DTO;


namespace RWIS.Presentation.Web.ViewModels.PscViewModels
{
    public class WorkflowLogVM
    {
        /// <summary>
        /// 流程日志列表
        /// </summary>
        public IList<ProcessTrace> WorkflowLogList { get; set; }

        /// <summary>
        /// 流程实例ID
        /// </summary>
        public string ProcInstID { get; set; }

        /// <summary>
        /// 环节ID
        /// </summary>
        public string ActID { get; set; }
    }
}