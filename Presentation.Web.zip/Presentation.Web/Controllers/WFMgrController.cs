﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CIT.App.Lib.Uwf.Model;
using NET01.CoreFramework;
using RWIS.Presentation.Web.Core;
using CIT.App.Lib.Uwf.Client.Service;
using CIT.App.Lib.Uwf.Client.Configs;
using CIT.App.Lib.Uwf.Client.Factory;
using RWIS.Presentation.Web.ViewModelBuilder.PscVMBuilder;
using CIT.PSC.Service.Entity.DTO;
using RWIS.Presentation.Web.Core.Filter;

namespace RWIS.Presentation.Web.Controllers
{
    [ExcuteTime()]
    public class WFMgrController : CommonControllerBase
    {

        /// <summary>
        /// 获取下一处理环节列表
        /// </summary>
        /// <param name="procInstId">流程实例编号</param>
        /// <param name="procId">流程号</param>
        /// <param name="sn">工作任务号</param>
        /// <param name="actId">当前节点编号</param>
        /// <returns></returns>
        public JsonResult GetNextActList(string procInstId, string procId, string sn, string actId)
        {
            var route = new CIT.App.Lib.Uwf.Client.Service.AutoRoute();

            List<ActRoute> actRouteList = new List<ActRoute>();

            try
            {
                actRouteList = route.GetAutoRoute(procInstId, procId, sn, actId, AppContext.CurrentUser.UserId);
                actRouteList = actRouteList.FindAll(t => t.Name == "同意");
                if (actRouteList != null)
                {
                    actRouteList = actRouteList.OrderBy(t => t.OrderIndex).ToList();
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex);
            }
            return Json(actRouteList, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 获取退回节点列表
        /// </summary>
        /// <param name="procInstId">流程实例编号</param>
        /// <param name="procId">流程号</param>
        /// <param name="actId">当前节点编号</param>
        /// <returns></returns>
        public JsonResult GetGoBackList(string procInstId, string procId, string actId)
        {
            var autoRoute = new AutoRoute();

            List<ActRoute> list = new List<ActRoute>();

            try
            {
                list = autoRoute.GetBackRoute(procInstId, procId, actId);

                IList<ProcessTrace> logList = PSCWorkflowTaskVMBuilder.GetProcessTraceList(procInstId, "", "", 1, 100);
                if (logList != null)
                {
                    list = list.FindAll(p => logList.Any(l => l.ProcessLogDTO.ActID.ToString() == p.TargetActID));
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex);
            }
            return Json(list);
        }


        /// <summary>
        /// 获取下一步处理人
        /// </summary>
        /// <param name="procInstId">流程实例编号</param>
        /// <param name="procId">流程号</param>
        /// <param name="sn">工作任务号</param>
        /// <param name="actId">当前节点编号</param>
        /// <param name="targetId">目标节点号</param>
        /// <returns></returns>
        public JsonResult GetNextProcessUser(string procInstId, string procId, string sn, string actId, string targetId)
        {
            List<UWFUser> actRouteList = new List<UWFUser>();
            string IsRepickUser = "Y";
            try
            {
                var autoRole = new AutoRole();
                ActRoute actRoute = new ActRoute();
                actRouteList = autoRole.GetAutoRole(procInstId, procId, sn, actId, targetId, AppContext.CurrentUser.UserId);
                if (actRouteList == null)
                {
                    actRouteList = new List<UWFUser>();
                }
                WorkflowConfig wfConfig = ServiceFactory.Instance.WorkflowConfig;
                ActCfg actCfg = wfConfig.GetActByProcIdAndActId(procId, targetId);
                if (actCfg != null)
                {
                    IsRepickUser = actCfg.IsRepickUser;
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex);
            }

            return Json(new { IsRepickUser = IsRepickUser, UserList = actRouteList });
        }

        /// <summary>
        /// 根据退回节点获取下一步处理人
        /// </summary>
        /// <param name="procInstId">流程实例编号</param>
        /// <param name="procId">流程号</param>
        /// <param name="sn">工作任务号</param>
        /// <param name="actId">当前节点编号</param>
        /// <param name="targetId">目标节点号</param>
        /// <returns></returns>
        public ActionResult GetBackProcessUser(string procInstId, string procId, string sn, string actId, string targetId)
        {

            var autoRole = new AutoRole();

            List<UWFUser> list = new List<UWFUser>();

            try
            {
                list = autoRole.GetBackRole(procInstId, procId, sn, actId, targetId, string.Empty);
            }
            catch (Exception ex)
            {
                Log.LogError(ex);
            }
            return Json(list, JsonRequestBehavior.AllowGet);

        }

    }
}
