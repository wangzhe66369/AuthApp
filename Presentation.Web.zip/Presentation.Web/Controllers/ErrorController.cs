﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using NET01.CoreFramework.Mail;
using Microsoft.Practices.ServiceLocation;
using RWIS.Presentation.Web.Core;
using CIT.App.Lib.Uwf.Model;
using CIT.App.Lib.Uwf.Client.Service;
using NET01.CoreFramework;

namespace RWIS.Presentation.Web.Controllers
{
    /// <summary>
    /// 错误处理Controller
    /// </summary>
    public class ErrorController : CommonControllerBase
    {

        public ActionResult General()
        {
            string linkStaffName = string.Format("{0}[{1}]", ConfigurationManager.AppSettings["linkStaffName"], ConfigurationManager.AppSettings["linkStaffNO"]);
            string linkNumber = ConfigurationManager.AppSettings["linkNumber"];
            ViewBag.linkStaffName = linkStaffName;
            ViewBag.linkNumber = linkNumber;

            return View("Error");
        }

        public ActionResult NotFound()
        {
            this.ViewBag.Message = "找不到对应的请求页面！";
            return View("Error");
        }

        public ActionResult ServerConfigError()
        {
            this.ViewBag.Message = "服务器配置出错！";
            return View("Error");
        }

        public ActionResult DenyAccess()
        {
            this.ViewBag.Message = "对不起！你没有页面访问权限！";
            return View("Error");
        }

        

    }
}
