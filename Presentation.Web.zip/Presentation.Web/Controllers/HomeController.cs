﻿/********************************************************************************
 *
 *   项目名称   ：   标准化架构
 *   文 件 名   ：   HomeController.cs
 *   描    述   ：   Home Controller
 *   创 建 者   ：   框架人员
 *   创建日期   ：   2012-02-13 15:00:00
 *    
 *
 *　----------------变更历史----------------------------------------------------　 
 *   修改日期                版本       修改者       修改内容
 *   2012-02-13 15:00:00    1.0.0.0    框架人员       初版　 
 *    
 *
 *   
 *   
 *******************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.Mvc;
using CIT.UBA.StatServices;

using RWIS.Presentation.Web.Core;
using RWIS.Infrastructure.Crosscutting;
using NET01.Infrastructure.Workflow;
using CIT.App.Lib.SSO.SSOClient;
using Microsoft.Practices.ServiceLocation;
using NET01.Infrastructure.ORG;
using NET01.Infrastructure.Authorization;
using RWIS.Presentation.Web.Core.Filter;
using NET01.CoreFramework;
using RWIS.Presentation.Web.AscBimsServices;
using RWIS.Domain.DomainObjects;
using RWIS.Presentation.Web.Core.Globalization;
using System.Configuration;
using RWIS.Presentation.Web.Core.Login;
using RWIS.Domain.Repositories;
using RWIS.Presentation.Web.Core.Common;
using RWIS.Presentation.Web.Areas.SystemManage.ViewModels;
using UpcAuthClient = CIT.UPC.Authorization.Client;
using CIT.UPC.Authorization.Client;

namespace RWIS.Presentation.Web.Controllers
{
    /// <summary>
    /// Home Controller
    /// </summary>
    [ExcuteTime()]
    public class HomeController : Controller
    {
        LoginUser loginModel = null;

        /// <summary>
        /// 登录
        /// </summary>
        /// <returns></returns>
        public void Default()
        {

            string userId = String.Empty;

            //登录
            if (AppSetting.Instance.LoginMode == "Domain")
            {
                try
                {
                    userId = LoginInfo.GetDomainUser();
                    if (LoginInfo.SaveLoginInfo(userId))
                    {
                        if (AppContext.CurrentUser == null || AppContext.CurrentUser.UserId == "")
                        {
                            Response.Redirect("~/Home/Login", true);
                        }
                        else
                        {
                            Response.Redirect("~/Home/Index", true);
                        }
                    }
                    else
                    {
                        Response.Redirect("~/Home/Login", true);
                    }
                }
                catch
                {
                    Response.Redirect("~/Home/Login", true);
                }
            }
            else if (AppSetting.Instance.LoginMode == "SSO")
            {
                IClient ssoClient = new AppClient();
                if (ssoClient.Login(out userId))
                {
                    if (LoginInfo.SaveLoginInfo(userId))
                    {
                        Response.Redirect("~/Home/Index", true);
                    }
                    else
                    {
                        Response.Write(userId);
                    }
                }
                else
                {
                    Response.Write(userId);
                }
            }
            else// if (AppSetting.Instance.LoginMode == "Forms")
            {
                Response.Redirect("~/Home/Login", true);
            }

        }

        [UbaFilter(OperateType = OperateType.Page, OperateDescription = "系统首页")]
        public ActionResult Index()
        {
            if (AppContext.CurrentUser == null)
            {
                Response.Redirect("~/Home/Default", true);
                return null;
            }
            else
            {
                //得到某个人对应的约束
                string stationCodes = "";
                string constraintCodes = GetStations(out stationCodes);
                ViewBag.ViewProjects = stationCodes;

                //登录时设置语言
                string lang = string.Empty;
                lang = GlobalizationManager.GetRequestLanguage();
                if (string.IsNullOrWhiteSpace(lang))
                {
                    lang = AppSetting.Instance.DefaultLanguage;
                }
                GlobalizationManager.SetCurrentCulture(lang);

                ViewBag.UserNo = AppContext.CurrentUser.UserId.ToUpper();
                ViewBag.UserName = AppContext.CurrentUser.UserName;
                ViewBag.DeptName = AppContext.CurrentUser.DeptName;
                //从Session中获取解码后的TargetUrl
                ViewBag.TargetUrl = this.GetDecodeTargetUrlFromSession();
                try
                {
                    // MenuBuilder menuBuilder = new HardCodingMenuBuilder(this);//直接编码生成菜单
                  MenuBuilder menuBuilder = new UpcMenuBuilder(this);//根据框架集成的授权模块/统一授权中心生成菜单
                    ViewBag.MenuHtml = menuBuilder.GetMenuJavaScript();
                }
                catch
                {
                    MenuBuilder menuBuilder = new HardCodingMenuBuilder(this);//直接编码生成菜单
                    ViewBag.MenuHtml = menuBuilder.GetMenuJavaScript();
                }
                return View();
            }
        }

        #region 切换项目
        public JsonResult ChangeProject(ProjectVM vm)
        {
            AppContext.CurrentUser.ProjectCode = vm.ProjectCode;
            if (AppContext.CurrentUser.ProjectCode != vm.ProjectCode)
            {
                return Json(new { result = false, message = "切换电站失败" }, JsonRequestBehavior.AllowGet);
            }
            UpdateStation(AppContext.CurrentUser.UserId, vm.ProjectCode);
            return Json(new { result = true, message = "切换电站成功" }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 把登陆信息存入数据库或者更新数据库
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="stationCode"></param>
        /// <returns></returns>
        public JsonResult UpdateStation(string userId, string stationCode)
        {
            IUserLoginInfoRepository iUserLoginInfoRepository = ServiceLocator.Current.GetInstance<IUserLoginInfoRepository>();
            string projectId = iUserLoginInfoRepository.GetStationCode(userId, stationCode);
            UserLoginInfo loginInfo = null;
            if (string.IsNullOrEmpty(projectId))
            {
                loginInfo = new UserLoginInfo();
                loginInfo.UserCode = userId;
                loginInfo.StationCode = stationCode == null ? "CC" : stationCode;
                loginInfo.LoginId = Guid.NewGuid().ToString();
                iUserLoginInfoRepository.Create(loginInfo);
            }
            else
            {
                loginInfo = iUserLoginInfoRepository.GetUserLoginInfo(userId);
                loginInfo.StationCode = stationCode == null ? "CC" : stationCode;
                iUserLoginInfoRepository.Update(loginInfo);
            }

            iUserLoginInfoRepository.UnitOfWork.Commit();

            return Json(new { result = true, message = "更新成功" }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// 得到当前登陆者所在的电站
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetCurrentStation()
        {
            IUserLoginInfoRepository iUserLoginInfoRepository = ServiceLocator.Current.GetInstance<IUserLoginInfoRepository>();
            string stationInfo = string.Empty;
            string stationName = string.Empty;
            string stationCode = iUserLoginInfoRepository.GetStationCode(AppContext.CurrentUser.UserId,AppContext.CurrentUser.ProjectCode);
            if (!string.IsNullOrEmpty(stationCode))
            {
                AppContext.CurrentUser.ProjectCode = stationCode;
                IBasicWasteUnitRepository _basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
                IQueryable<BasicWasteUnit> query = _basicWasteUnitRepository.GetAll().AsQueryable().Where(c=>c.SimpleCode.ToUpper().Trim()==stationCode.ToUpper().Trim());
                if (query.Count() > 0)
                {
                    stationName = query.ToList()[0].UnitName;
                }
            }
            stationInfo = stationCode + "," + stationName;
            return JsonResultHelper.JsonResult(true, stationInfo);
        }

        public string GetStations(out string stationCodes)
        {
            stationCodes = "";
            IUserLoginInfoRepository iUserLoginInfoRepository = ServiceLocator.Current.GetInstance<IUserLoginInfoRepository>();
            IBasicWasteUnitRepository _basicWasteUnitRepository = ServiceLocator.Current.GetInstance<IBasicWasteUnitRepository>();
            IQueryable<BasicWasteUnit> iqueryWasteUnit = _basicWasteUnitRepository.GetAll().AsQueryable().Where(c => c.Status == "2" && c.IsStart == "1" && (c.ParentUnitID == "" || c.ParentUnitID == null));
            List<SelectListItem> list = new List<SelectListItem>();
            foreach (var wasteUnit in iqueryWasteUnit)
            {
                SelectListItem item = new SelectListItem();
                item.Text = wasteUnit.UnitName;
                item.Value = wasteUnit.SimpleCode;
                list.Add(item);
            }
            string stationCode = iUserLoginInfoRepository.GetStationCode(AppContext.CurrentUser.UserId, AppContext.CurrentUser.ProjectCode);
            string stations = string.Empty;
            foreach (var item in list)
            {
                if (!string.IsNullOrEmpty(stationCode) && item.Value == stationCode.ToUpper())
                {
                    item.Selected = true;
                    stations += item.Text + "," + item.Value + "," + "1" + ";";
                }
                else
                {
                    stations += item.Text + "," + item.Value + "," + "0" + ";";
                }
                stationCodes += item.Value + ",";

            }
            if (stationCodes.Length > 0)
            {
                stationCodes = stationCodes.TrimEnd(',');
            }
            if (stations.Length > 0)
            {
                stations = stations.TrimEnd(';');
            }
            return stations;
        }
        /// <summary>
        /// 得到电站列表
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetStationList()
        {
            string stationCodes = "";
            string stations = GetStations(out stationCodes);
            return JsonResultHelper.JsonResult(true, stations);
        }
        #endregion

        /// <summary>
        /// 系统界面欢迎页
        /// </summary>
        [LoginRequired]
        public ActionResult Welcome()
        {
            //得到某个人对应的约束
            string stationCodes = "";
            string constraintCodes = GetStations(out stationCodes);
            ViewBag.ViewProjects = constraintCodes;
           
            //得到角色信息
            string roleCodes = "";
            UpcAuthClient.IAuthorization auth = UpcAuthClient.AuthorizationFactory.Create();
            Role[] arrRole=auth.GetUserRols(AppContext.CurrentUser.UserId,AppContext.CurrentUser.ProjectCode);
            if (arrRole != null && arrRole.Length > 0)
            {
                foreach (var item in arrRole)
                {
                    roleCodes += item.RoleCode + ",";
                }
            }
            if (roleCodes.Length > 0) roleCodes = roleCodes.TrimEnd(',');
            ViewBag.ViewRoles = roleCodes;
            return View();
        }
        /// <summary>
        /// 用户登出
        /// </summary>
        public void LogOut()
        {
            //取消当前会话
            this.Session.Abandon();

            //清除Cookies
            foreach (string cookieName in Request.Cookies.AllKeys)
            {
                HttpCookie cookie = new HttpCookie(cookieName);
                cookie.Expires = DateTime.Today.AddDays(-1);
                Response.Cookies.Add(cookie);
            }
            if (AppSetting.Instance.LoginMode == "SSO")//SSO
            {
                IClient ssoClient = new AppClient();
                ssoClient.LogOut();
            }
            else
            {
                Response.Redirect("~/Home/Login", true);
            }
        }

        /// <summary>
        /// 关于
        /// </summary>
        public ActionResult About()
        {
            return View();
        }
        public ActionResult Login()
        {
            ViewBag.ProjectName = AppSetting.Instance.SystemName;
            return View();
        }
        [HttpPost]
        public JsonResult Login(LoginUser model, FormCollection collection)
        {
            try
            {
                loginModel = model;
                if (model.LoginUserName != null && model.LoginUserPassword != null)
                {
                    bool isTest = AppSetting.Instance.IsTest == "true";
                    bool isLoginSuccess = false;
                    if (isTest)
                    {
                        isLoginSuccess = model.LoginUserPassword == AppSetting.Instance.FormsLoginPassword;
                    }
                    else
                    {
                        UserLoginForDomain loginForDomain = new UserLoginForDomain();
                        isLoginSuccess = loginForDomain.impersonateValidUser(model.LoginUserName, AppSetting.Instance.Domain, model.LoginUserPassword);
                    }

                    if (SaveLoginInfo(model.LoginUserName) && isLoginSuccess == true)
                    {
                        return Json(new { result = true, message = "登录成功！" }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        return Json(new { result = false, message = "登录失败,用户名或密码错误" }, JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json(new { result = false, message = "登录失败,用户名或密码错误" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                return Json(new { result = false, message = "登录失败," + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }


        private bool SaveLoginInfo(string userId)
        {
            IUserLoginInfoRepository iUserLoginInfoRepository = ServiceLocator.Current.GetInstance<IUserLoginInfoRepository>();
            UserLoginInfo loginInfo = iUserLoginInfoRepository.GetUserLoginInfo(userId);
            string defaultStationCode = ConfigurationManager.AppSettings["DefaultConstraint"];
            if (loginInfo != null)
            {
                defaultStationCode = loginInfo.StationCode;
            }

            ApplicationUser user = new ApplicationUser();
            BIMS_WebServiceSoapClient client = new BIMS_WebServiceSoapClient();

            var ascBimsServcieDomain = ConfigurationManager.AppSettings["AscBimsServcieDomain"];
            var ascBimsServcieUserName = ConfigurationManager.AppSettings["AscBimsServcieUserName"];
            var ascBimsServciePassword = ConfigurationManager.AppSettings["AscBimsServciePassword"];

            client.ClientCredentials.Windows.ClientCredential.Domain = ascBimsServcieDomain;
            client.ClientCredentials.Windows.ClientCredential.UserName = ascBimsServcieUserName;
            client.ClientCredentials.Windows.ClientCredential.Password = ascBimsServciePassword;

            var tempUser = client.StaffSByStaffNO(userId, AppSetting.Instance.AscKey);

            //var tempUser = client.StaffSByStaffNO(userId.ToUpper(), AppSetting.Instance.AscKey);
            if (!string.IsNullOrEmpty(tempUser.STAFF_NO))
            {
                //为AppContext对象赋值
                user.UserId = userId.Trim().ToUpper();
                user.UserName = tempUser.STAFF_NAME;
                user.DeptNo = tempUser.DEPT_NO;
                user.DeptName = tempUser.DEPT_NAME;

                if (loginModel != null)
                {
                    user.ProjectCode = defaultStationCode;
                }
                else
                {

                    return false;

                }
                AppContext.CurrentUser = user;
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// 多语言切换
        /// </summary>
        /// <param name="lang">语言名称:cn/en-US</param>
        /// <returns></returns>
        public ActionResult SetCultureLang(string lang)
        {
            try
            {
                GlobalizationManager.SetCurrentCulture(lang);
                Response.Redirect("~/Home/Index", true);
                return Json(new { result = true, message = "多语言切换成功" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { result = false, message = "多语言切换失败," + ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
    }
}
