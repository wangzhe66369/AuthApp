﻿using OSharp.Entity;


namespace ZheZhe.CMS.Infos.Entities
{
    [TableNamePrefix("Infos")]
    public partial class MessageReply
    {
    }
}
