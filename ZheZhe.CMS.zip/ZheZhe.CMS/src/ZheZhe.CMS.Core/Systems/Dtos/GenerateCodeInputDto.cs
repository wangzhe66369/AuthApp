﻿// -----------------------------------------------------------------------
//  <copyright file="GenerateCodeInputDto.cs" company="OSharp开源团队">
//      Copyright (c) 2014-2019 OSharp. All rights reserved.
//  </copyright>
//  <site>http://www.osharp.org</site>
//  <last-editor>郭明锋</last-editor>
//  <last-date>2019-01-06 22:37</last-date>
// -----------------------------------------------------------------------

namespace ZheZhe.CMS.Systems.Dtos
{
    /// <summary>
    /// 代码生成输入DTO
    /// </summary>
    public class GenerateCodeInputDto
    { }
}