﻿
using OSharp.Core.Systems;


namespace ZheZhe.CMS.Systems.Dtos
{
    /// <summary>
    /// 系统设置项
    /// </summary>
    public class SystemSetting : ISetting
    {
    }
}
