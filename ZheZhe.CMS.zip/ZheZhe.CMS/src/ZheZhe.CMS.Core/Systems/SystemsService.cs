﻿// -----------------------------------------------------------------------
//  <copyright file="SystemsService.cs" company="OSharp开源团队">
//      Copyright (c) 2014-2019 OSharp. All rights reserved.
//  </copyright>
//  <site>http://www.osharp.org</site>
//  <last-editor>郭明锋</last-editor>
//  <last-date>2019-01-08 13:37</last-date>
// -----------------------------------------------------------------------

namespace ZheZhe.CMS.Systems
{
    /// <summary>
    /// 业务实现：系统模块
    /// </summary>
    public class SystemsService
    { }
}